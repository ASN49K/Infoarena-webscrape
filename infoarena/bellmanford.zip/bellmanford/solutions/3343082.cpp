#include <bits/stdc++.h>
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
const int NMAX = 50001, INF = 5e8;
int n, m, dist[NMAX];
bool in_queue[NMAX];
vector<pair<unsigned short, short>> adj[NMAX];
map<pair<unsigned short, unsigned short>, unsigned short> used;

bool Bellman(int source)
{
    fill(dist + 1, dist + n + 1, INF);
    dist[source] = 0;
    queue<unsigned short> Q({source});
    while(!Q.empty())
    {
        int node = Q.front(); Q.pop();
        in_queue[node] = false;
        for(auto [next, cost] : adj[node])
        {
            if(dist[node] + cost < dist[next])
            {
                dist[next] = dist[node] + cost;
                used[{node, next}]++;
                if(used[{node, next}] == n)
                    return true;
                if(!in_queue[next])
                {
                    Q.push(next);
                    in_queue[next] = true;
                }
            }
        }
    }
    return false;
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int u, v, cost;
        fin >> u >> v >> cost;
        adj[u].push_back({v, cost});
        used[{u, v}] = 0;
    }
    if(Bellman(1))
        fout << "Ciclu negativ!";
    else
        for(int node = 2; node <= n; node++)
            fout << dist[node] << " ";

    fin.close();
    fout.close();
    return 0;
}
