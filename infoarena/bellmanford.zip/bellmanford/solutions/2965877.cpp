#include <iostream>
#include <bits/stdc++.h>

using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

int n, m, x, y, z;
vector<pair<int, int>> g[50001];
vector<int> dist(50001, INT_MAX), nr(50001);
vector<float> dist2(50001, 99999999);
queue<int> q;
bool viz[50001];

float abss(float x)
{
    if (x<0){
        x*=-1;
        x/=100;
    }
    return x;
}

bool bellmanford() {
    q.push(1);
    dist[1] = 0;
    dist2[1] = 0;

    while (!q.empty()) {
        int t = q.front();
        q.pop();
        viz[t] = 0;

        for (auto& x : g[t]) {
            cout << dist2[t]+abss(x.second) << " " << dist2[x.first] << endl;
            if (dist[x.first] > dist[t] + x.second) {
                nr[x.first]++;
                if (dist2[x.first] <= dist2[t] + x.second) {
                    cout << "exista";
                    return 0;
                }
            if (dist2[x.first] > dist2[t] + abss(x.second))
                dist2[x.first] = dist2[t] + abss(x.second);
            dist[x.first] = dist[t] + x.second;
                if (!viz[x.first]) {
                    q.push(x.first);
                }
                viz[x.first] = 1;
            }
        }
    }

    return 1;
}

int main() {
    cout <<abss(-6);
    fin >> n >> m;
    for (int i = 0; i < m; i++) {
        fin >> x >> y >> z;
        g[x].push_back(make_pair(y, z));
    }
    if (bellmanford()) {
        for (int i = 2; i <= n; i++) {
            fout << dist[i] << " ";
        }
    } else {
        fout << "Ciclu negativ!";
    }
}
