#include <bits/stdc++.h>

using namespace std;

vector <pair<int,int>> graph[50005];
int distances[50005];
int noOfNodes[50005];
bool IsInQueue[50005];

void bellman(int source, int n)
{
    for(int i=1; i<=n; i++)
    {
        distances[i]=1e9;
    }
    queue <int> q;
    distances[source]=0;
    noOfNodes[source]=1;
    q.push(source);
    IsInQueue[source]=true;

    while(!q.empty())
    {
        int node = q.front();
        q.pop();
        IsInQueue[node]=false;

        if(noOfNodes[node] > n)
        {
            cout<<"Ciclu negativ!";
            exit(0);
        }

        for(auto x : graph[node])
        {
            if(distances[x.first] > distances[node] + x.second)
            {
                distances[x.first] = distances[node] + x.second;
                noOfNodes[x.first] = noOfNodes[node] + 1;
                if(!IsInQueue[x.first])
                {
                    q.push(x.first);
                }
            }
        }
    }
}

int main()
{
    int n, m;
    cin>>n>>m;
    for(int i=0; i<m; i++)
    {
        int u, v, w;
        cin>>u>>v>>w;
        graph[u].push_back({v,w});
    }
    int source = 1;
    bellman(source,n);
    for(int i=2; i<=n; i++)
    {
        cout<<distances[i]<<" ";
    }
    return 0;
}
