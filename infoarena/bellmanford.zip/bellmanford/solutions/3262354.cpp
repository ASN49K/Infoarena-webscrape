#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <bitset>
#include <algorithm>
#include <cassert>
using namespace std;

const char iname[] = "bellmanford.in";
const char oname[] = "bellmanford.out";

const int MAX_N = 50005;
const int INF = 0x3f3f3f3f;

vector < pair <int, int> > adj[MAX_N];
vector <int> adj_t[MAX_N];

int main(void) {
    ifstream in(iname);
    int nodes, edges;
    assert(in >> nodes >> edges);
    assert(1 <= nodes && nodes <= 50000);
    assert(1 <= edges && edges <= 250000);
    for (int i = 0; i < edges; ++ i) {
        int x, y, c;
        assert(in >> x >> y >> c);
        assert(1 <= x && x <= nodes);
        assert(1 <= y && y <= nodes);
        assert(-1000 <= c && c <= 1000);
        adj[x].push_back(make_pair(y, c));
        assert(find(adj_t[x].begin(), adj_t[x].end(), y) == adj_t[x].end());
        adj_t[x].push_back(y);
    }
    in.close();

    queue <int> Q;
    bitset <MAX_N> in_queue(false);
    vector <int> dist(MAX_N, INF), cnt_in_queue(MAX_N, 0);
    int negative_cycle = false;

    dist[1] = 0, Q.push(1), in_queue[1].flip();
    while (!Q.empty() && !negative_cycle)  {
        int x = Q.front();
        Q.pop();
        in_queue[x] = false;
        vector < pair <int, int> >::iterator it;
        for (it = adj[x].begin(); it != adj[x].end(); ++ it) if (dist[x] < INF)
            if (dist[it->first] > dist[x] + it->second) {
                dist[it->first] = dist[x] + it->second;
                if (!in_queue[it->first]) {
                    if (cnt_in_queue[it->first] > nodes)
                        negative_cycle = true;
                    else {
                        Q.push(it->first);
                        in_queue[it->first] = true;
                        cnt_in_queue[it->first] ++;
                    }
                }
            }
    }

    ofstream out(oname);
    if (!negative_cycle) {
        for (int i = 2; i <= nodes; ++ i)
            out << dist[i] << " ";
    }
    else
        out << "Ciclu negativ!\n";
    out.close();

    return 0;
}