// https://www.infoarena.ro/problema/bellmanford - Szücs Patrik - Kevin
#include <fstream>
#include <vector>
#include <climits>

struct edge
{
    int from, to, price;
};

int main()
{
    int n, m;
    std::ifstream in("bellmanford.in");
    in >> n >> m;

    std::vector<edge> edges(m);

    for (int i = 0; i < m; i++)
        in >> edges[i].from >> edges[i].to >> edges[i].price;
    in.close();

    //------------------------------------------------------------------------------------
    // Bellmanford
    std::vector<int> dist(n + 1, INT_MAX);
    dist[1] = 0;

    for (int i = 1; i < n; i++)
        for (auto &e : edges)
            if (dist[e.from] != INT_MAX && dist[e.from] + e.price < dist[e.to])
                dist[e.to] = dist[e.from] + e.price;

    bool changed = false;
    for (auto &e : edges)
        if (dist[e.from] + e.price < dist[e.to])
        {
            changed = true;
            break;
        }

    //------------------------------------------------------------------------------------

    std::ofstream out("bellmanford.out");
    if (changed)
        out << "Ciclu negativ!";
    else
        for (int i = 2; i <= n; i++)
            out << dist[i] << ' ';

    out.close();
    return 0;
}