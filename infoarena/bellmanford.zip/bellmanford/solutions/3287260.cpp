#include <iostream>
#include <fstream>
using namespace std;
ifstream fcin("bellmanford.in");
ofstream fcout("bellmanford.out");
const int inf=26000000;
struct nod
{
    int x,y,c;
} muchii[250001] ;
int d[50001],n,m;

int bellman_ford()
{
    int i=1,modif=1,j,k;
    while (i<=n && modif)
    {
        modif=0;
        for(j=1; j<=m; j++)
            if(d[muchii[j].y]>d[muchii[j].x]+muchii[j].c)
        {
            d[muchii[j].y]=d[muchii[j].x]+muchii[j].c;
            modif=1;
        }
    }
    for(j=1; j<=m; j++)
            if(d[muchii[j].y]>d[muchii[j].x]+muchii[j].c) return 0;
    return 1;
}

int main()
{
    int i,j,x,y,z;
    fcin>>n>>m;
    //cout<<m<<' '<<n<<endl;
    for(i=1; i<=n; i++) d[i]=inf;
    d[1]=0;
    for(i=1; i<=m; i++)
        fcin>>muchii[i].x>>muchii[i].y>>muchii[i].c;

    int rez=bellman_ford();
    //cout<<rez;
    if(rez)

        for(i=2; i<=n; i++)
        {
            if(d[i]==inf)
                fcout<<"-1 ";
            else fcout<<d[i]<<' ';
        }
    else fcout<<"Ciclu negativ!";
    return 0;
}
