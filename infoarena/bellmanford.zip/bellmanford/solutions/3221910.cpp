﻿#include <bits/stdc++.h>
#include <unordered_map>
#define nmax 50006
#define MOD 1999999973
#define INF 2012345678
#define ll long long
using namespace std;

ifstream f("bellmanford.in");
ofstream g("bellmanford.out");

int n, m;
vector <pair <int, int>> L[nmax];
queue <int> q;
bitset <nmax> viz;
int d[nmax], cnt[nmax];

bool BellmanFord(int k) {
	int x, cost;
	for (int i = 1; i <= n; i++)
		d[i] = INF;
	q.push(k);
	d[k] = 0;
	viz[k] = 1;
	while (!q.empty()) {
		k = q.front();
		q.pop();
		viz[k] = 0;
		for (auto w : L[k]) {
			x = w.second;
			cost = w.first;
			if (d[x] > d[k] + cost) {
				d[x] = d[k] + cost;
				if (viz[x] == 0) {
					viz[x] = 1;
					q.push(x);
					cnt[x]++;
					if (cnt[x] > n)
						return 1;
				}
			}
		}
	}

	return 0;
}

int main()
{
	int i, x, y, cost;
	f >> n >> m;
	for (i = 1; i <= m; i++) {
		f >> x >> y >> cost;
		L[x].push_back({ cost, y });
	}

	if (BellmanFord(1))
		g << "Ciclu negativ!";
	else {
		for (i = 2; i <= n; i++)
			g << d[i] << " ";
		g << "\n";
	}

	return 0;
}