#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f("bellmanford.in");
ofstream g("bellmanford.out");
vector<pair<int,int>>adj[500002];
int distante[500002];
int tata[500002];
bool bellmanford(int start,int n)
{
    for(int i=1; i<=n; i++)
    {
        distante[i]=1000000000;
        tata[i]=-1;
    }
    distante[start]=0;
    for(int i=1; i<n; i++)
    {   
        bool modif=false;
        for(int u=1; u<=n; u++)
        {
            if(distante[u]==1000000000)
            {
                continue;
            }
            for(pair<int,int>muchie:adj[u])
            {
                int vecin=muchie.first;
                int cost=muchie.second;
                if(distante[u]+cost<distante[vecin])
                {
                    distante[vecin]=distante[u]+cost;
                    modif=true;
                    tata[vecin]=u;
                }
            }
        }
        if(modif==false)
        {
            break;
        }
    }
    for(int u=1; u<=n; u++)
    {
        if(distante[u]==1000000000)
        {
            continue;
        }
        for(pair<int,int>muchie:adj[u])
        {
            int vecin=muchie.first;
            int cost=muchie.second;
            if(distante[u]+cost<distante[vecin])
            {
                return false;
            }
        }
    }
    return true;
}
int main()
{
int n,m;
f>>n>>m;
for(int i=1; i<=m; i++)
    {
    int x,y,z;
    f>>x>>y>>z;
    adj[x].push_back({y,z});
    }
if(bellmanford(1,n)==false)
{
    g<<"Ciclu negativ!";
}
else
{
for(int i=2; i<=n; i++)
{
    if(distante[i]==1000000000)
    {
        g<<0<<" ";
    }
    else
    {
    g<<distante[i]<<" ";
    }
}
}
return 0;
}