#include <bits/stdc++.h>
using namespace std;

#define INF 1000000000

ifstream f("bellmanford.in");
ofstream g("bellmanford.out");

int n, m;
int d[50001];
int inQ[50001];
vector<pair<int,int>> v[50001];
int cnt[50001];

priority_queue< pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>> q;

void Dijkstra(int start)
{
    for(int i=1;i<=n;i++)
        d[i]=INF;

    d[start]=0;
    q.push({0,start});
    cnt[start]=1;

    while(!q.empty())
    {
        auto [dist,nod]=q.top();
        q.pop();
        inQ[nod]=0;

        for(auto &e:v[nod])
        {
            int vecin=e.first;
            int cost=e.second;

            if(d[nod]+cost<d[vecin])
            {
                d[vecin]=d[nod]+cost;
                if(inQ[vecin]==0)
                {q.push({d[vecin],vecin});
                 inQ[vecin]=1;
                }
            }
        }
    }
}

int main()
{
    f>>n>>m;
    for(int i=1;i<=m;i++)
    {   int x,y,z;
        f>>x>>y>>z;
        v[x].push_back({y, z});
    }
    Dijkstra(1);
    for(int i=2;i<=n;i++)
    {
        if(d[i]==INF) 
            g<<0<<" ";
        else 
            g<<d[i]<< " ";
    }
    
    return 0;
}

   
