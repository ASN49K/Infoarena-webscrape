#include <fstream>
#include <vector>
#include <queue>
#include <limits>

using namespace std;

ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

vector<vector<pair<int, int>>> ad;
int vis[100005];


bool bellmanford(int start, vector<int>& dist) {
    int N = dist.size() - 1;
    vector<int> in_queue(N + 1, 0);
    vector<bool> in_q(N + 1, false); 

    queue<int> q;
    dist[start] = 0;
    q.push(start);
    in_q[start] = true;
    in_queue[start] = 1;

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        in_q[u] = false;

        for (auto &[v, cost] : ad[u]) {
            if (dist[u] != numeric_limits<int>::max() && dist[v] > dist[u] + cost) {
                dist[v] = dist[u] + cost;

                if (!in_q[v]) {
                    q.push(v);
                    in_q[v] = true;
                    in_queue[v]++;

                    if (in_queue[v] > N) return false;
                }
            }
        }
    }

    return true;
}

int main() {
    int N, M;
    fin >> N >> M;

    ad.resize(N + 1);

    for (int i = 0; i < M; i++) {
        int u, v, c;
        fin >> u >> v >> c;
        ad[u].push_back({v, c});
    }

    vector<int> dist(N + 1, 1e9);
    bool ok = bellmanford(1, dist);

    if ( ok == false ){
        fout << "Ciclu negativ";
        return 0;
    }
    for ( int i = 2; i <= N; i++ ){
        fout << dist[i] << ' ';
    }
    return 0;
}
