#include <bits/stdc++.h>

using namespace std;
int n,m,a,b,d;
vector<pair<int,int>>dist[50005];
int distanta[50005]; ///graphanta de la 1
int nr_noduri[50005];
bool e_in_q[50005];

void bellman_ford()
{
    for(int i=2; i<=n; i++)
        distanta[i]=1e9;
    queue<int>q;
    nr_noduri[1]=1;
    q.push(1);
    e_in_q[1]=1;

    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        e_in_q[nod]=0;
        if (nr_noduri[nod] > n) /// ciclu infinit, distanta scade infinit
        {
            cout << "Ciclu negativ!";
            exit(0); /// termina programul
        }
        for(auto var: dist[nod])
            if(distanta[var.first]>distanta[nod]+var.second)
            {
                distanta[var.first]=distanta[nod]+var.second;
                nr_noduri[var.first]=nr_noduri[nod]+1;
                if(!e_in_q[var.first])
                {
                    q.push(var.first);
                    e_in_q[var.first]=1;
                }
            }
    }
}
int main()
{
   ifstream cin("bellmanford.in");
    ofstream cout("bellmanford.out");
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        cin>>a>>b>>d;
        dist[a].push_back({b,d});
    }
    bellman_ford();
    for(int i=2; i<=n; i++)
        cout<<distanta[i]<<" ";
    return 0;
}
