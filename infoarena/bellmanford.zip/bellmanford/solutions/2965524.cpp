#include <fstream>
#include <deque>
#include <vector>
#define INF 100000000
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

struct muchie{
    int nod, cost;
};

vector <muchie> l[50001];
deque <int> q;
int viz[50001], ap[50001], d[50001];

int main()
{
    int n, m, i, x, y, c;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y>>c;
        l[x].push_back({y, c});
    }
    for(i=2;i<=n;i++)
    {
        d[i]=INF;
    }
    q.push_back(1);
    viz[1]=1;
    ap[1]++;
    int t, vecin, cost;
    while(q.empty()==0)
    {
        t=q.front();
        q.pop_front();
        viz[t]=0;
        for(i=0;i<l[t].size();i++)
        {
            vecin=l[t][i].nod;
            cost=l[t][i].cost;
            if(d[vecin]>d[t]+cost)
            {
                d[vecin]=d[t]+cost;
                if(viz[vecin]==0)
                {
                    ap[vecin]++;
                    if(ap[vecin]>n)
                    {
                        fout<<"Ciclu negativ!";
                        return 0;
                    }
                    viz[vecin]=1;
                    q.push_front(vecin);
                }
            }
        }
    }
    for(i=2;i<=n;i++)
    {
        fout<<d[i]<<" ";
    }
}
