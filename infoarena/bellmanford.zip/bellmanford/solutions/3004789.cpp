#include <fstream>
#include <deque>
#include <vector>
#define dim 50001
#define inf 100000000
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

struct muchie{
    int nod, cost;
};

deque <int> dq;
int ap[dim], viz[dim], d[dim];
vector <muchie> l[dim];

int main()
{
    int n, m, i, x, y, c;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y>>c;
        l[x].push_back({y, c});

    }
    for(i=2;i<=n;i++)
    {
        d[i]=inf;
    }
    d[1]=0;
    ap[1]++;
    viz[1]=1;
    dq.push_back(1);
    while(dq.empty()==0)
    {
        int nod=dq.front();
        dq.pop_front();
        viz[nod]=0;
        for(int i=0;i<l[nod].size();i++)
        {
            int vecin=l[nod][i].nod;
            int cost=l[nod][i].cost;
            if(d[vecin]>d[nod]+cost)
            {
                d[vecin]=d[nod]+cost;
                if(viz[vecin]==0)
                {
                    viz[vecin]=1;
                    dq.push_back(vecin);
                }
                ap[vecin]++;
                if(ap[vecin]>n)
                {
                    fout<<"Ciclu negativ!";
                    return 0;
                }
            }
        }
    }
    for(i=2;i<=n;i++)
    {
        fout<<d[i]<<" ";
    }
}
