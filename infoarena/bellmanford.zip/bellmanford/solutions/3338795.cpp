#include <fstream>
#include <vector>
#include <queue>
#define NMAX 50002
#define INF 100000000
using namespace std;
ifstream fin ("bellmanford.in");
ofstream fout ("bellmanford.out");
struct arc {int vf,c;}; //extremitatea finala a arcului si costul sau
vector<arc> G[NMAX];
int n,m,start=1;
int cmin[NMAX];
int nr[NMAX];
bool circuitneg=0;
queue<int> C;
int main()
{
    int i,x,y,cost;
    arc a;
    fin>>n>>m;
    for(i=0; i<m; i++)
    {   fin>>x>>y>>cost;
        a.vf=y;
        a.c=cost;
        G[x].push_back(a);
    }
    for (i=1; i<=n; i++) cmin[i]=INF;
    cmin[start]=0;
    C.push(start);
    while (!C.empty() && !circuitneg)
    {
        x=C.front(); C.pop();
        //parcurg lista de diacenta a lui x
        for (i=0; i<G[x].size(); i++)
        {
            y=G[x][i].vf;cost=G[x][i].c;
            if (cmin[y]>cmin[x]+cost)
            {
                cmin[y]=cmin[x]+cost;
                nr[y]++;
                if (nr[y]==n) circuitneg=1;
                else C.push(y);
            }
        }
    }
    if (!circuitneg)
    for (i=2; i<=n; i++) fout<<cmin[i]<<' ';
    else fout<<"Ciclu negativ!";
    return 0;
}
