#include <iostream>
#include <fstream>
#include <cstring>
#include <queue>
#include <climits>
using namespace std;

ifstream f ("apa.in");
ofstream g ("apa.out");

int viz[350] , tata[350] , cap[350][350] , n , x , y , c , i;

vector < int >v[350];

int bfs (int start , int stop)
{
    memset (viz , 0 , sizeof (viz));
    memset (tata , 0 , sizeof (tata));
    queue < int > coada;
    coada.push (start);
    viz[start] = 1;
    tata[start] = -1;
    while (!coada.empty ())
    {
        int nod = coada.front ();
        coada.pop ();

        if (nod == stop)
            return true;

        for (int i = 0 ; i < v[nod].size () ; i++)
        {
            int vecin = v[nod][i];
            if (viz[vecin] == 0 && cap[nod][vecin] > 0)
            {
                tata[vecin] = nod;
                viz[vecin] = 1;
                coada.push (vecin);
            }
        }
    }
    return false;
}


int flux (int start , int stop)
{
    int flow  , maxflow = 0;
    while (bfs (start , stop))
    {
        for (int i = 0 ; i < v[n].size () ; i++)
        {
            int vecin = v[n][i];
            if (viz[vecin])
            {
                tata[n] = vecin;
                flow = INT_MAX;

                for (int j = n ; j != 1 ; j = tata[j])
                    flow = min (flow , cap[tata[j]][j]);

                for (int j = n ; j != 1 ; j = tata[j])
                {
                    cap[tata[j]][j] -= flow;
                    cap[j][tata[j]] += flow;
                }
                maxflow += flow;
            }
        }
    }
    return maxflow;
}

int main()
{
    f >> n;
    while (f >> x >> y >> c)
    {
        v[x].push_back (y);
        v[y].push_back (x);
        cap[x][y] = c;
    }
    int fl = flux (1 , n);
    if (fl)
    g << fl;
    else g << "Apa nu ajunge!";
    return 0;
}
