#include <bits/stdc++.h>

using namespace std;

#define oo 0x3f3f3f3f

ifstream f("bellmanford.in");
ofstream g("bellmanford.out");

int n, m;
vector<pair<int, int>> graph[50005];
bool viz[50005];
int nr[50005], dp[50005];

void read() {
  f>>n>>m;
  int x, y, z;
  for(int i = 1;i <= m;++i) {
    f>>x>>y>>z;
    graph[x].push_back(make_pair(y, z));
  }
}

void solve() {
  memset(dp, oo, sizeof(dp));
  dp[1] = 0;
  queue<int> q;
  q.push(1);

  while(!q.empty()) {
    int node = q.front();

    for(const auto& edge : graph[node]) {
      if(dp[edge.first] < dp[node] + edge.second) {
        continue;
      }

      dp[edge.first] = dp[node] + edge.second;
      if(!viz[edge.first]) {
        q.push(edge.first);
      }
      viz[edge.first] = true;
      nr[edge.first]++;

      if(nr[edge.first] >= n) {
        g<<"Ciclu negativ!";
        return;
      }
    }

    q.pop();
    viz[node] = false;
  }
  for(int i = 2;i <= n;++i) {
    g<<dp[i]<<" ";
  }
}

int main() {
  read();
  solve();

  return 0;
}
