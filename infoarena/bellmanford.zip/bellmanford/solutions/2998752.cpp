#include <bits/stdc++.h>

#define int long long

using namespace std;

ifstream fin("morcovi.in");
ofstream fout("morcovi.out");

const int nmax = 1000;
const int pmax = 12;

int n, v[nmax + 5];
int k, p[nmax + 5];
int distMax[nmax + 5], answer;
bool inQueue[nmax + 5][(1 << pmax) + 5];

struct elem
{
    int nod, cost, mask;
};
queue<elem> coada;

signed main()
{
    fin >> n;
    for(int i = 1; i <= n; i ++)
    {
        fin >> v[i];
    }
    fin >> k;
    for(int i = 1; i <= k; i ++)
    {
        fin >> p[i];
    }
    for(int pozStart = 1; pozStart <= n; pozStart ++)
    {
        distMax[pozStart] = v[pozStart];
        inQueue[pozStart][0] = true;
        coada.push({pozStart, v[pozStart], 0});
        while(!coada.empty())
        {
            int poz = coada.front().nod;
            int cost = coada.front().cost;
            int mask = coada.front().mask;
            coada.pop();
            inQueue[poz][mask] = false;
            for(int i = 1; i <= k; i ++)
            {
                int bit = (1 << (i - 1));
                if((mask & bit) == 0)
                {
                    int newPoz = poz + p[i];
                    int newCost = cost + v[newPoz];
                    int newMask = mask ^ bit;
                    if(newPoz <= n && newCost > distMax[newPoz])
                    {
                        distMax[newPoz] = newCost;
                        if(inQueue[newPoz][newMask] == false)
                        {
                            coada.push({newPoz, newCost, newMask});
                            inQueue[newPoz][newMask] = true;
                        }
                    }
                    newPoz = poz - p[i];
                    newCost = cost + v[newPoz];
                    if(newPoz >= 1 && newCost > distMax[newPoz])
                    {
                        distMax[newPoz] = newCost;
                        if(inQueue[newPoz][newMask] == false)
                        {
                            inQueue[newPoz][newMask] = true;
                            coada.push({newPoz, newCost, newMask});
                        }
                    }
                }
            }
        }
        for(int i = 1; i <= n; i ++)
        {
            answer = max(answer, distMax[i]);
            distMax[i] = 0;
        }
    }
    fout << answer << '\n';
}

