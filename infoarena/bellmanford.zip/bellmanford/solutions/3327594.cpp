#include <bits/stdc++.h>
#define oo 2000000000
using namespace std;


ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
///         nod  cost
vector< pair<int, int> > L[50002];
int cnt[50002], viz[50002];
int d[50002], n, m;
queue<int> q;


void BellmanFord()
{
    int i, k, c;
    for (i = 2; i <= n; i++)
        d[i] = oo;
    d[1] = 0;
    q.push(1);
    viz[1] = 1;
    cnt[1]++;
    while (!q.empty())
    {
        k = q.front();
        q.pop();
        viz[k] = 0;
        for (auto e : L[k])
        {
            i = e.first;
            c = e.second;
            if (d[i] > d[k] + c)
            {
                d[i] = d[k] + c;
                if (!viz[i])
                {
                    viz[i] = 1;
                    q.push(i);
                    cnt[i]++;
                    if (cnt[i] > n)
                    {
                        fout << "Ciclu negativ!";
                        fout.close();
                        return;
                    }
                }
            }
        }
    }
    for (i = 2; i <= n; i++)
        fout << d[i] << " ";
}

int main()
{
    int i, j, p, c;
    fin >> n >> m;
    for (p = 1; p <= m; p++)
    {
        fin >> i >> j >> c;
        L[i].push_back({j, c});
    }
    BellmanFord();
    return 0;
}