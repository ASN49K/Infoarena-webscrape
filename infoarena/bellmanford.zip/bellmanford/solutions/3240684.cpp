#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;
ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");


int sum=0;
int n,m;
int a ,b,co;
int drum[50005];

struct permission_de
{
    vector <int> p,c;

}v[50001];

int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>a>>b>>co;
        v[a].p.push_back(b);

        v[a].c.push_back(co);


    }

    for(int i=1;i<=n;i++)
    {
        drum[i]=(1<<30);
    }
drum[1]=0;
    for(int j=1;j<=n-1;j++)
    {
        for(int i=1;i<=n;i++)
        {
            if(drum[i]==(1<<30))
            {
                continue;
            }
            for(int k=0;k<v[i].p.size();k++)
            {

                if(drum[v[i].p[k]]>drum[i]+v[i].c[k]  )
                {
                    drum[v[i].p[k]]=drum[i]+v[i].c[k];

                }
            }


        }
        for(int k=2;k<=n;k++)
        {
            cout<<drum[k]<<" ";
        }
        cout<<'\n';




    }


    return 0;
}




























