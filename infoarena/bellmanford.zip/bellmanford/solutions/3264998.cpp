#include <fstream>
#include <queue>
#include <vector>
#include <stack>
#include <algorithm>
using namespace std;
ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");
int n,m,viz[50005],iq[50005],d[50005];
vector<pair<int,int>>l[50005];
queue<int>q;
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y,c;
        cin>>x>>y>>c;
        l[x].push_back({y,c});
    }

    for(int i=2;i<=n;i++)
        d[i]=1e9;

    q.push(1);
    d[1]=0;viz[1]=1;iq[1]=1;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        viz[nod]=0;
        for(int i=0;i<l[nod].size();i++)
        {
            int vecin=l[nod][i].first;
            int cost=l[nod][i].second;
            if(d[vecin]>d[nod]+cost)
            {
                d[vecin]=d[nod]+cost;
                if(viz[vecin]==0)
                {
                    viz[vecin]=1;
                    iq[vecin]++;
                    if(iq[vecin]>n)
                    {
                        cout<<"Ciclu negativ!";
                        return 0;
                    }
                    q.push(vecin);
                }

            }
        }
    }
    for(int i=2;i<=n;i++)
        cout<<d[i]<<" ";
    return 0;
}
