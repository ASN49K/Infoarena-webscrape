#include <fstream>
#include <vector>
#include <queue>
#define NMAX 50002
#define INF 1000000000
using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");
int n, m, cmin[NMAX], nr[NMAX], start=1;
struct arc { int vf, cost; };
vector <arc> G[NMAX];
queue <int> C;
int main()
{   
	int i, j, x, y, c;
	bool circuitneg = 0;
	arc a;
	fin >> n >> m;
	for (i = 1; i <= m; i++)
	{
		fin >> x >> y >> c;
		a.vf = y;
		a.cost = c;
		G[x].push_back(a);
	}
	for (i = 1; i <= n; i++)
		cmin[i] = INF;
	cmin[start] = 0;
	C.push(start);
	while (!C.empty() && !circuitneg)
	{
		x = C.front();
		C.pop();
		for (i = 0; i < G[x].size(); i++)
		{
			y = G[x][i].vf;
			c = G[x][i].cost;
			if (cmin[y] > cmin[x] + c)
			{
				cmin[y] = cmin[x] + c;
				nr[y]++;
				if (nr[y] == n) circuitneg = 1;
				else C.push(y);
			}
		}
	}
	for (i = 2; i <= n; i++)
		fout << cmin[i] << ' ';
	return 0;
}