///DIJKSTRA
// #include<iostream>
// #include<vector>
// #include<queue>
// #include<fstream>
// using namespace std;
// ifstream f("dijkstra.in");
// ofstream g("dijkstra.out");
// vector<vector<pair<int,int>>>LA;
// const int inf=1e9+5;
// vector<long long>dist(50001,inf);
// vector<int>vis(50001,0);
// int n,m,a,b,c;
// int main()
// {
//     f>>n>>m;
//     LA.resize(n+1);
//     for(int i=0;i<m;i++)
//     {
//         f>>a>>b>>c;
//         LA[a].push_back({b,c});
//         // LA[b].push_back({a,c});
//     }
//     int s=1;
//     dist[s]=0;
//     priority_queue<pair<long long, int>>pq;
//     pq.push({-dist[s],s});
//     while(!pq.empty())
//     {
//         int nod=pq.top().second;
//         pq.pop();
//         if(vis[nod])continue;
//         vis[nod]=1;
//         for(auto it:LA[nod])
//         {
//             int vecin=it.first;
//             int cost=it.second;
//             if(dist[nod]+cost<dist[vecin])
//             {
//                 dist[vecin]=dist[nod]+cost;
//                 pq.push({-dist[vecin],vecin});
//             }
//         }
        
//     }
//     for(int i=2;i<=n;i++)
//     {
//         if(dist[i]==inf)g<<0<<" ";
//         else g<<dist[i]<<" ";
//     }
//     return 0;
// }


///ROY WARSHALL/FLOYD
// #include <iostream>
// #include <fstream>
// #include <vector>
// using namespace std;
// ifstream f("royfloyd.in");
// ofstream g("royfloyd.out");
// int c[101][101];
// const int inf=1e9+5;
// int n;
// vector<vector<int>>dist;
// int main()
// {
//     f>>n;
//     dist.resize(n,vector<int>(n,inf));
//     for(int i=0;i<n;i++)
//     {
//         for(int j=0;j<n;j++)
//         {
//             f>>c[i][j];
//         }
//     }
//     for(int i=0;i<n;i++)
//     {
//         for(int j=0;j<n;j++)
//         {
//             if(c[i][j]==0 && i!=j)dist[i][j]=inf;
//             else dist[i][j]=c[i][j];
//         }
//     }
//     for(int k=0;k<n;k++)
//     {
//         for(int i=0;i<n;i++)
//         {
//             for(int j=0;j<n;j++)
//             {
//                 if(dist[i][k]+dist[k][j]<dist[i][j])
//                 {
//                     dist[i][j]=dist[i][k]+dist[k][j];
//                 }
//             }
//         }
//     }
//     for(int i=0;i<n;i++)
//     {
//         for(int j=0;j<n;j++)
//         {
//             if(dist[i][j]==inf)g<<0<<" ";
//             else g<<dist[i][j]<<" ";
//         }
//         g<<"\n";
//     }
// }

///BELLMAN FORD
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("bellmanford.in");
ofstream g("bellmanford.out");
const int inf=1e9+5;
vector<int>dist(50001,inf);
vector<int>cnt(50001,0);
vector<int>inQ(50001,0);
int n,m,a,b,c;
vector<vector<pair<int,int>>>LA;
int main()
{
    f>>n>>m;
    LA.resize(n+1);
    for(int i=0;i<m;i++)
    {
        f>>a>>b>>c;
        LA[a].push_back({b,c});
        // LA[b].push_back({a,c});
    }
    int s=1;
    dist[s]=0;
    cnt[s]=1;
    queue<int>q;
    q.push(s);
    inQ[s]=1;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        inQ[nod]=0;
        for(auto it:LA[nod])
        {
            int vecin=it.first;
            int cost=it.second;
            if(dist[nod]+cost<dist[vecin])
            {
                dist[vecin]=dist[nod]+cost;
                if(inQ[vecin]==0)
                {
                    q.push(vecin);
                    inQ[vecin]=1;
                    cnt[vecin]++;
                    if(cnt[vecin]>n)
                    {
                        g<<"Ciclu negativ!\n";
                        return 0;
                    }
                }
            }
        }
    }
        for(int i=2;i<=n;i++)
        {
            if(dist[i]==inf)g<<0<<" ";
            else g<<dist[i]<<" ";
        }
        
}