#include <fstream>
#include <vector>
#include <set>
using namespace std;
ifstream cin("bellmanford.in");
ofstream cout("bellmanford.out");

const int INF = 1e9;

vector<vector<pair<int, int>>> ad;
int n, m;
vector<int> dist;

void init()
{
    for (int i = 1;i <= n;i++)
    {
        dist[i] = INF;
    }
}

void ford()
{
    set<pair<int, int>> pq;
    dist[1] = 0;
    pq.insert({ 0,1 });
    while (!pq.empty())
    {
        auto min1 = *pq.begin();
        int u = min1.second;
        pq.erase(min1);
        for (int i = 0;i < ad[u].size();i++)
        {
            int vr = ad[u][i].first;
            int wei = ad[u][i].second;
            if (dist[vr] > dist[u] + wei)
            {
                dist[vr] = dist[u] + wei;
                pq.insert({ dist[vr],vr });
            }
        }
    }
}

int main()
{
    cin >> n >> m;
    dist.resize(n + 1);
    init();
    int a, b, c;
    ad.resize(n + 1);
    for (int i = 1;i <= m;i++)
    {
        cin >> a >> b >> c;
        ad[a].push_back({ b,c });
    }
    ford();
    for (int i = 2;i <= n;i++)
    {
        cout << dist[i] << " ";
    }
    return 0;
}