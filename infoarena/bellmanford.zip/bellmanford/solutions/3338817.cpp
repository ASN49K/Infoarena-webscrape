#include <fstream>
#include <vector>
#include <queue>
#define NMAX 50002
#define INF 1e9

using namespace std;
ifstream fin("bellmanford.in");
ofstream fout("bellmanford.out");

struct arc{int vf,c;}; //extremitatea finala a arcului si costul sau
arc a;

vector<arc> G[NMAX];
queue<int> C;

int n,m, start=1;
int i,x,y,cost;
bool circuitneg=0;

int cmin[NMAX];
int nr[NMAX];

void citire();
void bellmanford();
void afisare();

int main()
{
    citire();
    bellmanford();
    afisare();

    return 0;
}

void citire()
{
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y>>cost;
        G[x].push_back({y,cost});
    }
}

void bellmanford()
{
    //initializare
    for(i=1; i<=n; i++)
        cmin[i]=INF;
    cmin[start]=0;
    C.push(start);

    while(!C.empty() && !circuitneg)
    {
        x=C.front();
        C.pop();

        //parcurg lista de adiacenta a lui x
        for(i=0; i<G[x].size(); i++)
        {
            y=G[x][i].vf;
            cost=G[x][i].c;

            if(cmin[y]>cmin[x]+cost)
            {
                cmin[y]=cmin[x]+cost;
                nr[y]++;

                if(nr[y]==n)
                    circuitneg=1;
                else
                    C.push(y);
            }
        }
    }
}

void afisare()
{
    if(circuitneg)
        fout<<"Ciclu negativ!"<<'\n';
    else
    {
        for(i=2; i<=n; i++)
            fout<<cmin[i]<<' ';
        fout<<'\n';
    }
}
