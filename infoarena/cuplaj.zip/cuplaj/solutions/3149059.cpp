#include <bits/stdc++.h>
#warning That's the baby, that's not my baby

typedef long long ll;

using namespace std;

const int NMAX = 1e4;

bool vis[NMAX + 1];
int l[NMAX + 1], r[NMAX + 1];
vector<int> g[NMAX + 1];

bool cupleaza (int u) {
    vis[u] = true;

    for (const auto &v : g[u]) { // asta e obvious, doar incercam sa punem u cu v
        if (!r[v]) {
            r[v] = u;
            l[u] = v;
            return true;
        }
    }

    for (const auto &v : g[u]) {
        if (!vis[r[v]] && cupleaza(r[v])) { // aici cred ca incercam sa cuplam u cu altcv
            r[v] = u;
            l[u] = v;
            return true;
        }
    }

    return false;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

#ifndef LOCAL
    freopen("cuplaj.in", "r", stdin);
    freopen("cuplaj.out", "w", stdout);
#endif

    int n, m, M;
    cin >> n >> m >> M;

    while (M--) {
        int u, v;
        cin >> u >> v;
        g[u].push_back(v);
    }

    int len = 0;

    bool repeat = true;

    while (repeat) {
        repeat = false;

        for (int i = 1; i <= n; i++) {
            vis[i] = false;
        }

        for (int i = 1; i <= n; i++) {
            if (!l[i] && cupleaza(i)) {
                len++;
                repeat = true;
            }
        }
    }

    cout << len << '\n';

    for (int i = 1; i <= n; i++) {
        if (l[i]) {
            cout << i << ' ' << l[i] << '\n';
        }
    }

    return 0;
}
