#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

int n,m,e,max_flow;
vector<vector<int>> adjacence_list;
vector <vector <int>> cap;
vector <int> root;
vector <bool> cuplat;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

bool bfs() {
    root = vector<int>(n+m+1,0);
    queue <int> q;
    q.push(1);
    while (!q.empty()) {
        int nod = q.front();
        q.pop();

        if (nod == n+m) {
            return true;
        }
        for (auto vecin : adjacence_list[nod]) {
            int current_cap = cap[nod][vecin];

            if (current_cap > 0 && root[vecin] == 0) {
                root[vecin] = nod;
                q.push(vecin);
            }
        }
    }

    return false;
}

int edmonds_karp_algorithm() {
    while (bfs()) {
        for (auto node : adjacence_list[n+m]) {
            if (root[node]) { // daca nodul are parinte dupa trecerea prin bfs
                root[n+m] = node; // il setam ca parintele destinatiei

                int current_flow = INT_MAX;
                int i = n+m;
                while (i != 1) {
                    current_flow = min(current_flow, cap[root[i]][i]);
                    i = root[i];
                }

                i = n+m;
                while (i != 1) {
                    cap[root[i]][i] -= current_flow;
                    cap[i][root[i]] += current_flow;
                    i = root[i];
                }

                max_flow += current_flow;
            }
        }
    }
    return max_flow;
}

int main()
{
    int x, y;
    f >> n >> m >> e;
    adjacence_list = vector<vector<int>>(n + m + 1);
    root = vector<int>(n + m + 1, 0);
    cap = vector<vector<int>>(n + m + 1, vector <int>(n + m + 1, 0));
    cuplat = vector<bool>(n + m + 1, false);
    for (int i = 0;i < e;i++) {
        f >> x >> y;
        if(find(adjacence_list[x].begin(), adjacence_list[x].end(), y+n) == adjacence_list[x].end())
            adjacence_list[x].push_back(y+n);
        if (find(adjacence_list[y+n].begin(), adjacence_list[y+n].end(), x) == adjacence_list[y+n].end())
            adjacence_list[y+n].push_back(x);
        cap[x][y+n] = 1;
    }
    for (int i = 2;i <= n;i++) {
        adjacence_list[1].push_back(i);
        adjacence_list[i].push_back(1);
        cap[1][i] = 1;
    }
    for (int i = 1;i < m;i++) {
        adjacence_list[i+n].push_back(n + m);
        adjacence_list[n + m].push_back(i + n);
        cap[i+n][n + m] = 1;
    }
    g << edmonds_karp_algorithm()<<endl;
    for (int i = 1;i <= n;i++) {
        int ok = 0;
        for (auto j : adjacence_list[i])
            if (cap[i][j] == 0 && j > n && !cuplat[i] && !cuplat[j]) {
                g << i << " " << j - n << endl;
                cuplat[i] = cuplat[j] = true;
                ok = 1;
                break;
            }
        if (!ok) {
            for (auto j : adjacence_list[i]) {
                if (cap[j][i] == 0 && j > n && !cuplat[i] && !cuplat[j])
                {
                    g << i << " " << j - n << endl;
                    cuplat[i] = cuplat[j] = true;
                    break;
                }
            }
        }
    }
    f.close();
    g.close();
}