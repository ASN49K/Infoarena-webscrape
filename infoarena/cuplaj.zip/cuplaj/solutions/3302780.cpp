#include <bits/stdc++.h>
#define MAX 10005
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n, m, e, x, y, cuplat1[MAX], cuplat2[MAX], nr, i, gasit;
vector<int>v[MAX];
bool pair_up(int nod) {
    for (auto x:v[nod]) {
        if (!cuplat2[x]) {
            cuplat2[x]=nod;
            cuplat1[nod]=x;
            return 1;
        }
    }
    for (auto x:v[nod]) {
        if (cuplat2[x] && cuplat2[x]!=nod && pair_up(cuplat2[x])) {
            cuplat2[x]=nod;
            cuplat1[nod]=x;
            return 1;
        }
    }
    return 0;
}
int main()
{
    fin>>n>>m>>e;
    for (i=1; i<=e; i++) {
        fin>>x>>y;
        v[x].push_back(y);
    }
    for (i=1; i<=n; i++) {
        for (auto x:v[i]) {
            if (!cuplat2[x]) {
                cuplat2[x]=i;
                cuplat1[i]=x;
                nr++;
                break;
            }
        }
    }
    do {
        gasit=0;
        for (i=1; i<=n; i++) if (!cuplat1[i] && pair_up(i)) gasit=1, nr++;
    } while (gasit);
    fout<<nr<<'\n';
    for (i=1; i<=n; i++) if (cuplat1[i]) fout<<i<<' '<<cuplat1[i]<<'\n';
    return 0;
}
