#include <bits/stdc++.h>

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

bool cty[10001][10001];
int fl[10001][10001];
int tata[10001];
vector <vector<int>> adjL;
vector  <int> viz;
int n1, n2, m, i, nr1, nr2, nr3, flow, minn, j;

int BFS(){
	queue<int> q;
	q.push(0);
	viz.assign(n1+n2+2, 0);
	while(!q.empty()){
		nr1 = q.front();
		q.pop();
		if(nr1 == n1+n2+1)
			break;
		viz[nr1]=1;
		for(auto &i : adjL[nr1]){
			if (!viz[i] && fl[nr1][i] != cty[nr1][i]){
				viz[i] = 1;
				tata[i] = nr1;
				q.push(i);
			}
		}
	}
	return viz[n1+n2+1];
}


int main(){
  	fin >>n1 >> n2>> m;
  	adjL.assign(n1+n2+2, vector<int>());
  	for(i = 0; i < m; ++i){
  		fin >> nr1 >> nr2;
  		adjL[nr1].push_back(nr2+n1);
  		adjL[nr2+n1].push_back(nr1);
  		cty[nr1][nr2+n1] = 1;
  	}
  	for (i = 1; i <= n1; ++i){
        adjL[0].push_back(i);
        adjL[i].push_back(0);
        cty[0][i]= 1;
  	}
  	for (i = n1+1; i <= n1+ n2 ; ++i){
        adjL[i].push_back(n1+n2+1);
        adjL[n1+n2+1].push_back(i);
        cty[i][n1+n2+1] = 1;
  	}
  	vector<pair <int, int>> rez;
  	//flow = 0;
  	while(BFS()){
  		for(auto &i:adjL[n1+n2+1]){
  			minn = INT_MAX;
  			tata[n1+n2+1] = i;
  			for (j = n1+n2+1; j> 0; j = tata[j]){
  				fl[tata[j]][j] += 1;
  				fl[j][tata[j]] -= 1;
  			}
  		}
  	}
  	for(i=1; i<= n1; ++i){
        for(auto &k : adjL[i]){
            if (fl[i][k] == 1){
                rez.push_back({i, k});
            }
        }
  	}
  	fout << rez.size() << "\n";
  	for( auto & k : rez)
        fout << k.first << " " << k.second << '\n';
    //fout << flow;
	return 0;
}
