/*
                `-/oo+/-   ``
              .oyhhhhhhyo.`od
             +hhhhyyoooos. h/
            +hhyso++oosy- /s
           .yoooossyyo:``-y`
            ..----.` ``.-/+:.`
                   `````..-::/.
                  `..```.-::///`
                 `-.....--::::/:
                `.......--::////:
               `...`....---:::://:
             `......``..--:::::///:`
            `---.......--:::::////+/`
            ----------::::::/::///++:
            ----:---:::::///////////:`
            .----::::::////////////:-`
            `----::::::::::/::::::::-
             `.-----:::::::::::::::-
               ...----:::::::::/:-`
                 `.---::/+osss+:`
                   ``.:://///-.
*/
#include <bits/stdc++.h>
#define dbg(x) cerr << #x << " " << x << '\n'
#define dbgsp(x) cerr << #x << " " << x << ' '

using namespace std;

ifstream in ("cuplaj.in");
ofstream out ("cuplaj.out");

bool pairup(int node, vector <int> &pairl, vector <int> &pairr,
        vector <bool> &viz, const vector <vector <int>> &g) {
    if (viz[node]) return false;
    viz[node] = true;

    for (int r : g[node])
        if (pairr[r] == 0) {
            pairl[node] = r;
            pairr[r] = node;
            return true;
        }

    for (int r : g[node])
        if (pairup(pairl[r], pairl, pairr, viz, g)) {
            pairl[node] = r;
            pairr[r] = node;
            return true;
        }

    return false;
}

int main() {
    int n, m, e;
    in >> n >> m >> e;

    vector <vector <int>> g(1 + n);
    for (int i = 0; i < e; i++) {
        int x, y;
        in >> x >> y;
        g[x].push_back(y);
    }
    
    bool change = true;
    vector <int> pairl(1 + n), pairr(1 + m);
    vector <bool> viz(1 + n);
    while (change) {
        change = false;
        fill(viz.begin(), viz.end(), false);
        for (int i = 1; i <= n; i++)
            if (pairl[i] == 0)
                change |= pairup(i, pairl, pairr, viz, g);
    }

    int cuplaj = 0;
    for (int i = 1; i <= n; i++)
        if (pairl[i])
            cuplaj++;
    
    out << cuplaj << '\n';
    for (int i = 1; i <= n; i++)
        if (pairl[i] > 0)
            out << i << ' ' << pairl[i] << '\n';

    in.close();
    out.close();
    return 0;
}
