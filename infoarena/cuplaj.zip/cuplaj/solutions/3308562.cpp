#include <bits/stdc++.h>

using namespace std;

ifstream in("cuplaj.in");
ofstream out("cuplaj.out");

const int MAX_N = 2e4 + 1;

int n, m, e;
int p[MAX_N];
bool used[MAX_N];
vector<int> g[MAX_N];

// Kuhn's algorithm - augmenting paths
bool match(int node) {
	if (used[node]) return false;
	used[node] = true;
	for (int son : g[node]) {
		if (p[son] == -1 || match(p[son])) {
			p[son] = node;
			return true;
		}
	}
	return false;
}

int main() {

	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	in >> n >> m >> e;

	for (int i = 1; i <= e; i++) {
		int x, y;
		in >> x >> y;
		y += n;
		g[x].push_back(y);
	}

	fill(p + 1, p + MAX_N, -1);

	int cnt = 0;
	for (int i = 1; i <= n; i++) {
		fill(used + 1, used + MAX_N, false);
		if (match(i)) {
			cnt++;
		}
	}

	out << cnt << '\n';

	for (int i = n + 1; i <= n + m; i++) {
		if (p[i] != -1) {
			out << p[i] << ' ' << i - n << '\n';
		}
	}

	return 0;
}
