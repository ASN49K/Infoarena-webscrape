#include <bits/stdc++.h>

using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int use[10005],a,b,cuplaj,l[10005],r[10005],n,m,e;
vector<int> muchii[10005];
bool ok;
bool pairup(int nod)
{
    if(use[nod])return 0;

    use[nod]=1;

    for(int i:muchii[nod])
        if(r[i]==0)
        {
            l[nod]=i;
            r[i]=nod;
            return 1;
        }
    for(int i:muchii[nod])
    {
        if(pairup(r[i]))
        {
            l[nod]=i;
            r[i]=nod;
            return 1;
        }
    }
    return 0;
}




int main()
{
    fin>>n>>m>>e;
    for(int i=1;i<=e;i++)
    {
        fin>>a>>b;
        muchii[a].push_back(b);
    }

    do{
        ok=0;
        for(int i=1;i<=n;i++)
            use[i]=0;
        for(int i=1;i<=n;i++)
            if(l[i]==0)ok|=pairup(i);


    }while(ok);

    for(int i=1;i<=n;i++)
    if(l[i])cuplaj++;

    fout<<cuplaj<<'\n';

    for(int i=1;i<=n;i++)
        if(l[i])
        fout<<i<<' '<<l[i]<<'\n';
    return 0;
}
