#include <bits/stdc++.h>

using namespace std;

const int NMAX = 10000;
const int VMAX = 2 * NMAX;

vector <int> edges[VMAX + 1];
bool viz[VMAX + 1];
int p[VMAX + 1];

bool dfs( int node ) {
    viz[node] = true;
    for ( auto vec : edges[node] ) {
        if ( !p[vec] || ( !viz[p[vec]] && dfs( p[vec] ) ) ) {
            p[node] = vec;
            p[vec] = node;
            return true;
        }
    }
    return false;
}
int main() {
    /// cuplaj
    ifstream fin( "cuplaj.in" );
    ofstream fout( "cuplaj.out" );
    int n, m, e, cuplaj = 0, improve = true;
    fin >> n >> m >> e;
    for ( int i = 1, a, b; i <= e; i ++ ) {
        fin >> a >> b;
        edges[a].push_back( b + n );
        edges[b + n].push_back( a );
    }
    while ( improve ) {
        improve = false;
        for ( int i = 1; i <= n; i ++ ) viz[i] = false;
        for ( int i = 1; i <= n; i ++ ) {
            if ( !viz[i] && !p[i] && dfs( i ) ) {
                cuplaj ++;
                improve = true;
            }
        }
    }
    fout << cuplaj << '\n';
    for ( int i = 1; i <= n; i ++ ) {
        if ( p[i] ) fout << i << ' ' << p[i] - n << '\n';
    }
    return 0;
}