#include <stdio.h>
#include <vector>

#define MAXN 10000

int n, m, match[2 * MAXN], dist[MAXN], coada[MAXN], viz[MAXN];
std::vector<int> g[2 * MAXN];

void bfs() {
  int i, prim, ultim, u1, v1, u2;
  
  prim = ultim = 0;
  for(i = 0; i < n; i++) {
    if(match[i] == -1) {
      dist[i] = 0;
      coada[ultim++] = i;
    } else {
      dist[i] = -1;
    }
  }
  
  while(prim != ultim) {
    u1 = coada[prim++];
    
    for(i = 0; i < (int)g[u1].size(); i++) {
      v1 = g[u1][i];
      u2 = match[v1];
      if(u2 >= 0 && dist[u2] == -1) {
        dist[u2] = dist[u1] + 1;
        coada[ultim++] = u2;
      }
    }
  }
}

int dfs(int u1) {
  int i, v1, u2, ret;
  
  viz[u1] = 1;
  i = 0;
  while(i < (int)g[u1].size() && (u2 = match[v1 = g[u1][i]]) >= 0 &&
                    (dist[u2] != dist[u1] + 1 || dfs(u2) == 0)) {
    i++;
  }
  
  ret = 0;
  if(i < (int)g[u1].size()) {
    ret = 1;
    match[u1] = v1;
    match[v1] = u1;
  }
  
  return ret;
}

int main() {
  int i, u, v, e, ok, ans;
  
  #ifndef LOCAL 
    freopen("cuplaj.in", "r", stdin);
    freopen("cuplaj.out", "w", stdout);
  #endif
  
  scanf("%d%d%d", &n, &m, &e);
  while(e--) {
    scanf("%d%d", &u, &v);
    u--;
    v += n - 1;
    g[u].push_back(v);
    g[v].push_back(u);
  }
  
  for(i = 0; i < n + m; i++) {
    match[i] = -1;
  }
  
  ans = 0;
  do {
    bfs();
    ok = 0;
    
    for(i = 0; i < n; i++) {
      viz[i] = 0;
    }
    for(i = 0; i < n; i++) {
      if(match[i] == -1 && dfs(i)) {
        ans++;
        ok = 1;
      }
    }
  } while(ok);
  
  printf("%d\n", ans);
  for(i = 0; i < n; i++) {
    if(match[i] >= 0) {
      printf("%d %d\n", i + 1, match[i] - n + 1);
    }
  }
  
  return 0;
}