#include <bits/stdc++.h>

#define MOD 1000000007

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

bool bfs(vector<unordered_map<int, bool> > graph, vector<int> &past, int n, int m)
{
    queue<int> que;
    que.push(0);

    for (int i = 0; i <= n + m + 1; ++i) {
        past[i] = -1;
    }

    while (!que.empty()) {
        int now = que.front();
        que.pop();

        if (now == n + m + 1) {
            return true;
        }

        for (auto nxt:graph[now]) {
            if (!nxt.first || nxt.second) {
                continue;
            }

            if (past[nxt.first] != -1) {
                continue;
            }
            past[nxt.first] = now;
            que.push(nxt.first);
        }
    }

    return false;
}

int main()
{
    int n, m, g;
    fin >> n >> m >> g;

    vector<unordered_map<int, bool> > graph(n + m + 2);

    for (int i = 1; i <= n; ++i) {
        graph[0].insert(make_pair(i, false));
        graph[i].insert(make_pair(0, true));
    }

    for (int i = n + 1; i <= n + m; ++i) {
        graph[i].insert(make_pair(n + m + 1, false));
        graph[n + m + 1].insert(make_pair(i, true));
    }

    while (g--) {
        int x, y;
        fin >> x >> y;
        graph[x].insert(make_pair(n + y, false));
        graph[n + y].insert(make_pair(x, true));
    }

    vector<int> past(n + m + 2);
    int sol = 0;
    while (bfs(graph, past, n, m)) {
        ++sol;

        int t = n + m + 1;
        while (past[t] != -1) {
            graph[t][past[t]] = false;
            graph[past[t]][t] = true;

            t = past[t];
        }
    }

    fout << sol << "\n";

    for (int i = 1; i <= n; ++i) {
        for (auto j:graph[i]) {
            if (j.first > n && j.first <= n + m && j.second) {
                fout << i << " " << j.first - n << "\n";
            }
        }
    }

    return 0;
}
