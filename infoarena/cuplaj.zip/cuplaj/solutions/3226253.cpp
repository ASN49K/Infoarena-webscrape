#include <bits/stdc++.h>

#pragma optimize GCC ("Ofast")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

///#include <tryhardmode>
///#include <GODMODE::ON>

using namespace std;

#define cin fin
#define cout fout

ifstream fin ("cuplaj.in");
ofstream fout ("cuplaj.out");

const int NMAX=1e5+5;

vector<int>v[NMAX];
bool viz[NMAX];
int st[NMAX];
int dr[NMAX];

bool pairup(int p)
{
    if(viz[p])
        return false;
    viz[p]=true;
    for(auto i:v[p])
    {
        if(!dr[i])
        {
            dr[i]=p;
            st[p]=i;
            return true;
        }
    }
    for(auto i:v[p])
    {
        if(pairup(dr[i]))
        {
            dr[i]=p;
            st[p]=i;
            return true;
        }
    }
    return false;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n,i,j,m,k;
    cin>>n>>m>>k;
    for(i=1;i<=k;i++)
    {
        int x,y;
        cin>>x>>y;
        v[x].push_back(y);
    }
    int kon=0;
    bool ok=true;
    while(ok)
    {
        ok=false;
        for(i=1;i<=n;i++)
            viz[i]=false;
        for(i=1;i<=n;i++)
        {
            if(!st[i])
            {
                int pairs=pairup(i);
                if(pairs)
                    ok=true;
                kon+=pairs;
            }
        }
    }
    cout<<kon<<"\n";
    for(i=1;i<=n;i++)
        if(st[i])
            cout<<i<<" "<<st[i]<<"\n";
    cin.close();
    cout.close();
    return 0;
}
