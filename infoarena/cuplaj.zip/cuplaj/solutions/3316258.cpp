// sursa inspiratie -> https://infoarena.ro/job_detail/3312475?action=view-source
#include <bits/stdc++.h>
#define VMAX 200007
#define INF 1e16+1
#define int long long int
using namespace std;
ifstream fin ("cuplaj.in");
ofstream fout ("cuplaj.out");

vector<int> graf[VMAX]; // nod si id
int nod_cu_care_e_cuplat[2][VMAX];
bool vizitat[VMAX];

vector<pair<int,int>> muchii_cuplate;

bool cuplaj(int nod)
{
    if(vizitat[nod])
        return 0;
    vizitat[nod]=1;

    //cautam o muchie goala
    for(auto it:graf[nod])
    {
        if(nod_cu_care_e_cuplat[1][it]==0) // cuplam
        {
            nod_cu_care_e_cuplat[0][nod]=it;
            nod_cu_care_e_cuplat[1][it]=nod;
            return 1;
        }
    }

    //cautam un drum luat si incercam sa marim drumul pe unul dintre acestea
    for(auto it:graf[nod])
    {
        if(nod_cu_care_e_cuplat[1][it])
        {
            //int nr = cuplaj(nod_cu_care_e_cuplat[1][it]) // cautam o cuplare mai buna in care it e conectat cu nod de fapt
            if(cuplaj(nod_cu_care_e_cuplat[1][it])) // daca am gasit solutie mai buna
            {
                nod_cu_care_e_cuplat[1][it]=nod;
                nod_cu_care_e_cuplat[0][nod]=it;
                return 1;
            }
        }
    }

    return 0;


}



signed main()
{
    ios_base::sync_with_stdio(0);
    int n,m,i,j,k,t,q,nr,lg,nod,minim,maxim,suma,st,dr,mij,ramase,ult_min,loc_ram;
    fin>>n>>m>>t;
    for(i=0;i<t;i++)
    {
        fin>>j>>k;
        graf[j].push_back(k);
    }
    bool modificare=1;

    while(modificare)
    {
        modificare=0;
        for(i=1;i<=n;i++)
            vizitat[i]=0;
        for(i=1;i<=n;i++)
            if(nod_cu_care_e_cuplat[0][i]==0 && cuplaj(i))
                modificare = 1;
    }


    for(i=1;i<=n;i++)
    {
        if(nod_cu_care_e_cuplat[0][i])
            muchii_cuplate.push_back({i,nod_cu_care_e_cuplat[0][i]});
    }

    fout<<muchii_cuplate.size()<<'\n';
    for(i=0;i<muchii_cuplate.size();i++)
        fout<<muchii_cuplate[i].first<<' '<<muchii_cuplate[i].second<<'\n';


    return 0;
}
