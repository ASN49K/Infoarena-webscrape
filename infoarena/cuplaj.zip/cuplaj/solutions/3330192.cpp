#include <bits/stdc++.h>

using namespace std;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

int n,m,E, u[10200],l[10200],r[10200];
vector <int> edges[10200];

bool pairup(int x){
	if(u[x])
		return 0;
	u[x] = 1;
	for(auto y:edges[x])
		if(r[y] == 0)
		{
			l[x] = y;
			r[y] = x;
			return 1;
		}
	for(auto y:edges[x])
		if(pairup(r[y]))
		{
			l[x] = y;
			r[y] = x;
			return 1;
		}
	return 0;
}

int main()
{
	f>>n>>m>>E;
	for(int i=1; i<=E; i++)
	{
		int x,y;
		f>>x>>y;
		edges[x].push_back(y);
	}
	int change=1;
	while(change)
	{
		change=0;
		memset(u, 0, sizeof(u));
		for(int i=1; i<=n; i++)
			if(l[i]==0)
				change |= pairup(i);
	}
	int cuplaj=0;
	for(int i=1; i<=n; i++)
		if(l[i])
			cuplaj++;
	g<<cuplaj<<'\n';
	for(int i=1; i<=n; i++)
		if(l[i]>0)
			g<<i<<' '<<l[i]<<'\n';
	return 0;
}