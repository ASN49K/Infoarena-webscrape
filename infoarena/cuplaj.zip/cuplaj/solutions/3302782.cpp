#include <bits/stdc++.h>
#define MAX 10005
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n, m, e, x, y, cuplat[2*MAX], viz[MAX], nr, i, gasit;
vector<int>v[MAX];
bool pair_up(int nod) {
    viz[nod]=1;
    for (auto x:v[nod]) {
        if (!cuplat[x]) {
            cuplat[x]=nod;
            cuplat[nod]=x;
            return 1;
        }
    }
    for (auto x:v[nod]) {
        if (cuplat[x] && cuplat[x]!=nod && viz[cuplat[x]]==0 && pair_up(cuplat[x])) {
            cuplat[x]=nod;
            cuplat[nod]=x;
            return 1;
        }
    }
    return 0;
}
int main()
{
    fin>>n>>m>>e;
    for (i=1; i<=e; i++) {
        fin>>x>>y;
        y+=n;
        v[x].push_back(y);
    }
    for (i=1; i<=n; i++) {
        for (auto x:v[i]) {
            if (!cuplat[x]) {
                cuplat[x]=i;
                cuplat[i]=x;
                nr++;
                break;
            }
        }
    }
    do {
        gasit=0;
        for (i=1; i<=n; i++) viz[i]=0;
        for (i=1; i<=n; i++) if (!cuplat[i] && pair_up(i)) gasit=1, nr++;
    } while (gasit);
    fout<<nr<<'\n';
    for (i=1; i<=n; i++) if (cuplat[i]) fout<<i<<' '<<cuplat[i]-n<<'\n';
    return 0;
}
