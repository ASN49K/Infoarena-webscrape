#include <fstream>
#include <cstdio>
#include <vector>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n,m,p,viz[10005],l[10005],r[10005],cuplaj,e;
vector<int>muchii[10005];
bool pairup(int x){
    if(viz[x]) return 0;
    viz[x]=1;
    for(auto it:muchii[x]){
      if(r[it]==0){
          r[it]=x;
          l[x]=it;
          return 1;
      }
    }
    for(auto it: muchii[x]){
      if(pairup(r[it])){
          r[it]=x;
          l[x]=it;
          return 1;
      }
    }
    return 0;
}
int main()
{
   ios::sync_with_stdio(false);
   fin.tie(0);
   fin>>n>>m>>e;
   for(int i=1;i<=e;++i){
      int x,y;
      fin>>x>>y;
      muchii[x].push_back(y);
   }
   bool ok=0;
   do{
      ok=0;
      for(int i=1;i<=n;++i) viz[i]=0;
      for(int i=1;i<=n;++i){
        if(l[i]==0) ok|=pairup(i);
      }
   }while(ok);
   for(int i=1;i<=n;++i){
    if(l[i]) cuplaj++;
   }
   fout<<cuplaj<<'\n';
   for(int i=1;i<=n;++i){
      fout<<i<<' '<<l[i]<<'\n';
   }
    return 0;
}
