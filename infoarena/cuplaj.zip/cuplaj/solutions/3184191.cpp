#include<bits/stdc++.h>
using namespace std;
ifstream F("cuplaj.in");
ofstream G("cuplaj.out");
#define N 10001
vector<int> g[N];
int l[N],r[N],n,m,e,c=1,i,j;
bitset<N> u,v;
int P(int n)
{
    if(u[n])
		return 0;
    int i,j=g[n].size();
    for(u[n]=1,i=0;i<j;i++)
		if(!r[g[n][i]])
        	return l[n]=g[n][i],r[g[n][i]]=n,1;
    for(i=0;i<j;i++)
		if(P(r[g[n][i]]))
        	return l[n]=g[n][i],r[g[n][i]]=n,1;
    return 0;
}
int main()
{
    for(F>>n>>m>>e;e--;F>>i>>j,g[i].push_back(j));
    for(;c;)
        for(c=0,u=v,i=1;i<=n;!l[i]?c|=P(i):0,++i);
    for(j=0,i=1;i<=n;j+=l[i]>0,++i);
    for(G<<j<<'\n',i=1;i<=n;++i)
		if(l[i])
            G<<i<<' '<<l[i]<<'\n';
    return 0;
}
