#include <bits/stdc++.h>
using namespace std;

string const& task("cuplaj");
ifstream fin(task + ".in");
ofstream fout(task + ".out");

int const N(1e4 + 5);

int lm[N], rm[N], n, m, e;
vector<int> g[N];
bitset<N> viz;
vector<pair<int, int>> res;

inline bool Match(int const& x) {
    if (viz[x])
        return false;
    viz[x] = 1;
    for (int const& y : g[x])
        if (!lm[y] || Match(lm[y])) {
            lm[y] = x, rm[x] = y;
            return true;
        }
    return false;
}

signed main() {

    fin >> n >> m >> e;
    while (e--) {
        int x, y;
        fin >> x >> y;
        g[x].emplace_back(y);
    }
    bool tinder = true;
    while (tinder) {
        tinder = false;
        viz.reset();
        for (int i = 1; i <= n; ++i)
            if (!rm[i] && Match(i))
                tinder = true;
    }
    for (int i = 1; i <= n; ++i)
        if (rm[i])
            res.emplace_back(i, rm[i]);
    fout << res.size() << '\n';
    for (pair<int, int> const& P : res)
        fout << P.first << ' ' << P.second << '\n';

    return 0;
}
