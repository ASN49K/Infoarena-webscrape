#pragma GCC optimize("O3")
#include <bits/stdc++.h>

using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
const int Nmax=1e4+5;
vector<int> v[Nmax];
int vis[Nmax];
int pl[Nmax],pr[Nmax];
bool augment(int nod)/// TOT TIMPUL NOD STANG
{
    for(int u:v[nod])
    {
        if(!vis[u])
        {
            vis[u]=1;
            if(!pr[u] || augment(pr[u]))
            {
                pr[u]=nod;
                pl[nod]=u;
                return 1;
            }
        }
    }
    return 0;
}
int main()
{
    int n,m,e;
    fin>>n>>m>>e;
    for(int i=1;i<=e;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
    }
    bool ok=1;
    while(ok)
    {
        ok=0;
        for(int i=1;i<=m;i++)
        {
            vis[i]=0;
        }
        for(int i=1;i<=n;i++)
        {
            if(pl[i]==0)
            {
                if(augment(i))
                {
                    ok=1;
                    break;
                }
            }
        }
    }
    vector<pair<int,int>> cupl;
    for(int i=1;i<=n;i++)
    {
        if(pl[i]!=0)
        {
            cupl.push_back({i,pl[i]});
        }
    }
    fout<<cupl.size()<<'\n';
    for(auto pi:cupl) fout<<pi.first<<' '<<pi.second<<'\n';
    return 0;
}
