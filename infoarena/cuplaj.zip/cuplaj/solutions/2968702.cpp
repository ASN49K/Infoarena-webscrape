#include <stdio.h>
#include <vector>

#define NONE (-1)

#define NMAX (10'000)
#define MMAX (10'000)

std::vector<int> g[NMAX];

int l[NMAX], r[MMAX];

bool used[NMAX];

bool dfs(int u)
{
    if(used[u])
        return false;

    used[u] = true;

    for(int v : g[u])
        if(r[v] == NONE)
        {
            l[u] = v;
            r[v] = u;
            return true;
        }
    
    for(int v : g[u])
        if(dfs(r[v]))
        {
            l[u] = v;
            r[v] = u;
            return true;
        }
    
    return false;
}

int main()
{
    freopen("cuplaj.in", "r", stdin);
    freopen("cuplaj.out", "w", stdout);

    int n, m, e;
    scanf("%d %d %d", &n, &m, &e);

    for(int i = 0; i < n; i++)
        l[i] = NONE;
    
    for(int i = 0; i < m; i++)
        r[i] = NONE;

    for(int i = 0; i < e; i++)
    {
        int u, v;
        scanf("%d %d", &u, &v);
        u--; v--;

        g[u].push_back(v);
    }

    bool found;
    do
    {
        found = false;

        for(int i = 0; i < n; i++)
            used[i] = false;
        
        for(int i = 0; i < n; i++)
            if(l[i] == NONE)
                found = (found || dfs(i));

    } while (found);

    int nr = 0;

    for(int i = 0; i < n; i++)
        if(l[i] != NONE)
            nr++;
    
    printf("%d\n", nr);

    for(int i = 0; i < n; i++)
        if(l[i] != NONE)
            printf("%d %d\n", i + 1, l[i] + 1);
    
    return 0;
}
