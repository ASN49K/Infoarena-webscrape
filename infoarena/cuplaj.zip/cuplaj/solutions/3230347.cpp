#include <vector>
#include <iostream>
#include <cstdio>
#define pb(x) push_back(x)
#include <random>
#include <algorithm>
using namespace std;
typedef long long ll;
typedef pair<ll,ll>pll;
vector<ll>vec[10001];
ll cnt,mt[10001],viz[10001],cp[10001];
bool cuplaj(ll x){
  if(viz[x]==cnt)return 0;
  viz[x]=cnt;
  for(ll y:vec[x]){
    if(mt[y]==0)return cp[x]=y,mt[y]=x,1;
  }
  for(ll y:vec[x]){
    if(cuplaj(mt[y]))return cp[x]=y,mt[y]=x,1;
  }
  return 0;
}
int main(){
  freopen("cuplaj.in","r",stdin);freopen("cuplaj.out","w",stdout);
  ios::sync_with_stdio(false);
  cin.tie(0);
  ll n,i,j,k,l,m,x,y,E;
  cin>>n>>m>>E;
  for(i=1;i<=E;i++){
    cin>>x>>y;
    vec[x].pb(y);
  }
  for(i=1;i<=n;i++)random_shuffle(vec[x].begin(),vec[x].end());
  ll gasit=1;
  while(gasit)
  {
    gasit=0;
    cnt++;
    for(i=1;i<=n;i++){
      if(!cp[i])gasit|=cuplaj(i);
    }
  }
  ll rez=0;
  for(i=1;i<=m;i++)rez+=mt[i]!=0;
  cout<<rez<<'\n';
  for(i=1;i<=m;i++)if(mt[i])cout<<mt[i]<<' '<<i<<'\n';
  return 0;
}
