#include<bits/stdc++.h>
#define inf (1<<30)
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int const N = 10001;
int n , m , e;
int st[N] , dr[N] , lv[N];
vector<int> v[N];
bool bfs(){
    queue<int> q;
    for(int i = 1 ; i <= n ; ++ i){
        if(!dr[i])
            lv[i] = 0 , q.push(i);
        else
            lv[i] = inf;
    }
    lv[0] = inf;
    while(!q.empty()){
        int x = q.front();
        q.pop();
        if(lv[x] < lv[0]){
            for(auto y : v[x]){
                if(lv[st[y]] == inf){
                    lv[st[y]] = 1 + lv[x];
                    q.push(st[y]);
                }
            }
        }
    }
    return lv[0] != inf;
}
bool dfs(int x){
    if(x == 0)
        return true;
    for(auto y : v[x]){
        if(lv[st[y]] == 1 + lv[x] && dfs(st[y])){
            dr[x] = y;
            st[y] = x;
            return true;
        }
    }
    lv[x] = inf;
    return false;
}
int maxmatch(){
    int r = 0;
    fill(st , st + 1 + n , 0);
    fill(dr , dr + 1 + m , 0);
    while(bfs()){
        for(int i = 1 ; i <= n ; ++ i)
            if(!dr[i] && dfs(i))
                ++ r;
    }
    return r;
}
int main(){
    fin >> n >> m >> e;
    for(int i = 1 ; i <= e ; ++ i){
        int x , y;
        fin >> x >> y;
        v[x].push_back(y);
    }
    fout << maxmatch() << '\n';
    for(int i = 1 ; i <= n ; ++ i)
        if(dr[i])
            fout << i << ' ' << dr[i] << '\n';
    return 0;
}
