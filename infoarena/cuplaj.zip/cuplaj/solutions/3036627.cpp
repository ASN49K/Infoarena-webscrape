#include <fstream>
#include <vector>
const int NMAX=100005;

using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

vector <int> v[NMAX];
int cp[NMAX], n, m, ans;
bool viz[NMAX], gasit;

bool cuplaj(int);

int main()
{
    int i, a, b;
    fin>>n>>a>>m;
    for(i=1; i<=m; i++)
    {
        fin>>a>>b;
        b+=n;
        v[a].push_back(b);
    }
    do
    {
        gasit=false;
        for(i=1; i<=n; i++)
        {
            if(!cp[i] && cuplaj(i))
            {
                ans++;
                gasit=true;
            }
        }
        for(i=1; i<=n; i++) viz[i]=false;
    }
    while(gasit);
    fout<<ans<<'\n';
    for(i=1; i<=n; i++)
    {
        if(cp[i]) fout<<i<<' '<<cp[i]-n<<'\n';
    }
    return 0;
}

bool cuplaj(int nod)
{
    if(viz[nod]) return false;
    viz[nod]=true;
    for(auto i:v[nod])
    {
        if(!cp[i])
        {
            cp[i]=nod;
            cp[nod]=i;
            return true;
        }
    }
    for(auto i:v[nod])
    {
        if(cuplaj(cp[i]))
        {
            cp[i]=nod;
            cp[nod]=i;
            return true;
        }
    }
    return false;
}
