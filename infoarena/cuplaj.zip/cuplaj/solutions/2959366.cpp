#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>

using namespace std;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

int N, M, E, u, v, match[10001];
bool viz[10001];
vector<vector<int> > G;

int pairup(int n)
{

    if(viz[n])
        return 0;

    viz[n] = 1;

    for(int i = 1; i <= M; i++)
        if(G[n][i] && (match[i] == 0 || pairup(match[i])))
        {
            match[i] = n;
            return 1;
        }

    return 0;

}

int main()
{

    f >> N >> M >> E;

    G.resize(N + 1);

    for(int i = 0; i <= N; i++)
        G[i].resize(M + 1);

    for(int i = 1; i <= E; i++)
    {
        f >> u >> v;
        G[u][v] = 1;
    }

    for(int i = 1; i <= N; i++)
    {
        memset(viz, 0, sizeof(viz));
        pairup(i);
    }

    int cnt = 0;
    for(int i = 1; i <= M; i++)
        if(match[i])
            cnt++;

    g << cnt << '\n';

    for(int i = 1; i <= M; i++)
        if(match[i])
            g << match[i] << " " << i << '\n';



    return 0;

}