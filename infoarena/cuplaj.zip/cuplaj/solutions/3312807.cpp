#include <bits/stdc++.h>

using namespace std;

const char iname[] = "cuplaj.in";
const char oname[] = "cuplaj.out";

int pairup(int const u, std::vector<int>& L, std::vector<int>& R,
           std::vector<int>& U, std::vector<vector<int>> const& G) {
  if (U[u]) {
    return 0;
  }
  U[u] = 1;
  for (int const v : G[u]) {
    if (!R[v]) {
      L[u] = v;
      R[v] = u;
      return 1;
    }
  }
  for (int const v : G[u]) {
    if (pairup(R[v], L, R, U, G)) {
      L[u] = v;
      R[v] = u;
      return 1;
    }
  }
  return 0;
}

int main() {
#ifndef LOCAL
  freopen(iname, "r", stdin);
  freopen(oname, "w", stdout);
#endif
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  int n;
  int m;
  int c;
  cin >> n >> m >> c;
  vector<vector<int>> G(n + 1);
  vector<int> L(n + 1);
  vector<int> R(m + 1);
  vector<int> U(n + 1);
  for (; c--;) {
    int u;
    int v;
    cin >> u >> v;
    G[u].push_back(v);
  }
  int d = 1;
  for (; d;) {
    d = 0;
    fill(U.begin(), U.end(), 0);
    for (int i = 1; i <= n; ++i) {
      if (!L[i]) {
        d |= pairup(i, L, R, U, G);
      }
    }
  }
  int o = 0;
  for (int i = 1; i <= n; ++i) {
    if (L[i]) {
      ++o;
    }
  }
  cout << o << endl;
  for (int i = 1; i <= n; ++i) {
    if (L[i]) {
      cout << i << " " << L[i] << endl;
    }
  }
  return 0;
}
