#include <fstream>
#include <vector>
#include <cstring>
#define nmax 1002
#define inf 1e9
using namespace std;
ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");
int n,m,x,y,e,st[nmax],dr[nmax],sol;
vector<int>v[nmax];
bool viz[nmax];
bool cuplaj(int nod){
    if(viz[nod])
        return 0;
    viz[nod]=1;
    for(auto i:v[nod])
        if(dr[i]==0){
            st[nod]=i;
            dr[i]=nod;
            return 1;
        }
    for(auto i:v[nod])
        if(cuplaj(dr[i])){/// am mutat nodul
            st[nod]=i;
            dr[i]=nod;
            return 1;
        }
    return 0;
}
signed main()
{
    cin>>n>>m>>e;
    for(int i=1;i<=e;i++){
        cin>>x>>y;
        v[x].push_back(y);
    }
    /// incerc sa tot cuplez pana nu mai reusesc
    bool ok=1;
    while(ok){
        memset(viz,0,sizeof(viz));
        ok=0;
        for(int i=1;i<=n;i++)
            if(st[i]==0)
                ok=cuplaj(i)||ok;
    }
    for(int i=1;i<=n;i++)
        if(st[i]!=0)
            sol++;
    cout<<sol<<'\n';
    for(int i=1;i<=n;i++)
        if(st[i]!=0)
            cout<<i<<" "<<st[i]<<'\n';
    return 0;
}
