#include <bits/stdc++.h>
using namespace std;
const int nmx = 1e4 + 2;
vector<int> ad[nmx];
int mt[nmx],viz[nmx]; // mtch[A] = B
int n,m,e;
int flg = 0;
#if 1
#define cin fin
#define cout fout
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
#endif // 1
bool dfs(int k){ // k - nod din A
    if(k==-1)
        return 0;
    if(viz[k])
        return 0;
    viz[k] = 1;
    for(int to : ad[k]){
        if(mt[to]==-1 || dfs(mt[to])){
            mt[to] = k;
            return 1;
        }
    }
    return 0;
}
int dn[nmx];
int kuhn(){
    int ans = 0;
    for(int i=1;i<=n;i++)
        for(int to : ad[i])
            if(mt[to] == -1){
                mt[to] = i;
                dn[i] = 1;
            }
    fill(mt,mt+nmx,-1);
    for(int i=1;i<=n;i++){
        fill(viz,viz+nmx,0);
        if(dn[i]==0)
            ans += dfs(i);
    }
    return ans;
}

int main(){
    cin >> n >> m >> e;
    while(e--){
        int u,v;
        cin >> u >> v;
        ad[u].push_back(v);
    }
    cout << kuhn() << "\n";
    for(int i=1;i<=m;i++)
        if(mt[i]!=-1)
            cout << mt[i] << " " << i << "\n";
}
