//algoritmul lui Hopcroft Karp O(sqrt(VE))
//#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <climits>
#include <queue>
#include <fstream>
#include <list>




using namespace std;

ifstream in("cuplaj.in");
ofstream out("cuplaj.out");


int n, m, e;

list<int> adj[20001];

int pairL[20001], pairR[20001], dist[20001];

bool bfs() {
    queue<int> q;

    for (int u = 1; u <= n; u++)
        if (pairL[u] == 0) {
            dist[u] = 0;
            q.push(u);
        } else dist[u] = INT_MAX;

    dist[0] = INT_MAX;

    while (!q.empty()) {
        int u = q.front();
        q.pop();

        if (dist[u] < dist[0]) {
            list<int>::iterator i;
            for (i = adj[u].begin(); i != adj[u].end(); i++) {
                int v = *i;
                if (dist[pairR[v]] == INT_MAX) {
                    dist[pairR[v]] = dist[u] + 1;
                    q.push(pairR[v]);
                }
            }
        }
    }

    return (dist[0] != INT_MAX);

}

bool dfs(int u) {
    if (u != 0) {
        list<int>::iterator i;
        for (i = adj[u].begin(); i != adj[u].end(); i++) {
            int v = *i;
            if (dist[pairR[v]] == dist[u] + 1) {
                if (dfs(pairR[v]) == true) {
                    pairR[v] = u;
                    pairL[u] = v;
                    return true;
                }
            }
        }

        dist[u] = INT_MAX;
        return false;
    }

    return true;
}

void hopcroftKarp() {

    for (int u = 0; u <= n; u++)
        pairL[u] = 0;
    for (int v = 0; v <= m; v++)
        pairR[v] = 0;

    int result = 0;

    while (bfs()) {
        for (int u = 1; u <= n; u++)
            if (pairL[u] == 0 && dfs(u)) {
                result++;
            }
    }

    out << result << endl;
    for (int i = 1; i <= n; i++)
        if (pairL[i])
            out << i << " " << pairL[i] << endl;

}


int main() {
    int i, a, b;
    in >> n >> m >> e;

    for (i = 1; i <= e; i++) {
        in >> a >> b;
        adj[a].push_back(b);
    }

    hopcroftKarp();

    return 0;
}