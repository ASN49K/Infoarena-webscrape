#include <bits/stdc++.h>
#define NMAX 10008

using namespace std;
ifstream fin ("cuplaj.in");
ofstream fout ("cuplaj.out");

int n, m, e, mt[NMAX];
bool viz[NMAX], cuplat[NMAX];
vector <int> G[NMAX];

bool DFS(int nod);

int main()
{
    int u, v;
    fin >> n >> m >> e;
    for (int i = 1; i <= e; i++)
    {
        fin >> u >> v;
        G[u].push_back(v);
    }
    for (int i = 0; i <= m; i++)
        mt[i] = -1;
    int nr;
    int ok = 1;
    while (ok)
    {
        ok = 0;
        for (int j = 0; j <= n; j++) viz[j] = 0;
        for (int i = 1; i <= n; i++)
            if (cuplat[i] == 0 && DFS(i))
            {
                nr++;
                ok = 1;
            }

    }
    fout << nr << '\n';
    for (int i = 1; i <= m; i++)
        if (mt[i] != -1)
            fout << mt[i] << ' ' << i << '\n';
    return 0;
}

bool DFS(int nod)
{
    if (viz[nod])
        return 0;
    viz[nod] = 1;
    for (auto el : G[nod])
        if (mt[el] == -1 || DFS(mt[el]))
        {
            mt[el] = nod;
            cuplat[nod] = 1;
            return 1;
        }
    return 0;
}
