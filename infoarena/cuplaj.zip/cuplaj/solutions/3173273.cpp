#include <fstream>
#include <vector>
#include <cstring>

#define NMAX 10000

using namespace std;

ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");

int n, m, e;
int x, y;
vector<int> g[2 * NMAX + 5];
int match[2 * NMAX + 5];
bool used[NMAX + 5];

bool find_path(int u);
int matching();

int main()
{
  cin >> n >> m >> e;
  for(int i = 1; i <= e; i++)
  {
    cin >> x >> y;
    y += n;
    g[x].push_back(y);
    g[y].push_back(x);
  }
  cout << matching() << '\n';
  for(int i = 1; i <= n; i++)
    if(match[i])
      cout << i << ' ' << match[i] - n << '\n';
  return 0;
}

bool find_path(int u)
{
  used[u] = true;
  for(auto v : g[u])
  {
    if(!match[v] || (!used[match[v]] && find_path(match[v])))
    {
      match[v] = u; match[u] = v;
      return true;
    }
  }
  return false;
}

int matching()
{
  bool ok = true;
  int cnt = 0;
  while(ok)
  {
    ok = false;
    memset(used, false, (n + 1) * sizeof(bool));
    for(int u = 1; u <= n; u++)
    {
      if(!match[u] && find_path(u))
      {
        ok = true;
        cnt++;
      }
    }
  }
  return cnt;
}
