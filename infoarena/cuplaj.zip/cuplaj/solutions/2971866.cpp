#include <fstream>
#include <vector>

#define NMAX 10005

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int le, r, m;
int x, y;
vector<int> l[NMAX];
int p[NMAX]; bool f[NMAX];
int counter;
int i;

bool dfs(int);

int main()
{
    fin >>le>>r>>m;
    for (i = 1; i <= m; ++i)
    {
        fin >>x>>y;
        l[x].push_back(y);
    }

    for (i = 1; i <= r; ++i) p[i] = -1;
    for (x = 1; x <= le; ++x)
    {
        for (i = 1; i <= le; ++i) f[i] = 0;
        if (dfs(x)) counter ++;
    }

    fout <<counter<<'\n';
    fout.close();
    return 0;
}

bool dfs(int vf)
{
    int i; int vfnou;
    f[vf] = 1;
    for (i = 0; i < l[vf].size(); ++i)
    {
        vfnou = l[vf][i];
        if (p[vfnou] == -1 || (!f[p[vfnou]]) && dfs(p[vfnou]))
        {
            p[vfnou] = vf;
            return 1;
        }
    }
    return 0;
}
