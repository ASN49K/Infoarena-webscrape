#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n, m, e, i, j, cnt, mt[10005], l[10005], x, y;
bool viz[10005];
vector <int> g[10005];
vector <pair<int, int>> ans;
bool try_kuhn(int nod)
{
    if(viz[nod])
        return false;
    viz[nod]=true;
    for(auto i: g[nod])
    {
        if(mt[i]==-1 || try_kuhn(mt[i]))
        {
            mt[i]=nod;
            l[nod]=i;
            return true;
        }
    }
    return false;
}
int main()
{
    fin>>n>>m>>e;
    for(i=1; i<=e; i++)
    {
        fin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    int change=1;
    for(i=1; i<=m; i++)
        mt[i]=-1;
    for(i=1; i<=n; i++)
        l[i]=-1;
    while(change)
    {
        change=0;
        for(i=1; i<=n; i++)
            viz[i]=0;
        for(i=1; i<=n; i++)
            if(l[i]==-1)
            change|=try_kuhn(i);
    }
    for(i=1; i<=m; i++)
        if(mt[i]>0)
        {
            cnt++;
            ans.push_back({mt[i], i});
        }
    fout<<cnt<<'\n';
    sort(ans.begin(), ans.end());
    for(auto i: ans)
        fout<<i.first<<" "<<i.second<<'\n';
    return 0;
}
