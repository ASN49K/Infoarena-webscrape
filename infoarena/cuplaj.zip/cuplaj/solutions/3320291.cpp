#include <fstream>
#include <vector>
#include <bitset>

using namespace std;

const string txt = "cuplaj";
const int nmax = 1e4 + 5;

ifstream f(txt + ".in");
ofstream g(txt + ".out");

int n1, n2, m, mat[nmax];
bool viz[nmax];
vector<int> v[nmax];

static bool mbm(int node)
{
	for (auto x : v[node])
	{
		if (viz[x]) continue;
		viz[x] = true;

		if (!mat[x] || mbm(mat[x])) {
			mat[x] = node;
			
			return true;
		}
	}

	return false;
}

static int cuplaj_max()
{
	int ans = 0;
	for (int i = 1; i <= n2; i++) 
	{
		for (int j = 0; j <= n1; j++) viz[j] = 0;

		if (mbm(i)) ans++;
	}

	return ans;
}

int main()
{
	f.tie(NULL);
	f >> n1 >> n2 >> m;
	for (int i = 1; i <= m; i++)
	{
		int x, y; f >> x >> y;
		v[y].push_back(x);
	}

	g << cuplaj_max() << '\n';
	for (int i = 1; i <= n1; i++)
		if (mat[i]) g << i << " " << mat[i] << '\n';
	return 0;
}