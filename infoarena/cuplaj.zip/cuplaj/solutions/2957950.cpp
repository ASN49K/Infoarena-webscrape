#include<iostream>
#include<algorithm>
#include<vector>
#include<fstream>
#include<queue>
using namespace std;

ifstream in("cuplaj.in");
ofstream out("cuplaj.out");

struct edge{
	int from, to, capacity;
	edge * reverse;
};

const int mx = 20100;
const int inf = 1e9;

vector<edge*> g[mx];
vector<edge*> edges;
int n,m,e;
int s,t;

void add_edge(int a,int b){
		edge* p = new edge();
		edge* q = new edge();

		p->from = a;
		p->to= b;
		p->capacity = 1;
		p->reverse = q;

		q->from = b;
		q->to= a;
		q->capacity = 0;
		q->reverse = p;
		g[a].push_back(p);
		g[b].push_back(q);

		edges.push_back(p);
		edges.push_back(q);
}

void read(){

	in>>n>>m>>e;
	s = 1;
	t = 2 + n + m;

	int a,b;
	for(int i=0;i<e;i++){
		in>>a>>b;

		a = a + 1;
		b = b + n + 1;
		add_edge(a,b);
	}

	for(int i=1;i<=n;i++){
		add_edge(s, 1+i);	
	}

	for(int i=1;i<=m;i++){
		add_edge(i+n+1, t);
	}
}

int flow(){
	vector<edge*> parent(mx,nullptr);
	queue<int> q;
	q.push(s);

	while(!q.empty()){
		int here = q.front();
		q.pop();
		if(here == t){
			int flow = inf;
			int now = t;
			while(now != s){
				edge * prev = parent[now];
				flow = min(flow,prev->capacity);
				now = prev->from;
			}
			now = t;
			while(now != s){
				edge * prev = parent[now];
				prev->capacity-=flow;
				prev->reverse->capacity+=flow;
				now = prev->from;
			}
			return flow;
		}

		for(edge*e : g[here]){
			if(parent[e->to] == nullptr && e->capacity!=0){
				parent[e->to] = e;	
				q.push(e->to);
			}
		}
	}
	return 0;
}


void solve(){
	int current_flow = 0, total_flow = 0;
	do{
		current_flow = flow();
		total_flow+=current_flow;
	}
	while(current_flow);
	out<<total_flow<<'\n';

	for(const edge*x : edges){
		if(x->from !=s && x->to != t && x->from < x->to && x->capacity == 0){
			out<<x->from - 1<<" "<<x->to - n - 1<<'\n';
		}	
	}
}



int main(){
	read();
	solve();

	return 0;
}
