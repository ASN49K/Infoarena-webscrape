/// patratele
#include <bits/stdc++.h>
using namespace std;

#define MOD 1000003
#define pb push_back
#define Nmax 10010

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int i, cumplat[2 * Nmax], n, m, k, x, y, cnt, viz[2 * Nmax], ras;
vector<int> v[2 * Nmax];

void cump(int a, int b)
{
    cumplat[cumplat[a]] = 0;
    cumplat[cumplat[b]] = 0;
    cumplat[a] = b;
    cumplat[b] = a;
}

int dfs(int nod)
{
    viz[nod] = cnt;
    for (auto it : v[nod])
    {
        if (viz[it] == cnt)
            continue;
        viz[it] = cnt;
        if (!cumplat[it])
        {
            cump(nod, it);
            ras++;
            return 1;
        }
        else if (dfs(cumplat[it]) == 1)
        {
            cump(nod, it);
            return 1;
        }
    }
    return 0;
}

int main()
{
    // ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    fin >> n >> m >> k;
    for (i = 1; i <= k; i++)
    {
        fin >> x >> y;
        v[x].pb(y + n);
        v[y + n].pb(x);
    }
    bool ok = 1;
    while (ok)
    {
        ok = 0;
        cnt++;
        //ras = 0;
        for (i = 1; i <= n + m; i++)
            if (viz[i] != cnt && !cumplat[i])
                ok |= dfs(i);
    }
    fout << ras << '\n';
    for (i = 1; i <= n; i++)
    {
        if (cumplat[i])
            fout << i << " " << cumplat[i]-n << '\n';
    }
    return 0;
}
