#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f ("cuplaj.in");
ofstream g ("cuplaj.out");
int n,m,e,cnt_rasp;
int dr[10001],st[10001];
vector<int>adiacenta[10001];
bool viz[10001];
bool cuplaj(int nod)
{
    if(viz[nod] == 1)
        return 0;
    viz[nod] = 1;

    for(auto x:adiacenta[nod])
    {
        if(dr[x]==0)
        {
            st[nod] = x;
            dr[x] = nod;
            return 1;
        }
    }
    for(auto x:adiacenta[nod])
    {
        if(cuplaj(dr[x]))
        {
            st[nod] = x;
            dr[x] = nod;
            return 1;
        }
    }
}
int main()
{
    f >> n>> m >> e;
    for(int i = 1;i<=e;i++)
    {
        int x,y;
        f >> x >> y;
        adiacenta[x].push_back(y);
    }
    bool change = 1;
    while(change)
    {
        for(int i = 1;i<=10000;i++)
            viz[i] = 0;
        change = 0;
        for(int i = 1;i<=n;i++)
        {
            if(st[i]==0)
            {
                if(cuplaj(i))
                    change = 1;
            }
        }
    }
    for(int i = 1;i<=n;i++)
    {
        cnt_rasp +=(st[i]>0);
    }
    g << cnt_rasp<<'\n';
    for(int i = 1;i<=n;i++)
    {
        if(st[i]!=0)
        {
            g <<i<< " "<< st[i]<<"\n";
        }
    }
}
