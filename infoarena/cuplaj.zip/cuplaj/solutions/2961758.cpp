#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <climits>
#include <bits/stdc++.h>
using namespace std;

int l,r,m,n,x,y,c;
vector<vector<int>>Lista;
int flux[20001][20001];

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

int BF(int s,int viz[], int t[]){
    for(int i = 1;i<=n;i++){
        t[i] = 0;
        viz[i] = 0;
    }

    queue<int>q;
    int vf = s;
    viz[vf] = 1;
    q.push(vf);

    while(!q.empty()){

        vf = q.front();
        q.pop();
        for(auto aux:Lista[vf]){

            if(!viz[aux] && flux[vf][aux]>0) {
                q.push(aux);
                t[aux] = vf;
                viz[aux] = 1;

                if(aux == n){
                    return 1;
                }
            }
        }
    }
    return 0;

}

int main() {
    f>>l>>r>>m;
    n=l+m+2;

    int viz[n+1];
    int t[n+1];
    Lista.resize(n+1);
    int graf[n+1][n+1];

    for(int i = 1;i<=l;i++){
        Lista[1].push_back(i+1);
        Lista[i+1].push_back(1);
        flux[1][i+1] = 1;
    }

    for(int i = 1;i<=r;i++){
        Lista[i+1+l].push_back(n);
        Lista[n].push_back(i+1+l);
        flux[i+1+l][n] = 1;
    }

    for(int i=0;i<m;i++){
        f>>x>>y;
        Lista[x+1].push_back(y+l+1);
        Lista[y+l+1].push_back(x+1);
        flux[x+1][y+l+1] = 1;
        graf[x][y] = 1;
    }

    while(BF(1,viz,t)){

        int minim = INT_MAX;
        int nod = n;

        while(nod!=1){
            int tata = t[nod];
            minim = min(minim,flux[tata][nod]);
            nod = tata;
        }
        nod = n;
        while(nod!=1){
            int tata = t[nod];
            flux[tata][nod] -= minim;
            flux[nod][tata] += minim;
            nod = tata;
        }
    }
    c=0;
    for(int i=1;i<=l;i++){
        for(int j=1;j<=r;j++){
            if(graf[i][j]==1 && flux[i+1][j+1+l] == 0){
                c++;
            }
        }
    }
    g<<c<<"\n";
    for(int i=1;i<=l;i++){
        for(int j=1;j<=r;j++){
            if(graf[i][j]==1 && flux[i+1][j+1+l] == 0){
                g<<i<<" "<<j<<"\n";
            }
        }
    }

}
