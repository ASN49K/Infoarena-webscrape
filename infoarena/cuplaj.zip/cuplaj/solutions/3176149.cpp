#include <fstream>
#include <vector>
#include <bitset>
using namespace std;
ifstream fin ("cuplaj.in");
ofstream fout ("cuplaj.out");
int n,m,p,vecin,ok,nr,i,x,y,l[10001],r[10001];
bitset <10001> viz;
vector <int> v[10001];
bool cuplaj (int nod)
{
    if (viz[nod]==1)
        return 0;
    viz[nod]=1;
    for (int i=0; i<v[nod].size (); i++)
    {
        int vecin=v[nod][i];
        if (r[vecin]==0)
        {
            l[nod]=vecin;
            r[vecin]=nod;
            return 1;
        }
    }
    for (int i=0; i<v[nod].size (); i++)
    {
        int vecin=v[nod][i];
        if (cuplaj (r[vecin]))
        {
            l[nod]=vecin;
            r[vecin]=nod;
            return 1;
        }
    }
    return 0;
}
int main ()
{
    fin>>n>>m>>p;
    for (i=1; i<=p; i++)
    {
        fin>>x>>y;
        v[x].push_back (y);
    }
    ok=1;
    while (ok)
    {
        ok=0;
        viz.reset ();
        for (i=1; i<=n; i++)
        {
            if (l[i]==0&&cuplaj (i))
                ok=1;
        }
    }
    for (i=1; i<=n; i++)
    {
        if (l[i]!=0)
            nr++;
    }
    fout<<nr<<"\n";
    for (i=1; i<=n; i++)
    {
        if (l[i]!=0)
            fout<<i<<" "<<l[i]<<"\n";
    }
    return 0;
}
