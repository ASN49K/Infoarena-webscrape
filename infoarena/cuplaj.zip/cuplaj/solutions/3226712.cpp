#include <bits/stdc++.h>

using namespace std;
const int NMAX = 1e4 + 5;

bool viz[NMAX], used[NMAX], ok, sw;
int n, m, e, mt[NMAX], init[NMAX], sz;
vector<int> v[NMAX];

bool kuhn (int x)
{
  viz[x] = true;
  for (auto u : v[x])
    if (!mt[u] || (!viz[mt[u]] && kuhn(mt[u])))
    {
      mt[u] = x;
      used[x] = true;
      return true;
    }
  return false;
}

signed main ()
{
  freopen("cuplaj.in", "r", stdin);
  freopen("cuplaj.out", "w", stdout);
  cin.tie(nullptr)->sync_with_stdio(false);
  cin >> n >> m >> e;
  if (n > m)
  {
    swap(n, m);
    sw = true;
  }
  while (e--)
  {
    int x, y; cin >> x >> y;
    if (sw)
      swap(x, y);
    v[x].push_back(y);
  }
  for (int i = 1; i <= n; i++)
    init[i] = i;
  sort(init + 1, init + n + 1, [&] (int x, int y)
  {
    return v[x].size() < v[y].size();
  });
  for (int i = 1; i <= n; i++)
    for (auto x : v[i])
      if (!mt[x])
      {
        used[i] = true;
        mt[x] = i;
        sz++;
        break;
      }
  do
  {
    ok = false;
    for (int i = 1; i <= n; i++)
      if (!viz[i] && !used[i])
        if (kuhn(i))
        {
          ok = true;
          sz++;
        }
    memset(viz, false, sizeof(viz));
  } while (ok);
  cout << sz << '\n';
  for (int i = 1; i <= m; i++)
    if (mt[i])
    {
      if (sw)
        cout << i << ' ' << mt[i] << '\n';
      else
        cout << mt[i] << ' ' << i << '\n';
    }
}
