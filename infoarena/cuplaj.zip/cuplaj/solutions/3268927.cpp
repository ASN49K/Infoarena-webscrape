#include <bits/stdc++.h>
#define sqr(x) ((x) * (x))

using namespace std;
using ld = long double;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int n, k, m;
vector<vector<int>> g;
vector<int> mt, l;
vector<bool> used;


bool try_kuhn(int v) {
    if (used[v])
        return false;
    used[v] = true;
    for (int to : g[v]) {
        if (mt[to] == -1 || try_kuhn(mt[to])) {
            l[v] = to;
            mt[to] = v;
            return true;
        }
    }
    return false;
}

int main() {
    fin >> n >> k >> m;
    g.assign(n, vector<int>());
    while(m -- ){
        int x, y;
        fin >> x >> y;
        -- x, --y;
        g[x].emplace_back(y);
    }
    
    mt.assign(k, -1);

    int change = 1;
    l.assign(n, -1);

    while(change){
        change = 0;
        used.assign(n, false);
        for (int v = 0; v < n; ++v) {
            if (l[v] == -1){
                change |= try_kuhn(v);
            }
        }
    }



    vector<pair<int ,int>> ans;
    for (int i = 0; i < k; ++i) {
        if (mt[i] != -1)    {
            ans.emplace_back(mt[i] + 1, i + 1);
        }
    }
    sort(ans.begin(), ans.end());
    fout << ans.size() << '\n';
    for (auto it : ans){
        fout << it.first << ' ' << it.second << '\n';
    }
    return 0;
}