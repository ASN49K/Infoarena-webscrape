#include <bits/stdc++.h>

using namespace std;

ifstream in("cuplaj.in");
ofstream out("cuplaj.out");

vector <int> g[100005];

int pairst[100005], pairdr[100005];

int fre[100005];

int find(int nod)
{
    if(fre[nod] == 1)
    {
        return 0;
    }
    fre[nod] = 1;
    for(auto i:g[nod])
    {
        if(pairdr[i] == 0)
        {
            pairdr[i] = nod;
            pairst[nod] = i;
            return 1;
        }
    }
    for(auto i:g[nod])
    {
        if(find(pairdr[i]) == 1)
        {
            pairdr[i] = nod;
            pairst[nod] = i;
            return 1;
        }
    }
    return 0;
}

signed main()
{
    int n, x, m;
    in >> n >> x >> m;
    int val;
    for(int i = 1; i <= m; i++)
    {
        int a, b;
        in >> a >> b;
        g[a].push_back(b);
    }
    int pos = 1, match = 0;
    while(pos == 1)
    {
        pos = 0;
        for(int i = 1; i <= n; i++)
        {
            fre[i] = 0;
        }
        for(int i = 1; i <= n; i++)
        {
            if(pairst[i] == 0)
            {
                val = find(i);
                pos = max(pos, val);
                match = match + val;
            }
        }
    }
    out << match << '\n';
    for(int i = 1; i <= n; i++)
    {
        if(pairst[i] != 0)
        {
            out << i << ' ' << pairst[i] << '\n';
        }
    }
    return 0;
}
