#include<fstream>
#include<vector>
#include<queue>
#include<bitset>
using namespace std;

ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");

const int NMAX = 1e4 + 1;

vector<int> vecini[NMAX];

int st[NMAX],dr[NMAX];

bitset<NMAX> g;

bool pairup(int nod)
{
    if(g[nod])
        return 0;
    g[nod] = 1;
    for(auto it : vecini[nod])
        {
            if(!dr[it])
                {
                    dr[it] = nod;
                    st[nod] = it;
                    return 1;
                }
        }

    for(auto it : vecini[nod])
        {
            if(pairup(dr[it]))
                {
                    st[nod] = it;
                    dr[it] = nod;
                    return 1;
                }
        }

    return 0;
}

int main()
{
    int n,d,m,a,b; cin >> n >> d >> m;
    for(int i = 0 ; i < m ; i++)
        {
            cin >> a >> b;
            vecini[a].emplace_back(b);
        }

    for(;;)
        {
            bool ok = false;
            g.reset();
            for(int i = 1; i <= n ; i++)
                {
                    if(st[i]) continue;
                    ok = ok || pairup(i);
                }

            if(!ok) break;
        }

    queue<pair<int,int>> ans;
    for(int i = 1; i <= n ; i++)
        {
            if(st[i])
                ans.push({i,st[i]});
        }

    cout << ans.size() << '\n';
    while(!ans.empty())
        {
            pair<int,int> it = ans.front(); ans.pop();
            cout << it.first << " " << it.second << '\n';
        }

}
