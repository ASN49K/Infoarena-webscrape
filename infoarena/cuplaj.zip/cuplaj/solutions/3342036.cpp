#include <fstream>
#include <vector>
#include <cstring>
using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int n,m,e,x,y,cnt;
int r[10001],l[10001];
bool vizitat[10001];

vector<int> v[10001];
vector<pair<int,int>> muchii;

bool check(int i){
    if(vizitat[i]){
        return false;///e vizitat
    }
    vizitat[i]=1;
    for(auto u:v[i]){
        if(l[u]==0){
            l[u]=i;
            r[i]=u;
            return true;///l am cuplat
        }
    }
    ///daca nu, decuplam alte noduri sa cuplam nodul curent
    for(auto u:v[i]){
        if(check(l[u])==1){///e cuplat
            l[u]=i;
            r[i]=u;
            return true;///l am cuplat
        }
    }
    return false;
}

int main()
{
    fin>>n>>m>>e;
    for(int i=1; i<=e; i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
    }
    bool ok=true;
    do
    {
        ok=false;
        memset(vizitat,0,sizeof(vizitat));
        for(int i=1; i<=n; i++)
        {
            if(r[i]==0 && check(i)==true)
            {
                cnt++;
                ok=true;
            }
        }
    }while(ok==true);
    fout<<cnt<<'\n';
    for(int i=1;i<=n;i++){
        if(r[i]){
            fout<<i<<" "<<r[i]<<'\n';
        }
    }
    return 0;
}
