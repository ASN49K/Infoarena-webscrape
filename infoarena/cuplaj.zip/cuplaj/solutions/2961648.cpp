#include <bits/stdc++.h>
#define MAX 131072

using namespace std;
const int NMAX = 20300;

struct obj {
    int node;
    int capacity, flow, idx;
    bool dir;
};

struct obj_1 {
    int node, idx;
};

int N1, N2, M, S, D, ansFlow;

bool wasSeen[NMAX];
obj_1 dad[NMAX];

vector <obj> edges[NMAX];

// flow.first = capacity
// flow.second = flow

void read(){
    scanf("%d%d%d", &N1, &N2, &M);
    int x, y;
    S = 0;
    D = N1 + N2 + 1;

    for(int i = 1; i <= M; i++){
        scanf("%d%d", &x, &y);

        int xSize = edges[x].size();
        int ySize = edges[N1 + y].size();
        edges[x].push_back({N1 + y, 1, 0, ySize, true});
        edges[N1 + y].push_back({x, 0, 0, xSize, false});
    }

    for(int node = 1; node <= N1; node++){
        int xSize = edges[S].size();
        int ySize = edges[node].size();
        edges[S].push_back({node, 1, 0, ySize, true});
        edges[node].push_back({S, 0, 0, xSize, false});
    }

    for(int node = N1 + 1; node <= N1 + N2; node++){
        int xSize = edges[D].size();
        int ySize = edges[node].size();
        edges[D].push_back({node, 0, 0, ySize, false});
        edges[node].push_back({D, 1, 0, xSize, false});
    }
}

// rezolvare cerinta a
// aplic algoritmul de flux, pornesc un BFS din nodul 1 si incerc sa ajung in nodul N pe muchiile care inca nu
// si-au atins capacitatea maxima, iar pentru fiecare nod retin nodul de unde am venit
// pentru toti vecinii lui N, calculez fluxul cu care pot sa ajung intr-un vecin de a lui, uitandu-ma la tatii acestuia
// insumez toate fluxurile gasite si obtin rezultatul

void printMinimumCut(int node){
    for(int i = 0; i <= D; i++)
        wasSeen[i] = false;
    vector <pair <int, int> > cutEdges;
    queue <int> Q;
    Q.push(node);
    wasSeen[node] = true;
    while(!Q.empty()){
        node = Q.front();
        Q.pop();
        for(auto it : edges[node]){
            if(!it.dir)
                continue;
            if(node != S && it.node != D && it.capacity - it.flow == 0){
                cutEdges.push_back(make_pair(node, it.node - N1));
                continue;
            }
            if(!wasSeen[it.node]){
                wasSeen[it.node] = true;
                Q.push(it.node);
            }
        }
    }
    for(auto it : cutEdges)
        printf("%d %d\n", it.first, it.second);
    cutEdges.clear();
}

bool generateFlow(int node){
    for(int i = 0; i <= D; i++){
        wasSeen[i] = false;
        dad[i] = {0, 0};
    }
    queue <int> Q;
    Q.push(node);
    wasSeen[node] = true;
    while(!Q.empty()){
        node = Q.front();
        Q.pop();
        for(int i = 0; i < edges[node].size(); i++){
            auto it = edges[node][i];
            if(!wasSeen[it.node] && it.capacity - it.flow > 0){
                wasSeen[it.node] = true;
                dad[it.node] = {node, i};
                Q.push(it.node);
            }
        }
    }

    if(!dad[D].node)
        return false;

    node = D;
    for(int ci = 0; ci < edges[node].size(); ci++){
        auto it = edges[node][ci];
        int MinFlow = edges[it.node][it.idx].capacity - edges[it.node][it.idx].flow;
        int PosFlow = 0;
        if(MinFlow > 0){
            for(int j = it.node; j != 0; j = dad[j].node){
                PosFlow = edges[dad[j].node][dad[j].idx].capacity - edges[dad[j].node][dad[j].idx].flow;
                if(PosFlow < MinFlow)
                    MinFlow = PosFlow;
            }
            if(!MinFlow)
                continue;
            edges[it.node][it.idx].flow += MinFlow;
            edges[node][ci].flow -= MinFlow;
            for(int j = it.node; j != 0; j = dad[j].node){
                int kidx = edges[dad[j].node][dad[j].idx].idx;
                edges[dad[j].node][dad[j].idx].flow += MinFlow;
                edges[j][kidx].flow -= MinFlow;
            }
            ansFlow += MinFlow;
        }
    }

    return true;
}

int main() {

    freopen("cuplaj.in", "r", stdin);
    freopen("cuplaj.out", "w", stdout);

    read();

    bool repeat = true;
    while(repeat)
        repeat = generateFlow(0);
    printf("%d\n", ansFlow);
    printMinimumCut(0);

    return 0;
}

