#include <iostream>
#include <vector>
#include <fstream>
#include <queue>
#include <numeric>
#define INFINITY 999999999
using namespace std;

int noNodes;
int noEdges;
int l, r, e;
vector<vector<pair<int, int>>> graf_c;

bool constructSTNesaturatedBF(int s, int t, vector<vector<int>>& f,
                            vector<vector<int>>& graf_t, vector<int>& tata, vector<bool>& viz);
void revizFlux(int s, int t, vector<vector<int>>& f, vector<int>& tata, int& ip);
int EndmondsKarp(int fin, vector<vector<int>>& f);
void citireFisier();
void testEdmondsKarp();

int main() {
    citireFisier();
    testEdmondsKarp();
    return 0;
}

void citireFisier(){
    int x, y, z;
    ifstream fin("cuplaj.in");
    fin>>l>>r>>e;
    noEdges = l + r + e;
    noNodes = l + r + 2;
    graf_c.resize(noNodes+1);

    for(int i = 1; i <= e; ++i){
        fin>>x>>y;
        graf_c[x].push_back(make_pair(y + l, 1));
    }

    for(int i = 1; i <= l; ++i){
        graf_c[0].push_back(make_pair(i, 1));
    }

    for(int i = 1; i <= r; ++i){
        graf_c[i + l].push_back(make_pair(l + r + 1, 1));
    }

    fin.close();
}

void testEdmondsKarp(){
    vector<vector<int>> f(noNodes + 1, vector<int>(noNodes + 1, 0));
    ofstream fout("cuplaj.out");
    fout<<EndmondsKarp(noNodes, f)<<endl;
    for(int i = 1; i <= l; ++i){
        for(int j = 1; j <= r; ++j){
            if(f[i][j + l] == 1){
                fout<<i<<" "<<j<<endl;
            }
        }
    }
    fout.close();
}

bool constructSTNesaturatedBF(int s, int t, vector<vector<int>>& f,
                                    vector<vector<int>>& graf_t, vector<int>& tata, vector<bool>& viz){
    int i, v, c;
    fill(viz.begin(), viz.end(), false);
    queue<int> C;
    C.push(s);
    viz[s] = true;

    while(!C.empty()) {
        i = C.front();
        if(i == t){
            C.pop();
            continue;
        }
        for(auto& j:graf_c[i]) {
            v = j.first; c = j.second;
            if (!viz[v] && c > f[i][v]) { ///arc direct
                C.push(v);
                viz[v] = 1;
                tata[v] = i;
                if(v == t)
                    return true;
            }
        }
        for(auto& j:graf_t[i]){
            v = j;
            if(viz[v] == 0 && f[v][i] > 0){   ///arc invers
                C.push(v);
                viz[v] = 1;
                tata[v] = -i;
                if(v == t)
                    return true;
            }
        }
        C.pop();
    }
    if(viz[t])
        return true;
    return false;
}
void revizFlux(int s, int t, vector<vector<int>>& f, vector<int>& tata, int& ip){
    int nod = t, parent, mod_nod;
    do{
        mod_nod = abs(nod);
        parent = tata[mod_nod];
        if(parent >= 0){
            f[parent][mod_nod] += ip;
        }else{
            f[mod_nod][abs(parent)] -= ip;
        }
        nod = tata[mod_nod];
    }while(abs(nod) != s);
}
int EndmondsKarp(int fin, vector<vector<int>>& f){
    short offset = 1;
    int sum = 0, s = 1 - offset, t = fin - offset, minim;
    vector<vector<int>> graf_t(noNodes + 1);
    vector<bool> viz(noNodes + 1, false);
    vector<int> tata(noNodes + 1, 0);
    vector<vector<int>> c(noNodes + 1, vector<int>(noNodes + 1, 0));

    for(int i = 1 - offset; i <= noNodes - offset; ++i){
        for(auto& j:graf_c[i]){
            c[i][j.first] = j.second;
            graf_t[j.first].push_back(i);
        }
    }

    while(constructSTNesaturatedBF(s, t, f, graf_t, tata, viz)){
        for (auto& node: graf_t[t]) {
            if (f[node][t] == c[node][t] || !viz[node])
                continue;

            tata[t] = node;
            minim = INFINITY;

            int nod = t, parent, mod_nod;
            do{
                mod_nod = abs(nod);
                parent = tata[mod_nod];
                if(parent >= 0){
                    minim = min(minim, c[parent][mod_nod] - f[parent][mod_nod]);
                }else{
                    minim = min(minim, f[mod_nod][abs(parent)]);
                }
                nod = tata[mod_nod];
            }while(abs(nod) != s && minim != 0);
            if (minim == 0)
                continue;

            revizFlux(s, t, f, tata, minim);
            sum += minim;
        }
    }
    return sum;
}
