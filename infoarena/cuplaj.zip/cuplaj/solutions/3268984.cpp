#include <bits/stdc++.h>
#define NMAX  5005000
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int use[NMAX], mt[NMAX],l[NMAX],n,m,e;
vector<int>v[NMAX];
bool try_kuhn(int node)
{
    if(use[node])
        return false;
    use[node]=true;
    for(auto i:v[node])
        if(mt[i]==-1 || try_kuhn(mt[i])==1)
        {
            l[node]=i;
            mt[i]=node;
            return true;
        }
    return false;
}
int ok,x,y;
vector<pair<int,int>>ans;
int main()
{
    fin>>n>>m>>e;
    for(int i=1;i<=e;++i)
    {
        fin>>x>>y;
        v[x].push_back(y);
    }

    for(int i=1;i<=m;++i)
        mt[i]=-1;
    for(int i=1;i<=n;++i)
        l[i]=-1;
    ok=1;
    while(ok)
    {
        ok=0;
        for(int i=1;i<=n;++i)
            use[i]=false;
        for(int i=1;i<=n;++i)
            if(l[i]==-1)
                ok=try_kuhn(i);
    }

    for(int i=1;i<=m;++i)
        if(mt[i]!=-1)
            ans.push_back({mt[i], i});
    sort(ans.begin(), ans.end());
    fout<<ans.size()<<'\n';
    for(auto i:ans)
        fout<<i.first<<" "<<i.second<<'\n';

    return 0;
}
