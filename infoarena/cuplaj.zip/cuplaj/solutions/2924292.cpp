#include <bits/stdc++.h>

using namespace std;

ifstream f ("cuplaj.in");
ofstream g ("cuplaj.out");

int n,k,m;
int pereche[10005];
vector <int> v[10005];
int ok;
struct el
{
    int prim;
    int secund;
};
vector <el> a;
int viz[10005];

void lejer()
{
    for(int x=0; x<a.size(); ++x)
    {
        pereche[a[x].prim]=a[x].secund;
        pereche[a[x].secund]=a[x].prim;
    }
}

void pairup(int nod)
{
    viz[nod]=1;
    for(int x=0; x<v[nod].size(); ++x)
    {
        int fiu=v[nod][x];
        if(pereche[fiu]!=nod && viz[fiu]==0)
        {
            a.push_back({nod,fiu});
            viz[fiu]=1;
            if(pereche[fiu]==0)
            {
                lejer();
                ok=1;
                return;
            }
            pairup(pereche[fiu]);
            a.pop_back();

        }

    }
}



int main()
{
    f>>n>>k>>m;
    for(int i=1; i<=m; ++i)
    {
        int x,y;
        f>>x>>y;
        v[x].push_back(n+y);
        v[n+y].push_back(x);
    }

    for(int i=1; i<=n; ++i)
        if(pereche[i]==0)
            for(int x=0; x<v[i].size(); ++x)
            {
                int fiu=v[i][x];
                if(pereche[fiu]==0)
                {
                    pereche[i]=fiu;
                    pereche[fiu]=i;
                    break;
                }
            }


    ok=1;
    while(ok==1)
    {
        ok=0;

        for(int i=1; i<=n; ++i)
        {
            if(pereche[i]==0)
            {
                for(int j=1;j<=n;++j)
                viz[j]=0;

            a.clear(), pairup(i);
            }

        }

    }


    int cont=0;
    for(int i=1; i<=n; ++i)
        if(pereche[i]!=0)
            ++cont;
    g<<cont<<"\n";
    for(int i=1; i<=n; ++i)
        if(pereche[i]!=0)
            g<<i<<" "<<pereche[i]-n<<"\n";




    return 0;
}
