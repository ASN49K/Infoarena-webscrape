#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define all(v) begin(v), end(v)
#define al(v, l, r) begin(v) + l, begin(v) + r + 1
#define pb push_back
#define pob pop_back
#define sz(v) (int)v.size()
#define fs first
#define sd second

constexpr int inf = 2e9;
constexpr ll infll = 4e18;

int n, m, e;
vector<vector<int>> g;
vector<int> st, dr;
vector<bool> viz;

bool cuplaj(int i) {
    if (viz[i]) {
        return false;
    }

    viz[i] = true;
    for (int y : g[i]) {
        if (dr[y] == -1) {
            dr[y] = i;
            st[i] = y;
            return true;
        }
    }

    for (int y : g[i]) {
        if (cuplaj(dr[y])) {
            dr[y] = i;
            st[i] = y;
            return true;
        }
    }

    return false;
}

signed main() {
    #ifndef ONLINE_JUDGE
        freopen("k.in", "r", stdin);
        freopen("k.out", "w", stdout);
    #endif
    ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
    freopen("cuplaj.in", "r", stdin);
    freopen("cuplaj.out", "w", stdout);

    cin >> n >> m >> e;
    g.assign(n + m + 5, {});
    st.assign(n + 2, -1);
    dr.assign(n + m + 5, -1);
    viz.assign(n + m + 5, false);

    for (int i = 0, x, y; i < e; ++i) {
        cin >> x >> y;
        g[x].pb(y + n);
        g[y + n].pb(x);
    }

    bool ok = false;
    int nr = 0;

    while (!ok) {
        ok = true;
        fill(all(viz), false);

        for (int i = 1; i <= n; ++i) {
            if (st[i] == -1 && cuplaj(i)) {
                ok = false;
                nr++;
            }
        }
    }

    cout << nr << "\n";
    for (int i = 1; i <= n; ++i) {
        if (st[i] == -1) {
            continue;
        }

        cout << i << " " << st[i] - n << "\n";
    }
}