#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

const int NMAX = 1e4;

int pairs[2][NMAX + 1];    // 0 e graful din stanga, 1 e cel din dreapta
bool vis[NMAX];
vector<int> adj[2][NMAX + 1];

bool pairUp(int nd1, int nd2);
bool change(int nd);
void match(int n, int m);

int main()
{
    int n, m, nd1, nd2, E;

    fin >> n >> m >> E;
    for (int i = 0; i < E; i++) {
        fin >> nd1 >> nd2;
        adj[0][nd1].push_back(nd2);
        adj[1][nd2].push_back(nd1);
    }

    match(n, m);

    int cnt = 0;
    for (int i = 1; i <= n; i++)
        cnt += (pairs[0][i] != 0);

    fout << cnt << '\n';
    for (int i = 1; i <= n; i++)
        if (pairs[0][i])
            fout << i << " " << pairs[0][i] << '\n';
    return 0;
}

bool pairUp(int nd1, int nd2) {
    if (change(pairs[1][nd2])) {
        pairs[0][nd1] = nd2;
        pairs[1][nd2] = nd1;
        return 1;
    }
    return 0;

}
bool change(int nd) {
    vis[nd] = 1;

    for (int nxt: adj[0][nd]) {
        if (!pairs[1][nxt]) {
            pairs[1][nxt] = nd;
            pairs[0][nd] = nxt;
            return 1;
        }
    }

    for (int nxt: adj[0][nd]) {
        if (!vis[pairs[1][nxt]] && change(pairs[1][nxt])) {
            pairs[1][nxt] = nd;
            pairs[0][nd] = nxt;
            return 1;
        }
    }
    return 0;
}
void match(int n, int m) {
    for (int nd = 1; nd <= n; nd++) {
        for (int i = 1; i <= n; i++)
            vis[i] = 0;

        bool ok = 0;
        for (int nxt: adj[0][nd])
            if (!pairs[1][nxt]) {
                pairs[0][nd] = nxt;
                pairs[1][nxt] = nd;
                ok = 1;
                break;
            }

        if (ok)
            continue;

        for (int nxt: adj[0][nd])
            if (pairUp(nd, nxt))
                break;
    }
}
