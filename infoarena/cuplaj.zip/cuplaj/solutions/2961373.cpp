#include <cstdio>
#include <vector>
#include <queue>
#include <climits>

const int INF = INT_MAX;

class MaxFlow{
private:
    int n, s, d;
    std::vector<std::vector<int>> cap_flow;
    std::vector<std::vector<int>> G;
    std::vector<int> t;

public:
    MaxFlow(int, int, int, std::vector<std::pair <int, std::pair<int, int>>>&);
    int bfs();
    int update_flow();
    int max_flow(); 
    std::vector<std::pair<int, int>> matching(int);
};

MaxFlow::MaxFlow(int n, int s, int d, std::vector<std::pair <int, std::pair<int, int>>>& edges): n(n), s(s), d(d){
    cap_flow = std::vector<std::vector<int>> (n, std::vector<int>(n, 0));
    G = std::vector<std::vector<int>>(n);

    for(const auto& edge: edges){
        G[edge.first].push_back(edge.second.first);
        G[edge.second.first].push_back(edge.first);
        cap_flow[edge.first][edge.second.first] = edge.second.second;
    }
}

int MaxFlow::bfs(){
    std::queue<int> q;

    t = std::vector<int> (n, -1);
    t[s] = -2;
    q.push(s);

    while(!q.empty()){
        int u = q.front();
        q.pop();
        if(u == d)
            continue;
        for(const auto& v: G[u])
            if(t[v] == -1 && cap_flow[u][v] > 0){
                t[v] = u;
                q.push(v);
            }
    }

    return t[d] != -1;
}

int MaxFlow::update_flow(){
    int node, flow;
    flow = INF;
    
    for(node = d; t[node] != -2; node = t[node])
        flow = std::min(flow, cap_flow[t[node]][node]);
    
    for(node = d; t[node] != -2; node = t[node]){
        cap_flow[t[node]][node] -= flow;
        cap_flow[node][t[node]] += flow;
    }

    return flow;
}

int MaxFlow::max_flow(){
    int flow = 0;
    
    while(bfs()){
        for(const auto& node: G[d]){
            if(t[node] == -1 || cap_flow[node][d] == 0)
                continue;
            t[d] = node;
            flow += update_flow();
        }
    }

    return flow;
}

std::vector<std::pair<int, int>> MaxFlow::matching(int l){
    std::vector<std::pair<int, int>> edges;
    
    for(int u = 1; u <= l; u ++)
        for(const auto& v: G[u])
            if(cap_flow[u][v] == 0 && v > l)
                edges.push_back({u, v});
    
    return edges;
}

int main(){
    freopen("cuplaj.in", "r", stdin);
    freopen("cuplaj.out", "w", stdout);

    int n, m, e, x, y;
    std::vector<std::pair <int, std::pair<int, int>>> edges;

    scanf("%d%d%d", &n, &m, &e);
    for(int i = 0; i < e; i ++){
        scanf("%d%d", &x, &y);
        edges.push_back({x, {y + n, 1}});
    }
    
    for(int i = 1; i <= n; i ++)
        edges.push_back({0, {i, 1}});
    for(int i = n + 1; i <= n + m; i ++)
        edges.push_back({i, {n + m + 1, 1}});

    MaxFlow maxflow(n + m + 2, 0, n + m + 1, edges);
    int max_flow = maxflow.max_flow();
    std::vector<std::pair<int, int>> matching_edges = maxflow.matching(n);

    printf("%d\n", max_flow);
    for(const auto& edge: matching_edges)
        printf("%d %d\n", edge.first, edge.second - n);

    return 0;
}