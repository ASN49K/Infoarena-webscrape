#include<iostream>
#include<fstream>
#include<vector>
#include<queue>
using namespace std;

int root, dest, n, m, n1, n2, c, total, l, r;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

int tati[10001];
vector<vector<int>>lista;
int flux[10001][10001];
int label[10001];
vector < pair<int, int>>final;


bool BFS() {
	queue<int>q;
	for (int i = 0; i <= n; i++)
	{
		tati[i] = 0;
		label[i] = 0;
	}
	label[0] = 1;
	q.push(0);
	while (!q.empty()) {
		int x = q.front();
		q.pop();
		for (auto el : lista[x]) {
			if (label[el] == 0 && flux[x][el] > 0) {
				tati[el] = x;
				q.push(el);
				label[el] = 1;
				if (el == n) {
					return 1;
				}
			}
		}
	}
	return 0;

}

int main() {
	f >> l >> r >> m;
	lista.resize(l + r + 2);
	for (int i = 1; i <= m; i++) {
		f >> n1 >> n2;
		lista[n1].push_back(l+n2);
		lista[l+n2].push_back(n1);
		flux[n1][l+n2] = 1;

	}
	n = l + r + 1;
	for (int i = 1; i <= l; i++)
	{
		lista[0].push_back(i);
		lista[i].push_back(0);
		flux[0][i] = 1;
	}
	for (int i = l + 1; i <= l + r; i++)
	{
		lista[i].push_back(n);
		lista[n].push_back(i);
		flux[i][n]=1;
	}

	while (BFS()) {
		for (auto el : lista[n])
		{
			if (!label[el])
				continue;
			int min1 = 10000000;
			int v = n;
			while (v != 0)
			{
				min1 = min(min1, flux[tati[v]][v]);
				v = tati[v];
			}
			v = n;
			while (v != 0) {
				flux[tati[v]][v] -= min1;
				flux[v][tati[v]] += min1;
				v = tati[v];
			}
			total = total + min1;
		}
	}
	g << total << "\n";
	for (int i = 1; i <= l; i++)
		for (int j = l + 1; j <= l + r; j++)
			if (flux[j][i] == 1)
				g << i << " " << j-l<<"\n";
}