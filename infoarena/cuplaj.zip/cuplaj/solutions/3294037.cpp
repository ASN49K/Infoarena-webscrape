#include <bits/stdc++.h>
#define nmx 10005
using namespace std;
int n,m,e,a,b,st[nmx],dr[nmx];
vector <int> v[nmx];
bool vf[nmx+5];
bool doit(int x)
{
    if (vf[x])
        return 0;
    vf[x]=1;
    for (auto it : v[x])
        if (!dr[it])
        {
            st[x]=it;
            dr[it]=x;
            return 1;
        }
    for (auto it : v[x])
    {
        if (doit(dr[it]))
        {
            st[x]=it;
            dr[it]=x;
            return 1;
        }
    }
    return 0;
}
int main()
{
    ifstream f ("cuplaj.in");
    ofstream g ("cuplaj.out");
    f>>n>>m>>e;
    for (int i=1; i<=e; i++)
    {
        f>>a>>b;
        v[a].push_back(b);
    }
    bool ok=1;
    while (ok)
    {
        ok=0;
        memset(vf,0,nmx);
        for (int i=1; i<=n; i++)
            if (!st[i])
                ok=max(ok,doit(i));
    }
    int ct=0;
    for (int i=1; i<=n; i++)
        if (st[i])
            ct++;
    g<<ct<<'\n';
    for (int i=1; i<=n; i++)
        if (st[i])
            g<<i<<' '<<st[i]<<'\n';
}
