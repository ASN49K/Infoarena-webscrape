#include<iostream>
#include<algorithm>
#include<vector>
#include<fstream>
#include<queue>
using namespace std;

ifstream in("cuplaj.in");
ofstream out("cuplaj.out");

struct edge{
	int from, to;
};

const int mx = 20100;
const int inf = 1e9;

vector<edge> edges;
vector<int> g[mx];
vector<int> parent;

int capacity[mx][mx];
int n,m,e,num_nodes;
int s,t;

void add_edge(int a,int b){
	g[a].push_back(b);
	g[b].push_back(a);
	capacity[a][b]++;
	edges.push_back({a,b});
}

void read(){

	in>>n>>m>>e;
	s = 1;
	t = 2 + n + m;
	num_nodes = n + m + 2;

	int a,b;
	for(int i=0;i<e;i++){
		in>>a>>b;

		a = a + 1;
		b = b + n + 1;
		add_edge(a,b);
	}

	for(int i=1;i<=n;i++){
		add_edge(s, 1+i);	
	}

	for(int i=1;i<=m;i++){
		add_edge(i+n+1, t);
	}
}

bool flow(){
	parent = vector<int>(mx,-1);
	queue<int> q;
	q.push(s);

	while(!q.empty()){
		int here = q.front();
		q.pop();
		if(here==t)
			continue;

		for(int k: g[here]){
			if(parent[k] == -1 && capacity[here][k]!=0){
				parent[k] = here;	
				q.push(k);
			}
		}
	}

	return parent[t]!=-1;
}


void solve(){
	int total_flow = 0;
	while(flow()){
		for(int k : g[t]){
			if(capacity[k][t] == 0 || parent[k] == -1)
				continue;

			parent[t] = k;

			int now = t;
			int cflow = inf;

			while(now != s){
				cflow = min(cflow,capacity[parent[now]][now]);
				now = parent[now];
			}
			now = t;

			while(now != s){
				capacity[parent[now]][now] -= cflow;
				capacity[now][parent[now]] += cflow;
				now = parent[now];
			}
			total_flow+=cflow;
		}
	}

	out<<total_flow<<'\n';

	for(const edge& x : edges){
		if(x.from !=s && x.to != t && capacity[x.from][x.to] == 0){
			out<<x.from - 1<<" "<<x.to - n - 1<<'\n';
		}	
	}
}



int main(){
	read();
	solve();

	return 0;
}
