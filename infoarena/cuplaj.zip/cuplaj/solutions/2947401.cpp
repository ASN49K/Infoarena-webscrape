#include <bits/stdc++.h>
#define NMAX 20005

using namespace std;

int n, m, e;
vector<int> adj[NMAX];
int other[NMAX];
bool viz[NMAX];

int tryrematch(int node) {

	viz[node] = true;
	for (int neighbour : adj[node]) {
		if (!other[neighbour] || (!viz[other[neighbour]] && tryrematch(other[neighbour]))) {
			other[neighbour] = node;
			other[node] = neighbour;
			return 1;
		}
	}

	return 0;
}

int main() {

	ifstream in("cuplaj.in");
	ofstream out("cuplaj.out");

	in >> n >> m >> e;
	for (int edge = 1, x, y; edge <= e; ++edge) {
		in >> x >> y;
		adj[x].push_back(y + n);
		adj[y + n].push_back(x);
	}

	for (int i = 1; i <= n; ++i) {
		if (other[i])
			continue;

		memset(viz, 0, sizeof(viz));
		tryrematch(i);
	}

	vector <pair<int, int>> result;
	for (int i = 1; i <= n; ++i)
		if (other[i])
			result.push_back({i, other[i]});

	out << result.size() << '\n';
	for (pair<int, int> p : result)
		out << p.first << ' ' << p.second - n << '\n';

	return 0;
}
