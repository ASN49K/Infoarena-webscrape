#include <bits/stdc++.h>

using namespace std;
#define pb push_back
const int N = 1e4 + 5;

int n, m, e, mt[N], l[N], used[N];
vector<int> g[N];

bool try_kuhn(int v) {
    if (used[v])
        return false;
    used[v] = true;
    for (int to : g[v]) {
        if (mt[to] == -1 || try_kuhn(mt[to])) {
            l[v] = to;
            mt[to] = v;
            return true;
        }
    }
    return false;
}

int main() {
    freopen("cuplaj.in", "r", stdin);
    freopen("cuplaj.out", "w", stdout);
    cin >> n >> m >> e;
    for (int i = 1; i <= e; i++) {
        int u, v;
        cin >> u >> v;
        g[u].pb(v);
    }
    memset(mt, -1, sizeof(mt));
    memset(l, -1, sizeof(l));
    int change = 1;
    while (change) {
        change = 0;
        memset(used, false, sizeof(used));
        for (int v = 1; v <= n; v++) {
            if (l[v] == -1) {
                change |= try_kuhn(v);
            }
        }
    }
    vector<pair<int, int>> ans;
    for (int v = 1; v <= m; v++) {
        if (mt[v] != -1) {
            ans.pb({mt[v], v});
        }
    }
    sort(ans.begin(), ans.end());
    cout << (int) ans.size() << '\n';
    for (auto it : ans) {
        cout << it.first << ' ' << it.second << '\n';
    }
}
