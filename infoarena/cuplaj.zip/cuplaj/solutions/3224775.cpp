#include <bits/stdc++.h>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

#define NMAX 10005
int n, m, e, uz[2*NMAX], st[2*NMAX], dr[2*NMAX], x, y;
vector<int> G[2*NMAX];

bool cup(int nod) {
    uz[nod] = 1;
    for (auto vecin: G[nod]) {
        if (!st[vecin]) { ///vecin necuplat
            st[vecin] = nod;
            dr[nod] = vecin;
            return 1;
        }
    }
    
    for (auto vecin: G[nod]) {
        if (!uz[st[vecin]] && cup(st[vecin])) { ///pot elibera vecinul
            st[vecin] = nod;
            dr[nod] = vecin;
            return 1;
        }
    }
    return 0;
}

int main() {
    
    fin >> n >> m >> e;
    for (int i = 1; i<=e; i++) {
        fin >> x >> y;
        y += n;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    
    bool ok = 1;
    while (ok) {
        for (int i = 1; i<=n+m; i++) uz[i] = 0;
        ok = 0;
        for (int i = 1; i<=n; i++) {
            if (!uz[i] && !dr[i]) ok |= cup(i);
        }
    }
    
    int ans = 0;
    for (int i = 1; i<=n; i++) {
        if (dr[i]) ans++;
    }
    
    fout << ans << "\n";
    for (int i = 1; i<=n; i++) {
        if (dr[i]) {
            fout << i << " " << dr[i]-n << "\n";
        }
    }
    
    return 0;
}
