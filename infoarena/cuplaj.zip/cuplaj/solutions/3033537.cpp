#include <fstream>
#include <iostream>
#include <vector>
#include <cstring>
using namespace std;
ifstream f ("cuplaj.in");
ofstream g ("cuplaj.out");
vector<int>adiacenta[10001];
int st[10001],dr[10001];
bool fr[10001];
bool pairup(int nod)
{
    if(fr[nod])
        return 0;
    fr[nod] = 1;
    for(auto x:adiacenta[nod])
    {
        if(dr[x]==0)
        {
            st[nod] = x;
            dr[x] = nod;
            return 1;
        }
    }

    for(auto x:adiacenta[nod])
    {
        if(pairup(x))
        {
            st[nod] = x;
            dr[x] = nod;
            return 1;
        }
    }
    return 0;
}
int main()
{

    int n,m,e;
    f >> n >> m>>e;
    for(int i =1;i<=e;i++)
    {
        int x,y;
        f >> x >> y;
        adiacenta[x].push_back(y);
    }

    int change = 1;
    while(change)
    {
        change = 0;
        memset(fr,0,sizeof(fr));
        for(int i = 1;i<=n;i++)
        {
            if(!st[i])
            {
                if(pairup(i))
                    change=1;
            }
        }
    }
    int cnt = 0;
    for(int i = 1;i<=n;i++)
    {
        cnt+=(st[i]>0);
    }
    g << cnt<< endl;;
    for(int i = 1;i<=n;i++)
    {
        if(st[i])
            g << i << " "<< st[i]<< endl;
    }
}
