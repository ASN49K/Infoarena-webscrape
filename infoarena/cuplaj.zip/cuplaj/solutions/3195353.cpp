#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin ( "cuplaj.in" );
ofstream fout ( "cuplaj.out" );

const int N = 1e4 + 10;

vector <int> g[N];

int l[N], r[N];
bool viz[N];

int PairUp ( int n ) {
    
    if ( viz[n] != 0 )
        return 0;
    
    viz[n] = 1;
    
    for ( int i = 0; i < g[n].size(); i++ ) {
        if ( r[g[n][i]] == 0 ) {
            l[n] = g[n][i];
            r[g[n][i]] = n;
            return 1;
        }
    }
    
    for ( int i = 0; i < g[n].size(); i++ ) {
        if ( PairUp ( r[g[n][i]] ) != 0 ) {
            l[n] = g[n][i];
            r[g[n][i]] = n;
            return 1;
        }
    }
    
    return 0;
}

int main () {
    
    int n1, n2, m;
    int a, b;
    
    fin >> n1 >> n2 >> m;
    
    for ( int i = 0; i < m; i++ ) {
        cin >> a >> b;
        g[a].push_back (b);
    }
    
    int ok = 1;
    
    while ( ok == 1 ) {
        
        ok = 0;
        
        for ( int i = 1; i <= n2; i++ )
            viz[i] = 0;
        
        for ( int i = 1; i <= n1; i++ )
            if ( l[i] == 0 && PairUp(i) == 1 )
                ok = 1;
    }
    
    int cnt = 0;
    
    for ( int i = 1; i <= n1; i++ )
        if ( l[i] != 0 )
            cnt++;
    
    fout << cnt << "\n";
    
    for ( int i = 1; i <= n1; i++ )
        if ( l[i] != 0 )
            fout << i << " " << l[i] << "\n";
    
    return 0;
}
