#include <fstream>
#include <iostream>
#include <climits>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

struct edge{
    int capacity, flow;
};

int n, m, x, y, e;
edge matrix[1005][1005];
queue<int> q;
int father[1005];
vector<int> ad[1005];
int source, destination;

bool explored[1005];

int bfs() {

    for(int i = 1; i <= n + m + 2; i++) {
        father[i] = 0;
        explored[i] = 0;
    }

    explored[source] = 1;
    q.push(source);

    while(!q.empty()) {
        int node = q.front();
//        if(node == destination)
//            return 0;
        q.pop();

        if(node == destination)
            continue;

        for(auto i : ad[node]) {
            if(matrix[node][i].flow < matrix[node][i].capacity && explored[i] == 0) {
                explored[i] = 1;
                q.push(i);
                father[i] = node;
            }
        }
    }

    if(explored[destination] == 0)
        return 0; // destination can't be reached!
    else
        return 1; // destination reached!
}


int main() {
    fin >> n >> m >> e;

    // pun muchiile citite in problema cu capacitate 1
    for (int i = 1; i <= e; i++ )
    {
        fin >> x >> y;
        matrix[x][y + n].capacity = 1;
        ad[x].push_back(y + n);
        ad[y + n].push_back(x);
    }

    source = n + m + 2; // aleg un nod sursa
    destination = n + m + 1; // aleg un nod destinatie

    // adaug muchii de capacitate 1 de la sursa la primul set de noduri
    for(int i = 1 ; i <= n ; i++) {
        matrix[source][i].capacity = 1;
        ad[source].push_back(i);
        ad[i].push_back(source);
    }

    // adaug muchii de capacitate 1 de la al doilea set de noduri la destinatie
    for(int i = n + 1; i <= n + m; i ++) {
        matrix[i][destination].capacity = 1;
        ad[i].push_back(destination);
        ad[destination].push_back(i);
    }


    int max_flow = 0;

    while(bfs()) {
        max_flow += 1;

        int min_flow = INT_MAX;
//        for(auto vec : ad[destination]) {
//            if(explored[vec] == 0 || matrix[vec][destination].flow == matrix[vec][destination].capacity)
//                continue;

            int node = destination;
            //father[destination] = vec;

//            while(father[node] != 0) {
//                min_flow = min(min_flow, matrix[father[node]][node].capacity - matrix[father[node]][node].flow);
//                node = father[node];
//            }
//            node = destination;

            while(father[node] != 0) {
                matrix[father[node]][node].flow ++;
                matrix[node][father[node]].flow --;
                node = father[node];
//            }
        }
    }

    fout << max_flow << '\n';
    for(int i = 1; i <= n; i ++)
        for(auto j : ad[i]) {
            if(matrix[i][j].flow == 1)
                fout << i << " " << j - n << '\n';
        }
    return 0;
}