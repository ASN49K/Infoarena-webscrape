#include <fstream>
#include <cstring>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <algorithm>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;
ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");
using ll = long long;
//#define int ll
using pi = pair<int,int>;
using pll = pair<ll, ll>;

#define pb push_back
#define x first
#define y second

const int MOD = 1e9+7, INF = 1e9, NMAX = 2e5+1;
int l[NMAX], r[NMAX], vis[NMAX];
vector<int> v[NMAX];
int pairup(int u)
{
    if(vis[u])
        return 0;
    vis[u] = 1;
    int i, nod;
    for(i = 0; i < v[u].size(); i++)
    {
        nod = v[u][i];
        if(!r[nod])
        {
            r[nod] = u;
            l[u] = nod;
            return 1;
        }
    }
    for(i = 0; i < v[u].size(); i++)
    {
        nod = v[u][i];
        if(pairup(r[nod]))
        {
            r[nod] = u;
            l[u] = nod;
            return 1;
        }
    }
    return 0;
}
void solve()
{
    ll n, m, e, i, a, b, ok, ans;
    cin >> n >> m >> e;
    for(i = 1; i <= e; i++)
    {
        cin >> a >> b;
        v[a].pb(b);
    }
    ok = 1;
    while(ok)
    {
        ok = 0;
        for(i = 1; i <= n; i++)
            vis[i] = 0;
        for(i = 1; i <= n; i++)
            if(!l[i] && pairup(i))
                ok = 1;
    }
    ans = 0;
    for(i = 1; i <= n; i++)
        if(l[i])
            ans++;
    cout << ans << '\n';
    for(i = 1; i <= n; i++)
        if(l[i])
            cout << i << ' ' << l[i] << '\n';
}
int main()
{
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(cin.failbit);
    int T;
    T = 1;
    while(T--)
        solve();
    return 0;
}
