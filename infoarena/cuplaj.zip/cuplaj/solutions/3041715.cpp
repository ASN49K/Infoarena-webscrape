#include <bits/stdc++.h>

using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n, m, e, l[10005], r[10005], x, y;
vector<int> g[10001];
bitset<10005> use;
//#define fin cin
//#define fout cout
inline void Connect(int a, int b)
{
    l[a] = b;
    r[b] = a;
}
int match(int u)
{
    if(use[u])
        return 0;
    use[u] = 1;
    for(auto v : g[u])
        if(!r[v])
    {
        Connect(u, v);
        return 1;
    }
    for(auto v : g[u])
    {
        if(match(r[v]))
        {
            Connect(u ,v);
            return 1;
        }
    }
    return 0;
}

int main()
{
    fin >> n >> m >> e;
    for(int _ = 1; _ <= e; ++_)
    {
        fin >> x >> y;
        g[x].push_back(y);
    }
    int ok = true;
    while(ok == true)
    {
        ok = false;
        use.reset();
        for(int i = 1; i <= n; ++ i)
            if(!l[i])
                ok |= match(i);

    }
    int sol = 0;
    for(int i = 1; i <= n; ++ i)
        if(l[i])
            sol++;
    fout << sol << '\n';
    for(int i = 1; i <= n; ++ i)
        if(l[i])
        fout << i << ' ' << l[i] << '\n';
    return 0;
}
