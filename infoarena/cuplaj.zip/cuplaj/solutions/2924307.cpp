#include <bits/stdc++.h>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
#define cin fin
#define cout fout
const int nmx = 5e4+1;
std::vector<int> a[nmx];
int match[nmx];
int viz[nmx];
int n, m, k;
bool Bpm(int k)
{
    for (int to : a[k])
    {
        if(viz[to] == 0)
        {
            viz[to] = 1;
            if (match[to] == -1 || Bpm(match[to]))
            {
                match[to] = k;
                return true;
            }
        }
    }

    return false;
}

int Solve()
{
    int cnt = 0;
    memset(match, -1, sizeof(match));
    for (int i = 1; i <= n; i++)
    {
        memset(viz, 0, sizeof(viz));
        cnt += Bpm(i);
    }
    return cnt;
}

int main()
{
    cin >> n >> m >> k;
    while (k--)
    {
        int b, c;
        cin >> b >> c;
        a[b].push_back(c);
    }
    int cnt = Solve();
    cout << cnt << "\n";
    for (int i=0;i<n;i++)
    {
        if(match[i] != -1)
            cout << match[i] << ' ' << i << '\n';
    }
}
