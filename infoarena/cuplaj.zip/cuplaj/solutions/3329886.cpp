#include <fstream>
#include <vector>
#include <iostream>
#include <queue>
#include <algorithm>

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

struct Muchie {
    int v, cap, flux, rev;
};

vector<Muchie> G[10000];
int tata[10000];
int id[10000];
int N, M, E, S, D;

void add(int x, int y) {
    Muchie a = {y, 1, 0, (int)G[y].size()};
    Muchie b = {x, 0, 0, (int)G[x].size()};
    G[x].push_back(a);
    G[y].push_back(b);
}

bool bfs() {
    fill(tata, tata + D + 1, -1);
    queue<int> Q;
    Q.push(S);
    tata[S] = -2;

    while(!Q.empty()){
        int nod = Q.front();
        Q.pop();

        for(int i = 0; i < G[nod].size(); i++){
            Muchie &m = G[nod][i];
            if(tata[m.v] == -1 && m.cap - m.flux > 0){
                tata[m.v] = nod;
                id[m.v] = i;
                Q.push(m.v);
                if(m.v == D) return true;
            }
        }
    }
    return false;
}

int main() {
    fin >> N >> M >> E;
    S = 0;
    D = N + M + 1;

    for(int i = 1; i <= N; i++) add(S, i);
    for(int i = 1; i <= M; i++) add(N + i, D);

    for(int i = 1; i <= E; i++) {
        int u, v;
        fin >> u >> v;
        add(u, N + v);
    }

    int cuplaj = 0;
    while(bfs()) {
        cuplaj++;
        int nod = D;
        while(nod != S) {
            int prev = tata[nod];
            int idx = id[nod];

            G[prev][idx].flux++;
            int rev = G[prev][idx].rev;
            G[nod][rev].flux--;

            nod = prev;
        }
    }

    fout << cuplaj << "\n";

    for(int i = 1; i <= N; i++) {
        for(int j = 0; j < G[i].size(); j++) {
            if(G[i][j].v > N && G[i][j].v <= N + M && G[i][j].flux == 1) {
                fout << i << " " << G[i][j].v - N << "\n";
            }
        }
    }

    return 0;
}
