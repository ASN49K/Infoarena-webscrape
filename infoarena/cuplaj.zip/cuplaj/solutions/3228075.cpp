#include <bits/stdc++.h>
using namespace std;

#ifndef HOME
	ifstream in("cuplaj.in");
	ofstream out("cuplaj.out");
	#define cin in
	#define cout out
#endif

vector <int> v[10001];
vector <pair<int, int>> afis;
int rpair[10001], lpair[10001];
bool been_here[10001];

bool pair_up(int nod)
{
    if(been_here[nod])
        return 0;
    been_here[nod] = 1;
    for(auto it:v[nod])
        if(!lpair[it])
        {
            lpair[it] = nod;
            rpair[nod] = it;
            return 1;
        }
    for(auto it:v[nod])
        if(pair_up(lpair[it]))
        {
            lpair[it] = nod;
            rpair[nod] = it;
            return 1;
        }
    return 0;
}

int main()
{
#ifdef HOME
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#endif // HOME
    int n, m, e, x, y, cnt = 0;
    cin >> n >> m >> e;
    for(int i = 1; i <= e; i++)
    {
        cin >> x >> y;
        v[x].push_back(y);
    }
    bool ok = 1;
    while(ok)
    {
        ok = 0;
        for(int i = 1; i <= n; i++)
            been_here[i] = 0;
        for(int i = 1; i <= n; i++)
            if(!rpair[i] && pair_up(i))
            {
                ok = 1;
                cnt++;
            }
    }
    cout << cnt << '\n';
    for(int i = 1; i <= n; i++)
        if(rpair[i])
            afis.push_back({i, rpair[i]});
    for(auto it:afis)
        cout << it.first << " " << it.second << '\n';
    return 0;
}