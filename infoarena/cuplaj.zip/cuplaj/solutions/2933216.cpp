#include <bits/stdc++.h>

using namespace std;
const int N = 10005;
bool upd[N];
vector <int> g[N];
int l[N], r[N];
bool pairup(int u)
{
    if(upd[u]) return false;
    upd[u] = true;
    for(int v : g[u]) if(!l[v] || pairup(l[v]))
        return r[l[v] = u] = v, true;
    return false;
}

int main()
{
//    ifstream cin("maxflow.in");
//    ofstream cout("maxflow.out");
    int n, m, e;
    cin >> n >> m >> e;
    for(int i = 0, u, v; i < e; i++) {
        cin >> u >> v;
        g[u].push_back(v);
    }
    while(true)
    {
        bool ok = false;
        fill(upd, upd + n + 1, false);
        for(int i = 1; i <= n; i++)
            if(!r[i])
                ok |= pairup(i);
        if(!ok) break;
    }
    vector <pair <int, int>> sol;
    for(int i = 1; i <= n; i++)
        if(r[i])
            sol.emplace_back(i, r[i]);
    cout << sol.size() << "\n";
    for(auto x : sol)
        cout << x.first << " " << x.second << "\n";
    return 0;
}
