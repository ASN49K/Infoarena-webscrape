#include <bits/stdc++.h>
#define INF 0x3f3f3f3f

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int n, m, e, x, y, ans, st[100005], d[100005];
vector<int> G[100005];
bitset<100005> v;

bool cuplaj(int nod) { // pairUp
    if(v[nod]) {
        return false;
    }
    v[nod] = true;
    for(auto i : G[nod]) {
        if(d[i] == 0) {
            st[nod] = i;
            d[i] = nod;
            return true;
        }
    }
    for(auto i : G[nod]) {
        if(cuplaj(d[i])) {
            st[nod] = i;
            d[i] = nod;
            return true;
        }
    }
    return false;
}

int main() {
    fin >> n >> m >> e;
    for(int i = 1; i <= e; i++) {
        fin >> x >> y;
        G[x].push_back(y);
    }
    fin.close();
    bool gasit = true;
    while(gasit) {
        gasit = false;
        v.reset();
        for(int i = 1; i <= n; i++) {
            if(st[i] == 0) {
                gasit |= cuplaj(i);
            }
        }
    }
    for(int i = 1; i <= n; i++) {
        ans += (st[i] > 0);
    }
    fout << ans << "\n";
    for(int i = 1; i <= n; i++) {
        if(st[i] != 0) {
            fout << i << " " << st[i] << "\n";
        }
    }
    return 0;
}
