#include <fstream>
#include <vector>
#include <cstring>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
const int NMax = 10000;
int N,M,E;
int L[NMax + 5],R[NMax + 5],Use[NMax + 5];
vector <int> G[NMax + 5];
void Read()
{
    fin >> N >> M >> E;
    for(int i = 1; i <= E; ++i)
    {
        int x,y;
        fin >> x >> y;
        G[x].push_back(y);
    }
}

int Pairup(int Nod)
{
    if(Use[Nod] == 1)
        return 0;
    Use[Nod] = 1;
    for(auto Vecin : G[Nod])
    {
        if(R[Vecin] == 0)
        {
            L[Nod] = Vecin;
            R[Vecin] = Nod;
            return 1;
        }
    }
    for(auto Vecin : G[Nod])
    {
        if(Pairup(R[Vecin]) == 1)
        {
            L[Nod] = Vecin;
            R[Vecin] = Nod;
            return 1;
        }
    }
    return 0;
}

void Solve()
{
    for(int i = 1; i <= N; ++i)
            {
                memset(Use,0,sizeof(Use));
                Pairup(i);
            }
}

void Print()
{
    int Cuplaj = 0;
    for(int i = 1; i <= N; ++i)
    {
        Cuplaj += (L[i]!=0);
    }
    fout << Cuplaj << "\n";
    for(int i = 1; i <= N; ++i)
    {
        if(L[i])
        {
            fout << i << " " << L[i] << "\n";
        }
    }
}

int main()
{
    Read();
    Solve();
    Print();
    return 0;
}

