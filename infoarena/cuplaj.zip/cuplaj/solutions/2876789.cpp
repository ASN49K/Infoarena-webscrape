#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

const int NMAX = 1e4 + 2;

int N, M, E;
int L[NMAX], R[NMAX];

vector < int > G[NMAX];
int sel[NMAX];

static inline void AddEdge(int a, int b)
{
    G[a].push_back(b);
}

static inline void Read()
{
    fin >> N >> M >> E;
    for(int i = 1; i <= E; ++i) {
        int x, y;
        fin >> x >> y;
        AddEdge(x, y);
    }

    return;
}

static inline bool Match (int node)
{
    sel[node] = true;
    for(auto it: G[node]) {
        if(R[it] == 0) {
            L[node] = it;
            R[it] = node;
            return true;
        }
    }

    for(auto it: G[node]) {
        if(!sel[R[it]] && Match(R[it])) {
            L[node] = it;
            R[it] = node;
            return true;
        }
    }
    return false;
}

static inline void Solve()
{
    int ok = true;
    int ans = 0;
    while(ok) {
        ok = false;
        for(int i = 1; i <= N; ++i)
            sel[i] = false;

        for(int i = 1; i <= N; ++i) {
            if(!sel[i] && L[i] == 0)
                ok |= Match(i);
        }
    }

    for(int i = 1; i <= N; ++i)
        if(L[i] > 0)
            ++ans;

    fout << ans << '\n';
    for(int i = 1; i <= N; ++i)
        if(L[i] > 0)
            fout << i << " " << L[i] << '\n';

    return;
}

int main()
{
    Read();
    Solve();
    return 0;
}
