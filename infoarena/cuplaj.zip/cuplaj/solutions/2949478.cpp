#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

struct Flow
{
  int n;
  struct Edge
  {
    int to;
    int cap;
  };
  vector<Edge> edges;
  vector<vector<int>> g;
  vector<int> level;
  vector<int> pt;
  void init(int nn)
  {
    n = nn;
    g.resize(n);
    level.resize(n);
    edges.clear();
    pt.resize(n);
  }
  void add(int a, int b, int c)
  {
    a--;
    b--;
    assert(0 <= a && a < n);
    assert(0 <= b && b < n);
    edges.push_back({b, c});
    edges.push_back({a, 0});
    g[a].push_back((int) edges.size() - 2);
    g[b].push_back((int) edges.size() - 1);
  }
  int dfs(int a, int cur)
  {
    if (cur == 0 || a == n - 1)
    {
      return cur;
    }
    for (int& eid = pt[a]; eid < (int) g[a].size(); eid++)
    {
      int i = g[a][eid];
      if (level[edges[i].to] == 1 + level[a] && edges[i].cap)
      {
        int sol = dfs(edges[i].to, min(cur, edges[i].cap));
        if (sol == 0)
        {
          continue;
        }
        edges[i].cap -= sol;
        edges[i ^ 1].cap += sol;
        return sol;
      }
    }
    return 0;
  }
  int get()
  {
    int sol = 0;
    while (1)
    {
      for (int i = 0; i < n; i++)
      {
        level[i] = -1;
        pt[i] = 0;
      }
      level[0] = 0;
      queue<int> q;
      q.push(0);
      while (!q.empty())
      {
        int a = q.front();
        q.pop();
        for (auto &i : g[a])
        {
          if (edges[i].cap && level[edges[i].to] == -1)
          {
            level[edges[i].to] = level[a] + 1;
            q.push(edges[i].to);
          }
        }
      }
      if (level[n - 1] == -1)
      {
        break;
      }
      while (1)
      {
        int e = dfs(0, (int) 1e9);
        if (e == 0)
        {
          break;
        }
        sol += e;
      }
    }
    return sol;
  }
};
signed main()
{
#ifdef ONPC
  freopen ("input.txt", "r", stdin);
#endif // ONPC
#ifndef ONPC
  ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
  freopen ("cuplaj.in", "r", stdin);
  freopen ("cuplaj.out", "w", stdout);
#endif // ONPC

  int n, m, e;
  cin >> n >> m >> e;
  Flow flow;
  flow.init(1 + n + m + 1);
  for (int i = 1; i <= n; i++)
  {
    flow.add(1, 1 + i, 1);
  }
  for (int i = 1; i <= m; i++)
  {
    flow.add(1 + n + i, 1 + n + m + 1, 1);
  }
  for (int i = 1; i <= e; i++)
  {
    int a, b;
    cin >> a >> b;
    assert(1 <= a && a <= n);
    assert(1 <= b && b <= m);
    flow.add(1 + a, 1 + n + b, 1);
  }
  cout << flow.get() << "\n";
  for (int a = 1; a <= n; a++)
  {
    for (auto &i : flow.g[1 + a - 1])
    {
      int b = flow.edges[i].to - 1 - n + 1;
      if (1 <= b && b <= m && flow.edges[i].cap == 0)
      {
        cout << a << " " << b << "\n";
      }
    }
  }
  return 0;
}
/**

**/
