#include <fstream>
#include <vector>

using namespace std;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

const int nmax = 10005;
int l, r, e, m1[nmax], m2[nmax], fr[nmax];
vector<int> v[nmax];

bool cuplaj(int nod)
{
    if(fr[nod])
        return false;
    fr[nod] = 1;

    for(auto x : v[nod])
        if(!m2[x]){
            m2[x] = nod; m1[nod] = x;
            return true;
        }

    for(auto x : v[nod])
        if(cuplaj(m2[x])){
            m2[x] = nod; m1[nod] = x;
            return true;
        }

    return false;
}

int main()
{
    f >> l >> r >> e;
    for(int i = 1; i <= e; i ++)
    {
        int x, y; f >> x >> y;
        v[x].push_back(y);
    }

    int ok = 1;
    while(ok)
    {
        ok = 0;
        for(int i = 1; i <= l; i ++)
            fr[i] = 0;

        for(int i = 1; i <= l; i ++)
            if(!m1[i])
                ok = cuplaj(i);
    }

    int num = 0;
    for(int i = 1; i <= l; i ++)
        if(m1[i])
            num ++;

    g << num << '\n';
    for(int i = 1; i <= l; i ++)
        if(m1[i])
            g << i << " " << m1[i] << '\n';
    return 0;
}
