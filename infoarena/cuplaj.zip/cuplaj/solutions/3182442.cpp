#include <bits/stdc++.h>
#include <fstream>
#define cin fin
#define cout fout
using namespace std;
ifstream cin ("cuplaj.in");
ofstream cout ("cuplaj.out");
int n,m,nods,i,j,ok,cnt,a,b;
int l[10008], r[10008], viz[10008];
vector<int>G[10008];
int cuplaj(int nod)
{
    if(viz[nod]==1)
        return 0;
    viz[nod]=1;
    for(auto i:G[nod])
    {
        if(r[i]==0)
        {
            r[i]=nod;
            l[nod]=i;
            return 1;
        }
    }
    for(auto i:G[nod])
    {
        if(cuplaj(r[i]))
        {
            r[i]=nod;
            l[nod]=i;
            return 1;
        }
    }
    return 0;
}
int main()
{
    cin>>n>>m>>nods;
    for(i=1;i<=nods;i++)
    {
        cin>>a>>b;
        G[a].push_back(b);
    }
    do
    {
        ok=0;
        for(i=1;i<=n;i++)
        {
            viz[i]=0;
        }
        for(i=1;i<=n;i++)
        {
            if(l[i]==0)
            ok=max(ok,cuplaj(i));
        }
    }while(ok!=0);
    for(i=1;i<=n;i++)
    {
        if(l[i]!=0)
            cnt++;
    }
    cout<<cnt<<'\n';
    for(i=1;i<=n;i++)
    {
        if(l[i]!=0)
            cout<<i<<" "<<l[i]<<'\n';
    }
    return 0;
}
