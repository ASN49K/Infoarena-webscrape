#include <bits/stdc++.h>

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int cty[20002][20002];
int tata[20002];
vector <vector<int>> adjL;
vector  <int> viz;
int n1, n2, m, i, nr1, nr2, nr3, flow, minn, j;

int BFS(){
	queue<int> q;
	q.push(0);
	viz.assign(n1+n2+2, 0);
	while(!q.empty()){
		nr1 = q.front();
		q.pop();
		if(nr1 == n1+n2+1)
			break;
		viz[nr1]=1;
		for(auto &i : adjL[nr1]){
			if (!viz[i] && cty[nr1][i] != 0){
				viz[i] = 1;
                if (cty[nr1][i] == -1)
                    tata[i] = -nr1;
                else
                    tata[i] = nr1;
				q.push(i);
			}
		}
	}
	return viz[n1+n2+1];
}


int main(){
  	fin >> n1 >> n2 >> m;
  	adjL.assign(n1+n2+2, vector<int>());

  	for(i = 0; i < m; ++i){
  		fin >> nr1 >> nr2;
  		adjL[nr1].push_back(nr2+n1);
  		adjL[nr2+n1].push_back(nr1);
  		cty[nr1][nr2+n1] = 1;
  	}

  	for (i = 1; i <= n1; ++i){
        adjL[0].push_back(i);
        adjL[i].push_back(0);
        cty[0][i]= 1;
  	}
  	for (i = n1+1; i <= n1+ n2 ; ++i){
        adjL[i].push_back(n1+n2+1);
        adjL[n1+n2+1].push_back(i);
        cty[i][n1+n2+1] = 1;
  	}

  	vector<pair <int, int>> rez;

  	while(BFS()){
  		for(auto &i:adjL[n1+n2+1]){
            minn = 1;
  			tata[n1+n2+1] = i;
  			for (j = n1+n2+1; j> 0;){
                if (tata[j] < 0){
                    minn = min(minn, -cty[-tata[j]][j]);
                    j = -tata[j];
                }
  				else{
                    minn = min(minn, cty[tata[j]][j]);
                    j = tata[j];
  				}
  			}
  			for (j = n1+n2+1; j> 0;){
                if (tata[j] < 0){
                    cty[-tata[j]][j] += minn;
                    cty[j][-tata[j]] += minn;
                    j = -1 * tata[j];
                }
  				else{
                    cty[tata[j]][j] -= minn;
                    cty[j][tata[j]] -= minn;
                    j = tata[j];
  				}
  			}
  		}
  	}
  	for(i=1; i<= n1; ++i){
        for(auto &k : adjL[i]){
            if (cty[i][k] == 0 && k != 0){
                rez.push_back({i, k-n1});
            }
        }
  	}
  	fout << rez.size() << "\n";
  	for( auto & k : rez)
        fout << k.first << " " << k.second << '\n';

	return 0;
}
