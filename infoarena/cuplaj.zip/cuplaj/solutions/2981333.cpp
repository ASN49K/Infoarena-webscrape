#include <bits/stdc++.h>

using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
char buff[4096];
int pbuf=4095;
void readbuff(){
    pbuf=0;fin.read(buff,4095);
}
int citire(){
    int nr=0;
    if(pbuf==4095){
        readbuff();
    }
    while(buff[pbuf]<'0'||buff[pbuf]>'9'){
        pbuf++;
        if(pbuf==4095){
            readbuff();
        }
    }
    while(buff[pbuf]>='0'&&buff[pbuf]<='9'){
        nr=nr*10+buff[pbuf]-'0';pbuf++;
        if(pbuf==4095){
            readbuff();
        }
    }
    return nr;
}
int n,m,e;
vector<int>G[10005];
int L[10005],R[10005];
/// i este din stanga si L[i] este cu cine e unit in dr
/// i este din dreapta si R[i] este cu cine e unit in st
int viz[10005];
bool pair_up(int nod){
    if(viz[nod]==1){return 0;}
    viz[nod]=1;
    for(int i=0;i<G[nod].size();i++){
        int j=G[nod][i];
        if(R[j]==0){
            L[nod]=j;R[j]=nod;return 1;
        }
    }
    for(int i=0;i<G[nod].size();i++){
        int j=G[nod][i];
        if(pair_up(R[j])==1){
            L[nod]=j;
            R[j]=nod;return 1;
        }
    }
    return 0;
}
int main()
{
    n=citire();m=citire();e=citire();
    int a,b;
    for(int i=1;i<=e;i++){
        a=citire();b=citire();
        G[a].push_back(b);
    }
    int ok=0;
    while(ok==0){
        ok=1;
        for(int i=1;i<=n;i++){
            viz[i]=0;
        }
        for(int i=1;i<=n;i++){
            if(L[i]==0&&pair_up(i)==1){
                ok=0;
            }
        }
    }
    int cnt=0;
    for(int i=1;i<=n;i++){
        if(L[i]!=0){cnt++;}
    }
    fout<<cnt<<'\n';
    for(int i=1;i<=n;i++){
        if(L[i]!=0){
            fout<<i<<" "<<L[i]<<'\n';
        }
    }
    return 0;
}
