#include <iostream>
#include <fstream>
#include <cstring>
#include <queue>
#include <climits>
using namespace std;

ifstream f ("cuplaj.in");
ofstream g ("cuplaj.out");

int viz[20005] , tata[20005] , nod , n , m , e , x , y , src , dst , cap[9005][9005];

vector <int>v[20005];

int bfs ()
{
    memset (viz , 0 , sizeof (viz));
    memset (tata , 0 , sizeof (tata));
    queue <int>coada;
    coada.push (src);
    viz[src] = 1;
    tata[src] = -1;
    while (!coada.empty ())
    {
        int nod = coada.front ();

        coada.pop ();
        if (nod == dst)
            return true;
        for (int i = 0 ; i < v[nod].size () ; i++)
        {
            int vecin = v[nod][i];
            if (cap[nod][vecin] > 0 && viz[vecin] == 0)
            {
                tata[vecin] = nod;
                coada.push (vecin);
                viz[vecin] = 1;
            }
        }
    }
    return 0;
}

int flux ()
{
    int maxflow = 0;
    while (bfs ())
    {
        int flow = 0;
        for (int i = 0 ; i < v[dst].size () ; i++)
        {
            int vecin = v[dst][i];
            if (viz[vecin])
            {
                 tata[dst] = vecin;
                 flow = 2e9;
               for (int j = dst ; j != src ; j = tata[j])
                   flow = min (flow , cap[tata[j]][j]);
               for (int j = dst ; j != src ; j = tata[j])
               {
                   cap[tata[j]][j] -= flow;
                   cap[j][tata[j]] += flow;
               }
                 maxflow += flow;
            }
        }
    }
    return maxflow;
}

int main()
{
    f >> n >> m >> e;
    dst = n + m + 1;
    src = 0;
    for (int i = 1 ; i <= e ; i++)
    {
        f >> x >> y;
        v[x].push_back (y + n);
        v[y + n].push_back (x);
        cap[x][y + n] = 1;
    }

    for (int i = 1 ; i <= n ; i++)
    {
        v[0].push_back (i);
        v[i].push_back (0);
        cap[0][i] = 1;
    }
    for (int i = 1 ; i <= m ; i++)
    {
        v[n + i].push_back (dst);
        v[dst].push_back (n + i);
        cap[n + i][dst] = 1;
    }

    g << flux () << '\n';;
      for (int i = 1 ; i < dst ; i++)
    {
        for (int j = 0 ; j < v[i].size() ; j++)
            {
                int vecin = v[i][j];
                if (i < vecin && cap[i][vecin] == 0 && vecin != dst)
                    g << i << " " << vecin - n << '\n';
            }

    }
    return 0;
}
