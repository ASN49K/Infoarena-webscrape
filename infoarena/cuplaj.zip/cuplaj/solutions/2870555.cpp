#include <bits/stdc++.h>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
const int N(1e5 + 5);
int n, m, k, lm[N], rm[N];
bitset<N> viz;
vector<int> g[N];
inline bool Match(int const& x) {
    if (viz[x]) return false;
    viz[x] = true;
    for (int const& y : g[x])
        if (!lm[y] || Match(lm[y])) {
            lm[y] = x;
            rm[x] = y;
            return true;
        }
    return false;
}
void Cuplaj() {
    while (true) {
        bool ok = false;
        viz.reset();
        for (int i = 1; i <= n; ++i)
            if (!rm[i] && Match(i))
                ok = true;
        if (!ok) break;
    }
}
main() {
    fin >> n >> m >> k;
    while (k--) {
        int x, y;
        fin >> x >> y;
        g[x].emplace_back(y);
    }
    Cuplaj();
    vector<pair<int, int>> sol;
    for (int i = 1; i <= n; ++i)
        if (rm[i])
            sol.emplace_back(i, rm[i]);
    fout << sol.size() << '\n';
    for (pair<int, int> const& P : sol)
        fout << P.first << ' ' << P.second << '\n';
    return 0;
}
