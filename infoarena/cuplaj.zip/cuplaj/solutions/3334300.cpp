#include <fstream>
#include <vector>
using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int n,m,e;
int l[10001],r[10001];
bool viz[10001];
int cuplaj;

vector<int>muchie[10001];

bool pairup(int nod)
{
    if(viz[nod])
        return 0;
    viz[nod]=1;
    for(auto&it:muchie[nod])
        if(!r[it])
        {
            l[nod]=it;
            r[it]=nod;
            return 1;
        }
    for(auto&it:muchie[nod])
        if(pairup(r[it]))
        {
            l[nod]=it;
            r[it]=nod;
            return 1;
        }
        return 0;
}

int main()
{
    int a,b;
    fin>>n>>m>>e;
    for(int i=1;i<=e;i++)
    {
        fin>>a>>b;
        muchie[a].push_back(b);
    }
    bool ok=0;
    do
    {
        ok=0;
        for(int i=1;i<=n;i++)
            viz[i]=0;
        for(int i=1;i<=n;i++)
            if(!l[i])
                if(pairup(i))
                    ok=1;
    }while(ok);

    for(int i=1;i<=n;i++)
        if(l[i])
            cuplaj++;
    fout<<cuplaj<<'\n';
    for(int i=1;i<=n;i++)
        if(l[i])
            fout<<i<<' '<<l[i]<<'\n';

    return 0;
}
