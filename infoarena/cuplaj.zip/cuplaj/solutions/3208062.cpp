#include <bits/stdc++.h>
using namespace std;
const char nl = '\n';
const char sp = ' ';
const int inf = 0x3f3f3f3f;
const int mod = 1e9 + 7;
const char out[2][4]{ "NO", "YES" };
#define all(a) a.begin(), a.end()
using ll = long long;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

const int nmax = 1e4;
int n1, n2, m;
vector<int> g[nmax + 5];
bool vis[nmax + 5]{ 0 };
int match[nmax + 5]{ 0 };

bool solve(int u) {
    vis[u] = true;
    for (auto& v : g[u]) {
        if (match[v] == 0) {
            match[v] = u;
            return true;
        }
        if (vis[match[v]]) {
            continue;
        }
        if (solve(match[v])) {
            match[v] = u;
            return true;
        }
    }
    return false;
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    fin >> n1 >> n2 >> m;
    for (int i = 1; i <= m; ++i) {
        int u, v;
        fin >> u >> v;
        g[u].push_back(v + n1);
    }
    for (int i = 1; i <= n1; ++i) {
        fill(vis + 1, vis + n1 + 1, 0);
        solve(i);
    }
    fout << n1 - count(match + 1, match + n1 + 1, 0) << nl;
    for (int i = 1; i <= n1; ++i) {
        if (match[i] != 0) {
            fout << i << sp << match[i] - n1 << nl;
        }
    }
}