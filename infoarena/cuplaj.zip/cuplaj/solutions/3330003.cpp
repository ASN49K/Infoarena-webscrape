#include <bits/stdc++.h>

using namespace std;

#define USE_STD_IO 0
//#define if(USE_STD_IO) cout
#if USE_STD_IO
    #define fin cin
    #define fout cout
#else
    ifstream fin("cuplaj.in");
    ofstream fout("cuplaj.out");
#endif // USE_STD_IO

int n, m, q, i, rasp;
vector<int> gr[10002];

int cup[10002];
bool viz[10002];

static inline bool Cupleaza(int nod) {
    if(viz[nod]) return false;
    viz[nod] = true;
    for(int vec : gr[nod]) {
        if(cup[vec] == 0) {
            cup[vec] = nod;
            return true;
        }
    }
    for(int vec : gr[nod]) {
        if(Cupleaza(cup[vec])) {
            cup[vec] = nod;
            return true;
        }
    }

    return false;
}

int main() {
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin >> n >> m >> q;
    for(i = 1; i <= q; i++) {
        int x, y;
        fin >> x >> y;
        gr[x].push_back(y);
    }
    for(i = 1; i <= n; i++) {
        memset(viz, false, sizeof(viz));
        if(Cupleaza(i)) rasp++;
    }
    fout << rasp << "\n";
    for(i = 1; i <= m; i++) {
        if(cup[i] != 0) fout << cup[i] << " " << i << "\n";
    }

    return 0;
}
