//https://infoarena.ro/problema/cuplaj

#ifdef _MSC_VER
	#define _CRT_SECURE_NO_WARNINGS
#elif  __GNUC__
	#pragma GCC optimize("Ofast,unroll-loops,inline")
	#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
#endif

//#define _USE_MATH_DEFINES

#include <iostream>
#include <fstream>
#include <utility>
#include <cstdint>
//#include <cstdio>
//#include <algorithm>
#include <vector>
//#include <array>
//#include <list>
//#include <forward_list>
//#include <string>
#include <cstring>
//#include <cmath>
//#include <bitset>
//#include <queue>
//#include <stack>
//#include <map>
//#include <set>
//#include <unordered_map>
//#include <unordered_set>
//#include <limits>
//#include <climits>
//#include <iomanip>
//#include <tuple>
//#include <numeric>
//#include <chrono>
//#include <memory>

using namespace std;

using int64 = int64_t;
using uint64 = uint64_t;
using int32 = int32_t;
using uint32 = uint32_t;
using int16 = int16_t;
using uint16 = uint16_t;
using pii = pair<int, int>;
using pll = pair<int64, int64>;

#define all(x) (x).begin(), (x).end()
#define allg(x) (x).begin(), (x).end(), greater<int>()
#define sz(x) (int)(x).size()
#define pb push_back
#define eb emplace_back
#define rfor(i, st, dr) for(auto i=(st); i<=(dr); ++i)
#define for0(i,n) for(auto i=0; i<(n); ++i)
#define rfor0(i,n) for(auto i=(n)-1; i>=0; --i)
#define for1(i,n) for(auto i=1; i<=(n); ++i)
#define rfor1(i,n) for(auto i=(n); i>=1; --i)
#define foreach(x,a) for(auto& x : a)
#define cforeach(x,a) for(const auto& x : a)
#define ft first
#define sd second
#define cendl cout << "\n"
#define fendl fout << "\n"
#define FASTIO ios::sync_with_stdio(false); cin.tie(nullptr);

//#define int int64

template<typename T>
class FastIO
{
private:
	ifstream& fin;
	ofstream& fout;

	static constexpr int IN_BUF_SIZE = 262144;
	static constexpr int OUT_BUF_SIZE = 262144;

	char inBuf[IN_BUF_SIZE];
	int inPos = IN_BUF_SIZE, inBytes = IN_BUF_SIZE;

	char outBuf[OUT_BUF_SIZE];
	int outPos = 0;

	inline char getChar()
	{
		if (inPos == inBytes)
		{
			fin.read(inBuf, IN_BUF_SIZE);
			inBytes = fin.gcount();
			inPos = 0;
			if (inBytes == 0)
				return -1;
		}

		return inBuf[inPos++];
	}

	inline void writeChar(char c)
	{
		if (outPos == OUT_BUF_SIZE)
		{
			fout.write(outBuf, outPos);
			outPos = 0;
		}
		outBuf[outPos++] = c;
	}

	T read()
	{
		char c;
		bool neg = false;

		do
		{
			c = getChar();
			if (c == -1)
				return -1;
		} while ((c < '0' || c > '9') && c != '-');

		if (c == '-')
		{
			neg = true;
			c = getChar();
		}

		T res = 0;
		while (c >= '0' && c <= '9')
		{
			res = res * 10 + (c - '0');
			c = getChar();
		}
		return neg ? -res : res;
	}

	void write(T x)
	{
		if (x < 0)
		{
			writeChar('-');
			x = -x;
		}

		char temp[20];
		int len = 0;
		do
		{
			temp[len++] = '0' + x % 10;
			x /= 10;
		} while (x);

		while (len--)
			writeChar(temp[len]);
	}

public:
	FastIO(ifstream& finStream, ofstream& foutStream) : fin(finStream), fout(foutStream) {}

	void flush()
	{
		if (outPos > 0)
		{
			fout.write(outBuf, outPos);
			outPos = 0;
		}
	}

	friend FastIO<T>& operator>>(FastIO<T>& io, T& x)
	{
		x = io.read();
		return io;
	}

	friend FastIO<T>& operator<<(FastIO<T>& io, T x)
	{
		io.write(x);
		return io;
	}

	friend FastIO& operator<<(FastIO& io, const char* s)
	{
		for (int i = 0; s[i]; ++i)
			io.writeChar(s[i]);
		return io;
	}
};

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

//FILE* fin = fopen("cuplaj.in", "r");
//FILE* fout = fopen("cuplaj.out", "w");

const int NRMAX = 10000;

int dr[NRMAX + 5], st[NRMAX + 5];
vector<int> gr[NRMAX + 5];
int b[NRMAX + 5], poz;

bool dfs(int x) {
	if (b[x] == poz)
		return false;
	b[x] = poz;

	for (int it : gr[x]) {
		if (!dr[it]) {
			dr[it] = x;
			st[x] = it;
			return true;
		}
	}

	for (int it : gr[x]) {
		if (dfs(dr[it])) {
			dr[it] = x;
			st[x] = it;
			return true;
		}
	}

	return false;
}

int32 main() {
	//FASTIO;

	FastIO<int> io(fin, fout);

	int n, m, e, i, x, y;
	int rez = 0;

	io >> n >> m >> e;

	for (i = 0; i < e; ++i) {
		io >> x >> y;
		gr[x].push_back(y);
	}

	bool sant = true;

	while(sant) {
		sant = false;
		++poz;
		for (int i = 1; i <= n; ++i) {
			if (!st[i]) { 
				if (dfs(i)) {
					sant = true;
				}
			}
		}
	}

	for (i = 1; i <= n; ++i) {
		if (st[i])
			++rez;
	}

	io << rez << "\n";
	io.flush();
	for (i = 1; i <= n; ++i) {
		if (st[i])
			fout << i << " " << st[i] << "\n";
	}
	io.flush();

	return 0;
}
