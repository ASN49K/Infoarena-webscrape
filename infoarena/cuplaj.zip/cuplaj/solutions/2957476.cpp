#include <iostream>
#include <bits/stdc++.h>
#include <fstream>

#define mx 10001
using namespace std;
ifstream f("cuplaj.in");
ofstream g("cuplaj.out");
#define minim min(x,flux)
int n, m, x, y, capacitate, e;
int rgraf[2 * mx][2 * mx];

bool bfs(int s, int d, int tata[], bool vizitat[]) {
    queue<int> q;
    vizitat[s] = true;
    tata[s] = -1;
    q.push(s);
    while (!q.empty()) {
        int front = q.front();
        q.pop();
        for (int i = 1; i <= n + m + 1; ++i) {
            if (vizitat[i] == false && rgraf[front][i] > 0) {
                if (i == n + m + 1) {
                    tata[i] = front;
                    return true;
                }
                vizitat[i] = true;
                q.push(i);
                tata[i] = front;
            }
        }
    }
    //daca se poate ajunge la destinatie
    return vizitat[n + m + 1];
}

int main() {
    f >> n >> m >> e;
    for (int i = 1; i <= n; ++i) {
        rgraf[0][i] = 1;
    }
    for (int i = n + 1; i <= m + n; ++i) {
        rgraf[i][m + n + 1] = 1;
    }

    for (int i = 0; i < e; i++) {
        f >> x >> y;
        rgraf[x][y + n] = 1;
    }
    int tata[n + m + 2];
    for (int i = 0; i <= m + n + 1; i++)
        tata[i] = -1;
    bool vizitat[n + m + 2];
    for (int i = 0; i <= n + m + 1; i++)
        vizitat[i] = false;
    int cuplaje = 0;
    vector<pair<int, int>> muchii;
    while (bfs(0, n + m + 1, tata, vizitat)) {
        for (int i = n + 1; i <= n + m; i++) {
            if (rgraf[i][n + m + 1] > 0 && vizitat[i] == true) {
                tata[n + m + 1] = i;

                int flux = INT_MAX;
                int u = n + m + 1;
                while (u != 0) {
                    int x = rgraf[tata[u]][u];
                    flux = minim;
                    u = tata[u];
                }

                if (flux != 0) {
                    cuplaje += 1;
                    u = n + m + 1;
                    int nr = 0;
                    while (u != 0) {
                        int vecin = tata[u];
                        if (nr++ == 1)
                            muchii.push_back({vecin, u - n});
                        rgraf[vecin][u] -= flux;
                        rgraf[u][vecin] += flux;
                        u = tata[u];
                    }
                }

            }
        }
        for (int i = 0; i <= m + n + 1; i++)
            tata[i] = -1;
        for (int i = 0; i <= m + n + 1; i++)
            vizitat[i] = false;

    }

    g << cuplaje << '\n';
    for (auto muchie: muchii)
        if (rgraf[muchie.first][muchie.second] == 0 && rgraf[muchie.second][muchie.first] == 0)
            g << muchie.first << ' ' << muchie.second << '\n';
    f.close();
    f.close();
    return 0;
}