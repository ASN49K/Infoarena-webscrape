#include <fstream>
#include <vector>

using namespace std;
const int nmax = 2e4;

vector < int > g[nmax];
int p[nmax];
int vis[nmax];

int Pair ( int node ) {
    vis[node] = 1;
    for ( int x: g[node] ) {
        if ( p[x] == -1 ) {
            p[x] = node;
            p[node] = x;
            return true;
        }
        if ( !vis[p[x]] && Pair ( p[x] ) ) {
            p[x] = node;
            p[node] = x;
            return true;
        }
    }
    return false;
}

ifstream fin ( "cuplaj.in" );
ofstream fout ( "cuplaj.out" );

int main() {
    int n, m, e, x, y;
    fin >> n >> m >> e;
    for ( int i = 0; i < e; i++ ) {
        fin >> x >> y;
        x--, y--;
        y += n;
        g[x].push_back ( y );
        g[y].push_back ( x );
    }

    for ( int i = 0; i < n + m; i++ )
        p[i] = -1;

    int cnt = 0, pairup;
    do {
        pairup = false;
        for ( int i = 0; i < n; i++ )
            if ( !vis[i] && p[i] == -1 && Pair ( i ) ) {
                cnt++;
                pairup = true;
            }

        for ( int i = 0; i < n + m; i++ )
            vis[i] = 0;
    } while ( pairup );

    fout << cnt << '\n';
    for ( int i = 0; i < n; i++ )
        if ( p[i] != -1 )
            fout << 1 + i << ' ' << 1 + p[i] - n << '\n';


    return 0;
}
