#include <fstream>
#include <vector>
using namespace std;

ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");

const int MAX = 1e4 + 1;

int l[MAX] , r[MAX] , x , y , m , n , muchii;

bool viz[MAX];

vector <int> g[MAX];

int hk( int x ){

    viz[x] = 1;

    for(auto it : g[x]){

        if(!r[it]){

            r[it]=x;
            l[x]=it;

            return 1;
        }
    }

    for(auto it : g[x]){

        if(!viz[r[it]] && hk(r[it])){

            r[it]=x;
            l[x]=it;

            return 1;
        }
    }

    return 0;
}

int main(){

    cin >> n >> m >> muchii;

    while(muchii--){

        cin >> x >> y;

        g[x].push_back(y);
    }

    int cate = 0 , cateog = 0;

    while(1){

        for(int i = 1 ; i <= n ; i++){

            viz[i] = 0;
        }

        cateog = cate;

        for(int i = 1 ; i <= n ; i++){

            if(!l[i]){

                cate+=hk(i);
            }
        }

        if(cate == cateog) break;
    }

    cout << cate << '\n';

    for(int i = 1 ; i <= n ; i++){

        if(l[i]) cout << i << ' ' << l[i] << '\n';
    }

    return 0;
}
