#include <fstream>
#include <vector>
#include <algorithm>

std::ifstream in("cuplaj.in");
std::ofstream out("cuplaj.out");

constexpr int N = 1e4+1;
int n1, n2;
std::vector<int> g1[N];
int pereche1[N], pereche2[N];
bool vis[N];

int incearca(int x1){
    if(vis[x1]) 
        return 0;
    vis[x1] = true;
    for(auto x2 : g1[x1]){
        if(pereche2[x2] == 0 || incearca(pereche2[x2]) != 0){
            pereche1[x1] = x2;
            pereche2[x2] = x1;
            return x2;
        }
    }
    return 0;
}

int main(){
    int m;
    in >> n1 >> n2 >> m;
    for(int i=0; i<m; ++i){
        int u, v;
        in >> u >> v;
        g1[u].push_back(v);
    }
    bool imbunatatit;
    do{
        imbunatatit = false;
        std::fill(vis + 1, vis + 1 + N, false);
        for(int i=1; i<=n1; ++i){
            if(pereche1[i] == 0){
                pereche1[i] = incearca(i);
                imbunatatit |= (pereche1[i] != 0);
            }
        }
    }
    while(imbunatatit);
    int cuplaj = std::count_if(pereche1 + 1, pereche1 + 1 + n1, [](int val){return val!=0;});
    out << cuplaj << '\n';
    for(int i=1; i<=n1; ++i){
        if(pereche1[i] != 0) 
            out << i << ' ' << pereche1[i] << '\n'; 
    }
}