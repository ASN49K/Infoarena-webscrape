#include <bits/stdc++.h>
using namespace std;

vector<int> v[10005];

int l[10005], r[10005];
bool vis[10005];

bool dfs(int x)
{
    if(vis[x]) return false;
    vis[x] = true;

    for(auto y : v[x])
    {
        if(r[y] == 0 || dfs(r[y]))
        {
            l[x] = y;
            r[y] = x;
            return true;
        }
    }

    return false;
}

int main()
{
    ifstream cin("cuplaj.in");
    ofstream cout("cuplaj.out");

    int n,m,e;
    cin >> n >> m >> e;

    for(int i=0;i<e;i++)
    {
        int x,y;
        cin >> x >> y;
        v[x].push_back(y);
    }

    bool ok = true;

    while(ok)
    {
        ok = false;
        memset(vis,0,sizeof(vis));

        for(int i=1;i<=n;i++)
            if(l[i]==0)
                if(dfs(i))
                    ok = true;
    }

    int cnt = 0;

    for(int i=1;i<=n;i++)
        if(l[i]) cnt++;

    cout << cnt << "\n";

    for(int i=1;i<=n;i++)
        if(l[i])
            cout << i << " " << l[i] << "\n";
}
