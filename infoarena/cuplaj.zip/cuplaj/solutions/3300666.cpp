#include <bits/stdc++.h>

using namespace std;

#define INF INT_MAX

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

vector<vector<int>> cap;
vector<vector<int>> adj;
vector<int> sol;
int n, a, b;


int bfs(int s, int t, vector<int>& p) {
    queue<pair<int, int>> q;
    fill(p.begin(), p.end(), -1);

    q.push({s, INT_MAX});

    while(!q.empty()) {
        auto& [nod, minf] = q.front();
        q.pop();

        for (int neigh : adj[nod])
            if (p[neigh] == -1 && cap[nod][neigh]) {
                p[neigh] = nod;
                int new_minf = min(minf, cap[nod][neigh]);
                if (neigh == t)
                    return new_minf;
                q.push({neigh, new_minf});
            }
    }

    return 0;
}

int edmonds_karp(int s, int t) {
    int maxflow = 0, newflow;
    vector<int> p(n + 2);

    while(newflow = bfs(s, t, p)) {
        maxflow += newflow;
        int curr = t, x, y = p[t];
        
        while(curr != s) {
            int prev = p[curr];
            cap[curr][prev] += newflow;
            cap[prev][curr] -= newflow;
            curr = prev;
        }
    }

    return maxflow;
}

int main() {
    int m;

    fin >> a >> b >> m;
    n = a + b;
    cap.resize(n + 2, vector<int>(n + 2));
    adj.resize(n + 2);
    sol.resize(n + 2);

    for (int i = 1, x, y; i <= m; ++i) {
        fin >> x >> y;
        y += a;
        cap[x][y] = 1;
        adj[x].push_back(y);
        adj[y].push_back(x);

        adj[0].push_back(x);
        adj[x].push_back(0);
        cap[0][x] = cap[x][0] = 1;

        adj[y].push_back(n + 1);
        adj[n + 1].push_back(y);
        cap[y][n + 1] = cap[n + 1][y] = 1;
    }

    fout << edmonds_karp(0, n + 1) << '\n';
    for (int i = 1; i <= a; ++i)
        for (int j = a + 1; j <= n; ++j)
            if (cap[j][i])
                fout << i << ' ' << j - a << '\n';
}