#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
using namespace std;
ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

queue<int> coada;

vector<vector<int>> a;

vector<int> vizitat;

int flux[10003][10003], fmax, fmin = 9999999999, n, m, tata[10003], ok, e, nrmax;

void citire()
{
    f>>n>>m>>e;

    int x, y;

    nrmax = n + m + 1;

    a.resize(nrmax+1);

    for(int i = 0; i < e; i++)
    {
        f>>x>>y;
        a[x].push_back(y+n);
        a[y+n].push_back(x);
    }


    for(int i = 1; i <= n; i++)
    {
        a[0].push_back(i);
        a[i].push_back(0);
    }

    for(int i = 1; i <= m; i++)
        {
            a[nrmax].push_back(i+n);
            a[i+n].push_back(nrmax);
        }

}

void afisare()
{
    for(int i = 1; i <= n; i++)
    {
        for(int j = 0; j < a[i].size(); j++)
        {
            g<<i<<" "<<a[i][j]<<" "<<1<<endl;
        }
    }
}

void bfs(int &ok)
{
    coada.push(0);

    fill(vizitat.begin(), vizitat.end(), 0);

    vizitat[0] = 1;

    while(!coada.empty())
    {
        int nod = coada.front();
        coada.pop();

        if(nod != nrmax)

        for(int k = 0; k < a[nod].size(); k++)
        {
            if(vizitat[a[nod][k]] == 0 && 1 != flux[nod][a[nod][k]])
            {
                coada.push(a[nod][k]);
                vizitat[a[nod][k]] = 1;
                tata[a[nod][k]] = nod;
            }
        }
    }

    ok = vizitat[nrmax];
}


int main()
{
    citire();

    vizitat.resize(nrmax+1);

    do
        {

        bfs(ok);

        for(int i = 0; i < a[nrmax].size(); i++)
        {

            int nod = a[nrmax][i];

            if(1 != flux[nod][nrmax] && vizitat[nod])
            {
                fmin = 9999999999; tata[nrmax] = nod;

                nod = nrmax;

                while(nod != 0)
                {
                    if(fmin > 1 - flux[tata[nod]][nod])
                        fmin = 1 - flux[tata[nod]][nod];
                    nod = tata[nod];
                }

                if(fmin)
                {
                    nod = nrmax;

                    while(nod != 0)
                    {
                        flux[tata[nod]][nod] += fmin;
                        flux[nod][tata[nod]] -= fmin;
                        nod = tata[nod];
                    }

                    fmax += fmin;
                }
            }
        }

        }while(ok);

    g<<fmax<<'\n';


    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= m; j++)
        if(flux[i][j+n])
        g<<i<<" "<<j<<'\n';

}
