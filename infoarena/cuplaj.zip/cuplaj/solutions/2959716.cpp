#include <cstdio>
#include <vector>
#include <algorithm>
#include<cstring>
using namespace std;

const char iname[] = "cuplaj.in";
const char oname[] = "cuplaj.out";

#define MAXN  10005
#define FOR(i, a, b)  for (int i = (int)(a); i <= (int)(b); ++ i)
#define FORI(i, V)    for (vector <int>::iterator i = (V).begin(); i != (V).end(); ++ i)

vector <int> G[MAXN];

int l[MAXN], r[MAXN], u[MAXN];


int pairup(const int n)
{
    if (u[n])  return 0;
    u[n] = 1;
    FORI (i, G[n]) if (!r[*i]) {
        l[n] = *i;
        r[*i] = n;
        return 1;
    }
    FORI (i, G[n]) if (pairup(r[*i])) {
        l[n] = *i;
        r[*i] = n;
        return 1;
    }
    return 0;
}

int main(void)
{
    freopen(iname, "r", stdin);
    freopen(oname, "w", stdout);

    int n, m, cnt_edges;
    scanf("%d %d %d", &n, &m, &cnt_edges);
    for (; cnt_edges --; )
    {
        int x, y;
        scanf("%d %d", &x, &y);
        G[x].push_back(y);
    }
    int cuplaj = 0;
    FOR (i, 1, n) if (!l[i]) {
        if (!pairup(i)) {
            memset(u, 0, sizeof(u));
            cuplaj += pairup(i);
        }
        else
            cuplaj ++;
    }
    printf("%d\n", cuplaj);
    FOR (i, 1, n) if (l[i] > 0)
        printf("%d %d\n", i, l[i]);

    return 0;
}
