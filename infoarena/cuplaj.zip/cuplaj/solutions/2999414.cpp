#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
#include <map>
#include <set>
#include <cstring>
#include <string>
#include <unordered_set>
#include <cmath>
#include <iomanip>
#include <unordered_map>
#include <climits>
#include <random>
#include <functional>

using namespace std;

ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");

int l[10005], r[10005], use[10005];
vector<int> L1[10005], L2[10005];
int n, m;
bool pairup(int x)
{
    if (use[x])
        return false;
    use[x] = true;
    for (int i : L1[x])
        if (!r[i])
        {
            l[x] = i;
            r[i] = x;
            return true;
        }
    for (int i : L1[x])
        if (pairup(r[i]))
        {
            l[x] = i;
            r[i] = x;
            return true;
        }
    return false;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    int n, m, e;
    cin >> n >> m >> e;
    while (e--)
    {
        int x, y;
        cin >> x >> y;
        L1[x].push_back(y);
        L2[y].push_back(x);
    }
    bool changed;
    do
    {
        changed = false;
        memset(use, 0, sizeof(use));
        for (int i=1;i<=n;i++)
        {
	        if (l[i])
                continue;
            if (pairup(i))
                changed = true;
        }
    } while (changed);
    int cup = 0;
    for (int i = 1; i <= n; i++)
        if (l[i])
            cup++;
    cout << cup << '\n';
    for (int i = 1; i <= n; i++)
        if (l[i])
            cout << i << ' ' << l[i] << '\n';
    return 0;
}
