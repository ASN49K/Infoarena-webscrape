#include <bits/stdc++.h>
using namespace std;
const char nl = '\n';
const char sp = ' ';
const int inf = 0x3f3f3f3f;
const int mod = 1e9 + 7;
const char out[2][4]{ "NO", "YES" };
#define all(a) a.begin(), a.end()
using ll = long long;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

const int nmax = 1e4;
int n1, n2, m;
vector<int> g[nmax + 5];
bool vis[nmax + 5]{ 0 };
int match[nmax + 5]{ 0 };

bool solve(int u) {
    vis[u] = true;
    for (auto& v : g[u]) {
        if (match[v] == 0) {
            match[v] = u;
            return true;
        }
        if (vis[match[v]]) {
            continue;
        }
        if (solve(match[v])) {
            match[v] = u;
            return true;
        }
    }
    return false;
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    fin >> n1 >> n2 >> m;
    vector<pair<int, int>> edges;
    for (int i = 1; i <= m; ++i) {
        int u, v;
        fin >> u >> v;
        edges.push_back({ u, v });
    }
    bool swapped = n1 > n2;
    if (n1 > n2) {
        for (auto& edge : edges) {
            swap(edge.first, edge.second);
        }
        
    }
    for (int i = 1; i <= n1; ++i) {
        fill(vis + 1, vis + n1 + 1, 0);
        solve(i);
    }
    fout << n2 - count(match + 1, match + n2 + 1, 0) << nl;
    for (int i = 1; i <= n2; ++i) {
        if (match[i] != 0) {
            if (swapped) {
                fout << i << sp << match[i] << nl;
            }
            else {
                fout << match[i] << sp << i << nl;
            }
        }
    }
}