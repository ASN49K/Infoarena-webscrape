#include <fstream>
#include <queue>
#include <vector>
using namespace std;

ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");

int n, m, e;
bool used[10005];
int l[10005], r[10005];
vector<int> edges[10005];
bool pairup(int node) {
    if(used[node])return 0;
    used[node]=1;
    for(auto i: edges[node]) {
        if(r[i]==0) {
            l[node]=i;
            r[i]=node;
            return 1;
        }
    }
    for(auto i: edges[node]) {
        if(pairup(r[i])) {
            l[node]=i;
            r[i]=node;
            return 1;
        }
    }
    return 0;
}

int main() {
    cin>>n>>m>>e;
    for(int i=0;i<e;i++) {
        int st, dr;
        cin>>st>>dr;
        edges[st].push_back(dr);
    }
    bool changed=true;
    while(changed) {
        changed=false;
        for(int i=1;i<=n;i++) used[i]=0;
        for(int i=1;i<=n;i++)
        {
            if(l[i]==0)changed|=pairup(i);
        }
    }
    int cuplaj=0;
    for(int i=1;i<=n;i++) {
        if(l[i])cuplaj++;
    }
    for(int i=1;i<=n;i++) {
        if(l[i])cout<<i<<' '<<l[i]<<'\n';
    }
    return 0;
}
