#include <iostream>
#include <fstream>
#include <bitset>
#include <vector>

#define MAX 10002

using namespace std;

ifstream fin ("cuplaj.in");
ofstream fout ("cuplaj.out");

int n, m, e, r[MAX], l[MAX];
vector<int> G[MAX];
bitset<MAX> viz;

void citire()
{
    fin >> n >> m >> e;
    for (int i = 1; i <= e; i++)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
    }
}

bool match(int nod)
{
    if (viz[nod])
        return false;
    viz[nod] = true;

    for (int i = 0; i < G[nod].size(); i++)
    {
        if (r[G[nod][i]] == 0)
        {
            l[nod] = G[nod][i];
            r[G[nod][i]] = nod;
            return true;
        }
    }

    for (int i = 0; i < G[nod].size(); i++)
    {
        if (match(G[nod][i]))
        {
            l[nod] = G[nod][i];
            r[G[nod][i]] = nod;
            return true;
        }
    }

    return false;
}

int main()
{
    citire();

    bool ok = true;
    while (ok)
    {
        ok = false;
        viz.reset();

        for (int i = 1; i <= n; i++)
        {
            if (l[i] == 0)
                ok |= match(i);
        }
    }

    int sol = 0;
    for (int i = 1; i <= n; i++)
        if (l[i] != 0) sol++;

    fout << sol << "\n";

    for (int i = 1; i <= n; i++)
        if (l[i] != 0)
            fout << i << " " << l[i] << "\n";


    return 0;
}
