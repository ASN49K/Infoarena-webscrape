#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
#include <algorithm>
using namespace std;

const int MAXN = 10005;
const int INF = 1e9;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int N, M, E;
vector<int> graph[MAXN];
int matchL[MAXN], matchR[MAXN];
int dist[MAXN];

bool bfs() {
    queue<int> q;
    for (int u = 1; u <= N; u++) {
        if (matchL[u] == 0) {
            dist[u] = 0;
            q.push(u);
        } else {
            dist[u] = INF;
        }
    }
    dist[0] = INF;
    while (!q.empty()) {
        int u = q.front(); q.pop();
        if (dist[u] < dist[0]) {
            for (int v : graph[u]) {
                if (dist[matchR[v]] == INF) {
                    dist[matchR[v]] = dist[u] + 1;
                    q.push(matchR[v]);
                }
            }
        }
    }
    return dist[0] != INF;
}

bool dfs(int u) {
    if (u != 0) {
        for (int v : graph[u]) {
            if (dist[matchR[v]] == dist[u] + 1) {
                if (dfs(matchR[v])) {
                    matchR[v] = u;
                    matchL[u] = v;
                    return true;
                }
            }
        }
        dist[u] = INF;
        return false;
    }
    return true;
}

int hopcroftKarp() {
    memset(matchL, 0, sizeof(matchL));
    memset(matchR, 0, sizeof(matchR));
    int matching = 0;
    while (bfs()) {
        for (int u = 1; u <= N; u++) {
            if (matchL[u] == 0 && dfs(u)) {
                matching++;
            }
        }
    }
    return matching;
}

int main() {
    fin >> N >> M >> E;
    for (int i = 0; i < E; i++) {
        int u, v;
        fin >> u >> v;
        graph[u].push_back(v);
    }
    int result = hopcroftKarp();
    fout << result << "\n";
    for (int u = 1; u <= N; u++) {
        if (matchL[u] != 0) {
            fout << u << " " << matchL[u] << "\n";
        }
    }
    fin.close();
    fout.close();
    return 0;
}