#include <fstream>
#include <vector>
#include <bitset>

using namespace std;

const int N = 10000;

int n1, n2, pereche1[N+1], pereche2[N+1];
vector <int> a1[N+1];//, a2[N+1];
bitset <N+1> viz;

int incearca(int x1)
{
    if (viz[x1])
    {
        return 0;
    }
    viz[x1] = 1;
    for (auto x2: a1[x1])
    {
        if (pereche2[x2] == 0 || incearca(pereche2[x2]) != 0)
        {
            pereche1[x1] = x2;
            pereche2[x2] = x1;
            return x2;
        }
    }
    return 0;
}

int main()
{
    ifstream in("cuplaj.in");
    ofstream out("cuplaj.out");
    int m;
    in >> n1 >> n2 >> m;
    for (int i = 0; i < m; i++)
    {
        int x1, x2;
        in >> x1 >> x2;
        a1[x1].push_back(x2);
        //a2[x2].push_back(x1);
    }
    bool imbunatatit;
    do
    {
        imbunatatit = false;
        viz.reset();
        for (int i = 1; i <= n1; i++)
        {
            if (pereche1[i] == 0)
            {
                pereche1[i] = incearca(i);
                if (pereche1[i] != 0)
                {
                    imbunatatit = true;
                }
            }
        }
    }
    while (imbunatatit);
    int cuplaj = 0;
    for (int i = 1; i <= n1; i++)
    {
        if (pereche1[i] != 0)
        {
            cuplaj++;
        }
    }
    out << cuplaj << "\n";
    for (int i = 1; i <= n1; i++)
    {
        if (pereche1[i] != 0)
        {
            out << i << " " << pereche1[i] << "\n";
        }
    }
    return 0;
}
