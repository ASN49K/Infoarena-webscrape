#include <bits/stdc++.h>

using namespace std;
ifstream f("cuplaj.in");
ofstream g("cuplaj.out");
int destinatie, capacitate[10000001][10000001], parinte[10000001];
vector<vector<int> > muchii;

int newSource, newDestination;

int N, M, E;

void citeste();
int edmondsKarp();


bool bfs() {
    vector<bool> ap;
    queue<int> q;
    ap.resize(newDestination + 1);
    q.push(newSource);
    ap[newSource] = true;
    while(!q.empty()){
        int nod = q.front();
        q.pop();
        for(auto it : muchii[nod]){
            if(!ap[it] && capacitate[nod][it]){
                parinte[it] = nod;
                ap[it] = true;
                q.push(it);
                if(it == newDestination)
                    return true;
            }
        }
    }
    return false;
}

int edmondsKarp()
{
    int raspuns = 0;
    while(bfs()) {
        int nod = newDestination, newFlow = 1000000000;
        while(nod != 0) {
            int par = parinte[nod];
            if(capacitate[par][nod] < newFlow) {
                newFlow = capacitate[par][nod];
            }
            nod = par;
        }
        nod = newDestination;
        while(nod != 0) {
            int par = parinte[nod];
            capacitate[par][nod] -= newFlow;
            capacitate[nod][par] += newFlow;
            nod = par;
        }
        raspuns += newFlow;
    }
    return raspuns;
}

int main()
{


    f >> N >> M >> E;
    muchii.assign(N + M + 2, vector<int>());
    while(E--) {
        int x, y;
        f >> x >> y;
        y = N + y;
        muchii[x].push_back(y);
        muchii[y].push_back(x);
        capacitate[x][y] = 1;
    }

    
    newSource = 0;  
    newDestination = N + M + 1;

    

    // Adaug muchii de la newSource la fiecare nod din partea stanga
    for(int i = 1; i <= N; i++) {
        muchii[0].push_back(i);
        muchii[i].push_back(0);
        capacitate[0][i] = 1;
    }
    
    

    // Adaug muchii de la fiecare nod din partea dreapta la newDestination
    for(int i = N + 1; i <= N + M; i++) {
        muchii[i].push_back(newDestination);
        muchii[newDestination].push_back(i);
        capacitate[i][newDestination] = 1;
    }

    
    // Print muchii

    // for(int i = 0; i < muchii.size(); i++) {
    //     cout << i << ": ";
    //     for(int j = 0; j < muchii[i].size(); j++) {
    //         cout << muchii[i][j] << " ";
    //     }
    //     cout << endl;
    // }





    f.close();

    g << edmondsKarp()<< endl;

    for(int i = 1; i <= N; i++) {
        for(int j = N + 1; j <= N + M; j++) {
            if(capacitate[j][i] == 1) {
                g << i << " " << j - N << endl;
            }
        }
    }
    g.close();

    return 0;
}