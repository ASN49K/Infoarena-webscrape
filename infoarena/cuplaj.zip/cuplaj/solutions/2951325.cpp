#include <fstream>
#include <vector>

using namespace std;
const int nmax = 1e5;

vector < int > g[2 * nmax + 1];
bool vis[2 * nmax + 1];
int p[2 * nmax + 1];

bool Pair ( int node ) {
    vis[node] = true;
    for ( int x: g[node] ) {
        if ( p[x] == 0 ) {
            p[node] = x;
            p[x] = node;
            return true;
        }
        if ( !vis[p[x]] && Pair ( p[x] ) ) {
            p[node] = x;
            p[x] = node;
            return true;
        }
    }
    return false;
}

ifstream fin ( "cuplaj.in" );
ofstream fout ( "cuplaj.out" );

int main() {
    int n, m, e, a, b;

    fin >> n >> m >> e;

    for ( int i = 0; i < e; i++ ) {
        fin >> a >> b;
        b += n;
        g[a].push_back ( b );
        g[b].push_back ( a );
    }

    int cnt = 0;
    bool ok;
    do {
        ok = false;
        for ( int i = 1; i <= n; i++ )
            if ( !vis[i] && !p[i] && Pair ( i ) ) {
                cnt++;
                ok = true;
            }
        for ( int i = 1; i <= n + m; i++ )
            vis[i] = false;
    } while ( ok );

    fout << cnt << '\n';
    for ( int i = 1; i <= n; i++ )
        if ( p[i] )
            fout << i << ' ' << p[i] - n << '\n';

    return 0;
}
