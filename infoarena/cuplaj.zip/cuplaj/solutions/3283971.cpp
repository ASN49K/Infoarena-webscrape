#include <bits/stdc++.h>
using namespace std;
ifstream in("cuplaj.in");
ofstream out("cuplaj.out");
bitset<10001> vstd;
int pairSt[10001], pairDr[10001], nodes1, nodes2, edges, a, b, cuplaj;
vector<int> v[10001];
bool pairUp(int node)
{
    if(vstd[node])
        return false;
    vstd[node]=1;
    for(auto nextNode : v[node])
    {
        if(pairDr[nextNode]==0)
        {
            pairSt[node]=nextNode;
            pairDr[nextNode]=node;
            return true;
        }
    }
    for(auto nextNode : v[node])
    {
        if(nextNode!=pairSt[node] && pairUp(pairDr[nextNode]))
        {
            pairSt[node]=nextNode;
            pairDr[nextNode]=node;
            return true;
        }
    }
    return false;
}
int main()
{
    ios::sync_with_stdio(false);
    in.tie(0);
    out.tie(0);
    in >> nodes1 >> nodes2 >> edges;
    while(edges--)
    {
        in >> a >> b;
        v[a].push_back(b);
    }
    bool changed=true;
    while(changed)
    {
        changed=false;
        vstd=0;
        for(int i=1; i<=nodes1; i++)
        {
            if(pairSt[i]==0 && pairUp(i))
            {
                changed=true;
                cuplaj++;
            }
        }
    }
    out << cuplaj << '\n';
    for(int i=1; i<=nodes1; i++)
    {
        if(pairSt[i]!=0)
            out << i << ' ' << pairSt[i] << '\n';
    }
}