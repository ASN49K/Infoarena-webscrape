#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n, m, e, i, j, x, y, l[20005], r[20005], nr;
vector <int> v[20005];
bool viz[20005];
bool try_kuhn(int nod)
{
    if(viz[nod])
        return false;
    viz[nod]=true;
    for(auto i: v[nod])
        if(r[i]==-1 || try_kuhn(r[i]))
    {
        r[i]=nod;
        l[nod]=i;
        return true;
    }
    return false;
}
int main()
{
    fin>>n>>m>>e;
    for(i=1; i<=e; i++)
    {
        fin>>x>>y;
        v[x].push_back(y+n);
        v[y+n].push_back(x);
    }
    for(i=1; i<=n; i++)
        l[i]=-1;
    for(i=n+1; i<=n+m; i++)
        r[i]=-1;
    bool change=1;
    while(change)
    {
        change=0;
        for(i=1; i<=n+m; i++)
            viz[i]=0;
        for(i=1; i<=n; i++)
            if(l[i]==-1)
              change|=try_kuhn(i);
    }
    for(i=1; i<=n; i++)
        if(l[i]!=-1)
          nr++;
    fout<<nr<<'\n';
    for(i=1; i<=n; i++)
        if(l[i]!=-1)
        fout<<i<<" "<<l[i]-n<<'\n';
    return 0;
}
