#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <climits>
#include <bits/stdc++.h>
using namespace std;

int l,r,m,n,x,y,c,s,d;
vector<int>viz;
vector<int>t;
vector<vector<int>>indici;


struct muchie{
    int x,y,c,poz;
};

vector<muchie>M;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

int BFS(){
    for(int i = 0;i<=n;i++){
        t[i] = 0;
        viz[i] = 0;
    }
    queue<int>q;
    viz[s]=1;
    q.push(s);

    while(!q.empty()){
        int vf = q.front();
        q.pop();
        if(vf == d){
            return 1;
        }
        for(auto aux:indici[vf]){
            muchie mc = M[aux];
            if(!viz[mc.y] && mc.c>0){
                q.push(mc.y);
                viz[mc.y] = 1;
                t[mc.y] = aux;
            }
        }
    }
   return 0;
}


int main(){
    f>>l>>r>>m;
    n=l+r+2;
    s=0;
    d = n-1;

    viz.resize(n);
    t.resize(n);
    indici.resize(n);

    int dim = 0;
    for(int i=1;i<=m;i++){
        f>>x>>y;
        dim +=2;
        M.push_back({x,y+l,1,dim-1});
        M.push_back({y+l,x,0,dim-2});
        indici[x].push_back(dim-2);
        indici[y+l].push_back(dim-1);
    }

    for(int i=1;i<=l;i++){
        dim+=2;
        M.push_back({s,i,1,dim-1});
        M.push_back({i,s,0,dim-2});
        indici[s].push_back(dim-2);
        indici[i].push_back(dim-1);
    }

    for(int i = 1+l; i<=r+l; i++){
        dim+=2;
        M.push_back({i,d,1,dim-1});
        M.push_back({d,i,0,dim-2});
        indici[i].push_back(dim-2);
        indici[d].push_back(dim-1);
    }

    c=0;
    while(BFS()){
        for(auto aux:indici[d]){
            if(viz[M[aux].y] && M[M[aux].poz].c!=0){
                int minim = INT_MAX;
                muchie mc = M[aux];
                t[d] = mc.poz;
                int nod = d;

                while(nod != s){
                    minim = min(minim, M[t[nod]].c);
                    nod = M[t[nod]].x;
                }
                c +=minim;
                nod = d;
                while(nod!=s){
                    M[t[nod]].c -= minim;
                    M[M[t[nod]].poz].c +=minim;
                    nod = M[t[nod]].x;
                }
            }
        }
    }
    g<<c<<"\n";

    for(auto aux: M){
        if(aux.c==0 && aux.x!=s && aux.y!=d && aux.x<aux.y){
            g<<aux.x << " " << aux.y-l<<"\n";
        }
    }

    return 0;
}
