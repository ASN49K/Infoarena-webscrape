#include<bits/stdc++.h>
using namespace std;
ifstream F("cuplaj.in");
ofstream G("cuplaj.out");
vector<int> g[10001];
int u[10001],v[10001],d[10001],n,m,e,i,j,k,a[10001],b[10001];
bool A()
{
    int i;
    queue<int> q;
    for(i=1;i<=n;!u[i]?q.push(i),d[i]=0:d[i]=2e9,++i);
    for(d[0]=2e9;!q.empty();q.pop())
        if(i=q.front(),d[i]<d[0])
            for(int k=g[i].size(),j=0;j<k;d[v[g[i][j]]]==2e9?q.push(v[g[i][j]]),d[v[g[i][j]]]=d[i]+1:0,++j);
    return (d[0]!=2e9);
}
bool B(int i)
{
    if(i) {
        for(int k=g[i].size(),j=0;j<k;++j)
            if(d[v[g[i][j]]]==d[i]+1&&B(v[g[i][j]]))
                return v[g[i][j]]=i,u[i]=g[i][j],1;
        return d[i]=2e9,0;
    }
    return 1;
}
int main()
{
    for(F>>n>>m>>e;e--;F>>i>>j,g[i].push_back(j));
    for(;A();)
        for(i=1;i<=n;++i)
            if(!u[i]&&B(i))
                a[k]=i,b[k++]=u[i];
    for(G<<k<<'\n',i=0;i<k;G<<a[i]<<' '<<b[i]<<'\n',++i);
    return 0;
}
