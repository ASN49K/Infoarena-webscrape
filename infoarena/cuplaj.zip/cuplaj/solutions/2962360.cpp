#include <bits/stdc++.h>
using namespace std;
///ex2-a infoarena cuplaj
struct Edge{
    int y, capacity;
};
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
vector<vector<Edge>> lista;
vector<int> viz, tata;
int n1, n2, m, t;
bool BFS()
{
    int s = 1;
    viz.clear();
    viz.resize(t + 1, 0);
    tata.clear();
    tata.resize(t + 1, 0);
    queue<int> coada;
    coada.push(s);
    viz[s] = 1;
    while(!coada.empty()) {
        int nod = coada.front();
        coada.pop();
        if (nod == t)
            continue;
        for (Edge &edge: lista[nod]) {
            if (!viz[edge.y] && edge.capacity > 0) {
                viz[edge.y] = 1;
                tata[edge.y] = nod;
                coada.push(edge.y);
            }
        }
    }
    return viz[t];
}
int findPosition(int x, int y){

    int st = 0;
    int dr = lista[x].size() - 1;
    int mij;
    while(st <= dr) {
        mij = (st + dr) / 2;
        if(lista[x][mij].y == y)
            return mij;
        else if(lista[x][mij].y < y)
            st = mij + 1;
        else if(lista[x][mij].y > y)
            dr = mij - 1;
    }
    return -1;
}
int minFlow(){

    int minflux = INT_MAX;
    for(int nod = t;tata[nod];nod = tata[nod])
    {
        minflux = min(minflux, lista[tata[nod]][findPosition(tata[nod], nod)].capacity);
    }
    return minflux;
}
void ex2(){
    fin>>n1>>n2>>m;
    t = n1 + n2 + 2;
    lista.resize(t + 1);
    for(int i = 0; i < m; i++)
    {
        int x, y;
        fin >> x >> y;
        lista[x + 1].push_back({y + n1 +1, 1});
        lista[y + n1 + 1].push_back({x + 1, 0});

    }
    for(int i = 2; i <= n1 + 1; i++)
    {
        lista[1].push_back({i, 1});
        lista[i].push_back({1, 0});
    }
    for(int i = n1 + 2; i <= n1 + n2 + 1; i++)
    {
        lista[i].push_back({t, 1});
        lista[t].push_back({i, 0});
    }
    for(int i = 1 ; i <= t; i++)
        sort(lista[i].begin(), lista[i].end(), [](Edge a, Edge b){return a.y < b.y;});
    int maxflow = 0;
    while(BFS())
    {
        for(Edge& edge : lista[t]){
            int pos = findPosition(edge.y,t);
            if (!viz[edge.y] || lista[edge.y][pos].capacity == 0)
                continue;
            tata[t] = edge.y;
            int minflux = minFlow();
            if (minflux == 0)
                continue;
            for(int nod = t; tata[nod]; nod = tata[nod])
            {
                lista[tata[nod]][findPosition(tata[nod], nod)].capacity -= minflux;
                lista[nod][findPosition(nod,tata[nod])].capacity += minflux;
            }
            maxflow += minflux;
        }
    }
    fout << maxflow << "\n";
    for(int i = 2; i <= n1 + 1; i++)
    {
        for(Edge& edge : lista[i])
        {
            if(edge.capacity == 0 && edge.y != 1)
                fout << i - 1 << " " << edge.y - n1 - 1 << "\n";
        }
    }
}

int main() {
    ex2();
    return 0;
}
