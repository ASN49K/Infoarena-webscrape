#include <bits/stdc++.h>

using namespace std;

ifstream in("cuplaj.in");
ofstream out("cuplaj.out");

int n,m,e;
vector<int>g[10005];
int cine[10005];
bool viz[10005];

bool kuhn(int nod)
{
    if (viz[nod])
        return false;
    viz[nod] = true;
    for (auto vecin : g[nod])
    {
        if (cine[vecin] == 0 or kuhn(cine[vecin]))
        {
            cine[vecin] = nod;
            return true;
        }
    }
    return false;
}

int main()
{
    in >> n >> m >> e;
    for (int i = 1; i <= e; i++)
    {
        int x,y;
        in >> x >> y;
        g[x].push_back(y);
    }
    vector<int>ord;
    for (int i = 1; i <= n; i++)
        ord.push_back(i);
    shuffle(ord.begin(),ord.end(),default_random_engine(12345));
    for (auto i : ord)
    {
        memset(viz,0,sizeof(viz));
        bool idk = kuhn(i);
    }
    int cardinal = 0;
    for (int i = 1; i <= m; i++)
        if (cine[i])
            cardinal++;
    out << cardinal << '\n';
    for (int i = 1; i <= m; i++)
        if (cine[i])
            out << cine[i] << ' ' << i << '\n';
    return 0;
}
