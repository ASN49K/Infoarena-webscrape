#include <bits/stdc++.h>
#define DIM 10001
using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int n, m, q, a, b;

int i, j;

int x[DIM], y[DIM];

bool ok;

bool found[DIM];

vector <int> G[DIM];

queue <int> ans;

bool join(int nod){

    found[nod] = 1;

    for(auto k : G[nod]){

        if(!y[k]){

            x[nod] = k;

            y[k] = nod;

            return 1;

        }

    }

    for(auto k : G[nod]){

        if(!found[y[k]] && join(y[k])){

            x[nod] = k;

            y[k] = nod;

            return 1;

        }

    }

    return 0;

}

int main(){

    fin >> n >> m >> q;

    for(i = 1; i <= q; i++){

        fin >> a >> b;

        G[a].push_back(b);

    }

    ok = 1;

    while(ok){

        ok = 0;

        memset(found, 0, sizeof(found));

        for(i = 1; i <= n; i++){

            if(!x[i]){

                ok |= join(i);

            }

        }

    }

    for(i = 1; i <= n; i++)

        if(x[i])

            ans.push(i);

    fout << ans.size() << "\n";

    while(!ans.empty()){

        fout << ans.front() << " " << x[ans.front()] << "\n";

        ans.pop();

    }

}
