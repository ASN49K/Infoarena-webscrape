#include <fstream>
#include <vector>
#include <cstring>
#define nmax (int)(1e4+1)
using namespace std;
ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");
int n1,n2,m,x,y,st[nmax],dr[nmax];
vector<int>v[nmax];
bool viz[nmax];
bool cuplaj(int nod){
    if(viz[nod])
        return 0;
    viz[nod]=1;
    for(auto i:v[nod])
        if(dr[i]==0){
            st[nod]=i;
            dr[i]=nod;
            return 1;
        }
    for(auto i:v[nod])
        if(cuplaj(dr[i])){
            st[nod]=i;
            dr[i]=nod;
            return 1;
        }
    return 0;
}
signed main()
{
    cin>>n1>>n2>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back(y);
    }
    bool ok=1;
    while(ok){
        memset(viz,0,sizeof(viz));
        ok=0;
        for(int i=1;i<=n1;i++)
            if(st[i]==0)
                ok=cuplaj(i)||ok;
    }
    int sol=0;
    for(int i=1;i<=n1;i++)
        if(st[i]!=0)
            sol++;
    cout<<sol<<'\n';
    for(int i=1;i<=n1;i++)
        if(st[i]!=0)
            cout<<i<<" "<<st[i]<<'\n';
    return 0;
}
