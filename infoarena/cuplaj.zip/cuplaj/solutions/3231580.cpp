import java.io.*;
import java.util.*;

public class Main {
	static final int MAX_NODES = 10001;
	static List<Integer>[] adjacencyList = new List[MAX_NODES];
	static int[] matchU = new int[MAX_NODES];
	static int[] matchV = new int[MAX_NODES];
	static int[] distance = new int[MAX_NODES];

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		int numU = scanner.nextInt();
		int numV = scanner.nextInt();
		int numEdges = scanner.nextInt();

		for (int i = 0; i <= numU; i++) {
			adjacencyList[i] = new ArrayList<>();
		}

		for (int i = 0; i < numEdges; i++) {
			int u = scanner.nextInt();
			int v = scanner.nextInt();
			adjacencyList[u].add(v);
		}

		System.out.println();
		int maxMatching = findMaximumMatching(numU, numV);
		System.out.println(maxMatching);

		for (int u = 1; u <= numU; u++) {
			if (matchU[u] != 0) {
				System.out.println(u + " " + matchU[u]);
			}
		}

		scanner.close();
	}

	static boolean bfs(int numU) {
		Queue<Integer> queue = new LinkedList<>();
		for (int u = 1; u <= numU; u++) {
			if (matchU[u] == 0) {
				distance[u] = 0;
				queue.add(u);
			} else {
				distance[u] = Integer.MAX_VALUE;
			}
		}
		distance[0] = Integer.MAX_VALUE;
		while (!queue.isEmpty()) {
			int u = queue.poll();
			if (distance[u] < distance[0]) {
				for (int v : adjacencyList[u]) {
					if (distance[matchV[v]] == Integer.MAX_VALUE) {
						distance[matchV[v]] = distance[u] + 1;
						queue.add(matchV[v]);
					}
				}
			}
		}
		return distance[0] != Integer.MAX_VALUE;
	}

	static boolean dfs(int u) {
		if (u != 0) {
			for (int v : adjacencyList[u]) {
				if (distance[matchV[v]] == distance[u] + 1) {
					if (dfs(matchV[v])) {
						matchV[v] = u;
						matchU[u] = v;
						return true;
					}
				}
			}
			distance[u] = Integer.MAX_VALUE;
			return false;
		}
		return true;
	}

	static int findMaximumMatching(int numU, int numV) {
		Arrays.fill(matchU, 0);
		Arrays.fill(matchV, 0);
		int matching = 0;
		while (bfs(numU)) {
			for (int u = 1; u <= numU; u++) {
				if (matchU[u] == 0 && dfs(u)) {
					matching++;
				}
			}
		}
		return matching;
	}
}