#include <fstream>
#include <algorithm>
#include <random>
#include <vector>
#include <bitset>

using namespace std;
const int NMAX = 10002;

ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");

bitset <NMAX> f;
vector <vector <int>> vst;
int cuplaj_st[NMAX], cuplaj_dr[NMAX];

int pair_up(int start) {
    if(f[start]) ///am mai vizitat
        return 0;
    f[start] = 1;
    for(const int& x : vst[start]) {
        if(!cuplaj_dr[x]) { ///dc nu e cuplat, cuplam
            cuplaj_dr[x] = start;
            cuplaj_st[start] = x;
            return 1;
        }
    }
    ///dc n-am gasit niciun cuplaj
    for(const int& x : vst[start]) {
        if(cuplaj_dr[x] != start && ///pt noduri VIITOARE, ca sa gasim ALTA var
            pair_up(cuplaj_dr[x])) { ///adica dc merge sa schimbam, mai avem altceva
            cuplaj_dr[x] = start;
            cuplaj_st[start] = x;
            return 1;
        }
    }
    return 0; ///dc nu se poate in niciun caz
}
vector <int> ord;
int main() {
    int n, m, e;
    cin >> n >> m >> e;
    vst.resize(n + 1);
    for(int i = 1; i <= e; i++) {
        int a, b;
        cin >> a >> b;
        vst[a].push_back(b);
    }


    /*mt19937 g(23478321);
    for(int i = 1; i <= n; i++)
        ord.push_back(i);
    shuffle(ord.begin(), ord.end(), g);*/
    /*for(auto x : ord)
        cout << x << " ";
    cout << '\n';*/

    int ans = 0;
    while(1) {
        f = 0;
        int cnt = 0;
        for(int i = 1; i <= n; i++) {
            if(!cuplaj_st[i]) {
                int val = pair_up(i);
                cnt += val;
            }
        }
        ans += cnt;
        if(!cnt)
            break;
        //cout << cnt << '\n';
        //break;
    }
    cout << ans << '\n';
    for(int i = 1; i <= n; i++) {
        if(cuplaj_st[i])
            cout << i << " " << cuplaj_st[i] << '\n';
    }
    return 0;
}