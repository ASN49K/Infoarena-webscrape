#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

ifstream in("cuplaj.in");
ofstream out("cuplaj.out");
const int NMAX=1e4+2;

int seen[NMAX],r[NMAX],l[NMAX],n,m,nr;

vector<int>g[NMAX];

int pairup(int n){
    if(seen[n])
        return 0;
    seen[n]=1;
    for(int vec:g[n])
        if(!r[vec]){
            l[n]=vec;
            r[vec]=n;
            return 1;
    }

    for(int vec:g[n])
        if(pairup(r[vec])){
            l[n]=vec;
            r[vec]=n;
            return 1;
    }
    return 0;
}

int main() {
    in>>n>>m>>nr;
    for(int i=0,a,b;i<nr;i++){
        in>>a>>b;
        g[a].push_back(b);
    }

    for(int change = 1;change;){
        change=0;
        memset(seen,0,sizeof(seen));
        for(int i=1;i<=n;i++)
            if(!l[i])
                change |= pairup(i);
    }

    int cuplaj =0;
    for(int i=1;i<=n;i++)
        cuplaj += (l[i]>0);
    out<<cuplaj<<"\n";
    for(int i=1;i<=n;i++)
        if(l[i])
            out<<i<<" "<<l[i]<<"\n";
    return 0;
}
