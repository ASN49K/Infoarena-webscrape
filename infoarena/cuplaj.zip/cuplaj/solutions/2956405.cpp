#include <cstring>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
ifstream f("cuplaj.in");
ofstream o("cuplaj.out");
long long int n1, n2, m;
long long int raspuns[10000];
bool bpm(bool bpGraph[1000][1000], long long int u,
         bool seen[], long long int matchR[]) {
    // Try every job one by one
    for (long long int v = 0; v < n2; v++) {
        // If applicant u is interested in
        // job v and v is not visited
        if (bpGraph[u][v] && !seen[v]) {
            // Mark v as visited
            seen[v] = true;

            // If job 'v' is not assigned to an
            // applicant OR previously assigned
            // applicant for job v (which is matchR[v])
            // has an alternate job available.
            // Since v is marked as visited in
            // the above line, matchR[v] in the following
            // recursive call will not get job 'v' again
            if (matchR[v] < 0 || bpm(bpGraph, matchR[v],
                                     seen, matchR)) {
                matchR[v] = u;
                cout<<u+1<<" "<<v+1<<"\n";
                raspuns[u+1]=v+1;
                return true;
            }
        }
    }
    return false;
}
long long int maxBPM(bool bpGraph[1000][1000]) {
    long long int matchR[n2];
    memset(matchR, -1, sizeof(matchR));
    long long int result = 0;
    for (long long int u = 0; u < n1; u++) {
        // Mark all jobs as not seen
        // for next applicant.
        bool seen[n2];
        memset(seen, 0, sizeof(seen));

        // Find if the applicant 'u' can get a job
        if (bpm(bpGraph, u, seen, matchR))
            result++;
    }
    return result;
}
int main() {

    f >> n1 >> n2 >> m;
    bool bpGraph[1000][1000];
    memset(bpGraph, false, sizeof(bpGraph));
    for (long long int i = 1; i <= m; i++) {
        long long int nod1, nod2;
        f >> nod1 >> nod2;
        bpGraph[nod1 - 1][nod2 - 1] = true;
    }
//    for (long long int i = 1; i <= n1; i++) {
//        for (long long int j = 1; j <= n2; j++)
//            cout << bpGraph[i - 1][j - 1] << " ";
//        cout << endl;
//    }
    o << maxBPM(bpGraph)<<"\n";
    for(long long int i=1;i<10000;i++)
        if(raspuns[i])
            o<<i<<" "<<raspuns[i]<<"\n";

    return 0;
}
