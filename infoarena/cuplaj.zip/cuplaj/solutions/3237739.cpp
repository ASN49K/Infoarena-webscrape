#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <set>
#include <bitset>
#include <fstream>

#define ll long long
#define f first
#define s second
#define eb emplace_back
#define pb push_back

using namespace std;

bitset<10000> b1;
bitset<10000> b3;
vector<int> b2[10000];
int g[10000]; // :3

bool connect(int i) {
    if (b1[i]) return false;
    b1[i] = true;

    for (int j : b2[i]) if (!g[j]) {
        g[j] = i + 1;
        return true;
    }

    for (int j : b2[i]) if (connect(g[j] - 1)) {
        g[j] = i + 1;
        return true;
    }

    return false;
}

int main() {
    ifstream cin("cuplaj.in");
    ofstream cout("cuplaj.out");

    int n, m, k; cin >> n >> m >> k;
    for (int i = 0; i < k; i++) {
        int a, b; cin >> a >> b; a--, b--;
        b2[a].pb(b);
    }

    int d = 0;
    bool any = true;
    while (any) {
        any = false;
        for (int i = 0; i < n; i++) {
            if (b3[i]) continue;
            if (connect(i)) {
                b3[i] = true;
                any = true;
                d++;
            }
        }
        b1.reset();
    }

    cout << d << endl;
    for (int i = 0; i < m; i++) {
        if (g[i]) {
            cout << g[i] << ' ' << i + 1 << endl;
        }
    }
}
