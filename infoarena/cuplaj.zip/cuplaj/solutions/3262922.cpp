#include <bits/stdc++.h>

using namespace std;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

const int NMAX = 1e3;
int n, m;
vector<int> G[NMAX + 1];
int flux[NMAX + 1][NMAX + 1];
int capacitate[NMAX + 1][NMAX + 1];
int vis[NMAX + 1], p[NMAX + 1];

int bfs(int s, int d) {
    for(int i = 0; i <= n; i++) {
        p[i] = -1;
        vis[i] = 0;
    }
    queue<int> q;
    q.push(s);
    vis[s] = 1;
    while(!q.empty()) {
        int node = q.front();
        q.pop();
        for(auto vecin : G[node]) {
            if(!vis[vecin]) {
                if(capacitate[node][vecin] - flux[node][vecin] > 0) {
                    q.push(vecin);
                    vis[vecin] = 1;
                    p[vecin] = node;
                }
            }
        }
    }
    if(!vis[d]) {
        return 0;
    }
    vector<int> path;
    int x = d;
    while(x != -1) {
        path.push_back(x);
        x = p[x];
    }
    reverse(path.begin(), path.end());
    int flow = 1e9;
    for(int i = 0; i < path.size() - 1; i++) {
        int x = path[i];
        int y = path[i + 1];
        flow = min(flow, capacitate[x][y] - flux[x][y]);
    }
    for(int i = 0; i < path.size() - 1; i++) {
        int x = path[i];
        int y = path[i + 1];
        flux[x][y] += flow;
        flux[y][x] -= flow;
    }
    return flow;

}


int main() {
    int a, b, m;
    f >> a >> b >> m;
    for(int i = 1; i <= m; i++) {
        int x, y;
        f >> x >> y;
        //(x, a + y)
        capacitate[x][a + y] = 1;
        G[x].push_back(a + y);
        G[a + y].push_back(x);
        //(0, x)
        //0 o sa fie sursa
        capacitate[0][x] = 1;
        G[0].push_back(x);
        G[x].push_back(0);
        //(a + y, a + b + 1)
        //a + b + 1 o sa fie destinatie
        capacitate[a + y][a + b + 1] = 1;
        G[a + y].push_back(a + b + 1);
        G[a + b + 1].push_back(a + y);
    }

    n = a + b + 1;
    //cout << bfs(0, a + b + 1);
    int maxFlow = 0;
    while(1) {
        int flow = bfs(0, a + b + 1);
        if(flow == 0) {
            break;
        }
        maxFlow += flow;
    }
    g << maxFlow << '\n';
    for(int i = 1; i <= a; i++) {
        for(int j = 1; j <= b; j++) {
            if(flux[i][a + j] == 1) {
                g << i << ' ' << j << '\n';
            }
        }
    }
    return 0;
}
