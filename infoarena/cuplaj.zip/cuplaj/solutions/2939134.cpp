#include <bits/stdc++.h>
#define cin fin
#define cout fout
using namespace std;
ifstream cin ("cuplaj.in");
ofstream cout ("cuplaj.out");
int n,m,nods,i,j,change,cnt,a,b;
int l[10008], r[10008], u[10008];
vector<int>G[10008];
int pairup(int n)
{
    if (u[n])  return 0;
    u[n]=1;
    for(auto i:G[n])
    {
        if(r[i]==0)
        {
            r[i]=n;
            l[n]=i;
            return 1;
        }
    }
    for(auto i:G[n])
    {
        if(pairup(r[i]))
        {
            r[i]=n;
            l[n]=i;
            return 1;
        }
    }
    return 0;
}
int main()
{
    cin>>n>>m>>nods;
    for(i=1;i<=nods;i++)
    {
        cin>>a>>b;
        G[a].push_back(b);
    }
    change=1;
    while(change)
    {
        change=0;
        memset(u, 0, max(n,m)+1);
        for(i=1;i<=n;i++)
        {
            if(l[i]==0)
            {
                change=max(change,pairup(i));
            }
        }
    }
    for(i=1;i<=n;i++)
    {
        if(l[i]>0)
            cnt++;
    }
    cout<<cnt<<'\n';
    for(i=1;i<=n;i++)
        if(l[i]>0)
            cout<<i<<" "<<l[i]<<'\n';
    return 0;
}
