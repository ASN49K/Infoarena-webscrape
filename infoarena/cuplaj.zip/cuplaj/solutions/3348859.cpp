#include <fstream>
#include <cstring>
#include <vector>
#define nmax 10001
using namespace std;
ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");
int n,m,e,x,y,l[nmax],r[nmax],ans;
bool viz[nmax];
vector<int>v[nmax];
bool cuplaj(int nod){
    if(viz[nod])
        return 0;
    viz[nod]=1;
    for(auto i:v[nod])
        if(r[i]==0){
            l[nod]=i;
            r[i]=nod;
            return 1;
        }
    /// incerc sa recuplez
    for(auto i:v[nod])
        if(cuplaj(r[i])){
            l[nod]=i;
            r[i]=nod;
            return 1;
        }
    return 0;
}
int main()
{
    cin>>n>>m>>e;
    for(int i=1;i<=e;i++){
        cin>>x>>y;
        v[x].push_back(y);
    }
    bool ok=1;
    while(ok){
        ok=0;
        memset(viz,0,sizeof(viz));
        for(int i=1;i<=n;i++)
            if(l[i]==0)
                ok=(cuplaj(i)|ok);
    }
    for(int i=1;i<=n;i++)
        if(l[i]!=0)
            ans++;
    cout<<ans<<'\n';
    for(int i=1;i<=n;i++)
        if(l[i]!=0)
            cout<<i<<" "<<l[i]<<'\n';
    return 0;
}
