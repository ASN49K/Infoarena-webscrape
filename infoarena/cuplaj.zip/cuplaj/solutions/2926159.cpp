#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair
#define dbg(x) cout << #x <<": " << x << "\n";
#define sz(x) ((int)x.size())

using ll = long long;

const string fn = "cuplaj";
ifstream fin(fn + ".in");
ofstream fout(fn + ".out");

const int mxn = 10005;

int n, m, e;
bitset<10005> viz;
vector<int> g[mxn];
int st[mxn], dr[mxn];


bool comb(int nod){

    if(viz[nod]) return false;
    viz[nod] = true;

    for(int i : g[nod]){
        if(!dr[i]){
            st[nod] = i;
            dr[i] = nod;
            return true;
        }
    }
    for(int i : g[nod])
        if(comb(dr[i])){
            st[nod] = i;
            dr[i] = nod;
            return true;
        }
    return false;
}


int main() {

	ios_base::sync_with_stdio(false);
	cin.tie();

	int ans = 0;

    fin >> n >> m >> e;
    for(int i = 1; i <= e; ++i){
        int x, y;
        fin >> x >> y;
        g[x].pb(y);
    }

    bool gata = false;
    while(!gata){
        gata = true;
        viz.reset();
        for(int i = 1; i <= n; ++i)
            if(st[i] == 0 && comb(i)){
                ++ans;
                gata = false;
        }

    }

    fout << ans << '\n';
    for(int i = 1; i <= n; ++i)
        if(st[i])
            fout << i << " " << st[i] << '\n';



	return 0;
}
