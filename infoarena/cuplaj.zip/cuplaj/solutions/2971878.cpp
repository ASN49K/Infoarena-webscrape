#include <fstream>
#include <vector>

#define NMAX 10005

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int le, r, m;
int x, y;
vector<int> l[NMAX];
int p[NMAX]; bool f[NMAX];
bool cuplat[NMAX];
int counter;
bool ok = 1;
int i;

bool dfs(int);

int main()
{
    fin >>le>>r>>m;
    for (i = 1; i <= m; ++i)
    {
        fin >>x>>y;
        l[x].push_back(y);
    }

    while (ok)
    {
        ok = 0;
        for (i = 1; i <= le; ++i) f[i] = 0;
        for (i = 1; i <= le; ++i)
            if (!cuplat[i] && dfs(i))
                counter ++, ok = 1;
    }

    fout <<counter<<'\n';
    for (i = 1; i <= r; ++i)
        if (p[i])
            fout <<p[i]<<' '<<i<<'\n';
    fout.close();
    return 0;
}

bool dfs(int vf)
{
    int i; int vfnou;
    f[vf] = 1;
    for (i = 0; i < l[vf].size(); ++i)
    {
        vfnou = l[vf][i];
        if (!p[vfnou] || (!f[p[vfnou]] && dfs(p[vfnou])))
        {
            p[vfnou] = vf;
            cuplat[vf] = 1;
            return 1;
        }
    }

    return 0;
}
