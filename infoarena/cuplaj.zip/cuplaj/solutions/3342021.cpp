#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int n,m,e,x,y,cnt;


pair<int,int> nrNoduri[10001];
vector<int> v[10001];
bool vizitat[10001];

vector<pair<int,int>> muchii;

int main()
{
    fin>>n>>m>>e;
    if(n>m)
    {
        for(int i=1; i<=e; i++)
        {
            fin>>x>>y;
            nrNoduri[x].first++;
            nrNoduri[x].second=x;
            v[x].push_back(y);
        }
    }
    else
    {
        for(int i=1; i<=e; i++)
        {
            fin>>x>>y;
            nrNoduri[y].first++;
            nrNoduri[y].second=x;
            v[y].push_back(x);
        }
    }
    sort(nrNoduri+1,nrNoduri+n+1);

    for(int i=1; i<=n; i++)
    {
        //fout<<nrNoduri[i].first<<" "<<nrNoduri[i].second<<'\n';
        if(nrNoduri[i].first)
        {
            for(auto u:v[nrNoduri[i].second])
            {
                if(!vizitat[u])
                {
                    vizitat[u]=1;
                    muchii.push_back({nrNoduri[i].second,u});
                    break;
                }
            }
        }
    }
    fout<<muchii.size()<<'\n';
    for(auto u:muchii)
    {
        fout<<u.first<<" "<<u.second<<'\n';
    }
    return 0;
}
