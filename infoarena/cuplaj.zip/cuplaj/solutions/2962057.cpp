#include <iostream>
#include <fstream>
#include <cstdio>
#include <vector>
#include <queue>

using namespace std;

class Flow {
  struct Edge {
    int from, to;
    int cf;

    Edge(int from = 0, int to = 0, int cf = 0) : from(from), to(to), cf(cf) {}
  };

  int n, offset;
  int source, destination;
  // adjList[i] = indicii muchiilor care pornesc din nodul i
  vector<vector<int>> adjList;
  vector<Edge> edges;
  // dad[i] = indicele muchiei parinte din arborele BFS
  vector<int> dad;

  // adauga flux in drumul de ameliorare care se termina in nodul dat ca parametru si intoarce valoarea fluxului adaugat
  int addFlow(int node) {
    int canAdd = -1; // fluxul maxim pe care il pot adauga pe drumul de ameliorare curent
    int crt = node;
    while(crt != source) {
      if(canAdd == -1 || edges[dad[crt]].cf < canAdd)
        canAdd = edges[dad[crt]].cf;
      crt = edges[dad[crt]].from;
    }

    // parcurg din nou drumul de ameliorare ca sa adaug noul flux
    crt = node;
    while(crt != source) {
      edges[dad[crt]].cf -= canAdd;
      edges[dad[crt] ^ 1].cf += canAdd;
      crt = edges[dad[crt]].from;
    }

    return canAdd;
  }

  // creeaza arborele BFS prin vectorul de tati si intoarce daca a gasit macar un drum de ameliorare sau nu
  bool bfs() {
    bool reachedDestination = false; // daca am ajuns la destinatie printr-un drum de ameliorare
    queue<int> q;
    q.push(source);
    for(int i = 1; i <= n; i++)
      dad[i] = -1;

    while(!q.empty()) {
      int node = q.front();
      q.pop();

      for(int edgeIdx: adjList[node]) {
        int ngh = edges[edgeIdx].to;
        // caut muchii in care mai pot adauga flux si care ajung in noduri nevizitate
        if(ngh == source || dad[ngh] != -1 || edges[edgeIdx].cf == 0)
          continue;
        // daca am ajuns la destinatie nu memorez nodul din care am ajuns pentru ca pot avea mai multe drumuri
        if(ngh == destination) {
          reachedDestination = true;
          return true;
        }

        dad[ngh] = edgeIdx;
        q.push(ngh);
      }
    }

    return reachedDestination;
  }

public:
  void init(int n, int offset, int source = 1, int destination = -1) {
    this->n = n;
    this->source = source;
    this->destination = destination == -1 ? n : destination;
    this->offset = offset;
    adjList.resize(n + 1);
    dad.resize(n + 1);
  }

  // adauga muchia (from, to) in retea; indicele muchiei va fi pe o pozitie para, iar muchia inversa va fi pe urmatoarea pozitie
  void addEdge(int from, int to, int capacity) {
    edges.push_back(Edge(from, to, capacity));
    adjList[from].push_back(edges.size() - 1);
    // adaug si muchia inversa de capacitate 0
    edges.push_back(Edge(to, from, 0));
    adjList[to].push_back(edges.size() - 1);
  }

  // intoarce fluxul maxim din retea
  int maxFlow() {
    int maxFlow = 0;

    // cat timp exista drumuri de ameliorare mai putem adauga flux
    while(bfs())
      for(int edgeIdx: adjList[destination]) {
        int node = edges[edgeIdx].to;

        // conectam pe rand nodul destinatie la toate nodurile din care se poate ajunge in acesta si care sunt capatul unui drum de ameliorare
        if((node == source || dad[node] != -1) && edges[edgeIdx ^ 1].cf > 0) {
          dad[destination] = edgeIdx ^ 1;
          maxFlow += addFlow(destination);
        }
      }

    return maxFlow;
  }

  void printEdges(ofstream &fout) {
    for(int i = 0; i < edges.size(); i += 2)
      if(edges[i].to <= n - 2 && edges[i].from <= n - 2 && edges[i].cf == 0)
        fout << edges[i].from << " " << edges[i].to - offset << endl;
  }
};

void read(Flow &flow) {
  ifstream fin("cuplaj.in");
  int n, m, e;

  fin >> n >> m >> e;
  // nodurile din dreapta vor avea indicii n + 1, ..., n + m, sursa va fi n + m + 1, iar destinatia n + m + 2
  int source = n + m + 1, destination = n + m + 2;
  flow.init(n + m + 2, n, source, destination);

  int a, b;
  for(int i = 1; i <= e; i++) {
    fin >> a >> b;
    flow.addEdge(a, b + n, 1);
  }
  // adaug muchii de la sursa la toate nodurile din stanga
  for(int i = 1; i <= n; i++)
    flow.addEdge(source, i, 1);
  // adaug muchii de la toate nodurile din dreapta la destinatie
  for(int i = n + 1; i <= n + m; i++)
    flow.addEdge(i, destination, 1);
  // muchiile adaugate trebuie sa aiba capacitate 1 ca sa ne asiguram ca nu exista mai mult de muchie adiacenta cu fiecare nod
}

int main() {
  ofstream fout("cuplaj.out");

  Flow flow;
  read(flow);
  int maxFlow = flow.maxFlow();
  fout << maxFlow << endl;
  flow.printEdges(fout);

  return 0;
}
