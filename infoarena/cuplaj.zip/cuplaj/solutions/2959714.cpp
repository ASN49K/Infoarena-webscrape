#include<iostream>
#include<fstream>
#include<vector>
#include<queue>
#include<cstring>
#include<climits>
using namespace std;

int n,m;
int s,t;
int *parinti;

struct muchie{
    int nodDest;
    int capacitate;
    int flux;
    int revers;
    
    muchie(int dest, int cap, int fl, int revers1)
    : nodDest(dest), capacitate(cap), flux(fl), revers(revers1){};
};

bool bfs(int vizitate[], vector<muchie> muchii[]){
    memset(vizitate, 0, sizeof(int)*(n+m+2));

    queue<int> q;
    
    for(muchie& m : muchii[s])
        if(m.flux != m.capacitate){
            vizitate[m.nodDest] = true;
            q.push(m.nodDest);
        }
    
    while(!q.empty()){
        int nod = q.front(); q.pop();
        if(nod==t)
            return true;
        for(muchie& m : muchii[nod]){
            if(!vizitate[m.nodDest] && m.flux < m.capacitate){
                vizitate[m.nodDest] = true;
                q.push(m.nodDest);
            }
        }
    }
    
    return false;
}

int trimite(int start, int flux, int vizitate[], vector<muchie> muchii[]){
    if(start==t)
        return flux;
        
    vizitate[start]=1;
    
    for(muchie& m : muchii[start]){
        if(!vizitate[m.nodDest] && m.flux < m.capacitate){
            int fluxC;
            if(flux < m.capacitate - m.flux)
                fluxC = flux;
            else
                fluxC = m.capacitate - m.flux;
            
            int fluxT = trimite(m.nodDest, fluxC, vizitate, muchii);
            if(fluxT > 0){
                parinti[m.nodDest] = start;
                m.flux += fluxT;
                if(m.revers!=-1){
                    muchii[m.nodDest][m.revers].flux -= fluxT;
                }
                return fluxT;
            }
        }
    }
    
    return 0;
}

int main(){
    ifstream fin("cuplaj.in");
    ofstream fout("cuplaj.out");
    int e;
    fin>>n>>m>>e;
    
    s=0, t=n+m+1;
    
    vector<muchie> muchii[n+m+2];
    int x,y;
    for(int i=0;i<e;i++){
        fin>>x>>y;
        y+=n;
        int lastPozX = muchii[x].size();
        int lastPozY = muchii[y].size();
        muchii[x].push_back(muchie(y,1,0,lastPozY));
        muchii[y].push_back(muchie(x,0,0,lastPozX));
    }
    
    for(int i=1;i<=n;i++){
        muchii[s].push_back(muchie(i,1,0,-1));
    }
    
    for(int i=n+1;i<=n+m;i++){
        muchii[i].push_back(muchie(t, 1, 0, -1));
    }
    
    
    int vizitate[n+m+2];
    int vizitate2[n+m+2];
    parinti=new int[n+m+2];
    memset(parinti, 0, sizeof(int)*(n+m+2));
    while(bfs(vizitate, muchii)){
        memset(vizitate2, 0, sizeof(int)*(n+m+2));
        while(trimite(s, INT_MAX, vizitate2, muchii));
    }
    
    vector<pair<int,int>> cuplaje;
    for(int i=n+1;i<=n+m;i++)
        if(parinti[i]!=0)
            cuplaje.push_back({parinti[i], i-n});
    fout<<cuplaje.size()<<"\n";
    for(pair<int, int>& p : cuplaje)
        fout<<p.first<<" "<<p.second<<"\n";

    return 0;
}
