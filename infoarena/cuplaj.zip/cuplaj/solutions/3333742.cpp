#include <bits/stdc++.h>
using namespace std;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

const int inf = 1e9;
int n, m, e, x, y, total_flow;
int S, D;
int level[20005], ptr[20005];

struct Edge {
    int to, cap, flow, rev;
};

vector <Edge> v[20005];
queue <int> q;

void add_edge(int from, int to, int cap) {
    Edge a = {to, cap, 0, (int)v[to].size()};
    Edge b = {from, 0, 0, (int)v[from].size()}; 
    v[to].push_back(b);
}

bool bfs() {
    while (!q.empty()) q.pop();
    
    for (int i = 0; i <= D; ++i) level[i] = -1;
    
    level[S] = 0;
    q.push(S);
    
    while (!q.empty()) {
        int nod_curent = q.front();
        q.pop();
        
        for (auto &edge : v[nod_curent]) {
            if (edge.cap - edge.flow > 0 && level[edge.to] == -1) {
                level[edge.to] = level[nod_curent] + 1;
                q.push(edge.to);
            }
        }
    }
    return level[D] != -1;
}

int dfs(int nod, int pushed) {
    if (pushed == 0 || nod == D) return pushed;
    
    for (int &cid = ptr[nod]; cid < v[nod].size(); ++cid) {
        auto &edge = v[nod][cid];
        
        if (level[nod] + 1 != level[edge.to] || edge.cap - edge.flow == 0) continue;
        
        int tr = dfs(edge.to, min(pushed, edge.cap - edge.flow));
        if (tr == 0) continue;
        
        edge.flow += tr;
        v[edge.to][edge.rev].flow -= tr;
        
        return tr;
    }
    return 0;
}

void dinic() {
    while (bfs()) {
        for (int i = 0; i <= D; ++i) ptr[i] = 0;
        
        while (int pushed = dfs(S, inf)) {
            total_flow += pushed;
        }
    }
}

int main()
{
    f >> n >> m >> e;
    
    S = 0;
    D = n + m + 1;
    
    for (int i = 1; i <= n; ++i) {
        add_edge(S, i, 1);
    }
    
    for (int i = 1; i <= m; ++i) {
        add_edge(n + i, D, 1);
    }
    
    for (int i = 1; i <= e; ++i) {
        f >> x >> y;
        add_edge(x, n + y, 1); 
    }
    
    dinic();
    
    g << total_flow << '\n';
    
 
    for (int i = 1; i <= n; ++i) {
        for (auto &edge : v[i]) {
            if (edge.to > n && edge.to != D && edge.flow == 1) {
                g << i << ' ' << edge.to - n << '\n';
                break; 
            }
        }
    }
    
    return 0;
}