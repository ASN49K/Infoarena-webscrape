﻿#include <bits/stdc++.h>
#include <unordered_map>
#include <map>

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
//-----------------------------------------
#define ll long long
#define pii pair<int, int>
#define pll pair<long long, long long>
#define vi vector<int>
#define vll vector<long long>
#define mii map<int, int>
#define si set<int>
#define sc set<char>
//-----------------------------------------
#define f(i,s,e) for(int i=s;i<=e;++i)
#define nf(i,s,e) for(i=s;i<e;++i)
#define rf(i,e,s) for(i=e;i>=s;--i)
#define pb push_back
#define eb emplace_back
#define fi first
#define se second
#define sp <<" "
//------------------------------------------
const int NMAX = 6e1 + 20;
const int KMAX = 1e1 + 5;
const int MOD = 1e6 + 3;
const int INF = 0x3f3f3f3f;
//------------------------------------------
int n, m, k,ct, A[NMAX], B[NMAX];
vector <int> g[NMAX];
bitset <NMAX> V;
//------------------------------------------
void read() {
    fin >> n >> m >> k;
    for (int i = 1; i <= k; ++i) {
        int x, y;
        fin >> x >> y;
        g[x].pb(y);
    }
}
int connect(int v) {
    if (V[v])
        return 0;
    V[v] = 1;
    for (auto x : g[v])
        if (!B[x])
        {
            A[v] = x;
            B[x] = v;
            return 1;
        }
    for (auto x : g[v])
        if (connect(B[x])) {
            A[v] = x;
            B[x] = v;
            return 1;
        }
    return 0;
}
void solve() {
    bool ok = false;
    while (!ok) {
        ok = true;
        V.reset();
        for(int i=1;i<=n;++i)
            if (!A[i] && connect(i)) {
                ct++;
                ok = false;
            }
    }
    fout << ct << "\n";
    for (int i = 1; i <= n; ++i)
        if (A[i])
            fout << i << " " << A[i] << "\n";
}
int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0); cout.tie(0);
    read();
    solve();
    return 0;
}