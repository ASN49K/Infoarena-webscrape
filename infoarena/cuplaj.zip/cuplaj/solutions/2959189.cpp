#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <bits/stdc++.h>
#include <fstream>
using namespace std;
using namespace std::chrono;
//ifstream in("maxflow.in");
//ofstream out("maxflow.out");
ifstream in("cuplaj.in");
ofstream out("cuplaj.out");
struct edge{
    int n1, n2, cap, pos;
};
vector<vector<int>> adjList;
vector<edge> edges;
vector<bool> visited;
vector<int> parent;
int n,m,e, nrN;
int source,dest;
void read(){
    in >> n >> m >> e;
    nrN = n + m + 2;
    source = 0;
    dest = nrN -1;
    adjList.resize(nrN);
    int x, y;
    for(int i = 0; i < e; ++i)
    {
        in >> x >> y;
        int s = (int)edges.size();
        adjList[x].emplace_back(s);
        adjList[y].emplace_back(s+1);
        edges.push_back({x, y+n, 1, s + 1});
        edges.push_back({y + n, x, 0 ,s});
    }
    for(int i = 1; i <= n; ++i)
    {

        int s = (int)edges.size();
        adjList[0].emplace_back(s);
        adjList[i].emplace_back(s + 1);
        edges.push_back({0, i, 1, s+1});
        edges.push_back({i,0,0,s});

    }
    for(int i = 1; i <= m; ++i)
    {

        int s = (int)edges.size();
        adjList[i + n].emplace_back(s);
        adjList[n + m + 1].emplace_back(s+1);
        edges.push_back({i+n, n+m+1, 1, s+1});
        edges.push_back({n+m+1, i+n, 0 ,s});
    }
}

bool BFS(int source, int dest)
{

    parent.clear();
    parent.resize(nrN);
    visited.clear();
    visited.resize(nrN, false);

    visited[source] = true;
    queue<int> q;
    q.push(source);
    while(!q.empty()) {

        int pNode = q.front(); //nodul parinte
        q.pop();
        if(pNode != dest)
            // el e pozitia din lista de muchii a nodului parinte
            for (int el: adjList[pNode])
            {
                edge cEdge = edges[el];
                if(!visited[cEdge.n2] && cEdge.cap != 0)
                {
                    parent[cEdge.n2] = el;
                    //adaugam urmatorul nod ce urmeaza sa fie vizitat
                    q.push(cEdge.n2);
                    visited[cEdge.n2] = true;
                }
            }
    }
    return visited[dest];
}


int FordFulkerson(int source, int dest)
{
    int mxFlow = 0;


    while(BFS(source, dest)) {
        for (int el: adjList[dest]) {
            if (visited[edges[el].n2] && edges[edges[el].pos].cap != 0) {
                int mnCap = INT_MAX;
                edge cEdge = edges[el];
                parent[dest] = cEdge.pos;
                int cNode = dest;
                while (cNode != source) {

                    mnCap = min(mnCap, edges[parent[cNode]].cap);
                    cNode = edges[parent[cNode]].n1;
                }
                cNode = dest;
                while (cNode != source){
                    edges[edges[parent[cNode]].pos].cap += mnCap;
                    edges[parent[cNode]].cap -= mnCap;
                    cNode = edges[parent[cNode]].n1;
                }
                mxFlow += mnCap;
            }
        }
    }
    return mxFlow;
}

int main() {



    auto start = high_resolution_clock::now();

    read();

    out << FordFulkerson(0, n + m + 1) << endl;

    for(auto edge:edges){
        if(edge.n1 < edge.n2 && edge.n1 != 0 && edge.n2!= dest && edge.cap==0)
            out<<edge.n1<<" "<<edge.n2 - n<<endl;
    }
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
    cout << "Durata: " << duration.count();
    return 0;
}