#include <bits/stdc++.h>
using namespace std;
///ex1-a infoarena maxflow
//ifstream fin("maxflow.in");
//ofstream fout("maxflow.out");
//vector<vector<int>> lista, flux;
//vector<int> viz, tata;
//int n, m;
//bool BFS()
//{
//    int s = 1;
//    int d = n;
//    for(int i = 1; i <= n; i++)
//    {
//        viz[i] = 0;
//        tata[i] = 0;
//    }
//    queue<int> coada;
//    coada.push(s);
//    viz[s] = 1;
//    while(!coada.empty())
//    {
//        int nod = coada.front();
//        coada.pop();
//        for(int& vecin : lista[nod])
//        {
//            if(!viz[vecin] && flux[nod][vecin] > 0)
//            {
//                viz[vecin] = 1;
//                tata[vecin] = nod;
//                coada.push(vecin);
//                if(vecin == d)
//                    return true;
//            }
//        }
//    }
//    return false;
//}
//int minFlow(){
//    int nod = n;
//    int minflux = INT_MAX;
//    while(nod != 1)
//    {
//        minflux = min(minflux, flux[tata[nod]][nod]);
//        nod = tata[nod];
//    }
//    return minflux;
//}
//void ex1a(){
//    fin >> n >> m;
//    lista.resize(n + 1);
//    flux.resize(n + 1, vector<int>(n + 1, 0));
//    viz.resize(n + 1);
//    tata.resize(n + 1);
//    for(int i = 0; i < m; i++)
//    {
//        int x, y, c;
//        fin >> x >> y >> c;
//        lista[x].push_back(y);
//        lista[y].push_back(x);
//        flux[x][y] = c;
//    }
//    int maxflow = 0;
//    while(BFS())
//    {
//        int minflux = minFlow();
//        int nod = n;
//        while(nod != 1)
//        {
//            flux[tata[nod]][nod] -= minflux;
//            flux[nod][tata[nod]] += minflux;
//            nod = tata[nod];
//        }
//        maxflow += minflux;
//    }
//    fout << maxflow;
//}
//void DFS(int nod)
//{
//    viz[nod] = 1;
//    for(int& vecin : lista[nod])
//    {
//        if(!viz[vecin] && flux[nod][vecin] != 0)
//            DFS(vecin);
//    }
//}
//
/////ex1-b taietura minima
//void ex1b(){
//    fin >> n >> m;
//    lista.resize(n + 1);
//    flux.resize(n + 1, vector<int>(n + 1, 0));
//    viz.resize(n + 1);
//    tata.resize(n + 1);
//    for(int i = 0; i < m; i++)
//    {
//        int x, y, c;
//        fin >> x >> y >> c;
//        lista[x].push_back(y);
//        lista[y].push_back(x);
//        flux[x][y] = c;
//    }
//    while(BFS())
//    {
//        int minflux = minFlow();
//        int nod = n;
//        while(nod != 1)
//        {
//            flux[tata[nod]][nod] -= minflux;
//            flux[nod][tata[nod]] += minflux;
//            nod = tata[nod];
//        }
//    }
//    for(int i = 1; i <= n; i++) viz[i] = 0;
//    DFS(1);
//    for(int i = 1; i <= n; i++)
//    {
//        for(int& vecin : lista[i])
//        {
//            if(viz[i] && !viz[vecin])
//                fout << i << " " << vecin << "\n";
//        }
//    }
//}

///ex2-a infoarena cuplaj
struct Edge{
    int y, capacity;
};
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
vector<vector<Edge>> lista;
vector<int> viz, tata;
int n1, n2, m, t;
bool BFS()
{
    int s = 1;
    for(int i = 1; i <= t; i++)
    {
        viz[i] = 0;
        tata[i] = 0;
    }
    queue<int> coada;
    coada.push(s);
    viz[s] = 1;
    while(!coada.empty())
    {
        int nod = coada.front();
        coada.pop();
        for(Edge& edge : lista[nod])
        {
            if(!viz[edge.y] && edge.capacity > 0)
            {
                viz[edge.y] = 1;
                tata[edge.y] = nod;
                coada.push(edge.y);
                if(edge.y == t)
                    return true;
            }
        }
    }
    return false;
}
int findPosition(int x, int y){

    int st = 0;
    int dr = lista[x].size() - 1;
    int mij;
    while(st <= dr) {
        mij = (st + dr) / 2;
        if(lista[x][mij].y == y)
            return mij;
        else if(lista[x][mij].y < y)
            st = mij + 1;
        else if(lista[x][mij].y > y)
            dr = mij - 1;
    }

    return -1;
}
int minFlow(){
    int nod = t;
    int minflux = INT_MAX;
    while(nod != 1)
    {
        minflux = min(minflux, lista[tata[nod]][findPosition(tata[nod], nod)].capacity);
        nod = tata[nod];
    }
    return minflux;
}
void ex2(){
    fin>>n1>>n2>>m;
    t = n1 + n2 + 2;
    lista.resize(t + 1);
    viz.resize(t + 1);
    tata.resize(t + 1);
    for(int i = 0; i < m; i++)
    {
        int x, y;
        fin >> x >> y;
        lista[x + 1].push_back({y + n1 +1, 1});
        lista[y + n1 + 1].push_back({x + 1, 0});

    }
    for(int i = 2; i <= n1 + 1; i++)
    {
        lista[1].push_back({i, 1});
        lista[i].push_back({1, 0});
    }
    for(int i = n1 + 2; i <= n1 + n2 + 1; i++)
    {
        lista[i].push_back({t, 1});
        lista[t].push_back({i, 0});
    }
    for(int i = 1 ; i <= t; i++)
        sort(lista[i].begin(), lista[i].end(), [](Edge a, Edge b){return a.y < b.y;});
    int maxflow = 0;
    while(BFS())
    {
        int minflux = minFlow();
        int nod = t;
        while(nod != 1)
        {
            lista[tata[nod]][findPosition(tata[nod], nod)].capacity -= minflux;
            lista[nod][findPosition(nod,tata[nod])].capacity += minflux;
            nod = tata[nod];
        }
        maxflow += minflux;
    }
    fout << maxflow << "\n";
    for(int i = 2; i <= n1 + 1; i++)
    {
        for(Edge& edge : lista[i])
        {
            if(edge.capacity == 0 && edge.y != 1)
                fout << i - 1 << " " << edge.y - n1 - 1 << "\n";
        }
    }
}

int main() {
    ex2();
    return 0;
}
