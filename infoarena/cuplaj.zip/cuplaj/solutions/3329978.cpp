#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

const int NMAX = 1001;

vector<vector<int>> edgRezid;
vector<int> tata;
int rezid[NMAX][NMAX];
int n, m, e;

bool BFS(int s, int t){
    queue<int> q;
    vector<int> viz(n+m+2, 0);
    tata.resize(n+m+2, 0);
    q.push(s);
    while(!q.empty()){
        int u = q.front();
        q.pop();
        for(auto &v:edgRezid[u]){
            if(!viz[v] && rezid[u][v]> 0){
                viz[v] = 1;
                q.push(v);
                tata[v] = u;
                if(v == t)
                    return true;
            }
        }

    }
    return false;
}

int capRezid(vector<int> &tata, int s, int t){
    int mn = 200000;
    for(int v = t; v!=s; v = tata[v]){
        mn = min(mn, rezid[tata[v]][v]);

    }
    return mn;
}

void actualizareFlux(vector<int> &tata, int s, int t, int cr){
    for(int v = t; v!=s; v = tata[v]){

            rezid[tata[v]][v] -= cr;

            rezid[v][tata[v]] += cr;

    }
}

int main(){
    fin>>n>>m>>e;
    edgRezid.resize(n+m+2);
    //edgOut.resize(n+1);
    while(e--){
        int u, v, c;
        fin>>u>>v;
        edgRezid[u].push_back(v+n);
        edgRezid[v+n].push_back(u);
        rezid[u][v+n] = 1;
    }
    int sursa = 0;
    int target = n+m+1;
    for(int i=1; i<=n; ++i){
        edgRezid[sursa].push_back(i);
        rezid[sursa][i] = 1;
    }
    for(int i=n+1; i<=n+m; ++i){
        edgRezid[i].push_back(target);
        rezid[i][target] = 1;
    }
    int fluxmax = 0;
    while(BFS(sursa, target)){
        int cr = capRezid(tata, sursa, target);
        actualizareFlux(tata, sursa, target, cr);
        fluxmax += cr;
    }
    fout<<fluxmax<<"\n";
    for(int i=1; i<=n; ++i){
        for(int j=n+1; j<=n+m; ++j){
            if(rezid[j][i] == 1)
                fout<<i<<" "<<j-n<<"\n";
        }
    }
    return 0;
}
