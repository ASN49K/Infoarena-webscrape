#include <fstream>
#include <vector>
#include <cstdio>
#include <algorithm>

using namespace std;
ifstream cin ("cuplaj.in");
ofstream cout ("cuplaj.out");
int fre[100005];
int perst[100005];
int perdr[100005];
vector<int>adj[100005];
int findcouple(int curr)
{
    int i,k;
    if(fre[curr]!=0)
    {
        return 0;
    }
    fre[curr]=1;
    for(i=0;i<adj[curr].size();i++)
    {
        k=adj[curr][i];
        if(perdr[k]==0)
        {
            perst[curr]=k;
            perdr[k]=curr;
            return 1;
        }
    }
    for(i=0;i<adj[curr].size();i++)
    {
        k=adj[curr][i];
        if(findcouple(perdr[k])==1)
        {
            perst[curr]=k;
            perdr[k]=curr;
            return 1;
        }
    }
    return 0;
}
int main()
{
    int n,i,j,k,m,edges,x,y;
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>n>>m>>edges;
    for(i=1;i<=edges;i++)
    {
        cin>>x>>y;
        adj[x].push_back(y);
    }
    int schm=1;
    while(schm==1)
    {
        schm=0;
                    for(j=1;j<=n;j++)
            {
                fre[j]=0;
            }
        for(i=1;i<=n;i++)
        {
            if(perst[i]==0)
            {
                schm|=findcouple(i);
            }
        }
    }
    int cnt=0;
    for(i=1;i<=n;i++)
    {
       if(perst[i]!=0)
       {
           cnt++;
       }
    }
    cout<<cnt<<'\n';
    for(i=1;i<=n;i++)
    {
        if(perst[i]!=0)
        {
            cout<<i<<" "<<perst[i]<<'\n';
        }
    }
    return 0;
}
