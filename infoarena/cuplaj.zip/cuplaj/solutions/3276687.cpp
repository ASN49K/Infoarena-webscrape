#include <bits/stdc++.h>

#define DIM 100000

using namespace std;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

int n,m,e;
int x,y;
int c1[DIM+5],c2[DIM+5];

vector<int> v[DIM+5];

bool u[DIM+5];

bool cupleaza(int nod){

    if(u[nod]){
        return 0;
    }
    u[nod] = 1;

    //cout<<nod<<'\n';

    for(auto i:v[nod]){
        if(!c2[i]){
            c1[nod] = i;
            c2[i] = nod;
            //cout<<"!!!\n";
            return 1;
        }
    }

    for(auto i:v[nod]){
        if(cupleaza(c2[i])){
            c1[nod] = i;
            c2[i] = nod;

            return 1;
        }
    }

    return 0;

}

int main()
{
    f>>n>>m>>e;
    for(int i=1;i<=e;i++){
        f>>x>>y;
        v[x].push_back(y);
    }

    bool ok = 1;
    while(ok){

        ok = 0;

        //memset(u,0,DIM+1);
        for(int i=1;i<=n;i++){
            u[i] = 0;
        }

        for(int i=1;i<=n;i++){
            if(!c1[i]){
                 ok |= cupleaza(i);
            }
        }
    }

    /*for(int i=1;i<=n;i++){
        cout<<c1[i]<<" ";
    }
    cout<<'\n';
    for(int j=1;j<=m;j++){
        cout<<c2[j]<<" ";
    }*/

    int sol = 0;
    for(int i=1;i<=n;i++){
        if(c1[i]){
            sol++;
        }
    }

    g<<sol<<'\n';
    for(int i=1;i<=n;i++){
        if(!c1[i]){
            continue;
        }
        g<<i<<" "<<c1[i]<<'\n';
    }

    return 0;
}
