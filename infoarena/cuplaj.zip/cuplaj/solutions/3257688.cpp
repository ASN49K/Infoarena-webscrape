#include <iostream>
#include <vector>
#include <fstream>
#include <cstring>

using namespace std;

const int MAXN = 1005;

vector<int> adj[MAXN]; 
int matchR[MAXN], matchL[MAXN]; 
bool visited[MAXN]; 

bool dfs(int u) {
    for (int v : adj[u]) {
        if (!visited[v]) {
            visited[v] = true;
            if (matchR[v] == -1 || dfs(matchR[v])) {
                matchL[u] = v;
                matchR[v] = u;
                return true;
            }
        }
    }
    return false;
}

int main() {
    ifstream fin("cuplaj.in");
    ofstream fout("cuplaj.out");

    int N, M, E;
    fin >> N >> M >> E;

    for (int i = 0; i < E; i++) {
        int u, v;
        fin >> u >> v;
        adj[u].push_back(v);
    }

    memset(matchL, -1, sizeof(matchL));
    memset(matchR, -1, sizeof(matchR));

    int maxMatching = 0;

    for (int u = 1; u <= N; u++) {
        memset(visited, false, sizeof(visited));
        if (dfs(u)) {
            maxMatching++;
        }
    }

    fout << maxMatching << "\n";

    for (int u = 1; u <= N; u++) {
        if (matchL[u] != -1) {
            fout << u << " " << matchL[u] << "\n";
        }
    }

    return 0;
}

