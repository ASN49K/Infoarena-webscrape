#pragma GCC optimize("Ofast")
#pragma GCC target("sse4.2")
#include <bits/stdc++.h>

using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
const int Nmax=1e4+5;
vector<short int> v[Nmax];
short int pl[Nmax],pr[Nmax];
bitset<Nmax> viz;
bool augment(short int nod)
{
    for(short int u:v[nod])
    {
        if(!viz[u])
        {
            viz[u]=1;
            if(pr[u]==0)
            {
                pl[nod]=u;
                pr[u]=nod;
                return 1;
            }
        }
    }
    for(short int u:v[nod])
    {
        if(!viz[u])
        {
            viz[u]=1;
            if(augment(pr[u]))
            {
                pl[nod]=u;
                pr[u]=nod;
                return 1;
            }
        }
    }
    return 0;
}
int main()
{
    int n,m,e;
    fin>>n>>m>>e;
    for(int i=1;i<=e;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
    }
    bool ok=1;
    while(ok)
    {
        ok=0;
        viz.reset();
        for(short int i=1;i<=n;i++)
        {
            if(pl[i]==0)
            {
                if(augment(i))
                {
                    ok=1;
                }
            }
        }
    }
    int cnt=0;
    for(short int i=1;i<=n;i++)
    {
        if(pl[i]!=0)
        {
            cnt++;
        }
    }
    fout<<cnt<<'\n';
    for(short int i=1;i<=n;i++)
    {
        if(pl[i]!=0)
        {
            fout<<i<<' '<<pl[i]<<'\n';
        }
    }
    return 0;
}
