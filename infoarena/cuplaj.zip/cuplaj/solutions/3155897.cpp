#include <fstream>
#include <vector>
using namespace std;

ifstream cin ("cuplaj.in");
ofstream cout ("cuplaj.out");

vector <int> adiacenta[10001];
int pereche[2][10001];
bool vizitat[10001];

bool Cauta_Pereche (const int nod_actual)
{
    if (vizitat[nod_actual])
        return false;

    vizitat[nod_actual] = true;
    for (auto nod_vecin : adiacenta[nod_actual])
        if (!pereche[1][nod_vecin])
        {
            pereche[0][nod_actual] = nod_vecin;
            pereche[1][nod_vecin] = nod_actual;
            return true;
        }

    for (auto nod_vecin : adiacenta[nod_actual])
        if (pereche[1][nod_vecin] && Cauta_Pereche(pereche[1][nod_vecin]))
        {
            pereche[0][nod_actual] = nod_vecin;
            pereche[1][nod_vecin] = nod_actual;
            return true;
        }
    
    return false;
}

int main ()
{
    int numar_noduri[2] , numar_muchii;
    cin >> numar_noduri[0] >> numar_noduri[1] >> numar_muchii;

    for (int nod[2] ; numar_muchii ; numar_muchii--)
        { cin >> nod[0] >> nod[1]; adiacenta[nod[0]].push_back(nod[1]); }

    while (true)
    {
        bool gasit = false;
        for (int indice = 1 ; indice <= numar_noduri[0] ; indice++)
            if (!pereche[0][indice]) gasit |= Cauta_Pereche(indice);

        if (!gasit)
            break;

        for (int indice = 1 ; indice <= numar_noduri[0] ; indice++)
            vizitat[indice] = false;
    }

    int cuplaj = 0;
    for (int indice = 1 ; indice <= numar_noduri[0] ; indice++)
        cuplaj += (pereche[0][indice] != 0);

    cout << cuplaj << '\n';

    for (int indice = 1 ; cuplaj ; indice++)
        if (pereche[0][indice]) { cout << indice << ' ' << pereche[0][indice] << '\n'; cuplaj--; }

    cout.close(); cin.close();
    return 0;
}