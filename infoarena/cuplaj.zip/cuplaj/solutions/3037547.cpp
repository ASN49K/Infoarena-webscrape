#include<bits/stdc++.h>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int na,nb,m;
vector<int> con[2005];
int whoa[2005];///whoa[i] = cu cine este cuplat a[i]
int whob[2005];
bool used[2005];
bool cupleaza(int a)
{
    if(used[a])
        return 0;
    used[a]=1;
    for(auto adj:con[a])
    {
        if(whob[adj]==0)
        {
            whob[adj]=a;
            whoa[a]=adj;
            return 1;
        }
    }
    for(auto adj:con[a])
    {
        if(cupleaza(whob[adj]))
        {
            whoa[a]=adj;
            whob[adj]=a;
            return 1;
        }
    }
    return 0;
}
void cuplaj_maxim()
{
    int changed=1;
    while(changed)
    {
        changed=0;
        memset(used, 0, sizeof(used));
        for(int i=1;i<=na;i++)
            if(whoa[i]==0)
                changed+=cupleaza(i);
    }
    int cnt=0;
    for(int i=1;i<=na;i++)
        if(whoa[i]!=0)
            cnt++;
    fout<<cnt<<"\n";
    for(int i=1;i<=na;i++)
        if(whoa[i]!=0)
            fout<<i<<" "<<whoa[i]<<"\n";
}
signed main()
{
    int a,b;
    fin>>na>>nb>>m;
    for(int i=0;i<m;i++)
    {
        fin>>a>>b;
        con[a].push_back(b);
    }
    cuplaj_maxim();
    return 0;
}
