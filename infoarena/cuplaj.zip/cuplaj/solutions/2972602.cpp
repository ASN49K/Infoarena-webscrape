#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#define ll long long
#define mod 1000000007
using namespace std;
ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");
int n, m, e, a, b, mt[10001], st[10001];
bool use[10001];
vector<int> g[10001];
vector<pair<int, int>> ans;
bool trykuhn(int nod)
{
    if (use[nod])
        return 0;
    use[nod] = 1;
    for (auto i : g[nod])
    {
        if (mt[i] == 0 || trykuhn(mt[i]))
        {
            mt[i] = nod;
            return 1;
        }
    }
    return 0;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin >> n >> m >> e;
    for (int i = 1; i <= e; i++)
    {
        cin >> a >> b;
        g[a].push_back(b);
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
            use[j] = 0;
        trykuhn(i);
    }
    for (int i = 1; i <= m; i++)
    {
        if (mt[i])
            ans.push_back({ mt[i],i });
    }
    cout << ans.size() << '\n';
    for (auto& i : ans)
        cout << i.first << ' ' << i.second << '\n';
    return 0;
}