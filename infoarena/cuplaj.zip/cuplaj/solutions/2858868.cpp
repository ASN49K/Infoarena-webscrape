#include <bits/stdc++.h>
#define ll long long
#define pb push_back
#define pf push_front
#define MOD 1000000007
#define MAX 10005

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

vector < int > v[MAX];
int p[MAX];
bool viz[MAX], cuplat[MAX];

bool dfs(int nod);

int main()
{
    ios_base::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    int l, r, m, x, y, i, j;
    bool ok = 1;

    fin >> l >> r >> m;
    for(i = 1; i <= m; i++)
    {
        fin >> x >> y;
        v[x].pb(y);
    }

    while(ok == 1)
    {
        ok = 0;
        for(j = 1; j <= l; j++) viz[j] = 0;
        for(i = 1; i <= l; i++) if(cuplat[i] == 0 && dfs(i) == 1) ok = 1;
    }

    int nr = 0;
    for(i = 1; i <= r; i++) if(p[i] != 0) nr++;
    fout << nr << '\n';

    for(i = 1; i <= r; i++) if(p[i] != 0) fout << p[i] << ' ' << i << '\n';

    return 0;
}

bool dfs(int nod)
{
    viz[nod] = 1;
    for(auto it:v[nod])
        if(p[it] == 0 || (viz[p[it]] == 0 && dfs(p[it]) == 1))
        {
            p[it] = nod;
            cuplat[nod] = 1;
            return 1;
        }

    return 0;
}
