#include <bits/stdc++.h>
#define NMAX 10010
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int use[NMAX], l[NMAX], mt[NMAX];
vector<int>v[NMAX];
vector<pair<int,int>>ans;
bool try_kuhn(int node)
{
    if(use[node]==1)
        return false;
    use[node]=1;
    for(auto i:v[node])
        if(mt[i]==-1 || try_kuhn(mt[i])==1)
        {
            l[node]=i;
            mt[i]=node;
            return true;
        }
    return false;
}
int n, m, e, x, y,ok;
int main()
{
    fin>>n>>m>>e;
    for(int i=1;i<=e;++i)
    {
        fin>>x>>y;
        v[x].push_back(y);
    }

    for(int i=1;i<=m;++i)
        mt[i]=-1;//mt[i]-> i ;  i->l[i]

    ok=1;
    while(ok)
    {
        ok=0;cout<<"A";
        for(int i=1;i<=n;++i)
            use[i]=0;
        for(int i=1;i<=n;++i)
            if(l[i]==0)
                ok|=try_kuhn(i);
    }

    for(int i=1;i<=n;++i)
        if(l[i]!=0)
            ans.push_back({i,l[i]});

    sort(ans.begin(), ans.end());
    fout<<ans.size()<<'\n';;
    for(auto i:ans)
            fout<<i.first<<" "<<i.second<<'\n';
    return 0;
}
