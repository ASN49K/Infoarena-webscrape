#include<bits/stdc++.h>
using namespace std;
ifstream in("cuplaj.in");
ofstream out("cuplaj.out");
int n,m,p,total,rezultat;
vector<vector<int>>muchii(30000,vector<int>());
map<int,map<int,int>>val;
int tata[30000];
vector<pair<int,int>>perechi;
bool bfs()
{tata[0]=0;
    for(int i=1;i<=total;i++)
tata[i]=-1;
int ok=0;
queue<int> q;
q.push(0);
while(!q.empty())
{int nod=q.front();
q.pop();
for(auto x:muchii[nod])
{if(tata[x]!=-1||val[nod][x]<=0)continue;
tata[x]=nod;
if(x!=total)
q.push(x);
else
ok=1;
}
}
return ok;
}
int main()
{in>>n>>m>>p;
total=n+m+1;

for(int i=1;i<=n;i++)
{val[0][i]=1;
muchii[0].push_back(i);
muchii[i].push_back(0);}
for(int i=n+1;i<total;i++)
{val[i][total]=1;
muchii[i].push_back(total);
muchii[total].push_back(i);}
for(int i=1;i<=p;i++)
{int x,y;
in>>x>>y;
perechi.push_back({x,y+n});
val[x][y+n]=1;
muchii[x].push_back(y+n);
muchii[y+n].push_back(x);
}
while(bfs())
for(auto x:muchii[total])
if(val[x][total]&&tata[x]!=-1)
{int ok=1,vmin=val[x][total];
    int parent=tata[x],son=x;
    while(son&&ok)
    {if(val[parent][son]<=0||son==-1)ok=0;
        vmin=min(vmin,val[parent][son]);
        son=parent;
        parent=tata[parent];
        }
        if(ok)
        {rezultat+=vmin;

            parent=tata[x],son=x;
        while(son)
        {val[parent][son]-=vmin;
        val[son][parent]+=vmin;
        son=parent;
        parent=tata[parent];
        }
        val[x][total]-=vmin;
        val[total][x]+=vmin;
        rezultat+=vmin;
        }
}

    out<<rezultat<<endl;
    for(auto x:perechi)
    if(val[x.first][x.second]==0)
    out<<x.first<<" "<<x.second-n<<'\n';
}
