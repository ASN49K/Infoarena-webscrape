///sortaret
#include <bits/stdc++.h>
#define MOD 1000000007
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");

int i,j,n,m,x,y,f[500010],p,maxi,d[500010];
vector <int> v[500010];
queue <int> q;
set <int> se;
char sir1[110],sir2[110];
int main()
{
    cin.tie(0);
    cout.tie(0);
    fin>>n;
    for(i=1;i<=n;i++)

    return 0;
}
