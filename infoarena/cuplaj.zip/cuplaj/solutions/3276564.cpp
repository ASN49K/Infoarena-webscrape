///circular
#include <bits/stdc++.h>
#define MOD 30011
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int i,f[100010],to[100010],fro[100010],n,m,k,x,y;
vector <int> v[100010];

bool cup(int k)
{
    if(f[k])
        return false;
    f[k]=1;
    for(int it : v[k])
    {
        if(fro[it]==0 || cup(fro[it]))
        {
            fro[it]=k;
            to[k]=it;
            return true;
        }
    }
    return false;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    fin>>n>>m>>k;
    for(i=1; i<=k; i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
    }
    bool ski=true;
    while(ski)
    {
        ski=false;
        memset(f,0,sizeof(f));
        for(i=1; i<=n; i++)
            if(to[i]==0)
                ski|=cup(i);
    }
    int cn=0;
    for(i=1; i<=n; i++)
        if(to[i])
            cn++;
    fout<<cn<<'\n';
    for(i=1; i<=n; i++)
        if(to[i])
            fout<<i<<" "<<to[i]<<'\n';
    return 0;
}
