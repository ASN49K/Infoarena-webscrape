#include <bits/stdc++.h>
#define MAX 10000
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
vector<int>v1[MAX+5], v2[MAX+5];
int a, b, m, x, y, i, nod, cuplat1[MAX+5], cuplat2[MAX+5];
bool viz[MAX+5];
vector<pair<int, int>>r;
bool dfs(int nod) {
    for (int x:v1[nod]) {
        if (viz[x]==1) continue;
        if (cuplat2[x]==0) {
            cuplat2[x]=nod;
            return 1;
        }
        else {
            viz[x]=1;
            y=dfs(cuplat2[x]);
            if (y==1) {
                cuplat2[x]=nod;
            }
            return y;
        }
    }
    return 0;
}
int main()
{
    fin>>a>>b>>m;
    for (i=1; i<=m; i++) {
        fin>>x>>y;
        v1[x].push_back(y);
        v2[y].push_back(x);
    }
    x=1;
    while (x==1) {
        for (i=1; i<=b; i++) viz[i]=0;
        for (nod=1; nod<=a; nod++) {
            if (cuplat1[nod]==0) {
                x=dfs(nod);
                if (x==1) {
                    cuplat1[nod]=1;
                    break;
                }
            }
        }
    }
    for (i=1; i<=b; i++) {
        if (cuplat2[i]!=0) r.push_back({cuplat2[i], i});
    }
    fout<<r.size()<<'\n';
    for (auto x:r) fout<<x.first<<' '<<x.second<<'\n';
    return 0;
}
