#include <fstream>
#include <vector>
#include <omp.h>
using namespace std;

class InParser {
    vector<char> str;
    int ptr;
    ifstream fin;

    char getChar() {
        if (ptr == int(str.size())) {
            fin.read(str.data(), str.size());
            ptr = 0;
        }
        return str[ptr++];
    }

    template<class T>
    T getInt() {
        char chr = getChar();
        while (!isdigit(chr) && chr != '-')
            chr = getChar();
        int sgn = +1;
        if (chr == '-') {
            sgn = -1;
            chr = getChar();
        }
        T num = 0;
        while (isdigit(chr)) {
            num = num * 10 + chr - '0';
            chr = getChar();
        }
        return sgn * num;
    }

public:
    InParser(const char* name) : str(100000), ptr(str.size()), fin(name) { }
    ~InParser() { fin.close(); }

    template<class T>
    friend InParser& operator>>(InParser& in, T& num) {
        num = in.getInt<T>();
        return in;
    }
};

class OutParser {
    vector<char> str;
    int ptr;
    ofstream fout;

    void putChar(char chr) {
        if (ptr == int(str.size())) {
            fout.write(str.data(), str.size());
            ptr = 0;
        }
        str[ptr++] = chr;
    }

    template<class T>
    void putInt(T num) {
        if (num < 0) {
            putChar('-');
            num *= -1;
        }
        if (num > 9)
            putInt(num / 10);
        putChar(num % 10 + '0');
    }

public:
    OutParser(const char* name) : str(100000), ptr(0), fout(name) { }
    ~OutParser() { fout.write(str.data(), ptr); fout.close(); }

    template<class T>
    friend OutParser& operator<<(OutParser& out, const T num) {
        out.putInt(num);
        return out;
    }

    friend OutParser& operator<<(OutParser& out, const char chr) {
        out.putChar(chr);
        return out;
    }

    friend OutParser& operator<<(OutParser& out, const char* str) {
        for (int i = 0; str[i]; i++)
            out.putChar(str[i]);
        return out;
    }
};

const int MAX = 10001;

vector<int> g[MAX];
int a, b, m, l[MAX], r[MAX], cuplaj;
bool viz[MAX];

bool cupleaza(int i) {
    viz[i] = 1;

    for (auto it : g[i]) {
        if (!r[it]) {
            r[it] = i;
            l[i] = it;
            return true;
        }
    }

    for (auto it : g[i]) {
        if (!viz[r[it]] && cupleaza(r[it])) {
            r[it] = i;
            l[i] = it;
            return true;
        }
    }

    return false;
}

int main() {
    InParser cin("cuplaj.in");
    OutParser cout("cuplaj.out");

    cin >> a >> b >> m;

    int x, y;
    while (m--) {
        cin >> x >> y;
        g[x].push_back(y);
    }

    bool ok = true;

    while (ok) {
        ok = false;

        #pragma omp parallel for
        for (int i = 1; i <= a; i++) {
            viz[i] = 0;
        }

        for (int i = 1; i <= a; i++) {
            if (!l[i] && cupleaza(i)) {
                cuplaj++;
                ok = true;
            }
        }
    }

    cout << cuplaj << '\n';
    for (int i = 1; i <= a; i++) {
        if (l[i]) cout << i << ' ' << l[i] << '\n';
    }

    return 0;
}
