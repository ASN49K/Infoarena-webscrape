#include <bits/stdc++.h>
#define maXX 22000
using namespace std;
ifstream f("cuplaj.in");
ofstream g("cuplaj.out");
vector<int> adj[6001];
int MaxFLOW,flow,fluxmin,fluxmax;
int i,j,k,n,m,C[6001][6001],viz[6001],x,y,z,fth[6001],nod,F[6001][6001],e,source,last_node;
queue<int>q;
int bfs()
{
    int top,next;
    memset(viz,0,sizeof(viz));
    q.push(source);
    while(q.empty() == false)
    {
        top = q.front();
        q.pop();
        viz[top] = 1;
        if(top == last_node)
            break;
        for(int i=0; i<adj[top].size(); i++)
        {
            next = adj[top][i];
            if(viz[next] == 0 && F[top][next] != C[top][next])
            {
                viz[next]=1;
                q.push(next);
                fth[next] = top;
            }
        }
    }
    return viz[last_node];
}
int main()
{
    f>>n>>m>>e;
    last_node = n+m+1;
    source = 0;
    for(i=1;i<=n;i++)
    {
        adj[source].push_back(i);
        adj[i].push_back(source);
        C[source][i] = 1;
    }
    for(i=1;i<=e;i++)
    {
        f>>x>>y;
        adj[x].push_back(n+y);
        adj[n+y].push_back(x);
        C[x][n+y] = 1;
    }
    for(i=1;i<=m;i++)
    {
        adj[n+i].push_back(last_node);
        adj[last_node].push_back(n+i);
        C[n+i][last_node] = 1;
    }

    for(MaxFLOW = 0; bfs();)
    {
        for(i=0; i<adj[last_node].size(); i++)
        {
            fluxmin = 10e7;
            nod = adj[last_node][i];
            if(!viz[nod] || F[nod][last_node] == C[nod][last_node])
                continue;
            fth[last_node] = nod;
            for(nod = last_node; nod != source ; nod = fth[nod])
            {
                fluxmin = min(fluxmin,C[fth[nod]][nod] - F[fth[nod]][nod]);
            }
            if(fluxmin == 0)
                continue;
            for (nod = last_node; nod != source ; nod = fth[nod])
            {
                F[fth[nod]][nod] += fluxmin;
                F[nod][fth[nod]] -= fluxmin;
            }
            MaxFLOW += fluxmin;
        }
        // MaxFLOW += fluxmin;
    }
    g<<MaxFLOW<<endl;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
        {
            if(F[i][n+j] == 1)
                g<<i<<" "<<j<<endl;
        }
    }
    return 0;
}
