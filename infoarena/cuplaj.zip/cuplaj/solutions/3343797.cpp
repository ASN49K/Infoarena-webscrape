#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n, m, e, x, y, l[20005], r[20005], i;
vector <int> v[20005];
bool viz[20005];
bool try_kuhn(int nod)
{
    if(viz[nod])
        return false;
    viz[nod]=true;
    for(auto i: v[nod])
        if(r[i]==-1 || try_kuhn(r[i]))
        {
            l[nod]=i;
            r[i]=nod;
            return true;
        }
    return false;
}
int main()
{
    fin>>n>>m>>e;
    for(i=1; i<=e; i++)
    {
        fin>>x>>y;
        v[x].push_back(y+n);
        v[y+n].push_back(x);
    }
    for(i=1; i<=n+m; i++)
        l[i]=r[i]=-1;
    bool check=1;
    while(check)
    {
        check=0;
        for(i=1; i<=n+m; i++)
            viz[i]=0;
        for(i=1; i<=n; i++)
            if(l[i]==-1)
                check|=try_kuhn(i);
    }
    int nr=0;
    for(i=1; i<=n; i++)
        if(l[i]!=-1)
            nr++;
    fout<<nr<<'\n';
    for(i=1; i<=n; i++)
        if(l[i]!=-1)
            fout<<i<<" "<<l[i]-n<<'\n';
    return 0;
}
