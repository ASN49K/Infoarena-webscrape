#include <iostream>
#include <fstream>
#include <vector>

std::ifstream fin("cuplaj.in");
std::ofstream fout("cuplaj.out");

const int MAX_N = 10000;

int n, m;
int n_edges;
std::vector<int> g[MAX_N];
bool visited[MAX_N];
int match_l[MAX_N];
int match_r[MAX_N];

bool match(int node) {
    if (visited[node])
        return false;

    visited[node] = true;

    for (int neighbour : g[node])
        if (match_r[neighbour] == -1) {
            match_l[node] = neighbour;
            match_r[neighbour] = node;
            return true;
        }

    for (int neighbour : g[node])
        if (match(match_r[neighbour])) {
            match_l[node] = neighbour;
            match_r[neighbour] = node;
            return true;
        }

    return false;
}

int main() {
    fin >> n >> m >> n_edges;

    for (int i = 0; i < n_edges; i++) {
        int l_node, r_node;
        fin >> l_node >> r_node;
        l_node--; r_node--;
        g[l_node].push_back(r_node);
    }

    for (int i = 0; i < n; i++)
        match_l[i] = -1;
    for (int i = 0; i < m; i++)
        match_r[i] = -1;

    bool improved_matching = true;

    while (improved_matching) {
        improved_matching = false;

        for (int i = 0; i < n; i++)
            visited[i] = false;

        for (int i = 0; i < n; i++)
            if (match_l[i] == -1)
                improved_matching |= match(i);
    }

    int edges_in_matching = 0;

    for (int i = 0; i < n; i++)
        edges_in_matching += (match_l[i] != -1);

    fout << edges_in_matching << '\n';

    for (int i = 0; i < n; i++)
        if (match_l[i] != -1) {
            fout << i + 1 << ' ' << match_l[i] + 1 << '\n';
        }

    return 0;
}
