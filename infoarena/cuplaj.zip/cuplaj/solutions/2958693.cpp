#include <iostream>
#include <vector>
#include <fstream>
#include <queue>
#include <algorithm>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
const int d = 2005;
int c[d][d]; //capacitate intre doua noduri
int f[d][d]; //capacitate consumata
vector<int> la[d]; //lista adiacenta
vector<int> vizitat;
int tata[d]; //tatal fiecarui nod
int n,m,e,x,y,i,j,sursa,destinatie,z,flow,nod;

int bfs()
{
    vizitat.assign(destinatie+1, 0);
    queue<int> coada;
	coada.push(sursa);
	while(!coada.empty())
    {
        nod=coada.front();
        coada.pop();
        vizitat[nod]=1;
        if(nod == destinatie) break; //opresc parcurgerea daca ajung la destinatie
        for(int j=0;j<la[nod].size();j++)
        {
            if(vizitat[la[nod][j]]==0 && c[nod][la[nod][j]]!=f[nod][la[nod][j]]) //daca nu e vizitat si daca drumul nu a fost consumat
            {
                coada.push(la[nod][j]);
                vizitat[la[nod][j]];
                tata[la[nod][j]]=nod; //retin tatal nodului
            }
        }
    }
    return vizitat[destinatie];//ne zice daca a ajuns la final drumul -> nu s a gasit fluxul maxim deci continuam
}

int main()
{
    fin>>n>>m>>e;
    //transformam in retea de transport folosind sursa si destinatie
    sursa=0;
    destinatie=n+m+1;
    for(i=1;i<=n;i++)
    {
  		la[sursa].push_back(i);
  		la[i].push_back(sursa);
  		c[sursa][i]=1;
    }
    for(i=1;i<=e;i++)
    {
        fin>>x>>y;
  		la[x].push_back(n+y);
  		la[n+y].push_back(x);
  		c[x][n+y]=1;
    }
    for(i=1;i<=m;i++)
    {
  		la[n+i].push_back(destinatie);
  		la[destinatie].push_back(n+i);
  		c[n+i][destinatie]=1;
    }
    flow=0;
    while(bfs())
    {
        for(i=0;i<la[destinatie].size();i++)
        {
            nod = la[destinatie][i];
			if (f[nod][destinatie] == c[nod][destinatie] || !vizitat[nod]) continue;
			tata[destinatie] = nod;
			int minn=9999999;
			for (j = destinatie; j> sursa; j = tata[j])
            {
  				minn = min(minn, c[tata[j]][j] - f[tata[j]][j]); //calculez capacitatea minima a drumului (capacitate totala-consumata)
  			}
			if (minn == 0) continue;
			for (j = destinatie; j> sursa; j = tata[j]) //modific capacitatile drumurilor+ maresc flowul rezidual
            {
  				f[tata[j]][j] += minn;
  				f[j][tata[j]] -= minn;
  			}
  			flow=flow+minn;
        }
    }
    fout<<flow<<"\n";
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=m;j++)
        {
            if(f[i][j+n]==1)
            {
                fout<<i<<" "<<j<<"\n";
            }
        }
    }
    return 0;
}
