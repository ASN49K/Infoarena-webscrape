#include <bits/stdc++.h>
using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int n,i,y,m,l[20005],e,x,cnt;
vector<int>v[20005];
bool ok=1;
int used[20005];

bool kk(int k)
{
    if(used[k])return 0;

    used[k]=1;

    for(auto i : v[k])
    if(l[i]==-1 || kk(i)){
        l[i]=k;
        cnt++;
        return 1;
    }
    return 0;
}

int main(){

    fin>>n>>m>>e;

    for(i=1;i<=e;i++){
        fin>>x>>y;
        v[x].push_back(y+n);

    }

    for(i=1;i<=n+m;i++)l[i]=-1;

    while(ok){
        ok=0;
       for(i=1;i<=n+m;i++)used[i]=0;

        for(i=1;i<=n+m;i++)
            if(l[i]==-1)
            ok|=kk(i);
    }
    fout<<cnt<<'\n';
    for(i=1;i<=n+m;i++)
        if(l[i]!=-1)
        if(i>n)
        fout<<l[i]<<" "<<i-n<<'\n';

    else fout<<i<<" "<<l[i]-n<<'\n';
}
