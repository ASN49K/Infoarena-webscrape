#include <fstream>
#include <vector>
using namespace std;

ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");

const int Nmax = 1e5 + 5;

vector<int>g[Nmax];
bool vis[Nmax];
int vecin[Nmax], vecin2[Nmax];
//vecin[i] = vec din dreapta al lui i(care e mereu din stanga)
//vecin2[i] = vec din stanga al lui i(care e mereu din dreapta)

int n;

bool cupleaza(int nod)
{
    if (vis[nod])
        return false;
    vis[nod] = true;
    for(auto it: g[nod])
    {
        if (vecin2[it] == 0 || cupleaza(vecin2[it]))
        {
            vecin[nod] = it;
            vecin2[it] = nod;
            return true;
        }
    }
    return false;
}

void cuplaj_max()
{
    int ok = 1;
    while(ok)
    {
        ok = 0;
        for(int i = 1; i <= n; i ++)
            vis[i] = 0;
        for(int i = 1; i <= n; i ++)
            if(vecin[i] == 0)
                ok += cupleaza(i);
    }
}

int main()
{
    int m, e, i, x, y, cnt = 0;
    cin >> n >> m >> e;
    for(i = 1; i <= e; i ++)
    {
        cin >> x >> y;
        y += n;
        g[x].push_back(y);
    }
    cuplaj_max();
    for(i = 1; i <= n; i ++)
        cnt += (vecin[i] > 0);
    cout << cnt << '\n';
    for(i = 1; i <= n; i ++)
        if(vecin[i] > 0)
            cout << i << " " << vecin[i] - n << '\n';
    return 0;
}
