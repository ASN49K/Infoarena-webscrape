#include <fstream>
#include <cstring>
#include <vector>
using namespace std;
ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");
const int Dim = 100001;
vector<int>g[Dim];
int n,m,viz[Dim],L[Dim],R[Dim];

int cuplaj(int i){
    if(viz[i] == 1)
    return false;
    viz[i] = 1;
    for(auto y: g[i]){
        if(!R[y] || cuplaj(R[y])) {
            L[i] = y;
            R[y] = i;
            return true;
        }
    }
    return false;
}

int main(){
    int e;
    cin >> n >> m>>e;
    for(int i = 1,x,y; i <= e; ++i) {
    
        cin >> x >> y;
        g[x].push_back(y+n);
    }
    int cnt = 0;
    bool ok = false;
    while(ok ==false) {
        memset(viz,0,sizeof(viz));
        ok = true;
        for(int i = 1; i <= n; ++i) 
            if(!L[i] && cuplaj(i))
                ++cnt,ok=false;
        
    }
    cout << cnt << "\n";
    for(int i = 1; i <= n; ++i)
        if(L[i])
            cout <<i << " " << L[i]-n << "\n";
}