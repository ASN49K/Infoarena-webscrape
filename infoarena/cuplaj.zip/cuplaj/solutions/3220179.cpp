#include <bits/stdc++.h>
#ifdef LOCAL
#define in cin
#define out cout
#endif

using namespace std;

#ifndef LOCAL
ifstream in("cuplaj.in");
ofstream out("cuplaj.out");
#endif

const int nmax = 1e4 + 5;

int l[nmax];
int r[nmax];
bool viz[nmax];
vector<int> adj[nmax];

bool pairup(int nod)
{
    if (viz[nod])
        return 0;
    viz[nod] = 1;
    for (auto i : adj[nod])
    {
        if (r[i] == 0)
        {
            r[i] = nod;
            l[nod] = i;
            return 1;
        }
    }
    for (auto i : adj[nod])
    {
        if (pairup(r[i]))
        {
            r[i] = nod;
            l[nod] = i;
            return 1;
        }
    }
    return 0;
}

int main()
{
    int n, m, e;
    in >> n >> m >> e;
    for (int i = 0; i < e; i++)
    {
        int a, b;
        in >> a >> b;
        adj[a].push_back(b);
    }
    int cup = 0;
    bool schimb = 0;
    do
    {
        schimb = 0;
        memset(viz, 0, sizeof viz);
        for (int i = 1; i <= n; i++)
        {
            if (l[i] == 0)
            {
                if (pairup(i))
                {
                    schimb = 1;
                    cup++;
                }
            }
        }
    } while (schimb);
    out << cup << '\n';
    for (int i = 1; i <= n; i++)
    {
        if (l[i] != 0)
        {
            out << i << ' ' << l[i] << '\n';
        }
    }
}