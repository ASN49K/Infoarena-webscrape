#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define vt vector
#define pq priority_queue
#define pu push
#define pub push_back
#define em emplace
#define emb emplace_back
#define all(x) x.begin(), x.end()
#define allp(x, l, r) x.begin() + l, x.begin() + r
#define sz(x) x.size()

using namespace std;
using namespace __gnu_pbds;

using ll = long long;
using ld = long double;
using ull = unsigned long long;

template <class T> void re(vt <T>& x);
template <class T> void re(T& x) {
    cin >> x;
}

template <class H, class... T> void re(H& x, T&...y) {
    re(x); re(y...);
}

template <class T> void re(vt <T>& x) {
    for(auto& it : x)
        re(it);
}

template <class T> void wr(T x) {
    cout << x;
}

template <class H, class ...T>  void wr(H x, T... y) {
    wr(x), wr(y...);
}

inline void Open(const string Name) {
    #ifndef ONLINE_JUDGE
        (void)!freopen((Name + ".in").c_str(), "r", stdin);
        (void)!freopen((Name + ".out").c_str(), "w", stdout);
    #endif
}

struct HopcroftKarp {
    static const int inf = 1e9;
    int n;
    vt <int> l, r, d;
    vt <vt <int>> g;

    HopcroftKarp(int _n, int _m) {
        n = _n;
        int p = _n + _m + 1;
        g.resize(p);
        l.resize(p, 0);
        r.resize(p, 0);
        d.resize(p, 0);
    }

    void add_edge(int u, int v) {
        g[u].push_back(v + n); //right id is increased by n, so is l[u]
    }

    bool bfs() {
        queue <int> q;
        for(int u = 1;u <= n;u++) {
            if (!l[u]) {
                d[u] = 0;
                q.em(u);
                continue;
            }
            d[u] = inf;
        }

        d[0] = inf;
        while(sz(q)) {
            int u = q.front();
            q.pop();
            for(auto& v : g[u]) {
                if(d[r[v]] == inf) {
                    d[r[v]] = d[u] + 1;
                    q.em(r[v]);
                }
            }
        }
        return d[0] != inf;
    }

    bool dfs(int u) {
        if(!u) {
            return 1;
        }

        for(auto& v : g[u]) {
            if(d[r[v]] == d[u] + 1 && dfs(r[v])) {
                l[u] = v;
                r[v] = u;
                return 1;
            }
        }
        d[u] = inf;
        return 0;
    }

    int maximum_matching() {
        int ans = 0;
        while(bfs()) {
            for(int u = 1; u <= n; u++) 
                if(!l[u] && dfs(u))
                    ++ans;
        }
        return ans;
    }
};

void solve() {
    int n, m, q; re(n, m, q);
    HopcroftKarp M(n, m);
    while(q--) {
        int a, b; re(a, b);
        M.add_edge(a, b);
    }

    wr(M.maximum_matching(), '\n');
    for(int i = 1;i <= n;i++)
        if(M.l[i])
            wr(i, ' ', M.l[i] - n, '\n');
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    Open("cuplaj");

    int t = 1;
    for(;t;t--) {
        solve();
    }
    
    return 0;
}