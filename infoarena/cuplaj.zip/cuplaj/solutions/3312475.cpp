#pragma GCC optimize("Ofast,no-stack-protector,unroll-loops,fast-math")
#include <complex.h>
#include <bits/stdc++.h>

using namespace std;

#define NMAX 10000
#define MMAX 10
#define PMAX 524288
#define LOG 18
#define INF 100000000
#define BS 666013
#define MOD 1000000007
#define INV_2 500000004
#define INV_24 41666667

#define ll long long
#define ull unsigned long long
#define dbl double
#define pii pair<int, int>
#define piv pair<int, vector<int>>

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int n, m, k, x, y;
vector<pii> ans;
vector<int> gr[NMAX + 2];
vector<int> st(NMAX + 2, 0), dr(NMAX + 2, 0);
vector<bool> viz(NMAX + 2, 0);

bool cuplaj(int nod) {
    if (viz[nod]) {
        return 0;
    }
    viz[nod] = 1;

    for (int vec : gr[nod]) {
        if (!dr[vec]) {
            st[nod] = vec;
            dr[vec] = nod;
            return 1;
        }
    }
    for (int vec : gr[nod]) {
        if (cuplaj(dr[vec])) {
            st[nod] = vec;
            dr[vec] = nod;
            return 1;
        }
    }
    return 0;
}

int main() {
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);

    fin >> n >> m >> k;

    while (k--) {
        fin >> x >> y;
        gr[x].emplace_back(y);
    }

    bool done = 1;
    while (done) {
        done = 0;
        fill(viz.begin(), viz.end(), 0);

        for (int i = 1; i <= n; i++) {
            if (!st[i] && cuplaj(i)) {
                done = 1;
            }
        }
    }

    for (int i = 1; i <= n; i++) {
        if (st[i]) {
            ans.emplace_back(i, st[i]);
        }
    }

    fout << ans.size() << '\n';
    for (auto it : ans) {
        fout << it.first << ' ' << it.second << '\n';
    }
    return 0;
}