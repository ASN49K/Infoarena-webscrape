#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <cstring>
#include <fstream>

using namespace std;

ifstream f("cuplaj.in");
ofstream o("cuplaj.out");
vector<int> adj[20001];
int viz[20001], g1[20001], g2[20001] ;

int matching(int val) {
    if(viz[val]) return 0;
    viz[val] = 1;

    for(int i = 0; i < adj[val].size(); ++i) {
        if(!g2[adj[val][i]]) {
            g1[val] = adj[val][i];
            g2[adj[val][i]] = val;
            return 1;
        }
    }
    for(int i = 0; i < adj[val].size(); ++i) {
        if(matching(g2[adj[val][i]])) {
            g1[val] = adj[val][i];
            g2[adj[val][i]] = val;
            return 1;
        }
    }

    return 0;
}

int main() {
    int n, m, e, st, fin, ok = 1, match = 0;
    f>>n>>m>>e;
    for(int i = 1; i <= e; ++i) {
        f>>st>>fin;
        adj[st].push_back(fin);
    }
    while(ok) {
        ok = 0;
        memset(viz, 0, sizeof(viz));
        for(int i = 1; i <= n; i++) if(!g1[i]) ok = ok || matching(i);
    }

    for(int i = 1; i <= n; ++i) if(g1[i]) match += 1;
    o<<match<<"\n";
    for(int i = 1; i <= n; ++i) if(g1[i]) o<<i<<" "<<g1[i]<<"\n";

    return 0;
}
