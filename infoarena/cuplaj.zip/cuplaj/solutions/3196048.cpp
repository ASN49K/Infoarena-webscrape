#include <bits/stdc++.h>

using namespace std;

#define MAX_N 10000

vector <int> match;
vector <vector <int> > graph;
bitset <MAX_N + 1> viz;

int n, m, e, ans;

bool pairUp(int node)
{
//    if(viz[node] == 1)
//        return 0;
//
//    viz[node] = 1;

    for(int x : graph[node])
    {
        if(!match[x - n])
        {
            ans ++;
            match[x - n] = node;
            return 1;
        }
    }

    for(int x : graph[node])
    {
        if(match[x - n] != node  &&  pairUp(match[x - n]))
        {
            match[x - n] = node;
            return 1;
        }
    }

    return 0;
}

int main()
{
    ios_base :: sync_with_stdio(0);
    cin.tie(0);

    freopen("cuplaj.in", "r", stdin);
    freopen("cuplaj.out", "w", stdout);

    cin >> n >> m >> e;
    graph.resize(n + 1);
    match.resize(m + 1, 0);

    for(int i = 0; i < e; i ++)
    {
        int x, y;
        cin >> x >> y;
        graph[x].push_back(n + y);
    }

    for(int i = 1; i <= n; i ++)
//        if(!viz[i])
            pairUp(i);

    cout << ans << "\n";
    for(int i = 1; i <= m; i++)
        if(match[i])
            cout << match[i] << " " << i << "\n";
    return 0;
}
