#include <bits/stdc++.h>
#define MAX 10005
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n, m, e, x, y, cuplat[2*MAX], nr, i, gasit, ultimul;
vector<int>v[2*MAX];
bool pair_up(int nod) {
    for (auto x:v[nod]) {
        if (!cuplat[x]) {
            cuplat[x]=nod;
            cuplat[nod]=x;
            return 1;
        }
    }
    for (auto x:v[nod]) {
        if (cuplat[x] && cuplat[x]!=nod && pair_up(cuplat[x])) {
            cuplat[x]=nod;
            cuplat[nod]=x;
            return 1;
        }
    }
    return 0;
}
int main()
{
    fin>>n>>m>>e;
    for (i=1; i<=e; i++) {
        fin>>x>>y;
        y+=n;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    for (i=1; i<=n; i++) {
        for (auto x:v[i]) {
            if (!cuplat[x]) {
                cuplat[i]=x;
                cuplat[x]=i;
                ultimul=i;
                nr++;
                break;
            }
        }
    }
    if (nr==n) {
        fout<<n<<'\n';
        for (i=1; i<=n; i++) fout<<i<<' '<<cuplat[i]<<'\n';
        return 0;
    }
    do {
        gasit=0;
        for (i=1; i<=n; i++) {
            if (!cuplat[i] && pair_up(i)) gasit=1, nr++;
        }
    } while (gasit);
    fout<<nr<<'\n';
    for (i=1; i<=n; i++)
        if (cuplat[i])
            fout<<i<<' '<<cuplat[i]-n<<'\n';
    return 0;
}
