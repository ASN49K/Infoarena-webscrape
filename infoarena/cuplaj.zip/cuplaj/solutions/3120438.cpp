#include <bits/stdc++.h>
using namespace std ;
ifstream fin("cuplaj.in") ;
ofstream fout("cuplaj.out") ;
#define pb(x) push_back(x)
const int NMAX=1e4+4 ;
vector <int> g[NMAX] ;
int n,m,e,x,y,cuplat[NMAX],cuplaj ;
bool viz[NMAX],este[NMAX] ;
int dfs(int nod)
{
    if(viz[nod]) return 0 ;
    viz[nod]=1 ;
    for(auto it:g[nod])
    {
        if(!cuplat[it] || dfs(cuplat[it]))
        {
            cuplat[it]=nod,este[nod]=1;
            return 1 ;
        }
    }
    return 0 ;
}
int main()
{
    fin>>n>>m>>e ;
    for(int i=1; i<=e; ++i) fin>>x>>y,g[x].pb(y) ;
    for(bool am=1; am;)
    {
        am=0 ;
        memset(viz,0,sizeof(viz)) ;
        for(int i=1; i<=n; ++i) if(!este[i] && dfs(i)) am=1 ;
    }
    for(int i=1; i<=m; ++i) cuplaj+=(cuplat[i]>0) ? 1 :0 ;
    fout<<cuplaj<<'\n' ;
    for(int i=1; i<=n; ++i) if(cuplat[i]>0) fout<<i<<" "<<cuplat[i]<<'\n' ;
    return 0 ;
}
