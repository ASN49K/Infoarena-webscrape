#include<bits/stdc++.h>
using namespace std;
const int NMAX=10005;
int left1[NMAX],right1[NMAX],viz[NMAX];
vector<int>v[NMAX];
bool cuplaj(int nod)
{
    if(viz[nod])return 0;
    viz[nod]=1;
    for(auto it:v[nod])
        if(!right1[it])
    {
        right1[it]=nod;
        left1[nod]=it;
        return 1;
    }
    for(auto it:v[nod])
    {
        if(cuplaj(right1[it]))
        {
            right1[it]=nod;
            left1[nod]=it;
            return 1;
        }
    }
    return 0;
}
int main()
{
    freopen("cuplaj.in","r",stdin);
    freopen("cuplaj.out","w",stdout);
    int m,n,k,a,b,i;
    cin>>m>>n>>k;
    for(i=1;i<=k;i++)
    {
        cin>>a>>b;
        v[a].push_back(b);
    }
    int ok=1;
    while(ok)
    {
        ok=0;
        memset(viz,0,sizeof(viz));
        for(i=1;i<=m;i++)
        if(!left1[i]){int ok1=cuplaj(i);if(ok1)ok=1;}
    }
    int cnt=0;
    for(i=1;i<=m;i++)
        if(left1[i])cnt++;
    cout<<cnt<<'\n';
    for(i=1;i<=m;i++)
        if(left1[i])cout<<i<<" "<<left1[i]<<'\n';
}
