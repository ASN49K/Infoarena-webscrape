#include <bits/stdc++.h>

using namespace std;

#define NMAX 10000
int f[NMAX][NMAX], c[NMAX][NMAX], p[NMAX];
ofstream fout("cuplaj.out");
ifstream fin("cuplaj.in");


bool findPath(int src, int trg, vector<vector<int>>& adj) {

    for (int i = 0 ; i < NMAX ; i++)
        p[i] = -1;

    queue<int> q;

    q.push(src);

    while (!q.empty()) {

        int node = q.front();
        q.pop();

        if (node == trg)
            return true;

        for (auto neigh : adj[node]) {
            if (f[node][neigh] >= c[node][neigh] || p[neigh] != -1) {
                continue;
            }

            p[neigh] = node;
            q.push(neigh);
        }
    }

    return false;
}

int flux(int src, int trg, int n, vector<vector<int>>& adj) {

    int flow = 0;
    // found path
    while (findPath(src, trg, adj)) {
        int idx = trg;
        while (p[idx] != -1) {
            f[p[idx]][idx]++;
            f[idx][p[idx]]--;
            idx = p[idx];
        }

        flow++;
    }

    return flow;
}

int main() {
    int n, m, e;
    fin >> n >> m >> e;

    vector<int> C(n, 1);
    vector<vector<int>> adj(n + m + 2);

    for (int i = 0 ; i < e ; i++) {
        int l, r;
        fin >> l >> r;
        l--;
        r += n - 1;

        adj[l].push_back(r);
        f[l][r] = 0;
        c[l][r] = 1;
        adj[r].push_back(l);
        f[r][l] = 0;
        c[r][l] = 0;
    }

    int src = n + m;
    int trg = n + m + 1;

    for (int i = 0 ; i < n ; i++) {
        f[src][i] = 0;
        c[src][i] = 1;
        adj[src].push_back(i);
    }

    for (int i = n ; i < n + m ; i++) {
        f[i][trg] = 0;
        c[i][trg] = 1;
        adj[i].push_back(trg);
    }

    fout << flux(src, trg, n, adj) << endl;

    for (int i = 0 ; i < n ; i++)
        for (int j = n ; j < n + m ; j++)
            if (f[i][j] == 1)
                fout << i + 1 << " " << j - n + 1 << endl;

    return 0;


}