#include <bits/stdc++.h>

using namespace std;

const int nmax = 1e4 + 1;

vector<int> adj[nmax];
bool f[nmax];
int l[nmax];
int r[nmax];

int up(int i) {
  if(f[i]) {
    return 0;
  }
  f[i] = 1;
  for(auto it : adj[i]) {
    if(!r[it]) {
      l[i] = it;
      r[it] = i;
      return 1;
    }
  }
  for(auto it : adj[i]) {
    if(up(r[it])) {
      l[i] = it;
      r[it] = i;
      return 1;
    }
  }
  return 0;
}

int32_t main() {
  ifstream cin("cuplaj.in");
  ofstream cout("cuplaj.out");
  int n, m, e;
  cin >> n >> m >> e;
  while(e--) {
    int a, b;
    cin >> a >> b;
    adj[a].push_back(b);
  }
  while(true) {
    bool ok = 0;
    memset(f, 0, sizeof(f));
    for(int i = 1; i <= n; i++) {
      if(!l[i]) {
        ok |= up(i);
      }
    }
    if(!ok) {
      break;
    }
  }
  int ans = 0;
  for(int i = 1; i <= n; i++) {
    ans += (l[i] > 0);
  }
  cout << ans << '\n';
  for(int i = 1; i <= n; i++) {
    if(l[i]) {
      cout << i << " " << l[i] << '\n';
    }
  }
  return 0;
}

/*
7
1 2 5 10 11 13 14 12 9 8 7 6 4 3
5
1 2 8 9 10 7 6 5 4 3
*/
