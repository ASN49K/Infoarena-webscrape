#include <bits/stdc++.h>

using namespace std;

ifstream in("cuplaj.in");
ofstream out("cuplaj.out");

class Graph
{
    int n, m;

    list<int> *adj;

    int *pairL, *pairR, *dist;

public:
    Graph(int n, int m);
    void addEdge(int u, int v);

    bool bfs();

    bool dfs(int u);

    int hopcroftKarp();

};

int Graph::hopcroftKarp()
{
    pairL = new int[n+1];
    pairR = new int[m+1];
    dist = new int[n+1];

    int l[100001];
    int k = 0;

    for(int u = 0; u <= n; u++)
        pairL[u] = 0;
    for(int v = 0; v <= m; v++)
        pairR[v] = 0;

    int result = 0;

    while (bfs())
    {
        for(int u = 1; u <= n; u++)
            if(pairL[u] == 0 && dfs(u))
            {
                result++;
                k++;
                l[k] = u;
            }
    }

    out<<result<<endl;
    for(int i = 1; i <= result; i++)
        out<<l[i]<<" "<<pairL[l[i]]<<endl;
}

bool Graph::bfs()
{
    queue<int> q;

    for(int u = 1; u <= n; u++)
        if(pairL[u] == 0)
        {
            dist[u] = 0;
            q.push(u);
        }

        else dist[u] = 999999;

    dist[0] = 999999;

    while(!q.empty())
    {
        int u = q.front();
        q.pop();

        if(dist[u] < dist[0])
        {
            list<int>::iterator i;
            for(i=adj[u].begin(); i!=adj[u].end(); i++)
            {
                int v = *i;
                if(dist[pairR[v]] == 999999)
                {
                    dist[pairR[v]] = dist[u] + 1;
                    q.push(pairR[v]);
                }
            }
        }
    }

    return (dist[0] != 999999);

}

bool Graph::dfs(int u)
{
    if(u != 0)
    {
        list<int>::iterator i;
        for(i=adj[u].begin(); i!=adj[u].end(); i++)
        {
            int v = *i;
            if(dist[pairR[v]] == dist[u] + 1)
            {
                if(dfs(pairR[v]) == true)
                {
                    pairR[v] = u;
                    pairL[u] = v;
                    return true;
                }
            }
        }

        dist[u] = 999999;
        return false;
    }

    return true;
}

Graph::Graph(int n, int m)
{
    this->n =n;
    this->m = m;
    adj = new list<int>[n+1];
}

void Graph::addEdge(int u, int v)
{
    adj[u].push_back(v);
}

int main()
{
    int n, m, e, i, a, b;
    in>>n>>m>>e;

    Graph g(n, m);

    for(i=1; i<=e; i++)
    {
        in>>a>>b;
        g.addEdge(a, b);
    }

    g.hopcroftKarp();

    return 0;
}
