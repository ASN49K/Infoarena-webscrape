#include <bits/stdc++.h>
using namespace std;

int n, m, e;
vector<int> adj[10007], dist, upair, vpair;

bool dfs(int u) {
  if (u == n) return true;
  for (int v : adj[u]) {
    if (dist[vpair[v]] == dist[u] + 1) {
      if (dfs(vpair[v])) {
        vpair[v] = u;
        upair[u] =v;
        return true;
      }
    }
  }
  dist[u] = INT_MAX;
  return false;
}

bool bfs() {
  queue<int> q;
  for (int u = 0; u < n; u++) {
    if (upair[u] != m) dist[u] = INT_MAX;
    else dist[u] = 0, q.push(u);
  }
  dist[n] = INT_MAX;
  while (!q.empty()) {
    int u = q.front();
    q.pop();
    if (dist[u] >= dist[n]) continue;;
    for (int v : adj[u]) {
      if (dist[vpair[v]] == INT_MAX) {
        dist[vpair[v]] = dist[u] + 1;
        q.push(vpair[v]);
      }
    }
  }
  return dist[n] != INT_MAX;
}

void solve() {
  cin >> n >> m >> e;
  dist.resize(n + 1);
  upair.resize(n, m);
  vpair.resize(m, n);
  for (int i = 0; i < e; i++) {
    int u, v;
    cin >> u >> v;
    adj[u - 1].push_back(v - 1);
  }

  while (bfs()) {
    for (int u = 0; u < n; u++) {
      if (upair[u] == m) {
        dfs(u);
      }
    }
  }

  vector<pair<int, int>> mat;

  for (int u = 0; u < n; u++) {
    if (upair[u] == m) continue;
    mat.push_back({u, upair[u]});
  }

  cout << mat.size() << endl;

  for (auto [u, v] : mat) {
    cout << u + 1 << ' ' << v + 1 << '\n';
  }
}

int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("cuplaj.in", "r", stdin);
  freopen("cuplaj.out", "w", stdout);
  #endif

  ios_base::sync_with_stdio(false), cin.tie(NULL);

  solve();
}
