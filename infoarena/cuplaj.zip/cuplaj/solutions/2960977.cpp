#include <bits/stdc++.h>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n,m,e,graf[200000][20000],a,b,rgraf[20000][20000];
bool functie_sort(pair<int,int>a, pair<int, int> b)
{
    return a.second<b.second;
}
bool bfs(int rgraf[20000][20000], int tata[], int n)
{
    bool vizitat[n+m+1];
    for(int i=0;i<=n+m+1;i++)
        vizitat[i] = false;

    queue<int> q;
    q.push(0);
    vizitat[0] = true;
    tata[0] = -1;

    while(!q.empty())
    {
        int u = q.front();
        q.pop();

        for(int i = 0; i<=n+m+1;i++)
        {
            if(vizitat[i] == false && rgraf[u][i] > 0)
            {
                if(i == n+m+1)
                {
                    tata[i] = u;
                    return true;
                }

                q.push(i);
                tata[i] = u;
                vizitat[i] = true;
            }
        }
    }

    return false;

}
int main()
{
    fin>>n>>m>>e;
    for(int i=0;i<e;i++)
    {
        fin>>a>>b;
        graf[a][n+b] = 1;
    }

    for(int i=1;i<=n;i++)
    {
        graf[0][i] = 1;
    }
    for(int i=1;i<=m;i++)
    {
        graf[n+i][n+m+1] = 1;
    }

    for(int i=0;i<=n+m+1;i++)
        for(int j=0;j<=n+m+1;j++)
        {
            rgraf[i][j] = graf[i][j];
        }

    int tata[n+m+1];

    while(bfs(rgraf, tata, n))
    {
        int capacitate_drum = INT_MAX;

        for(int i=n+m+1; i!=0; i = tata[i])
        {
            int u = tata[i];
            capacitate_drum = min(capacitate_drum, rgraf[u][i]);
        }

        for(int i=n+m+1; i!=0; i = tata[i])
        {
            int u = tata[i];
            rgraf[u][i] -= capacitate_drum;
            rgraf[i][u] += capacitate_drum;
        }
    }

    int nr_muchii=0;
    vector<pair<int,int>> muchii;
    for(int i=n+1;i<=n+m;i++)
    {
        for(int j=1;j<=n;j++)
        {
            if(rgraf[i][j] == 1)
            {
                nr_muchii++;
                muchii.push_back(make_pair(i-n,j));
            }
        }
    }

    sort(muchii.begin(),muchii.end(), functie_sort);
    fout<<nr_muchii<<endl;
    for(pair<int,int> i : muchii)
    {
        fout<<i.second<<" "<<i.first<<endl;
    }
    return 0;
}