#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

#define pii pair <int, int>

string filename = "cuplaj";

#ifdef LOCAL
    ifstream fin("input.in");
    ofstream fout("output.out");
#else
    ifstream fin(filename + ".in");
    ofstream fout(filename + ".out");
#endif

const int NMAX = 1e4;

vector <int> adj[NMAX + 1];

int l[NMAX + 1];
int r[NMAX + 1];

bool viz[NMAX + 1];

bool pairUp(int node){
    if(viz[node]){
        return false;
    }
    viz[node] = true;

    for(int vec : adj[node]){
        if(r[vec] == 0){
            l[node] = vec;
            r[vec] = node;
            return true;
        }
    }

    for(int vec : adj[node]){
        if(pairUp(r[vec])){
            l[node] = vec;
            r[vec] = node;
            return true;
        }
    }

    return false;
}

int main(){

    int n, m, e;
    fin >> n >> m >> e;

    for(int i = 1; i <= e; i++){
        int a, b;
        fin >> a >> b;
        adj[a].push_back(b);
    }

    while(true){
        bool ok = false;

        for(int i = 1; i <= n; i++){
            viz[i] = false;
        }

        for(int i = 1; i <= n; i++){
            if(l[i] == 0){
                ok |= pairUp(i);
            }
        }

        if(!ok){
            break;
        }
    }

    int ans = 0;
    for(int i = 1; i <= n; i++){
        if(l[i]){
            ans++;
        }
    }

    fout << ans << '\n';
    for(int i = 1; i <= n; i++){
        if(l[i]){
            fout << i << ' ' << l[i] << '\n';
        }
    }
    fout << '\n';

    return 0;
}
