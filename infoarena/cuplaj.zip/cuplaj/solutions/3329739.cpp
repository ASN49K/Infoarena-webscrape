#include<fstream>
#include<iostream>
#include <queue>
#include <cstring>
#define NMX 20005
using namespace std;
int tata[NMX],n1,n2,m,viz[NMX],src,tg;
//vector<int> l[NMX];
vector<int> lrezid[NMX];
int rezid[NMX][NMX]={0};

int bfs( ){
    int i,s=0,x,t=tg;
    for(i=0;i<=tg;i++)
    	viz[i]=tata[i]=0;
    queue<int> c;

    c.push(s);
    viz[s]=1;
    while(c.size()>0){
        x=c.front();
        c.pop();

        for(int y:lrezid[x]){
            if(viz[y]==0 && rezid[x][y]>0){
                tata[y]=x;
                if(y==tg)
                    return 1;
                c.push(y);
                viz[y]=1;
            }
        }

    }
    return 0;
}

int main(){
     ifstream fs("cuplaj.in");

     int i,x,y,j;
     int c;

     fs>>n1>>n2>>m;
     src=0;
     tg=n1+n2+1;
     for(int i=1;i<=n1;i++){
        lrezid[0].push_back(i);
        rezid[0][i]=1;}
     for(int i=n1+1;i<=n1+n2;i++){
        lrezid[i].push_back(tg);
        rezid[i][tg]=1;
     }

     for(i=0;i<m;i++){
         fs>>x>>y;
          lrezid[x].push_back(y+n1);
         lrezid[y+n1].push_back(x);

         rezid[x][y+n1]=1;

     }

     fs.close();
ofstream g("cuplaj.out");

     int fmax=0;
     while(bfs()){

          int iP=1;
          /*
          int t=n-1;

           while(t!=0)  {

                if(iP>rezid[tata[t]][t])
                    iP= rezid[tata[t]][t];
                t=tata[t];
            }
          */

          int t=tg;
          while(t!=src)  {
               rezid[tata[t]][t]-=iP;
                rezid[t][tata[t]]+=iP;
                t=tata[t];
          }
          fmax+=iP;

     }

     g<<fmax<<endl;

         g.close();

     return 0;
}
