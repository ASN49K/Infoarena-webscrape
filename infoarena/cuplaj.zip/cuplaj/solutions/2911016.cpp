#include <bits/stdc++.h>
#define N 10005
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n1,n2,m,cuplaj;
vector<int>g[N];
int st[N],dr[N];
bitset<N>viz;
bool pair_up(int x)
{
    if(viz[x]) return 0;
    viz[x]=1;
    for(auto i:g[x])
        if(!dr[i])
    {
        st[x]=i;dr[i]=x;
        return 1;
    }
    for(auto i:g[x])
        if(pair_up(dr[i]))
    {
        st[x]=i;dr[i]=x;
        return 1;
    }
    return 0;
}
int main()
{
    int i,x,y;
    fin>>n1>>n2>>m;
    while(m--)
    {
        fin>>x>>y;
        g[x].push_back(y);
    }
    bool ok=1;
    while(ok)
    {
        ok=0;viz.reset();
        for(int i=1;i<=n1;i++)
            if(!st[i]) ok|=pair_up(i);
    }
    for(int i=1;i<=n1;i++) cuplaj+=!!st[i];
    fout<<cuplaj<<"\n";
    for(int i=1;i<=n1;i++)
        if(st[i]) fout<<i<<" "<<st[i]<<"\n";
    return 0;
}
