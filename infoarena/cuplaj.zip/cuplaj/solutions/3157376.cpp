#include <bits/stdc++.h>

using namespace std;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

int n, m, p;
int l[10001], r[10001];
bool viz[10001];
vector<int> graph[10001];

void read() {
  f>>n>>m>>p;
  int x, y;
  for(int i = 1;i <= p;++i) {
    f>>x>>y;
    graph[x].push_back(y);
  }
}

bool find(const int& node) {
  if(viz[node]) {
    return false;
  }
  viz[node] = true;
  for(const auto& ngh : graph[node]) {
    if(!r[ngh]) {
      r[ngh] = node;
      l[node] = ngh;
      return true;
    }
  }
  for(const auto& ngh : graph[node]) {
    if(find(r[ngh])) {
      r[ngh] = node;
      l[node] = ngh;
      return true;
    }
  }

  return false;
}

void solve() {
 bool change = true;
 while(change) {
    change = false;
    memset(viz, false, sizeof(viz));

    for(int i = 1;i <= n;++i) {
      if(!l[i]) {
          change |= find(i);
      }
    }
 }
  
  int sum = 0;
  for(int i = 1;i <= n;++i) {
    if(l[i]) {
      sum++;
    }
  }
  g<<sum<<'\n';
  for(int i = 1;i <= n;++i) {
    if(l[i]) {
      g<<i<<" "<<l[i]<<'\n';
    }
  }
}

int main() {
  
  read();
  solve();

  return 0;
}
