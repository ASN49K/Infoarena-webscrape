#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
#include <cmath>
#include <climits>

using namespace std;

int n,m,nr; //nr- nr total de noduri
//nr-1 - nodul start
//nr - nodul destinatie
int tata[20001], viz[20001];
int capacitate [10001][10001];
int flux[10001][10001];

int construire_lant()
{
    int i,j,u,v,w,flx;
    
    for(i=1; i<=nr; i++)
    {
        tata[i]=0;
        viz[i]=0;
    }

    queue<int> q;

    q.push(nr-1);
    viz[nr-1]=1;

    while(!q.empty())
    {
        u=q.front();
        q.pop();
        
        for(i=1;i<=nr;i++) //arcele directe
        if(i!=u)
        {
            v=i;
            w=capacitate[u][v]; //capacitatea
            flx=flux[u][v]; //fluxul trimis
            if(viz[v]==0 && w-flx>0)
            {
                q.push(v);
                viz[v]=1;
                tata[v]=u;
                if(v==nr)
                    return 1;
            }
        }

        for(i=1;i<=nr;i++)
        if(i!=u)
        {    
            v=i;
            flx=flux[v][u];
            if(viz[v]==0 && flx>0)
            {
                q.push(v);
                viz[v]=1;
                tata[v]=-u;
                if(v==nr)
                    return 1;
            }
        }
                    
    }
    
    return 0;
}

void revizuieste_lant()
{
    int i,x,t,w,min_f=INT_MAX;
    x=nr;
    
    while(x!=nr-1)
    {
        t=tata[x];
        if(t>0)
        {    
            w=capacitate[t][x] - flux[t][x];
        }
        else
            {
            t=abs(t);
            w=flux[x][t];
            }
        min_f=min(min_f,w);
        x=t;
    }
    x=nr;
    while(x!=nr-1)
    {
        t=tata[x];
        if(t>0)
            flux[t][x]+=min_f;
        else
            {
            t=abs(t);
            flux[x][t]-=min_f;
            }
        x=t;
    }
}


int main()
{
    ifstream f("cuplaj.in");
    ofstream g("cuplaj.out");

    int x, y, c, i, j, n2;

    f >> n>> n2 >> m;
    
    for (i = 1; i <= m; i++)
    {
        f >> x >> y;
        capacitate[x][y+n]=1;
    }
    nr=n+n2+2;

    for(i=1;i<=n;i++)
        capacitate[nr-1][i]=1;
    
    for(i=n+1;i<=n2+n;i++)
        capacitate[i][nr]=1;
 

    while(construire_lant()==1)
        revizuieste_lant();

    int s=0;
    for(i=1;i<=nr-2;i++)
        for(j=1;j<=nr-2;j++)
            if(flux[i][j]!=0)
                s++;

    g<<s<<endl;

    for(i=1;i<=nr-2;i++)
        for(j=1;j<=nr-2;j++)
            if(flux[i][j]!=0)
                g<<i<<' '<<j-n<<endl;
    return 0;
}