#include <bits/stdc++.h>
using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int n,i,y,m,l[20005],e,x,cnt,mt[20005];
vector<int>v[20005];
bool ok=1;
bool used[20005];

bool kk(int k)
{
    if(used[k])return false;

    used[k]=true;

    for(auto i : v[k])
    if(l[i]==-1 || kk(l[i])){
        l[i]=k;

        return true;
    }
    return false;
}

int main(){

    fin>>n>>m>>e;

    for(i=1;i<=e;i++){
        fin>>x>>y;
        v[x].push_back(y+n);

    }

    for(i=1;i<=n+m;i++)l[i]=mt[i]=-1;

    while(ok){
        ok=0;
       for(i=1;i<=n;i++)used[i]=false;

        for(i=1;i<=n;i++)
            if(l[i]==-1)
            ok|=kk(i);
    }

      for(i=1;i<=n+m;i++)
        if(l[i]!=-1)cnt++;

    fout<<cnt<<'\n';
    for(i=n+1;i<=n+m;i++)
        if(l[i]!=-1)fout<<l[i]<<" "<<i-n<<'\n';

}
