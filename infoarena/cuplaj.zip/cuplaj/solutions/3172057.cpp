#include <bits/stdc++.h>
using namespace std;

const int nmax = 1e4 + 7;

int n, m, e;
vector<int> adj[nmax];
int upair[nmax];
int vpair[nmax];
int dist[nmax];


bool bfs() {
  queue<int> q;
  for (int i = 1; i <= n; i++) {
    if (upair[i] == 0) dist[i] = 0, q.push(i);
    else dist[i] = INT_MAX;
  }
  dist[0] = INT_MAX;

  while (!q.empty()) {
    int u = q.front();
    q.pop();
    if (dist[u] == dist[0]) continue;
    for (int v : adj[u]) {
      if (dist[vpair[v]] == INT_MAX) {
        dist[vpair[v]] = dist[u] + 1;
        q.push(vpair[v]);
      }
    }
  }

  return dist[0] != INT_MAX;
}

bool dfs(int u) {
  if (u == 0) return true;
  for (int v : adj[u]) {
    if (dist[vpair[v]] == dist[u] + 1) {
      if (dfs(vpair[v])) {
        upair[u] = v;
        vpair[v] = u;
        return true;
      }
    }
  }

  dist[u] = INT_MAX;
  return false;
}

void solve() {

  cin >> n >> m >> e;

  for (int i = 0; i < e; i++) {
    int u, v;
    cin >> u >> v;
    adj[u].push_back(v);
  }

  int cnt = 0;

  while (bfs()) {
    for (int u = 1; u <= n; u++) {
      if (upair[u] == 0) {
        cnt += dfs(u);
      }
    }
  }

  cout << cnt << '\n';
  
  for (int u = 1; u <= n; u++) {
    if (upair[u] == 0) continue;
    cout << u << ' ' << upair[u] << '\n';
  }



}


int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("cuplaj.in", "r", stdin);
  freopen("cuplaj.out", "w", stdout);
  #endif

  solve();

}