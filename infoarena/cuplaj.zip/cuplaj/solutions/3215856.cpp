#include <bits/stdc++.h>

#define NMAX 10002

using namespace std;

ifstream fin ("cuplaj.in");
ofstream fout ("cuplaj.out");

int n, m, e, l[NMAX], r[NMAX];
vector<int> G[NMAX];
bitset<NMAX> viz;

void read_data()
{
    fin >> n >> m >> e;
    for (int i = 1; i <= e; i++)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
    }
}

bool match(int nod)
{
    if (viz[nod]) return false;
    viz[nod] = true;

    for (auto it : G[nod])
    {
        if (r[it] == 0)
        {
            l[nod] = it;
            r[it] = nod;
            return true;
        }
        if (match(r[it]))
        {
            l[nod] = it;
            r[it] = nod;
            return true;
        }
    }
    return false;
}

int main()
{
    read_data();

    bool ok = true;
    while (ok)
    {
        ok = false;
        viz.reset();

        for (int i = 1; i <= n; i++)
            if (l[i] == 0) ok |= match(i);
    }

    int sol = 0;
    for (int i = 1; i <= n; i++)
        if (l[i]) sol++;

    fout << sol << "\n";
    for (int i = 1; i <= n; i++)
        if (l[i]) fout << i << " " << l[i] << "\n";

    fin.close();
    fout.close();

    return 0;
}
