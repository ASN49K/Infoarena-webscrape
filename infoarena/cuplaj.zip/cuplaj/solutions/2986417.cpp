#include <fstream>
#include <vector>
#include <queue>
#include <bitset>
using namespace std;
ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");
const int N = 10009, M = 10009;
int n,m,e,C[2*N][2*N],t[2*N],a,b;
vector<vector<int>> G;
queue<int> q;
bitset<2*N> v;


bool Bfs(int source,int sink)
{
    v.reset();
    v[source] = true;
    q.push(source);

    while(!q.empty())
    {
        int x = q.front();
        q.pop();

        for(auto y : G[x])
            if(!v[y] && C[x][y])
            {
                v[y] = true;
                t[y] = x;
                q.push(y);
            }
    }

    return v[sink];
}
void Augment(int source,int sink)
{
    for(int i = sink; i != source; i = t[i])
        C[t[i]][i]--,
        C[i][t[i]]++;
}
int FluxMaxim(int source,int sink)
{
    int F = 0;
    for(;Bfs(source,sink);++F,Augment(source,sink));
    return F;
}
int main()
{
    cin>>n>>m>>e;
    G = vector<vector<int>>(n+m+3);
    while(e--)
    {
        cin>>a>>b;
        G[a].push_back(b+n);
        G[b+n].push_back(a);
        C[a][b+n] = 1;
    }
    for(int i = 1; i <= n; ++i)
    {
        G[0].push_back(i);
        C[0][i] = 1;
    }
    for(int i = 1; i <= m; ++i)
    {
        G[n+i].push_back(n+m+1);
        C[n+i][n+m+1] = 1;
    }

    cout<<FluxMaxim(0,n+m+1)<<'\n';
    for(int i = 1; i <= n; ++i)
        for(auto j : G[i])
            if(C[i][j] == 0)
                cout<<i<<' '<<j-n<<'\n';
    return 0;
}
