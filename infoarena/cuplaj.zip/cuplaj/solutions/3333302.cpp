#include <bits/stdc++.h>

using namespace std;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

const int nmax=1e4+5;

int n,m,e;
int st[nmax],dr[nmax];

bool used[nmax];
bool change;

vector <int> gr[nmax];

bool cupleaza(int nod)
{
    if ( used[nod] ) return false;

    used[nod]=true;

    for (auto x:gr[nod] )
    {
        if ( !dr[x] )
        {
            st[nod]=x;
            dr[x]=nod;

            return true;
        }
    }

    for (auto x:gr[nod] )
    {
        if ( cupleaza(dr[x]) )
        {
            st[nod]=x;
            dr[x]=nod;
            return true;
        }
    }

    return false;
}

void reset()
{
    change=false;
    for (int i=1; i<=n; i++ )
        used[i]=false;
}

int main()
{
    f >> n >> m >> e;

    for (int i=1; i<=e; i++ )
    {
        int x,y; f >> x >> y;
        gr[x].push_back(y);
    }

    change=true;
    while ( change==true )
    {
        reset();

        for (int i=1; i<=n; i++ )
            if ( !st[i] && cupleaza(i) )
                change=true;
    }

    int nr=0;
    for (int i=1; i<=n; i++ )
        if ( st[i]>0 )
            nr++;

    g << nr << '\n';
    for (int i=1; i<=n; i++ )
        if ( st[i]>0 )
            g << i << " " << st[i] << '\n';

    return 0;
}
