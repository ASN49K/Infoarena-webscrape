#include <fstream>
#include <queue>
#include <vector>
#include <cstring>
using namespace std;
ifstream f("cuplaj.in");
ofstream g("cuplaj.out");
vector<int> v[10005];
int couple[2][10005],viz[10005],lastit;
bool wingman(int y)
{
    viz[y]=lastit;
    for(auto i:v[y])
        if(!couple[1][i])
    {
        couple[1][i]=y, couple[0][y]=i;
        return true;
    }
    for(auto i:v[y])
        if(viz[couple[1][i]]!=lastit&&wingman(couple[1][i]))
    {
        couple[1][i]=y, couple[0][y]=i;
        return true;
    }
    return false;
}
int main()
{
    int n,m,e;
    f>>n>>m>>e;
    for(int i=1;i<=e;i++)
    {
        int a,b;
        f>>a>>b;
        v[a].push_back(b);
    }
    int cnt=0,ok=1;
    while(ok)
    {
        ok=0;
        for(int i=1;i<=n;i++)
            if(!couple[0][i])
        {
            lastit++;
            if(wingman(i))
                ok++, cnt++;
        }
    }
    g<<cnt<<'\n';
        for(int i=1;i<=n;i++)
            if(couple[0][i])
                g<<i<<" "<<couple[0][i]<<'\n';
    return 0;
}