#include <bits/stdc++.h>

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

const int NMAX = 20005;

int n, m, e;
vector<int> g[NMAX];
int st[NMAX], dr[NMAX];
bool used[NMAX];

bool cuplaj(int nod)
{
    if(used[nod])
        return false;
    used[nod] = true;
    for(auto it : g[nod])
        if(!dr[it])
        {
            dr[it] = nod;
            st[nod] = it;
            return true;
        }
    for(auto it : g[nod])
        if(cuplaj(dr[it]))
        {
            dr[it] = nod;
            st[nod] = it;
            return true;
        }
    return false;
}

int main()
{
    fin >> n >> m >> e;
    for(int i = 1; i <= e; i++)
    {
        int u, v;
        fin >> u >> v;
        v += n;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    bool ok = 1;
    while(ok)
    {
        ok = 0;
        memset(used, 0, sizeof(used));
        for(int i = 1; i <= n; i++)
            if(!st[i])
                ok |= cuplaj(i);
    }
    int ans = 0;
    for(int i = 1; i <= n; i++)
        ans += (bool) st[i];
    fout << ans << '\n';
    for(int i = 1; i <= n; i++)
        if(st[i])
            fout << i << ' ' << st[i] - n << '\n';
    return 0;
}
