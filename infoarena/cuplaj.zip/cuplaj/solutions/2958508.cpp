/*
 * Edmonds-Karp's algorithm
 * https://www.infoarena.ro/problema/cuplaj
 */
#include <bits/stdc++.h>

using namespace std;

ifstream in("cuplaj.in");
ofstream out("cuplaj.out");

int leftSize, rightSize, edges, s, t;
vector<pair<int, int>> parrent; // parrent[u] = {v, adjListRes[v].second.second} where adjListRes[v].first = u
vector<vector<pair<int, pair<int, int>>>> adjListRes; // adjList[u] = {v, {0/1, index}}

void addEdge(int u, int v){
    adjListRes[u].push_back({v, {1, adjListRes[u].size()}});
    adjListRes[v].push_back({u, {0, adjListRes[v].size()}});
}

void init() {
    s = 0;
    t = leftSize+rightSize+1;
    parrent.resize(t+1);
    adjListRes.resize(t+1);
    for(int i = 1; i <= leftSize; i++)
        addEdge(s, i);
    for(int i = 1; i <= rightSize; i++)
        addEdge(leftSize+i, t);
}

void read(){
    in >> leftSize >> rightSize >> edges;
    init();
    for(int i = 1; i <= edges; i++){
        int u, v;
        in >> u >> v;
        addEdge(u, leftSize + v);
    }
}

bool bf(){
    vector<bool> visited(t+1);
    queue<int> q;
    q.push(s);
    visited[s] = true;
    parrent[s] = {-1, -1};
    while(!q.empty()){
        int u = q.front();
        q.pop();
        for(auto node: adjListRes[u]){
            int v, c, i; // node, capacity, index
            v = node.first;
            c = node.second.first;
            i = node.second.second;
            if(!visited[v] and c){
                parrent[v] = {u, i}; // adjListRes[u][i].first == v
                if(v == t)
                    return true;
                visited[v] = true;
                q.push(v);
            }
        }
    }
    return false;
}

int maxFlow(){
    long max_flow = 0;
    set<int> temp;
    while(bf()){
        int v, u, i, j;
        v = t;
        while(parrent[v].first != -1){
            u = parrent[v].first;
            i = parrent[v].second;
            adjListRes[u][i].second.first = 0;
            j = 0;
            while(adjListRes[v][j].first != u)
                j++;
            adjListRes[v][j].second.first = 1;
            v = u;
        }
        max_flow += 1;
    }
    return max_flow;
}

int main() {
    read();
    out << maxFlow() << '\n';
    return 0;
}