#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
struct Flow {
  const int INF = (int)1e9 + 7;
  int n;

  struct Edge {
    int to, cap;
  };

  vector<Edge> edges;
  vector<vector<int>> g;
  vector<int> level, pt;

  Flow(int n) :
    n(n),
    g(n),
    level(n),
    pt(n) {
  }

  void addEdge(int a, int b, int c) {
    a--, b--;
    assert(0 <= a && a < n);
    assert(0 <= b && b < n);
    g[a].push_back((int)edges.size());
    g[b].push_back((int)edges.size() + 1);
    edges.push_back({ b, c });
    edges.push_back({ a, 0 });
  }

  int dfs(int a, int cur) {
    if (a == n - 1 || cur == 0) return cur;

    while (pt[a] < (int)g[a].size()) {
      int i = g[a][pt[a]++];
      int b = edges[i].to, cap = edges[i].cap;
      if (level[b] == 1 + level[a] && cap) {
        int x = dfs(b, min(cur, cap));
        if (x) {
          pt[a]--;

          edges[i].cap -= x;
          edges[i ^ 1].cap += x;

          return x;
        }
      }
    }

    return 0;
  }

  int get() {
    int sol = 0;
    while (1) {
      for (int i = 0; i < n; i++) level[i] = -1, pt[i] = 0;
      level[0] = 0;
      queue<int> q;
      q.push(0);
      while (!q.empty()) {
        int a = q.front();
        q.pop();
        for (auto& i : g[a]) {
          if (edges[i].cap&&level[edges[i].to]==-1) {
            level[edges[i].to] = 1 + level[a];
            q.push(edges[i].to);
          }
        }
      }
      if (level[n - 1] == -1) break;
      while (1) {
        int x = dfs(0, INF);
        if (!x) break;
        sol += x;
      }
    }
    return sol;
  }

  vector<bool> get_min_cut_side() {
    vector<bool> marked(n, 0);
    queue<int> q;
    q.push(0);
    marked[0] = 1;
    while (!q.empty()) {
      int a = q.front();
      q.pop();
      for (auto &i : g[a]) {
        if (edges[i].cap && !marked[edges[i].to]) {
          marked[edges[i].to] = 1;
          q.push(edges[i].to);
        }
      }
    }
    return marked;
  }
};
signed main()
{
#ifdef ONPC
  freopen ("input.txt", "r", stdin);
#endif // ONPC
#ifndef ONPC
  ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
  freopen ("cuplaj.in", "r", stdin);
  freopen ("cuplaj.out", "w", stdout);
#endif // ONPC

  int n, m, e;
  cin >> n >> m >> e;
  Flow flow(1 + n + m + 1);
  for (int i = 1; i <= n; i++)
  {
    flow.addEdge(1, 1 + i, 1);
  }
  for (int i = 1; i <= m; i++)
  {
    flow.addEdge(1 + n + i, 1 + n + m + 1, 1);
  }
  for (int i = 1; i <= e; i++)
  {
    int a, b;
    cin >> a >> b;
    assert(1 <= a && a <= n);
    assert(1 <= b && b <= n);
    flow.addEdge(1 + a, 1 + n + b, 1);
  }
  cout << flow.get() << "\n";
  for (int a = 1; a <= n; a++)
  {
    for (auto &i : flow.g[1 + a - 1])
    {
      int b = flow.edges[i].to - 1 - n + 1;
      if (1 <= b && b <= m && flow.edges[i].cap == 0)
      {
        cout << a << " " << b << "\n";
      }
    }
  }
  return 0;
}
/**

**/
