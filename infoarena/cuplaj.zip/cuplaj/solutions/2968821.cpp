#include <bits/stdc++.h>
using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int capacity[21001][21001],n,m,flow,max_flow;
vector<int> visited,parent;
vector<vector<int>> adj_list;

bool bfs()
{
    fill(visited.begin(), visited.end(), 0);
    fill(parent.begin(), parent.end(), 0);

    visited[0] = 1;
    parent[0] = 0;
    queue<int> q;
    q.push(0);

    while(!q.empty())
    {
        int nod = q.front();

        q.pop();

        if(nod == n+m+1)
            return true;

        for(int i=0; i<adj_list[nod].size(); i++)
        {
            if(!visited[adj_list[nod][i]] && capacity[nod][adj_list[nod][i]] > 0)
            {
                q.push(adj_list[nod][i]);
                parent[adj_list[nod][i]] = nod;
                visited[adj_list[nod][i]] = 1;
            }
        }
    }

    return false;


}

int main()
{
    int a,b,c,e;
    fin>>n>>m>>e;
    visited.resize(n+m+2, 0);
    parent.resize(n+m+2, 0);
    adj_list.resize(n+m+2, {});

    for(int i=1; i<=e; i++)
    {
        fin>>b>>c;
        adj_list[b].push_back(c+n);
        capacity[b][c+n] = 1;
        adj_list[c+n].push_back(b);
        adj_list[0].push_back(b);
        adj_list[b].push_back(0);
        capacity[0][b] = 1;
        adj_list[c+n].push_back(n+m+1);
        adj_list[n+m+1].push_back(c+n);
        capacity[c+n][n+m+1] = 1;
    }

    int reusit = bfs();

    while(reusit)
    {
        for(int i=0; i<adj_list[n+m+1].size(); i++)
        {
            if(visited[adj_list[n+m+1][i]])
            {
                parent[n+m+1] = adj_list[n+m+1][i];
                flow = INT_MAX;
                for(int j=n+m+1; j!=0; j=parent[j])
                {
                    flow=min(flow, capacity[parent[j]][j]);
                }
                if(flow != 0)
                {
                    for(int j=n+m+1; j!=0; j=parent[j])
                    {
                        capacity[parent[j]][j] -= flow;
                        capacity[j][parent[j]] += flow;
                    }
                    max_flow += flow;
                }
            }
        }
        reusit = bfs();
    }
    fout<<max_flow<<'\n';

    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=m+1; j++)
        {
            if(capacity[i][j+n] == 0 && capacity[j+n][i] == 1)
                fout<<i<<' '<<j<<'\n';
        }
    }

    return 0;
}
