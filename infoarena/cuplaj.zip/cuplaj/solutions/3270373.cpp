#include <iostream>
#include <vector>

#define NMAX 10000

using namespace std;
FILE *in=fopen("cuplaj.in", "r"), *out=fopen("cuplaj.out", "w");

int n, m, p, x, y, nm, mx;
vector<int> adc[NMAX+2];
vector<bool> us;
vector<pair<int, int>> af;
vector<int> mt;

bool kuhn(int v)
{
    if(us[v]==1)
        return  0;
    
    us[v]=1;
    for(auto it : adc[v])
    {
        if(mt[it]==-1 || kuhn(mt[it]))
        {
            mt[it]=v;
            return 1;
        }
    }
    return 0;
}

int main()
{
    fscanf(in, "%d %d %d", &n, &m, &p);
    for(int i=1; i<=p; i++)
    {
        fscanf(in, "%d %d", &x, &y);
        y += n;
        adc[x].push_back(y);
        adc[y].push_back(x);
    }

    mt.assign(n+m+1, -1);
    for(int i=1; i<=n; i++)
    {
        us.assign(n+m+1, 0);
        //us.assign(n+1, 0);
        kuhn(i);
    }

    for(int j=n; j<=n+m; j++)
        if(mt[j]!=-1)
            af.push_back({mt[j], j-n});

    fprintf(out, "%d\n", af.size());
    for(auto i=af.begin(); i!=af.end(); i++)
    {
        fprintf(out, "%d %d\n", (*i).first, (*i).second);
    }

}