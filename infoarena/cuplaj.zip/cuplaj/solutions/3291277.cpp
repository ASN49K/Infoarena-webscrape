#include <bits/stdc++.h>

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n, m, e, i, j, x, y;
int m1[10002], m2[10002];
vector<int> a[10002];
bool fr[10002];

static inline bool Cupleaza(int nod) {
    if(fr[nod]) return false;
    fr[nod] = true;

    for(int urm : a[nod]) {
        if(m2[urm] == 0) {
            m1[nod] = urm;
            m2[urm] = nod;
            return true;
        }
    }

    for(int urm : a[nod]) {
        if(Cupleaza(m2[urm])) {
            m1[nod] = urm;
            m2[urm] = nod;
            return true;
        }
    }
    return false;
}

int main() {
    fin >> n >> m >> e;
    while(e--) {
        fin >> x >> y;
        a[x].push_back(y);
    }

    bool ok;
    do {
        memset(fr, false, sizeof(fr));
        ok = false;

        for(i = 1; i <= n; i++) {
            if(m1[i] == 0) ok |= Cupleaza(i);
        }
    }
    while(ok);

    fout << min(n, m) << "\n";
    for(i = 1; i <= n; i++) {
        if(m1[i] != 0) fout << i << " " << m1[i] << "\n";
    }

    return 0;
}
