#include<bits/stdc++.h>

using namespace std;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

int nr_noduri, dest;
vector<vector<int>> adj;
int element, nod, flux_maxim=0, flux_minim, firstelem, k=0;
vector<int> tata;
vector<bool> vizitat;
queue<int> coada;

struct muchie
{
    int nod1,nod2,flux,poz;
};

vector<muchie> muchii;



int creare_lant()
{

    while(!coada.empty()) coada.pop();

    tata.clear();
    tata.resize(nr_noduri+1,0);
    vizitat.clear();
    vizitat.resize(nr_noduri+1,false);

    coada.push(0);
    vizitat[0]=true;

    while(!coada.empty())
        {
        firstelem=coada.front();
        coada.pop();

        if(firstelem!=dest)
        {
            for(auto p:adj[firstelem])
        {

            muchie edge=muchii[p];
            if(vizitat[edge.nod2]==false && edge.flux!=0)
            {
                coada.push(edge.nod2);
                vizitat[edge.nod2]=true;
                tata[edge.nod2]=p;
            }
        }

    }
        }
        return vizitat[dest];

}

void revizuire_flux()
{

    for(auto p:adj[dest])
    {
        muchie edge=muchii[p];
        if(muchii[edge.poz].flux!=0 && vizitat[edge.nod2]==true)

    {
        element = dest;
        tata[dest] = edge.poz;
        flux_minim=INT_MAX;

        while (element!=0)
        {
            if (flux_minim > muchii[tata[element]].flux)
                flux_minim = muchii[tata[element]].flux;

            element = muchii[tata[element]].nod1;


        }

        element = dest;

        while (element!=0)
        {

            muchii[tata[element]].flux-= flux_minim;

            muchii[muchii[tata[element]].poz].flux += flux_minim;



            element = muchii[tata[element]].nod1;

        }

        flux_maxim = flux_maxim + flux_minim;

    }
    }
}



int main()
{

    int card_L, card_R, nr_muchii;
    f>>card_L>>card_R>>nr_muchii;

    nr_noduri = card_L+card_R+2;

    dest=nr_noduri-1;

    adj.resize(nr_noduri+1);
    tata.resize(nr_noduri+1);
    vizitat.resize(nr_noduri+1);
    int x,y;

    for(int i=1;i<=nr_muchii;i++)
    {
        f>>x>>y;
        muchii.push_back({x,y+card_L,1,2*i-1});
        muchii.push_back({y+card_L,x,0,2*i-2});

        adj[y+card_L].push_back(2*i-1);
        adj[x].push_back(2*i-2);


    }


    int dim_muchii = int(muchii.size());

    for (int i = 1;i <= card_L;i++)
    {
        dim_muchii += 2;
        muchii.push_back({0,i,1, dim_muchii-1});
        adj[i].push_back(dim_muchii-1);
        muchii.push_back({i,0,0,dim_muchii-2});
        adj[0].push_back(dim_muchii-2);


    }

    for (int i=card_L+1;i <nr_noduri-1; i++)
    {
        dim_muchii+=2;
        muchii.push_back({i,dest,1,dim_muchii- 1});
        adj[dest].push_back(dim_muchii-1);
        muchii.push_back({dest,i,0,dim_muchii-2});
        adj[i].push_back(dim_muchii-2);
    }

    while(creare_lant())
    {
        revizuire_flux();
    }

    g<<flux_maxim<<'\n';


    for (auto p: muchii)
    {
        if (p.flux==0 && p.nod1!=0 && p.nod2!=dest &&p.nod1<p.nod2)
        {
            g<<p.nod1<<' '<<p.nod2-card_L<<'\n';
        }
    }



}
