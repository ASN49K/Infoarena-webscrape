#include <bits/stdc++.h>
using namespace std;

class Cuplaj {

  const int n, m;
  const vector<vector<int>> adj;
  vector<int> dist, upair, vpair;
  int _matching = 0;

  bool dfs(int u) {
    if (u == n) return true;
    for (int v : adj[u]) {
      if (dist[vpair[v]] == dist[u] + 1) {
        if (dfs(vpair[v])) {
          vpair[v] = u;
          upair[u] = v;
          return true;
        }
      }
    }
    dist[u] = INT_MAX;
    return false;
  }

  bool bfs() {
    queue<int> q;
    for (int i = 0; i < n; i++) {
      if (upair[i] != m) dist[i] = INT_MAX;
      else dist[i] = 0, q.push(i);
    }
    dist[n] = INT_MAX;
    while (!q.empty()) {
      int u = q.front(); q.pop();
      if (dist[u] < dist[n]) {
        for (int v : adj[u]) {
          if (dist[vpair[v]] == INT_MAX) {
            dist[vpair[v]] = dist[u] + 1;
            q.push(vpair[v]);
          }
        }
      }
    }
    return dist[n] != INT_MAX;
  }

  public:

  vector<pair<int, int>> matching() {
    vector<pair<int, int>> res;
    res.reserve(_matching);
    for (int i = 0; i < n; i++) {
      if (upair[i] != m) {
        res.push_back({i, upair[i]});
      }
    }
    return res;
  }

  Cuplaj(int left, int right, const vector<vector<int>>& adjacency_graph) : n(left), m(right), adj(adjacency_graph) {
    dist.resize(n + 1);
    upair.resize(n, m);
    vpair.resize(m, n);
    while (bfs()) {
      for (int i = 0; i < n; i++) {
        if (upair[i] == m) {
          if (dfs(i)) {
            _matching++;
          }
        }
      }
    }
  }
};

void solve() {
  int n, m, e;
  cin >> n >> m >> e;
  vector<vector<int>> adj(n);
  for (int i = 0; i < e; i++) {
    int u, v;
    cin >> u >> v;
    adj[u - 1].push_back(v - 1);
  }

  Cuplaj cuplaj(n, m, adj);

  auto matching = cuplaj.matching();

  cout << matching.size() << '\n';

  for (auto [u, v] : matching) {
    cout << u + 1 << ' ' << v + 1 << '\n';
  }
}

int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("cuplaj.in", "r", stdin);
  freopen("cuplaj.out", "w", stdout);
  #endif

  ios_base::sync_with_stdio(false), cin.tie(NULL);

  solve();
}
