#include <fstream>
#include <vector>

using namespace std;

ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

int n, m, e;

int l[10001], r[10001];

bool used[10001];

vector < int > adj[10001];

bool pairup(int node)
{
    if (used[node])
        return false;

    used[node] = true;

    for (auto it : adj[node])
        if (!r[it])
        {
            l[node] = it;
            r[it] = node;
            return true;
        }

    for (auto it : adj[node])
        if (pairup(r[it]))
        {
            l[node] = it;
            r[it] = node;
            return true;
        }

    return false;
}

int main()
{
    f >> n >> m >> e;

    for (int i = 1; i <= e; i++)
    {
        int x, y; f >> x >> y;
        adj[x].push_back(y);
    }

    while (true)
    {
        for (int i = 1; i <= n; i++)
            used[i] = false;

        bool ok = false;

        for (int i = 1; i <= n; i++)
            if (!l[i])
                ok = ok | pairup(i);

        if (!ok)
            break;
    }

    int cuplaj = 0;

    for (int i = 1; i <= n; i++)
        if (l[i])
            cuplaj++;

    g << cuplaj << "\n";
    for (int i = 1; i <= n; i++)
        if (l[i])
            g << i << " " << l[i] << "\n";

    return 0;
}
