#include <fstream>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <cmath>
#include <random>
#include <ctime>
using namespace std;
class InParser {
    vector<char> str;
    int ptr;
    ifstream fin;
    char getChar() {
        if (ptr == int(str.size())) {
            fin.read(str.data(), str.size());
            ptr = 0;
        }
        return str[ptr++];
    }
    template<class T>
    T getInt() {
        char chr = getChar();
        while (!isdigit(chr) && chr != '-')
            chr = getChar();
        int sgn = +1;
        if (chr == '-') {
            sgn = -1;
            chr = getChar();
        }
        T num = 0;
        while (isdigit(chr)) {
            num = num * 10 + chr - '0';
            chr = getChar();
        }
        return sgn * num;
    }
public:
    InParser(const char* name) : str(1e5), ptr(str.size()), fin(name) { }
    ~InParser() { fin.close(); }

    template<class T>
    friend InParser& operator>>(InParser& in, T& num) {
        num = in.getInt<T>();
        return in;
    }
};

InParser cin("cmap.in");
ofstream cout("cmap.out");
#pragma GCC optimize ("Ofast,unroll-loops")
mt19937 mt(time(nullptr));
// e infoarena deci probabil se ia 100 cu asta
int n;
struct point{int x,y;};
point p[100001];
double formula(point unu, point doi)
{
    return sqrtl(1LL*(unu.x-doi.x)*(unu.x-doi.x)+1LL*(unu.y-doi.y)*(unu.y-doi.y));
}
signed main()
{
    cin >> n;
    for(int i = 1 ; i <= n ; ++i)
    {
        int asta , ala;
        cin >> asta >> ala;
        p[i] = {asta,ala};
    }
    sort(p+1,p+1+n,[](point unu,point doi){
         if(unu.x==doi.x) return (bool)(mt()%2);
         else return unu.x<doi.x;});
    double dist = formula(p[1],p[2]);
    for(int i = 3 ; i <= n ; ++i)
    {
        for(int j = i-1 ; j >= 1 ; --j)
        {
            int d = (int)dist;
            if(p[i].x-p[j].x > d) break;
            dist = min(dist,formula(p[i],p[j]));
        }
    }
    cout << fixed << setprecision(6) << dist ;
    return 0;
}
