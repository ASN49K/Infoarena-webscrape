#include <vector>
#include <fstream>
#define NMAX 10005
using namespace std;
ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");
int n,m,e;
int l[NMAX],r[NMAX];
vector<int>muchii[NMAX];
int use[NMAX];
int cuplaj;

int pairup(int nod)
{
    int i;
    if(use[nod])
        return 0;
    use[nod]=1;
    for(i=0; i<muchii[nod].size(); i++)
        if(r[muchii[nod][i]]==0)
            {
             r[muchii[nod][i]]=nod;
             l[nod]=muchii[nod][i];
             return 1;
            }
    for(i=0; i<muchii[nod].size(); i++)
        if(pairup(r[muchii[nod][i]]))
            {
             r[muchii[nod][i]]=nod;
             l[nod]=muchii[nod][i];
             return 1;
            }
    return 0;
}
int main()
{
    int i,a,b;
    cin>>n>>m>>e;
    for(i=1; i<=e; i++)
    {
        cin>>a>>b;
        muchii[a].push_back(b);
    }
    bool ok;
    do
    {
        ok=0;
        for(i=1; i<=n; i++)
            use[i]=0;
        for(i=1; i<=n; i++)
            if(l[i]==0)
                if(pairup(i))
                    ok=1;
    }
    while(ok);
    for(i=1; i<=n; i++)
        if(l[i]) cuplaj++;
    cout<<cuplaj<<'\n';
    for(i=1; i<=n; i++)
        if(l[i])
            cout<<i<<' '<<l[i]<<'\n';
    return 0;
}
