#include <bits/stdc++.h>
#define dbgv(x) if(COND) {cout << #x << ": "; for (auto k : x) cout << k << " " ; cout << "\n";}
#define dbg(x) if(COND) {cout << #x << "=" << x << "\n";}
#define dbgvmp(x) if(COND) {cout << #x << ": ";int ind = 0; for (auto k : x) {cout << ind++ << ": "; for (auto p : k) cout << "{" << p.first << "," << p.second << "} ";  cout << "\n"; } cout << "\n";}
#define dbgvp(x) if(COND) {cout << #x << ": "; for (auto k : x) cout <<"{"<< k.first << "," << k.second << "} "; cout << "\n";}
#define sep if (COND) {cout << "\n---------------------\n";}
#define dbgq(x) if(COND) {cout << #x << ": "; stack<pp> cl = q; while(!cl.empty()) {cout << "{" << cl.top().first << "," << cl.top().second << "} "; cl.pop();} cout << "\n"; }
#define brk(x) if (x) COND = true; else COND = false;

using namespace std;

bool COND = true;

#ifdef LOCAL
ifstream in("in.in");
ofstream out("out.out");
#else
ifstream in("cuplaj.in");
ofstream out("cuplaj.out");
#endif

const int nmax = 200005;
int saturated[nmax],viz[nmax],taken[nmax],n,m,e;
vector<pair<int,int>> edges;
vector<vector<pair<int,int>>> g;
bool try_kuhn(int node, int edgeBelongs) {
    viz[node] = 1;


    for (auto k : g[node]) {
        if (viz[k.first] == 1 || taken[k.second] != edgeBelongs) continue;

        if (saturated[k.first] == 0) {

            taken[k.second] = 1;
            saturated[node] = 1;
            saturated[k.first] = 1;
            return true;
        }

                //brk(node == 6);
       // dbg(k.first);
        //dbg(k.second);

        bool res = try_kuhn(k.first ,1- edgeBelongs);


        if (res == true) {
            saturated[node] = 1;
            taken[k.second] = 1 - taken[k.second];
            return true;
        }
    }
    return false;
}
int32_t main() {
    in >> n >> m >> e;
    g.resize(n + m + 1);
    edges.resize(e + 1);
    for (int i = 1; i <= e; i++) {
        int u,v;
        in >> u >> v;
        v += n;
        g[u].push_back({v,i});
        g[v].push_back({u,i});
        edges[i] = {u,v - n};
    }

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n + m; j++) viz[j] = 0;
        if (saturated[i] == 0) {
            try_kuhn(i , 0); /// 0 means you want to go through an edge not belonging, 1 means it should be belonging
        }
    }

    int nr = 0;
    for (int i = 1; i <= e; i++) {
        if (taken[i] == 1)nr++;
    }
    out << nr << "\n";

    for (int i = 1; i <= e; i++) {
        if (taken[i] == 1) {
            out << edges[i].first << " " << edges[i].second << "\n";
        }

    }
}
