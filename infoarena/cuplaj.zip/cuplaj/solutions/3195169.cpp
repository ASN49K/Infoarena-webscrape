#include <bits/stdc++.h>

using namespace std;

ifstream fin ("cuplaj.in");
ofstream fout ("cuplaj.out");


#define limn 10010
int N, M, E, A[limn], B[limn];
vector <int> G[limn];
bool viz[limn];

bool pairUp (int nod) {
    if ( viz[nod]  == 1 )
         return 0;
    viz[nod] = 1;

    for ( auto it : G[nod]) { //nu face parte din A
        if ( !B[it] ) {//combinam nod cu it 
            B[it] = nod;
            A[nod] = it;
            return 1;
        }
    }

    for ( auto it: G[nod] ) {
        if ( pairUp(B[it]) ) { //putem strica perechea de la B[it]
            B[it] = nod;
            A[nod] = it;
            return 1;
        }
    }

    return 0;
}

int main () {
    fin >> N >> M >> E;
    int x, y;
    for ( int i = 1; i <= E; ++i ) {
        fin >> x >> y;
        G[x].push_back(y);
    }

    bool pathFound = 1;

    while ( pathFound) { //gasim un augumentat
        pathFound = 0;
        for ( int i = 1; i <= N; ++i ) {  //inii viz
            viz[i] = 0;
        }
        for ( int i = 1; i <= N; ++i ) {
            if ( !A[i] ) {
                pathFound |= pairUp(i);
            }
        }
    }

    int nrMatches = 0;

    for ( int i = 1 ; i <= N; ++i  ) {
        if ( A[i] ) {
            nrMatches ++;
        }
    }    
    fout << nrMatches << '\n';
    for ( int i = 1; i <= N; ++i ) {
        if ( A[i] ) {
            fout << i << " " << A[i] << '\n';
        }
    }
    return 0;
}