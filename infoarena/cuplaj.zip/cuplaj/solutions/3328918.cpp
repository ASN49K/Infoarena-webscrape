#include <bits/stdc++.h>

using namespace std;
ifstream f("cuplaj.in");
ofstream g("cuplaj.out");

struct vecini {
    int node;
    int cap;
    int rev;
};
vector<vecini> v[10006];
int depth[10006];
int n,m;
int src;
int dest;
void BFS() {
    queue<int> q;
    q.push(src);

    for (int i=1;i<=n;i++) {
        depth[i]=-1;
    }
    depth[src]=0;
    while(!q.empty()) {
        int x=q.front();
        q.pop();
        for(auto nod:v[x]) {
            if (nod.node==dest) {
                continue;
            }
            if (nod.cap!=0) {
                if (depth[nod.node]==-1) {
                    depth[nod.node]=depth[x]+1;
                    q.push(nod.node);
                }
            }
        }
    }
}

int DFS(int node,int possible=1000000) {
    int ans=0;

    for (auto& vec:v[node]) {
        if (vec.node==dest) {
            int flow=min(possible,vec.cap);
            ans+=flow;
            possible-=flow;
            vec.cap-=flow;
        }
        if (depth[vec.node]==depth[node]+1) {
            int flow=DFS(vec.node,min(possible,vec.cap));
            ans+=flow;
            possible-=flow;
            vec.cap-=flow;
            v[vec.node][ vec.rev].cap+=flow;
        }
    }
    return ans;
}
int main() {
    int n1,n2,q;
    f>>n1>>n2>>q;
    n=n1+n2+2;
    for(int i=0;i<q;i++) {
        int x,y,cost;
        f>>x>>y;
        y=y+n1+1;
        x=x+1;
        v[y].push_back({x,0,(int)v[x].size()});
        v[x].push_back({y,1,(int)v[y].size()-1});
    }
    for (int i=1;i<=n1;i++) {
        v[i+1].push_back({1,0,(int)v[1].size()});
        v[1].push_back({i+1,1,(int)v[i+1].size()-1});
    }
    for (int i=1;i<=n2;i++) {
        v[n].push_back({i+n1+1,0,(int)v[i+n1+1].size()});

        v[i+n1+1].push_back({n,1,(int)v[n].size()-1});
    }
    dest=n;
    src=1;
    int ans=0;
    while(1) {
        BFS();
        int x=DFS(src,10000000);
        if (x==0) {
            break;
        }
        ans+=x;
    }
    g<<ans<<"\n";
    for (auto i:v[1]) {
        if (i.cap==0) {
            g<<i.node-1;
            for (auto j:v[i.node]) {
                if (j.cap==0) {
                    g<<" "<<j.node-1-n1;
                    break;
                }
            }
            g<<'\n';
        }
    }
}



