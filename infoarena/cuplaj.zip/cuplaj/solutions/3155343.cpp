#pragma GCC optimize("Ofast,unroll-loops")
#include <bits/stdc++.h>

#define sz(a) ((int)(a).size())
#define all(a) (a).begin(), (a).end()

#define fi first
#define se second

using namespace std;

class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}

	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	InParser& operator >> (long long &n) {
		char c;
		n = 0;
		while (!isdigit(c = read_ch()) && c != '-');
		long long sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
};

#ifdef LOCAL
InParser fin("input.txt");
#define fout cout
#else
#define FILE_NAME "cuplaj"
InParser fin(FILE_NAME ".in");
ofstream fout(FILE_NAME ".out");
#define endl '\n'
#endif

typedef long long ll;
typedef pair<int, int> pii;

const int NMAX = 2e4+5;
const int INF = 2e9+5;

struct Edge {
	int dest, flow, rev;
};

int n, m, n1, n2;
vector<Edge> g[NMAX];
int d[NMAX];
int last[NMAX];

void add_edge(int x, int y) {
	g[x].push_back({ y, 1, sz(g[y]) });
	g[y].push_back({ x, 0, sz(g[x]) - 1 });
}

void read() {
	fin >> n1 >> n2 >> m;
	n = n1 + n2 + 2;
	for (int i = 1, x, y; i <= m; i++) {
		fin >> x >> y;
		add_edge(x + 1, n1 + y + 1);
	}
	for (int i = 2; i <= n1 + 1; i++)
		add_edge(1, i);
	for (int i = n1 + 2; i < n; i++)
		add_edge(i, n);
}

bool bfs() { 
	memset(d, 0, sizeof(d));
	memset(last, 0, sizeof(last));

	queue<int> q;
	q.push(1);
	d[1] = 1;

	while (!q.empty()) {
		int u = q.front();
		q.pop();
		if (u == n) continue;
		for (auto &it : g[u]) {
			if (!d[it.dest] && it.flow > 0) {
				d[it.dest] = d[u] + 1;
				q.push(it.dest);
			}
		}
	}

	return d[n];
}

int dfs(int x, int flow) {
	if (x == n) return flow;

	for (; last[x] < sz(g[x]); last[x]++) {
		Edge &e = g[x][last[x]];
		if (e.flow > 0 && d[e.dest] == d[x] + 1) {
			if (int ret = dfs(e.dest, min(flow, e.flow))) {
				e.flow -= ret;
				g[e.dest][e.rev].flow += ret;
				return ret;
			}
		}
	}

	return 0;
}

int dinic() {
	int max_flow = 0;
	while (bfs()) {
		while (int flow = dfs(1, INF))
			max_flow += flow;
	}
	return max_flow;
}

signed main() {
	read();
	fout << dinic() << endl;
	for (int i = 2; i <= n1 + 1; i++) {
		for (auto &it : g[i]) {
			if (it.flow == 0 && it.dest != 1) {
				fout << i - 1 << ' ' << it.dest - n1 - 1 << endl;
				break;
			}
		}
	}
	return 0;
}
