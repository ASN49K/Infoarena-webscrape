#include <iostream>
#include <cmath>
#include <vector>
#include <cstdio>
#include <queue>
#include <stack>
#include <bitset>
#include <cassert>
#include <fstream>
#include <map>
#include <algorithm>
#include <climits>
#include <numeric>
#include <iomanip>
#include <array>
#include <iomanip>
#include <cstring>
#include <utility>
#include <functional>
#define all(x) x.begin(),x.end()
#include <list>
#include <queue>
#include <set>
#define pb(x) push_back(x)
//#pragma GCC optimize("Ofast","unroll-loops")
//#pragma GCC target("avx2")
#define XD return cout<<"DA\n",void();
#define DX return cout<<"NU\n",void();
using namespace std;
typedef long long ll;
typedef pair<ll,ll>pll;
typedef long double ld;
typedef pair<ld,ld>pld;
typedef array<ll,3> ll3;
typedef array<ll,2> ll2;
typedef array<ll,4> ll4;
ll mt[10001],used[10001];
vector<ll>vec[10001];
ll rez=0;
bool match(ll x){
  if(used[x])return 0;
  used[x]=1;
  for(auto y:vec[x]){
    if(mt[y]==0||match(mt[y]))return mt[y]=x,1;
  }
  return 0;
}
int main(){
  freopen("cuplaj.in","r",stdin);
  freopen("cuplaj.out","w",stdout);
  ios::sync_with_stdio(false);
  cin.tie(0);
  ll m,i,j,k,l,E,p,d,T,n,x,g,y;
  cin>>n>>m>>E;
  for(i=1;i<=E;i++)cin>>x>>y,vec[x].pb(y);
  for(i=1;i<=n;i++){
    for(j=1;j<=n;j++)used[j]=0;
    match(i);
  }
  for(i=1;i<=m;i++)if(mt[i])rez++;
  cout<<rez<<'\n';
  for(i=1;i<=m;i++)if(mt[i])cout<<mt[i]<<' '<<i<<'\n';
  return 0;
}
