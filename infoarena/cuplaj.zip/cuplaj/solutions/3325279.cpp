#include <fstream>
#include <vector>

using namespace std;
ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");

const int NMAX = 1e5 + 5;
vector<int> v[NMAX];
bool vis[NMAX];
int cpl[NMAX];

bool pairUp(int nod) {
    if (vis[nod]) {
        // ai incercat deja sa gasesti drum de crestere
        // deci nu s-ar mai contoriza acum
        return false;
    }
    vis[nod] = true;

    // prima data incerci sa cuplezi cu
    // un vecin necuplat
    for (auto i: v[nod]) {
        if (!cpl[i]) {
            cpl[nod] = i;
            cpl[i] = nod;
            return true;
        }
    }

    // incerci sa decuplezi un vecin
    // si sa cuplezi cu el
    // asta nu o sa scada |cuplajul actual|
    for (auto i: v[nod]) {
        if (pairUp(cpl[i])) {
            cpl[i] = nod;
            cpl[nod] = i;
            return true;
        }
    }

    return false;
}

int main() {
    int n, m, mm, cnt = 0;
    cin >> n >> m >> mm;

    for (int i = 1; i <= mm; i++) {
        int a, b;
        cin >> a >> b;

        v[a].push_back(b + n);
        v[b + n].push_back(a);
    }

    bool found;
    do {
        found = false;
        for (int i = 1; i <= n; i++) {
            vis[i] = false;
            // vis[i] = true, daca ai incercat
            // sa gasesti drum de crestere din i
        }

        for (int i = 1; i <= n; i++) {
            if (!cpl[i] && pairUp(i)) {
                // ai gasit drum de crestere
                cnt++;
                found = true;
            }
        }
    } while (found);

    cout << cnt << '\n';
    for (int i = 1; i <= n; i++) {
        if (cpl[i]) {
            cout << i << ' ' << cpl[i] - n << '\n';
        }
    }
}
