#include <bits/stdc++.h>

using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
const int Nmax=1e4+5;
vector<pair<int,int>> v[2*Nmax];
pair<int,int> muchii[10*Nmax];
int f[10*Nmax];
int isin[2*Nmax];
unordered_set<int> isfree;
pair<int,int> prv[2*Nmax];
bitset<2*Nmax> viz;
int n,m,e;
void reconst(int nod)
{
    if(prv[nod].first==-1)
    {
        isfree.erase(nod);
        isin[nod]=1;
        return;
    }
    if(nod<=n)
    {
        f[prv[nod].second]=0;
    }
    else
    {
        f[prv[nod].second]=1;
    }
    reconst(prv[nod].first);
}
int dfs(int nod,int prev,int muchie)
{
    ///cout<<nod<<'\n';
    prv[nod]={prev,muchie};
    if(nod>n && isin[nod]==0) return nod;
    if(nod<=n)
    {
        for(pair<int,int> u:v[nod])
        {
            if(f[u.second]==0 && u.first!=prev)
            {
                int v=dfs(u.first,nod,u.second);
                if(v!=-1) return v;
            }
        }
    }
    else
    {
        for(pair<int,int> u:v[nod])
        {
            if(f[u.second]==1 && u.first!=prev)
            {
                int v=dfs(u.first,nod,u.second);
                if(v!=-1) return v;
            }
        }
    }
    return -1;
}
int main()
{
    fin>>n>>m>>e;
    for(int i=1;i<=e;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back({y+n,i});
        v[y+n].push_back({x,i});
        muchii[i]={x,y};
    }
    for(int i=1;i<=n;i++)
    {
        isfree.insert(i);
    }
    int cnt=0;
    while(cnt<=e && !isfree.empty())
    {
        bool ok=0;
        for(int x:isfree)
        {
            int v=dfs(x,-1,-1);
            if(v!=-1)
            {
                ///cout<<x<<' '<<v<<'\n';
                reconst(v);
                cnt++;
                isfree.erase(v);
                isin[v]=1;
                ok=1;
                break;
            }
        }
        if(!ok) break;
    }
    fout<<cnt<<'\n';
    for(int i=1;i<=e;i++)
    {
        if(f[i]==1)
        {
            fout<<muchii[i].first<<' '<<muchii[i].second<<'\n';
        }
    }
    return 0;
}
