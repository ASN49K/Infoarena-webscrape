#include <stdio.h>
#include <vector>

const int MAXN = 2e4;
const int NIL = -1;

std::vector<int> adj[MAXN];
bool viz[MAXN];
int pair[MAXN];

bool try_pair( int u ){
  viz[u] = true;

  for( int v : adj[u] )
    if( pair[v] == NIL ){
      pair[v] = u;
      pair[u] = v;

      return true;
    }

  for( int v : adj[u] )
    if( !viz[v] ){
      viz[v] = true;
      if( try_pair( pair[v] ) ){ // deconectam perechea lui v de v si conectam cu u
        pair[v] = u;
        pair[u] = v;

        return true;
      }
    }

  return false;
}

int main(){
  FILE *fin  = fopen( "cuplaj.in", "r" );
  FILE *fout = fopen( "cuplaj.out", "w" );

  int n, m, i, a, b;

  fscanf( fin, "%d%d%d", &n, &m, &i );
  
  for( ; i-- ; ){
    fscanf( fin, "%d%d", &a, &b );
    a--;
    b--;
    b += n;

    adj[a].push_back( b );
    adj[b].push_back( a );
  }

  for( i = n + m ; i-- ; )
    pair[i] = NIL;

  bool stegulet = true;
  while( stegulet ){
    stegulet = false;
    
    for( i = n + m ; i-- ; )
      viz[i] = false;

    for( i = 0 ; i < n ; i++ )
      stegulet |= try_pair( i );
  }

  a = 0;
  for( i = 0 ; i < n ; i++ )
    a += (pair[i] != NIL);

  fprintf( fout, "%d\n", a );
  for( i = 0 ; i < n ; i++ )
    if( pair[i] != NIL )
      fprintf( fout, "%d %d\n", i + 1, pair[i] - n + 1 );

  fclose( fin );
  fclose( fout );
  return 0;
}
