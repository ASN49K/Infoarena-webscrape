#include <bits/stdc++.h>
using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

const int N = 2 * 1e4 + 5;
int n, m, edges;
int l[N], r[N], vis[N];
vector<int> g[N];

bool match(int u) {
  if (vis[u])
    return false;
  vis[u] = 1;
  for (int v : g[u]) {
    if (!r[v]) {
      l[u] = v;
      r[v] = u;
      return 1;
    }
  }
  for (int v : g[u]) {
    if (match(r[v])) {
      r[v] = u;
      l[u] = v;
      return 1;
    }
  }
  return 0;
}

int main() {
  fin >> n >> m >> edges;
  for (int u, v, i = 1; i <= edges; ++i) {
    fin >> u >> v;
    g[u].emplace_back(v);
  }
  bool ok = 1;
  while (ok) {
    ok = 0;
    for (int i = 1; i <= n; ++i)
      vis[i] = false;
    for (int i = 1; i <= n; ++i)
      if (!l[i])
        ok |= match(i);
  }
  int nr = 0;
  for (int i = 1; i <= n; ++i)
    nr += (l[i] > 0);
  fout << nr << '\n';
  for (int i = 1; i <= n; ++i)
    if (l[i])
      fout << i << ' ' << l[i] << '\n';
}
