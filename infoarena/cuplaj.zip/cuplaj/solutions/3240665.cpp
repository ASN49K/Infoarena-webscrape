#include <fstream>
#include <vector>
using namespace std;
vector <int> v[10005];
int viz[10005], tata[10005], j;
bool dfs(int x) {
	int i;
	viz[x] = j;
	for (i = 0; i < v[x].size(); i++) {
		if (tata[v[x][i]] == -1 || (viz[tata[v[x][i]]] != j && dfs(tata[v[x][i]]) == 1)) {
			tata[v[x][i]] = x;
			return 1;
		}
	}
	return 0;
}
int main() {
	int n, m, e, i, x, y, r;
	ifstream fin( "cuplaj.in" );
	ofstream fout( "cuplaj.out" );
	fin >> n >> m >> e;
	for (i = 0; i < e; i++) {
		fin >> x >> y;
		v[x].push_back( y );
	}
	for (i = 1; i <= m; i++) {
		tata[i] = -1;
	}
	r = 0;
	for (j = 1; j <= n; j++) {
		r += dfs( j );
	}
	fout << r << '\n';
	for (i = 1; i <= m; i++) {
		if (tata[i] != -1) {
			fout << tata[i] << ' ' << i << '\n';
		}
	}
	return 0;
}