#include <bits/stdc++.h>

using namespace std;

#define ST_DIO 0
#if ST_DIO
    #define fin cin
    #define fout cout
#else
    ifstream fin("cuplaj.in");
    ofstream fout("cuplaj.out");
#endif  // ST_DIO

bool fr[10002], cuplat[10002];
int pereche[10002], rasp;
vector<int> gr[10002];
int n, m, e, i;

static inline bool DFS(int nod) {
    if(fr[nod]) return false;

    fr[nod] = true;
    for(int urm : gr[nod]) {
        if(!pereche[urm] || DFS(pereche[urm])) {
            pereche[urm] = nod;
            cuplat[nod] = true;
            return true;
        }
    }
    return false;
}

int main() {
    if(ST_DIO) ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin >> n >> m >> e;
    while(e--) {
        int x, y;
        fin >> x >> y;
        gr[x].push_back(y);
    }

    while(true) {
        bool ok = true;

        memset(fr, false, sizeof(fr));
        for(i = 1; i <= n; i++) {
            if(!cuplat[i] && DFS(i)) ok = false;
        }
        if(ok) break;
    }

    for(i = 1; i <= m; i++) rasp += (pereche[i] > 0);

    fout << rasp << "\n";
    for(i = 1; i <= m; i++) {
        if(pereche[i]) fout << pereche[i] << " " << i << "\n";
    }

    return 0;
}
