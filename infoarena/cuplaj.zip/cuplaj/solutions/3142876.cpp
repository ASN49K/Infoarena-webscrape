#include <bits/stdc++.h>

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n, m, e, i, x, y;
int cup[10002], r;
vector<int> a[10002];
bitset<10002> fr, p;
bool ok = true;

static inline bool parc(int nod) {
    if(fr[nod]) return false;
    fr[nod] = 1;
    for(auto it : a[nod]) {
        if(!cup[it] || parc(cup[it])) {
            cup[it] = nod;
            p[nod] = 1;
            return true;
        }
    }
    return false;
}

int main() {
    fin >> n >> m >> e;
    for(i = 1; i <= e; i++) {
        fin >> x >> y;
        a[x].push_back(y);
    }

    while(ok) {
        ok = false;
        fr = 0;
        for(i = 1; i <= n; i++) {
            if(!p[i] && parc(i)) ok = true;
        }
    }
    for(i = 1; i <= m; i++) r += (cup[i] > 0);
    fout << r << "\n";
    for(i = 1; i <= m; i++) {
        if(cup[i]) fout << cup[i] << " " << i << "\n";
    }

    return 0;
}
