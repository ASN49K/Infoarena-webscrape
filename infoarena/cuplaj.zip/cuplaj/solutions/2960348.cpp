#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream in("cuplaj.in");
ofstream out("cuplaj.out");
const int maxn = 20005;

struct muchie
{
    int nod, vec, flux, cap;
};

vector <muchie> v[maxn];
vector <muchie> drum;
muchie tata[maxn];
int dist[maxn];
int n, m;
int sursa, destinatie;

queue <int> q;

bool bfs()
{
    for(int i = 1; i <= n + m + 2; i++)
    {
        dist[i] = (1 << 30);
        tata[i] = {0, 0, 0};
    }
    dist[sursa] = 0;
    q.push(sursa);
    while(!q.empty())
    {
        int nod = q.front();
        q.pop();
        for(auto it : v[nod])
        {
            if(dist[it.vec] > dist[nod] + 1 && it.flux < it.cap) /// pot trimite flux pe aici
            {
                dist[it.vec] = dist[nod] + 1;
                tata[it.vec] = it;
                q.push(it.vec);
            }
        }
    }
    if(dist[destinatie] != (1 << 30))
        return 1;
    return 0;
}

int main()
{
    int e;
    in >> n >> m >> e;
    sursa = n + m + 1;
    destinatie = n + m + 2;
    for(int i = 1; i <= e; i++)
    {
        int x, y;
        in >> x >> y;
        v[x].push_back({x, y + n, 0, 1});
        v[y + n].push_back({y + n, x, 0, 0});
    }
    for(int i = 1; i <= n; i++)
    {
        v[sursa].push_back({sursa, i, 0, 1});
        v[i].push_back({i, sursa, 0, 0});
    }
    for(int i = 1; i <= m; i++)
    {
        v[i + n].push_back({i + n, destinatie, 0, 1});
        v[i + n].push_back({destinatie, i + n, 0, 0});
    }
    /*
    for(int i = 1; i <= n + m + 2; i++)
        for(auto it : v[i])
            cerr << i << " " << it.vec << "\n";
    cerr << "INTRA";
    */
    while(bfs()) /// cat timp gasesc un drum de la 1 la n
    {
        int act = destinatie;
        drum.clear();
        while(tata[act].nod != 0)
        {
            drum.push_back(tata[act]);
            act = tata[act].nod;
        }
        int posibil = (1 << 30); /// fluxul maxim pe care il pot trimite pe drumul gasit
        for(auto it : drum) /// calculez ce flux pot trimite
            posibil = min(posibil, it.cap - it.flux);
        for(auto m : drum) /// scad si adun fluxul pe care il bag din toate muchiile
        {
            int x = m.nod;
            int y = m.vec;
            for(int i = 0; i < v[x].size(); i++) /// gasesc muchia (x, y) si adun fluxul bagat
            {
                if(v[x][i].vec == y)
                {
                    v[x][i].flux += posibil;
                    break;
                }
            }
            for(int i = 0; i < v[y].size(); i++)
            {
                if(v[y][i].vec == x)
                {
                    v[y][i].flux -= posibil; /// gasesc muchia (y, x) si scad fluxul bagat
                    break;
                }
            }
        }
    }
    //cerr << "INTRA";
    vector <pair <int, int> > sol;
    for(int i = 1; i <= n; i++)
        for(auto it : v[i])
            if(it.flux > 0)
                sol.push_back(make_pair(i, it.vec - n));
    out << sol.size() << "\n";
    for(auto it : sol)
        out << it.first << " " << it.second << "\n";
    return 0;
}
