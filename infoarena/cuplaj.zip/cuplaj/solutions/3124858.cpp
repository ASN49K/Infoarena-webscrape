#include <fstream>
#include <vector>

using namespace std;

ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");

const int NMAX = 1e4;
int n, m, e;
vector<int> G[NMAX + 1];
bool folosit[NMAX + 1], cuplat[NMAX + 1];
int pereche[NMAX + 1];
int cuplaj;

bool DFS(int nod)
{
    if(folosit[nod])
        return false;
    folosit[nod] = true;

    for(int x : G[nod])
    {
        if(pereche[x] == 0 || DFS(pereche[x]))
        {
            pereche[x] = nod;
            cuplat[nod] = true;

            return true;
        }
    }
    return false;
}

int main()
{
    cin >> n >> m >> e;
    for(int i = 1; i <= e; i++)
    {
        int x, y;
        cin >> x >> y;
        G[x].push_back(y);
    }

    bool modificat = true;
    while(modificat)
    {
        modificat = false;
        for(int i = 1; i <= n; i++)
            folosit[i] = 0;
        
        for(int i = 1; i <= n; i++)
            if(!cuplat[i] && DFS(i))
                modificat = true;
    }

    for(int i = 1; i <= m; i++)
        if(pereche[i] != 0)
            cuplaj++;

    cout << cuplaj << '\n';
    for(int i = 1; i <= m; i++)
        if(pereche[i] != 0)
            cout << pereche[i] << ' ' << i << '\n';       

    return 0;
}