#include <fstream>
#include <vector>
using namespace std;

ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");

const int MAX = 1e4 + 1;

vector <int> g[MAX];

int a , b , m , l[MAX] , r[MAX] , cuplaj;

bool viz[MAX];

int cupleaza( int i ){

    viz[i] = 1;

    for(auto it:g[i]){

        if(!r[it]){

            r[it] = i;
            l[i] = it;
            return 1;
        }
    }

    for(auto it:g[i]){

        if(!viz[r[it]] && cupleaza(r[it])){

            r[it] = i;
            l[i] = it;
            return 1;
        }
    }

    return 0;
}

int main(){


    cin >> a >> b >> m;

    int x , y;

    while(m--){

        cin >> x >> y;

        g[x].push_back(y);
    }

    bool ok = 1;

    while(ok){

        ok = 0;

        for(int i = 1 ; i <= a ; i++){

            viz[i] = 0;
        }

        for(int i = 1 ; i <= a ; i++){

            if(!l[i] && cupleaza(i)){

                cuplaj++;

                ok = 1;
            }
        }
    }

    cout << cuplaj << '\n';

    for(int i = 1 ; i <= a ; i++){

        if(l[i]) cout << i << ' ' << l[i] << '\n';
    }

    return 0;
}
