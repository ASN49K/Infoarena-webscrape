#include <fstream>
#include <vector>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
int n, m, e, i, j, x, y;
vector <int> viz, L, R;
vector <vector <int>> G;
bool cuplaj (int x)
{
    if (viz[x]) return 0;
    viz[x] = 1;
    for (int i = 0; i < G[x].size(); i++)
    {
        if (R[G[x][i]] == 0)
        {
            R[G[x][i]] = x;
            L[x] = G[x][i];
            return 1;
        }
    }
    for (int i = 0; i < G[x].size(); i++)
    {
        if (cuplaj(R[G[x][i]]))
        {
            R[G[x][i]] = x;
            L[x] = G[x][i];
            return 1;
        }
    }
    return 0;
}
int main()
{
    fin >> n >> m >> e; G.resize(n+1); L.resize(n+1); R.resize(m+1);
    for (i = 1; i <= e; i++)
    {
        fin >> x >> y;
        G[x].push_back(y);
    }
    bool valid = 1;
    while (valid)
    {
        valid = 0;
        viz.clear();
        viz.resize(n+1);
        for (i = 1; i <= n; i++)
            if (L[i] == 0)
                if (cuplaj(i)) valid = 1;
    }
    int nrc = 0;
    for (i = 1; i <= n; i++)
    {
        if (L[i] > 0)
            nrc++;
    }
    fout << nrc << "\n";
    for (i = 1; i <= n; i++)
    {
        if (L[i] > 0)
            fout << i << " " << L[i] << '\n';
    }
    return 0;
}
