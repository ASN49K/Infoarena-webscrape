#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

vector<int> graf[20001];
bool viz[20001];
int F[20001];

bool cuplaj(int nod)
{
    viz[nod] = true;
    for(int vecin : graf[nod]) {
        // daca un vecin nu este cuplat formeaza pereche
        if(F[vecin] == 0) {
            F[nod] = vecin;
            F[vecin] = nod;
            return true; //cuplat
        }

        //incercam sa cuplam nodul necuplat
        if(viz[F[vecin]]==false && cuplaj(F[vecin])) {
            F[nod] = vecin;
            F[vecin] = nod;
            return true; //cuplat
        }
    }
    return false; //necuplat
}

int main()
{
    ifstream f("cuplaj.in");
    ofstream g("cuplaj.out");
    int n, m, e, x, y, c=0, i;
    bool cuplat=true;
    f>>n>>m>>e;

    for(i=0; i<e; i++) {
        f>>x>>y;
        y += n;
        graf[x].push_back(y);
    }

    do {
        cuplat = false;

        //cauta noduri necuplate:
        for(i=1; i<=n; i++)
            if(!viz[i] && !F[i] && cuplaj(i)) {
                c++;
                cuplat = true;
            }
        // reinitiaza vectorul vizited ca sa reincerce cuplajul nodurilor ramase
        for(i=1; i<=n+m; i++)
            viz[i] = false;
    }while(cuplat);

    g<<c<<'\n';
    for(i=1; i<=n; i++)
        if(F[i] != 0)
            g<<i<<" "<<F[i]-n<<'\n';

    f.close(); g.close();
    return 0;
}
