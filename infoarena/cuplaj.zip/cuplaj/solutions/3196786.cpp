#include <fstream>
#include <vector>
#include <iostream>

using namespace std;

ifstream in("cuplaj.in");
ofstream out("cuplaj.out");
int n, m, q;
vector<int> v[10005];
int viz[10005];
int pst[10005], pdr[10005];
int ans;

int gasire(int nod)
{
    if(viz[nod] == 1)
    {
        return 0;
    }

    viz[nod] = 1;


    for(int it: v[nod])
    {
        if(pst[it] == 0)
        {
            pdr[nod] = it;
            pst[it] = nod;
            ans++;
            //cout<<nod<<" - "<<it<<" (1)"<<endl;
            return 1;
        }
    }

    for(int it: v[nod])
    {
        if(gasire(pst[it]))
        {
            pdr[nod] = it;
            pst[it] = nod;

            //cout<<nod<<" - "<<it<<" (2)"<<endl;

            return 1;

        }
    }

    return 0;
}

int main()
{
    in>>n>>m>>q;

    int x, y;
    for(int i = 1; i<=q; i++)
    {
        in>>x>>y;

        v[x].push_back(y);
    }

    int ok = 1;
    while(ok == 1)
    {
        ok = 0;

        for(int i = 1; i<=n; i++)
        {
            viz[i] = 0;
        }

        for(int i = 1; i<=n; i++)
        {
            if(viz[i] == 0 && pdr[i] == 0)
            {
                if(gasire(i))
                {
                    ok = 1;
                }
            }
        }

        //cout<<"sugus"<<endl;
    }

    out<<ans<<'\n';

    for(int i = 1; i<=n; i++)
    {
        if(pdr[i] != 0)
        {
            out<<i<<" "<<pdr[i]<<'\n';
        }
    }

    return 0;
}
