#include <bits/stdc++.h>
using namespace std;
ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");
vector<int>a[10001],b[10001];
bool cuplat[10001];
int pereche[10001],i;
bool viz[10001];
int cup_init(int x)
{
    for(auto q:a[x])
        if(!pereche[q])
            return q;
    return 0;
}
bool incearca(int x)
{
    if(viz[x])
        return false;
    viz[x]=true;
    for(auto q:a[x])
    {
        if(pereche[q]==0||incearca(pereche[q]))
        {
            cuplat[x]=true;
            pereche[q]=x;
            return true;
        }
    }
    return false;
}
int main()
{
    int n,m,e;
    fin>>n>>m>>e;
    for(i=1; i<=e; i++)
    {
        int x,y;
        fin>>x>>y;
        a[x].push_back(y);
        b[y].push_back(x);
    }
    for(i=1; i<=n; i++)
    {
        int x=cup_init(i);
        if(x!=0)
        {
            pereche[x]=i;
            cuplat[i]=true;
        }
    }
    int l=0;
    bool imbunatatit;
    do
    {
        imbunatatit=false;
        fill(viz,viz+n+1,0);
        for(int i=1; i<=n; i++)
            if(!cuplat[i])
            {
                cuplat[i]=incearca(i);
                imbunatatit=cuplat[i];
            }
    } while(imbunatatit);
    for(i=1; i<=m; i++)
        if(pereche[i])
            l++;
    fout<<l<<"\n";
    for(i=1; i<=m; i++)
    {
        if(pereche[i])
            fout<<pereche[i]<<" "<<i<<"\n";
    }
    fin.close();
    fout.close();
    return 0;

}
