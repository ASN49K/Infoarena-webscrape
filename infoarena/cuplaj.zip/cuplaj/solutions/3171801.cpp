#include <bits/stdc++.h>
using namespace std;

const int nmax = 1e4 + 7;

int n, m, k;
vector<int> adjf[nmax];
int parinv[nmax];
int par[nmax];

bool dfs(int u) {
  if (par[u] == -1) return true;
  for (int v : adjf[par[u]]) {
    if (v == u) continue;
    if (dfs(v)) {
      parinv[par[u]] = v;
      par[v] = par[u];
      return true;
    }
  }
  return false;
}

int main() {
  
  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("cuplaj.in", "r", stdin);
  freopen("cuplaj.out", "w", stdout);
  #endif

  cin >> n >> m >> k;

  fill(par + 1, par + m + 1, -1);

  for (int i = 0; i < k; i++) {
    int u, v;
    cin >> u >> v;
    adjf[u].push_back(v);
    adjb[v].push_back(u);
  }

  int cnt = 0;

  for (int u = 1; u <= n; u++) {
    for (int v : adjf[u]) {
      if (dfs(v)) {
        cnt++;
        parinv[u] = v;
        par[v] = u;
        break;
      }
    }
  }

  cout << cnt << '\n';




}