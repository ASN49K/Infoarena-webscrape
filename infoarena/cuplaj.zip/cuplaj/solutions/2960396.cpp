#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream f ("cuplaj.in");
ofstream g ("cuplaj.out");

vector <int> l[20001];
int n, m, c[20001][20001], fl[20001][20001], t[20001], v[20001];

int bf (int vf)
{
    int i;
    queue <int> q;
    q.push(vf);
    v[vf] = 1;
    t[vf] = 0;
    while (!q.empty())
    {
        vf = q.front();
        q.pop();
        for (i = 0; i < l[vf].size(); i++)
        {
            if (!v[l[vf][i]] && fl[vf][l[vf][i]] < c[vf][l[vf][i]])
            {
                q.push(l[vf][i]);
                v[l[vf][i]] = 1;
                t[l[vf][i]] = vf;
                if (l[vf][i] == n + m + 1) return 1;
            }
        }
    }
    return 0;
}


int main()
{int e, flux = 0, i, j, x, y, mn;
f >> n >> m >> e;
for (i = 1; i <= n; i++)
{
    l[0].push_back(i);
    l[i].push_back(0);
    c[0][i] = 1;
}
for (i = 1; i <= m; i++)
{
    l[i + n].push_back(n + m + 1);
    l[n + m + 1].push_back(i + n);
    c[i + n][n + m + 1] = 1;
}
for (i = 0; i < e; i++)
{
    f >> x >> y;
    l[x].push_back(y + n);
    l[y + n].push_back(x);
    c[x][y + n] = 1;
}
/*for (i = 0; i <= n + m + 1; i++)
{
    cout << i << '\n';
    for (j = 0; j < l[i].size(); j++)
        cout << l[i][j] << ' ';
    cout << '\n';
}*/
while (bf(0))
{
    i = n + m + 1;
    mn = 999999;
    while (i > 0)
    {
        if (c[t[i]][i] - fl[t[i]][i] < mn)
            mn = c[t[i]][i] - fl[t[i]][i];
        i = t[i];
    }
    flux += mn;
    i = n + m + 1;
    while (i > 0)
    {
        fl[t[i]][i] += mn;
        fl[i][t[i]] -= mn;
        i = t[i];
    }
    for (i = 0; i <= n + m + 1; i++)
    {
        v[i] = 0;
        t[i] = 0;
    }
}
g << flux << '\n';
for (i = 1; i <= n; i++)
    for (j = n + 1; j < n + m + 1; j++)
        if (fl[i][j] == c[i][j] && fl[i][j] == 1)
            g << i << ' ' << j - n << '\n';
return 0;
}
