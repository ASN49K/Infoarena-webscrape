/// patratele
#include <bits/stdc++.h>
using namespace std;

#define MOD 1000000003
#define NMAX 10010

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

int i, cumplat[NMAX], viz[NMAX], cn, n, m, e, x, y;
vector<int> v[NMAX];

void cumplez(int a, int b)
{
  cumplat[cumplat[a]] = 0;
  cumplat[a] = b;
  cumplat[cumplat[b]] = 0;
  cumplat[b] = a;
}

int dfs(int nod)
{
  viz[nod] = cn;
  for (auto it : v[nod])
  {
    if (viz[it] != cn)
    {
      viz[it] = cn;
      if (!cumplat[it])
      {
        cumplez(nod, it);
        return 1;
      }
      if (cumplat[it] && (cumplat[it]) == 1)
      {
        cumplez(nod, it);
        return 1;
      }
    }
  }
  return 0;
}

int main()
{
  // ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  fin >> n >> m >> e;
  for (i = 1; i <= e; i++)
  {
    fin >> x >> y;
    v[x].push_back(y + n);
    v[y + n].push_back(x);
  }
  int ok = 1;
  while (ok)
  {
    ok = 0;
    cn++;
    for (i = 1; i <= n + m; i++)
      if (viz[i] != cn && !cumplat[i])
        ok |= dfs(i);
  }
  cn = 0;
  for (i = 1; i <= n; i++)
  {
    if (cumplat[i])
      cn++;
  }
  fout << cn << '\n';
  for (i = 1; i <= n; i++)
  {
    if (cumplat[i])
      fout << i << " " << cumplat[i] - n << '\n';
  }
}
