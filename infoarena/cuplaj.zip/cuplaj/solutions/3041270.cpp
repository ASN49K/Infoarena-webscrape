#include <fstream>
#include <vector>
using namespace std;
ifstream f("cuplaj.in");
ofstream g("cuplaj.out");
int n,m;
const int N=1e4+4;
bool viz[N];
int st[N],dr[N];
int q,x,y,sol;
vector<int>a[N];
bool get(int nod)
{
    if(viz[nod])
        return false;
    viz[nod]=true;
    for(auto x: a[nod])
        if(!dr[x])
        {
            st[nod]=x;
            dr[x]=nod;
            return 1;
        }
    for(auto x: a[nod])
        if(get(dr[x])==true)
        {
            st[nod]=x;
            dr[x]=nod;
            return true;
        }
    return false;
}
int main()
{
    f>>n>>m>>q;
    for(int i=1;i<=q;i++)
    {
        f>>x>>y;
        a[x].push_back(y);
    }
    bool ok=true;
    while(ok)
    {
        ok=false;
        for(int i=1;i<=n;i++)
            viz[i]=false;
        for(int i=1;i<=n;i++)
            if(st[i]==0)
            {
                bool s=get(i);
                if(s)
                {
                    sol++;
                    ok=true;
                }
            }
    }
    g<<sol<<'\n';
    for(int i=1;i<=n;i++)
        if(st[i])
            g<<i<<" "<<st[i]<<'\n';
    return 0;
}
