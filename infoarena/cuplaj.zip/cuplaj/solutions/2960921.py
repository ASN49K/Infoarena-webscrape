from collections import defaultdict
from queue import Queue

graph = defaultdict(list)
capacity = defaultdict(dict)


def add_edge(x, y):
    graph[x].append(y)
    graph[y].append(x)
    capacity[x][y] = 1
    capacity[y][x] = 0


with open("cuplaj.in", "r") as fin:
    n, m, e = map(int, fin.readline().split())
    start = 0
    end = n + m + 1
    parent = [None] * (end + 1)

    # Legam left side de start
    for i in range(1, n + 1):
        add_edge(start, i)

    # Legam right side de end
    for i in range(1, m + 1):
        add_edge(n + i, end)

    for i in range(e):
        x, y = map(int, fin.readline().split())
        add_edge(x, y + n)


def bfs():
    vizitat = [False] * (end + 1)
    q = Queue(maxsize=end)
    q.put(start)
    vizitat[start] = True
    while not q.empty():
        nod = q.get()
        for vecin in graph[nod]:
            if not vizitat[vecin] and capacity[nod][vecin] > 0:
                parent[vecin] = nod
                vizitat[vecin] = True
                q.put(vecin)
    return vizitat[end]


def cuplaj():
    max_flow = 0

    while bfs():
        path_flow = float("inf")
        nod = end

        while nod != start:
            tata = parent[nod]
            path_flow = min(path_flow, capacity[tata][nod])
            nod = tata

        max_flow += path_flow
        nod = end

        while nod != start:
            tata = parent[nod]
            capacity[nod][tata] += path_flow
            capacity[tata][nod] -= path_flow
            nod = tata
    return max_flow


if __name__ == '__main__':
    with open("cuplaj.out", "w") as fout:
        fout.write(str(cuplaj()) + "\n")
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            try:
                if capacity[i][j + n] == 0:
                    fout.write(str(i) + " " + str(j) + "\n")
            except KeyError:
                pass
