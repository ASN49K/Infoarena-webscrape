
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");

int l,r,m,n,x,y,c,s,d;
vector<int>viz;
vector<int>t;//vector de muchii care duc la nodurile respective
vector<vector<int>>adj; //lista de adiacenta


struct muchie{
    int x,y,c,poz;
};

vector<muchie>M;

int BFS(){
    t.clear();
    t.resize(n);
    for(long long i=0;i<viz.size();i++)
        viz[i]=0;

    queue<int>coada;
    viz[s]=1;
    coada.push(s);

    while(!coada.empty()){
        int vf = coada.front();
        coada.pop();
        for(auto nod:adj[vf]){
            muchie mc = M[nod];
            if(!viz[mc.y] && mc.c>0){
                coada.push(mc.y);
                viz[mc.y] = 1;
                t[mc.y] = nod;
                if(mc.y == d){
                    return 1;
                }
            }
        }
    }
    return 0;
}


int main(){
    cin>>l>>r>>m;
    n=l+r+2;
    s=0;
    d = n-1;

    viz.resize(n+1);
    t.resize(n+1);
    adj.resize(n+1);

    int dim = 0;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        dim +=2;
        M.push_back({x,y+l,1,dim-1});
        M.push_back({y+l,x,0,dim-2});
        adj[x].push_back(dim-2);
        adj[y+l].push_back(dim-1);
    }

    //adaug muchii de la sursa spre fiecare nod din stanga
    for(int i=1;i<=l;i++){
        dim=dim+2;
        M.push_back({s,i,1,dim-1});
        M.push_back({i,s,0,dim-2});
        adj[s].push_back(dim-2);
        adj[i].push_back(dim-1);
    }

    for(int i = 1+l; i<=r+l; i++){
        dim+=2;
        M.push_back({i,d,1,dim-1});
        M.push_back({d,i,0,dim-2});
        adj[i].push_back(dim-2);
        adj[d].push_back(dim-1);
    }



    c=0;
    while(BFS()){
        for(auto nod:adj[d]){
            if(viz[M[nod].y] && M[M[nod].poz].c!=0){
                int minim = 999999;
                muchie mc = M[nod];
                t[d] = mc.poz;
                int nod = d;

                while(nod != s){
                    minim = min(minim, M[t[nod]].c);
                    nod = M[t[nod]].x;
                }
                c=c+minim;
                nod = d;
                while(nod!=s){
                    M[t[nod]].c =M[t[nod]].c- minim;
                    M[M[t[nod]].poz].c =M[M[t[nod]].poz].c-minim;
                    nod = M[t[nod]].x;
                }
            }
        }
    }
    cout<<c<<"\n";

    //nodurile cuplate fac parte din arcele care nu au extremitatile in sursa
    // sau destinatie si au capacitatea 0

    for(auto muchie: M){
        if(muchie.c==0 && muchie.x!=s && muchie.y!=d && muchie.x<muchie.y){
            cout<<muchie.x << " " << muchie.y-l<<"\n";
        }
    }
}