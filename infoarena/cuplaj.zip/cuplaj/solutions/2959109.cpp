#include <iostream>
#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream in("cuplaj.in");
ofstream out("cuplaj.out");

vector<int> adjList [20005];
int cap[20005][20005];
int n,m,e;
void read(){
    in >> n >> m >> e;
    int x, y;
    for(int i = 0; i < e; i++)
    {
        in >> x >> y;
        adjList[x].emplace_back(y+n);
        adjList[y + n].emplace_back(x);
        cap[x][y+n] = 1;
    }
    for(int i = 1; i <= n; i++)
    {
        adjList[0].emplace_back(i);
        adjList[i].emplace_back(0);
        cap[0][i] = 1;
    }
    for(int i = 1; i <= m; i++)
    {
        adjList[i + n].emplace_back(n + m + 1);
        adjList[n + m + 1].emplace_back(i + n);
        cap[i + n][n+m+1] = 1;
    }
}

int BFS(int source, int dest, vector<int>& parent)
{

    fill(parent.begin(), parent.end(), -1);
    parent[source] = 0;
    queue<int> q;
    q.push(source);
    while(!q.empty()) {

        int pNode = q.front(); //nodul parinte
        q.pop();
        for (auto el: adjList[pNode])
        {
            int cNode = el; // copiii nodului parinte actual
            if(cNode != pNode && parent[cNode] == -1 && cap[pNode][cNode] > 0)
            {
                parent[cNode] = pNode;
                if(cNode == dest)
                {
                    return 1;
                }
                //adaugam urmatorul nod ce urmeaza sa fie vizitat
                q.push({cNode});
            }
        }
    }
    return 0;
}


int FordFulkerson(int source, int dest)
{
    vector<int> parent(n + m + 3, -1);
    int mxFlow = 0;


    while(BFS(source,dest,parent)) {

        for (auto el: adjList[dest]) {
            if (parent[el] != -1) {
                int mnCap = INT_MAX;
                int cNode = dest;
                parent[dest] = el;
                while (cNode != source) {
                    mnCap = min(mnCap, cap[parent[cNode]][cNode]);
                    cNode = parent[cNode];
                }
                cNode = dest;
                while (cNode != source){
                    cap[cNode][parent[cNode]] += mnCap;
                    cap[parent[cNode]][cNode] -= mnCap;
                    cNode = parent[cNode];
                }
                mxFlow += mnCap;
            }
        }
    }
    return mxFlow;
}

int main()
{
    read();

    out<<FordFulkerson(0, n + m + 1)<<endl;

    for(int i = 1; i <= n; i++)
    {
        for(auto el : adjList[i])
        {
            if(el != 0 && el != n + m +1 && cap[i][el] == 0)
            {
                out<<i<<" "<<el - n<<endl;
            }
        }
    }
    return 0;
}