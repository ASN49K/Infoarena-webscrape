///Cuplaj maxim in graf bipartit
#include <fstream>
#include <vector>
using namespace std;
ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");
const int maxn=1e5+5;
int n1,n2,m;
///st[i]=nodul din dreapta la care este cuplat i
///dr[i]=nodul din stanga la care este cuplat i
///adj[i]=lista de adiacenta a nodului i din stanga
vector<int>adj[maxn];
int st[maxn],dr[maxn];
int vis[maxn];
///daca am gasit un drum alternant incepand din x
bool drum(int x){
    vis[x]=1;
    for(auto e:adj[x]){
        if(dr[e]==0){
            st[x]=e;
            dr[e]=x;
            return 1;
        }
    }
    for(auto e:adj[x]){
        if(!vis[dr[e]]){
            if(drum(dr[e])){
                st[x]=e;
                dr[e]=x;
                return 1;
            }
        }
    }
    return 0;
}
int cuplaj(){
    int c=0;
    int oldc=-1;
    while(c!=oldc){
        oldc=c;
        for(int i=1;i<=n1;i++) vis[i]=0;
        for(int i=1;i<=n1;i++){
            if(st[i]==0&&vis[i]==0){
                c+=drum(i);
            }
        }
    }
    return c;
}
int main()
{
    cin>>n1>>n2>>m;
    for(int i=1;i<=m;i++){
        int x,y;
        cin>>x>>y;
        adj[x].push_back(y);
    }
    cout<<cuplaj()<<'\n';
    for(int i=1;i<=n1;i++){
        if(st[i]!=0){
            cout<<i<<" "<<st[i]<<'\n';
        }
    }
    return 0;
}
