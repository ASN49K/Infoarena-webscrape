﻿#include <fstream>
#include <algorithm>
#include <cmath>
#include <vector>
#include <map>
#include <unordered_map>
#include <set>
#include <cstring>
#include <chrono>
#include <cassert>
#include <bitset>
#include <stack>
#include <queue>
#include <iomanip>
#include <random>
#include <string>
#include <complex>
#include <ext/pb_ds/assoc_container.hpp>

#ifdef _MSC_VER
#  include <intrin.h>
#  define __builtin_popcount __popcnt
#  define __builtin_popcountll __popcnt64
#endif

#pragma GCC optimize("Ofast")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#define x first
#define y second
#define ld long double
#define ll long long
#define ull unsigned long long
#define us unsigned short
#define lsb(x) ((x) & (-(x)))
#define pii pair <int, int>
#define pll pair <ll, ll>

using namespace std;
using namespace __gnu_pbds;

mt19937_64 gen(time(0));
uniform_int_distribution <int64_t> rng;

#ifdef  LOCAL
ifstream cin("test.in");
ofstream cout("test.out");
#else
ifstream cin("cuplaj.in");
ofstream cout("cuplaj.out");
#endif

const int N = 20000;

struct Flow {
    int n;

    int lvl[N + 5];
    gp_hash_table <int, int> cap[N + 5];
    vector <int> g[N + 5];

    void init(int _n) {
        n = _n;

        for (int i = 1; i <= n; i++)
            g[i].clear(), cap[i].clear();
    }

    void add_edge(int x, int y, int z) {
        cap[x][y] += z;
        g[x].push_back(y);
        g[y].push_back(x);
    }

    bool bfs(int src, int dst) {
        queue <int> q;
        memset(lvl, 0, sizeof(lvl));
        lvl[src] = 1;
        q.push(src);

        while (!q.empty()) {
            int node = q.front();
            q.pop();
            for (auto& son : g[node]) {
                if (!lvl[son] && cap[node][son] > 0) {
                    lvl[son] = lvl[node] + 1;
                    q.push(son);
                }
            }
        }

        return lvl[dst] > 0;
    }

    int dfs(int node, int dst, int flow = (int)1e9) {
        if (node == dst)
            return flow;
        for (auto& son : g[node]) {
            if (cap[node][son] <= 0 || lvl[son] != lvl[node] + 1)
                continue;
            int new_flow = dfs(son, dst, min(flow, cap[node][son]));

            if (new_flow) {
                cap[node][son] -= new_flow;
                cap[son][node] += new_flow;
                return new_flow;
            }
            lvl[son] = 0;
        }
        return 0;
    }

    int max_flow(int src, int dst) {
        int total_flow = 0, flow;
        while (bfs(src, dst)) {
            do {
                flow = dfs(src, dst);
                total_flow += flow;
            } while (flow);
        }

        return total_flow;
    }
} flow;

int n, m, e;

void solve(int test) {
    ld t1 = clock();
    cin >> n >> m >> e;
    flow.init(n + m + 2);
    vector <pii> edges;
    int src = n + m + 1, dst = n + m + 2;
    for (; e; e--) {
        int x, y;
        cin >> x >> y;
        edges.push_back({ x, y });
        flow.add_edge(x, y + n, 1);
    }
    for (int i = 1; i <= n; i++)
        flow.add_edge(src, i, 1);
    for (int i = 1; i <= m; i++)
        flow.add_edge(n + i, dst, 1);
    cout << flow.max_flow(src, dst) << "\n";
    for (auto &[i, j] : edges) {
        if (flow.cap[i][j + n] == 0)
            cout << i << " " << j << '\n';
    }
#ifdef LOCAL
    cout << (clock() - t1) / CLOCKS_PER_SEC << "s\n";
#endif
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    srand(time(0));

    int T = 1;
    //cin >> T;

    for (int t = 1; t <= T; t++) {
        solve(t);
    }

    return 0;
}