#include <fstream>
#include <vector>
using namespace std;
ifstream in("cuplaj.in");
ofstream out("cuplaj.out");
const int MAXN = 10010;
int l[MAXN], r[MAXN], n, m, e, check[MAXN], best, i, a, b;
vector <vector<int>> v;
bool change;
bool pairup(int node)
{
    if (check[node] != 0) ///ups, l-am verificat deja, sorry!
        return 0;
    check[node] = 1;
    for (auto i: v[node])
        if (r[i] == 0) ///aceasta muchie cu i (adica cu nodul b) nu este cuplata, asa ca o cuplam noi acum
        {
            r[i] = node;
            l[node] = i;
            return 1;
        }
    for (auto i: v[node]) ///acum cuplam muchii deja cuplate
        if (pairup(r[i]) != 0) ///oare putem cupla doua cuplate?
        {
            r[i] = node;
            l[node] = i;
            return 1;
        }
    return 0; ///nu am cuplat nimic
}
int main()
{
    in >> n >> m >> e;
    v.resize(n+2);
    for (i = 1; i <= e; i++)
    {
        in >> a >> b;
        v[a].push_back(b); ///exista muchie de la nodul a din l in nodul b din r
        //v.push_back(b, a);
    }
    change = 1;
    while (change)
    {
        change = 0; ///cat timp facem modificari, are rost sa continuam sa verificam
        for (i = 1; i <= n; i++)
            check[i] = 0;
        for (i = 1; i <= n; i++)
            if (l[i] == 0)
                change |= pairup(i); ///daca da pairup negativ la final e labubu
    }
    for (i = 1; i <= n; i++)
        best += (l[i] != 0); ///adaugam fiecare nod care este cuplat
    out << best << '\n'; ///curios, nu trebuie -1 ?
    for (i = 1; i <= n; i++)
        if (l[i] != 0)
            out << i << ' ' << l[i] << '\n'; ///muchiile cuplate
    return 0;
}
