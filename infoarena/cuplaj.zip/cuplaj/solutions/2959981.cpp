#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("cuplaj.in");
ofstream fout("cuplaj.out");

struct edge{
    int node1, node2, cap, pos;
};
vector<vector<int> > adjList;
vector<edge> edges;
vector<bool> visited;
vector<int> parent;
edge muchie;
int n, m, e, nrN, source, dest;

void addEdge(int x, int y){
    int dim = (int)edges.size();
    // Adaug muchia de capacitate 1.
    adjList[y].push_back(dim + 1);
    muchie.node1 = x;
    muchie.node2 = y;
    muchie.cap = 1;
    muchie.pos = dim + 1;
    edges.push_back(muchie);

    // Adaug muchia inversa de capacitate 0.
    adjList[x].push_back(dim);
    muchie.node1 = y;
    muchie.node2 = x;
    muchie.cap = 0;
    muchie.pos = dim;
    edges.push_back(muchie);
}
// Intoarce un boolean care arata daca a gasit sau nu macar un drum de ameliorare.
bool bfs() {
    // Se va crea arborele BFS prin vectorul de parinti.
    parent.clear();
    parent.resize(nrN);
    visited.clear();
    visited.resize(nrN, false);

    visited[source] = true;
    queue<int> q;
    q.push(source);
    while (!q.empty()) {
        // Nodul parinte.
        int pNode = q.front();
        q.pop();
        if(pNode != dest)
            // Pozitia din lista de muchii a nodului parinte.
            for (int index: adjList[pNode]) {
                edge cEdge = edges[index];
                if (!visited[cEdge.node2] && cEdge.cap != 0) {
                    parent[cEdge.node2] = index;
                    // Adaug urmatorul nod ce urmeaza sa fie vizitat.
                    q.push(cEdge.node2);
                    visited[cEdge.node2] = true;
                }
            }
    }
    return visited[dest];
}

int FordFulkerson(int source, int dest) {
    int maxFlow = 0;
    // Atata timp cat mai exista drumuri de ameliorare, inseamna ca mai putem adauga flux.
    while (bfs()) {
        for (int index: adjList[dest]) {
            if (visited[edges[index].node2] && edges[edges[index].pos].cap != 0) {
                int minCap = 2e9;
                edge cEdge = edges[index];
                parent[dest] = cEdge.pos;
                int cNode = dest;
                while (cNode != source) {
                    minCap = min(minCap, edges[parent[cNode]].cap);
                    cNode = edges[parent[cNode]].node1;
                }
                cNode = dest;
                // Parcurg din nou drumul de ameliorare pentru ca sa adaug fluxul nou.
                while (cNode != source){
                    edges[edges[parent[cNode]].pos].cap += minCap;
                    edges[parent[cNode]].cap -= minCap;
                    cNode = edges[parent[cNode]].node1;
                }
                maxFlow += minCap;
            }
        }
    }
    return maxFlow;
}

int main() {
    int x, y;
    fin >> n >> m >> e;
    // Numarul de noduri.
    nrN = n + m + 2;
    source = 0;
    dest = nrN - 1;
    adjList.resize(nrN);

    for (int i = 0; i < e; ++i) {
        fin >> x >> y;
        addEdge(x, y + n);
    }
    // Adaug muchii de la sursa la toate nodurile din stanga
    for (int i = 1; i <= n; ++i)
        addEdge(source, i);
    // Adaug muchii de la toate nodurile din dreapta la destinatie
    for (int i = 1; i <= m; ++i)
        addEdge(i + n, dest);

    fout << FordFulkerson(source, dest) << endl;

    for (edge edge_: edges)
        if(edge_.node1 < edge_.node2 && edge_.node1 != 0 && edge_.node2!= dest && edge_.cap == 0)
            fout << edge_.node1 << " " << edge_.node2 - n << "\n";

    return 0;
}