#include<bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debugs(x) cerr << #x << " " << x << " "
#pragma GCC optimize("Ofast")
#define int long long

using namespace std;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int range_rng(int l, int r)
{
    return uniform_int_distribution<int>(l,r)(rng);
}

vector<int> nodes[10005];
vector<pair<int,int>> perechi;
int match[10005];
bool viz[10005];

bool path(int node)
{
     int nxt;
     viz[node]=1;
     for (auto x : nodes[node])
     {
          nxt=match[x];
          if (nxt)
          {
              if (!viz[nxt] && path(nxt))
              {
                  match[x]=node;
                  match[node]=x;
                  return 1;
              }
          }
          else
          {
              match[x]=node;
              match[node]=x;
              return 1;
          }
     }
     return 0;
}

signed main()
{
    //ifstream fin("undo.in");
    //ofstream fout("undo.out");
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    int i,n,m,e,x,y,cuplaj;
    bool ok;
    cin >> n >> m >> e;
    for (i=1;i<=e;i++)
    {
         cin >> x >> y;
         nodes[x].push_back(y+n);
         nodes[y+n].push_back(x);
    }
    for (i=1;i<=n+m;i++)
         match[i]=0;
    ok=1;
    cuplaj=0;
    while (ok)
    {
        ok=0;
        for (i=1;i<=n+m;i++)
            viz[i]=0;
        for (i=1;i<=n;i++)
        {
             if (!match[i] && !viz[i] && path(i))
             {
                  ok=1;
                  cuplaj++;
             }
        }
    }
    for (i=1;i<=n;i++)
    {
          if (match[i])
          perechi.push_back({i,match[i]});
    }
    cout << cuplaj << "\n";
    for (auto x : perechi)
    {
         cout << x.first << " " << x.second-n << "\n";
    }
    return 0;
}
