#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;
#define INF 9999999
vector<vector<int>>adj;
int capacity[20002][20002];
int tata[20002];
int n,m;
int bfs(){
    queue<pair<int,int>> q;
    for(int i=0;i<=n+m+1;i++){
        tata[i]=-1;
    }
    q.push({0,INF});
    tata[0]=-2;
    while(!q.empty()){
        int u=q.front().first;
        int flow=q.front().second;
        q.pop();
        for(auto v:adj[u]){
            if(tata[v]==-1 && capacity[u][v]>0){
                tata[v]=u;
                int new_flow=min(flow,capacity[u][v]);
                if(v==n+m+1)
                    return new_flow;
                q.push({v,new_flow});
            }
        }
    }
    return 0;
}
int main() {
    int x,y,i,j,flow,maxflow=0,e;
    ifstream cin("cuplaj.in");
    ofstream cout("cuplaj.out");
    cin>>n>>m>>e;
    adj.resize(n+m+2);
    for(i=1;i<=e;i++){
        cin>>x>>y;
        adj[0].push_back(x);
        adj[x].push_back(0);
        capacity[0][x]=1;
        capacity[y+n][n+m+1]=1;
        adj[y+n].push_back(n+m+1);
        adj[n+m+1].push_back(y+n);

        adj[x].push_back(y+n);
        adj[y+n].push_back(x);
        capacity[x][y+n]=1;
    }
    while(flow=bfs()){
        maxflow+=flow;
        int cur=n+m+1;
        while(cur!=0){
            int prev=tata[cur];
            capacity[cur][prev]+=flow;
            capacity[prev][cur]-=flow;
            cur=prev;
        }
    }
    cout<<maxflow<<'\n';
    for(i=1;i<=n;i++)
        for(j=n+1;j<=n+m;j++)
            if(capacity[j][i]==1){
                cout<<i<<" "<<j-n<<'\n';
            }

    cin.close();
    cout.close();
}
