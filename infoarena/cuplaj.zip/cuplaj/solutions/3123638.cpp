#include <cmath>
#include <functional>
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <set>
#include <map>
#include <list>
#include <time.h>
#include <math.h>
#include <random>
#include <deque>
#include <cassert>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <iomanip>
#include <bitset>
#include <sstream>
#include <stack>
#include <chrono>
#include <cstring>
#include <numeric>
using namespace std;
signed main() {
#ifdef ONPC
	FILE* stream;
	freopen_s(&stream, "input.txt", "r", stdin);
#else
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	freopen("cuplaj.in", "r", stdin);
	freopen("cuplaj.out", "w", stdout);
#endif
	int n, m, e;
	bool changed;
	cin >> n >> m >> e;
	vector<vector<int>> g(n);
	for (int i = 1; i <= e; i++) {
		int a, b;
		cin >> a >> b;
		a--;
		b--;
		assert(0 <= a && a < n);
		assert(0 <= b && b < m);
		g[a].push_back(b);
	}
	vector<int> pi(n, -1), pj(m, -1);
	auto pairup = [&](int i, int j) {
		pi[i] = j;
		pj[j] = i;
	};
	vector<bool> vis;
	function<bool(int)> dfs = [&](int a) {
		if (vis[a]) {
			return 0;
		}
		vis[a] = 1;
		for (auto& b : g[a]) {
			if (pj[b] == -1) {
				pairup(a, b);
				return 1;
			}
		}
		for (auto& b : g[a]) {
			if (dfs(pj[b])) {
				pairup(a, b);
				return 1;
			}
		}
		return 0;
	};
	do {
		changed = 0;
		vis.clear();
		vis.resize(n, 0);
		for (int i = 0; i < n; i++) {
			if (pi[i] == -1) {
				changed |= dfs(i);
			}
		}
	} while (changed);
	int num = 0;
	for (int i = 0; i < n; i++) {
		num += (pi[i] != -1);
	}
	cout << num << "\n";
	for (int i = 0; i < n; i++) {
		if (pi[i] != -1) {
			cout << i + 1 << " " << pi[i] + 1 << "\n";
		}
	}
	return 0;
}