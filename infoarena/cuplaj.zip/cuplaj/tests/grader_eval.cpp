#include <cstdio>
#include <cstdlib>
#include <vector>
using namespace std;

#define FIN  "cuplaj.in"
#define FOUT "cuplaj.out"
#define FOK  "cuplaj.ok"

int l[10005], r[10005], n, m, e, Cuplaj, cuplaj;

vector <int> adj[10005];

void error(char msg[], int p)
{
	fprintf(stderr, msg);
	printf("%d", p);
	exit(0);
}

int vecin(int x, int y)
{
    for (int i = 0; i < adj[x].size(); ++ i)
        if (y == adj[x][i])
            return 1;
    return 0;
}

int main(void)
{
    int i, x, y;
    FILE *f;

    f = fopen(FIN, "r");
    if (!f) error("Nu am putut deschide fisierul de intrare", 0);
    if (fscanf(f, "%d %d %d", &n, &m, &e) != 3)
        error("Eroare in fisierul de intrare", 0);
    for (int i = 0; i < e; ++ i)
    {
        if (fscanf(f, "%d %d", &x, &y) != 2)
            error("Eroare in fisierul de intrare", 0);
        adj[x].push_back(y);
    }

    f = fopen(FOK, "r");
    if (!f) error("Nu am putut deschide fisierul de verificare", 0);
    if (fscanf(f, "%d", &Cuplaj) != 1)
        error("Eroare in fisierul de verificare", 0);

    f = fopen(FOUT, "r");
    if (!f) error("Fisier de iesire inexistent", 0);
    if (fscanf(f, "%d", &cuplaj) != 1)
        error("Fisier de iesire gol", 0);
    if (cuplaj != Cuplaj)
        error("Raspuns gresit", 0);
    for (int i = 0; i < cuplaj; ++ i)
    {
        if (fscanf(f, "%d %d", &x, &y) != 2)
            error("Multime de muchii incompleta", 4);
        if (x < 1 || x > n || y < 1 || y > m)
            error("Nod inexistent in graf", 4);
        if (l[x] || r[y])
            error("Multime de muchii incorecta", 4);
        if (!vecin(x, y))
            error("Muchie inexistenta", 4);
        l[x] = r[y] = 1;
    }
    error("OK", 10);

    return 0;
}

