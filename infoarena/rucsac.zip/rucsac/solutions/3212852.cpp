#include <fstream>

using namespace std;

int max(int a, int b)
{
    return (a > b) ? a : b;
}

int energie(int w, int e[], int c[], int n)
{
    if (n == 0 || w == 0)
        return 0;

    if (e[n - 1] > w)
        return energie(w, e, c, n - 1);
    else
        return max(c[n - 1]+ energie(w - e[n - 1], e, c, n - 1),energie(w, e, c, n - 1));
}

int main()
{
    ifstream in("energii.in");
    ofstream out("energii.out");
    int g,w,e[10000],c[10000];

    in >> g >> w;

    for(int i=0; i<g; i++)
    {
        in >> e[i] >> c[i];
    }

    out << energie(w,e,c,g);


    return 0;
}
