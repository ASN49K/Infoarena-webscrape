#include <fstream>
#include <algorithm>
#include <cmath>
#include <cstring>
using namespace std;
ifstream cin("rucsac.in") ;
ofstream cout("rucsac.out") ;
int nr,greutate[5005],valoare[5005],profit[10005],m,i,j,greutate_max;
int main()
{
    cin>>nr>>greutate_max;
    for(i=1;i<=nr;i++)
        cin>>greutate[i]>>valoare[i];
    for(i=1;i<=greutate_max;i++)
        profit[i]=-1;
    profit[0]=0;
    for(i=1;i<=nr;i++)
        for(j=greutate_max-greutate[i];j>=0;j--)
        {
            if(profit[j]!=-1&&profit[j]+valoare[i]>profit[j+greutate[i]])
                    profit[j+greutate[i]]=profit[j]+valoare[i];
        }
    cout<<profit[greutate_max];
    return 0;

}
