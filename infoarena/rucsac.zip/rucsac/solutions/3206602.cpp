#include <bits/stdc++.h>

using namespace std;

ifstream f("rucsac.in");
ofstream g("rucsac.out");

int n,k,m,x,y,i;
long long v[50001];

void rucs(int p1,int p)
{
    for (i=k;i>=0;i--)
    {
        if (v[i]!=-1)
        {
            if (v[i+p1]<v[i]+p)
            v[i+p1]=p+v[i];
        }
    }
}

int cmp()
{
    for(i=1;i<=k;i++)
        if(v[i]>m)
         m=v[i];
    return m;
}

int main()
{

    f>>n>>k;
    for(i=1;i<=k;i++)
        v[i]=-1;
    for(i=0;i<n;i++)
    {
        f>>x>>y;
        rucs(x,y);
    }
    g<<cmp();
    return 0;
}
