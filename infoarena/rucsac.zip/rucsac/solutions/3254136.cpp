#include <iostream>
#include <fstream>

using namespace std;

const int nmax=5001, gmax=10001;
int v[nmax][2], dp[nmax][gmax];

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int main()
{
    int n, g;
    fin >> n >> g;
    for(int i=1; i<=n; i++)
        fin >> v[i][0] >> v[i][1];
    for(int i=1; i<=n; i++)
        for(int w=1; w<=g; w++)
        {
            if(v[i][0]>w)
                dp[i][w]=dp[i-1][w];
            else
                dp[i][w]=max(dp[i-1][w], dp[i-1][w-v[i][0]] + v[i][1]);
        }
    fout << dp[n][g];
    return 0;
}
