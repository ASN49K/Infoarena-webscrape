import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Parser sc = new Parser("rucsac.in");

        int n = sc.nextInt();
        int g = sc.nextInt();

        // Singura memorie alocata in tot programul: un vector de marime g+1 (~40 KB)
        int[] dp = new int[g + 1];

        for (int i = 0; i < n; i++) {
            // Citim pe loc obiectul curent
            int currentW = sc.nextInt();
            int currentP = sc.nextInt();

            // Actualizam rucsacul folosind doar obiectul proaspat citit
            for (int j = g; j >= currentW; j--) {
                if (dp[j - currentW] + currentP > dp[j]) {
                    dp[j] = dp[j - currentW] + currentP;
                }
            }
        }

        // Afisarea rapida fara PrintWriter
        FileOutputStream out = new FileOutputStream("rucsac.out");
        out.write((String.valueOf(dp[g]) + "\n").getBytes());
        out.close();
    }
}

// Aceasta este clasa magica pentru Infoarena.
// Nu creeaza absolut niciun String in memorie, citind direct octetii!
class Parser {
    private final FileInputStream in;
    private final byte[] buffer = new byte[8192];
    private int head = 0;
    private int tail = 0;

    public Parser(String filename) throws IOException {
        in = new FileInputStream(filename);
    }

    public int nextInt() throws IOException {
        int c = read();
        // Sarim peste spatii, tab-uri sau enter-uri
        while (c <= ' ') {
            c = read();
        }

        int res = 0;
        // Construim numarul cifra cu cifra
        do {
            res = res * 10 + (c - '0');
            c = read();
        } while (c > ' ');

        return res;
    }

    private int read() throws IOException {
        if (head >= tail) {
            head = 0;
            tail = in.read(buffer, 0, buffer.length);
            if (tail <= 0) return -1;
        }
        return buffer[head++];
    }
}