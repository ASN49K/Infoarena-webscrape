#include <stdio.h>
#include <algorithm>
using namespace std;
int n,s,d[5001],t[5001],i,j,p[5001],G[5001],sol;
int main()
{
    FILE *f=fopen("rucsac.in","r");
    FILE *g=fopen("rucsac.out","w");
    fscanf(f,"%d%d",&n,&s);
    for(i=1;i<=n;i++)
        fscanf(f,"%d%d",&G[i],&p[i]);
    d[0]=1;
    for(i=1;i<=n;i++)
        for(j=s;j>=0;j--)
            if(d[j] && j+G[i]<=s)
            {
                d[j+G[i]]=max(d[j+G[i]],p[i]+d[j]);
                sol=max(sol,d[j+G[i]]);
            }
    fprintf(g,"%d",sol-1);
}