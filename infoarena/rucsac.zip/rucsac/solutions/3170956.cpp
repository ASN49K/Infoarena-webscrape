#include <bits/stdc++.h>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
typedef long long ll;
typedef long double ld;
ll sumw,prof,pmax ;
ll p[5005],wt[5005];
int viz[5005];
ll n,W;
struct date
{
    ll w;
    ll prf;
} v[5005];
bool sortbycomp(date a,date b)
{
    return a.prf*b.w>=b.prf*a.w;
}
ll greedy(int poz,ll g)
{
    ll greu=0,pf=0;
    for(int i=poz;i<=n;i++)
    if(greu+v[i].w<=g)
    {
        greu+=v[i].w;
        pf+=v[i].prf;
    }
    return pf;
}
ld greedy2(int poz,ll g)
{
    ld greu=0,pf=0;
    for(int i=poz;i<=n;i++)
    if(greu+v[i].w<=g)
    {
        greu+=v[i].w;
        pf+=v[i].prf;
    }
    else
    {
        ld a=g-greu;
        ld prof=(a*v[i].prf)/(ld)(v[i].w);
        pf+=prof;
        ld gg=(ld)(g-greu)/(ld)(v[i].w);
        return pf;
    }
    return pf;
}
void profit(int n)
{
    for(int i=n;i>=1;i--)
        p[i]=p[i+1]+v[i].prf;
    for(int i=n;i>=1;i--)
        wt[i]=wt[i=1]+v[i].w;
}
void bkt(int poz)
{
    if(poz==n+1)
    {
        pmax=max(pmax,prof);
        return;
    }
    viz[poz]=0;
    bkt(poz+1);
    viz[poz]=1;
    sumw+=v[poz].w;
    prof+=v[poz].prf;
    if((sumw<=W)&&(ld)prof+greedy2(poz+1,W-sumw)>=(ld)(pmax))
        bkt(poz+1);
    sumw-=v[poz].w;
    prof-=v[poz].prf;
}

int main()
{
    fin>>n>>W;
    for(int i=1;i<=n;i++)
    {
       fin>>v[i].w>>v[i].prf ;
    }
    sort(v+1,v+n+1,sortbycomp);
    profit(n);
    pmax=greedy(1,W);
    bkt(1);
    fout<<pmax;
    return 0;
}
