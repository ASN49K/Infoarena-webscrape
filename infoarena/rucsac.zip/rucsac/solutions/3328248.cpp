#include <fstream>
#include <vector>

using namespace std;

ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

vector<int> profit, weight, dp;
int n, g, ans = -1;

int main() {
    cin >> n >> g;
    profit.resize(n + 1);
    weight.resize(n + 1);
    dp.assign(g + 1, -1);
    for (int i = 1 ; i <= n ; ++i) {
        cin >> weight[i] >> profit[i];
    }
    dp[0] = 0;
    for (int i = 1 ; i <= n ; ++i) {
        for (int j = g - weight[i] ; j >= 0 ; --j) {
            if (dp[j] >= -1 && dp[j + weight[i]] < dp[j] + profit[i])
                dp[j + weight[i]] = dp[j] + profit[i];
        }
    }
    for (int j = 1 ; j <= g ; ++j) {
        ans = max(ans, dp[j]);
    }
    cout << ans;
    return 0;
}