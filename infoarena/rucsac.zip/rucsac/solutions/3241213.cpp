#include <bits/stdc++.h>
using namespace std;

ifstream fin("level2_1.in");
ofstream fout("level2_1.out");

const vector<int> dx = {1, -1, 0, 0}, dy = {0, 0, 1, -1};
map<char, int> dir = {{'D', 0}, {'U', 1}, {'R', 2}, {'L', 3}};
map<pair<int, int>, bool>, int> isGhost;
vector<<pair<int, int>>>

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    fin >> n;
    char a[n][n];
    int x, y;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            fin >> a[i][j];
        }
    }
    fin >> x >> y;
    int len;
    fin >> len;
    string s;
    fin >> s;
    int answer = 0;
    int g;
    fin >> g;
    for (int i = 0; i < g; ++i) {
        int row, col;
        fin >> row, col;

    }
    fout << answer;
    return 0;
}
