#include <iostream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int main()
{
    int dp[10001]={0}, n, g, sol=0;
    fin>>n>>g;
    for(int i=1; i<=n; i++)
    {
        int p, w;
        fin>>w>>p;
        for(int j=g-w; j>=0; j--)
        {
            if(dp[j+w]<dp[j]+p)
            {
                dp[j+w]=dp[j]+p;
                if(dp[j+w]>sol)
                {
                    sol=dp[j+w];
                }
            }
        }
    }
    fout<<sol;
    return 0;
}
