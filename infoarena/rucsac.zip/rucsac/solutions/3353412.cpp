#include <bits/stdc++.h>
std::ifstream cin("rucsac.in");
std::ofstream cout("rucsac.out");
long long n,max,sum[5010],ans;
struct fractii{long long g,v;}a[5010];
void bkt(long long poz,long long sumg,long long sumv)
{
    ans=std::max(ans,sumv);
    if(poz>n||sumv+sum[poz]<=ans)
        return;
    if(sumg+a[poz].g<=max)
        bkt(poz+1,sumg+a[poz].g,sumv+a[poz].v);
    bkt(poz+1,sumg,sumv);
}
int main()
{
    cin>>n>>max;
    for(int i=1;i<=n;++i)
    {
        cin>>a[i].g>>a[i].v;
    }
    for(int i=1;i<=n;++i)
        for(int j=1;j<n;++j)
            if(a[j].v*a[j+1].g<a[j+1].v*a[j].g)
                std::swap(a[j],a[j+1]);
    for(int i=1;i<=n;++i)
    {
        int ga=0;
        for(int j=i;j<=n;++j)
        {
            if(ga+a[j].g<max)
            {
                sum[i]+=a[j].v;
                ga+=a[j].g;
            }
            else
            {
                sum[i]+=a[j].v*(max-ga)/a[j].g;
                break;
            }
        }
    }
    ans=sum[1];
    bkt(1,0,0);
    cout<<ans;
    return 0;
}
