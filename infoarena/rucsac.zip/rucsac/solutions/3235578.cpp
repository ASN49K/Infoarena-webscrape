#include <fstream>
#include <algorithm>

using namespace std;

ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

int dp[10001];

struct obj{int g,pr;};

int main()
{
    int n,G;
    cin>>n>>G;
    obj o[5001];

    for(int i=1;i<=n;i++)
        cin>>o[i].g>>o[i].pr;

     for(int i=1;i<=n;i++)
        for(int j=G;j>=1;j--)
            if(j>=o[i].g)
            {
                dp[j]=max(dp[j-o[i].g]+o[i].pr,dp[j]);
            }
    cout<<dp[G];
}
