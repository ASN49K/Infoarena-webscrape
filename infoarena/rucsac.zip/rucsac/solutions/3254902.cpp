#include <algorithm>
#include <bits/stdc++.h>

#define ll long long
#define ull unsigned long long
#define pii std::pair<int, int>

#define IO (std::string) "rucsac"
std::ifstream fin(IO + ".in");
std::ofstream fout(IO + ".out");

#define NMAX 5001

int n, G;
struct Obj {
  int g, p;
} o[NMAX];

int max = 0;
int gt[NMAX], pt[NMAX];

int gc, pc;
int v[NMAX];

bool viabil() {
  if (gc > G)
    return 0;

  return 1;
}

void bkt(int pos) {
  if (!viabil())
    return;
  if (pos == n + 1) {
    max = std::max(max, pc);
    return;
  }

  v[pos] = 0;
  bkt(pos + 1);
  v[pos] = 1;
  gc += o[pos].g;
  pc += o[pos].p;
  bkt(pos + 1);
  gc -= o[pos].g;
  pc -= o[pos].p;
}

void citire() {
  fin >> n >> G;
  for (int i = 1; i <= n; i++) {
    fin >> o[i].g >> o[i].p;
    gt[i] += gt[i - 1] + o[i].g;
    pt[i] += pt[i - 1] + o[i].p;
  }
}

int main() {
  fin.tie(0)->std::ios::sync_with_stdio(0);
  citire();
  std::sort(o, o + n + 1, [](Obj a, Obj b) { return a.g * b.p < b.g * a.p; });

  bkt(1);
  fout << max;
  return 0;
}
