#include <bits/stdc++.h>
using namespace std;
#define nMax 5005
#define GMax 10005
ifstream f("rucsac.in");
ofstream g("rucsac.out");

int n, G;
int w, p;
int dp[GMax];

int main()
{
    f >> n >> G;
    for(int i=1; i<=n; i++)
    {
        f >> w >> p;
        for(int j=G; j>=w; j--)
        {
            dp[j] = max(dp[j], dp[j-w] + p);
        }
    }
    g << dp[G];
}
