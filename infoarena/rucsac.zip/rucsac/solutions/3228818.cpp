#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream in("rucsac.in");
ofstream out("rucsac.out");
const int GMAX = 1e4 + 5;
int dp[GMAX];
int main()
{
    int n, g;
    in >> n >> g;
    for( int i = 1; i <= n; i++ ){
        int wi, pi; in >> wi >> pi;
        for( int j = g; j >= wi; j-- ){
            if( pi + dp[j - wi] > dp[j] )
                dp[j] = pi + dp[j - wi];
        }
    }
    int maxi = 0;
    for( int i = 1; i <= g; i++ )
        maxi = max( maxi, dp[i]);
    out << maxi;
    return 0;
}
