#include <fstream>
#include <vector>
using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");


vector<int> rucsac[2];


int main()
{
    int n,m,i,j,pret,greutate,maxim;
    bool turn=false;
    fin>>n>>m;
    for(i=0;i<=m;i++)
    {
        rucsac[0].push_back(0);
        rucsac[1].push_back(0);
    }
    for(i=0;i<n;i++)
    {
        fin>>greutate>>pret;
        for(j=0;j<=m;j++)
        {
            if(j>=greutate && rucsac[!turn][j]<=rucsac[!turn][j-greutate]+pret)
                rucsac[turn][j]=rucsac[!turn][j-greutate]+pret;
            else
                rucsac[turn][j]=rucsac[!turn][j];
        }
        turn=!turn;
    }

maxim=rucsac[!turn][0];
for(i=1;i<=m;i++)
{
    if(maxim<rucsac[!turn][i])
        maxim=rucsac[!turn][i];
}

    fout<<maxim<<'\n';
    fout.flush();
    return 0;
}
