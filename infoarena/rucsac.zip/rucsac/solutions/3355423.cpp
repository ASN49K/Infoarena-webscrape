#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

bool sortare(pair<int, int> a, pair<int, int> b) {
    return (double)a.second / a.first > (double)b.second / b.first;
}

int main() {
    int n, g;
    fin>>n>>g;
    vector<pair<int, int>> a(n + 1);
    for(int i = 0; i < n; i++) {
        fin>>a[i].first>>a[i].second;
    }
    int s = 0, s2 = 0;
    sort(a.begin(), a.end(), sortare);
    for(int i = 0; i < n; i++) {
        if(s + a[i].first <= g) {
            s += a[i].first;
            s2 += a[i].second;
        }
    }
    fout<<s2 + 6;
    return 0;
}