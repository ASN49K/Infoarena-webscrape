// https://infoarena.ro/problema/rucsac

#include <bits/stdc++.h>

using namespace std;

ifstream in("rucsac.in");
ofstream out("rucsac.out");

int main()
{
    int n, g;
    in >> n >> g;
    vector<pair<int, int>> knapsack(n + 1);
    for(int i = 1; i <= n; i++)
    {
        int w, pret;
        in >> w >> pret;
        knapsack[i] = {w, pret};
    }

    vector<vector<int>> dp(n + 1, vector<int>(g + 1, 0));
    for(int i = 1; i <= n; i++)
    {
        for(int w = 1; w <= g; w++)
        {
            dp[i][w] = dp[i - 1][w];

            if(knapsack[i].first <= w) 
            {
                dp[i][w] = max(dp[i - 1][w], dp[i - 1][w- knapsack[i].first] + knapsack[i].second);
            }
        }
    }

    out << dp[n][g] << "\n";
    return 0;
}