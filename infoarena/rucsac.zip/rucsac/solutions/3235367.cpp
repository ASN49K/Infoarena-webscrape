#include <fstream>
#include <algorithm>

using namespace std;

ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

int mat[5001][10001];

struct obj{int g,pr;};

int main()
{
    int n,G;
    cin>>n>>G;
    obj o[5001];

    for(int i=1;i<=n;i++)
        cin>>o[i].g>>o[i].pr;

     for(int i=1;i<=n;i++)
        for(int j=1;j<=G;j++)
            if(j>=o[i].g)
            {
                if(i!=1)
                {
                    int gcr=o[i].g;
                    mat[i][j]=max(mat[i-1][j],mat[i-1][j-gcr]+o[i].pr);
                }
                else
                    mat[i][j]=o[i].pr;
            }

    cout<<mat[n][G];
}
