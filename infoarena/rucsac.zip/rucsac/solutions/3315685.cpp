#include <fstream>
#define NMAX 5002
#define GMAX 10002
using namespace std;
ifstream  fin("rucsac.in");
ofstream fout("rucsac.out");
int N,G,W[NMAX],P[NMAX],dp[GMAX];
/// dp[greutate]=pret maxim
void citire()
{
    fin>>N>>G;

    for(int i=1; i<=N; i++)
    {
        fin>>W[i]>>P[i];
    }
}

int main()
{
    citire();

    dp[0]=0;
    for(int i=1; i<=N; i++)
    {
        for(int j=G-W[i]; j>=0; j--)
        {
            if(dp[j]+P[i]>dp[j+W[i]])
            {
                dp[j+W[i]]=dp[j]+P[i];
            }
        }
    }

    int ans=0;
    for(int i=0; i<=G; i++)
    {
        ans=max(ans,dp[i]);
    }

    fout<< ans << "\n";

    return 0;
}
