import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        int n, max_weight;
        int[] weights;
        int[] values;
        int[] dp;
        Scanner sc = new Scanner(System.in);

        n = sc.nextInt();
        max_weight = sc.nextInt();

        weights = new int[n];
        values = new int[n];
        dp = new int[max_weight + 1];

        for (int i = 0; i < n; ++i) {
            weights[i] = sc.nextInt();
            values[i] = sc.nextInt();
        }

        sc.close();

        for (int i = 0; i < n; ++i)
            for (int w = max_weight; w - weights[i] >= 0; --w)
                dp[w] = Math.max(dp[w], dp[w - weights[i]] + values[i]);

        System.out.println(dp[max_weight]);
    }
}
