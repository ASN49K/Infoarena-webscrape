#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int v[5001], g[5001];
int dp[10001];
int G, N;

int main()
{
    fin >> N >> G;
    for(int i = 1; i <= N; i++)
    {
        fin >> g[i] >> v[i];
    }
    dp[0] = 1;
    for(int i = 1; i <= N; i++)
    {
        for(int j = G; j >= g[i]; j--)
        {
            if(dp[j - g[i]])
            {
                dp[j] = max(dp[j], dp[j - g[i]] + v[i]);
            }
        }
    }
    int maxim = 0;
    for(int i = 1; i <= G; i++)
    {
        maxim = max(maxim, dp[i]);
    }
    fout << maxim - 1;
    return 0;
}
