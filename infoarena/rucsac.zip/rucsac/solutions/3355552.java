import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {
    public static final String INPUT_FILE = "rucsac.in";
    public static final String OUTPUT_FILE = "rucsac.out";

    public static void main(String[] args) throws FileNotFoundException {
        Scanner sc = new Scanner(new File(INPUT_FILE));
        PrintWriter pw = new PrintWriter(OUTPUT_FILE);

        int n = sc.nextInt();
        int g = sc.nextInt();

        int[] w = new int[n + 1];
        int[] p = new int[n + 1];

        for (int i = 1; i <= n; i++) {
            w[i] = sc.nextInt();
            p[i] = sc.nextInt();
        }

        int[][] dp = new int[n + 1][g + 1];

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= g; j++) {
                if (j < w[i]) {
                    dp[i][j] = dp[i - 1][j];
                } else {
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i - 1][j - w[i]] + p[i]);
                }
            }
        }

        pw.println(dp[n][g]);
        pw.close();
    }
}
