#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("rucsac.in");
ofstream fout ("rucsac.out");
int dp[10001];
int main()
{
    int n,g,j;
    fin>>n>>g;
    for(int i=1;i<=n;i++)
    {
        int w,p;
        fin>>w>>p;
        for( j=g;j>=w;j--)
        {
            dp[j]=max(dp[j],dp[j-w]+p);
        }
    }
    fout<<dp[g];
    return 0;
}
