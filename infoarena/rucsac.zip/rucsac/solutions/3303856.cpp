#include <fstream>
#include <vector>

using namespace std;

ifstream be("rucsac.in");
ofstream ki("rucsac.out");

int main()
{
    int n, g;

    be >> n >> g;

    vector<int> w(n + 1);
    vector<int> p(n + 1);

    for(int i = 1; i <= n; i++)
    {
        be >> w[i] >> p[i];
    }

    vector<int> dp(g + 1);

    for(int i = 1; i <= n; i++)
    {
        for(int j = g; j >= w[i]; j--)
        {
            dp[j] = max(p[i] + dp[j - w[i]], dp[j]); 
        }
    }

    ki << dp[g];

    return 0;
}