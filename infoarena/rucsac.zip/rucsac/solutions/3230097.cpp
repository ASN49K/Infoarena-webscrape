#include <fstream>
using namespace std;
ifstream in("rucsac.in");
ofstream out("rucsac.out");
int n, g, dp[2][5010], i, j;
pair<int, int> a;
void copiere()
{
	for (int i = 1; i <= g; i++)
		dp[0][i] = dp[1][i];
}
int main()
{
	in >> n >> g;
	for (i = 1; i <= n; i++)
	{
		copiere();
		in >> a.first >> a.second;
		for (j = 1; j <= g; j++)
		{
			dp[1][j] = dp[0][j];
			if (a.first <= j)
				dp[1][j] = max(dp[1][j], dp[0][j - a.first] + a.second);
		}
	}
	out << dp[1][g];
	return 0;
}