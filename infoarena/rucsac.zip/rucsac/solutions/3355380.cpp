#include <algorithm>
#include <climits>
#include <cstring>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
const long long MOD = 1e9 + 7;
int main() {
  ifstream fin("rucsac.in");
  ofstream fout("rucsac.out");
  int n;
  fin >> n;
  int g;
  fin >> g;
  vector<pair<int, int>> obj(n);

  for (int i = 0; i < n; i++) {
    int w, p;
    fin >> w >> p;
    obj[i] = {w, p};
  }
  vector<vector<int>> dp(n + 1, vector<int>(g + 1, 0));
  if (obj[0].first <= g)
    dp[0][obj[0].first] = obj[0].second;
  for (int i = 1; i < n; i++) {
    for (int j = 0; j <= g; j++) {
        dp[i][j] = dp[i-1][j];
        if(j-obj[i].first>=0)
        {
            dp[i][j] = max(dp[i-1][j],dp[i-1][j-obj[i].first]+obj[i].second);
        }
    }
  }
  fout<<dp[n][g];
  return 0;
} // 1 2 5 2 1 4 3 2