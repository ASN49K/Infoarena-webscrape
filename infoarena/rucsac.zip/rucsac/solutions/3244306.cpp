#include <fstream>

using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
long long w[10001],p[10001],dp[2][10001];
int main()
{
    int n;
    cin>>n;
    int g;
    cin>>g;
    for(int i=1;i<=n;i++)
    {
        cin>>w[i]>>p[i];
    }

    for(int i=1;i<=n;i++)
    {
        int lin_cur=i%2;
        int lin_ant=1-lin_cur;
        for(int j=w[i];j<=g;j++)
        {
               dp[lin_cur][j]=max(dp[lin_ant][j],dp[lin_ant][j-w[i]]+p[i]);
        }
    }
    long long max1=-10000000;
    for(int j=1;j<=g;j++)
    {
        max1=max(max1,dp[n%2][j]);
    }
    cout<<max1<<" ";
    return 0;
}
