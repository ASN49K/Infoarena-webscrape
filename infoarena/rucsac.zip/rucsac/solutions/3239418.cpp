#include <bits/stdc++.h>
#define ll long long
#define pb push_back
#define F first
#define S second
#define endl '\n'
#define all(a) (a).begin(),(a).end()
using namespace std;
const ll maxn = 2e5 + 5;
const ll mod = 1e9 + 7;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
 
void solve() {
    int n, g;
    fin >> n >> g;
    vector<int> w(n), p(n);
    for (int i = 0; i < n; i++) {
        fin >> w[i] >> p[i];
    }
    vector<vector<int>> dp(n + 1, vector<int>(g + 1));
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= g; j++) {
            if (i == 0 || j == 0) {
                dp[i][j] = 0;
            }
            else if (w[i] <= g) {
                dp[i][j] = max(dp[i - 1][j], p[i] + dp[i - 1][j - w[i]]);
            }
            else {
                dp[i][j] = dp[i - 1][j];
            }
        }
    }
    fout << dp[n][g] << endl;
}
 
int main() {
    ll t = 1;
    // cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}