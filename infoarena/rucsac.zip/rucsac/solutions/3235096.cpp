#include <fstream>

using namespace std;

ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

const int MAX_N = 5000;
const int MAX_G = 10000;

int n, g_max, dp[MAX_G + 1];

struct object {
	int profit;
	int greutate;
} v[MAX_N + 1];

int main() {

	cin >> n >> g_max;

	for (int i = 1; i <= n; i++)
		cin >> v[i].greutate >> v[i].profit;

	for (int i = 1; i <= n; i++) {
		for (int j = g_max; j >= v[i].greutate; j--)
            dp[j] = max(dp[j], dp[j - v[i].greutate] + v[i].profit);
	}

    cout << dp[g_max];

	return 0;
}
