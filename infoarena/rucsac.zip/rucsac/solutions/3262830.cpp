#include <fstream>
#include <vector>

using namespace std;

int main()
{
    ifstream in("rucsac.in");
    ofstream out("rucsac.out");
    int n, k;
    in >> n >> k;
    vector <int> g(n), p(n);
    for (int i = 0; i < n; i++)
    {
        in >> g[i] >> p[i];
    }
    vector <vector <int>> profit(n);
    vector <int> aux(k + 1, -1);
    if (g[0] <= k)
    {
        aux[g[0]] = p[0];
    }
    aux[0] = 0;
    profit[0] = aux;
    for (int i = 1; i < n; i++)
    {
        vector <int> aux(profit[i-1]);
        for (int j = g[i]; j <= k; j++)
        {
            if (profit[i-1][j-g[i]] != -1)
            {
                aux[j] = max(aux[j], profit[i-1][j-g[i]] + p[i]);
            }
        }
        profit[i] = aux;
    }
    int profit_max = -1;
    for (auto pr: profit[n-1])
    {
        profit_max = max(profit_max, pr);
    }
    out << profit_max << "\n";
    in.close();
    out.close();
    return 0;
}
