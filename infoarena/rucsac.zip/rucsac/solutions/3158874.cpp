#include <fstream>

using namespace std;

ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

int n, g;
struct tip{int greutate, pret;}v[5005];
int dp[10005];

int main()
{
    cin >> n >> g;
    for(int i = 1; i <= n; i++)
        cin >> v[i].greutate >> v[i].pret;
    for(int i = 1; i <= n; i++)
    {
        for(int j = g - v[i].greutate; j >= 0; j--)
        {
            if(dp[j + v[i].greutate] < dp[j] + v[i].pret)
            {
                dp[j + v[i].greutate] = dp[j] + v[i].pret;
            }
        }
    }
    cout << dp[g] << '\n';
    return 0;
}
