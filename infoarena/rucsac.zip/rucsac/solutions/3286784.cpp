#include <fstream>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int n, g, i, dp[2][5005], w[5005], p[5005], ans, j;
int main()
{
    fin>>n>>g;
    for(i=1; i<=n; i++)
        fin>>w[i]>>p[i];
    for(i=1; i<=n; i++)
    {
        for(j=1; j<=g; j++)
        {
            dp[i%2][j]=dp[(i+1)%2][j];
            if(j>=w[i])
                dp[i%2][j]=max(dp[i%2][j], dp[(i+1)%2][j-w[i]]+p[i]);
        }
        for(j=1; j<=g; j++)
            dp[(i+1)%2][j]=dp[i%2][j];
    }

    for(i=1; i<=g; i++)
        ans=max(ans, dp[n%2][i]);
    fout<<ans;
    return 0;
}
