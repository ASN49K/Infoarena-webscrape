#include <bits/stdc++.h> 
  
using namespace std; 
  
ifstream fin("rucsac.in"); 
ofstream fout("rucsac.out"); 

int n, g, w, p;
int dp[10001];
int main(){ 
// dp[i] = profitul maxim cu greutatea g
fin>>n>>g;
for (int i = 1; i <= n; i++){
    fin>>w>>p;
    for (int j = g; j >= 1; j--){
        if (dp[j] && j + w <= g)
            dp[j+w] = max(dp[j+w], dp[j] + p);
    }
    dp[w] = max(dp[w], p);
}
int Max = 0;
for (int i = 1; i <= g; i++){
    Max = max(Max, dp[i]);
}
fout << Max;
    return 0; 
}