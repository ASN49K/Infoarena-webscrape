#include <fstream>
#include <algorithm>
using namespace std;
ifstream F("rucsac.in");
ofstream G("rucsac.out");
int main(){
  int n,g;
  f>>n>>g;

  int weight, value;
  int dp[10001] = {0};

  while(F>>weight>>value) {
    for(int i=g;i>=weight;i--){
      dp[i]=max(dp[i],value+dp[i-weight]);
    }
  }
  G<<dp[g]<<"\n";

  // Inchidem fisierele
  F.close();
  G.close();

  return 0;
}
