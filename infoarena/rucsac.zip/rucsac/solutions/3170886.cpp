#include <fstream>
#include <algorithm>
#include <cstdlib>
#include <ctime>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

/*bool verif()
{
  int i;
  for(i=1; i<=n; i++)
  {
    if(v[i])
    {
      ww+=w[i];
      pp+=p[i];
    }
  }
  if(ww<W) return true;
  return false;
}*/

//poti calcula separat pt ultime 15/20 pozitii si sa te opresti

/*void bkt(int poz)
{
  if(ww>W) return;
  if(pp+greedy(i+1, W-ww)<=pmax) return;
  if(nu exista i a.i. sw[i]<ww<sw[i+1] si p[i]<ptot) return;
  if(poz<=n)
  {
    pmax=max(pmax, pp);
    bkt(poz+1);
    ww+=w[i];
    pp+=p[i];
    v[poz]=true;
    bkt(poz+1);
    ww-=w[i];
    pp-=p[i];
    v[poz]=false;
  }
  return;
}*/

int n, wmax, pmax;
pair<int, int> a[5005];

int main()
{
  int i, j, pp=0, ww=0, val;
  val=1e7;
  srand(time(0));
  fin>>n>>wmax;
  for(i=1; i<=n; i++) fin>>a[i].first>>a[i].second;
  for(i=1; i<=val/n; i++)
  {
    random_shuffle(a+1, a+n+1);
    for(ww=pp=0, j=1; j<=n; j++)
    {
      if(ww+a[j].first<=wmax)
      {
        ww+=a[j].first;
        pp+=a[j].second;
      }
    }
    pmax=max(pmax, pp);
  }
  fout<<pmax<<'\n';
}
