#include <fstream>
using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
int n,G;
int dp[5001][5001];
vector<pair<int,int>>obj;
int main()
{
    cin >> n >> G;
    for(int i=1;i<=n;i++)
    {
        int g,p;
        cin >> g >> p;
        for(int j=0;j<=G;j++)
            if(g<=j)
                dp[i][j]=max(dp[i-1][j],dp[i-1][j-g]+p);
    }
    cout << dp[n][G];
    return 0;
}
