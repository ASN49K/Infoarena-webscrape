#include<iostream>
#include<fstream>
#include<cstring>
using namespace std;
ifstream in("rucsac.in");
ofstream out("rucsac.out");
const int N=10001;
int v[N],c[N],i,j,P[N],W[N],n,g;

void read(){
int x,y;
in>>x>>y;
n=x;g=y;
for(i=1;i<=n;++i)

    in>>W[i]>>P[i];


}


int main(){

    read();

    for(i=1;i<=n;++i)v[i]=0;

    for(i=1;i<=n;++i){

        for(int j = 1;j<=g;++j)
        {

            if(W[i]<=j)
                c[j] = max(v[j],v[j-W[i]]+P[i]);
            else c[j] = v[j];


        }

        memcpy(v,c,sizeof(c));

        }
    out<<c[g];

return 0;}
