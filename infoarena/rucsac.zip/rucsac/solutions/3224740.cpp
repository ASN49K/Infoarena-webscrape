#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");


int main()
{
    int i,l,n,d[10001],j,g,k;
    fin>>n>>g;
    for(l=1;l<=n;l++)
    {
        fin>>i>>j;
        for(k=g;k>=i;--k)
            d[k] = max(d[k],d[k-i]+j);
    }
    fout<<d[g];
    return 0;
}
