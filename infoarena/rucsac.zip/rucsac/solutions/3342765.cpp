#include <fstream>

using namespace std;
const int NMAX=5000,
          GMAX=10000;

ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

struct obiect{
    int g,v;
};

int N,G;
int M[2][GMAX+1];
obiect a[NMAX+1];

int main()
{
    cin >> N >> G;
    for(int i=1;i<=N;i++)
        cin >> a[i].g >> a[i].v;
    //
    int p=0,u=1;
    for(int i=1;i<=N;i++){
        for(int j=0;j<=G;j++){
            if(a[i].g>j) M[u][j]=M[p][j];
            else M[u][j]=max(M[p][j],M[p][j-a[i].g]+a[i].v);
        }
        swap(p,u);
    }
    cout << M[p][G];
    return 0;
}
