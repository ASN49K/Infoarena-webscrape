#include <bits/stdc++.h>
using namespace std;

string fileName = "rucsac";
ifstream in (fileName + ".in");
ofstream out (fileName + ".out");

const int nMax = 5000;
const int mMax = 10000;

int weight[nMax], profit[nMax];
int dp[nMax];
int main( ) {
	int n, maxWeight; in >> n >> maxWeight;
	for (int i = 0; i < n; ++i) 
		in >> weight[i] >> profit[i];

	int ans = 0;
	dp[0] = 0;

	for (int i = 0; i < n; ++i)
		for (int j = maxWeight - weight[i]; j >= 0; --j)
			if (dp[j + weight[i]] < dp[j] + profit[i]) {
				dp[j + weight[i]] = dp[j] + profit[i];
				ans = max(ans, dp[j + weight[i]]);
			}
	out << ans << '\n';
	return 0;
}
