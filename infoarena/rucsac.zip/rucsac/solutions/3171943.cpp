#include <iostream>
#include <cstdio>
//#include <fstream>
#include <algorithm>
using namespace std;
int n,W,suf,i,j,k,VMAX,x,y,z,t,vtot,wtot;
pair<int,int> obj[5002],sufpart[5002];
int greedsuf(int poz,int wmax)
{
    int rez=0;
    while(poz<n&&obj[poz].first<wmax)rez+=obj[poz].second,wmax-=obj[poz++].first;
    if(poz==n)return rez;
    return rez+obj[poz].second*wmax/obj[poz].first;
}
void bkt(int poz)
{
    if(poz==n)
    {
        VMAX=max(VMAX,vtot);
        return;
    }
    //cerr<<poz<<endl;
    wtot+=obj[poz].first;
    vtot+=obj[poz].second;
    if(wtot>W||vtot+greedsuf(poz+1,W-wtot)<=VMAX)
    {
        wtot-=obj[poz].first,vtot-=obj[poz].second;
        bkt(poz+1);
        return;
    }
    if(wtot+sufpart[poz+1].first<=W){VMAX=max(vtot+sufpart[poz+1].second,VMAX);return;}
    bkt(poz+1);
    wtot-=obj[poz].first;
    vtot-=obj[poz].second;
    bkt(poz+1);
}
bool comp(pair<int,int>a,pair<int,int>b){return a.second*b.first>=b.second*a.first;}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    freopen("rucsac.in","r",stdin);
    freopen("rucsac.out","w",stdout);
    //ifstream cin("rucsac.in");
    //ofstream cout("rucsac.out");
    cin>>n>>W;
    for(i=0;i<n;i++)cin>>obj[i].first>>obj[i].second;
    sort(obj,obj+n,comp);
    obj[n].first=1;
    for(i=n-1;i>=0;i--)sufpart[i]=make_pair(sufpart[i+1].first+obj[i].first,sufpart[i+1].second+obj[i].second);
    x=VMAX=0;
    for(i=0;i<n;i++)
    {
        x+=obj[i].first;
        if(x<=W)VMAX+=obj[i].second;
        else break;
    }
    vtot=0;
    wtot=0;
    bkt(0);
    cout<<VMAX;
	return 0;
}
