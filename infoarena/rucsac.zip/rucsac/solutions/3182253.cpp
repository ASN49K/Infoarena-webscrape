#include <fstream>
#include <iostream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int dp[10001];

int main()
{
    int n,g;
    fin>>n>>g;
    int val[n+1],gr[n+1],i,j;
    for(i=1;i<=n;i++)
        fin>>gr[i]>>val[i];
    for(i=1;i<=n;i++)
        for(j=g-gr[i];j>=0;j--)
            dp[j+gr[i]]=max(dp[j+gr[i]],dp[j]+val[i]);
    fout<<dp[g];
    return 0;
}
