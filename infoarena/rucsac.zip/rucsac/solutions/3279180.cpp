#include <fstream>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int n;
int maxg;
int w;
int p;
int r[10001];
int main() {
    fin>>n>>maxg;
    for(int i=0;i<n;i++) {
        fin>>w>>p;
        for(int j=maxg-w; j>=0; --j) {
            r[j+w]=max(r[j+w],r[j]+p);
        }
    }
    fout<<r[maxg];
}
