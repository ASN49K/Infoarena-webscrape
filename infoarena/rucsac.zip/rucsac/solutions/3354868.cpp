#include <bits/stdc++.h>
#include <vector>
#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int main ()
{
    ios::sync_with_stdio(false);
    int n, g;
    fin >> n >> g;
    vector<int> dp(g + 1, 0);

    for (int i = 0; i < n; i++) {
        int w, p;
        fin >> w >> p;

        for (int cap = g; cap >= w; cap--) {
            dp[cap] = max(dp[cap], dp[cap - w] + p);
        }
    }

    fout << dp[g] << '\n';

    return 0;
}