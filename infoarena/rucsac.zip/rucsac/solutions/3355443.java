import java.io.*;
import java.util.StringTokenizer;

public class Main {
    public static void main(String[] args) throws IOException {
        MyScanner sc = new MyScanner("rucsac.in");
        PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter("rucsac.out")));

        int n = sc.nextInt();
        int g = sc.nextInt();

        // Folosim indexare de la 1 pentru a avea linia 0 si coloana 0 ca "borduri"
        int[] w = new int[n + 1]; // greutatile
        int[] p = new int[n + 1]; // profiturile

        for (int i = 1; i <= n; i++) {
            w[i] = sc.nextInt();
            p[i] = sc.nextInt();
        }

        // dp[i][j] = profitul maxim obtinut folosind o submultime din primele 'i' obiecte,
        // avand la dispozitie un rucsac de capacitate 'j'
        int[][] dp = new int[n + 1][g + 1];

        for (int i = 1; i <= n; i++) {
            for (int j = 0; j <= g; j++) {

                // Daca obiectul curent 'i' incape in rucsacul de capacitate 'j'
                if (w[i] <= j) {
                    // Alegem maximul dintre:
                    // 1. NU luam obiectul (pastram profitul de la pasul anterior pentru aceeasi capacitate)
                    // 2. LUAM obiectul (adunam profitul lui la profitul optim obtinut pe capacitatea ramasa)
                    dp[i][j] = Math.max(dp[i - 1][j], dp[i - 1][j - w[i]] + p[i]);
                }
                else {
                    // Daca obiectul NU incape, suntem obligati sa nu il luam
                    dp[i][j] = dp[i - 1][j];
                }

            }
        }

        // Raspunsul se afla in coltul dreapta-jos: am analizat toate cele 'N' obiecte,
        // avand la dispozitie toata capacitatea 'G'
        out.println(dp[n][g]);
        out.close();
    }
}

// Clasa MyScanner ramane la fel
class MyScanner {
    BufferedReader br;
    StringTokenizer st;

    public MyScanner(String fileName) throws FileNotFoundException {
        br = new BufferedReader(new FileReader(fileName));
    }

    String next() {
        while (st == null || !st.hasMoreElements()) {
            try {
                String line = br.readLine();
                if (line == null) return null;
                st = new StringTokenizer(line);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return st.nextToken();
    }

    int nextInt() {
        return Integer.parseInt(next());
    }
}