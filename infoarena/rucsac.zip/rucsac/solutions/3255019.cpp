#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

#define limN 5002
#define limG 10002

int dp[limG];

int main()
{
    int n, gmax, weight, profit;
    fin >> n >> gmax;

    for(int i = 1; i <= n; i++)
    {
        fin >> weight >> profit;
        for(int j = gmax; j >= weight; j--)
            dp[j] = max(dp[j], dp[j-weight]+profit);
    }
    int rez = 0;
    for(int i = 0; i <= gmax; i++)
        rez = max(rez, dp[i]);
    fout << rez;
    return 0;
}
