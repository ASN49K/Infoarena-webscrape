#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
#define NMAX 5005
#define GMAX 10005

using namespace std;

ifstream in("rucsac.in");
ofstream out("rucsac.out");

pair <int, int> v[NMAX];
int dp[GMAX];

int main() {
    int n, g, maxx = -1;
    in >> n >> g;
    for (int i = 1; i <= n; ++i)
        in >> v[i].first >> v[i].second;

    for (int i = 1; i <= n; ++i) {
        for (int j = g; j >= 1; --j) {
            if (j >= v[i].first)
                dp[j] = max(dp[j], dp[j - v[i].first] + v[i].second);
        }
        maxx = max(maxx, dp[g]);
    }

    out << maxx;
    return 0;
}