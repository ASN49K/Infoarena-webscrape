#include <fstream>

using namespace std;

ifstream f("rucsac.in");
ofstream g("rucsac.out");

int n, G, gr, p, dp[10005];

int main()
{
    f >> n >> G;

    while (n--) {
        f >> gr >> p;

        for (int j = G; j >= gr; --j) {
            dp[j] = max(dp[j], dp[j - gr] + p);
        }
    }

    g << dp[G];

    return 0;
}
