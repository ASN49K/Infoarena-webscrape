#include <fstream>
#include <string.h>
using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int n, g, w, p;

const int WMAX = 1e4 + 1;
int dp[2][WMAX];

int main()
{
    fin >> n >> g;
    memset(dp, -1, sizeof(dp));
    dp[1][0] = 0;
    dp[0][0] = 0;
    int vMax = 0;
    for (int i = 0; i < n; ++i)
    {
        int crtIndex = i % 2, antIndex = 1 - crtIndex;
        fin >> w >> p;
        for (int j = w; j <= g; ++j)
        {
            int prev = j - w;
            dp[crtIndex][j] = dp[antIndex][j];
            if (dp[antIndex][prev] != -1 && dp[antIndex][prev] + p > dp[crtIndex][j])
            {
                dp[crtIndex][j] = dp[antIndex][prev] + p;
                if (dp[crtIndex][j] > vMax)
                    vMax = dp[crtIndex][j];
            }
        }
    }
    fout << vMax << '\n';
    return 0;
}