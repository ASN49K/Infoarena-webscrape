#include <bits/stdc++.h>
#define lim 10010
using namespace std;

ifstream in("rucsac.in");
ofstream out("rucsac.out");

int n, dp[lim], gmax, g, p, rez=-1;

int main()
{
    in>>n>>gmax;
    for(int i=1; i<=n; i++)
    {
        in>>g>>p;
        for(int j=gmax-g; j>0; j--)
            if(dp[j] && dp[j+g]<dp[j]+p)
                dp[j+g]= dp[j]+p, rez=max(rez, dp[j+g]);
        dp[g]=max(dp[g], p);
        rez=max(rez, dp[g]);
    }
    out<<rez;
}
