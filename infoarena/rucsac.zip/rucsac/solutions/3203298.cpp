
#include <fstream>
#include <vector>
using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
int n,g;
vector<int> W,P,dp;
int maxi;
int main()
{
    cin>>n>>g;
    W.resize(n+1);
    P.resize(n+1);
    dp.resize(g+1);
    for(int i=1;i<=n;i++)
        cin>>W[i]>>P[i];
    for(int i=1;i<=n;i++)
      for(int j=g-W[i];j>=0;j--)
      {
         dp[j+W[i]]=max(dp[j]+P[i],dp[j+W[i]]);
         maxi=max(maxi,dp[j+W[i]]);
      }
    cout<<maxi;
    return 0;
}
