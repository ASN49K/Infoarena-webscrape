#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int dp[10005][10005], G, n;
int p[10005], g[10005], sol;

int main()
{
	int i, j;
	fin >> n >> G;
	for (i = 1; i <= n; i++)
	{
		fin >> g[i] >> p[i];
		dp[i][g[i]] =p[i];
	}
	for (i = 2; i <= n; i++)
		for (j = 0; j <= G; j++)
		{
			if (g[i] <= j)
				dp[i][j] = max(dp[i - 1][j - g[i]] + p[i], dp[i - 1][j]);
		}
	sol = dp[n][1];
	for (i = 2; i <= G; i++)
		sol = max(sol, dp[n][i]);
	fout << sol;
	return 0;
}