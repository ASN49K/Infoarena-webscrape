#include <fstream>

using namespace std;

ifstream cin ("rucsac.in");
ofstream cout ("rucsac.out");

int n,g,a[1001],b[1001],i,j;
long long int c[10001];

int main()
{
    cin>>n>>g;
    for(i=1;i<=n;i++)
        cin>>a[i]>>b[i];
    for(i=1;i<=n;i++)
        for(j=g;j>=a[i];j--)
            c[j]=max(c[j],c[j-a[i]]+b[i]);
    cout<<c[g];
    return 0;
}
