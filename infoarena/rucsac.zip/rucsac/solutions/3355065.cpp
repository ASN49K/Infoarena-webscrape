#include<iostream>
#include<vector>
#include<fstream>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int main() {
	int n,g;
	fin>>n>>g;
	vector<int> dp(g + 1, 0);

	for( int i = 0; i < n; i++) {
		int weight, price;
		fin >> weight >> price;
		
		for (int w = g; w >= weight; w--) {
			dp[w] = max(dp[w], dp[w-weight] + price)
		}
	}
	fout << dp[g];	
}
	