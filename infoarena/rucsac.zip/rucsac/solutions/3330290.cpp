/*
https://www.infoarena.ro/problema/rucsac
*/
#include <fstream>

using namespace std;

const int N = 5000;
const int K = 10000;

struct obiect
{
    int g, p;
};

int profit[K+1];

int main()
{
    ifstream in("rucsac.in");
    ofstream out("rucsac.out");
    int n, k;
    in >> n >> k;
    for (int j = 1; j <= k; j++)
    {
        profit[j] = -1;
    }
    profit[0] = 0;
    for (int i = 0; i < n; i++)
    {
        obiect ob;
        in >> ob.g >> ob.p;
        for (int j = k; j >= ob.g; j--)
        {
            if (profit[j-ob.g] != -1)
            {
                profit[j] = max(profit[j], profit[j-ob.g] + ob.p);
            }
        }
    }
    int v_max = -1;
    for (int j = 1; j <= k; j++)
    {
        v_max = max(v_max, profit[j]);
    }
    out << v_max << "\n";
    in.close();
    out.close();
    return 0;
}
