#include <bits/stdc++.h>

using namespace std;
ifstream in("rucsac.in");
ofstream out("rucsac.out");
int dp[10005];
int w[5005], p[5005];
int main()
{
    int n, g;
    in >> n >> g;
    for( int i = 1; i <= n; i++ )
        in >> w[i] >> p[i];
        
    int maxi = 0;
    dp[0] = 1;
    for( int i = 1; i <= n; i++ ){
        for( int weight = g; weight >= w[i]; weight-- )
            if( dp[weight-w[i]] )
                dp[weight] = max(dp[weight], dp[weight-w[i]] + p[i]);
    }
    for( int i = 0; i <= g; i++ )
        maxi = max( maxi, dp[i]);
    out << maxi - 1;
    return 0;
}
