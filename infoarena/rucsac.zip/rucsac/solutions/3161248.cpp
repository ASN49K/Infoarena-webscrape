#include <fostream>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
const int MAX_N = 5001;
const int MAX_G = 1000;

int dp[MAX_N][MAX_G];

struct t_object{
  int greutate;
  int profit;
};

int main()
{
    int nr_elem;
    int gmax;
    t_object objs[MAX_N];

    fin >> nr_elem >> gmax;

    for(int i = 1; i <= nr_elem; i ++){
      int greutate;
      int profit;

      fin >> greutate >> profit;
      t_object obj = {greutate, profit};

      objs[i] = obj;
    }

    /// cazul idx == 0 este deja acoperit din mom ce matricea a fost declarata global

    /// cazul greutate == 0 din mom ce matricea a fost declarata global

    for(int idx = 1; idx <= nr_elem; idx ++){
        for(int g = 1; g <= gmax; g ++){
          t_object obj = objs[idx];

          if ( obj.greutate > g){
            ///nu are loc in ghiozdan
            dp[idx][g] = dp[idx - 1][g];
          }
          else {
            ///are loc in ghiozgan si consideram doua cazuri

            ///cazul 1 - nu il punem in ghiozdan
            int profit1 = dp[idx - 1][g];

            ///cazul 2 - il punem in ghiozdan
            int profit2 = obj.profit + dp[idx - 1][g - obj.greutate];

            dp[idx][g] = max(profit1, profit2);
          }
        }
    }
    fout << dp[nr_elem][gmax] << endl;
    return 0;
}
