#include <iostream>
#include <cstdio>
#include <fstream>
#include <algorithm>
using namespace std;
int n,W,suf,i,j,k,VMAX,x,y,z,t;
pair<int,int> obj[5002],sufpart[5002];
class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}

	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	InParser& operator >> (long long &n) {
		char c;
		n = 0;
		while (!isdigit(c = read_ch()) && c != '-');
		long long sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
};

int greedsuf(int poz,int wmax)
{
    int rez=0;
    while(poz<n&&obj[poz].first<wmax)rez+=obj[poz].second,wmax-=obj[poz++].first;
    if(poz==n)return rez;
    return rez+obj[poz].second*wmax/obj[poz].first;
}

void bkt(int poz,int vtot,int rem /*W'*/)
{
    if(poz==n)
    {
        VMAX=max(VMAX,vtot);
        return;
    }
    //cerr<<poz<<endl;
    //nu luam elementul curent
    if(vtot + greedsuf(poz+1,rem)>VMAX)
        bkt(poz+1,vtot,rem);
    //luam elementul curent
    if(rem-obj[poz].first>=0 && vtot+obj[poz].second+greedsuf(poz+1,rem-obj[poz].first) > VMAX)
        // incape obiectul  &&  daca luam obiectul si in continuare luam ideal trecem de VMAX
        bkt(poz+1, vtot+obj[poz].second,rem-obj[poz].first);
}

bool comp(const pair<int,int>&a,const pair<int,int>&b){return a.second*b.first>=b.second*a.first;}

int main()
{
    InParser fin("rucsac.in");
    ofstream fout("rucsac.out");

    fin>>n>>W;

    for(i=0;i<n;i++)fin>>obj[i].first>>obj[i].second;
    sort(obj,obj+n,comp);
    
    obj[n].first=1;
    
    for(i=n-1;i>=0;i--)sufpart[i]=make_pair(sufpart[i+1].first+obj[i].first,sufpart[i+1].second+obj[i].second);
    x=VMAX=0;
    for(i=0;i<n;i++)
    {
        x+=obj[i].first;
        if(x<=W)VMAX+=obj[i].second;
        else break;
    }
    bkt(0,0,W);
    fout<<VMAX;
	return 0;
}

/*
P1 = rucsac normal
w1, v1
w2, v2
w3, v3
...
W
Vmax = ?

P2 = rucsac fractionar
w1, v2
w2, v2
w3, v3
...
W
Vmax2 = ?


Vmax <= Vmax2


bkt(k) - rucsac normal
w1, w2, ..., wk-1 - stim daca le luam sau nu
wk + 1, wk + 2... wn - inca nu stim daca le luam sau nu
W' = W - ce am luat
W' <= 0 => ne oprim

Vcurentmax = Vcurent + (wk + 1, wk + 2, ..., wn, W') rucsac normal

Vmax cea mai buna configuratie finala pana acum

Vcurent pt configuratia aleas

Vsuf = (wk + 1, wk + 2, ..., wn) pe rucsac fractionar, cu greutatea ramasa

Vrucentmax <= Vcurent + Vsuf

daca Vcurent + Vsuf < Vmax, putem ignora
daca Vcurent + Vsuf < Vmax => Vcurentmax < Vmax 


daca Vmax = 9
Vcurent = 5
Vsuf = 4
=> mai bine de 9 nu putem face
*/