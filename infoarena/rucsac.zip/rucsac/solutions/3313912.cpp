#include <bits/stdc++.h>
using namespace std;

/**
 * Problem: Problema rucsacului
 * URL: https://www.infoarena.ro/problema/rucsac
 * TL: 200 ms
 * ML: ${memoryLimit} MB
 */
#define MULTITEST 0
#define int long long
inline void tc() {
    int n, g; cin >> n >> g;
    vector<int> dp(g + 1);
    vector<pair<int, int>> v(n + 1);
    for (int i = 1; i <= n; i ++) {
        cin >> v[i].first >> v[i].second;
    }

    for (int i = 1; i <= n; i ++) {
        for (int j = g; j >= v[i].first; j --) {
            dp[j] = max(dp[j], dp[j - v[i].first] + v[i].second);
        }
    }

    cout << dp[g] << '\n';
}

#define FILEIO 1
#define FILE "rucsac"
signed main() {
#if FILEIO && !defined(LOCAL)
    freopen(FILE ".in", "r", stdin);
    freopen(FILE ".out", "w", stdout);
#endif
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
#if MULTITEST == 1
    int tt;
    cin >> tt;
    while (tt--) {
        tc();
    }
#else
    tc();
#endif
    return 0;
}