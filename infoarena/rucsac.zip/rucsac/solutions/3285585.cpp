// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <fstream>
#include <vector>
using namespace std;

ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

int n, g;

int gr, p;

int mat[10001];

int main()
{
	cin >> n >> g;
	for (int i = 1;i <= n;i++)
	{
		cin >> gr >> p;
		for (int j = 1;j <= g;j++)
		{
			mat[j] = max(mat[j], mat[j - gr] + p);	
		}
	}
	cout << mat[g];
}