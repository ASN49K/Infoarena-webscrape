#include<bits/stdc++.h>
using namespace std;
ifstream fcin("rucsac.in");
ofstream fcout("rucsac.out");

typedef struct {
	int weight;
	int price;
} item;


int main(void) {
	int n, wmax;
	fcin>> n >> wmax;
	
	vector<item> items(n + 2, {0, 0});	
	for(int i = 1 ; i <= n; i++) {
		fcin>>items[i].weight>>items[i].price;
	}
	// dp[i][j] = valoarea maxima pana la weight i din primele j iteme
	vector<vector<int>> dp (wmax + 1, vector<int>(n + 1, 0));

	//take item[i] ->> dp[i][j] = dp[i - item[i].weight][j - 1] + items[i].weight;
	//skip  ->> dp[i][j] = dp[i][j - 1]
	for(int i = 0; i <= wmax; i++) {
		for(int j = 1; j <= n; j++) {

			if(i >= items[j].weight) { // could take
				
				dp[i][j] = max(dp[i][j - 1], dp[i - items[j].weight][j - 1] + items[j].price);
			} else {
				dp[i][j] = dp[i][j-1];
			}
		}
	}

	fcout<<dp[wmax][n]<<"\n";
	return 0;
}