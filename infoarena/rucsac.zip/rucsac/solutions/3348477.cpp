#include <fstream>
#define NMAX 5005
#define GMAX 10005
using namespace std;
ifstream  fin("rucsac.in");
ofstream fout("rucsac.out");
int N,G,W[NMAX],P[NMAX],dp[GMAX];

void citire()
{
    fin>>N>>G;

    for(int i=1; i<=N; i++)
    {
        fin>>W[i]>>P[i];
    }
}

int main()
{
    citire();

    for(int i=0; i<=G; i++)
    {
        dp[i]=-1;
    }

    int ans=0;
    dp[0]=0;
    for(int i=1; i<=N; i++)
    {
        for(int j=G-W[i]; j>=0; j--)
        {
            if(dp[j]!=-1)
            {
                dp[j+W[i]]=max(dp[j]+P[i],dp[j+W[i]]);
                ans=max(ans,dp[j+W[i]]);
            }
        }
    }

    fout<< ans << "\n";

    return 0;
}
