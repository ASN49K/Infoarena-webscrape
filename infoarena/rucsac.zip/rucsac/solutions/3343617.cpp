#include <fstream>

using namespace std;

ifstream f("rucsac.in");
ofstream g("rucsac.out");

int N, G, w, p, dp[10001];

int main()
{
	f >> N >> G;
	for(int i = 1; i <= N; i++)
	{
		f >> w >> p;
		for(int j = G; j >= w; j--)
			dp[j] = max(dp[j], dp[j - w] + p);
	}
	g << dp[G];
	f.close();
	g.close();
	return 0;
}
