#include <iostream>
#include <fstream>
using namespace std;

//Variabile var 1
struct
{
    float gr, val, ef;
    bool luat = 0;
} ob[5001];

//Variabile var 2
//int castig[10001], ales[10001], gr[10001], c[10001], i, j, n, g;

//Variabile var 3
//int castig[10001][10001], alege[10001][10001], gr[10001], c[10001], i, j, n, g, obj;

int main()
{
    ifstream in("rucsac.in");
    ofstream out("rucsac.out");

    int Gmax, n, poz = 0, nr_luate = 0, Vmax = 0;
    float efmax, S = 0;
    in >> n >> Gmax;
    for (int i = 1; i <= n; i++)
    {
        in >> ob[i].gr;
        in >> ob[i].val;
        ob[i].ef = ob[i].val / ob[i].gr;
        if (ob[i].val > Vmax) Vmax = ob[i].val;
    }
    while (Gmax > 0 && nr_luate < n)// -> stergi do si decomm linia +comm blocku din interior daca vrei sa iti ia si gr partiale
    {
        efmax = 0;
        poz = -1;
        for (int i = 1; i <= n; i++)
        {
            if (ob[i].val >= efmax && (ob[i].luat == 0) && ob[i].gr <= Gmax)
            {
                efmax = ob[i].val;
                poz = i;
            }
        }
        nr_luate++;
        /*if (ob[poz].gr >= Gmax)
        {
            S += Gmax * efmax;
            Gmax = 0;
        }
        else*/
        if (poz != -1)
        {
            S += ob[poz].val;
            Gmax -= ob[poz].gr;
            ob[poz].luat = 1;
            //out << "pozitia " << poz << ": " << ob[poz].gr << " " << ob[poz].val << " " << ob[poz].luat << " -> greutatea ramasa in rucsac: " << Gmax << endl;
        }
    }
    if (Gmax < 0)
    {
        S -= ob[poz].val;
    }
    out << S;

    /* Varianta 2 -> poate sa ia un obj de acelasi tip de nenumarate ori
    in >> n >> g;
    for (int i = 1; i <= n; i++)
    {
        in >> gr[i] >> c[i];
    }
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= g; j++)
        {
            if (gr[i] <= j)
            {
                if (c[i] + castig[j - gr[i]] > castig[j])
                {
                    castig[j] = c[i] + castig[j - gr[i]];
                    ales[j] = c[i];
                }

            }
            cout << gr[i] << " " << c[i] << " " << castig[j - gr[i]] << endl;
        }
    }
    j = g;
    out << castig[g] << endl;
    //for (int k = 1; k <= n; k++) out << castig[k] << " ";
    /*
    out << endl;
    while (ales[j])
    {
        out << "produsul " << ales[j] << " greutate " << gr[ales[j]] << " castig " << c[ales[j]] << endl;
        j -= gr[ales[j]];
    }//*///*/

    /* Varianta 3 -> prea multa memorie necesara
    in >> n >> g;
    for (int i = 1; i <= n; i++)
    {
        in >> gr[i] >> c[i];
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= g; j++)
        {
            if (gr[i] <= j)
            {
                if (c[i] + castig[i - 1][j - gr[i]] > castig[i - 1][j])
                {
                    castig[i][j] = c[i] + castig[i - 1][j - gr[i]];
                    alege[i][j] = i;
                }
                else
                {
                    castig[i][j] = castig[i - 1][j];
                    alege[i][j] = alege[i - 1][j];
                }
            }
            else
            {
                castig[i][j] = castig[i - 1][j];
                alege[i][j] = alege[i - 1][j];
            }
        }
    }
    i = n; j = g;
    out << castig[n][g] << endl;
    /*while (alege[i][j])
    {
        obj = alege[i][j];
        out << "produsul " << alege[i][j] << " greutate " << gr[alege[i][j]] << " castig " << c[alege[i][j]] << endl;
        while (obj == alege[i][j])
        {
            j -= alege[i][j];
            i--;
        }
    }*///*/

    return 0;
}