#include <fstream>
#include <vector>
#include <map>
#include <iomanip>
#include <cmath>
#include <algorithm>
#include <set>
using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
#define ll long long
#define pb(x) push_back(x)
#define all(x) x.begin(), x.end()
ll n, g;
ll dp[2][10005];
int main()
{
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ///ll t; cin>>t; while(t--) solve(), cout<<'\n';
    cin>>n>>g;
    ll w[n + 5], p[n + 5];
    for(int i = 1; i <= n; i++)
        cin>>w[i]>>p[i];
    bool l = 0;
    for(int i = 1; i <= n; i++, l = 1 - l)
    {
        for(int j = 0; j <= g; j++)
        {
            dp[l][j] = dp[1 - l][j];
            if(w[i] <= j)
                dp[l][j] = max(dp[l][j], dp[1 - l][j - w[i]] + p[i]);
        }
    }
    cout<<dp[1 - l][g];
    return 0;
}