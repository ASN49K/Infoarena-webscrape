#include <fstream>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
struct object{
    int greutate;
    int profit;

};
const int max_n=5001;
const int max_g=10001;
int dp[max_n][max_g]; // valori initializate cu 0
int main()
{
    int nr_elem,gmax;
    object objs[max_n];
    fin>>nr_elem>>gmax;
    for(int i=1;i<=nr_elem;i++)
    {
        int greutate;
        int profit;
        fin>>greutate>>profit;
        object obs={greutate,profit};
        objs[i]=obs;
    }
    //cazul i==0 este deja acoperit din moment ce matr a fost declarata global

    //greutate==0 din moment ce matr a fost declarata global
    for(int i=1;i<=nr_elem;i++)
        for(int g=1;g<=gmax;g++)
    {
        object obj=objs[i];
        if(obj.greutate>g)
            dp[i][g]=dp[i-1][g];
        else
        {
            int profit1=dp[i-1][g];
            int profit2= obj.profit+dp[i-1][g-obj.greutate];
            dp[i][g]=max(profit1,profit2);
        }
    }
    fout<<dp[nr_elem][gmax];
    return 0;
}
