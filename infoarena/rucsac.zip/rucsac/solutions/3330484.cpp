#include <bits/stdc++.h>
#define fi second
#define se first
#define MAXN 5005
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int n, k, suf[MAXN], suf2[MAXN], ans=0, sum=0, val=0, w;
pair<int, int>x[MAXN];
int get1(int i, int j);
int get2(int i, int j);
long double greedy(int i);
void bkt(int i);
bool compara(pair<int, int>a, pair<int, int>b);
int main()
{
    fin>>n>>k;
    for (int i=1; i<=n; i++) {
        fin>>x[i].fi>>x[i].se;
    }
    sort(x+1, x+n+1, compara);
    for (int i=n; i>=1; i--) {
        suf[i]=suf[i+1]+x[i].se;
        suf2[i]=suf2[i+1]+x[i].fi;
    }
    for (int i=1; i<=n; i++) {
        w+=x[i].fi;
        if (w>k) break;
        ans+=x[i].se;
    }
    bkt(1);
    fout<<ans;
    return 0;
}
int get1(int i, int j) {
    return suf[i]-suf[j+1];
}
int get2(int i, int j) {
    return suf2[i]-suf2[j+1];
}
long double greedy(int i) {
    int st=i, dr=n, rasp=n;
    while (st<=dr) {
        int mij=(st+dr)/2;
        if (get2(i, mij)>k-sum) {
            rasp=mij;
            dr=mij-1;
        }
        else st=mij+1;
    }
    return (long double)get1(i, rasp-1)+(((long double)(x[rasp].se*(k-sum-get2(i, rasp-1))))/(long double)(x[rasp].fi));
}
/*long double greedy(int i) {
    int ww=0;
    long double pp=0;
    for (int j=i; j<=n; j++) {
        if (ww+x[j].fi<=k-sum){
            pp+=x[j].se;
            ww+=x[j].fi;
        }
        else {
            pp+=(((long double)(x[j].se*(k-sum-ww)))/(long double)(x[j].fi));
            return pp;
        }
    }
    return pp;
}*/
void bkt(int i) {
    if (sum>k) return ;
    if ((long double)(val+greedy(i))<(long double)(ans)) return ;
    if (i>n) {
        ans=max(ans, val);
        return ;
    }
    sum+=x[i].fi;
    val+=x[i].se;
    bkt(i+1);
    sum-=x[i].fi;
    val-=x[i].se;
    bkt(i+1);
}
bool compara(pair<int, int>a, pair<int, int>b) {
    return (a.first*b.second>a.second*b.first);
}
