#include <stdio.h>
#include <stdlib.h>

#define GMAX 10000

int vec[GMAX + 1];

int main()
{
    FILE *fin, *fout;
    int num_n, greutate_max, greutate, profit, ind, ind1, maxi;

    fin = fopen( "rucsac.in", "r" );
    fscanf( fin, "%d%d", &num_n, &greutate_max );

    for ( ind = 0; ind < num_n; ind++ ) {
      fscanf( fin, "%d%d", &greutate, &profit );
      for ( ind1 = greutate_max; ind1 >= greutate; ind1-- )
        if ( vec[ind1 - greutate] + profit > vec[ind1] )
          vec[ind1] = vec[ind1 - greutate] + profit;
    }
    fclose( fin );

    maxi = 0;
    for ( ind = 1; ind <= greutate_max; ind++ )
      if ( vec[ind] > maxi )
        maxi = vec[ind];

    fout = fopen( "rucsac.out", "w" );
    fprintf( fout, "%d\n", maxi );
    fclose( fout );
    return 0;
}
