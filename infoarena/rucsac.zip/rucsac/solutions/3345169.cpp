#include <fstream>
#include <iostream>
#include <cmath>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

const int N_MAX = 5005, G_MAX = 10005;

int n, g, w[N_MAX], p[N_MAX], dp[2][G_MAX];

int main() {
    fin >> n >> g;
    for (int i = 1; i <= n; i++)
        fin >> w[i] >> p[i];
    int maxim = 0;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= g; j++) {
            if (j >= w[i])
                dp[1][j] = max(dp[0][j], dp[0][j - w[i]] + p[i]);
            else
                dp[1][j] = dp[0][j];
            maxim = max(maxim, dp[1][j]);
        }
        for (int j = 1; j <= g; j++) {
            dp[0][j] = dp[1][j];
            dp[1][j] = 0;
        }
    }
    fout << maxim << "\n";
    return 0;
}
