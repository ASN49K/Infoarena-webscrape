#include <fstream>
#include <algorithm>
#define modula 777013
using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

int n, s, dp[2][1000000], v[100000], g[100000], stare=1;


int main()
{
    cin>>n>>s;
    for(int i=1; i<=n; i++)
        cin>>v[i]>>g[i];

    for(int i=1; i<=n; i++)
    {
        stare=1-stare;
        for(int j=0; j<=s; j++)
        {
            dp[stare][j]=dp[1-stare][j];
        }
        for(int j=0; j<=s; j++)
        {
            if(j>=v[i])
            {
                dp[stare][j]=max(dp[1-stare][j],dp[1-stare][j-v[i]]+g[i]);
            }
        }
    }
    cout<<dp[stare][s];
}
