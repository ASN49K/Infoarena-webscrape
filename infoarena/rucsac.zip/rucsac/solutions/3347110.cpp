#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;
ifstream f("rucsac.in");
ofstream g("rucsac.out");
int d[10005];
int n, G, w, p;

int main() {
    f >> n >> G;
    for (int i = 1; i <= n; i++) {
        f >> w >> p;
        for (int j = G; j >= w; j--) {
            if (d[j - w] + p > d[j]) {
                d[j] = d[j - w] + p;
            }
        }
    }
    g << d[G] << endl;
    return 0;
}
