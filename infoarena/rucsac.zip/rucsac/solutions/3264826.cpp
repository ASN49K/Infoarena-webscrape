#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

const int MAX = 1e4;
int dp[MAX];

int main()
{
    int n, g;
    fin >> n >> g;
    for (int i = 0; i < n; ++i)
    {
        int w, p;
        fin >> w >> p;
        for (int j = g; j >= w; --j)
        {
            dp[j] = max(dp[j], dp[j - w] + p);
        }
    }
    fout << dp[g];
    return 0;
}
