#include <bits/stdc++.h>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
long long w[5010],p[5010],k,n,m,i,j,dp[3][10010],s=0,maxi=0,g;
int main()
{
    fin>>n>>g;
    for(i=1;i<=n;i++)
    {
        fin>>w[i]>>p[i];
    }
    for(i=1;i<=n;i++)
        for(j=1;j<=g;j++)
        {
            dp[i%2][j]=dp[1-i%2][j];
            if(j>=w[i])
                dp[i%2][j]=max(dp[i%2][j],dp[1-i%2][j-w[i]]+p[i]);
        }
    for(j=1;j<=g;j++)
        maxi=max(dp[n%2][j],maxi);
    fout<<maxi;

    return 0;
}
