/*
 * author [dubit]
*/
#include <bits/stdc++.h>

using namespace std;

int n,gmax;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    freopen("rucsac.in","r",stdin);
    freopen("rucsac.out","w",stdout);
    cin>>n>>gmax;
    vector<int>dp(gmax+1,0);
    for (int i=0;i<n;i++) {
        int g,v;
        cin>>g>>v;
        for (int j=gmax;j>=g;j--)
            dp[j]=max(dp[j],dp[j-g]+v);
    }
    cout<<dp[gmax];
}