#include <fstream>
#include <iostream>
using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int main() {
    int n, g, gmax, p, i, j, last = 0, pmax = 0;
    fin >> n >> gmax;
    int d[gmax + 5];
    d[0] = 0;
    for (i = 1; i <= gmax; ++i) d[i] = -1;
    for (i = 1; i <= n; ++i) {
        cin >> g >> p;
        for (j = last; j >= 0; --j) {
            if (j + g > gmax) continue;
            if (d[j] != -1)  // daca am ajuns la rucsacul cu greutatea j(daca
                             // exista o combinatie de obiecte)
            {
                if (d[j] + p >
                    d[j + g])  // d[j+g] este este rucsacul la care am
                               // ajuns(daca valoarea  lui este mai mica decat
                               // cea pe care o obtinem din rucsacul j adaugand
                               // elementul de greutate g si profit p
                {
                    d[j + g] = d[j] + p;
                    if (j + g > last) last = j + g;
                }
            }
        }
    }
    // for(i = 1; i <= gmax; ++i)
    //     cout<<d[i]<<' ';
    for (i = 1; i <= gmax; ++i) {
        if (pmax < d[i]) pmax = d[i];
    }
    fout << pmax;
    return 0;
}
