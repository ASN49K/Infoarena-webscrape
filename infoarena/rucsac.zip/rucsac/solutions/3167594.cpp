﻿#include <bits/stdc++.h>
#include <random>
#include <chrono>
using namespace std;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
const char nl = '\n';
const char sp = ' ';
const int inf = 0x3f3f3f3f;
const long long INF = 1000000000000000000;
const int mod = 1e9 + 7;
const char out[2][4]{ "NO", "YES" };
#define all(A) A.begin(), A.end()
using ll = long long;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

#define variableName(var) #var
#define __debug(var) cout << #var << " = " << var << '\n'
inline int rint(int a, int b) { return uniform_int_distribution<int>(a, b)(rng); }

const int nmax = 5000;
const int gmax = 10000;
int n, g;
pair<int, int> v[nmax + 5];
int dp[gmax + 5]{ 0 };

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    fin >> n >> g;
    for (int i = 1; i <= n; ++i) {
        fin >> v[i].first >> v[i].second;
    }
    for (int i = 1; i <= n; ++i) {
        for (int j = g; j >= v[i].first; --j) {
            dp[j] = max(dp[j], dp[j - v[i].first] + v[i].second);
        }
    }
    fout << *max_element(dp, dp + g + 1);
}