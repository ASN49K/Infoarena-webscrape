#include "stdio.h"
#include "stdint.h"
#include "stdlib.h"


#define NMAX 5000
typedef struct{
    double weight,value,average;
}Object;

int compare(const void *a, const void *b){
    Object *A = (Object *)a;
    Object *B = (Object *)b;
    return -(A->average - B->average);
}

int main(){
    Object Objects[NMAX];
    int n=0;
    double MaxWeight=0, sum=0, Weight = 0, percentage = 0;
    scanf("%d %lf",&n,&MaxWeight);
    for(int i=0;i<n;++i){
        scanf("%lf %lf", &Objects[i].weight, &Objects[i].value);
        Objects[i].average = Objects[i].value / Objects[i].weight;
    }
    qsort(Objects, n, sizeof(Object), compare);

    /*for(int i=0;i<n;i++){
        printf("%lf | %lf | %lf|\n", Objects[i].value, Objects[i].weight,Objects[i].average);
    }*/

    for(int i=0;i<n;++i){
        Weight += Objects[i].weight;
        if(Weight > MaxWeight){
            Weight -= Objects[i].weight;
            percentage = MaxWeight - Weight;
            sum += percentage*Objects[i].average;
            break;
        }
        else{
            sum += Objects[i].value;
        }
    }
    printf("Total value stolen: %lf", sum);
}