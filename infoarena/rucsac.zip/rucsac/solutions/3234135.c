#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int greutate;
    int valoare;
    double raport;
} obiect;

int comp(const void *a, const void *b) {
    obiect *oa = (obiect *)a;
    obiect *ob = (obiect *)b;

    if(oa->raport < ob->raport) return 1;
    if(oa->raport > ob->raport) return -1;
    return 0;
}

int main() {
    int n, g;
    FILE *in = fopen("rucsac.in", "r");
    FILE *out = fopen("rucsac.out", "w");

    fscanf(in, "%d %d", &n, &g);

    obiect Obiecte[5000];
    for(int i = 0; i < n; i++) {
        fscanf(in, "%d %d", &Obiecte[i].greutate, &Obiecte[i].valoare);
        Obiecte[i].raport = (double)Obiecte[i].valoare / Obiecte[i].greutate;
    }

    qsort(Obiecte, n, sizeof(obiect), comp);

    int currentWeight = 0, maxProfit = 0;

    for(int i = 0; i < n; i++) {
        if(currentWeight + Obiecte[i].greutate <= g) {
            currentWeight += Obiecte[i].greutate;
            maxProfit += Obiecte[i].valoare;
        }
    }

    fprintf(out, "%d\n", maxProfit);

    fclose(in);
    fclose(out);

    return 0;
}