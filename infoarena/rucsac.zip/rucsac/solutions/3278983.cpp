#include <bits/stdc++.h>

using namespace std;

int n, Gmax, greutate[1001]{}, profit[1001]{}, dp[1001][10001]{}, x;

int main(){
    
    cin >> n >> Gmax;
    for(int i = 1; i <= n; i++)
        cin >> greutate[i] >> profit[i];
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= Gmax; j++){
            if(greutate[i] > j)
                dp[i][j] = dp[i-1][j];
            else
                dp[i][j] = max(dp[i-1][j], dp[i-1][j-greutate[i]] + profit[i]);
        }
    }
    cout << dp[n][Gmax];
    
}