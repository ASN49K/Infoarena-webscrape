#include <fstream>


using namespace std;

int s[10001],pr[10001];

int main()

{
  ifstream in("rucsac.in");
  ofstream out("rucsac.out");
    int n,G,sol=0;
    in>>n>>G;
    s[0]=1; // suma 0 se poate construi
    for(int i=1;i<=n;i++)
    {
      in>>w>>p; // acest obiect se adauga  la sume vechi
      for( int j= G-w; j>=0; j--)
      {
        if(s[j]==1)
        {
          s[j+w]=1;
          if(pr[j] + p > pr[j+w])
          pr[j+w] = pr[j] + p;
        }
      }
      
    } 
    

    for(int j=1;j<=G;j++)
         sol=max(sol,pr[j]);
    out<<sol;
    
    
    return 0;
}