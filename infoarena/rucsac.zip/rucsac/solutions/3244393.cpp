#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int main()
{
    int dp[10001]={};
    int w[5001], p[5001];
    int n,gmax;
    fin>>n>>gmax;
    for(int i=1;i<=n;i++)
        fin>>w[i]>>p[i];
    for(int i=1;i<=n;i++)
    {
       for(int g=gmax;g>=w[i];g--)
        dp[g]=max(dp[g-w[i]]+p[i],dp[g]);
    }
    fout<<dp[gmax];
    return 0;
}
