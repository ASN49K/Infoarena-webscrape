#include <fstream>
using namespace std;
ifstream in("rucsac.in");
ofstream out("rucsac.out");

const int MAXG = 10000 + 2;

int maxval[MAXG];

int main()
{
    int n, g;
    int m = 0;
    in >> n >> g;
    for(int i = 0; i < n; i++) {
        int w, p;
        in >> w >> p;
        for(int k = g; k >= 0; k--) {
            if(k + w > g)
                continue;
            if(maxval[k]) {
                maxval[k+w] = max(maxval[k+w], maxval[k] + p);
                m = max(maxval[k+w], m);
            }
        }
        maxval[w] = max(maxval[w],p);
    }
    out << m;
}
