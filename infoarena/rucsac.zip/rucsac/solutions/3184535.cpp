#include <iostream>
#include <fstream>
#include <algorithm>
#include <string.h>
#define N_MAX 5000

using namespace std;

ifstream in("rucsac.in");
ofstream out("rucsac.out");

const int oo = 0x3f3f3f3f;
const int GMAX = 1e4 + 2;

int dp[2][GMAX], n, w, p, g, rez;

int main (){
    dp[0][0] = 0;
    
    in >> n >> g;
    for (int i=1; i<=n; ++i){
        in >> w >> p;

        int crtIndex = i & 1, antIndex = crtIndex ^ 1;
        for (int j=0; j <= g; ++j){
            if (j - w >= 0)
                dp[crtIndex][j] = max(dp[antIndex][j], dp[antIndex][j-w] + p);
            else
                dp[crtIndex][j] = dp[antIndex][j];

            if (dp[crtIndex][j] > rez)
                rez = dp[crtIndex][j];
        }
    }

    out << rez;
    return 0;
}