#include <iostream>
using namespace std;

struct obiect {
    int greutate;
    int valoare;
};

int main() {
    int n, g;
    cin >> n >> g;

    obiect o[1000];

    for (int i = 0; i < n; i++) {
        cin >> o[i].greutate >> o[i].valoare;
    }

    int dp[1001] = {0};

    for (int i = 0; i < n; i++) {
        int w = o[i].greutate;
        int p = o[i].valoare;

        for (int j = g; j >= w; j--) {

            dp[j] = max(dp[j], dp[j - w] + p);
        }
    }

    cout << dp[g] << endl;

    return 0;
}
