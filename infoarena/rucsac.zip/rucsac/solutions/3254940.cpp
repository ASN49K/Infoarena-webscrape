#include <bits/stdc++.h>
using namespace std;
#define cin fin
#define cout fout
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");


int n, d;
vector<pair<int,int>> v;
vector<long long> spw, spg;
long long pmax, pinit,pmax1;
int viabil(int pos, int g){
    int l = pos, r = n, rez = 0;
    long long col = 0;
    //if(spw[n] - spw[pos - 1] + pmax1 <= pinit) return 0;
    for(int i = pos; i <= n; i++){
        if(g + v[i].second <= d){
            col += v[i].first;
            g += v[i].second;
        }
    }
    //long long tetra = (rez ? spw[rez] - spw[pos - 1] : 0);
    if(pinit > pmax1 + col){
        return 0;
    }
    return 1;
}
void bkt(int pos, int g){
    if(pos == n + 1) return;
    if(!viabil(pos,g)) return;
    if(g + v[pos].second <= d){
        pmax1 += v[pos].first;
        pinit = max(pinit, pmax1);
        bkt(pos + 1, g + v[pos].second);
        pmax1 -= v[pos].first;

    }
    bkt(pos + 1, g);
}

int main(){
    cin >> n >> d;
    v.assign(n + 1, {0,0});
    for(int i = 1; i <= n; i++){
        int w,p;
        cin >> w >> p;
        swap(p,w);
        v[i] = {w,p};
    }

    sort(v.begin() + 1, v.begin() +  1 + n,[&](pair<int,int> a, pair<int,int>b){
        long double p = (long double)a.first/(a.second * 1.0);
        long double d = (long double)b.first/(b.second * 1.0);

        return p > d;
    });
    int g1 = 0;
    for(int i = 1; i <= n; i++){
        if(g1 + v[i].second <= d){
            g1 += v[i].second;
            pmax += v[i].first;
        }
    }
    spw.assign(n + 1, 0);
    spg.assign(n + 1, 0);
    for(int i = 1; i <= n; i++){
        spw[i] = spw[i-1] + v[i].first;
        spg[i] = spg[i-1] + v[i].second;
    }
    bkt(1,0);

    cout << pinit;
}
