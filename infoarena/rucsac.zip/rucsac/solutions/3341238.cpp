#include <bits/stdc++.h>
#define int long long
#define cin ci
#define cout co
using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
int n, g;
vector<pair<int, int>> v;
vector<int> dp;
int32_t main()
{
    cin >> n >> g;
    v.resize(n + 5);
    dp.assign(g + 5, -1);
    for(int i = 1; i <= n; i ++)
        cin >> v[i].first >> v[i].second;

    dp[0] = 0;
    for(int i = 1; i <= n; i ++)
        for(int j = g; j >= v[i].first; j --)
            if(dp[j - v[i].first] != -1)
                dp[j] = max(dp[j], dp[j - v[i].first] + v[i].second);

    int ans = 0;
    for(int i = 0; i <= g; i ++)
        ans = max(ans, dp[i]);
    cout << ans;
    return 0;
}
