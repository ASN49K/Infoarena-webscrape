#include <fstream>

using namespace std;
ifstream fin("iepuri.in");
ofstream fout("iepuri.out");
const long long MOD=666013;
long long t,a,b,c,i0,i1,i2,n;
long long v[5][5];

void inmultire(long long a[5][5], long long b[5][5] )
{
    long long c[5][5]= {0};

    for(long long i=1; i<=3; i++)
        for(long long j=1; j<=3; j++)
            for(long long k=1; k<=3; k++)
            {
                c[i][j]=(c[i][j]+(a[i][k] * b[k][j])%MOD)%MOD;
            }
    for(long long i=1; i<=3; i++)
        for(long long j=1; j<=3; j++)
            a[i][j]=c[i][j];

}

void ridicare_putere(long long n)
{
    long long p[5][5]= {0};
    p[1][1]=1;
    p[2][2]=1;
    p[3][3]=1;

    while(n)
    {
        if(n % 2 == 1)
        {
            inmultire(p, v);
        }
        inmultire(v,v);
        n /= 2;
    }

    for(long long i=1; i<=3; i++)
        for(long long j=1; j<=3; j++)
            v[i][j]=p[i][j];
}
int main()
{
    fin>>t;
    for(int i=0; i<t; i++)
    {
        fin>>i0>>i1>>i2>>a>>b>>c>>n;

        v[1][1]=0;
        v[1][2]=1;
        v[1][3]=0;

        v[2][1]=0;
        v[2][2]=0;
        v[2][3]=1;

        v[3][1]=c;
        v[3][2]=b;
        v[3][3]=a;

        ridicare_putere(n);

        fout<<((v[1][1]*i0%MOD+v[1][2]*i1%MOD)%MOD+v[1][3]*i2%MOD)%MOD<<'\n';
    }
    return 0;
}
