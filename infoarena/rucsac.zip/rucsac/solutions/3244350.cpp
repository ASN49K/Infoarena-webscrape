#include <fstream>

using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
long long w[10001],p[10001],dp[10001];
int main()
{
    int n;
    cin>>n;
    int g;
    cin>>g;
    for(int i=1;i<=n;i++)
    {
        cin>>w[i]>>p[i];
    }

    for(int i=1;i<=n;i++)
    {
        for(int j=g;j>=0;j--)
        {
            if(j<w[i])
                dp[j]=dp[j];
            else
                dp[j]=max(dp[j],dp[j-w[i]]+p[i]);
        }
    }
    long long max1=-1000000000;
    for(int i=0;i<=g;i++)
    {
        max1=max(max1,dp[i]);
    }
    cout<<max1<<" ";
    return 0;
}
