#include <fstream>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int m[3][10005];
int w[5005], p[5005];
int main()
{
    int n, g;
    fin>>n>>g;
    for(int i=1; i<=n; i++){
        fin>>w[i]>>p[i];
    }
    for(int i=1; i<=n; i++){
        for(int j=1; j<=g; j++){
            m[1][j] = m[2][j];
            if(w[i] <= j){
                m[2][j] = max(m[1][j], m[1][j-w[i]] + p[i]);
            }
            else{
                m[2][j] = m[1][j];
            }
        }
    }
    fout<<m[2][g];
    return 0;
}
