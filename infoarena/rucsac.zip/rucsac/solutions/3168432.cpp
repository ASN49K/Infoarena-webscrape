#include <fstream>
using namespace std;
ifstream fin ("rucsac.in");
ofstream fout("rucsac.out");
int n,m,G,g,i,j,p,sol,D[10001];
int main()
{

    fin>>n>>G;
    D[0]=1;
    for(i=1;i<=n;i++)
    {
        fin>>g>>p;
        for(j=G;j>=0;j--)
        {
            if(D[j]&&j+g<=G)
            {
                D[j+g]=max(D[j+g],D[j]+p);
                sol=max(sol,D[j+g]);
            }
        }
    }
    sol--;
    fout<<sol;
    return 0;
}
