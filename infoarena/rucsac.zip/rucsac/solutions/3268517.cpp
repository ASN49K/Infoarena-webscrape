#include <fstream>
#include <vector>

using namespace std;

ifstream f("rucsac.in");
ofstream g("rucsac.out");

constexpr int INF = ((int)(1e9));

int get_max(const vector<int> &v)
{
    if (v.empty())
        return 0;

    int x = v[0], n = (int)v.size();
    for (int i = 1; i < n; ++i)
        if (v[i] > x)
            x = v[i];

    return x;
}

int main()
{
    int n = 0, W = 0;
    f >> n >> W;

    vector<int> dp((W + 1), (-INF));
    dp[0] = 0;

    int w = 0, p = 0;
    for (int i = 0; i < n; ++i)
    {
        f >> w >> p;

        for (int j = (W - w); j >= 0; --j)
            if ((dp[j] + p) > dp[(j + w)])
                dp[(j + w)] = (dp[j] + p);
    }

    g << get_max(dp) << '\n';

    return 0;
}
