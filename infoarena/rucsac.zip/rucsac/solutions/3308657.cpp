// https://infoarena.ro/problema/rucsac - Szücs Patrik - Kevin
#include <fstream>
#include <algorithm>

int main()
{
    short n, g;

    std::ifstream in("rucsac.in");
    in >> n >> g;

    short p[n], w[n];
    for (int i = 0; i < n; i++)
    {
        in >> w[i] >> p[i];
    }
    in.close();

    short dp[g + 1]{};
    for (int i = 1; i <= n; i++)
    {
        for (int j = g; w[i - 1] <= j; j--)
        {
            dp[j] = (dp[j] > dp[j - w[i - 1]] + p[i - 1]) ? dp[j] : dp[j - w[i - 1]] + p[i - 1];
        }
    }

    std::ofstream out("rucsac.out");
    out << dp[g] << '\n';

    out.close();
    return 0;
}