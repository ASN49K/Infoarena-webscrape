#include <bits/stdc++.h>
using namespace std;

#define gr first
#define v second

int n, gmx, aux;
vector<pair<int, int>> ob;
int main() {
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    cin >> n >> gmx;

    ob.resize(n + 1);
    for (int i = 1; i <= n; ++i) {
        cin >> ob[i].gr >> ob[i].v;
    }

    vector<vector<int>> dp(2, vector<int>(gmx + 1, 0));

    int lc = 1, lp = 0;
    for (int i = 1; i <= n; ++i) {
        for (int g = 1; g <= gmx; ++g) {
            dp[lc][g] = dp[lp][g];

            if (ob[i].gr <= g) {
                aux = dp[lp][g - ob[i].gr] + ob[i].v;
                dp[lc][g] = max(aux, dp[lc][g]);
            }
        }

        lc = lp;
        lp = 1 - lc;
    }

    cout << dp[lp][gmx];
}
