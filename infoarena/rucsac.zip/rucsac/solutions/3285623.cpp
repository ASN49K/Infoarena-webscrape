#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

const int NMAX=1e4;

int dp[NMAX+1];
int n,gmax;

int main()
{
    int maxlocal,maxglobal,g,val;
    fin>>n>>gmax;

    maxlocal=maxglobal=0;
    for(int i=1;i<=n;i++)
    {
        fin>>g>>val;
        for(int i=min(maxlocal,gmax-g);i>0;i--)
            if(dp[i]!=0 && dp[i+g]<dp[i]+val)
            {
                dp[i+g]=dp[i]+val;
                if(dp[i+g]>maxglobal)
                    maxglobal=dp[i+g];
            }
        if(dp[g]<val)
            dp[g]=val;
        maxlocal+=g;
        if(maxlocal>gmax)
            maxlocal=gmax;
    }
    fout<<maxglobal<<"\n";
    return 0;
}
