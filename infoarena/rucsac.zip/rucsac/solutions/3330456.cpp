#include <bits/stdc++.h>
#define MAXN 5005
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int n, k, w[MAXN], p[MAXN], ans=0, sum=0, val=0;
void bkt(int i);
int main()
{
    fin>>n>>k;
    for (int i=1; i<=n; i++) {
        fin>>w[i]>>p[i];
    }
    bkt(1);
    fout<<ans;
    return 0;
}
void bkt(int i) {
    if (i>n) {
        if (sum<=k) ans=max(ans, val);
        return ;
    }
    sum+=w[i];
    val+=p[i];
    bkt(i+1);
    sum-=w[i];
    val-=p[i];
    bkt(i+1);
}
