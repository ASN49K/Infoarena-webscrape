#include <bits/stdc++.h>
using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int v[5001], p[5001];
int dp[10001];

int main()
{
    int n, G;
    fin >> n >> G;
    for(int i = 1; i <= n; ++i) {
        fin >> v[i] >> p[i];
    }

    for(int i = 0; i <= G; ++i) {
        dp[i] = 0;
    }
    int maxp = 0;
    for(int i = 1; i <= n; ++i) {
        for(int j = G - v[i]; j >= 0; --j) {
                dp[j + v[i]] = max(dp[j + v[i]], dp[j] + p[i]);
                if(dp[j + v[i]] > maxp)
                    maxp = dp[j + v[i]];
            }
        }
    fout << maxp;
    return 0;
}
