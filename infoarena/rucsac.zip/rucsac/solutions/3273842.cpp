#include <bits/stdc++.h>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int n, g, ans;

int w[5005];
int p[5005];

int dp[10005];

int main() {
    fin >> n >> g;
    for (int i = 1; i <= n; i++) {
        fin >> w[i] >> p[i];
    }

    for (int i = 1; i <= n; i++) {
        for (int j = g - w[i]; j >= 0; j--) {
            dp[j + w[i]] = max(dp[j] + p[i], dp[j + w[i]]);
            ans = max(ans, dp[j + w[i]]);
        }
    }

    fout << ans;
    return 0;
}