#include <bits/stdc++.h>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int n, gmax;

struct Iris {
    int greutate, profit;
}v[5010];

int main()
{
    fin >> n >> gmax;
    for(int i=1; i<=n; i++) fin >> v[i].greutate >> v[i].profit;
    vector<int> dp(gmax + 1, 0);
    for(int i=1; i<=n; i++)
        for(int j=gmax; j>=v[i].greutate; j--) dp[j] = max(dp[j], dp[j - v[i].greutate] + v[i].profit);
    int maxim = -1;
    for(int i=1; i<=gmax; i++) maxim = max(maxim, dp[i]);
    fout << maxim;

    return 0;
}
