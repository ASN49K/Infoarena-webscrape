#include <fstream>
#include <vector>
using namespace std;

ifstream fin ("rucsac.in");
ofstream fout("rucsac.out");

const int n_Max = 5e3 + 1;
const int G_Max = 1e4 + 1;

vector <int> g(n_Max), v(n_Max), dp(G_Max);

int n, G; 

int main()
{
    fin >> n >> G;
    for (int i = 1; i <= n; ++i)
        fin >> g[i] >> v[i];

    for (int i = 1; i <= n; ++i)
        for (int j = G; j >= g[i]; --j)
            dp[j] = max(dp[j], dp[j - g[i]] + v[i]);

    fout << dp[G];

    fin.close();
    fout.close();
    return 0;
}