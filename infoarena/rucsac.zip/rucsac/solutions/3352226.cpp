#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
const int N = 1e5;
int n,g;
int w[N], v[N], dp[N][N];
void citire(){
    fin >> n >> g;
    for(int i = 1; i<=n; i++){
        fin >> w[i] >> v[i];
    }
}
void solve(){
    
}
int main(){
    citire();
    solve();
    fout << dp[n][g] << '\n';

    return 0;
}