#include <fstream>
using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
const int nmax=5000, gmax=10000;
int n, g, dp[2][gmax+5], w[nmax+5], v[nmax+5];
int main()
{
    cin>>n>>g;
    for(int i=1;i<=n;i++)
        cin>>w[i]>>v[i];
    for(int i=1;i<=n;i++)
    {
        dp[1][0]=0;
        for(int j=1;j<=g;j++)
        {
            int pick=0, notpick=dp[0][j];
            if(w[i]<=j)pick=v[i]+dp[0][j-w[i]];
            dp[1][j]=max(pick, notpick);
        }
        for(int j=1;j<=g;j++)
            dp[0][j]=dp[1][j];
    }
    cout<<dp[0][g];
    return 0;
}
