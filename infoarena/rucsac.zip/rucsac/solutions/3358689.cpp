#include <fstream>
#include <vector>

using namespace std;

struct obiect {
    int g, p;
};

int main() {
    ifstream in("rucsac.in");
    ofstream out("rucsac.out");
    int n, k;
    in >> n >> k;
    vector <obiect> v(n);
    vector <vector <int>> profit(n, vector<int>(k + 1));
    for (auto &ob: v) {
        in >> ob.g >> ob.p;
    }
    in.close();
    fill(profit[0].begin(), profit[0].end(), -1);
    profit[0][0] = 0;
    if (v[0].g <= k) {
        profit[0][v[0].g] = v[0].p;
    }
    for (int i = 1; i < n; i++) {
        profit[i] = profit[i-1];
        for (int j = v[i].g; j <= k; j++) {
            if (profit[i-1][j-v[i].g] != -1) {
                profit[i][j] = max(profit[i][j], profit[i-1][j-v[i].g] + v[i].p);
            }
        }
    }
    int profit_max = -1;
    for (auto p: profit[n-1]) {
        profit_max = max(profit_max, p);
    }
    out << profit_max << "\n";
    out.close();
    return 0;
}