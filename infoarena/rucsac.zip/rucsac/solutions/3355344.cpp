#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int main() {
    ifstream fin("rucsac.in");
    ofstream fout("rucsac.out");

    int n, g;
    fin >> n >> g;

    vector<int> w(n+1);
    vector<int> p(n+1);

    for (int i = 1; i <= n; i++) {
        int iw, ip;
        fin >> iw >> ip;
        w[i] = iw;
        p[i] = ip;
    }

    vector<vector<int>> dp(g+1, vector<int>(n+1, 0));
    for (int i = 1; i <= g; i++) {
        dp[i][0] = 0;
    }

    for (int i = 1; i <= g; i++) {
        for (int j = 1; j <= n; j++) {
            dp[i][j] = dp[i][j-1];

            if (i - w[j] >= 0) {
                dp[i][j] = max(dp[i][j], dp[i - w[j]][j-1] + p[j]);
            }
        }
    }

    fout << dp[g][n];

    fin.close();
    fout.close();

    return 0;
}