#include <fstream>

using namespace std;
int dp[5005][10005], c[5005], w[5005];
int main()
{
    ifstream cin("rucsac.in");
    ofstream cout("rucsac.out");
    int n, g;
    cin >> n >> g;
    for(int i = 1; i <= n; i++){
        cin >> w[i] >> c[i];
    }
    for(int i = 1; i <= n; i++){///obiectele
        for(int j = 0; j <= g; j++){///greutatile
            if(w[i] <= j){
                dp[i][j] = max(dp[i - 1][j], (dp[i - 1][j - w[i]] + c[i]));
            }else{
                dp[i][j] = dp[i - 1][j];
            }
        }
    }
    cout << dp[n][g];
    return 0;
}
