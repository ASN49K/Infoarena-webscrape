#include <fstream>

using namespace std;
Ifstream cin("rucsac.in");
Ofstream cout("rucsac.out");
int max=0;
int s=0,s1=0;
int n,G;
struct rucsac{
    int g;
    int p;}v[1000];
    struct rez{
    int g1;
    int p1;
    int d;}x[1000];

int afisare()
{
    for(int i=n;i>0;i--)
    {
       s=x[i].g1+s;
       if (s<=G) s1=x[i].p1+s1;

    }
    cout<<s1;
}
int main()
{cin>>n>>G;
if(n==0 || G==0) cout<<0;
else
{
    for(int i=1;i<=n;i++)
    {
        cin>>v[i].g>>v[i].p;
           x[i].d=v[i].p-v[i].g;
           x[i].p1=v[i].p;
           x[i].g1=v[i].g;    }
    for(int i=1;i<=n-1;i++)
{
	for(int j=i+1;j<=n;j++)
	{
		if(x[i].d>x[j].d)
		{
		swap(x[i],x[j]);
		}
	}

}
for(int i=1;i<=n-1;i++)
{
    if(x[i].d==x[i-1].d)
    {
        if(x[i].p1<x[i-1].p1) swap(x[i],x[i-1]);
    }
}
} afisare();


    return 0;
}