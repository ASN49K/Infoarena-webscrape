#include <bits/stdc++.h>
using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

#define cin fin
#define cout fout
#define ll long long

int n, gmax;
int dp[10001];
int w[5001], v[5001];

int main() {
    cin >> n >> gmax;
    for(int i = 1; i <= n; i++) {
        cin >> w[i] >> v[i];
    }
    for(int i = 1; i <= n; i++) {
        for(int j = gmax; j >= w[i]; j--) {
            dp[j] = max(dp[j], dp[j-w[i]]+v[i]);
        }
    }
    cout << dp[gmax];
    return 0;
}
