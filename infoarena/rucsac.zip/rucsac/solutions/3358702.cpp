#include <fstream>
using namespace std;struct b{int g, v;}x[10001];int v[10001];int main(){ifstream f("rucsac.in");ofstream o("rucsac.out");int i, j, n, m;f>>n>>m;for(i=1;i<=n;i++)f>>x[i].g>>x[i].v;for(i=1;i<=n;i++)for(j=m;j>=x[i].g;j--)v[j]=max(v[j-x[i].g]+x[i].v,v[j]);o<<v[m];}
