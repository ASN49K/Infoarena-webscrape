#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int w[5001], p[5001];
int dp[10001];

int main()
{
    int n, g;
    fin>>n>>g;

    for(int i = 1; i <= n; i++){
        fin>>w[i]>>p[i];
    }

    int sol = 0;

    for(int i = 1; i <= n; i++){
        int lin_cur = i % 2;
        int lin_ant = 1 - lin_cur;
        for(int j = g; j >= 0; j--){
            if(j < w[i]){
                dp[j] = dp[j];
            }
            else{
                dp[j] = max(dp[j], dp[j - w[i]] + p[i]);
            }
        }
    }

    for(int j = 0; j <= g; j++){
        sol = max(dp[j], sol);
    }

    fout<<sol;

    return 0;
}
