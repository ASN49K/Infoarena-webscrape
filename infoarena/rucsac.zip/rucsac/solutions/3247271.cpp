#include <bits/stdc++.h>

using namespace std;
int dp[100005], w[100005], p[100005];
int main()
{
    ifstream cin("rucsac.in");
    ofstream cout("rucsac.out");
    int n,g;
    cin>>n>>g;
    for(int i=1;i<=n;i++)
        cin>>w[i]>>p[i];

    for(int i=1; i<=n; i++)
        for(int j=g; j>=w[i]; j--)
            dp[j] = max(dp[j], dp[j-w[i]] + p[i]);

    cout<<dp[g];

    return 0;
}
