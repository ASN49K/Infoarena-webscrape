#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("rucsac.in");
ofstream fout ("rucsac.out");

int n,G,p[5001],g[5001],dp[2][5001];

int main()
{
    fin>>n>>G;
    for(int i=1;i<=n;i++) fin>>g[i]>>p[i];
    for(int i=1;i<=n;i++)
        for(int j=1;j<=G;j++)
        {
            dp[i%2][j]=dp[(i-1)%2][j];
            if(g[i]<=j) dp[i%2][j]=max(dp[i%2][j],dp[(i-1)%2][j-g[i]]+p[i]);
        }
    fout<<dp[n%2][G];
    return 0;
}
