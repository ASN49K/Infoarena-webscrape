#include <fstream>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int v[1001], n, g, i, j, dp[4][10001], w[5001], p[5001];
int main()
{
    fin>>n>>g;
    for(i=1; i<=n; i++)
        fin>>w[i]>>p[i];
    for(i=1; i<=n; i++)
    {
        for(j=1; j<=g; j++)
        {
            if(w[i]>j)
                dp[2][j]=dp[1][j];
            else
                dp[2][j]=max(dp[1][j], dp[1][j-w[i]]+p[i]);
        }
        for(j=1; j<=g; j++)
        {
            dp[1][j]=dp[2][j];
            dp[2][j]=0;
        }
    }
    fout<<dp[1][g];
    return 0;
}
