#include <fstream>
#include <algorithm>
#include <vector>
#include <cstring>
using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

const int INF=10000005;
int mat[101][101],dr[101];

struct obj{int g,pr;};

bool cmp(obj o1,obj o2)
{
    return (o1.pr<o2.pr);
}

int main()
{
    int n,G,G_T=0,P_T=0;
    cin>>n>>G;
    obj o[5001];

    for(int i=1;i<=n;i++)
    {
        cin>>o[i].g>>o[i].pr;
        P_T+=o[i].pr;
        G_T+=o[i].g;
    }

    sort(o+1,o+n+1,cmp);

    for(int i=1;i<n;i++)
        for(int j=i+1;j<=n;j++)
            if(o[i].pr==o[j].pr&&o[i].g<o[j].g)
                swap(o[i],o[j]);
    int i=1;
    while(G_T>G&&i<=n)
    {
        G_T=G_T-o[i].g;
        P_T=P_T-o[i].pr;
        i++;
    }
    cout<<P_T;
}

