#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

std::ifstream in("rucsac.in");
std::ofstream out("rucsac.out");

int main() {
    int N, G;
    in >> N >> G;

    std::vector<int> w(N);
    std::vector<int> p(N);
    std::vector<int> dp(G + 1, 0);
    
    for (int i = 0; i < N; i++) {
        in >> w[i] >> p[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j = G; j >= w[i]; j--) {
            if (dp[j - w[i]] + p[i] > dp[j]) {
                dp[j] = dp[j - w[i]] + p[i];
            }
        }
    }
    out << dp[G] << std::endl;
    return 0;
}

