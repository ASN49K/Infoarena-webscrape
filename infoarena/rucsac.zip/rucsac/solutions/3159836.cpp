#include <fstream>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int v[1001], n, g, i, j, dp[5001][10001], w[5001], p[5001];
int main()
{
    fin>>n>>g;
    for(i=1; i<=n; i++)
        fin>>w[i]>>p[i];
    for(i=1; i<=n; i++)
        for(j=1; j<=g; j++)
    {
        if(w[i]>j)
            dp[i][j]=dp[i-1][j];
        else
            dp[i][j]=max(dp[i-1][j], dp[i-1][j-w[i]]+p[i]);
    }
    fout<<dp[n][g];
    return 0;
}
