#include <bits/stdc++.h>
using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

struct obiect{
  int greutate;
  int profit;

};

obiect v[5002];

int dp[5002];


int main() {
   int n,g;
   fin>>n>>g;
   
   
   for(int i=1;i<=n;i++){
    fin>>v[i].greutate>>v[i].profit;
    
   }
   
   dp[0]=0;
   for(int i=1;i<=g;i++){
    dp[i]=-1;
    
    
   }
   
   for(int i=1;i<=n;i++){
    for(int j=g-v[i].greutate;j>=0;j--){
            if(dp[j]!=-1 && dp[v[i].greutate+j]<dp[j]+v[i].profit){
                dp[v[i].greutate+j]=dp[j]+v[i].profit;
                
            }
        
        
    }
   }
   
   int ans=-1;
   for(int i=1;i<=g;i++){
    if(dp[i]>ans){
        ans=dp[i];
    }
   }
   
   
   fout<<ans;
   
   
   
   
}