#include <fstream>
#include <vector>

using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

int main() {
    int n, g;
    cin >> n >> g;

    vector<int> dp(g + 5, 0);
    for (int i = 1; i <= n; i++) {
        int w, p;
        cin >> w >> p;

        for (int j = g; (j - w) >= 0; j--) {
            dp[j] = max(dp[j], dp[j - w] + p);
        }
    }

    cout << dp[g] << '\n';
}
