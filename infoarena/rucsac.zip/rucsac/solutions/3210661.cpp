#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int dp[2][10001], n, G, p[5001], g[5001];

int main(){
    fin >> n >> G;
    for(int i = 1; i <= n; i++) fin >> g[i] >> p[i];
    for(int i = 1; i <= n; i++){
        for(int gc = 0; gc <= G; gc++){
            dp[i % 2][gc] = dp[(i - 1) % 2][gc];

            if(g[i] <= gc) dp[i % 2][gc] = max(dp[i % 2][gc], dp[(i - 1) % 2][gc - g[i]] + p[i]);
        }
    }
    fout << dp[n % 2][G];
    return 0;
}