#include <fstream>
#include <vector>
#include <iomanip>
#include <algorithm>

using namespace std;

ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

struct rucsac
{
    int g, p;
};

ostream &operator<<(ostream &os, rucsac a)
{
    return os << a.g << " " << a.p;
}

bool comp(rucsac a, rucsac b)
{
    return ((double)a.p / (double)a.g) > ((double)b.p / (double)b.g);
}

vector<rucsac> v;

int greedy(int k)
{
    sort(v.begin(), v.end(), comp);
    size_t i = 0;
    double val = 0;
    while (k)
    {
        if (v[i].g <= k)
        {
            val += v[i].p;
            k -= v[i].g;
            i++;
        }
        else
        {
            break;
        }
    }
    return val;
}

int back(int n, int k)
{
    if (k == 0 || n < 0)
    {
        return 0;
    }
    if (v[n].g > k)
    {
        return back(n - 1, k);
    }
    else
    {
        return max(back(n - 1, k), v[n].p + back(n - 1, k - v[n].g));
    }
}

int main()
{
    size_t n;
    int k;
    cin >> n >> k;
    for (size_t i = 0; i < n; i++)
    {
        rucsac local;
        cin >> local.g >> local.p;
        v.push_back(local);
    }
    // int greed = greedy(obiecte, k);
    int bck = back(v.size() - 1, k);
    cout << bck;
}