#include <bits/stdc++.h>
using namespace std;
const int GMAX=1e4+5;
const int NMAX=5005;
int n,G,p[NMAX],w[NMAX],dp[GMAX],mx;
signed main(){
    ifstream f("rucsac.in");
    ofstream g("rucsac.out");
    f>>n>>G;
    for(int i=1;i<=n;i++){
        f>>w[i]>>p[i];
    }
    for(int i=1;i<=n;i++){
        for(int gr=G;gr>=w[i];gr--){
            dp[gr]=max(dp[gr],dp[gr-w[i]]+p[i]);
            mx=max(mx,dp[gr]);
        }
    }
    g<<mx;
    return 0;
}
