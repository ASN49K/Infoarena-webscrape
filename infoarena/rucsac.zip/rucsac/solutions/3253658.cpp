#include <fstream>
#include <cstring>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int n,G,w[5005],c[5005],dp[5][10005];
int main()
{
    fin>>n>>G;
    for(int i=1;i<=n;i++)
    {
        fin>>w[i]>>c[i];
    }
    memset(dp, 0, sizeof(dp));
    for(int i=1;i<=n;i++)
    {
        for(int k=0;k<=G;k++)
            if(k>=w[2])
                dp[2][k]=max(dp[1][k], dp[1][k-w[2]]+c[2]);
            else dp[2][k]=dp[1][k];
        if(i>2)
            for(int k=0;k<=G;k++)
                swap(dp[1][k],dp[2][k]),dp[2][k]=0;
    }
    fout<<dp[n][G];
    return 0;
}
