#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream in("rucsac.in");
ofstream out("rucsac.out");

struct obiect
{
    int p, g;
};

int profit_max;

int main()
{
    int n, k;

    in>>n>>k;

    vector<obiect>v(n);
    vector<int>profit(k+1, -1);

    for (int i=0; i<n; i++)
    {
        in>>v[i].g>>v[i].p;
    }

    profit[0] = 0;

    if (v[0].g<=k)
    {
        profit[v[0].g] = v[0].p;
    }

    for (int i=1; i<n; i++)
    {
        for (int j=k; j>=v[i].g; j--)
        {
            if (profit[j-v[i].g] != -1)
            {
                profit[j] = max(profit[j], profit[j-v[i].g] + v[i].p);
            }
        }
    }

    for (int j=1; j<=k; j++)
    {
        profit_max = max(profit_max, profit[j]);
    }

    out<<profit_max;

    return 0;
}
