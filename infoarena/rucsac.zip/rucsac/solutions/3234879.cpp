#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

typedef struct
{
    int w, p;
} object_t;

int sortCompare(const object_t &a, const object_t &b)
{
    return a.p > b.p;
}

int main()
{
    int N, G;
    fin >> N >> G;

    vector<object_t> B(N);

    for (int i = 0; i < N; i++)
    {
        fin >> B[i].w >> B[i].p;
    }

    // Sort objects by profit
    sort(B.begin(), B.end(), sortCompare);

    int maxW = 0;
    int maxP = 0;
    for (int i = 0; i < N; i++)
    {
        if (maxW + B[i].w <= G)
        {
            maxW += B[i].w;
            maxP += B[i].p;
        }
    }

    fout << maxP << endl;

    fin.close();
    fout.close();
    return 0;
}