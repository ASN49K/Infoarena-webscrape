#include <iostream>
#include <fstream>
using namespace std;


ifstream fin("rucsac.in");
ofstream fout("rucsac.out");


int n,g,ans;


int gr[5005];
int pr[5005];
int dp[10005];///profitul maxim pe care il putem obtine din primele i elemente fara sa depasim greutatea w


int main()
{
    fin>>n>>g;
    for(int i=1;i<=n;i++)
        fin>>gr[i]>>pr[i];
    dp[0]=1;
    for(int i=1;i<=n;i++)
        for(int w=g-gr[i];w>=0;w--)
            if(dp[w])
            {
                dp[w+gr[i]]=max(dp[w+gr[i]],dp[w]+pr[i]);
                ans=max(ans,dp[w+gr[i]]);
            }
    fout<<ans-1;
    return 0;
}
