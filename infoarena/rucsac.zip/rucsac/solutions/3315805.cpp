#include <bits/stdc++.h>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int n,g,p[5010],w[5010],dp[2][10010];

int main()
{
    fin >>n >>g;
    for(int i = 1;i <= n;i++)
    {
        fin >>w[i] >>p[i];
    }
    for(int i = 1;i <= n;i++)
    {
        for(int c = 0;c <= g;c++)
        {
            dp[1][c] = dp[0][c];
            if(c-w[i] >= 0)
            {
                dp[1][c] = max(dp[1][c],dp[0][c-w[i]]+p[i]);
            }
        }
        for(int j = 0;j <= g;j++)
        {
            dp[0][j] = dp[1][j];
        }
    }
    fout <<dp[1][g];
    return 0;
}
