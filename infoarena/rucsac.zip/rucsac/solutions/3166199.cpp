/// met 2: dinamica pe 2 dimensiuni memorie 2*g
/// pentru ca foloseam doar liniile i si i-1, le inlocuim cu sus si jos
#include <iostream>

using namespace std;

int n, GMax, v[5002], w[5002], dp[2][10002], sus, jos = 1;

int main()
{
    cin >> n >> GMax;
    for (int i = 1; i <= n; i++)
        cin >> w[i] >> v[i];

    for (int i = 1; i <= n; i++) {
        swap(sus, jos);
        for (int g = 0; g <= GMax; g++) {
            dp[sus][g] = dp[jos][g];
            if (w[i] <= g) {
                dp[sus][g] = max(dp[sus][g], dp[jos][g-w[i]]+v[i]);
            }
        }
    }

    cout << dp[1][GMax];

    return 0;
}
