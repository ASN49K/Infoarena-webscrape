#include <bits/stdc++.h>
#define NMAX 5005

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int N,G;
int v[NMAX],Pmax;

struct obiect
{
    int w,p;
}obj[NMAX];

bool valid(int gr)
{
    return (gr<=G) && (1);
}

void bkt(int pos, int gr, int pr)
{
    if(!valid(gr)) return;

    if(pos==N+1)
    {
        if(pr>Pmax)
            Pmax=pr;
        return;
    }

    v[pos]=0;
    bkt(pos+1,gr,pr);
    v[pos]=1;
    bkt(pos+1,gr+obj[pos].w,pr+obj[pos].p);
}

bool cmp(obiect a, obiect b)
{
    return (a.p*b.w > b.p*a.w);
}

int main()
{
    int i;

    fin>>N>>G;

    for(i=1; i<=N; i++)
        fin>>obj[i].w>>obj[i].p;


    sort(obj+1,obj+N+1,cmp);

    bkt(1,0,0);

    fout<<Pmax;

    return 0;
}
