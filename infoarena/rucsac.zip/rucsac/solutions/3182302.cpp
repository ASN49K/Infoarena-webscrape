#include <fstream>
#include <iostream>
//#define ll long long

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
struct object
{
    int w, p;
}v[5005];
int n,g;
int dp[5005][10005];

void din()
{
    for(int i=1;i<=n;i++)
        for(int j=1;j<=g;j++)
    {
        if(v[i].w<=j)
        dp[i][j]=max(dp[i-1][j],v[i].p+dp[i-1][j-v[i].w]);
        else
            dp[i][j]=dp[i-1][j];
    }
}

int main()
{
    fin>>n>>g;
    for(int i=1;i<=n;i++)
        fin>>v[i].w>>v[i].p;
    din();
    //for(int i=0;i<=n;i++,cout<<'\n')
        //for(int j=0;j<=g;j++)
        //cout<<dp[i][j]<<" ";
    //cout<<'\n';
    fout<<dp[n][g];
    return 0;
}
