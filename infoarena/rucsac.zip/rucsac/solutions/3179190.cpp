#include <bits/stdc++.h>

using namespace std;

ifstream fin ("rucsac.in");
ofstream fout ("rucsac.out");

int n, gmax, dp[5001][5001], g[5001], p[5001];
int main()
{
    fin >> n >> gmax;

    for (int i = 1; i <= n; i++)
    {
        fin >> g[i] >> p[i];
    }

    for (int i = 1; i <= n; i++)
    {
        for (int cw = 0; cw <= gmax; cw++)
        {
            dp[i][cw] = dp [i-1][cw];
            if (g[i] <= cw)
            {
                dp[i][cw] = max(dp[i][cw], dp[i-1][cw-g[i]] + p[i]);
            }
        }
    }

    fout << dp[n][gmax];

    return 0;
}
