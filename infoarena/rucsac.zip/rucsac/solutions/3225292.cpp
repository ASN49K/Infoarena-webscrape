﻿#include <iostream>
#include <fstream>
#include <stdint.h>
#include <cctype>
#include <cstring>
#include <algorithm>
#include <vector>
#include <map>
#include <cmath>
#include <set>
#include <queue>

using namespace std;
typedef long long ll;
#pragma warning(disable : 4996)
;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

//rucsac discret

int p[5001], g[5001], N, G, dp[10001];

int main() {

	fin >> N >> G;

	for (int i = 1; i <= N; i++)
		fin >> g[i] >> p[i];

	for (int i = 1; i <= N; i++)
		for (int j = G - g[i]; j >= 0; j--)
			dp[j + g[i]] = max(dp[j + g[i]], dp[j] + p[i]);

	int maxi = -1;
	for (int i = 1; i <= G; i++) maxi = max(maxi, dp[i]);

	fout << maxi;

	return 0;
}