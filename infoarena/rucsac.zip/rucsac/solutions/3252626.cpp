#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int w[5001],p[5001],dp[10001];
int n,G;

int main()
{
    fin>>n>>G;
    for(int i=1;i<=n;i++)
    {
        fin>>w[i]>>p[i];
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=G;j>=w[i];j--)
        {
            dp[j]=max(dp[j],dp[j-w[i]]+p[i]);
        }
    }
    fout<<dp[G];
    return 0;
}
