#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>



using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int main() {
    int N, G;
    fin >> N >> G;
    vector<int> dp(G+1, 0);

    for(int i = 1; i<=N; i++) {
        int W, P;
        fin >> W >> P;

        for(int g = G; g >= W; g--) {
            dp[g] = max(dp[g], dp[g - W] + P);
        }
    }

    fout << dp[G];
    return 0;
}