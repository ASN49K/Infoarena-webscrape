#include <bits/stdc++.h>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
struct ob
{
    double g;
    double pret;
}c[1001*1001+1];
int n;
double gmax;
void citire(ob v[],int&n)
{
    fin>>n;
    fin>>gmax;
    for(int i=1;i<=n;++i)
    {
        fin>>v[i].g>>v[i].pret;
    }
}
void ord(ob v[],int n)
{
    int ok;
    do
    {
        ok=0;
        for(int i=1;i<n;++i)
        {
            if(v[i].pret/v[i].g<v[i+1].pret/v[i+1].g)
            {
                v[0]=v[i];
                v[i]=v[i+1];
                v[i+1]=v[0];
                ok=1;
            }
        }
    }
    while(ok==1);
}
void solve(ob v[],int n)
{
    double s=0;
    for(int i=1;i<=n && gmax>0;++i)
    {
        if(v[i].g<=gmax)
        {
            s=s+v[i].pret;
            gmax=gmax-v[i].g;
        }
        else
        {
            s+=gmax*(v[i].pret/v[i].g);
            gmax=0;
        }
    }
    fout<<s;
}
int main()
{
    citire(c,n);
    ord(c,n);
    solve(c,n);
    return 0;
}
