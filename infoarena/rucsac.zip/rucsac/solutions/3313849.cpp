#include <fstream>

using namespace std;
struct jd{
    int p, w;
};
jd v[5005];
int dp[5005][10005];
int main()
{
    ifstream cin("rucsac.in");
    ofstream cout("rucsac.out");
    int n, g;
    cin >> n >> g;
    for(int i = 1; i <= n; i++){
        cin >> v[i].w >> v[i].p;
    }
    for(int j = 1; j <= g; j++){
        for(int i = 1; i <= n; i++){
            dp[i][j] = dp[i - 1][j];
            if(v[i].w <= j){
                dp[i][j] = max(dp[i][j], dp[i - 1][j - v[i].w] + v[i].p);
            }
        }
    }
    cout << dp[n][g];
    return 0;
}
