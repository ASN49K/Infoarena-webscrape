#include <bits/stdc++.h>

using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    ifstream fin("rucsac.in");
    ofstream fout("rucsac.out");

    int n, g;
    if (!(fin >> n >> g)) return 0;

    vector<int> dp(g + 1, 0);

    for (int i = 0; i < n; ++i) {
        int w, p;
        fin >> w >> p;
        for (int j = g; j >= w; --j) {
            dp[j] = max(dp[j], dp[j - w] + p);
        }
    }

    fout << dp[g] << "\n";

    return 0;
}














