#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

constexpr int NMAX = 5010, GMAX = 10010;

int w[NMAX], p[NMAX], dp[GMAX];

int main()
{
    int n, g;
    fin >> n >> g;

    for (int i = 1; i <= n; i++)
        fin >> w[i] >> p[i];

    // Pentru fiecare obiect
    for (int i = 1; i <= n; i++)
    {
        // Vedem in ce rucsacuri ne avantajeaza sa-l adaugam
        for (int j = g; j >= w[i]; j--)
        {
            dp[j] = max(dp[j], dp[j - w[i]] + p[i]); // maximul dintre daca nu adaugam elementul actual si daca il adaugam la solutia cu maxim j - w[i]
        }
    }

    fout << dp[g];
}
