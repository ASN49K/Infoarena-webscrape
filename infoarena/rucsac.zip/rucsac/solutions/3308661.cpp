#include <bits/stdc++.h>
using namespace std;

ifstream fin ("rucsac.in");
ofstream fout ("rucsac.out");

int n, g, w, p, maxi = 0;
int dp[5001][10001];

int main(){

    fin >> n >> g;

    dp[0][0] = 1;

    for (int i = 1; i <= n; i++){
        fin >> w >> p;
        for (int j = g; j >= w; j--){
            if (dp[i - 1][j - w] != 0){
                dp[i][j] = max(dp[i-1][j], (dp[i - 1][j - w] + p));
            }
            else{
                dp[i][j] = dp[i-1][j];
            }
        }
    }

    for (int j = 1; j <= g; j++){
        if (dp[n][j] >= maxi){
            maxi = dp[n][j];
        }
    }

    fout << maxi - 1;

    return 0;

}
