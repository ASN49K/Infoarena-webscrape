#include <stdio.h>
#include <stdlib.h>

#define FILE_IN "rucsac.in"
#define FILE_OUT "rucsac.out"
#define ITEM_AMOUNT 5000
#define WEIGHT_MAX 10000

int values[ITEM_AMOUNT + 1], weights[ITEM_AMOUNT + 1];
int m[ITEM_AMOUNT + 1][WEIGHT_MAX + 1];
int n, w;

int max(int a, int b) {
    return a > b ? a : b;
}

int main()
{
    FILE *fileIn = fopen(FILE_IN, "r"),
         *fileOut = fopen(FILE_OUT, "w");

    fscanf(fileIn, "%d%d", &n, &w);
    for(int i = 1; i <= n; i++) {
        fscanf(fileIn, "%d%d", &weights[i], &values[i]);
    }
    
    for(int j = 0; j <= w; j++) {
        m[0][j] = 0;
    }
    for(int i = 0; i <= n; i++) {
        m[i][0] = 0;
    }
    
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= w; j++) {
            if(weights[i] > j) m[i][j] = m[i - 1][j];
            else m[i][j] = max(m[i - 1][j], m[i - 1][j - weights[i]] + values[i]);
        }
    }

    fprintf(fileOut, "%d\n", m[n][w]);

    fclose(fileIn);
    fclose(fileOut);
    return 0;
}
