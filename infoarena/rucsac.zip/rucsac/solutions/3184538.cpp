#include <fstream>
#include <string.h>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

const int oo = 0x3f3f3f3f;
const int GMAX = 1e4 + 2;

int dp[GMAX], n, w, p, g, res;

int main()
{
    fin >> n >> g;
    memset(dp, -oo, sizeof(dp));

    dp[0] = 0;

    for (int i = 1; i <= n; ++i)
    {
        fin >> w >> p;

        for (int j = g; j >= 0; --j)
        {
            if (j - w >= 0)
                dp[j] = max(dp[j], dp[j - w] + p);
            if (dp[j] > res)
                res = dp[j];
        }
    }

    fout << res << '\n';

    return 0;
}