#include <fstream>

using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
int a[5000][2], dp[1000][1000],n,dim;
int main()
{
    cin>>n>>dim;
    for(int i=1;i<=n;i++){
        cin>>a[i][1]>>a[i][2];
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=dim;j++){
            if(a[i][1]<=j){
                dp[i][j]=max(dp[i-1][j],a[i][2]+dp[i-1][j-a[i][1]]);
            }else
            {
                dp[i][j]=dp[i-1][j];
            }

        }
    }
/**
    for(int i=1;i<=n;i++,cout<<'\n')
        for(int j=1;j<=dim;j++)
            cout<<dp[i][j]<<' ';
*/
    cout<<dp[n][dim];
    return 0;
}
