#include <bits/stdc++.h>

using namespace std;
ifstream in("rucsac.in");
ofstream out("rucsac.out");
int v[10001],n,i,p,g,k,j,sol;
int main()
{
    in>>n>>k;
    for(i=1;i<=k;i++){
        v[i]=-1;
    }
    for(i=1;i<=n;i++){
        in>>g>>p;
        for(j=k;j>=0;j--){
            if(v[j]!=-1){
               v[j+g]=max(v[j+g],v[j]+p);
            }
        }
        /*for(j=0;j<=k;j++){
            cout<<v[j]<<" ";
        }
        cout<<"\n";*/
    }
    for(j=0;j<=k;j++){
        sol=max(sol,v[j]);
    }
    out<<sol;
    return 0;
}
