#include <fstream>
using namespace std;
struct o{
    int g, v;
}x[10001];
int v[10001];
int main()
{
    ifstream fin("rucsac.in");
    ofstream fout("rucsac.out");
    int i, j, n, m;
    fin>>n>>m;
    for(i=1;i<=n;i++)
        fin>>x[i].g>>x[i].v;
    for(i=1;i<=n;i++)
        for(j=m;j>=x[i].g;j--)
            v[j]=max(v[j-x[i].g]+x[i].v,v[j]);
    fout<<v[m]<<'\n';
    return 0;
}
