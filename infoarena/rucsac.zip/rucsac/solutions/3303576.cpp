#include <fstream>
#include <vector>

struct taska{
   int w, p;
};

int main(){
   std::ifstream bem("rucsac.in");
   std::ofstream kim("rucsac.out");
   int n, g;
   bem >> n >> g;
   std::vector<taska> tomb(n);
   std::vector<int> dp(g + 1, 0);
   for(int i = 0; i < n; i++) bem >> tomb[i].w >> tomb[i].p;
   for(int i = 0; i < n; i++)
      for(int j = g; j >= tomb[i].w; j--)
         dp[j] = ((dp[j] > dp[j - tomb[i].w] + tomb[i].p) ? dp[j] : dp[j - tomb[i].w] + tomb[i].p);
   kim << dp[g] << '\n';
}
