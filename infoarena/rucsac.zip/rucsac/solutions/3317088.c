#include <stdio.h>
#include <stdlib.h>
#define N 5000
#define K 10000

typedef struct
{
    int g, p;
} obiect;

int profit[K+1];

int max(int x, int y)
{
    return (x > y ? x : y);
}

int main()
{
    FILE *in, *out;
    in = fopen("rucsac.in", "r");
    out = fopen("rucsac.out", "w");
    int n, k;
    fscanf(in, "%d%d", &n, &k);
    ///initializare profit
    profit[0] = 0;
    for (int j = 1; j <= k; j++)
    {
        profit[j] = -1;
    }
    for (int i = 0; i < n; i++)
    {
        obiect ob_i;
        fscanf(in, "%d%d", &ob_i.g, &ob_i.p);
        for (int j = k - ob_i.g; j >= 0; j--)
        {
            if (profit[j] != -1)
            {
                profit[j+ob_i.g] = max(profit[j+ob_i.g], profit[j] + ob_i.p);
            }
        }
    }
    ///gasim profitul maxim
    int profit_maxim = -1;
    for (int j = 1; j <= k; j++)
    {
        profit_maxim = max(profit_maxim, profit[j]);
    }
    fprintf(out, "%d\n", profit_maxim);
    fclose(in);
    fclose(out);
    return 0;
}
