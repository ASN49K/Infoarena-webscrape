#include <bits/stdc++.h>
using namespace std;

ifstream f("rucsac.in");
ofstream g("rucsac.out");

int n, gmax, greutate[5001], valoare[5001];
int dp[1001][10001];
int main(){
    f >> n >> gmax;
    for(int i = 1; i <= n; i++){
        f >> greutate[i] >> valoare[i];
    }

     
    for(int cap = 0; cap <= gmax; cap++){
        dp[0][cap] = 0;
    }

    for(int i = 1; i <= n; i++){
        for(int cap = 0 ; cap <= gmax; cap++){
            dp[i][cap] = dp[i - 1][cap];

            if(cap - greutate[i] >= 0){
                int sol_aux = dp[i - 1][cap - greutate[i]] + valoare[i];
                dp[i][cap] = max(dp[i][cap], sol_aux);
            }
        }
    }

    g << dp[n][gmax];

    return 0;
}