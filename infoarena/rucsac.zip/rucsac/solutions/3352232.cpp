#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
const int Nmax = 1e4+5;
int n, g;
// int weights[Nmax], vals[Nmax], dp[Nmax][Nmax];
vector<int> weights, vals, prevdp, curdp;
void citire(){
    fin >> n >> g;
    weights.resize(n+1);
    vals.resize(n+1);
    prevdp.resize(g+1, 0);
    curdp.resize(g+1, 0);
    for(int i = 1; i<=n; i++) {
        fin >> weights[i] >> vals[i];
    }
}
void solve(){
    for(int i = 1; i<=n; i++){
        for(int j = 1; j<=g; j++){
            if(weights[i] > j) curdp[j] = prevdp[j];
            else{
                curdp[j] = max(prevdp[j], vals[i] + prevdp[j-weights[i]]);
            }
        }
        prevdp = curdp;
    }
}
int main(){
    citire();
    solve();
    fout << curdp[g] << '\n';

    return 0;
}