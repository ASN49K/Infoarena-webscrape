#include <iostream>
#include <vector>
#include <algorithm>
#include<fstream>

using namespace std;

int main()
{
    ifstream fin("rucsac.in");
    ofstream fout("rucsac.out");
    int n, g;
    fin >> n >> g;
    vector<pair<int, int>> wp(n + 1);
    for(int i = 1; i <= n; i++) {
        fin >> wp[i].first>>wp[i].second;
    }
    vector<vector<int>> dp(n + 1, vector<int>(g + 1, 0));
    for(int i = 1; i <= n; i++) {
        for(int j = 0; j <= g; j++) {
            if (j - wp[i].first >= 0) {
                dp[i][j] = max({dp[i - 1][j], dp[i - 1][j - wp[i].first] + wp[i].second});

            } else {
                dp[i][j] = dp[i - 1][j];
            }
        }
    }

    fout << dp[n][g] << "\n";
    return 0;


}