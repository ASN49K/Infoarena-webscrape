#include <iostream>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>

using namespace std;
int main(){
	int n,g;
	freopen("rucsac.in","r",stdin);
	freopen("rucsac.out","w",stdout);
	scanf("%d %d",&n,&g);
	vector<int> greutate(n+1);
	vector<int> profit(n+1);
	for(int i=1;i<=n;i++){
		scanf("%d %d",&greutate[i],&profit[i]);
	}
	vector<vector<int>> dp(n+1,vector<int>(g+1,0));
	// for(int i=1;i<=n;i++){
	// 	printf("%d %d\n",greutate[i],profit[i]);
	// }
	int pmax=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=g;j++){
			int luam=0;
			if(j-greutate[i]>=0){
				luam=dp[i-1][j-greutate[i]]+profit[i];
			} 
			int nu_luam=dp[i-1][j];
			dp[i][j]=max(luam,nu_luam);
		}
	}
	printf("%d\n",dp[n][g]);
	return 0;
}