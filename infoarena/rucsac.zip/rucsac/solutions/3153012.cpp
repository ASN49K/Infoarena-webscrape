#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int n, gmax, dp[10005];

void citire() {
    fin>>n>>gmax;
    int g, v;
    for (int i=0; i<n; i++) {
        fin>>g>>v;
        for (int j=gmax; j>=g; j--)
            dp[j]=max(dp[j], dp[j-g]+v);
    }
}

int main() {
    citire();
    fout<<dp[gmax];
    return 0;
}
