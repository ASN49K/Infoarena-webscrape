#include <bits/stdc++.h>
using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
///rucsac

int n, G;
int w[5005], p[5005];
int dp[5005];

int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int i, j;
    fin >> n >> G;
    for(i=1; i<=n; i++)
        fin >> w[i] >> p[i];
    for(i=1; i<=n; i++)
        for(j=G; j>=1; j--)
            if(w[i] <= j) dp[j] = max(dp[j], dp[j-w[i]] + p[i]);
    fout << dp[G] << " ";
    fin.close();
    fout.close();
    return 0;
}
