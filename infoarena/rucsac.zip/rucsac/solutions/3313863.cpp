#include <bits/stdc++.h>

using namespace std;

struct Ir{
    int c,v;
};
Ir v[5005];

int cmp(Ir a,Ir b)
{
    if(a.c==b.c)
        return a.v > b.v;
    return a.c>b.c;
}
int dp[10005];
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        cin>>v[i].c>>v[i].v;
    }
    sort(v+1,v+n+1,cmp);
    for(int i=1;i<=n;i++)
    {
        for(int j=m;j>=0;j--)
        {
            if(dp[j]>0)
            dp[v[i].c+j]=max(dp[v[i].c+j],dp[j]+v[i].v);
        }
        dp[v[i].c]=max(dp[v[i].c],v[i].v);
    }

    for(int i=1;i<=m;i++)
    {
        dp[i]=max(dp[i-1],dp[i]);
    }
    cout<<dp[m];

    return 0;
}
