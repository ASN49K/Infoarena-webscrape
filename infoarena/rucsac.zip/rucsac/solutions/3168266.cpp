#include <bits/stdc++.h>
#define DIM 10001
using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int n, gmax, ans;
int g[DIM], p[DIM], d[DIM*DIM];
int i, j;

int main(){
    fin>>n>>gmax;
    for(i=1; i<=n; i++)
        fin>>g[i]>>p[i];
    d[0]=1;
    for(i=1; i<=n; i++){
        for(j=gmax; j>=0; j--){
            if(d[j] && j+g[i]<gmax){
                d[j+g[i]]=max(d[j+g[i]], d[j]+p[i]);
                ans=max(ans, d[j+g[i]]);
            }
        }
    }
    fout<<ans+1;
}
