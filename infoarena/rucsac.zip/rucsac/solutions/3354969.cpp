#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int dp[10005];

int main() {
    int n, g;
    fin >> n >> g;
    vector <int> dp(g + 1, 0);
    for (int i = 1; i <= n; i++) {
        int w_object, p_object;
        fin >> w_object >> p_object;
        for (int w = g; w >= w_object; w--) {
            dp[w] = max(dp[w], dp[w - w_object] + p_object);
        }
    }
    
    fout << dp[g] << '\n';
    return 0;
}