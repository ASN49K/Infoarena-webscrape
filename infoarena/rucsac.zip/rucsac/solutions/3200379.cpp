// #include <iostream>
#include <fstream>

using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
int n,gmax;
int g[5002],p[5002],mat[5002][10002];

int main()
{
    cin>>n>>gmax;
    
    for(int i=1;i<=n;++i)
        cin>>g[i]>>p[i];
        
    for(int i=1;i<=n;++i)
        for(int j=0;j<=gmax;++j){
            mat[i][j]=mat[i-1][j];
            
            if(j>=g[i])
                mat[i][j]=max(mat[i][j],p[i]+mat[i-1][j-g[i]]);
        }
    
    cout<<mat[n][gmax];
                
    return 0;
}