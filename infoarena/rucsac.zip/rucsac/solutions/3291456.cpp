#include <bits/stdc++.h>
#define pii pair<int,int>

using namespace std;

ifstream f("lca.in");
ofstream g("lca.out");

int n,q,x,k,viz[100200],nivel[100200],first[100200],node[400200],rmq[20][400200];
vector <int> edges[100200];

void euler(int x){
    viz[x]=1;
    node[++k]=x;
    for(auto y:edges[x])
        if(viz[y]==0)
            nivel[y]=nivel[x]+1, euler(y), node[++k]=x;
}

void rmqprecalc()
{
    for(int i=1; i<=k; i++)
        rmq[0][i]=i;
    for(int l=1; (1<<l)<=k; l++)
        for(int i=1; i<=k-(1<<l)+1; i++)
        {
            int j=i+(1<<(l-1));
            if(nivel[node[rmq[l-1][i]]]<=nivel[node[rmq[l-1][j]]])
                rmq[l][i]=rmq[l-1][i];
            else
                rmq[l][i]=rmq[l-1][j];
        }
}

int32_t main()
{
    f>>n>>q;
    for(int i=2; i<=n; i++)
        f>>x, edges[x].push_back(i);
    euler(1);
    rmqprecalc();
    for(int i=1; i<=k; i++)
        cout<<i<<' ';
    for(int i=1; i<=k; i++)
        if(first[node[i]]==0)
            first[node[i]]=i;
    for(int i=1; i<=q; i++)
    {
        int x,y;
        f>>x>>y;
        x=first[x], y=first[y];
        if(x>y)
            swap(x,y);
        int l=log2(y-x+1);
        if(nivel[node[rmq[l][x]]]<nivel[node[rmq[l][y-(1<<l)+1]]])
            g<<node[rmq[l][x]]<<'\n';
        else
            g<<node[rmq[l][y-(1<<l)+1]]<<'\n';
    }
    return 0;
}
