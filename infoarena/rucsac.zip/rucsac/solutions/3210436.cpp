#include <bits/stdc++.h>

using namespace std;

ifstream fin ("rucsac.in");
ofstream fout ("rucsac.out");

int n, g, mar, gre, mat[3][10001];

int main()
{
    fin >> n >> g;

    for (int i = 1; i <= n; i ++)
    {
        fin >> mar >> gre;

        for (int j = 1; j <= g; j ++)
        {
            if (j >= mar)
                mat[2][j] = max(mat[1][j - mar] + gre, mat[1][j]);
            else
                mat[2][j] = mat[1][j];
        }

        for (int j = 1; j <= g; j ++) mat[1][j] = mat[2][j];
    }

    fout << mat[2][g];

    return 0;
}
