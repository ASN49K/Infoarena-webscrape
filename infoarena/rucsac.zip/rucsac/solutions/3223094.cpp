#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

struct Obiect
{
   int prof, g;
   
};
Obiect ob[50001];

int dp[10001];

int main()
{
    int n, G;
       
    int i, j;
    
    fin>>n>>G;
    
    for(i=1; i<=n; i++)
        fin>>ob[i].g>>ob[i].prof;
    
    for(i=1; i<=n; i++)
    {
        for(j=G; j>=ob[i].g; j--)
        {
            int x = dp[j - ob[i].g] + ob[i].prof;
            dp[j] = max(x, dp[j]);
        }
    }
    
    int maxi=0;
    
    for(i=0; i<=G; i++)
    {
       if(dp[i]>maxi) maxi = dp[i];
    }
    
    fout<<maxi;
       

}
