#include <fstream>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
long long w[5002],p[5002],optim[10002],sol,n,g;

int main()
{
    fin>>n>>g;
    for(long long i=1;i<=n;i++)
    {
        fin>>w[i]>>p[i];
    }


    optim[0]=0;
    sol=0;

    for(long long i=1;i<=n;i++)
        {
            for(long long j=g-w[i];j>=0;j--)
                if(optim[j+w[i]] < optim[j]+p[i]  )
            {
                optim[j+w[i]] =optim[j]+p[i] ;
                if(optim[j+w[i]]>sol)sol=optim[j+w[i]];
            }
        }
        fout<<sol;
    return 0;
}
