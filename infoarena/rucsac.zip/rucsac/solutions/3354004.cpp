#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
const int Nmax = 1e4+5;
int n, g;
int weights[Nmax], vals[Nmax], dp[Nmax];
// vector<int> weights, vals, prevdp, curdp;
void citire(){
    fin >> n >> g;
    for(int i = 1; i<=n; i++) {
        fin >> weights[i] >> vals[i];
    }
}
void solve(){
    int ans = 0;
    for(int i = 1; i<=n; i++){
        for(int j = g-weights[i]; j>=0; j--){
            if(dp[j+weights[i]] < dp[j] + vals[i]){
                dp[j+weights[i]] = dp[j] + vals[i];
                if(dp[j+weights[i]] > ans) ans = dp[j+weights[i]];
            }
        }
    }
    cout << ans;
}
int main(){
    citire();
    solve();
    // fout << curdp[g] << '\n';

    return 0;
}