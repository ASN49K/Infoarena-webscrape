#include <bits/stdc++.h>

using namespace std;

#define inf -2000000

int dp[2][10001];

int main () {
    freopen("rucsac.in", "r", stdin);
    freopen("rucsac.out", "w", stdout);

    int n, g, w, p;
    cin >> n >> g;

    for (int i = 1; i <= g; ++i) {
        dp[0][i] = inf;
    }

    for (int i = 1; i <= n; ++i) {
        cin >> w >> p;
        for (int j = 0; j <= g; ++j) {
            if (j - w >= 0) {
                dp[i % 2][j] = max(dp[(i - 1) % 2][j], dp[(i - 1) % 2][j - w] + p);
            } else {
                dp[i % 2][j] = dp[(i - 1) % 2][j];
            }
        }
    }

    int res = -1;
    for (int i = 0; i <= g; ++i) {
        res = max(res, dp[n % 2][i]);
    }
    cout << res;

    return 0;
}
