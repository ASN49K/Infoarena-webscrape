﻿#include <iostream>
#include <vector>
#include <algorithm>
#include <iostream>
#include <string>
#include <bitset>
#include <queue>
#include <fstream>
#include <stdio.h>
#include <string.h>
#include <iomanip>
#include <stack>
#include <climits>
#include <unordered_map>
#include <map>
#include <set>
using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

struct S
{
	int g, val;
} a[5002];

int n, G, dp[5002][10002]; /// dp[i][j] = val maxima care se poate obtine din primele i obiecte de greutate totala j

int main()
{
	int i, j;
	fin >> n >> G;
	for (i = 1; i <= n; i++)
		fin >> a[i].g >> a[i].val;
	dp[1][a[1].g] = a[1].val;
	for (i = 2; i <= n; i++)
		for (j = 0; j <= G; j++)
		{
			/// nu il pun
			dp[i][j] = dp[i - 1][j];
			/// il pun
			if(j >= a[i].g) dp[i][j] = max(dp[i][j], a[i].val + dp[i - 1][j - a[i].g]);
		}
	int ans = -1;
	for (j = 0; j <= G; j++)
		ans = max(ans, dp[n][j]);
	fout << ans;
	return 0;
}