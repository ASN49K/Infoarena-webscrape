/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
long long dp[5001][10001];;
int main()
{
    ifstream f("rucsac.in");
    ofstream g("rucsac.out");
    int n,gmax;
    f>>n>>gmax;
    vector<long long> v(n), p(n);
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=2; j++)
        {
            f>>v[i]>>p[i];
        }
    }
    
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=gmax; j++)
        {
            if(v[i]>j)
            {
                dp[i][j]=dp[i-1][j];
            }
            else
            {
                dp[i][j]=max(dp[i-1][j-v[i]]+p[i], dp[i-1][j]);
            }
        }
    }
    
    g<<dp[n][gmax];

    return 0;
}