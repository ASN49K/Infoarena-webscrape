#include <fstream>
#include <algorithm>

using namespace std;

ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

int main()
{
    int n, gmax, s[10005] = {}, w, p, val = 0;

    cin >> n >> gmax;
    
    for (int i = 1; i <= n; ++i)
    {
        cin >> w >> p;
        for (int j = gmax - w; j >= 0; --j)
            if (s[j] || j == 0)
                if (s[j] + p > s[j + w])
                    s[j + w] = s[j] + p;
    }

    for (int j = 1; j <= gmax; ++j)
        val = max(val, s[j]);
    
    cout << val;

    return 0;
}
