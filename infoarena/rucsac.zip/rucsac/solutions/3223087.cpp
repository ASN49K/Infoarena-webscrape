#include <iostream>
#include <fstream>

using namespace std;
ifstream in("rucsac.in");
ofstream out("rucsac.out");

const int gmax = 10001;
const int nmax = 5001;
int dp[nmax],pr[nmax], gr[nmax];

int main()
{
    int n,G;
    in>>n>>G;
    for(int i = 1; i <= n; i++)
        in>>gr[i]>>pr[i];
    for(int i = 1; i <= n ; i++)
    {
        for(int j = G; j >= 0; j--)
            if(dp[j] + pr[i] >= dp[j + gr[i]] && j + gr[i] <= G)
                dp[j + gr[i]] = dp[j] + pr[i];
    }
    int maxig = 0;
    for(int i = G; i >= 1; i--)
        maxig = max(maxig, dp[i]);
    out<<maxig;
    return 0;
}
