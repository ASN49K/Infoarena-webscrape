#include <bits/stdc++.h>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
#define cin fin
#define cout fout
int n, G;
struct val{
    int g, p;
} v[5005];
/*int maxp[5005][10005];
int dp (int k, int g){
    if (k == n) return 0;
    if (maxp[k][g] == -1){
        maxp[k][g] = dp(k + 1, g);
        if (g + v[k].g <= G){
            maxp[k][g] = max(maxp[k][g], v[k].p + dp(k + 1, g + v[k].g));
        }
    } return maxp[k][g];
}*/
int dp[10005];
int main(){
    cin >> n >> G;
    for (int i = 0; i < n; ++i){
        cin >> v[i].g >> v[i].p;
    }
    for (int i = 0; i < n; ++ i){
        for (int j = G; j >= 1; j -= 1){
            if (dp[j] != 0 && j + v[i].g <= G){
                dp[j + v[i].g] = max(dp[j + v[i].g], dp[j] + v[i].p);
            }
        }
        dp[v[i].g] = max(dp[v[i].g], v[i].p);
    }

    int max1 = -22;
    for (int i = 1; i <= G; ++ i){
        max1 = max(max1, dp[i]);
        //cout << dp[i] << ' ';
    }
    cout << max1 << '\n';
    /*memset(maxp, -1, sizeof(maxp));
    cout << dp(0, 0) << endl;*/
    return 0;
}