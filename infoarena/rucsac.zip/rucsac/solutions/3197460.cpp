#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

struct taska {
	int suly, ertek;
};

int dp[5010][10010];

int main() {
	int n, g;
	fin >> n >> g;  
	vector<taska> v(n+1);
	for(int i=1; i<=n; i++) {
		fin >> v[i].suly >> v[i].ertek;
	}
	
	for(int i=1; i<=n; i++) {
		for(int j=g; j>=1; j--) {
			dp[i][j]=dp[i-1][j];
		}
		for(int j=1; j<=g; j++) {
			if(dp[i-1][j]!=0) {
				if(j+v[i].suly<=g) {
					dp[i][j+v[i].suly]=max(dp[i][j+v[i].suly], dp[i-1][j]+v[i].ertek);
				}
			}
			if(dp[i][v[i].suly]<v[i].ertek) {
				dp[i][v[i].suly]=v[i].ertek;
			}
		}
	}
	int maxi=-1;
	for(int j=1; j<=g; j++) {
		maxi=max(maxi, dp[n][j]);
	}
	fout << maxi;
  	return 0;
}