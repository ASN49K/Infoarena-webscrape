#include <bits/stdc++.h>

using namespace std;
ifstream fin("rucsac.in");
ofstream fou("rucsac.out");

int main() {
    int n, W;
    fin>>n>>W;
    vector<int>p(n + 1, 0);
    vector<int>w(n + 1, 0);
    vector<vector<int>>dp(n + 1, vector<int>(W + 1, 0));
    for (int i = 1; i <= n; i++) {
        fin>>w[i]>>p[i];
    }
    for (int k = 0; k <= W; k++) {
        dp[0][k] = 0;
    }
    for (int i = 1; i <= n; i++) {
        for (int k = 0; k <= W; k++) {
            if (w[i] <= k) {
                dp[i][k] = dp[i - 1][k - w[i]] + p[i];
            }
            dp[i][k] = max(dp[i][k], dp[i - 1][k]);
        }
    }
    fout<<dp[n][W];
    return 0;
}