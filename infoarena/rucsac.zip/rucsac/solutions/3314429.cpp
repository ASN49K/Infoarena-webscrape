#include <bits/stdc++.h>
using namespace std;
struct Cows
{
    int w, p;
}v[5005];
int dp[10005];
signed main()
{
    ifstream cin("rucsac.in");
    ofstream cout("rucsac.out");
    int n, g;
    cin>>n>>g;
    for(int i=1; i<=n; i++)
    {
        cin>>v[i].w>>v[i].p;
        //dp[v[i].w]=max(dp[v[i].w], v[i].p);
    }
    for(int i=1; i<=n; i++)
    {
        for(int j=g; j>0; j--)
        {
            if(j>=v[i].w)
                dp[j]=max(dp[j], dp[j-v[i].w]+v[i].p);
        }
    }
    cout<<dp[g];
    return 0;
}
