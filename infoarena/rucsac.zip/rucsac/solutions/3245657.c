#include <stdio.h>

enum { NMAX = 5000, GMAX = 10000 };

int maxprof[GMAX + 1];
int gr[NMAX], prof[NMAX];

int main() {
  FILE *fin, *fout;
  int n, g, i, j, rasp;

  fin = fopen("rucsac.in", "r");
  fscanf(fin, "%d%d", &n, &g);
  for (i = 0; i < n; i++) {
    fscanf(fin, "%d%d", &gr[i], &prof[i]);
  }
  fclose(fin);

  rasp = -1;
  for (i = 0; i < n; i++) {
    for (j = g; j >= gr[i]; j--) {
      if (maxprof[j - gr[i]] + prof[i] > maxprof[j])
        maxprof[j] = maxprof[j - gr[i]] + prof[i];
      if (maxprof[j] > rasp)
        rasp = maxprof[j];
    }
  }

  fout = fopen("rucsac.out", "w");
  fprintf(fout, "%d\n", rasp);
  fclose(fout);

  return 0;
}
