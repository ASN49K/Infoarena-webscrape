#include <fstream>
#include <vector>

using namespace std;

///parking
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

const int MAXG = 1e4 + 5;
int dp[MAXG]; ///profitul maxim obtinut pentru i

int main()
{
    int n, g, i, j;

    fin >> n >> g;
    vector <int> w(n + 1), p(n + 1);
    for(i = 1; i <= n; i++)
        fin >> w[i] >> p[i];

    for(i = 1; i <= n; i++)
        for(j = g; j >= w[i]; j--)
            if(dp[j - w[i]] + p[i] > dp[j])
                dp[j] = dp[j - w[i]] + p[i];

    fout << dp[g] << '\n';


    return 0;
}






