#include <iostream>
#include <fstream>
#include <algorithm>
#include <utility>
#include <vector>
#include <array>
#include <climits>
#include <cmath>
#include <iomanip>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int dp[4000001];
int main(){
    int w[2000001];
    int p[2000001];
    int n,W;
    fin>>n;
    fin>>W;
    for(int i=1;i<=n;i++){
        fin>>w[i];
        fin>>p[i];
    }

    for(int i=1;i<=n;i++){
        for(int j=W-w[i];j>=0;j--){
            dp[j+w[i]]=max(dp[j+w[i]],dp[j]+p[i]);
        }
    }

    int max=0;
    for (int i = 0; i <=W+1; i++) {
        if(max<dp[i])
            max = dp[i];
    }
    cout<<max;
    fout<<max;
    return 0;
}