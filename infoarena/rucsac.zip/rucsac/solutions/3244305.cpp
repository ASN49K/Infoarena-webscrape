#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

long long int dp[2][10005], w[5005],p[5005];

int main()
{
    int n, Gmax;
    fin>>n>>Gmax;

    for(int i=1;i<=n;i++){
        fin>>w[i]>>p[i];
    }

    for(int i=1;i<=n;i++){
        int lin_cur=i%2;
        int lin_ant=1-lin_cur;

        for(int j=w[i]; j<=Gmax; j++)
            dp[lin_cur][j]=max( dp[lin_ant][j], dp[lin_ant][j-w[i]] + p[i] );
    }

    fout<<dp[n%2][Gmax];

       return 0;
}
