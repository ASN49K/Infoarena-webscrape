#include <fstream>

using namespace std;

ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

int n, g;
struct tip{int greutate, pret;}v[5005];
int dp[10005];

int main()
{
    cin >> n >> g;
    for(int i = 1; i <= n; i++)
        cin >> v[i].greutate >> v[i].pret;
    for(int i = v[1].greutate; i <= g; i++)
        dp[i] = v[i].pret;
    for(int i = 2; i <= n; i++)
    {
        for(int j = g; j >= 1; j--)
        {
            dp[j] = max(dp[j], (dp[j - v[i].greutate] + v[i].pret) * (v[i].greutate <= j));
        }
    }
    cout << dp[g] << '\n';
    return 0;
}
