#include <fstream>

using namespace std;

ifstream in("rucsac.in");
ofstream out("rucsac.out");
int n, g, ans;
pair<int, int> v[5005];
int dp[10005];

int main()
{
    in>>n>>g;

    for(int i = 1; i<=n; i++)
    {
        in>>v[i].first>>v[i].second;
    }

    for(int i = 1; i<=n; i++)
    {
        for(int j = g; j>=0; j--)
        {
            if((j == 0 || dp[j] > 0) && j + v[i].first <= g)
            {
                dp[j + v[i].first] = max(dp[j + v[i].first], dp[j] + v[i].second);

                ans = max(ans, dp[j + v[i].first]);
            }
        }
    }

    out<<ans;

    return 0;
}
