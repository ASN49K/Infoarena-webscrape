#include <bits/stdc++.h>
std::ifstream cin("rucsac.in");
std::ofstream cout("rucsac.out");
int n,max,sum[5010][210],ans,calc[10010];
struct fractii{int g,v;}a[5010];
void bkt(int poz,int sumg,int sumv)
{
    ans=std::max(ans,sumv);
    if(poz>n)
        return;
    if(sumg+a[poz].g<=max&&sumv+sum[poz][(max-sumg)/50+1]>ans)
        bkt(poz+1,sumg+a[poz].g,sumv+a[poz].v);
    if(sumv+sum[poz+1][(max-sumg)/50+1]>ans)
        bkt(poz+1,sumg,sumv);
}
int main()
{
    cin>>n>>max;
    for(int i=1;i<=n;++i)
    {
        cin>>a[i].g>>a[i].v;
    }
    for(int i=1;i<=n;++i)
        for(int j=1;j<n;++j)
            if(a[j].v*a[j+1].g<a[j+1].v*a[j].g)
                std::swap(a[j],a[j+1]);
    for(int i=1;i<=n;++i)
    {
        int ga=0,poz=i,gl=0;
        for(int j=1;j<=max/50*50+50;++j)
        {
            if(poz>n)
                break;
            ++gl;
            calc[j]=calc[j-gl]+a[poz].v*gl/a[poz].g;
            if(gl==a[poz].g)
            {
                gl=0;
                ++poz;
            }
        }
        if(i==1)
            ans=calc[max-gl];
        for(int j=1;j<=max/50+1;++j)
            sum[i][j]=calc[j*50];
    }
    /*std::cout<<ans<<'\n';
    for(int i=1;i<=n;++i)
        std::cout<<sum[i]<<' ';*/
    bkt(1,0,0);
    cout<<ans;
    return 0;
}
