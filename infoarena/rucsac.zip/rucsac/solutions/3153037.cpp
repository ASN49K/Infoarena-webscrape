#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

struct obiect {
    int greutate;
    int valoare;
};

int dp[10000] = {0};
int main() {
    int n, g;
    fin >> n >> g;

    obiect o[5000];

    for (int i = 0; i < n; i++) {
        fin >> o[i].greutate >> o[i].valoare;
    }

    

    for (int i = 0; i < n; i++) {
        int w = o[i].greutate;
        int p = o[i].valoare;

        for (int j = g; j >= w; j--) {

            dp[j] = max(dp[j], dp[j - w] + p);
        }
    }

    fout << dp[g] << endl;

    return 0;
}
