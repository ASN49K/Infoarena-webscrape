#include <fstream>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
long long n, gm, g[50001], v[50001], i, j, maxim, a[50001];
int main(){
    fin>>n>>gm;
    for(i=1; i<=n; i++)
        fin>>g[i]>>v[i];
    for(i=1; i<=n ;i++)
    for(j=gm-g[i]; j>=0; j--){
        if(a[j+g[i]] < a[j]+v[i]) a[j+g[i]] = a[j]+v[i];
        if(a[j+g[i]] > maxim) maxim = a[j+g[i]];
    }
    fout<<maxim;
}