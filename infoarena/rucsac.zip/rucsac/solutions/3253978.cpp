#include <bits/stdc++.h>
using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int v[1<<17], p[1<<17];
int dp[1002];

int main()
{
    int n, G;
    fin >> n >> G;
    for(int i = 1; i <= n; ++i) {
        fin >> v[i] >> p[i];
    }

    for(int i = 0; i <= G; ++i) {
        dp[i] = 0;
    }

    for(int i = 1; i <= n; ++i) {
        for(int j = G; j >= v[i]; --j) {
                dp[j] = max(dp[j], dp[j - v[i]] + p[i]);
            }
        }

    int maxp = 0;
    for(int i = 0; i <= G; i++)
        if(maxp < dp[i])
            maxp = dp[i];
    fout << maxp;
    return 0;
}
