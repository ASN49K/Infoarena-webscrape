#include <fstream>

using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
int n,G,sol;
int g[10002],p[10002];
int l,dp[3][10002];
int main()
{
    /**
    dp[i][g]=profitul maxim pe care il putem obtine luand o submultime din primele i elemente cu greutatate g
    dp[i][g]={ - 0   i=0 sau g=0
             { -max(dp[i-1][g],d[i-1][g-Gi]+p[i]
            ori nu adaugam elementul i si dp[i][g]=dp[i-1][g]
            ori adaugam elementul i dp[i][g]=d[i-1][g-Gi]+p[i]
            Gi=greutatea elementului i si p[i]=profitul elementului i

    observam ca noi calculam cu ajutorul liniei precedente =>avem nevoie doar de doua linii

    **/
    cin>>n>>G;
    for(int i=1;i<=n;i++)
        cin>>g[i]>>p[i];
    l=0;
    for(int i=1;i<=n;i++,l=1-l)
    {
        for(int j=0;j<=G;j++)
        {
            dp[1-l][j]=dp[l][j];
            if(0<=j-g[i])
               dp[1-l][j]=max(dp[1-l][j],dp[l][j-g[i]]+p[i]);
        }


    }
    cout<<dp[l][G];
    return 0;
}
