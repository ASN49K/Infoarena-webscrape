#include <iostream>
using namespace std;
struct obiecte {
	int w;
	int p;
};
int main()
{
	int n, g;
	int v[10000]={0};
	cin >> n >> g;
	obiecte ob[5000];
	for (int i = 0; i < n; i++) {
		cin >> ob[i].w >> ob[i].p;
	}
	for (int i = 0; i < n; i++) {
		int w = ob[i].w;
		int p = ob[i].p;
		for (int j = g; j >= w; j--) {
			v[j] = max(v[j], v[j - w] + p);
		}
	}
	cout << v[g];
}
