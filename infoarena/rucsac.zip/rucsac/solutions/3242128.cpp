#include <bits/stdc++.h>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
vector<int> dp;
int main(){
    int n, g;
    fin>>n>>g;
    dp.resize(g+1);
    vector<pair<int,int> > obiecte(n+1);
    for(int i=1;i<=n;i++){
        fin>>obiecte[i].first>>obiecte[i].second;
    }
    for(int i=1;i<=n;i++){
        for(int j=g-obiecte[i].first;j>=0;j--){
            if(dp[j+obiecte[i].first]<dp[j]+obiecte[i].second){
                dp[j+obiecte[i].first]=dp[j]+obiecte[i].second;
            }
        }
    }
    fout<<dp[g];
}
