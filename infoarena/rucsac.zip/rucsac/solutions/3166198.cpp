/// met 1: dinamica pe 2 dimensiuni memorie n*g

#include <fstream>

using namespace std;

ifstream cin("rucsac.in");
ofstream cout("rucsac.out");

int n, GMax, v[5002], w[5002], dp[5002][10002];

int main()
{
    cin >> n >> GMax;
    for (int i = 1; i <= n; i++)
        cin >> w[i] >> v[i];

    for (int i = 1; i <= n; i++) {
        for (int g = 0; g <= GMax; g++) {
            dp[i][g] = dp[i-1][g];
            if (w[i] <= g) {
                dp[i][g] = max(dp[i][g], dp[i-1][g-w[i]]+v[i]);
            }
        }
    }

    cout << dp[n][GMax];

    return 0;
}
