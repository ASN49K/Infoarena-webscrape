#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
int main(){
    ifstream cin("rucsac.in");
    ofstream cout("rucsac.out");
    int n, g;
    cin>>n>>g;
    vector <pair<int,int>>a(n);
    for(int i=0; i<n; i++){
        cin>>a[i].first>>a[i].second;
    }
    vector <int> b(g+1, -1);
    for(int i=0; i<n; i++){
        for(int j=g; j>=0; j--){
            if(b[j]!=-1){
                if(j+a[i].first<=g){
                    b[j+a[i].first]=max(b[j], a[i].second+b[j]);
                }
            }
            if(j==a[i].first&&b[j]==-1){
                b[j]=a[i].second;
            }
        }
    }
    int m=b[0];
    for(int i=1; i<=g; i++){
        m=max(m, b[i]);
    }
    cout<<m;
    cin.close();
    cout.close();
    return 0;
}
