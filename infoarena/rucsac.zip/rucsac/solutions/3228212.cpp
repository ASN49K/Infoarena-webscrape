#include <bits/stdc++.h>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
long long n, G, gr[5001], val[5001], dp[10001];
int main()
{
    fin>>n>>G;
    for(int i = 1; i <= n; i++)
        cin>>gr[i]>>val[i];

    long long Pmax = 0; //profitul maxim
    for(int i = 1; i <= n; i++)
        for(int j = G - gr[i]; j >= 0; j--)
        {
            dp[j+gr[i]] = max(dp[j+gr[i]], dp[j] + val[i]);
            Pmax = max(Pmax, dp[j+gr[i]]);
        }
    fout << Pmax;
    return 0;
}