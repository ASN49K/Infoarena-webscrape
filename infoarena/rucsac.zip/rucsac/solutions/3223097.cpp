#include <fstream>
#include<cmath>
using namespace std;
ifstream f("rucsac.in");
ofstream g("rucsac.out");
int dp[10001];
int N,G;
struct idk{
    
    int g,profit; 
};
idk ob[5001];
int main()
{
    int i,j,maxim;
    f>>N>>G;
    for(i=1;i<=N;i++)
    {
        f>>ob[i].g;
        f>>ob[i].profit;
    }
    for(i=1;i<=N;i++)
    {
        for(j=G; j>=ob[i].g; j--)
            dp[j]=max(dp[j-ob[i].g] + ob[i].profit , dp[j]);
    }
    g<<dp[G];
    f.close();
    g.close();
    return 0;
}