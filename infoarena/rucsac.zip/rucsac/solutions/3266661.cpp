#include <bits/stdc++.h>

using namespace std;

#define INFILE "rucsac.in"
#define OUTFILE "rucsac.out"

typedef long long ll;

const int N_MAX = 5000;
const int G_MAX = 10000;

int n, maxWeight;
pair<int, int> v[N_MAX + 1]; // first - weight, second - profit

ll dp[G_MAX + 1];

void solve(){

    cin >> n >> maxWeight;

    for(int i = 1; i <= n; i++){
        cin >> v[i].first >> v[i].second;
    }

    for(int i = 1; i <= n; ++i){
        for(int j = maxWeight; j >= v[i].first; --j){
            dp[j] = max(dp[j], dp[j - v[i].first] + v[i].second);
        }
    }

    cout << dp[maxWeight] << '\n';

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr), cout.tie(nullptr);
    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);
    solve();
    return 0;
}