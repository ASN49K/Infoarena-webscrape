#include <stdio.h>
#include <stdlib.h>
#define N 5000
#define K 10000

typedef struct
{
    int g, p;
} obiect;

obiect v[N];
int profit[K+1];

int max(int x, int y)
{
    return (x > y ? x : y);
}

int main()
{
    FILE *in, *out;
    in = fopen("rucsac.in", "r");
    out = fopen("rucsac.out", "w");
    int n, k;
    fscanf(in, "%d%d", &n, &k);
    ///initializare profit
    profit[0] = 0;
    for (int j = 1; j <= k; j++)
    {
        profit[j] = -1;
    }
    for (int i = 0; i < n; i++)
    {
        fscanf(in, "%d%d", &v[i].g, &v[i].p);
        for (int j = k - v[i].g; j >= 0; j--)
        {
            if (v[j].g != -1)
            {
                profit[j+v[i].g] = max(profit[j+v[i].g], profit[j] + v[i].p);
            }
        }
    }
    ///gasim profitul maxim
    int profit_maxim = -1;
    for (int j = 1; j <= k; j++)
    {
        profit_maxim = max(profit_maxim, profit[j]);
    }
    fprintf(out, "%d\n", profit_maxim);
    fclose(in);
    fclose(out);
    return 0;
}
