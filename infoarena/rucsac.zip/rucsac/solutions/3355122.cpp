#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>

using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int main() {
    int N, G;
    fin >> N >> G;
    
    vector<int> dp(G + 1, 0);// dp[cw] va retine profitul maxim pentru greutatea cw

    for (int i = 0; i < N; ++i) {
        int weight, profit;
        fin >> weight >> profit;

        for (int cw = G; cw >= weight; --cw) {
            if (dp[cw - weight] + profit > dp[cw]) {
                dp[cw] = dp[cw - weight] + profit;
            }
        }
    }

    // Rezultatul maxim va fi valoarea maxima din vectorul dp
    int max_profit = 0;
    for (int cw = 0; cw <= G; ++cw) {
        if (dp[cw] > max_profit) {
            max_profit = dp[cw];
        }
    }

    fout << max_profit << endl;

    return 0;
}
