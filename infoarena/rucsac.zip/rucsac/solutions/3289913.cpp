#include <fstream>
#include <vector>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

typedef pair<int, int> pi;

const int NMAX = 5001;
const int GMAX = 1e4 + 1;

long long dp[2][GMAX];

int n, g, w, p;

int main()
{
    fin >> n >> g;
    for (int i = 1; i <= n; ++i)
    {
        fin >> w >> p;
        int crtIndex = i % 2;
        int antIndex = 1 - crtIndex;
        for (int j = 1; j <= g; ++j)
        {
            dp[crtIndex][j] = dp[antIndex][j];
            if (j >= w)
                dp[crtIndex][j] = max(dp[crtIndex][j], dp[antIndex][j - w] + p);
        }
    }

    fout << dp[n % 2][g] << '\n';

    return 0;
}
