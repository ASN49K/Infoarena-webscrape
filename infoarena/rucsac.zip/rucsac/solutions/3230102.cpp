#include <fstream>
#include <algorithm>
using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
struct ceva
{
    int p,g;
} elem[5001];

int dp[10001],n,lim,i;

int main()
{
    cin>>n>>lim;
    for(i=1; i<=n; i++)
        cin>>elem[i].g>>elem[i].p;
    for(i=1; i<=n; i++)
    {
        for(int curr_w=lim; curr_w>=1; curr_w--)
        {
            dp[curr_w]=dp[curr_w];
            if(elem[i].g<=curr_w)
                dp[curr_w]=max(dp[curr_w],dp[curr_w-elem[i].g]+elem[i].p);
        }
    }
    cout<<dp[lim];
    return 0;
}
