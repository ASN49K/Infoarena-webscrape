#include <iostream>
#include <fstream>
using namespace std;
ifstream in("rucsac.in");
ofstream out("rucsac.out");
int a[1000][2], dp[1000][1000],n,dim;
int main()
{
    cin>>n>>dim;
    for(int i=1;i<=n;i++){
        cin>>a[i][1]>>a[i][2];
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=dim+1;j++){
            if(a[i][1]<j){
                dp[i][j]=max(dp[i-1][j],a[i][2]+dp[i-1][j-a[i][1]]);
            }
        }
    }
    /**
    for(int i=1;i<=n;i++,cout<<'\n')
        for(int j=1;j<=dim+1;j++)
            cout<<dp[i][j]<<' ';
            */
    cout<<dp[n][dim+1];
    return 0;
}
