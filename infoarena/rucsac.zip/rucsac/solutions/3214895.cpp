#include <bits/stdc++.h>

using namespace std;

ifstream f ("rucsac.in");
ofstream g ("rucsac.out");

int n,gg;
int gr[10005];
int val[10005];
int dp[2][100005];

int main()
{
    f>>n>>gg;
    for(int i=1;i<=n;++i)
        f>>gr[i]>>val[i];

    for(int i=0;i<=2;++i)
        for(int j=0;j<=gg;++j)
            dp[i][j]=-1;

    dp[0][0]=0;
    for(int i=1;i<=n;++i)
    {
        for(int j=0;j<gr[i];++j)
            dp[1][j]=dp[0][j];

        for(int j=gr[i];j<=gg;++j)
        {
            if(dp[0][j]!=-1)
                dp[1][j]=dp[0][j];
            if(dp[0][j-gr[i]]!=-1)
                dp[1][j]=max(dp[1][j], dp[0][j-gr[i]]+val[i]);
        }
        for(int j=0;j<=gg;++j)
        {
            dp[0][j]=dp[1][j];
            dp[1][j]=-1;
        }
    }
    int maxim=-1;
    for(int i=0;i<=gg;++i)
        maxim=max(maxim, dp[0][i]);

    g<<maxim;

    return 0;
}
