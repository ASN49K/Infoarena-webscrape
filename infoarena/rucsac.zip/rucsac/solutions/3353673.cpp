#include <bits/stdc++.h>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int N, G, g[5001], p[5001];
int dp[2][10001];

int main()
{
    int i, j, linie, maxim = -1;
    fin >> N >> G;
    for (i = 1 ; i <= N ; i++)
        fin >> g[i] >> p[i];
    linie = 1;
    dp[0][g[1]] = p[1];
    for (i = 2 ; i <= N ; i++)
    {
        for (j = 1 ; j <= G ; j++)
        {
            if (g[i] <= j)
                dp[linie][j] = max(dp[1 - linie][j], dp[1 - linie][j - g[i]] + p[i]);
            else
                dp[linie][j] = dp[1 - linie][j];
        }
        linie = 1 - linie;
    }
        for (j = 1 ; j <= G ; j++)
            maxim = max(maxim, dp[1 - linie][j]);
    fout << maxim;
    return 0;
}
