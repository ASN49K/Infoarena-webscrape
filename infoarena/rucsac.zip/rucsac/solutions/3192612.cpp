#include<bits/stdc++.h>
using namespace std;
ifstream f("rucsac.in");
ofstream g("rucsac.out");
int n,G,ans;
vector<int>weight,profit,dp;
int main()
{
    f>>n>>G;
    dp.assign(G+1,-1);
    weight.resize(n+1);
    profit.resize(n+1);
    for(int i=1; i<=n; i++)
        f>>weight[i]>>profit[i];
    dp[0]=0;
    for(int i=1; i<=n; i++)
        for(int j=G-weight[i]; j>=0; j--)
            if(dp[j]!=-1 && dp[j+weight[i]]<dp[j]+profit[i])
                dp[j+weight[i]]=dp[j]+profit[i];
    for(int i=1; i<=G; i++)
        ans=max(ans,dp[i]);
    g<<ans;
    return 0;
}
