#include <fstream>

using namespace std;

ifstream in("rucsac.in");
ofstream out("rucsac.out");
int n, g, ans;
pair<int, int> v[5005];
int dp[10005];

int main()
{
    in>>n>>g;

    for(int i = 1; i<=n; i++)
    {
        in>>v[i].first>>v[i].second;
    }

    for(int i = 0; i<=g; i++)
    {
        dp[i] = -1;
    }

    dp[0] = 0;
    for(int i = 1; i<=n; i++)
    {
        for(int j = g - v[i].first; j>=0; j--)
        {
            if(dp[j] >= 0)
            {
                dp[j + v[i].first] = max(dp[j + v[i].first], dp[j] + v[i].second);

                ans = max(ans, dp[j + v[i].first]);
            }
        }
    }

    out<<ans;

    return 0;
}
