#include <fstream>
using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
int d[2][10005];
pair<int, int> v[5005];
void cutVec()
{
    for(int i = 0; i < 10005; i++)
    {
        d[0][i] = d[1][i];
        d[1][i] = 0;
    }
}
int main()
{
    int n, g;
    cin >> n >> g;
    for(int i = 1; i <= n; i++)
    {
        cin >> v[i].first >> v[i].second;
    }
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= g; j++)
        {
            if(j - v[i].first >= 0)
            {
                d[1][j] = max(d[0][j], d[0][j - v[i].first] + v[i].second);
            }
            else
            {
                d[1][j] = d[0][j];
            }
        }
        cutVec();
    }
    cout << d[0][g];
}