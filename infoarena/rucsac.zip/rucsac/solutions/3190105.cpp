#include <fstream>

using namespace std;
ifstream cin ("rucsac.in");
ofstream cout ("rucsac.out");

int n,g,i,j,a[10005],b[10005],dp[10005][10005];

int main()
{
    cin>>n>>g;
    for(i=1;i<=n;i++)
        cin>>a[i]>>b[i];
    for(i=1;i<=n;i++)
        for(j=1;j<=g;j++)
            {
                if(a[i]>j)
                    dp[i][j]=dp[i-1][j];
                else
                    dp[i][j]=max(dp[i-1][j],dp[i-1][j-a[i]]+b[i]);
            }
    cout<<dp[n][g];
    return 0;
}
