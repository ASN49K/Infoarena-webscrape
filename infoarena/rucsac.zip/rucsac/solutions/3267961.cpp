#include <bits/stdc++.h>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
int dp[10005], n, G;

int main()
{
    int i, g, p, j;
    fin >> n >> G;
    for(i = 1; i <= n; i++)
    {
        fin >> g >> p;
        for(j = G; j >= g; j--)
            dp[j] = max(dp[j], dp[j - g] + p);
    }
    fout << dp[G];
    return 0;
}
