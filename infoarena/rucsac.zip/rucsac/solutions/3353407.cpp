#include <vector>
#include <iostream>
#include <stack>
#include <algorithm>
#include <queue>
#include <fstream>
#include <iomanip>
#include <map>
#include <cmath>
#include <set>
#include <string>
using namespace std;

ifstream in("rucsac.in");
ofstream out("rucsac.out");
int test, n, g, dp[100005], w, v, ans;

void solve()
{
    in >> n >> g;

    ans = 0;
    for (int i = 1; i <= n; i ++)
    {
        in >> w >> v;

        for (int j = g; j >= w; j --)
        {
            dp[j] = max (dp[j], dp[j - w] + v);
            ans = max (ans, dp[j]);
        }
    }

    out << ans;
}

int main()
{
    //ios::sync_with_stdio(false);
    //cin.tie(NULL);
    //cout.tie(NULL);

    //cin >> test;
    //for (int i = 1; i <= test; i++)
    solve();
    return 0;
}