#include<fstream>
using namespace std;
ifstream cin("rucsac.in");
ofstream cout("rucsac.out");
int a[10001];
int main()
{
    int n,m;
    for(cin>>n>>m;n--;) {
        int i,j;
        cin>>i>>j;
        for(int k=m;k>=i;a[k]=max(a[k],j+a[k-i]),--k);
    }
    return cout<<a[m],0;
}
