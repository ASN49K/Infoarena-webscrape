#include <fstream>

using namespace std;
ifstream cin ("rucsac.in");
ofstream cout ("rucsac.out");

int n,g,i,j,a[10005],b[10005],dp[10005];

int main()
{
    cin>>n>>g;
    for(i=1;i<=n;i++)
        cin>>a[i]>>b[i];
    for(i=1;i<=n;i++)
        for(j=g;j>=a[i];j--)
            dp[j]=max(dp[j],dp[j-a[i]]+b[i]);
    cout<<dp[g];
    return 0;
}
