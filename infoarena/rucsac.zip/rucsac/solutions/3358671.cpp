#include <fstream>
#include <vector>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int main(){
    int n,g,w,p;
    fin>>n>>g;
    vector<int> D(g+1,0);
    for(int i=1;i<=n;i++){
        fin>>w>>p;
        for(int j=g;j>=w;j--){
            D[j] = max(D[j],D[j-w]+p);
        }
    }
    fout<<D[g]<< '\n';

    fin.close();
    fout.close();
    return 0;
}