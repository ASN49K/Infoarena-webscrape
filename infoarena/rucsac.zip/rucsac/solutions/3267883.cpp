#include <iostream>
#include <fstream>
using namespace std;

struct
{
    float gr, val, ef;
    bool luat = 0;
} ob[5001];

int main()
{
    ifstream in("rucsac.in");
    ofstream out("rucsac.out");

    int Gmax, n, poz = 0, nr_luate = 0, Vmax = 0;
    float efmax, S = 0;
    in >> n >> Gmax;
    for (int i = 1; i <= n; i++)
    {
        in >> ob[i].gr;
        in >> ob[i].val;
        ob[i].ef = ob[i].val / ob[i].gr;
        if (ob[i].val > Vmax) Vmax = ob[i].val;
    }
    while (Gmax > 0 && nr_luate < n)
    {
        efmax = 0;
        for (int i = 1; i <= n; i++)
        {
            if (ob[i].val >= efmax && ob[i].luat == 0 && ob[i].gr <= Gmax)
            {
                efmax = ob[i].val;
                poz = i;
            }
        }
        nr_luate++;
        {
            S += ob[poz].val;
            Gmax -= ob[poz].gr;
            ob[poz].luat = 1;
        }
    }
    if (Gmax < 0)
    {
        S -= ob[poz].val;
    }
    out << S;
    return 0;
}