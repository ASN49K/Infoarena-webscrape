#include<fstream>
std::ifstream fin("rucsac.in");
std::ofstream fout("rucsac.out");
int n, gmax;
int line[10001];
struct object{
    int weight;
    int value;
};
void createLine(object local)
{
    for(int index=gmax; index>0; --index)
        if(index>=local.weight)
            line[index]=std::max(line[index], line[index-local.weight]+local.value);
}
void solve()
{
    fin>>n>>gmax;
    object local;
    for(int index=0; index<n; ++index)
    {
        fin>>local.weight>>local.value;
        createLine(local);
    }
    fout<<line[gmax];
}
int main()
{
    solve();
    fin.close();
    fout.close();
    return 0;
}