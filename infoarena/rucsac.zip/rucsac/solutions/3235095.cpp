#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");
struct obiect{
    int g, v;
}v[5005];

int dp[10005][10005];
int main()
{
    int n, Gmax;
    fin>>n>>Gmax;

    for(int i=1;i<=n;i++)
        fin>>v[i].g>>v[i].v;
    dp[1][1]=1;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=Gmax; j++){

            if(j-v[i].g >= 0)
                dp[i][j] = max(dp[i-1][j-v[i].g] + v[i].v, dp[i-1][j]);
            else
                dp[i][j] = dp[i-1][j];
        }
    fout<<dp[n][Gmax];
    return 0;
}
