#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>


std::ifstream fin("rucsac.in");
std::ofstream fout("rucsac.out");

int main(void) {

	std::ios::sync_with_stdio(false);

	int N = 0;
	int G = 0;
	fin >> N >> G;
	std::vector<std::pair<int, int>> objects(N + 1);
	for (int i = 1; i <= N; i++) {
		fin >> objects[i].first >> objects[i].second;
	}

	std::vector<int> prev(G + 1, 0);
	std::vector<int> curr(G + 1);

	for (int i = 1; i <= N; i++) {
		for (int j = 0; j <= G; j++) {
			curr[j] = prev[j];
			if (j >= objects[i].first) {
				curr[j] = std::max(prev[j], prev[j - objects[i].first] + objects[i].second);
			}
		}
		for (int j = 0; j <= G; j++) {
			prev[j] = curr[j];
		}
	}
	fout << curr[G] << '\n';
}