#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("rucsac.in");
ofstream fout ("rucsac.out");
int v[5001];
int w[5001];
int dp[5001];
int n,k;
int main()
{
    cout<<1;
    fin>>n>>k;
    for(int i=1;i<=n;i++){
        fin>>w[i]>>v[i];
    }
    for(int i = 1;i<=n;i++){
        for(int j = k;j>=w[i];j++){
            dp[j] = max(dp[j], dp[j-w[i]]+v[i]);
        }
    }
    int vmax = -1;
    for(int i=1;i<=n;i++){
        vmax = max(vmax, dp[i]);
    }
    fout<<vmax;
    return 0;
}
