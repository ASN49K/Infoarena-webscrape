#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

int w[5001], p[5001];
int dp[2][10001];

int main()
{
    int n, g;
    fin>>n>>g;

    for(int i = 1; i <= n; i++){
        fin>>w[i]>>p[i];
    }

    for(int i = 1; i <= n; i++){
        int lin_cur = i % 2;
        int lin_ant = 1 - lin_cur;
        for(int j = w[i]; j <= g; j++){
            if(j < w[i]){
                dp[lin_cur][j] = dp[lin_ant][j];
            }
            else{
                dp[lin_cur][j] = max(dp[lin_ant][j], dp[lin_ant][j - w[i]] + p[i]);
            }
        }
    }

    int maxx = 0;

    for(int j = 0; j <= g; j++){
        maxx = max(dp[n % 2][j], maxx);
    }

    fout<<maxx;

    return 0;
}
