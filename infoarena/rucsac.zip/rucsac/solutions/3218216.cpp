#include <cstdio>
#include <algorithm>

using namespace std;

#define MAXN 5010
#define MAXG 10010

int N, G, Pmax;
int W[MAXN], P[MAXN];
int D[2][MAXG];

int main()
{
    freopen("rucsac.in", "r", stdin);
    freopen("rucsac.out", "w", stdout);

    // Citire
    scanf("%d%d", &N, &G);
    for(int i = 1; i <= N; ++i)
        scanf("%d%d", &W[i], &P[i]);

    // Dinamica D[i][cw] - profitul maxim pe care-l putem obtine adaugand o submultime a primelor i obiecte, insumand greutatea cw
    // Din aceasta dinamica vom tine ultimele doua linii, astfel: linia l va fi cea pe care avem solutia pentru al (i-1)-lea element,
    // in timp ce  pe linia 1-l vom construi solutia pentru elementul i.
    int l=0;
    for(int i = 1; i <= N; ++i, l = 1 - l)
        for(int cw = 0; cw <= G; ++cw)
        {
            // Mai intai nu punem obiectul i.
            D[1-l][cw] = D[l][cw];

            // Daca acest lucru duce la o solutie curenta mai buna, adaugam obiectul i la o solutie anterioara.
            if(W[i] <= cw)
                D[1-l][cw] = max(D[1-l][cw], D[l][cw - W[i]] + P[i]);
        }

    // Solutia se va afla in statea D[N][G], adica pe linia l, la coloana G
    Pmax = D[l][G];

    // Afisare
    printf("%d\n", Pmax);

    return 0;
}
