#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

const int LMAX = 10005;
const int NMAX = 5005;
int weight[NMAX], profit[NMAX];
//dp[i] profitul maxim cand in rucsam este greutatea i

int main() {
    int n, g, i, j;
    fin>>n>>g;
    for (i = 1; i <= n; i++) {
        fin>>weight[i]>>profit[i];
    }
    vector<int> dp(g+1, -1);
    dp[0] = 0;
    for (i = 1; i <= n; i++) {
        for (j = g - weight[i]; j >= 0; j--) {
            if (dp[j] != -1)
                dp[j + weight[i]] = max(dp[j + weight[i]], dp[j] + profit[i]);
        }
    }
    int ans = -1;
    for (i = 1; i <= g; i++) {
        ans = max(ans, dp[i]);
    }
    fout<<ans;

    fin.close();
    fout.close();
    return 0;
}
