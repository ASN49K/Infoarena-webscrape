#include <bits/stdc++.h>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

const int NMAX = 5001;
const int GMAX = 10001;

int N, G;
int P[NMAX];
int W[NMAX];
//int DP[NMAX][GMAX]; /// DP[i][j] = profitul maxim pt un rucsac de greutate j, luand in calcul primele i greutati
/// DP[i][j] = max{DP[i-1][j], DP[i-1][j - W[i]] + P[i]
///                 ^we don't take the ith object
///                                  ^we take it

int DP[2][GMAX];

int main()
{
    fin >> N >> G;
    for(int i = 1; i <= N; i++) {
        fin >> W[i] >> P[i];
    }

    for(int i = 1; i <= N; i++) {
        for(int j = 1; j <= G; j++) {
            if(j >= W[i])
                DP[1][j] = max(DP[0][j], DP[0][j - W[i]] + P[i]);
            else
                DP[1][j] = DP[0][j];
        }
        for(int j = 1; j <= G; j++) {
            DP[0][j] = DP[1][j];
        }
    }
    //    for(int i = 1; i <= N; i++) {
    //        for(int j = 1; j <= G; j++)
    //            cout << DP[i][j] << ' ';
    //        cout << '\n';
    //    }

    int rez = 0;
    for(int i = 1; i <= G; i++)
        rez = max(rez, DP[1][i]);
    fout << rez;
    return 0;
}
