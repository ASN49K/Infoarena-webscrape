#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("rucsac.in");
ofstream fout("rucsac.out");

struct
{
    int gr, pr;
} ob[5001];

int n, g, maxim, lc, la, i, j, dp[10001][10001], pmax;

int main()
{
    fin >> n >> g;

    for(i = 1; i <= n; i++)
    {
        fin >> ob[i].gr >> ob[i].pr;
    }

    dp[1][ob[1].gr] = ob[1].pr;

    for(i = 1; i <= n; i++)
    {
        /*
        cout << "pas " << i << '\n';
        for(j = 0; j <= g; j++)
        {
            cout << dp[i % 2][j] << ' ';
        }
        cout << '\n';
         for(j = 0; j <= g; j++)
        {
            cout << dp[1 - i % 2][j] << ' ';
        }*/

        lc = i % 2;
        la = 1 - lc;

        for(j = g; j >= 0; j--)
        {
            if(j >= ob[lc].gr)
                dp[lc][j] = max(dp[la][j - ob[i].gr] + ob[i].pr, dp[la][j]);
            else
                dp[lc][j] = dp[la][j];
        }
    }

    for(j = 0; j <= g; j++)
    {
        pmax = max(pmax, dp[n % 2][j]);
    }

    fout << pmax;

    return 0;
}
