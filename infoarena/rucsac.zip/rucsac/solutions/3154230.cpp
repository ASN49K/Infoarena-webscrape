#include <bits/stdc++.h>

using namespace std;

ifstream fin ("rucsac.in");
ofstream fout ("rucsac.out");

int n,G;
int w[5001],p[5001];
int dp[5001][1001];

int main()
{
    fin >> n >> G;
    for (int i=1;i<=n;i++)
        fin >> w[i] >> p[i];
    for (int i=1;i<=n;i++)
        for (int j=0;j<=G;j++)
    {
        dp[i][j]=dp[i-1][j];
        if (w[i]<=j)
        {
            dp[i][j]=max(dp[i][j],dp[i-1][j-w[i]]+p[i]);
        }
    }
    fout << dp[n][G];
    return 0;
}
