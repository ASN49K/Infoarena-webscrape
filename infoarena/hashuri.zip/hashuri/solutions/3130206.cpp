
#include <fstream>

struct i32 {
	int value = 0;
	i32* prev = nullptr;
	i32* next = nullptr;
};

void hash_aux(i32* table, int number) {
	if (table->value == number)
		return;
	if (table->value > 0) {
		if (table->next != nullptr)
			hash_aux(table->next, number);
		else {
			table->next = new i32;
			table->next->prev = table;
			table->next->value = number;
		}
	}
	else {
		table->value = number;
	}
}

constexpr int prime = 999983;

void hash(i32* table, int number) {
	hash_aux(&table[number % prime], number);
}

void del_aux(i32* table, int number, int depth = 0) {
	if (table->value != number) {
		if (table->next != nullptr)
			del_aux(table->next, number, depth + 1);
	}
	else {
		if (depth > 0) {
			table->prev->next = table->next;
			if(table->next != nullptr)
				table->next->prev = table->prev;
			delete table;
			table = nullptr;
		}
		else
			table->value = 0;
	}
}

void del(i32* table, int number) {
	del_aux(&table[number % prime], number);
}

bool find_aux(i32* table, int number) {
	if (table->value != number) {
		if (table->next != nullptr)
			return find_aux(table->next, number);
		else
			return false;
	}
	return true;
}

bool find(i32* table, int number) {
	return find_aux(&table[number % prime], number);
}

int main() {
	std::ifstream fin("hashuri.in");
	std::ofstream fout("hashuri.out");

	i32* table = new i32[10000000];

	int n;
	fin >> n;
	while (n--) {
		short x;
		fin >> x;
		int nr;
		fin >> nr;
		switch (x)
		{
		case 1:
			hash(table, nr);
			break;
		case 2:
			del(table, nr);
			break;
		case 3:
			fout << find(table, nr) << '\n';
			break;
		}
	}
	return 0;
}