#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

vector<int> hashuri[666013];
int main(){
    //ifstream fin("nr.txt");
    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");
    int op, x, nr, ok;

    fin>>nr;

    for(int i = 0; i < nr; i++){
        fin>>op>>x;
        int prim = x%666013;
        int a = hashuri[prim].size();
        ok = 0;
        for(int j = 0; j < a; j++)
            if(hashuri[prim][j] == x){
                ok = 1;
                if(op == 2)
                    hashuri[prim][j] = 0;
            }
        if(ok == 0 && op == 1){
            hashuri[prim].push_back(x);
        }


        if(op == 3)
            cout<<ok<<"\n";
    }
    fin.close();
    fout.close();
    return 0;
}
