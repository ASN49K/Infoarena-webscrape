#include<fstream>
#include<vector>
const std::string txt="hashuri";
std::ifstream cin(txt+".in");
std::ofstream cout(txt+".out");
#define mod 666013
std::vector <int> h[mod];
std::vector <int> ::iterator it;
#define pb push_back
int p;
std::vector <int> ::iterator findx(int x){
    for(it=h[p].begin();it!=h[p].end();++it)
        if(*it==x)
            return it;
    return it;
}
void addx(int x){
    if(it==h[p].end())
        h[p].pb(x);
}
void deletex(){
    if(it!=h[p].end())
        h[p].erase(it);
}
bool writex(int x){
    if(it!=h[p].end())
        return 1;
    return 0;
}
signed main(int n,int c,int x){
    cin>>n;
    while(n--){
        cin>>c>>x;
        p=x%mod;
        it=findx(x);
        if(c==1)
            addx(x);
        else if(c==2)
            deletex();
        else
            cout<<writex(x)<<'\n';
    }
}
