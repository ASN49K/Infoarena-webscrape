//ALEXANDRU MICLEA

#include <vector>
#include <algorithm>
#include <string>
#include <cstring>
#include <queue>
#include <map>
#include <set>
#include <unordered_map>
#include <time.h>
#include <iomanip>
#include <deque>
#include <math.h>
#include <cmath>
#include <assert.h>
#include <stack>
#include <bitset>
#include <random>
#include <chrono>
#include <iostream>
#include <fstream>
#include <array>

using namespace std;
ifstream fin("hashuri.in"); ofstream fout("hashuri.out");

typedef long long ll;
typedef unsigned long long ull;
typedef long double ld;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef pair<double, double> pdd;
typedef vector<ll> vll;
typedef vector<int> vi;
typedef vector<vector<int> > vvi;
typedef vector<vector<ll> > vvll;
typedef vector<vector<pll> > vvpll;
typedef vector<pll> vpll;
typedef vector<pii> vpii;
const ll MOD = 1e9 + 7;
double eps = 1e-6;
#define forn(i,e) for(ll i = 1; i <= e; i++)
#define for0n(i,e) for(ll i = 0; i < (e); i++)
#define forsn(i,s,e) for(ll i = s; i <= e; i++)
#define rforn(i,s) for(ll i = s; i >= 1; i--)
#define rfor0n(i,s) for(ll i = s; i >= 0; i--)
#define rforsn(i,s,e) for(ll i = s; i >= e; i--)
#define ln "\n"
#define dbg(x) fout<<#x<<" = "<<x<<ln
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define llinf 2e18
#define iinf 1e9
#define all(x) (x).begin(), (x).end()
#define sz(x) ((ll)(x).size())

//VARIABLES

vector<int> v[666105];
int n;

//FUNCTIONS

void insert(int val) {
    int mod = val % 666013;
    for (auto& x : v[mod]) {
        if (x == val) return;
    }
    v[mod].push_back(val);
}

void remove(int val) {
    int mod = val % 666013;
    vector <int> aux;
    for (auto& x : v[mod]) {
        if (x != val) {
            aux.push_back(x);
        }
    }

    v[mod] = aux;
}

void search(int val) {
    int mod = val % 666013;
    for (auto& x : v[mod]) {
        if (x == val) {
            fout << "1\n";
            return;
        }
    }
    fout << "0\n";
}

//MAIN
int main() {

//#ifdef INFOARENA
//    freopen("hashuri.in", "r", stdin);
//    freopen("hashuri.out", "w", stdout);
//#endif


    fin >> n;

    while (n--) {
        int c, val;
        fin >> c >> val;
        if (c == 1) insert(val);
        if (c == 2) remove(val);
        if (c == 3) search(val);
    }

    return 0;
}