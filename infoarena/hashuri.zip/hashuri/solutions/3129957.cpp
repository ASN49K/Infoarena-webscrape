#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");
vector <vector<int>> hashTable;

int returnFromHash(int x){
    int hash = x%666100;
    for(int i = 0; i< hashTable[hash].size(); i++){
        if (x==hashTable[hash][i]) return i;

    }
    return -1;
}
void insert(int x){
    if (returnFromHash(x)==-1){
        hashTable[x % 666100].push_back(x);
    }
}
void remove(int x){
    int poz =returnFromHash(x);
    if (poz!=-1){
        hashTable[x % 666100].erase(hashTable[x % 666100].begin()+poz);
    }
}
int main(){
    int n;
    in>>n;
     for(int i = 0; i <= 666100; i++){
        hashTable.push_back(vector<int>());
    }
    for(int i = 0; i<n; i++){
        int c,x;
        in>>c>>x;
        if (c==1){
            insert(x);
        }
        if(c==2){
            remove(x);
        }
        if(c==3){
            if (returnFromHash(x)==-1) out<<0<<endl;
            else out<<1<<endl;
        }
    }

}