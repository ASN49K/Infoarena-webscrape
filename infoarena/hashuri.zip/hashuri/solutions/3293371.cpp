#include <fstream>
#include <set>
using namespace std;
ifstream cin ("hashuri.in");
ofstream cout ("hashuri.out");
int main()
{
    set <int> s;
    int n;
    cin>>n;
    int c,x;
    for (int i=1;i<=n;i++)
    {
        cin>>c>>x;
        if (c==1)
        {
            s.insert(x);
        }
        if (c==2)
        {
            s.erase(x);
        }
        if (c==3)
        {
            auto it=s.find(x);
            if (*it==x)
            {
                cout<<"1"<<'\n';
            }
            else
                cout<<"0"<<'\n';
        }
    }
    return 0;
}
