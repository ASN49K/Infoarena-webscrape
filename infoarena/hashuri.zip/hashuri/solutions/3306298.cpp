#include <bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector<vector<int>>vi(1e6+10);
vector<vector<string>>vs(1e6+10);

int Hash(int x)
{
    int mod = 1e6+7;
    return x % mod;
}

int Hash(string x)
{
    int mod = 1e6 + 7;
    int rez = 0;
    for(int j=0;j<x.size();j++)
    {
        rez += ( x[j] ^ j  );
    }
    return rez % mod;
}
int main()
{
    int n;
    fin >> n;
    for(int i=1;i<=n;i++)
    {
        int op,x;
        fin >> op >> x;
        if(op==1)
        {
            vi[Hash(x)].push_back(x);
        }
        else if(op==2)
        {
                int idx = -1;
                int h = Hash(x);
                for(int i=0;i<vi[h].size();i++)
                {
                    if(vi[h][i] == x)
                    idx = i;
                }
                if(idx != -1)
                vi[h].erase(vi[h].begin() + idx);
        }
        else
        {
            int idx = -1;
                int h = Hash(x);
                for(int i=0;i<vi[h].size();i++)
                {
                    if(vi[h][i] == x)
                    idx = i;
                }

            fout << (idx != -1) <<'\n';
        }
    }
    return 0;
}
