#include <fstream>
#include <vector>
#define MOD 666013

using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hashuri.out");
int  n, op, x;
vector <int>h[MOD];
bool srch(int x){
    if (h[x%MOD].empty())return 0;
    for (int i=0;i<h[x%MOD].size();i++)
        if (h[x%MOD][i]==x)return 1;
    return 0;
}
void del(int x){
    if (h[x%MOD].empty())return;
    for (int i=0;i<h[x%MOD].size();i++)
        if (h[x%MOD][i]==x)h[x%MOD].erase(h[x%MOD].begin()+i);
}
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>op>>x;
        if (op==1&&srch(x)==0)h[x%MOD].push_back(x);
        else if (op==2)del(x);
        else cout<<srch(x)<<'\n';
    }
    return 0;
}
