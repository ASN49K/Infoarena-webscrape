#include <bits/stdc++.h>
#define prim 1000003
#define maxval 2000000009
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int n, op, x;
vector <int> hashmap[prim];

bool existaElem(int k)
{
    int i, rest = k%prim;
    int len = hashmap[rest].size();
    for(i = 0; i < len; i++)
        if(hashmap[rest][i] == k)
            return true;
    return false;
}

void adaugareElem(int k)
{
    if(existaElem(k))
        return;
    hashmap[k%prim].push_back(k);
}

void scoateElem(int k)
{
    if(!existaElem(k))
        return;
    int i, rest = k%prim;
    int len = hashmap[rest].size();
    for(i = 0; i < len; i++)
        if(hashmap[rest][i] == k)
            hashmap[rest].erase(hashmap[rest].begin() + i), i = maxval;
}

int main()
{
    int i;
    fin >> n;
    for(i = 0; i < n; i++)
    {
        fin >> op >> x;
        if(op == 1)
            adaugareElem(x);
        else if(op == 2)
            scoateElem(x);
        else
        {
            if(existaElem(x))
                fout << 1 << '\n';
            else
                fout << 0 << '\n';
        }


    }
    return 0;
}
