#include<fstream>
#include<vector>
#include<algorithm>

#define mod 999973

using namespace std;

ifstream cin("hashuri.in");
ofstream cout("hashuri.out");

vector<int> a[mod];
 vector<int>::iterator it;
int x,n;
int main()
{cin>>n;
int i=1;
for(;i<=n;i++)
{
   int op;
   cin>>op>>x;
   int j=x%mod;
   bool ok=false;
         it=find(a[j].begin(),a[j].end(),x);
         if(it!=a[j].end())
         ok=true;
      if(op==1 && !ok)
      {
         a[j].push_back(x);
      }
      if(op==2 && ok)
      {
         a[j].erase(it);
      }
      if(op==3)
      { cout<<ok<<'\n';
      }
}
}