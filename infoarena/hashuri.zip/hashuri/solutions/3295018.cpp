//#include<fstream>
//#include<vector>
//using namespace std;
//ifstream fin("date.in");
//ofstream fout("date.out");
//int main() {
//	vector<int> v = { 324,32,3,2,91,82,902,92,1,43,45,21,88,232,100,101,31,90,80,70 };
//	vector<int> ::iterator it1, it2, it3, it4, it5;
//	it1 = v.begin();
//	fout << *it1 << '\n';
//
//	//it2 = v.end() - 1;
//	it2 = v.end();
//	it2--;
//	fout << *it2 << '\n';
//
//	it3 = v.begin() + 3;
//	fout << *it3 << '\n';
//
//	it4 = it3 + 4;
//	fout << *it4 << '\n';
//
//	it5 = it4;
//	*it5 = *it5 * 2 + 1;
//	fout << *it4;
//
//}


//#include<fstream>
//#include<vector>
//using namespace std;
//ifstream fin("date.in");
//ofstream fout("date.out");
//int main() {
//	vector<int> v = { 324,32,3,2,91,82,902,92,1,43,45,21,88,232,100,101,31,90,80,70 };
//	vector<int> ::iterator it1, it2, it3, it4, it5;
//	it1 = v.begin() + 4;
//	it2 = v.begin() + 7;
//	fout << it2 - v.begin() << endl;
//	fout << it2 - it1 << endl;
//	fout << distance(it1, it2) << endl;
//}

//#include<fstream>
//#include<vector>
//using namespace std;
//ifstream fin("date.in");
//ofstream fout("date.out");
//int main() {
//	vector<int> v = { 324,32,3,2,91,82,902,92,1,43,45,21,88,232,100,101,31,90,80,70 };
//	vector<int> ::iterator it1, it2, it3, it4, it5;
//	it1 = v.begin() + 4;
//	fout << it1 - v.begin() << " " << *it1 << endl;
//
//	advance(it1, 7);
//	fout << it1 - v.begin() << " " << *it1 << endl;
//	advance(it1, -3);
//	fout << it1 - v.begin() << " " << *it1 << endl;
//
//	it2 = next(it1, 5);
//	fout << it2 - v.begin() << " " << *it2 << endl;
//
//	it3 = next(it1, -1);
//	fout << it3 - v.begin() << " " << *it3 << endl;
//
//	it4 = prev(it1, 1);
//	fout << it4 - v.begin() << " " << *it4 << endl;
//
//	it5 = prev(it1, -1);
//	fout << it5 - v.begin() << " " << *it5 << endl;
//
//}

/*
	Se da un vector cu elemente de tip structura cu doua campuri, notate unu,doi si o valoare 
Sa se returneze primul element din vector care are campul doi egal cu valoare; daca nu exista sa se 
afiseze mesajul "nu exista".
	Sa se construiasca o functie nu numele "Cauta", care returneaza unu iterator la pozitia
dorita din vector.
*/

//#include<fstream>
//#include<vector>
//using namespace std;
//ifstream fin("date.in");
//ofstream fout("date.out");
//
//struct AAA {
//	int unu, doi;
//};
//
//int n;
//vector<AAA> v;
//
//vector<AAA> ::iterator Cauta(int val) {
//	vector<AAA>::iterator it;
//	for (it = v.begin(); it != v.end(); it++) {
//		if ((*it).doi == val)
//			return it;
//	}
//	return v.end();
//}
//
//int main() {
//	int i, j, x, y, val;
//	fin >> n >> val;
//	for (i = 1; i <= n; i++) {
//		fin >> x >> y;
//		v.push_back({ x,y });
//	}
//
//	vector<AAA> ::iterator poz;
//	poz = Cauta(val);
//	if (poz == v.end())
//		fout << "NU EXISTA";
//	else
//		fout << distance(v.begin(),poz) << " " << (*poz).unu <<" "<<(*poz).doi;
//	
//}

/*

	Ca in problema precedenta, decat ca retin toate pozitiile unde campul doi coincide cu val
intr-un VECTOR DE ITERATORI

*/

//#include<fstream>
//#include<vector>
//using namespace std;
//ifstream fin("date.in");
//ofstream fout("date.out");
//
//struct AAA {
//	int unu, doi;
//};
//
//int n;
//vector<AAA> v;
//vector< vector<AAA>::iterator> memo;
//
//void Cauta(int val) {
//	vector<AAA>::iterator it;
//	for (it = v.begin(); it != v.end(); it++) {
//		if ((*it).doi == val)
//			memo.push_back(it);
//	}
//	
//}
//
//int main() {
//	int i, j, x, y, val;
//	fin >> n >> val;
//	for (i = 1; i <= n; i++) {
//		fin >> x >> y;
//		v.push_back({ x,y });
//	}
//
//	Cauta(val);
//	if (memo.empty())
//		fout << "NU EXISTA";
//	else {
//		for (auto e : memo)
//			fout << distance(v.begin(), e) << " " << (*e).unu << " " << (*e).doi << endl;
//	}
//}



//   HASHURI


#include<fstream>
#include<vector>
using namespace std;
ifstream fin("date.in");
ofstream fout("date.out");

const int MOD = 13;

vector<int> L[MOD];

vector<int> ::iterator Cauta(int val) {
	int r = val % MOD;
	vector<int> ::iterator it;
	for (it = L[r].begin(); it != L[r].end(); it++) {
		if (*it == val)
			return it;
	}
	return L[r].end();
}

void Inserare(int val) {
	if (Cauta(val) == L[val % MOD].end())
		L[val % MOD].push_back(val);
}

void Sterge(int val) {
	vector<int> ::iterator it;
	it = Cauta(val);
	if (it != L[val % MOD].end())
		L[val % MOD].erase(it);
}

int main() {

	int n, tip, val,i;
	vector<int> ::iterator it;
	fin >> n;
	for (i = 1; i <= n; i++) {
		fin >> tip >> val;
		if (tip == 1) {
			Inserare(val);
			continue;
		}
		if (tip == 2) {
			Sterge(val);
			continue;
		}
		if (tip == 3) {
			it = Cauta(val);
			if (it == L[val % MOD].end()) 
				fout << "0\n";
			else
				fout << "1\n";
		}
		
	}
	
}