#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
#define mod 666013

using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

//matrice(indice linie=cheie)
vector <int>m[mod+1];

int n, cerinta, x;

int main()
{
    in>>n;
    int ind;
    bool gasit;
    for(int i=0; i<n; i++)
    {
        in>>cerinta>>x;
        ind=x%mod;
        //int l=m[ind].size();

        if(cerinta==1)
        {
            gasit=0;
            for(int j=0; j<m[ind].size(); j++)
                if(m[ind][j]==x)
                {
                    gasit=1;
                    break;
                }

            if(gasit==0)
            {
                m[ind].push_back(x);
                //l++;
            }

        }
        if(cerinta==2)
        {
            for(int j=0; j<m[ind].size(); j++)
                if(m[ind][j]==x)
                {
                    /*int aux=m[ind][j];
                    m[ind][j]=m[ind][l-1];
                    m[ind][l-1]=aux;
                    */
                    swap(m[ind][j], m[ind][m[ind].size()-1]);
                    m[ind].pop_back();
                    //l--;
                }
        }
        if(cerinta==3)
        {
            bool gasit=0;
            for(int j=0; j<m[ind].size(); j++)
                if(m[ind][j]==x)
                {
                    gasit=1;
                    out<<1<<'\n';
                    break;
                }
            if(gasit==0)
                out<<0<<'\n';
        }

    }

    return 0;
}


