#include <fstream>
#include <vector>

using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector<int>::iterator find_number(int x, int hash_function, vector<int> table[]) {
    for (auto it = table[hash_function].begin(); it != table[hash_function].end(); it++)
        if (x == *it)
            return it;
    return table[hash_function].end();
}

int main() {
    int n, x, hash_function, op;
    fin >> n;
    vector<int> table[1000001];
    for (int i = 0; i < n; i++) {
        fin >> op >> x;
        hash_function = x % 1000001;
        auto it = find_number(x, hash_function, table);
        if (op == 1) {
            if (it == table[hash_function].end())
                table[hash_function].push_back(x);
        } else if (op == 2) {
            if (it != table[hash_function].end())
                table[hash_function].erase(it);
        } else if (op == 3) {
            (fout << (it != table[hash_function].end())) ? 1 : 0;
            fout << "\n";
        }
    }
}