#include <fstream>
#include <set>
using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");
set<int> a ;

int main()
{
    int q ;

    in >> q ;
    for (int i= 1; i <= q ; i ++)
    {
        long long t ,x ;
        in >> t >> x ;

        if ( t == 1 )
            a.insert(x);
        if ( t == 2 )
            a.erase(x);
        if ( t == 3 )
            out << a.count(x) <<'\n';
    }
    return 0;
}
