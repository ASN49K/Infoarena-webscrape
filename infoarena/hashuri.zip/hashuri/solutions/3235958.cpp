#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
int t, a, b, i, op, x;
int mod=660013;
vector <int> g[660013];
inline vector<int>::iterator find_value(int x)
{
    int list=x%mod;
    vector<int>::iterator it;
     for (it = g[list].begin(); it != g[list].end(); it++)
    if(*it==x)
    return it;
    return g[list].end();
}
inline void insert_value(int x)
{
    int list=x%mod;
    if(find_value(x)==g[list].end())
        g[list].push_back(x);

}
inline void erase_value(int x)
{
    int list=x%mod;
    vector<int>::iterator it=find_value(x);
    if(it!=g[list].end())
       g[list].erase(it);

}
int main()
{
    fin>>t;
    while(t--)
    {
        fin>>op>>x;
        if(op==1)
            insert_value(x);
        if(op==2)
            erase_value(x);
        if(op==3)
        {
            if(find_value(x)!=g[x%mod].end())
            fout<<1<<'\n';
            else
                fout<<0<<'\n';
        }

    }
    return 0;
}
