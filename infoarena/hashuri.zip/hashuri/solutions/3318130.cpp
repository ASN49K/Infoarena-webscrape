#include <iostream>
#include <fstream>
#include <map>

using namespace std;

ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");

int n;
map <int,int> f;

int main() {
    fin >> n;
    while (n--) {
        int op, x;
        fin >> op >> x;
        if (op == 1)
            f[x] = 1;
        else if (op == 2)
            f[x] = 0;
        else {
            if (f[x] == 0)
                fout << "0\n";
            else
                fout << "1\n";
        }
    }
    fout << "\n";
    return 0;
}
