#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
#define f first
#define s second
#define pb push_back
#define mp make_pair
#define pi pair<ll, ll>
#define sz(x) (int)((x).size())
#define all(a) (a).begin(), (a).end()

/*const ll maxn = 1e5;
int f[maxn],nf[maxn],inv[maxn];
const int M=998244353;
void init(){
    inv[1]=1; for (int i=2;i<maxn;i++) inv[i]=M-1ll*(M/i)*inv[M%i]%M;
    f[0]=nf[0]=1; for (int i=1;i<maxn;i++) f[i]=1ll*f[i-1]*i%M,nf[i]=1ll*nf[i-1]*inv[i]%M;
}
int C(int x,int y){return 1ll*f[x]*nf[y]%M*nf[x-y]%M;} */

const ll mod = 444263;
ll n, k, m, mi, ma;

void solve(){
	
	ifstream cin("hashuri.in");
	ofstream cout("hashuri.out");
	
	cin >> n;
	set<ll> s[mod];
	for(int i = 0; i<n; i++){
		ll type, x;
		cin >> type >> x;
		ll h = (x*6977)%mod;
		if(type == 1) s[h].insert(x);
		if(type == 2) s[h].erase(x);
		if(type == 3) if(s[h].find(x) == s[h].end()) cout << "0\n"; else cout << "1\n";
	}
	

}

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);

	//init();
	
	int t=1;
	//cin >> t;
	while(t--) solve();
	
	return 0;
}
