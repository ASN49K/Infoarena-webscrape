#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector<int>hash_table[49157];

void insereaza(int x)
{
	bool gasit = false;
	if (hash_table[x % 49157].size() == 0)
		hash_table[x % 49157].push_back(x);
	else
	{
		for (int j = 0; j < hash_table[x % 49157].size(); ++j)
		{
			if (hash_table[x % 49157][j] == x)
			{
				gasit = true;
				break;
			}
		}
		if (!gasit)
			hash_table[x % 49157].push_back(x);
	}
}

void sterge(int x)
{
	for (int j = 0; j < hash_table[x % 49157].size(); ++j)
		if (hash_table[x % 49157][j] == x)
		{
			for (int k = j + 1; k < hash_table[x % 49157].size(); ++k)
				hash_table[x % 49157][k - 1] = hash_table[x % 49157][k];
			hash_table[x % 49157].pop_back();
			break;
		}
}

int main()
{
	int N, nr_operatie, x;
	bool gasit;
	fin >> N;
	for (int i = 0; i < N; ++i)
	{  
		fin >> nr_operatie >> x;
		if(nr_operatie == 1)
		{
			insereaza(x);
		}
		
		else if (nr_operatie == 2)
		{
			sterge(x);

		}
		else if(nr_operatie == 3)
		{
			gasit = false;
			for (int j = 0; j < hash_table[x % 49157].size(); ++j)
				if (hash_table[x % 49157][j] == x)
				{
					fout << 1 << '\n';
					gasit = true;
					break;
				}
			if(!gasit)
			  fout << 0 << '\n';
		}
	}
	return 0;
}