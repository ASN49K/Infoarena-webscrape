#include <fstream>
#include <map>
using namespace std;
ifstream cin ("hashuri.in");
ofstream cout ("hashuri.out");
int t,c,x;
bool f[2000000];
int main()
{
    cin>>t;
    while (t)
    {
        t--;
        cin>>c>>x;
        x=x%19001012;
        if (c==1) f[x]=1;
        if (c==2) f[x]=0;
        if (c==3) cout<<f[x]<<'\n';
    }

    return 0;
}
