#include <iostream>
#include <fstream>
#include <list>
#include <vector>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

class HashTable {
private:
    int dispersie;
    vector<list<int> > table;

    int hash(int val) {
        return val % dispersie;
    }

public:
    HashTable(int dim) : dispersie(dim) {
        table.resize(dispersie);
    }

    void insert(int val) {
        int index = hash(val);
        table[index].push_back(val);
    }

    void remove(int val) {
        int index = hash(val);
        list<int>::iterator i;
        for (i = table[index].begin(); i != table[index].end(); i++) {
            if (*i == val){table[index].erase(i); break;}
        }   
    }

    bool find(int val) {
        int index = hash(val);
        list<int>::iterator i;
        for (i = table[index].begin(); i != table[index].end(); i++) {
            if (*i == val)return true;
        }
        return false;
    }
};

int main() {
    HashTable hash(666013);
    int n;
    fin>>n;
    for(int i=0;i<n;i++)
    {
        int optiune;
        fin>>optiune;
        if(optiune == 1)
        {
            int x;
            fin>>x;
            hash.insert(x);
        }
        if(optiune == 2)
        {
            int x;
            fin>>x;
            hash.remove(x);
        }
        if(optiune == 3)
        {
            int x;
            fin>>x;
            fout<<hash.find(x)<<endl;
        }
    }
    return 0;
}