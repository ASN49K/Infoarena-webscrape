#include <iostream>
#include <fstream>
#include <unordered_set>

using namespace std;

int main() {
	ifstream fin("hashuri.in");
	ofstream fout("hashuri.out");

	unordered_set<int> ht;
	int N, i, operation, value;

	fin >> N;
	for (i = 0; i < N; i++) {
		fin >> operation >> value;

		if (operation == 1)
			ht.insert(value);
		else if (operation == 2)
			ht.erase(value);
		else fout << (ht.find(value) != ht.end()) << '\n';
	}

	fin.close();
	fout.close();
	return 0;
}