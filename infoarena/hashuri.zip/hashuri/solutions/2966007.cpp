#include <iostream>
#include <unordered_map>
using namespace std;

FILE *in = fopen("hashuri.in", "r"), *out = fopen("hashuri.out", "w");
int N;
unordered_map <int, int> m;

int main()
{
    fscanf(in, "%d", &N);
    int type, arg;
    for(int i = 0; i < N; ++i){
        fscanf(in, "%d %d", &type, &arg);
        switch(type){
            case 1:
                m[arg] = 1;
                break;
            case 2:
                m.erase(arg);
                break;
            case 3:
                auto it = m.find(arg);
                if (it != m.end())
                    fprintf(out, "1\n");
                else
                    fprintf(out, "0\n");
        }
    }
    return 0;
}
