#include <bits/stdc++.h>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

class Hash {
private:
    static const int NN = 60000;
    vector<int> v[NN];

public:
    void ADD(int);

    void DELETE(int);

    int FIND(int);

    void display();
};

void Hash::ADD(int addedNumber) {
    int keyNumber = addedNumber % NN;
    int okay = 0;

    for (auto it: v[keyNumber]) {
        if (it == addedNumber)
            okay = 1;
    }
    if (okay)
        return;
    v[keyNumber].push_back(addedNumber);
}

void Hash::DELETE(int deletedNumber) {
    int keyNumber = deletedNumber % NN;
    int okay = 0;
    for (auto it: v[keyNumber])
        if (it == deletedNumber)
            okay = 1;
    if (!okay)
        return;

    vector<int>::iterator it = find(v[keyNumber].begin(), v[keyNumber].end(), deletedNumber);
    v[keyNumber].erase(it);
}

int Hash::FIND(int searchedNumber) {
    int keyNumber = searchedNumber % NN;
    vector<int>::iterator it = find(v[keyNumber].begin(), v[keyNumber].end(), searchedNumber);
    if (it != v[keyNumber].end())
        return 1;
    return 0;
}

Hash HASH;
int n, x, op;

int main() {
    fin >> n;
    for (; n != 0; n--) {
        fin >> op >> x;
        if (op == 1)
            HASH.ADD(x);
        else if (op == 2)
            HASH.DELETE(x);
        else if (op == 3)
            fout << HASH.FIND(x)<<'\n';
    }
    return 0;

}