/*#include <bits/stdc++.h>
using namespace std;

int n, x, y;
unordered_map <int, int> fr;

int main() {
    ifstream cin ("hashuri.in");
    ofstream cout ("hashuri.out");
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        cin >> x >> y;
        if (x == 1) {
            fr[y] = 1;
        }
        if (x == 2) {
            if (fr.find(y) != fr.end()) {
                fr.erase(y);
            }
        }
        if (x == 3) {
            if (fr.find(y) != fr.end()) {
                cout << "1\n";
            } else {
                cout << "0\n";
            }
        }
    }
    return 0;
}
*/
#include <bits/stdc++.h>

using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
const int key = 66613;

vector <int> H[key];

void adauga(int x) {
    int l = x % key;
    int sz = H[l].size();
    for(int i = 0; i < sz; i++) {
        if(H[l][i] == x) {
            return;
        }
    }
    H[l].push_back(x);
}

void sterg(int x) {
    int l = x % key;
    for(int i = 0; i < (int)H[l].size(); i++) {
        if(H[l][i] == x) {
            H[l].erase(H[l].begin() + i);
            return;
        }
    }
}

bool exista(int x) {
    int l = x % key;
    for(int i = 0; i < (int)H[l].size(); i++) {
        if(H[l][i] == x) {
            return 1;
        }
    }
    return 0;
}

int main()
{
    int n;
    fin >> n;
    for(int i = 1; i <= n; i++) {
        int x, y;
        fin >> x >> y;
        if(x == 1) {
            adauga(y);
        }
        else if(x == 2) {
            sterg(y);
        }
        else if(x == 3) {
            fout << exista(y) << '\n';
        }
    }
    return 0;
}
