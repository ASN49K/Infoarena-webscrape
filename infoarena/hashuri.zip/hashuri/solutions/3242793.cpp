#import<bits/stdc++.h>
std::fstream f("hashuri.in");std::ofstream g("hashuri.out");std::unordered_set<int>s;int n,x,c;main(){for(f>>n;n--;){f>>c>>x;if(c==1)s.insert(x);if(c==2)s.erase(x);if(c==3)g<<s.count(x)<<'\n';}}
