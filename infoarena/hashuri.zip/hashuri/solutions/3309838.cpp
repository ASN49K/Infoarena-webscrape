/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

struct HashTable {
    static const int P = 1000007;
    vector <int> table[P]; ///table[x] sunt elementele y care au h[y] = x;
    
    int h(int x) {
        return x % P;
    }
    
    bool lookup(int x) {
        ///return find(table[h(x)].begin(), table[h(x)].end(), x) != table[h(x)].end();
        int hash_value = h(x);
        for(int i = 0; i < table[hash_value].size(); i++) {
            if(x == table[hash_value][i]) {
                return true;
            }
        }
    
        return false;
    }
    
    void insert(int x) {
        if(lookup(x)) {
            return;
        }
        table[h(x)].push_back(x);
    }
    
    void erase(int x) {
        if(!lookup(x)) {
            return;
        }
        table[h(x)].erase(find(table[h(x)].begin(), table[h(x)].end(), x));
    }
};

HashTable H;

int main()
{
    int N;
    fin >> N;
    while(N--) {
        int t, x;
        fin >> t >> x;
        if(t == 1) {
            H.insert(x);
        }
        if(t == 2) {
            H.erase(x);
        }
        if(t == 3) {
            fout << H.lookup(x) << "\n";
        }
    }

    return 0;
}