
#include <iostream>
#include <fstream>
#include <vector>
#define MOD  666013

using namespace std;
vector<int> hashul_nebun[MOD+2];

inline vector<int>::iterator find_value(int x)
{
    int clasa_find = x % MOD;
    vector<int>::iterator it;

    for (it = hashul_nebun[clasa_find].begin(); it != hashul_nebun[clasa_find].end(); it++)
// dereferentiez astfel incat sa preiau valoarea de la acea adresa
        if (*it == x)
            return it;
    return hashul_nebun[clasa_find].end();
}


int main()
{
    int n, op, x;

    ifstream input("hashuri.in");
    ofstream output("hashuri.out");
    input >> n;

    for(int i = 1; i <= n; i++)
    {
        input >> op >> x;
        int clasa =x % MOD;

        if(op == 1)
        {
            if (find_value(x) == hashul_nebun[clasa].end())
                hashul_nebun[clasa].push_back(x);
            continue;
        }
        else if(op == 2)
        {
     // iteratorul valorii x este preluat si este cautat valoarea
            auto it = find_value(x);

      // daca este gasita valoarea, deci se ajunge la finalul hashului cu o val existenta  atunci o sterg
            if (it != hashul_nebun[clasa].end())
                hashul_nebun[clasa].erase(it);
            continue;
        }
        else if(op == 3)
        {
            int found=0;
            // daca este gasita valoarea atunci imi iau un flag de found pe care il si afisez
            if(find_value(x)!=hashul_nebun[clasa].end())
                found=1;

            output << found<< endl;
        }
    }

    return 0;
}