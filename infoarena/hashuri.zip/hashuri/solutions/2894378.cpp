#include <fstream>
#include <vector>

using namespace std;

int main() {
    vector<int> multime(1000002, 0);
    int n, x;
    char c;
    ifstream fin("input.in");
    ofstream fout("output.txt");
    fin >> n;
    for (int i = 0; i < n; i++) {
        fin >> c >> x;
        if (c == '1')
            multime[x] = 1;
        else if (c == '2')
            multime[x] = 0;
        else if (c == '3')
            fout << multime[x] << "\n";
    }
    return 0;
}