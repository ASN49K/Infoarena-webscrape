#include <fstream>
#include <vector>

using namespace std;

const unsigned long long int MAX = 506999947;

vector<vector<unsigned long long int>> fr(MAX + 1);

ifstream f("hashuri.in");
ofstream g("hashuri.out");

int main() {
    unsigned long long int n, i, x, y;
    f >> n;

    for (i = 0; i < n; i++)
    {
        f >> x >> y;
        if (x == 1)
        {
            fr[y % MAX].push_back(y);
        }
        else if (x == 2)
        {
            auto& bucket = fr[y % MAX];
            for (auto it = bucket.begin(); it != bucket.end(); ++it)
            {
                if (*it == y)
                {
                    bucket.erase(it);
                    break;
                }
            }
        }
        else if (x == 3)
        {
            auto& bucket = fr[y % MAX];
            bool found = false;
            for (auto it = bucket.begin(); it != bucket.end(); ++it)
            {
                if (*it == y)
                {
                    found = true;
                    break;
                }
            }
            g << (found ? "1\n" : "0\n");
        }
    }

    return 0;
}
