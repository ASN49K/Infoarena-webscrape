#include <iostream>
#include <string>
#include <queue>
#include <vector>
#include <cmath>
#include <algorithm>
#include <fstream>
#include <unordered_map>
using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");
int a,b,c,d,e,g,h,i,j,k,l,m,n,o,r,s,S,t,T,x,y,z,ok,nr,C,poz,pas,posibil,Min,Max;
unordered_map <int, int>M;
int main()
{
    in>>n;
    for(i=1;i<=n;i++){
        in>>c>>x;
        if(c==1) {
            M[x]=1;
        }
        if(c==2) {
            M.erase(x);
        }
        if(c==3) {
           out<<M[x]<<'\n';
        }
    }
    return 0;
}
