#include <iostream>
#include <ctime>
#include <vector>
#include <stdlib.h>
#include <limits>
#include <fstream>

using namespace std;

//ifstream f("hashuri.in.txt");
//ofstream g("hashuri.out.txt");
ifstream f("hashuri.in");
ofstream g("hashuri.out");

const int PRIME  = 666013; // numar prim

unsigned hashFuncDivision(const unsigned x) {
    return x % PRIME; // Division method with prime numbers
}



int find_value(vector<vector<unsigned>>& mp, const int index, const unsigned x) {
    unsigned sz = mp[index].size();
    for (unsigned i = 0; i < sz; i++)
    {
        if (mp[index][i] == x)
            return i;
    }
    return -1;
}
int main()
{
    vector<vector<unsigned>> hash_map;
    unsigned n, op, x;
    f >> n;
    for (unsigned i = 0; i < n; i++)
    {
        f >> op >> x;

        unsigned hashing = hashFuncDivision(x);
        int found = find_value(hash_map, hashing, x);
        
        if (op == 1) // Try insertion of elem 'x' into the hash
        {
            if (found == -1)
                hash_map[hashing].push_back(x); // INSERT the value into the hash

            continue;
        }

        if (op == 2) // Try deletion of elem 'x' into the hash
        {
            if (found >= 0)
            {
                const int sz = hash_map[hashing].size();

                swap(hash_map[hashing][found], hash_map[hashing][sz - 1]);

                hash_map[hashing].pop_back(); // DELETE the value from the hash
            }

            continue;
        }

        /// 'op == 3', so check if elem 'x' is already in the hash or not
        if (found >= 0) { // Elem 'x' found in the hash
            g << 1 << endl;
        } else {
            g << 0 << endl;
        }
    }

    f.close();
    g.close();

    return 0;
}
