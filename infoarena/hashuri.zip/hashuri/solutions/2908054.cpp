#include <iostream>
#include <fstream>

using namespace std;


class InParser {
private:
	FILE* fin;
	char* buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}

	InParser& operator >> (int& n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		}
		else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	
};

class OutParser {
private:
	FILE* fout;
	char* buff;
	int sp;

	void write_ch(char ch) {
		if (sp == 50000) {
			fwrite(buff, 1, 50000, fout);
			sp = 0;
			buff[sp++] = ch;
		}
		else {
			buff[sp++] = ch;
		}
	}


public:
	OutParser(const char* name) {
		fout = fopen(name, "w");
		buff = new char[50000]();
		sp = 0;
	}
	~OutParser() {
		fwrite(buff, 1, sp, fout);
		fclose(fout);
	}

	OutParser& operator << (int vu32) {
		if (vu32 <= 9) {
			write_ch(vu32 + '0');
		}
		else {
			(*this) << (vu32 / 10);
			write_ch(vu32 % 10 + '0');
		}
		return *this;
	}

	OutParser& operator << (long long vu64) {
		if (vu64 <= 9) {
			write_ch(vu64 + '0');
		}
		else {
			(*this) << (vu64 / 10);
			write_ch(vu64 % 10 + '0');
		}
		return *this;
	}

	OutParser& operator << (char ch) {
		write_ch(ch);
		return *this;
	}
	OutParser& operator << (const char* ch) {
		while (*ch) {
			write_ch(*ch);
			++ch;
		}
		return *this;
	}
};

const int mod = 5e6;

struct nod
{
	int val;
	nod* l;
};

nod* v[mod];

bool parcurgere(int x)
{
	int index = x % mod;
	nod* head = v[index];
	while (head != NULL)
	{
		if (head->val == x)
			return 1;
		head = head->l;
	}
	return 0;
}

void insereaza( int x)
{
	if (parcurgere(x) == 1)
		return;
	int index= x% mod;
	if (v[index] == NULL)
	{
		v[index] = new nod;
		v[index]->val = x;
		v[index]->l = NULL;
	}
	else
	{
		nod* k = new nod;
		k->val = x;
		k->l = v[index];
		v[index] = k;
	}
}

void stergere(int x)
{
	if (parcurgere(x) == 0)
		return;
	int index = x % mod;
	nod* head = v[index];
	nod* before = NULL;
	nod* after = NULL;

	while (head != NULL)
	{
		if (head->val == x)
		{
			after = head->l;
			break;
		}
		before = head;
		head = head->l;

	}

	if(before!=NULL)
		before->l = after;
	else
	{
		v[index] = after;
	}

	delete head;
	
}

int main()
{
	InParser fin("hashuri.in");
	OutParser fout("hashuri.out");
	int n,q,x;
	fin >> n;
	for (int i = 1; i <= n; i++)
	{
		fin >> q >> x;
		if (q == 1)
		{
			insereaza(x);
		}
		if (q == 2)
		{
			stergere(x);
		}
		if (q == 3)
		{
			fout << parcurgere(x) << endl;
		}

	}

	for (int i = 0; i < mod; i++)
	{
		nod* head = NULL;
		nod* next = v[i];
		while (next != NULL)
		{
			head = next;
			next = head->l;
			delete head;
		}
	}

	
}