#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

#define k 666013

vector <int> myhash[k+5];

int main()
{int n, i, j, x, caz, clasa, gasit, poz;

f>>n;

for(i = 1; i <= n; i++){

    f>>caz>>x;

    gasit = 0;

    clasa = x % k;

    for(j = 0; j < myhash[clasa].size(); j++){

            if(myhash[clasa][j] == x){

                gasit = 1;

                poz = j;

                break;
            }
    }

    if(caz == 1){

        if(gasit == 0)

            myhash[clasa].push_back(x);

    }else{

    if(caz == 2){

        if(gasit == 1){

            swap(myhash[clasa][j], myhash[clasa].back());
            myhash[clasa].pop_back();
        }


    }else{

        if(gasit == 1)

            g<<1<<'\n';
        else
            g<<0<<'\n';

}}

}


    return 0;
}
