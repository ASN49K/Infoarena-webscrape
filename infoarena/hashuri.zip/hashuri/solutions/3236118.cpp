#include <fstream>
#include <map>
#include <deque>

using namespace std;

ifstream cin ("hashuri.in");
ofstream cout ("hashuri.out");

long long int t,n,m,i,j,sum,k,x,y,x2,y2,a[200005],b[200005],l,r,nrp,nrn,ans,mini,ok,nr,ans2;
char s[200005],s2[200005];
deque<long long int>q;
map<int,int>fr;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>k>>x;
        if(k==1)
            fr[x]=1;
        if(k==2)
            fr[x]=0;
        if(k==3)
            cout<<fr[x]<<'\n';
    }
    return 0;
}

