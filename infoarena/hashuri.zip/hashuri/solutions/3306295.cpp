#include <bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

bool v[1000010];
int Hash(int x)
{
    int mod = 1e6+7;
    return x % mod;
}
int Hash(string x)
{
    int mod = 1e6 + 7;
    int rez = 0;
    for(int j=0;j<x.size();j++)
    {
        rez += ( x[j] ^ j  );
    }
    return rez % mod;
}
int main()
{
    int n;
    fin >> n;
    for(int i=1;i<=n;i++)
    {
        int op,x;
        fin >> op >> x;
        if(op==1)
        {
            v[Hash(x)] = 1;
        }
        else if(op==2)
        {
            v[Hash(x)] = 0;
        }
        else
        {
            fout << v[Hash(x)] <<'\n';
        }
    }
    return 0;
}
