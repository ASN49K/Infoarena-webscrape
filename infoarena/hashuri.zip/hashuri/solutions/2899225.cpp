#include <bits/stdc++.h>
using namespace std;
ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");

const int MOD=1800083;

vector <int> hash1[MOD];

int main()
{
    int n;
    fin >>n;
    for (int i=1;i<=n;++i){
        int op,x;
        fin >>op>>x;
        if (op==1){
            int y=x%MOD;
            hash1[y].push_back (x);
        }
        else{
            if (op==2){
                int y=x%MOD;
                for (int j=0;j<(int) hash1[y].size ();++j){
                    if (hash1[y][j]==x){
                        hash1[y].erase (hash1[y].begin ()+j);
                    }
                }
            }
            else{
                int ok=0,y=x%MOD;
                for (int j=0;j<(int) hash1[y].size ();++j){
                    if (hash1[y][j]==x){
                        ok=1;
                    }
                }
                fout <<ok<<'\n';
            }
        }
    }
    fin.close ();
    fout.close ();
    return 0;
}
