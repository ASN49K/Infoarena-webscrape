#include <fstream>
#include <set>
using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hashuri.out");
#define MOD 666013
set <int> v[MOD];
int h(int n)
{
    return n%MOD;
}
int main()
{
    set <int> :: iterator it;
    int n,i,t,nr;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>t>>nr;
        if(t==1)
            v[h(nr)].insert(nr);
        else
        if(t==2)
            v[h(nr)].erase(nr);
        else
        {
            it=v[h(nr)].find(nr);
            if(it!=v[h(nr)].end())
                cout<<1<<'\n';
            else
                cout<<0<<'\n';
        }
    }
    return 0;
}
