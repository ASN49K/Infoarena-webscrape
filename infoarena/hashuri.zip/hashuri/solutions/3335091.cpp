#include <bits/stdc++.h>
using namespace std;

int n, x, y;
unordered_map <int, int> fr;

int main() {
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        cin >> x >> y;
        if (x == 1) {
            fr[y] = 1;
        }
        if (x == 2) {
            if (fr.find(y) != fr.end()) {
                fr.erase(y);
            }
        }
        if (x == 3) {
            if (fr.find(y) != fr.end()) {
                cout << "1\n";
            } else {
                cout << "0\n";
            }
        }
    }
    return 0;
}
