#include <bits/stdc++.h>

using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
int n;
vector <int> Hash[84673]; //nr prim ales random
void stergere(int x)
{
    int i,val;
    val = x%84673;
    for(i=0;i<Hash[val].size();i++)
    {
        if(Hash[val][i] == x)
        {
            Hash[val][i] = -1;
            break;
        }
    }
}
int caut(int x)
{
    int val,i;
    val = x%84673;
    for(i=0; i<Hash[val].size(); i++)
    {
        if(Hash[val][i] == x)
            return 1;
    }
    return 0;
}
void adaugare(int x)
{
    int val;
    val = x % 84673;
    if(caut(x) == 0)
    {
        Hash[val].push_back(x);
    }
}
int main()
{
    int n,i,value,x;
    f>>n;
    for(i=0;i<n;i++)
    {
        f>>value>>x;
        if(value == 1)
        {
            adaugare(x);
        }
        if(value == 2)
        {
            stergere(x);
        }
        if(value == 3)
        {
            g<<caut(x)<<'\n';
        }
    }
    return 0;
}
