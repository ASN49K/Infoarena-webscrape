#include <fstream>

using namespace std;

const int N = 1e6;
const int K = 666019;

struct element
{
    int val, urm;
};

element v[N+1];
int nr_e, lst[K];

int caut_poz(int val)
{
    int c = val % K;
    for (int p = lst[c]; p != 0; p = v[p].urm)
    {
        if (v[p].val == val)
        {
            return p;
        }
    }
    return 0;
}

void adauga(int val)
{
    int p = caut_poz(val);
    if (p != 0)
    {
        return;
    }
    int c = val % K;
    ++nr_e;
    v[nr_e].val = val;
    v[nr_e].urm = lst[c];
    lst[c] = nr_e;
}

void sterge(int val)
{
    int p = caut_poz(val);
    if (p == 0)
    {
        return;
    }
    int c= val % K;
    v[p].val = v[lst[c]].val;
    lst[c] = v[lst[c]].urm;
}

bool exista(int val)
{
    return (caut_poz(val) != 0);
}

int main()
{
    ifstream in("hashuri.in");
    ofstream out("hashuri.out");
    int n;
    in >> n;
    for (int i = 0; i < n; i++)
    {
        int tip, val;
        in >> tip >> val;
        if (tip == 1)
        {
            adauga(val);
        }
        else if (tip == 2)
        {
            sterge(val);
        }
        else
        {
            out << exista(val) << "\n";
        }
    }
    return 0;
}
