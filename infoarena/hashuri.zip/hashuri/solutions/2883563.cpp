#include <fstream>
#include <set>
using namespace std;

ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");

int N;
const int c = 100005;
set<long long>v[c];

int main(){
    fin>>N;
    for (int i=1; i<=N; i++){
        int op, nr;
        fin>>op>>nr;

        if (op == 1){
            v[nr % c].insert(nr);
        }
        else if (op == 2){
            if (v[nr % c].find(nr) != v[nr % c].end())
                v[nr % c].erase(nr);
        }
        else if (op == 3){
            if (v[nr % c].find(nr) != v[nr % c].end())
                fout<<1<<"\n";
            else
                fout<<0<<"\n";
        }
    }

    return 0;
}