#include <cstdio>
#include<bitset>
using namespace std;

const int MOD1 = 666013;
const int MOD2 = 1000003;
const int NMAX = 1e7;

bool hash1[NMAX + 1], hash2[NMAX + 1];

void Add(int number) {
    hash1[number % MOD1] = true;
    //hash2[number % MOD2] = true;
}
void Delete(int number) {
    hash1[number % MOD1] = false;
    //hash2[number % MOD2] = false;
}

bool Exists(int number) {
    return hash1[number % MOD1];
    //return (hash1[number % MOD1] && hash2[number % MOD2]);
}
int main() {
    freopen("hashuri.in", "r", stdin);
    freopen("hashuri.out", "w", stdout);

    int operations;

    scanf("%d", &operations);

    for (; operations > 0; operations--) {
        int operation, number;
        scanf("%d %d", &operation, &number);
        if (operation == 1) {
            Add(number);
        }
        else if (operation == 2) {
            Delete(number);
        }
        else {
            printf("%d\n", Exists(number));
        }
    }
    return 0;
}