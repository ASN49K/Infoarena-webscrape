#include <bits/stdc++.h>

using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int n,o,x;
unordered_set<int> s;


int main()
{
    fin>>n;
    for(; n; n--)
    {
        fin>>o>>x;
        if(o==1)
        {
            s.insert(x);
        }
        else if(o==2)
        {
            s.erase(x);
        }
        else if(s.find(x)==s.end())
            fout<<"0\n";
        else
            fout<<"1\n";

    }
    return 0;
}
