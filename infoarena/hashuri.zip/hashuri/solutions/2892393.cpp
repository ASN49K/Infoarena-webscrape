#include<iostream>
#include<vector>
#include<iterator>
#include<fstream>
using namespace std;
vector<int> H[666013];
vector<int>::iterator ptr;
int i,y,n,x,p = 666013, ok;
int main() {
	ifstream f("hashuri.in");
	ofstream g("hashuri.out");
	f >> n;
	for (i = 1; i <= n; i++) {
		f >> x >> y;
		if (x == 1) {
			ok = 0;
			for (ptr = H[y % p].begin(); ptr < H[y % p].end(); ptr++)
				if (*ptr == y)
				{
					ok = 1;
					break;
				}
			if (ok == 0)
				H[y % p].push_back(y);
		}
		if (x == 2) {
			ok = 0;
			for (ptr = H[y % p].begin(); ptr < H[y % p].end(); ptr++)
				if (*ptr == y)
				{
					ok = 1;
					break;
				}
			if (ok == 1)
				H[y % p].erase(ptr);
		}
		if (x == 3) {
			ok = 0;
			for (ptr = H[y % p].begin(); ptr < H[y % p].end(); ptr++)
				if (*ptr == y)
				{
					ok = 1;
					break;
				}
			g << ok << "\n";
		}

	}
	return 0;
}