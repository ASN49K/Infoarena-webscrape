#include <bits/stdc++.h>

using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

//Problema palindrom

bool apare[10000001];

int h(int x)
{
    return x;
}

void adaug(int x)
{
    apare[h(x)]=true;
}

void sterge(int x)
{
    if(apare[h(x)]==true)
        apare[h(x)]=false;
}

bool exista(int x)
{
    if(apare[h(x)])
        return 1;
    return 0;
}


int i,x;
//refac arhitect cu set

int main()
{
    int N, op;
    fin>>N;
    for(i=1;i<=N;i++)
    {
        fin>>op>>x;
        if(op==1)
        {
            adaug(x);
        }
        else if(op==2)
        {
            sterge(x);
        }
        else if(op==3) fout<<exista(x)<<'\n';
    }

}
