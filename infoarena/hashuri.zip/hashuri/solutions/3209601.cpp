#include <iostream>
#include <fstream>
#include <map>
#define MOD 1000000
#include <vector>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector <int> multime [2000];

int gaseste(int a){
    int ind = a/MOD;
    for(int i = 0; i<multime[ind].size(); i++){
        if(multime[ind][i]==a%MOD){
            return i;
        }
    }
    return -1;
}

void inserare(int a){
    int ind = a/MOD;
    if(gaseste(a)==-1)
        multime[ind].push_back(a%MOD);
}

void eliminare(int a){
    int ind = a/MOD, f = gaseste(a);
    if(f!=-1)
        multime[ind].erase(multime[ind].begin()+f);
}

int main()
{
    int N, c, n;
    fin>>N;
    for(; N>0; N--){
        fin>>c>>n;
        if(c==1) inserare(n);
        if(c==2) eliminare(n);
        if(c==3) fout<<(gaseste(n) != -1 ? 1 : 0)<<'\n';
    }
    return 0;
}
