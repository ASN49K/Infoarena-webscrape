#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

#define PRIME 100003

int main() {
    std::ifstream input("hashuri.in");
    std::ofstream output("hashuri.out");

    std::vector<std::vector<int>> hashes(PRIME);

    int n;
    input >> n;
    while (n--) {
        int type, x;
        input >> type >> x;

        auto it = std::find(hashes[x % PRIME].begin(), hashes[x % PRIME].end(), x);

        if (type == 1) {
            if (it == hashes[x % PRIME].end()) hashes[x % PRIME].push_back(x);
        } else if (type == 2) {
            if (it != hashes[x % PRIME].end()) hashes[x % PRIME].erase(it);
        } else if (type == 3) {
            output << (it != hashes[x % PRIME].end()) << '\n';
        }

    }

    return 0;
}
