#include <fstream>
#include <map>

using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hasuri.out");
int N,NR;
map <int, int> M;
int main()
{
    int n,a,b;
    cin>>n;
    for (int i=1; i<=n; i++)
    {
        cin>>a>>b;
        if (a==1&& M.find(b)==M.end())
            M[b]=1;
        if (a==2)
            M.erase(b);
        if (a==3)
        {
            if(M.find(b)!=M.end())
                cout<<1<<'\n';
            else cout<<0<<'\n';
        }
    }

    return 0;
}
