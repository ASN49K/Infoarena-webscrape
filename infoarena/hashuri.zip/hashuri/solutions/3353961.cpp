#include <bits/stdc++.h>
using namespace std;

class Hash {
    private:
        const static int MOD = 666013;
        int hash(int x) {
            return x % MOD;
        }
        struct Node {
            int x;
            Node* next;
            Node(int val) {
                x = val;
                next = NULL;
            }
        };
        Node* head[MOD];
        Node* last[MOD];
        void addHelper(int id, int x) {
            Node* p = new Node(x);
            if(head[id] == NULL) {
                head[id] = last[id] = p;
            } else {
                last[id] -> next = p;
                last[id] = p;
            }
        }
        Node* searchHelper(int id, int val) {
            Node* p = head[id];
            while(p != NULL) {
                if(p -> x == val) {
                    return p;
                }
                p = p -> next;
            }
            return p;
        }
        void deleteHelper(int id, int val) {
            Node* p = searchHelper(id, val);
            if(p != NULL) {
                if(p == head[id]) {
                    if(head[id] == last[id]) {
                        head[id] = last[id] = NULL;
                        delete p;
                    } else {
                        head[id] = head[id] -> next;
                        delete p;
                    }
                } else {
                    if(p == last[id]) {
                        Node* q = head[id];
                        while(q -> next != p) {
                            q = q -> next;
                        }
                        q -> next = NULL;
                        last[id] = q;
                        delete p;
                    } else {
                        Node* q = head[id];
                        while(q -> next != p) {
                            q = q -> next;
                        }
                        q -> next = p -> next;
                        delete p;
                    }
                }
            }
        }
    public:
        Hash() {
            for(int i = 0; i < MOD; i++) {
                head[i] = last[i] = NULL;
            }
        }
        void add(int x) {
            addHelper(hash(x), x);
        }
        bool search(int x) {
            return searchHelper(hash(x), x) != NULL;
        }
        void del(int x) {
            deleteHelper(hash(x), x);
        }
};

int main() {
    ifstream cin("hashuri.in");
    ofstream cout("hashuri.out");
    Hash h;
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++) {
        int op, x;
        cin >> op >> x;
        if(op == 0) {
            if(h.search(x) == NULL) {
                h.add(x);
            }
        }
        if(op == 1) {
            if(h.search(x) != NULL) {
                h.del(x);
            }
        }
        if(op == 2) {
            cout << h.search(x) << '\n';
        }
    }
    return 0;
}