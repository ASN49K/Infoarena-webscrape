#include <fstream>
#include <vector>

using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
int n,i,t,x,ok,h,u,m;
const int N = 1048575;
vector<int> a[N];
vector<int>::iterator it;

int main()
{
    f >> n;
    for(i = 1; i <= n; i++)
    {
        f >> t;
        if(t==1)
        {
            f >> x;
            ok = 1;
            m = x&N;
            for(h = 0; h < a[m].size(); h++)
                if(a[m][h]==x) {ok = 0; h = n;}
            if(ok==1) a[m].push_back(x);
        }
        else if(t==2)
        {
            f >> x;
            ok = 1;
            m = x&N;
            for(h = 0; h < a[m].size(); h++)
                if(a[m][h]==x)
                {
                    u = h;
                    h = n;
                    ok = 0;
                }
            if(ok==0)
            {
                it = a[m].begin()+u;
                a[m].erase(it);
            }

        }
        else
        {
            f >> x;
            ok = 0;
            m = x&N;
            for(h = 0; h < a[m].size(); h++)
                if(a[m][h]==x) {ok = 1; h = n;}
            g <<  ok << "\n";
        }
    }
    return 0;
}
