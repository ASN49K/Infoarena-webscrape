//package hashuri;

import java.io.*;
import java.util.*;

public class Main {
    static final String INPUT_FILE = "hashuri.in";
    static final String OUTPUT_FILE = "hashuri.out";

    public static class TokenizedReader {
        private final BufferedReader reader;
        private StringTokenizer tokenizer;

        TokenizedReader(String filePath) throws FileNotFoundException {
            reader = new BufferedReader(new FileReader(filePath));
        }

        private String nextToken() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }

        private int nextInt() {
            return Integer.parseInt(nextToken());
        }

        public void close() throws IOException {
            reader.close();
        }
    }

    public static void main(String[] args) throws IOException {
        TokenizedReader reader = new TokenizedReader(INPUT_FILE);
        BufferedWriter writer = new BufferedWriter(new FileWriter(OUTPUT_FILE));
        solve(reader, writer);
        reader.close();
        writer.flush();
        writer.close();
    }

    public static void solve(TokenizedReader reader,
                             Writer writer) throws IOException {
        int n = reader.nextInt();
        Set<Integer> map = new HashSet<>();
        while (n-- > 0) {
            int op = reader.nextInt();
            int el = reader.nextInt();
            if (op == 1) {
                map.add(el);
            } else if (op == 2) {
                map.remove(el);
            } else if (op == 3) {
                writer.write(map.contains(el) ? 1 : 0);
            }
        }
    }
}