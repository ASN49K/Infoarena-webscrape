#include <string.h>
#include <fstream>
#include <vector>
#include <iostream>

# define hash 604559 // Alegem un numar prim mare pentru hashing, functia de hash fiind modulo

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector <int> v[hash + 1];

int main ()
{
    int n;
    fin >> n;
    int opt, x;
    for(int i = 0; i < n; i++)
    {
        fin >> opt >> x;
        int poz = x % hash;
        switch(opt)
        {
            case 1:
            {
                v[poz].push_back(x);
                break;
            }
            case 2:
            {
                for(int j = 0; j< v[poz].size(); j++)
                    if(v[poz][j] == x)
                        v[poz].erase(v[poz].begin() + j);
                break;
            }
            case 3:
            {
                int ok = 0;
                for(int j = 0; j < v[poz].size() && !ok; j++)
                    if(v[poz][j] == x)
                    {
                        fout << "1\n";
                        ok = 1;
                    }
                if(!ok)
                    fout << "0\n";
                break;
            }
        }
    }
    return 0;
}