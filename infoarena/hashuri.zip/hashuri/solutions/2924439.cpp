#include <fstream>
#include <vector>

using namespace std;

#define M 666013

vector<int> v[M];

bool exista(int x)
{
    int cod, i;
    cod = x % M;

    for(i = 0; i < v[cod].size(); i++)
    {
        if(x == v[cod][i])
        {
            return 1;
        }
    }

    return 0;
}

int poz(int x)
{
    int cod, i;
    cod = x % M;

    for(i = 0; i < v[cod].size(); i++)
    {
        if(x == v[cod][i])
        {
            return i;
        }
    }

    return -1;
}

void adauga(int x)
{
    int cod;
    cod = x % M;

    if(!exista(x))
    {
        v[cod].push_back(x);
    }
}

void sterge(int x)
{
    int cod;
    cod = x % M;

    if(exista(x))
    {
        v[cod].erase(v[cod].begin() + poz(x));
    }
}

int main()
{
    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");

    int n, i, cer, nr;

    fin >> n;

    for(i = 1; i <= n; i++)
    {
        fin >> cer >> nr;
        if(cer == 1)
        {
            adauga(nr);
        }
        else if(cer == 2)
        {
            sterge(nr);
        }
        else
        {
            fout << exista(nr) << '\n';
        }
    }
    return 0;
}
