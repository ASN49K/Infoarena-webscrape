#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_set>
using namespace std;

int main() {
    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");

    int n, x, y;
    const int MOD = 666013;
    vector<unordered_set<int>> valori(MOD);

    fin >> n;
    while (n--) {
        fin >> x >> y;
        int aux = y % MOD;

        if (x == 1) {
            valori[aux].insert(y);
        } else if (x == 2) {
            valori[aux].erase(y);
        } else if (x == 3) {
            bool rez = (valori[aux].count(y) != 0);
            fout << rez << '\n';
        }
    }

    fin.close();
    fout.close();
    return 0;
}
