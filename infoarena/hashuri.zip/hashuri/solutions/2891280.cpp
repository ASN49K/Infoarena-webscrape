#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
#define size 666013
vector<long long >h[size];
int cauta(long long x)
{
    int ok = 0;
    for (auto i = h[x%size].begin();i != h[x%size].end() && ok == 0;++i)
        if(*i == x)
            ok = 1;
    if(ok == 1)
      return 1;
    else
      return 0;
}
void adauga(long long x)
{
    if(cauta(x) == 1)
        return;
    else
        h[x%size].push_back(x);
}
void sterge(long long x)
{
    if(cauta(x) == 1)
        h[x%size].pop_back();
    else
        return;
}
int main() {
    ifstream f("hashuri.in");
    ofstream g("hashuri.out");
    long long n,op,x;
    f>>n;
    while (f>>op>>x)
    {
        switch (op) {
            case 1:
                adauga(x);
                break;
            case 2:
                sterge(x);
                break;
            case 3:
                g<<cauta(x)<<'\n';
                break;
            default:
                break;

        }
    }

    f.close();g.close();
    return 0;
}