#include <bits/stdc++.h>
#define MOD 100003

using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

set <int> h1[MOD];

int n, i, op, x;
int main()
{
    fin>>n;
    for(i=1; i<=n; i++)
    {
        fin>>op>>x;
        if(op==1)
        {
          h1[x%MOD].insert(x);
        }
        else
            if(op==2)
        {
            h1[x%MOD].erase(x);
        }
        else
            if(op==3)
        {
            if(h1[x%MOD].find(x)==h1[x%MOD].end())
               fout<<0<<'\n';
               else
                fout<<1<<'\n';
        }
    }
    return 0;
}
