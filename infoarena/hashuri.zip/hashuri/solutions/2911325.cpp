#include <bits/stdc++.h>

using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int n,o,x;
set<int> s;

int main()
{
    fin>>n;
    for(; n; n--)
    {
        fin>>o>>x;
        auto it = s.find(x);
        if(o==1)
        {
            s.insert(x);
        }
        else if(o==2)
        {
            s.erase(x);
        }
        else if(it==s.end())
            fout<<"0\n";
        else
            fout<<"1\n";

    }
    return 0;
}
