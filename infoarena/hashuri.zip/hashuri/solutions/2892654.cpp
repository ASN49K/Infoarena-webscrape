#include <bits/stdc++.h>

using namespace std;

ifstream in ("hashuri.in");
ofstream out ("hashuri.out");

int n,opcode,x,prim=50647;

vector <int> hashtab[50647];

void adauga(int x)
{
    int poz = x%prim,i;

    for (i = 0; i < hashtab[poz].size(); i++)
        if (x == hashtab[poz][i])   break;

    if (i == hashtab[poz].size()) hashtab[poz].push_back(x);
}

void sterge(int x)
{
    int poz = x%prim;

    for (int i = 0; i < hashtab[poz].size(); i++)
        if (x == hashtab[poz][i]) hashtab[poz][i] = -1;
}

bool gaseste(int x)
{
    int poz = x%prim;

    for (int i = 0; i < hashtab[poz].size(); i++)
        if (hashtab[poz][i] == x)   return 1;

    return 0;
}

int main()
{
    in>>n;

    for (int i = 0; i < n; i++)
    {
        in>>opcode>>x;

        switch (opcode)
        {
            case 1:
                adauga(x);
                break;

            case 2:
                sterge(x);
                break;

            case 3:
                out<<gaseste(x)<<"\n";
                break;
        }
    }

    return 0;
}
