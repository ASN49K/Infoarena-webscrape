#include <iostream>
#include <fstream>
#define MOD 666013
using namespace std;

struct nod{
    int inf;
    nod *leg;
}*H[MOD];
ofstream g;

void stergere(int x){
    int ind=x%MOD;
    nod *p, *u;
    p=u=H[ind];
    if (H[ind])
        if (H[ind]->inf==x) H[ind]=H[ind]->leg;
        else{
            while (p && p->inf!=x){
                u=p; p=p->leg;
            }
            u->leg=p->leg;
        }
}

void afisare(int x){
    nod *p;
    int ind=x%MOD;
    p=H[ind];
    bool ok=false;
    while (p){
        if (p->inf==x) ok=true;
        p=p->leg;
    }
    if (ok==true) g << "1" << '\n';
    else g << "0" << '\n';
}

int main()
{
    int op, ind;
    long long n, x;
    nod *p;
    ifstream f ("hashuri.in");
    g.open("hashuri.out");
    f >> n;
    for (int i=1; i<=n; i++){
        f >> op >> x;
        ind=x%MOD;
        if (op==1){
            p=new nod;
            p->inf=x;
            p->leg=H[ind];
            H[ind]=p;
        }
        else
            if (op==2) stergere(x);
            else afisare(x);
    }
    g.close();
    f.close();
}
