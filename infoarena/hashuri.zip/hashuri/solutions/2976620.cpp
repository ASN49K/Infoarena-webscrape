#include <fstream>
#include <unordered_map>
 
using namespace std;
 
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
 
unordered_map<int, bool> Hash;
int n, x, y;
 
int main() {
    fin >> n;
    for(int i = 1; i <= n; i++) {
        fin >> x >> y;
        if(x == 1) {
            Hash[y] = true;
        } else if(x == 2) {
            Hash.erase(y);
        } else if(x == 3) {
            fout << (Hash.find(y) != Hash.end()) << "\n";
        }
    }
    fin.close();
    fout.close();
    return 0;
}