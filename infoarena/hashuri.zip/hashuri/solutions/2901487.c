#include <stdio.h>
#include <stdlib.h>

const int mod = 702113;

typedef struct _lista {
    int val;
    struct _lista *next;
    struct _lista *prev;
} lista;

lista **v;  ///pointeri la primul element al fiecareia dintre cele 'mod' liste

lista *my_find(int nr, int *poz) {
    *poz = nr % mod;
    for (lista *it = v[*poz]; it != NULL; it=it->next) {
        if (it->val == nr)
            return it;
    }
    return NULL;
}

void adauga(int nr) {
    int poz;
    lista *it = my_find(nr, &poz);
    if (it == NULL) {
        lista *new_elem = (lista *) malloc(sizeof(lista));
        new_elem->val = nr;
        new_elem->prev = NULL;
        new_elem->next = v[poz];
        if (v[poz] != NULL)
            v[poz]->prev = new_elem;
        v[poz] = new_elem;
    }
}

void sterge(int nr) {
    int poz;
    lista *it = my_find(nr, &poz);
    if (it != NULL) {
        if (it->prev != NULL) ///daca elem sters are altul inaintea sa
            it->prev->next = it->next;
        if (it->next != NULL) ///daca elem sters are altul dupa el
            it->next->prev = it->prev;
        if (v[poz] == it) ///daca elementul sters e primul
            v[poz] = it->next;
        free(it);
    }
}

int gasete(int nr) {
    int poz;
    lista *it = my_find(nr, &poz);
    return it != NULL;
}

int main() {
    FILE *fin, *fout;
    fin = fopen("hashuri.in", "r");
    fout = fopen("hashuri.out", "w");
    int op, nr, n;
    v = (lista **) calloc(mod, sizeof(lista));

    fscanf(fin, "%d", &n);

    for (int i = 0; i < n; i++) {
        fscanf(fin, "%d%d", &op, &nr);
        switch (op) {
            case 1:
                adauga(nr);
                break;
            case 2:
                sterge(nr);
                break;
            default:
                fprintf(fout, "%d\n", gasete(nr));
                break;
        }
    }
    fclose(fin);
    fclose(fout);
    free(v);
    return 0;
}
