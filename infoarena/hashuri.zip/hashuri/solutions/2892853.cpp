#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
int main()
{
    int prime_number = 69313, n, op, val, pos;
    vector<vector<int>>v(prime_number);
    fin >> n;
    for(int i = 1; i <=n; i++)
    {
        fin >> op >> val;
        pos = val % prime_number;
        if(op == 1)
        {
            bool found = false;
            for(auto index = v[pos].begin(); index != v[pos].end(); index++)
                if(*index == val)
                {
                    found = true;
                    break;
                }
            if(!found)
                v[pos].push_back(val);
        }
        else if(op == 2)
        {
            for(auto index = v[pos].begin(); index != v[pos].end(); index++)
                if(*index == val)
                {
                    v[pos].erase(index);
                    break;
                }
        }
        else
        {
            bool found = false;
            for(auto index = v[pos].begin(); index != v[pos].end(); index++)
                if(*index == val)
                {
                    fout << 1 << '\n';
                    found = true;
                    break;
                }
            if(!found)
                fout << 0 << '\n';
        }
    }
    return 0;
}
