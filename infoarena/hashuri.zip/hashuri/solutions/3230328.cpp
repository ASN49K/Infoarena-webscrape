#include <fstream>
#include <unordered_map>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

int n;
unordered_map<int, int> a;

int main()
{
    f >> n;
    for(int i = 1; i <= n; i ++)
    {
        int op, x; f >> op >> x;

        if(op == 1)
            a[x] ++;

        else if(op == 2 && a[x])
            a[x] --;

        else if(op == 3)
            g << (a[x] > 0) << '\n';
    }
    return 0;
}
