#include <iostream>
#include <vector>

using namespace std;


const int N = 1000033;

vector<int> hashTable[N + 1];

inline int getHash(int x)
{
    return x % N;
}

inline void addElement(int num)
{
    hashTable[getHash(num)].push_back(num);
}


void eraseElement(int num)
{
    vector<int> element = hashTable[getHash(num)];
    for (auto i = element .begin(); i != element .end(); ++i)
    {
        if (*i == num)
        {
            element.erase(i);
            break;

        }
    }
    hashTable[getHash(num)] = element;
}


int findElement(int num)
{
    vector<int> element = hashTable[getHash(num)];
    for (auto i = element .begin(); i != element .end(); ++i)
    {
        if (*i == num)
        {
     return 1;
        }
    }    return 0;
}

int main()
{
//    666013

    int op, x, n;



    freopen("hashuri.in", "r", stdin);
    freopen("hashuri.out", "w", stdout);

    cin >> n;
    for ( int i = 0 ; i < n ; i++)
    {

        cin >> op >> x;
        if(op == 1)
        {
            addElement(x);
            continue;
        }

        else if ( op ==2 )
        {
            eraseElement(x);
            continue;
        }
        else
            cout <<findElement(x) << endl ;
    }



    return 0;
}
