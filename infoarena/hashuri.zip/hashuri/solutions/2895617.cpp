#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f ("hashuri.in");
ofstream g ("hashuri.out");
long long n, val;
vector<long long> v[319133];
int op;
int verifica(long indice, long long valoare) {
    if(v[indice].size() == 0) return -1;
    for(long i = 0; i < v[indice].size(); i++)
        if (v[indice][i] == valoare)
            return i;
    return -1;

}
int main()
{
    long long prim = 319133;
    f >> n;
    long long i;
    for(i = 0; i < n; i++)
    {
        f >> op;
        if(op == 1) {
            f >> val;
            if(verifica((prim % val), val) == -1)
                v[prim % val].push_back(val);
        }
        if(op == 2) {
            f >> val;
            if(verifica(prim % val, val) != -1) {
              //  for(long long j = 0; j < v[prim % val].size(); j++)
                //    if(v[prim % val][j] == val)
                  //      cout << "L-am gasit pe fraier " << val << " "<< (prim%val) << " " << j << '\n' ;
                long poz = verifica(prim % val, val);
                v[prim%val].erase(v[prim%val].begin() + poz);
            }
        }
        if(op == 3) {
            f >> val;
            if(verifica(prim % val, val) == -1)
                g << 0 << '\n';
            else
                g << 1 << '\n';
    }
    }
    return 0;
}
