#include <bits/stdc++.h>

using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
unordered_set<int> M;
int n,o,v;
int main()
{
    f>>n;
    for(int i=1;i<=n;i++)
    {
        f>>o>>v;
        if(o==1)
            M.insert(v);
        else if(o==2)
            M.erase(v);
        else if(M.find(v)==M.end())
            g<<"0\n";
        else
            g<<"1\n";
    }
    return 0;
}
