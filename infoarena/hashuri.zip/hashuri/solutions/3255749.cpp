#include <bits/stdc++.h>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");


int n, a, b;
vector<int> v[1000000];

int h(int x)
{
    return x%7919;
    //7919
}

int main()
{
    f>>n;
    for(int i=1;i<=n;i++)
    {
        f>>a>>b;
        int hs=h(b);
        if(a==1)
        {
            v[hs].push_back(b);
        }
        if(a==2)
        {
            if(!v[hs].empty())
            {
                for(int i=0;i<v[hs].size();i++)
                {
                    if(v[hs][i]==b)
                        v[hs].erase(v[hs].begin()+(i-1));
                }
            }
        }
        if(a==3)
        {
            int ok=0;
            if(!v[hs].empty())
            {
                for(int i=0;i<v[hs].size();i++)
                {
                    if(v[hs][i]==b)
                        ok=1;
                }
            }
            g<<ok<<endl;
        }
    }


    return 0;
}
