#include <fstream>
#include <vector>
#include <algorithm>
#define mod 987712
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector <int> l[mod];
vector <int>::iterator it;

int main()
{
    int n, t, x, i, ok, poz;
    fin>>n;
    while(n)
    {
        n--;
        fin>>t>>x;
        poz=x%mod;
        it=find(l[poz].begin(), l[poz].end(), x);
        ok=0;
        if(it!=l[poz].end())
        {
            ok=1;
        }
        if(t==1)
        {
            if(ok==0)
            {
                l[poz].push_back(x);
            }
        }
        else
        if(t==2)
        {
            if(ok==1)
            {
                l[poz].erase(it);
            }
        }
        else
        {
            fout<<ok<<"\n";
        }
    }
}
