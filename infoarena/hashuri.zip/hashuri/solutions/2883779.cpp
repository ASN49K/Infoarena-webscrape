#include <fstream>
#include <vector>
#define M 666013
using namespace std;
ifstream f("hashuri.in"); ofstream g("hashuri.out");
vector <int> H[M];
inline vector <int> :: iterator cauta(int x)
{   int r=x%M;
    vector <int> :: iterator it=H[r].begin(), sf=H[r].end();
    for(; it !=sf ; it++)
        if(*it==x) return it;
    return sf;
}
inline void adaug(int x)
{   int r=x%M;
    if(cauta(x)==H[r].end()) H[r].push_back(x);
}
inline void sterg(int x)
{   int r=x%M;
    vector <int> :: iterator it=cauta(x);
    if(it!=H[r].end()) H[r].erase(it);
}
int main()
{   int tip,x,t;
    f>>t;
    while(t--)
    {   f>>tip>>x;
        switch(tip)
        {   case 1 : adaug(x); break;
            case 2 : sterg(x); break;
            case 3 : if(cauta(x) == H[x % M].end()) g<<"0\n"; else g<<"1\n";
        };
    }
    g.close(); return 0;
}
