#include <bits/stdc++.h>

using namespace std;

ifstream fin( "hashuri.in" );
ofstream fout( "hashuri.out" );

const int MOD = 777013;

vector<int> vals[MOD];

int find( int val, int h ) {
  int i = 0;
  while ( i < (int)vals[h].size() && vals[h][i] != val ) {
	++i;
  }
  return (i >= (int)vals[h].size() ? -1 : i);
}

int main() {
  ios_base::sync_with_stdio(0);
  fin.tie(0);
  int n, tp, x;

  fin >> n;
  while ( n-- ) {
	fin >> tp >> x;
	int h = x % MOD;
	if ( tp == 1 ) {
	  if ( find(x, h) == -1 ) {
		vals[h].push_back(x);
	  }
	} else if ( tp == 2 ) {
	  int pos = find(x, h);
	  if ( pos != -1 ) {
	    vals[h][pos] = vals[h].back();
		vals[h].pop_back();
	  }
	} else {
	  fout << (find(x, h) != -1 ? "1\n" : "0\n");
	}
  }
  fin.close();
  fout.close();
  return 0;
}
