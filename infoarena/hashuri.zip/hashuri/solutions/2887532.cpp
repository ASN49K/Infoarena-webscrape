#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

#define k 666013

vector <int> hashh[k+3];

int main()
{
int n, i, j, x, y, cls, ok, poz;

f>>n;

for(i = 1; i <= n; i++)
    {

    f>>y>>x;
    ok = 0;
    cls = x %k;
    for(j = 0; j<hashh[cls].size(); j++)
    {
            if(hashh[cls][j] == x)
            {
                ok = 1;
                poz = j;
                break;
            }
    }
    if(y == 1)
    {
        if(ok == 0)

            hashh[cls].push_back(x);
    }
    else
    {
    if(y == 2)
    {
        if(ok == 1)
        {
            swap(hashh[cls][j],hashh[cls].back());
            hashh[cls].pop_back();
        }

    }
    else
        {
        g<<ok<<'\n';

    }}

}
    return 0;
}
