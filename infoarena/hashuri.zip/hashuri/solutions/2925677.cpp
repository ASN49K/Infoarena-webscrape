#include<bits/stdc++.h>
using namespace std;
ifstream F("hashuri.in");
ofstream G("hashuri.out");
#define M 666013
int n,o,x;
set<int> g[M];
int main()
{
    for(F>>n;n--;)
        if(F>>o>>x,o==1)
            g[x%M].insert(x);
        else if(o==2)
            g[x%M].erase(x);
        else
            G<<(g[x%M].find(x)!=g[x%M].end())<<'\n';
    return 0;
}
