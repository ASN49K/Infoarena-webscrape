#include <fstream>
using namespace std;

class Hash {

private:
    class Node
    {
    public:
        int val = -1;
        Node* urm = NULL;
    };
    Node* hash[87129];

public:
    Hash() {
        for (int i = 0; i < 87129; i++)
            hash[i] = nullptr;
    }

    void insert(int val) {
        int index = val % 87129;
        if (hash[index] == nullptr) {
            hash[index] = new Node;
            hash[index]->val = val;
        }
        else {
            Node* ptr = hash[index];
            while (ptr->urm != nullptr && ptr->val != val)
                ptr = ptr->urm;
            if (ptr->val != val) {
                ptr->urm = new Node;
                ptr->urm->urm = nullptr;
                ptr->urm->val = val;
            }
        }
    }

    void remove(int val) {
        int index = val % 87129;
        Node* ptr;
        if (hash[index] != nullptr && hash[index]->val == val) {
            ptr = hash[index]->urm;
            delete hash[index];
            hash[index] = ptr;
        }
        else if (hash[index] != nullptr && hash[index]->val != val && hash[index]->urm != nullptr) {
            ptr = hash[index];
            int ok = 0;
            while (ptr->val != val && ptr->urm != nullptr) {
                if (ptr->urm->val == val) {
                    ok = 1;
                    break;
                }
                ptr = ptr->urm;
            }
            if (ok == 1) {
                Node* ptr2 = ptr->urm->urm;
                delete ptr->urm;
                ptr->urm = ptr2;
            }
        }
    }

    int find(int val) {
        int index = val % 87129;
        Node* ptr = hash[index];
        while (ptr != nullptr && ptr->val != val)
            ptr = ptr->urm;
        if (ptr != nullptr)
            return 1;
        return 0;
    }

    
};

int main() {
    ifstream in("hashuri.in");
    ofstream out("hashuri.out");

    int op, val, n, ok = 0;
    Hash tabela;

    in >> n;


    for (int i = 1; i <= n; i++)
    {
        in >> op >> val;

        if (op == 1) {
            tabela.insert(val);
        }
        else if (op == 2) {
            tabela.remove(val);
        }
        else if (op == 3) {
            if (ok) {
                out << '\n';
            }
            out << tabela.find(val);
            ok = 1;
        }



    return 0;
}