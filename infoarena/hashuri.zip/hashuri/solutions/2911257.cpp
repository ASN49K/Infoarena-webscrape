#include <bits/stdc++.h>
using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

unordered_set<int> s;
int n, x;
int16_t op;

int main()
{
    f >> n;
    for (; n; n--)
    {
        f >> op >> x;
        if (op == 1) s.insert(x);
        else if (op == 2) s.erase(x);
        else {
            if(s.find(x) == s.end()) g << "0\n";
            else g<<"1\n";
        }
    }
    
    
    return 0;
}
