#include <bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

struct CustomHash
{
    long long splitmix64(long long x)
    {
        x += 0x9e3779b97f4a7c15;
        x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;
        x = (x ^ (x >> 27)) * 0x94d049bb133111eb;
        return x ^ (x >> 31);
    }

    int operator()(long long x)
    {
        static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();
        return splitmix64(x + FIXED_RANDOM);
    }
};

class Hash
{
public:
    const int n = (1<<16) - 1;
    vector<int> *H;
    vector<string> *Hs;
    vector<string> *Prefix;

    Hash()
    {
        H = new vector<int>[n];
        //Hs = new vector<string>[n];
        //Prefix = new vector<string>[n];
    }
    int Modulo(int x)
    {
        CustomHash hasher;
        return (hasher(x) % n + n) % n;
    }

    int Modulo_String(string x)
    {
        int i;
        long long p, nr;
        nr = 0;
        p = 1;
        for (i = 0; x[i] != 0; i++)
        {
            nr = (nr + (x[i] - 'a' + 1) * p) % n;
            p = (p * 137) % n;
        }
        return nr;
    }

    void Insert(int x)
    {
        int index = Modulo(x);
        H[index].push_back(x);
    }

    void Insert_String(string x)
    {
        int index = Modulo_String(x);
        Hs[index].push_back(x);
    }

    void Delete(int x)
    {
        int index = Modulo(x);
        const int lg = H[index].size();
        for (int i = 0; i < lg; i++)
        {
            if (H[index][i] == x)
            {
                H[index][i] = H[index].back();
                H[index].pop_back();
                return;
            }
        }
    }

    void Delete_String(string x)
    {
        int index = Modulo_String(x);
        const int lg = H[index].size();
        for (int i = 0; i < lg; i++)
        {
            if (Hs[index][i] == x)
            {
                Hs[index][i] = Hs[index].back();
                Hs[index].pop_back();
                return;
            }
        }
    }

    void Delete_Prefix(string x)
    {
        string s;
        int i;
        long long p, nr;
        nr = 0;
        p = 1;
        for (i = 0; x[i] != 0; i++)
        {
            nr = (nr + (x[i] - 'a' + 1) * p) % n;
            p = (p * 137) % n;
            s.push_back(x[i]);
            const int lg = Prefix[nr].size();
            for(int j = 0; j < lg; j++)
                if(Prefix[nr][j] == s)
                {
                    Prefix[nr][j] = Prefix[nr].back();
                    Prefix[nr].pop_back();
                    break;
                }
        }
    }

    void Afisare()
    {
        for (int i = 0; i < n; i++)
        {
            if (!H[i].empty())
            {
                cout << "Index " << i << ": ";
                for (int val : H[i])
                    cout << val << " ";
                cout << "\n";
            }
        }
    }

    bool Find(int x)
    {
        int index = Modulo(x);
        for (int val : H[index])
            if (val == x) return true;
        return false;
    }

    bool Find_String(string x)
    {
        int index = Modulo_String(x);
        for (const string &s : Hs[index])
            if (s == x) return true;
        return false;
    }

    bool Find_Prefix(string x)
    {
        int index = Modulo_String(x);
        for (const string &s : Prefix[index])
            if (s == x) return true;
        return false;
    }

    virtual void Add_Prefix(string x)
    {
        string s;
        int i;
        long long p, nr;
        nr = 0;
        p = 1;
        for (i = 0; x[i] != 0; i++)
        {
            nr = (nr + (x[i] - 'a' + 1) * p) % n;
            p = (p * 137) % n;
            s.push_back(x[i]);
            Prefix[nr].push_back(s);
        }
    }

    void Find_Longest_Prefix(string x)
    {
        string s, aux;
        int i, lg;
        long long p, nr;
        nr = lg = 0;
        p = 1;
        aux = x;
        for (i = 0; x[i] != 0; i++)
        {
            nr = (nr + (x[i] - 'a' + 1) * p) % n;
            p = (p * 137) % n;
            s.push_back(x[i]);
            if (!Prefix[nr].empty() && Find_Prefix(s))
            {
                lg = i + 1;
                aux = s;
            }
        }
        cout << aux << " ";
    }
};

class Hashuri : public Hash
{
public:
    Hashuri() : Hash()
    { }
    void Rezolvare()
    {
        int op, n, i, x;
        fin >> n;
        for(i=1; i<=n; i++)
        {
            fin >> op >> x;
            if(op == 1) Insert(x);
            else if(op == 2) Delete(x);
            else fout << Find(x)  << "\n";
        }
    }
};

int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    Hashuri A;
    A.Rezolvare();
    fin.close();
    fout.close();
    return 0;
}
