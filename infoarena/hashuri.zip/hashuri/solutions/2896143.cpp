#include <iostream>
#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
int main()
{

    set <int> hasht;

    int n, x, i;

    f>>n;

    for(i=0;i<n;i++)
    {
        f>>x;
        if(x==1)
        {
            f>>x;
            hasht.insert(x);
        }
        else if(x==2)
        {
            f>>x;
            if(hasht.count(x))
                hasht.erase(x);
        }
        else if(x==3)
        {
            f>>x;
            g<<hasht.count(x)<<endl;
        }
    }
}
