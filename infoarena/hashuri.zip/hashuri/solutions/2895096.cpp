#include <fstream>
#include <list>
#include <vector>

using namespace std;

const int hash_size = 3145739;		// intre 2^21 si 2^22

int hash_function(long long x)
{
	return x % hash_size;
}

int main()
{
	ifstream f("hashuri.in");
	ofstream g("hashuri.out");
	int nr_operatii;
	f >> nr_operatii;
	long long tip_operatie, valoare;
	vector<list<int>> hash(hash_size);
	int hash_value;
	for (int i = 0; i < nr_operatii; i++)
	{
		f >> tip_operatie >> valoare;
		hash_value = hash_function(valoare);
		if (tip_operatie == 1)
		{
			for (auto const& iterator : hash[hash_value])
				if (iterator == valoare)
					break;
			hash[hash_value].push_back(valoare);
		}
		else if (tip_operatie == 2)
		{
			hash[hash_value].remove(valoare);
		}
		else if (tip_operatie == 3)
		{
			int found = 0;
			for (auto const& iterator : hash[hash_value])
				if (iterator == valoare)
				{
					g << 1 << endl;
					found = 1;
					break;
				}
			if (!found)
				g << 0 << endl;
		}
	}
}