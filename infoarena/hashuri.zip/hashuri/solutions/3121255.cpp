#include <fstream>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

const int MOD_MAX = 666013;
const int N_MAX = 1e6;

class HashTable {
private:
		const int NIL = -1;
		int head[MOD_MAX];
		int key[N_MAX];
		int nxt[N_MAX];
		int mod;
		int curr;

public:
		HashTable(int x) {
			mod = x;

			curr = 0;
			for(int i = 0; i < mod; ++i)
				head[i] = NIL;
			for(int i = 0; i < N_MAX; ++i)
				nxt[i] = NIL;
		}

		int getkey(int x) {
			while(x < 0) x += mod;
			return x % mod;
		}

		void add(int x) {
			int list = getkey(x);
			key[curr] = x;
			nxt[curr] = head[list];
			head[list] = curr;
			++curr;
		}

		bool find(int x) {
			int list = getkey(x);
			int it = head[list];
			while(it != NIL && key[it] != x)
				it = nxt[it];

			return it != NIL;
		}

		void erase(int x) {
			int list = getkey(x);
			int ant = head[list], it = nxt[ant];
			if(key[ant] == x){
				head[list] = nxt[ant];
			}else{
				while(it != NIL && key[it] != x){
					ant = it;
					it = nxt[it];
				}

				if(it != NIL){
					nxt[ant] = nxt[it];
				}
			}
		}

};

HashTable ht(MOD_MAX);

int main() {
	int n, type, x;

	fin >> n;

	for(int i = 0; i < n; ++i){
		fin >> type >> x;

		switch(type){
			case 1:
				if(!ht.find(x))
					ht.add(x);
				break;
			case 2:
				ht.erase(x);
				break;
			case 3:
				fout << ht.find(x) << '\n';
				break;
			default:
				fout << "TIPUL OPERATIEI ESTE GRESIT\n";
		}
	}

	fin.close();
	fout.close();
	return 0;
}