#include <bits/stdc++.h>

using namespace std;

const int value = 666013;
int n;
vector<int> H[value];

void insert(int x){

    int aux = x % value;
    auto elem = find(H[aux].begin(), H[aux].end(), x);
    if(elem == H[aux].end())
        H[aux].push_back(x);
}

void erase(int x){
    int aux = x % value;
    auto elem = find(H[aux].begin(), H[aux].end(), x);

    if(elem != H[aux].end())
        H[aux].erase(elem);
}

bool find(int x){
    int aux = x % value;
    return find(H[aux].begin(), H[aux].end(), x) != H[aux].end();
}

int main(){

    ifstream f("hashuri.in");
    ofstream g("hashuri.out");

    f >> n;

    for(int i = 1; i <= n; ++i){
        int op, x;

        f >> op >> x;

        if(op == 1)
            insert(x);
        else if(op == 2)
            erase(x);
        else
            g << find(x) << '\n';
    }

    f.close();
    g.close();

    return 0;
}