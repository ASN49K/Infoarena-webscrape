#include <bits/stdc++.h>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

vector<int> h;

int main()
{
    int n;
    f>>n;
    for(int i=1;i<=n;i++)
    {
        int o,x;
        f>>o>>x;
        if(o==1) h.push_back(x);
        else if(o==2 && find(h.begin(), h.end(), x) != h.end()) h.erase(find(h.begin(), h.end(), x));
        else if(o==3)
            {
                if(find(h.begin(), h.end(), x) == h.end())
                    g<<"0"<<'\n';
                else
                    g<<"1"<<'\n';
            }
    }
}