#include <bits/stdc++.h>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
int n, a, x, i;

unordered_map<int, int> d;
int main()
{
    f>>n;
    for (i=0; i<n; i++)
    {

        f >> a >> x;
        if ( a==1 )
        {
            if ( d.find(x)==d.end())
                d[x]=1;
        }
        else if ( a==2 )
        {
                d.erase(x);
        }
        else if ( a==3 )
        {

            if ( d.find(x)!=d.end())
                g << 1 << endl;
            else
                g << 0 << endl;
        }
    }
    return 0;
}
