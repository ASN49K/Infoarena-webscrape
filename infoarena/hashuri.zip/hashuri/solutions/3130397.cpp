#include <iostream>
#include <fstream>
#include <map>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");

int main()
{
    int N, op, x, i;
    //folosim un dictionar ca sa retinem datele despre valori
    //in dictionar vor fi stocate valorile 1 pentru cazul in care valoarea a fost adaugata
    //si 1 pentru cazul in care valoarea nu a fost adaugata
    map<int, int> dictionar;
    f>>N;
    for (i=0; i<N; i++)
    {

        f >> op >> x;
        if ( op==1 ) //operatia de 'inserare'
        {
            if ( dictionar.find(x)==dictionar.end())
                dictionar[x]=1;
        }
        else if ( op==2 )  //operatia de 'stergere'
        {
                dictionar.erase(x);
        }
        else if ( op==3 ) //operatia de 'cautare'
        {

            if ( dictionar.find(x)!=dictionar.end())
                g << 1 << endl;
            else
                g << 0 << endl;
        }
    }
    f.close();
    g.close();
    return 0;
}
