#include <bits/stdc++.h>

using namespace std;

#define INFILE "hashuri.in"
#define OUTFILE "hashuri.out"

const int MOD = 393241;

vector<int> fr[MOD];

bool exists(int number){
    int group = number % MOD;
    return count(fr[group].begin(), fr[group].end(), number) > 0;
}

void insert(int number){
    if(!exists(number)){
        int group = number % MOD;
        fr[group].push_back(number);
    }
}

void erase(int number){
    int group = number % MOD;
    auto it = find(fr[group].begin(), fr[group].end(), number);
    if(it != fr[group].end()) fr[group].erase(it);
}

void solve(){

    int queries; cin >> queries;
    while(queries--){
        int type, number; cin >> type >> number;
        if(type == 1) insert(number);
        else if(type == 2) erase(number);
        else cout << exists(number) << '\n';
    }

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);
    solve();
    return 0;
}
