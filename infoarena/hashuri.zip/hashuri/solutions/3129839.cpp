#include <fstream>
#include <iostream>
#include <queue>
#include <unordered_map>

std::ifstream in;
std::ofstream out;

struct listInlt{
    int key;
    listInlt* next;

    listInlt(int x){
        key = x;
        next = nullptr;
    }
};

class listI{
    listInlt* l;
public:
    listI(){ l = nullptr; }
    listInlt* end(){
        listInlt * aux = l;
        if(!aux)
            return nullptr;
        while(aux->next)
            aux = aux->next;
        return aux;
    }
    void addValue(int x){
        listInlt * aux = listI::end();
        listInlt * newValue;
        newValue = new listInlt(x);
        if(!l)
            l = newValue;
        else
            aux->next = newValue;
    }
    void deleteValue(int x){
        listInlt * aux = l;
        if(l and l->key == x and !l->next){
            l = nullptr;
            return;
        }
        while(aux and aux->next and aux->next->key != x)
            aux = aux->next;
        if(!aux or !aux->next)
            return;
        if(aux->next->key == x){
            aux->next = aux->next->next;
        }
    }
    bool findValue(int x){
        listInlt * aux = l;
        while(aux and aux->key != x)
            aux = aux->next;
        if(!aux)
            return false;
        if(aux->key == x)
            return true;
        return false;
    }
};

int main() {
    int n, op, x;
    std::vector<listI> v(666013);

    in.open("hashuri.in");
    out.open("hashuri.out");
    in>>n;
    while(n>0){
        in>>op>>x;
        if(op == 1){
            v[x%666013].addValue(x);
        }
        else if(op == 2){
            v[x%666013].deleteValue(x);
        }
        else if(op == 3){
            out<<v[x%666013].findValue(x)<<'\n';
        }
        n--;
    }

    in.close();
    out.close();

    return 0;
}
