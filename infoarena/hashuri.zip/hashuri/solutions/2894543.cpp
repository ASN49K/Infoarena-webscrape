#include <fstream>
#include <vector>
#include <algorithm>
#define p 666013

std::vector<int> hash[p];

int main()
{
    std::ifstream fin("hashuri.in");
    std::ofstream fout("hashuri.out");

    int n;
    fin >> n;

    for (int i = 0; i < n; ++i) {
        int op, x;
        fin >> op >> x;
        if (op == 1) hash[x % p].push_back(x);
        else if (op == 2 && std::find(hash[x % p].begin(), hash[x % p].end(), x) != hash[x % p].end()) hash[x % p].erase(std::find(hash[x % p].begin(), hash[x % p].end(), x));
        else if (op == 3) {
            if (std::find(hash[x % p].begin(), hash[x % p].end(), x) != hash[x % p].end()) fout << 1 << '\n';
            else fout << 0 << '\n';
        }
    }

    return 0;
}