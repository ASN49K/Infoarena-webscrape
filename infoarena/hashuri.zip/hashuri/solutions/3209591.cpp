#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int multime[1000000];

int main()
{
    int N, c, n;
    fin>>N;
    for(; N>0; N--){
        fin>>c>>n;
        if(c==1) multime[n] = 1;
        if(c==2) multime[n] = 0;
        if(c==3) fout<<multime[n]<<'\n';
    }
    return 0;
}
