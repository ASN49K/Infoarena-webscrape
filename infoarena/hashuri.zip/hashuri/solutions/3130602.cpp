#include <fstream>
#include <vector>
#include <iostream>

#define PRIME_NUMBER 72227

std::ifstream input_file("hashuri.in");
std::ofstream output_file("hashuri.out");
std::vector<int> hashtable[PRIME_NUMBER];

void delete_number(int poz,int number) {
  std::vector<int>& bucket=hashtable[number%PRIME_NUMBER];
  bucket.erase(bucket.begin()+poz);
}

int main(){
  int n,operation,number;
  bool in_set;
  input_file>>n;

  for(int i=0;i<n;i++){
    input_file>>operation>>number;

    if(operation==1){
      hashtable[number%PRIME_NUMBER].push_back(number);
    }
    else if(operation==2){
      for(int j=0;j<hashtable[number%PRIME_NUMBER].size();j++){
        if(hashtable[number%PRIME_NUMBER][j]==number)
          delete_number(j,number);
      }
    }
    else{
      in_set=false;
      for(int j=0;j<hashtable[number%PRIME_NUMBER].size() && !in_set;j++){
        if(hashtable[number%PRIME_NUMBER][j]==number){
          in_set=true;
        }
      }
      if(in_set){
        output_file<<"1\n";
      }     
      else{
        output_file<<"0\n";
      }
    }
  }

  return 0;
}