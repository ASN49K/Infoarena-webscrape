#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

FILE *fin, *fout;

const int MOD = 666013;
const int B = 31;

vector <int> Hash[MOD + 5];

int hashf(int nr)
{
    int P = 0, b = B;

    while(nr)
    {
        int last = nr % 10;

        P += ((last * (b % MOD)) % MOD);

        b = (((b % MOD) * (b % MOD)) % MOD);

        nr /= 10;
    }

    return P;
}

int main()
{
    fin = fopen("hashuri.in", "r");
    fout = fopen("hashuri.out", "w");

    int n;
    fscanf(fin, "%d", &n);

    for(int i = 1; i <= n; i++)
    {
        int op, nr;
        fscanf(fin, "%d%d", &op, &nr);

        if(op == 1)
        {
            Hash[hashf(nr)].push_back(nr);
        }
        else if(op == 2)
        {
            int P = hashf(nr);

            auto it = find(Hash[P].begin(), Hash[P].end(), nr);

            if(it != Hash[P].end())
            {
                Hash[P].erase(it);
            }
        }
        else if(op == 3)
        {
            int P = hashf(nr);

            if(find(Hash[P].begin(), Hash[P].end(), nr) != Hash[P].end())
                fprintf(fout, "%d\n", 1);
            else fprintf(fout, "%d\n", 0);
        }
    }

    fclose(fin);
    fclose(fout);
    return 0;
}
