#include <bits/stdc++.h>

using namespace std;

ifstream in ("hashuri.in");
ofstream out ("hashuri.out");

int n,op,x,p=700001;
vector<int>v[700001];

void op1(int x){
    for (auto i:v[x%p]){
        if (i==x) return;
    }
    v[x%p].push_back(x);
}

void op2(int x){
    for (int i=0; i<v[x%p].size(); i++){
        if (v[x%p][i]==x){
            v[x%p].erase(v[x%p].begin()+i);
            return;
        }
    }
}

int op3(int x){
    for (auto i:v[x%p]){
        if (i==x) return 1;
    }
    return 0;
}

int main()
{
    in>>n;
    for (int i=1; i<=n; i++){
        in>>op>>x;
        if (op==1) op1(x);
        else if (op==2) op2(x);
        else out<<op3(x)<<'\n';
    }
}
