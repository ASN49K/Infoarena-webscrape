#include <fstream>
#include <set>
std::ifstream fin("hashuri.in");
std::ofstream fout("hashuri.out");
const int MOD = 100000;
std::set <int> h;
int main() {
    int n, x;
    char op;
    fin >> n;
    while (n) {
        -- n;
        fin >> op >> x;
        switch (op) {
            case '1': {
                h.insert(x);
                break;
            }
            case '2': {
                h.erase(x);
                break;
            }
            case '3': {
                if (h.find(x) != h.end())
                    fout << 1 << '\n';
                else
                    fout << 0 << '\n';
            }
        }
    }
    return 0;
}
