#include <bits/stdc++.h>
#define NMAX 1000000
#define MOD 1000003
using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

struct element
{
    int val, next;
};

int pos_last[MOD], idx=0;
element v[NMAX+1];

bool find(int x)
{
    int mod=x%MOD;
    for(int pos=pos_last[mod]; pos!=0; pos=v[pos].next)
    {
        if(v[pos].val==x) return 1;
    }
    return 0;
}

void insert(int x)
{
    int mod=x%MOD;
    if(find(x)) return;
    idx++;
    v[idx].val=x;
    v[idx].next=pos_last[mod];
    pos_last[mod]=idx;
}

void erase(int x)
{
    int mod=x%MOD;
    for(int pos=pos_last[mod]; pos!=0; pos=v[pos].next)
    {
        if(v[pos].val==x)
        {
            swap(v[pos].val, v[pos_last[mod]].val);
            pos_last[mod]=v[pos_last[mod]].next;
            break;
        }
    }
}

int main()
{
    int n;
    in >> n;
    for(int i=1; i<=n; i++)
    {
        int op, x;
        in >> op >> x;
        if(op==1) insert(x);
        if(op==2) erase(x);
        if(op==3) out << find(x) << "\n";
    }

    return 0;
}
