#include<bits/stdc++.h>
using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");

vector <vector <int>> hashh;
int p = 116351, k, c, val, x;

void ins(int x, int val)
{
    for(int j = 0; j < hashh[x].size(); j++)
        if(hashh[x][j] == val)
            return;
    hashh[x].push_back(x);
}

void del(int x)
{
    for(int j = 0; j < hashh[x].size(); j++)
        if(hashh[x][j] == val)
        {
            hashh[x].erase(hashh[x].begin() + j);
            break;
        }
}

void search(int x, int val)
{
    for(int j = 0; j < hashh[x].size(); j++)
        if(hashh[x][j] == val)
        {
            out << 1 << endl;
            return;
        }
    out << 0 << endl;
}

int main()
{
    in >> k;
    for(int i = 1; i <= k; i++)
    {
        in >> c >> val;
        x = val % p;
        while(hashh.size() <= x)
            hashh.push_back({});
        switch(c)
        {
        case 1:
        {
            ins(x, val);
            break;
        }
        case 2:
        {
            del(x);
            break;
        }
        case 3:
        {
            search(x, val);
            break;
        }
        }
    }
    return 0;
}
