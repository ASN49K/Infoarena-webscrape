#include <bits/stdc++.h>

using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
int q;
unordered_set<int> M;
int main()
{
    f>>q;
    for(;q;q--)
    {
        int t,v;
        f>>t>>v;
        if(t==1)
            M.insert(v);
        else if(t==2)
            M.erase(v);
        else if(M.find(v)==M.end())
            g<<"0\n";
        else
            g<<"1\n";
    }
    return 0;
}
