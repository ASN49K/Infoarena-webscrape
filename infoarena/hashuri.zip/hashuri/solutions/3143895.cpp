#include <iostream>
#include <set>

using namespace std;

set <int> harta;

int main()
{
    FILE *fin, *fout;
    int i,n,op,x;
    fin=fopen("hashuri.in", "r");
    fscanf(fin, "%d", &n);
    fout=fopen("hashuri.out", "w");
    for(i=0; i<n; i++){
      fscanf(fin, "%d%d", &op, &x);
      if(op==1){
        if(!harta.count(x))
          harta.insert(x);
      }
      else if(op==2){
        if(harta.count(x))
          harta.erase(x);
      }
      else{
        fprintf(fout, "%d\n", harta.count(x));
      }
    }
    fclose(fin);
    fclose(fout);
    return 0;
}
