#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;

ofstream out("hashuri.out");

class InParser {
private:
    FILE *fin;
    char *buff;
    int sp;

    char read_ch() {
        ++sp;
        if (sp == 4096) {
            sp = 0;
            fread(buff, 1, 4096, fin);
        }
        return buff[sp];
    }

public:
    InParser(const char* nume) {
        fin = fopen(nume, "r");
        buff = new char[4096]();
        sp = 4095;
    }

    InParser& operator >> (int &n) {
        char c;
        while (!isdigit(c = read_ch()) && c != '-');
        int sgn = 1;
        if (c == '-') {
            n = 0;
            sgn = -1;
        } else {
            n = c - '0';
        }
        while (isdigit(c = read_ch())) {
            n = 10 * n + c - '0';
        }
        n *= sgn;
        return *this;
    }

    InParser& operator >> (long long &n) {
        char c;
        n = 0;
        while (!isdigit(c = read_ch()) && c != '-');
        long long sgn = 1;
        if (c == '-') {
            n = 0;
            sgn = -1;
        } else {
            n = c - '0';
        }
        while (isdigit(c = read_ch())) {
            n = 10 * n + c - '0';
        }
        n *= sgn;
        return *this;
    }
};

const int p1 = 1500041;
const int p2 = 1500047;
const int m = 3e6;


long long int a1, b1;

inline int calculate_hash_function_1(long long int x) {
    return ((long long)(a1 * x + b1) % p1) % m;
}

long long int a2, b2;

inline int calculate_hash_function_2(long long int x) {
    return ((long long )(a2 * x + b2) % p2) % m;
}

long long int T1[m], T2[m];

inline bool Search(long long int x) {
    return (T1[calculate_hash_function_1(x)] == x || T2[calculate_hash_function_2(x)] == x);
}

void Insert(long long int x) {
    long long int y, z;
    int h1 = calculate_hash_function_1(x);
    if (T1[h1] == 0 || T1[h1] == x) {
        T1[h1] = x;
        return;
    } else {
        y = T1[h1];
        T1[h1] = x;
    }
    int h2 = calculate_hash_function_2(y);
    if (T2[h2] == 0 || T2[h2] == y) {
        T2[h2] = y;
        return;
    } else {
        z = T2[h2];
        T2[h2] = y;
    }
    Insert(z);
}

inline void Delete(long long int x) {
    int h1 = calculate_hash_function_1(x);
    int h2 = calculate_hash_function_2(x);
    if (T1[h1] == x) {
        T1[h1] = 0;
    } else if (T2[h2] == x) {
        T2[h2] = 0;
    }
}

int main() {

    srand(time(nullptr));
    a1 = rand()%p1;
    b1 = rand()%p1;
    a2 = rand()%p2;
    b2 = rand()%p2;

    InParser fin("hashuri.in");

    long long int n, op, x;
    fin >> n;
    while (n--) {
        fin >> op >> x;
        if (op == 1) {
            Insert(x);
        } else if (op == 2) {
            Delete(x);
        } else {
            out << Search(x) << "\n";
        }
    }


    return 0;
}