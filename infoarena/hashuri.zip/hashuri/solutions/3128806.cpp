#include <iostream>
#include <fstream>
#include <set>
#include <vector>

using namespace std;

int main() {
    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");

    int N, op, x;
    set<int> multime;
    vector<int> rezultate;

    fin >> N;

    for (int i = 0; i < N; i++) {
        fin >> op >> x;

        if (op == 1) {
            multime.insert(x);
        } else if (op == 2) {
            multime.erase(x);
        } else if (op == 3) {
            int rezultat = (multime.count(x) > 0) ? 1 : 0;
            rezultate.push_back(rezultat);
        }
    }

    for (int rezultat : rezultate) {
        fout << rezultat << "\n";
    }

    fin.close();
    fout.close();

    return 0;
}
