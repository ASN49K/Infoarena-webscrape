#include<bits/stdc++.h>
using namespace std;
ifstream A("hashuri.in");
ofstream B("hashuri.out");
#define M 666013
int n,o,x,y;
vector<int> G[M];
int main()
{
    for(A>>x;n;--n) {
        A>>o>>x,y=x%M;
        auto r=find(G[y].begin(),G[y].end(),x);
        if(o==1) {
            if(r==G[y].end())
                G[y].push_back(x);
        } else if(o==2) {
            if(r!=G[y].end())
                G[y].erase(r);
        } else
            B<<(r!=G[y].end())<<'\n';
    }
    return 0;
}
