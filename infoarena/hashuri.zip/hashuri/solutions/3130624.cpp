#include<fstream>

#include<vector>
#include<algorithm>
#define size 2320361
using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hashuri.out");

int main(){
    
    vector<int>* arr=new vector<int>[size]{vector<int>()};
    
    
    int x,y,n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>x;
        switch (x)
        {
        case 1:{
                cin>>y;
                int number=y%size;
                int index=number<0? -number:number;
                if(find(arr[index].begin(),arr[index].end(),y)==arr[index].end()){
                    arr[index].push_back(y);
                }
            }
            break;
        
        case 2:{
                cin>>y;
                int number=y%size;
                int index=number<0? -number:number;
                auto j=find(arr[index].begin(),arr[index].end(),y);
                if(j!=arr[index].end()){
                    arr[index].erase(j);
                }
            }
        
            break;
        case 3:{
            cin>>y;
            int number=y%size;
            int index=number<0? -number:number;
            auto j=find(arr[index].begin(),arr[index].end(),y);
            if(j!=arr[index].end()){
                cout<<'1'<<'\n';
            }
            else{
                cout<<'0'<<'\n';
            }

        }

            break;
        }
    }
}