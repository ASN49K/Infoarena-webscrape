#include <bits/stdc++.h>
#define nr 666013

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int N, operatie;

long long numar;

vector <int> v[nr+5];

void op1(int numar){
    int ok1=0, var=numar%nr;
    for(int j=0;j<v[var].size();j++)
        if(v[var][j]==numar)
            ok1=1;
    if(ok1==0)
        v[var].push_back(numar);
}

void op2(int numar){
    int pozitie=-1, var=numar%nr;
    for(int k=0;k<v[var].size();k++)
        if(v[var][k]== numar)
        {
            pozitie=k;
            break;
        }
    if(pozitie!=-1)
    {
        swap(v[var][pozitie],v[var][v[var].size()-1]);
        v[var].pop_back();
    }
}

int op3(int numar){
    int var=numar%nr;
    for(int j=0;j<v[var].size();j++)
        if(v[var][j]==numar)
            return 1;
    return 0;
}


int main()
{
    fin>>N;
    for(int i=0;i<N;i++)
    {
        fin>>operatie>>numar;
        if(operatie==1)
            op1(numar);
        else
            if(operatie==2)
                op2(numar);
            else
                fout<<op3(numar)<<'\n';
    }
    return 0;
}
