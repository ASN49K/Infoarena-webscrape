#include <fstream>
#include <iostream>
#include <vector>

#define MOD 666013


using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector<int> has[MOD];

void insert(int b);
vector<int>::iterator find(int b);
void dell(int b);




int main()
{
    int op = 0;
    fin>>op;
    for (int i = 1; i <= op; i++)
    {
        int a;
        int b;
        fin>>a>>b;
        if (a == 1)
        {
            insert(b);
        }
        else if (a == 2)
        {
            dell(b);
        }
        else
        {
            fout<<(find(b) != has[b % MOD].end())<<"\n";
        }

    }
    return 0;
}

// functia de gasire in tabelul hash
// foloseste iterator pe care il returneaza

vector<int>::iterator find(int b)
{
    int loc = b % MOD;
    vector<int>::iterator it;
    for(it = has[loc].begin(); it != has[loc].end(); it++)
    {
        if(*it == b)
        {
            return it;
        }
    }
    return has[loc].end();
}


// aici se trateaza cazurile in care avem dubluri folosind functia find
void insert(int b)
{
    int loc = b % MOD;
    if(find(b) == has[loc].end())
    {
        has[loc].push_back(b);
    }
}

// aici il sterge in cazul in care il gaseste

void dell(int b)
{
    int loc = b % MOD;
    vector<int>::iterator it = find(b);
    if(it != has[loc].end())
        has[loc].erase(it);
}
