#include <vector>     
#include <fstream>    
using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");


vector<int>Hash[666017 + 5];

int find_rec(vector<int>& h, int x, int i)
{
    if (i >= h.size())
        return -1;

    if (h[i] == x)
        return i;

    return find_rec(h, x, i + 1);
}

int find(int x)
{
    int b = x % 666017;
    return find_rec(Hash[b], x, 0);
}


void insert(int x)
{
    int b = x % 666017;
    if (find(x) == -1)
        Hash[b].push_back(x);

}
void del(int x)
{
    int b = x % 666017;
    int poz = find(x);
    if (poz != -1)
        Hash[b].erase(Hash[b].begin() + poz);

}

int main()
{
    int n;
    f >> n;
    for (int j = 1; j <= n; j++)
    {
        int op, x;
        f >> op >> x;

        if (op == 1)
            insert(x);

        if (op == 2)
            del(x);

        if (op == 3)
            g << (find(x) != -1) << '\n';
    }

    return 0;
}