#include <iostream>
#include <fstream>
#define MOD 1e9+7
#include <map>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

map <int, bool> multime;

int main()
{
    int N, c, n;
    fin>>N;
    for(; N>0; N--){
        fin>>c>>n;
        if(c==1) multime[n] = true;
        if(c==2) multime[n] = false;
        if(c==3) fout<<multime[n]<<'\n';
    }
    return 0;
}
