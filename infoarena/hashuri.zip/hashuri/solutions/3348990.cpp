#include <bits/stdc++.h>
#define int long long
using namespace std;
const int mod=666013;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
vector <int> v[666100];
int p37[10], p25[10];
int h (int nr)
{
    int ans=nr%mod;
    ans=ans*p37[nr%7+2]%mod;
    ans+=p37[nr%9];
    ans%=mod;
    return ans;
}
signed main ()
{
    int n;
    f >> n;
    while (n--)
    {
        int tip, val;
        f >> tip >> val;
        int og=val;
        if (tip==1)
        {
            val=h(val);
            bool ok=1;
            for (auto x:v[val])
                if (x==val)
            {
                ok=0;
                break;
            }
            if (ok)
                v[val].push_back(og);
        }
        else if (tip==2)
        {
            val=h(val);
            for (int i=0; i<v[val].size(); i++)
            {
                if (v[val][i]==og)
                {
                    v[val].erase (v[val].begin()+i);
                    break;
                }
            }
        }
        else
        {
            val=h(val);
            bool ok=1;
            for (auto x:v[val])
                if (x==og)
            {
                ok=0;
                break;
            }
            g << 1-ok<<'\n';
        }
    }
}
