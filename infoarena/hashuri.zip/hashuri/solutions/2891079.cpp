#include <fstream>
#include <vector>

using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

const int MOD = 666013;

vector < int > Hash[MOD];

vector < int >::iterator find_value(int x){
        int list = x % MOD;
        vector < int >::iterator it;

        for(it = Hash[list].begin(); it != Hash[list].end(); ++it)
                if(*it == x)
                        return it;

        return Hash[list].end();
}

void insert_value(int x){
        int list = x % MOD;
        if(find_value(x) == Hash[list].end())
                Hash[list].push_back(x);
}

void erase_value(int x){
        int list = x % MOD;
        vector < int >::iterator it = find_value(x);
        if(it != Hash[list].end())
                Hash[list].erase(it);
}

int main(){

        int op, x, n;
        in >> n;
        while(n--) {
                in >> op >> x;
                switch(op) {
                case 1:
                        insert_value(x);
                        break;
                case 2:
                        erase_value(x);
                        break;
                case 3:
                        out << (find_value(x) != Hash[x % MOD].end()) << '\n';
                        break;
                }
        }

        return 0;
}
