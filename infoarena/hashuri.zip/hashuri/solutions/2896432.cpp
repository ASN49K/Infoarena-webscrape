
#include <iostream>
#include<fstream>
#include<vector>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

#define max 777973
vector<int>V[max];

int search(int x)
{
    int i=x%max;
    vector<int>::iterator it;
    for(it=V[i].begin(); it!=V[i].end(); ++it)
    {
        if(*it==x)
            return 1;
    }
    return 0;
}

int add(int x)
{
    int i=x%max;
    if(!search(x))
        V[i].push_back(x);
}

void del(int x)
{
    int i=x%max;
    vector<int>::iterator it;
    for(it=V[i].begin(); it!=V[i].end(); it++)
    {
        if(*it==x)
            {V[x%max].erase(it);
            break;
            }
    }

}
int main()
{
    int N,op,nr;
    fin>>N;
    for(int i=0;i<N;i++)
    {
        fin>>op>>nr;
        switch(op)
        {
            case 1:
                 add(nr);
                break;
            case 2:
                if (search(nr)) del(nr);
                break;
            case 3:
                fout << search(nr) << '\n';
        }
    }
    return 0;
}
