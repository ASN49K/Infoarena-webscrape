#include <bits/stdc++.h>

using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

const int Nmax = 1e6 + 5, MOD = 666013;

vector<int> G[MOD + 5];

int main()
{
    int T, c, x;
    in >> T;
    while(T--)
    {
        in >> c >> x;
        int key = x % MOD, i;
        bool OK = 0;
        for(i = 0; i < G[key].size(); ++i)
            if(G[key][i] == x)
            {
                OK = 1;
                break;
            }
        if(c == 1)
        {
            if(!OK)
                G[key].push_back(x);
        }
        else if(c == 2)
        {
            if(OK)
            {
                swap(G[key][i],G[key].back());
                G[key].pop_back();
            }
        }
        else
        {
            out << (OK ? 1 : 0) << '\n';
        }
    }
    return 0;
}
