#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
using namespace std;
#define size 666073
vector<long long >h[size];

int main() {
    ifstream f("hashuri.in");
    ofstream g("hashuri.out");
    long long n,op,x;
    short ok;
    f>>n;
    while (f>>op>>x)
    {
        vector<long long > ::iterator i;

         if(op == 1)
         {
                ok = 0;
             for ( i = h[x%size].begin();i != h[x%size].end();++i)
                if(*i == x)
                    ok = 1;
             if(ok == 0)
                 h[x%size].push_back(x);
         }
         else if(op == 2)
        {
             ok = 0;
            for ( i = h[x%size].begin();i != h[x%size].end() && ok == 0;++i)
                if(*i == x) { h[x % size].erase(i); ok = 1;}
        }
         else
         {
              ok = 0;
             for ( i = h[x%size].begin();i != h[x%size].end() && ok == 0;++i)
                 if(*i == x)
                 {ok = 1;}
             if(ok == 0)
                 g<<0<<'\n';
             else
                 g<<1<<'\n';
         }
    }

    f.close();g.close();
    return 0;
}