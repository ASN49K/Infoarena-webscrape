#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");

const int Mod = 666013;
vector <int> H[Mod];

void addIfNotExist(int x) {
    int rest = x % Mod;

    for(auto nod : H[rest]) {
        if(nod == x) {
            return ;
        }
    }

    H[rest].push_back(x);
}


void deleteIfExist(int x) {
    int rest = x % Mod;
    auto nod = find(H[rest].begin(), H[rest].end(), x);

    if(nod != H[rest].end()) {
        H[rest].erase(nod);
    }
}

bool findIfExist(int x) {
    int rest = x % Mod;

    for(auto nod : H[rest]) {
        if(nod == x) {
            return 1;
        }
    }

    return 0;
}

int main()
{
    int N;
    f >> N;

    for(int i = 0; i < N; ++i) {
        int tip, x;
        f >> tip >> x;

        /*==================if==================      => TLE pe ultimele 2 teste
        if(tip == 1) {
            addIfNotExist(x);
        }
        else if(tip == 2) {
            deleteIfExist(x);
        }
        else if(tip == 3) {
            g << findIfExist(x) << '\n';
        }
        //==================if==================*/

        //*==================switch==================
        switch(tip) {
            case 1 : addIfNotExist(x); break;
            case 2 : deleteIfExist(x); break;
            case 3 : g << findIfExist(x) << '\n';
        };
        //==================switch==================*/

    }

    f.close();
    g.close();
    return 0;
}
