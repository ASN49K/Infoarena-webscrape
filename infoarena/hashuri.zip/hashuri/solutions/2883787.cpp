#include <fstream>
#include <vector>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");

const int Mod = 666013;
vector <int> H[Mod];

void addIfNotExist(int x) {
    int rest = x % Mod;

    for(int i = 0; i < (int) H[rest].size(); ++i) {
        if(H[rest][i] == x) {
            return ;
        }
    }

    H[rest].push_back(x);
}

void deleteIfExist(int x) {
    int rest = x % Mod;

    for(int i = 0; i < (int) H[rest].size(); ++i) {
        if(H[rest][i] == x) {
            H[rest].erase(H[rest].begin() + i);
            return ;
        }
    }
}

bool findIfExist(int x) {
    int rest = x % Mod;

    for(int i = 0; i < (int) H[rest].size(); ++i) {
        if(H[rest][i] == x) {
            return 1;
        }
    }

    return 0;
}

int main()
{
    int N;
    f >> N;

    for(int i = 0; i < N; ++i) {
        int tip, x;
        f >> tip >> x;

        switch(tip) {
            case 1 : addIfNotExist(x); break;
            case 2 : deleteIfExist(x); break;
            case 3 : g << findIfExist(x) << '\n';
        };
    }

    f.close();
    g.close();
    return 0;
}
