#include <fstream>
#include <vector>

#define MOD 666013
using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hashuri.out");


int i,n;
 vector<int> hashez[MOD];

 vector<int>::iterator find_val(int nr)
 {
     int part=nr%MOD;
     vector<int>::iterator it;
     for(it=hashez[part].begin();it!=hashez[part].end();it++)
        if(*it==nr)
        return it;
     return hashez[part].end();

 }

 void delete_val(int nr)
 {int part = nr%MOD;
 vector<int>::iterator it=find_val(nr);
    if(it!=hashez[part].end())
    hashez[part].erase(it);

 }

 void insert_val(int nr)
 {int part = nr%MOD;
 if(find_val(nr)==hashez[part].end())
    hashez[part].push_back(nr);

 }

int main()
{cin>>n;
for(i=1;i<=n;i++)
{int com,num;
    cin>>com>>num;
    if(com==1)
        {insert_val(num);
        continue;
        }
    if(com==2)
        {delete_val(num);
        continue;
        }
    bool corect = find_val(num)!=hashez[num%MOD].end();
    cout<<corect<<'\n';


}

    return 0;
}
