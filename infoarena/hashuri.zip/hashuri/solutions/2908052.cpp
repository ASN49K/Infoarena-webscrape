#include <iostream>
#include <fstream>

using namespace std;


class InParser {
private:
	FILE* fin;
	char* buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}

	InParser& operator >> (int& n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		}
		else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	
};
ofstream fout("hashuri.out");


const int mod = 1e6;

struct nod
{
	int val;
	nod* l;
};

nod* v[mod];

const int mod = 1e6;

bool parcurgere(int x)
{
	int index = x % mod;
	nod* head = v[index];
	while (head != NULL)
	{
		if (head->val == x)
			return 1;
		head = head->l;
	}
	return 0;
}

void insereaza( int x)
{
	if (parcurgere(x) == 1)
		return;
	int index= x% mod;
	if (v[index] == NULL)
	{
		v[index] = new nod;
		v[index]->val = x;
		v[index]->l = NULL;
	}
	else
	{
		nod* k = new nod;
		k->val = x;
		k->l = v[index];
		v[index] = k;
	}
}

void stergere(int x)
{
	if (parcurgere(x) == 0)
		return;
	int index = x % mod;
	nod* head = v[index];
	nod* before = NULL;
	nod* after = NULL;

	while (head != NULL)
	{
		if (head->val == x)
		{
			after = head->l;
			break;
		}
		before = head;
		head = head->l;

	}

	if(before!=NULL)
		before->l = after;
	else
	{
		v[index] = after;
	}

	delete head;
	
}

int main()
{
	InParser fin("hashuri.in");
	int n,q,x;
	fin >> n;
	for (int i = 1; i <= n; i++)
	{
		fin >> q >> x;
		if (q == 1)
		{
			insereaza(x);
		}
		if (q == 2)
		{
			stergere(x);
		}
		if (q == 3)
		{
			fout << parcurgere(x) << endl;
		}

	}

	for (int i = 0; i < mod; i++)
	{
		nod* head = NULL;
		nod* next = v[i];
		while (next != NULL)
		{
			head = next;
			next = head->l;
			delete head;
		}
	}

	
}