#include <fstream>
#include <vector>
#define MOD 499999

using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
long long n,i,j,q,a,ok;
struct elem
{
    vector <long long>  e;

}c,v[500001];
int main()
{
    fin>>n;
    for(i=1; i<=n; i++)
    {
        fin>>q>>a;
        if(q==1)
        {
            ok=0;
            for(j=v[a%MOD].e.size()-1; j>=0; j--)
                if(v[a%MOD].e[j]==a)
                {
                    ok=1;
                    break;
                }
            if(!ok)
                v[a%MOD].e.push_back(a);
        }
        else if(q==2)
        {

            for(j=v[a%MOD].e.size()-1; j>=0; j--)
                if(v[a%MOD].e[j]==a)
                {
                    v[a%MOD].e.erase(v[a%MOD].e.begin()+v[a%MOD].e.size()-j-1);
                    break;
                }
        }
        else
        {
            ok=0;
            for(j=v[a%MOD].e.size()-1; j>=0; j--)
                if(v[a%MOD].e[j]==a)
                {
                    ok=1;
                    break;
                }
            fout<<ok<<'\n';
        }
    }
    return 0;
}
