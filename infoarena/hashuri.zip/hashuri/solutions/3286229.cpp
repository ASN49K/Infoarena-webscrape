#include <bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

unordered_map <int, int> M;

int main()
{
    int i, n, x, q;
    fin >> n;
    for (i = 1; i <= n; i++)
    {
        fin >> q >> x;
        if (q == 1) M[x] = 1;
        else if (q == 2) M[x] = 0;
        else fout << M[x] << "\n";
    }
    return 0;
}

//0, 1, 3-5, 7-18, 21, 22, 24-27, 29, 30, 34-36, 42, 44, 45, 47, 48, 51, 54, 56-58
