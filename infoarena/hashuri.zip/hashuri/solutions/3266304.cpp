#include <fstream>
#include <unordered_map>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

unordered_map<int, int> M;

int main() {
    int n;
    fin >> n;

    for (int i = 1; i <= n; ++i) {
        int op, x;
        fin >> op >> x;

        if (op == 1) {
            M[x] = 1;
        } else if (op == 2) {
            M[x] = 0;
        } else {
            fout << M[x] << '\n';
        }
    }
    return 0;
}
