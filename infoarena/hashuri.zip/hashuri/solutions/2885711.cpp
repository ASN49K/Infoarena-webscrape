#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
vector <int> hashh[15];
int main()
{
    int j,nr,i,ok,clasa,k=10,x,y;
    f>>nr;
    for(j=0;j<nr;j++)
    {
        f>>x;
        f>>y;
        if(x==1)
        {
            ok=1;
            clasa=y%k;
            for(int i=0;i<hashh[clasa].size();i++)
            {
                if( hashh[clasa][i]==y)
                {
                    ok=0;
                    break;
                }
            }
            if(ok)
            {
                hashh[clasa].push_back(y);
            }
        }
        if(x==2)
        {
            clasa=y%k;
            for(int i=0;i<hashh[clasa].size();i++)
            {
                if( hashh[clasa][i]==y)
                {
                    swap(hashh[clasa][i], hashh[clasa].back());
                    hashh[clasa].pop_back();
                    break;
                }
            }

        }
        if(x==3)
        {
            ok=1;
            clasa=y%k;
            for(int i=0;i<hashh[clasa].size();i++)
            {
                if( hashh[clasa][i]==y)
                {
                    ok=0;
                    break;
                }
            }
            if(ok)
            {
                g<<0<<endl;
            }
            else
            {
                g<<1<<endl;
            }
        }
    }
    g.close();
    f.close();
}
