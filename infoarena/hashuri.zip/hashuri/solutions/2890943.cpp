#include <bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

#define PRM 786433

vector<int> v[PRM + 2];

int main()
{
    long long n,i,j,k,tip,nr,ok,cheie;
    fin>>n;
    for(i = 1; i<=n; i++)
    {
        fin>>tip>>nr;
        cheie = nr % PRM;
        if(tip == 1)
        {
            ok = 1;
            for(j = 0; j< v[cheie].size(); j++)
            {
                if(v[cheie][j] == nr){
                    ok = 0;
                    break;
                }
            }
            if(ok == 1)
                v[cheie].push_back(nr);
        }
        else if(tip == 2)
        {
            ok = 1;
            for(j = 0; j< v[cheie].size(); j++)
            {
                if(v[cheie][j] == nr){
                    ok = 0;
                    break;
                }
            }
            if(ok == 0)
                v[cheie].erase(v[cheie].begin() + j);
        }
        else if(tip == 3)
        {
            ok = 1;
            for(j = 0; j<v[cheie].size(); j++)
            {
                if(v[cheie][j] == nr)
                {
                    fout<<1<<'\n';
                    ok = 0;
                    break;
                }
            }
            if(ok == 1)
            {
                fout<<0<<'\n';
            }
        }
    }
    return 0;
}
