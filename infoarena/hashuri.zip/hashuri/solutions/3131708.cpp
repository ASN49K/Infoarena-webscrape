#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

const int nr_prim = 666013;
vector <int> v[nr_prim];

int functie_de_hash(int valoare)
	{
		return valoare % nr_prim;
	}


void inserare(int valoare_insert)
{
    int r = functie_de_hash(valoare_insert);
    for (auto i:v[r])
		{
			if (i==valoare_insert)
			{
			    return;
			}
		}
    v[r].push_back(valoare_insert);
}

bool cautare(int valoare_find)
{
    int r = functie_de_hash(valoare_find);
    for (auto i:v[r])
	{
		if (i == valoare_find)
				{
					return true;
				}
	}
	return false;
}

void stergere(int valoare_stergere)
{
    int r = functie_de_hash(valoare_stergere);
    for (int i = 0; i < v[r].size(); i++)
    {
        if (v[r][i] == valoare_stergere)
        {
            v[r].erase(v[r].begin()+i);
        }
    }
}

int main()
{
    int n, i;
	f>>n;
	for (i = 1; i <=n ; i++)
    {
        int optiune, valoare;
        f>>optiune>>valoare;

        if(optiune==1)
        {
            inserare(valoare);
        }

        if(optiune==2)
        {
            stergere(valoare);
        }

        if(optiune==3)
        {
            g<<cautare(valoare)<<endl;
        }
    }

    return 0;
}
