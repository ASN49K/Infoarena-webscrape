#include<bits/stdc++.h>
using namespace std;
ifstream F("hashuri.in");
ofstream G("hashuri.out");
vector<int> v[9973];
vector<int>::iterator k;
int i,j,m=9973;
int main()
{
    for(F>>i;F>>i>>j;)
        if(k=find(v[j%m].begin(),v[j%m].end(),j),i<2&&k==v[j%m].end())
            v[j%m].push_back(j);
        else if(i==2&&k!=v[j%m].end())
            v[j%m].erase(k);
        else if(i==3)
            G<<(k!=v[j%m].end())<<'\n';
    return 0;
}
