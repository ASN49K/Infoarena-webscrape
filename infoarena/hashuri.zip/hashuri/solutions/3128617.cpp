#include<iostream>
#include<fstream>
#include<vector>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int cautare(vector<vector<int>>v ,int nr ){
    for(unsigned int j = 0 ; j < v[nr%666103].size() ; j++)
        if(v[nr%666103][j] == nr) return j+1;
    return 0;
}

int main(){
    vector<vector<int>>v(666103);
    int n,k,nr;
    fin>>n;
    for(int i = 0 ; i < n ; i++){
        fin>>k>>nr;
        switch(k){

            case 1:
                if(!cautare(v,nr))
                    v[nr%666103].push_back(nr);
                break;

            case 2:
                if(cautare(v,nr))
                    for(unsigned int j = 0 ; j < v[nr%666103].size() ; j++)
                        if(v[nr%666103][j] == nr){
                            v[nr%666103].erase(v[nr%666103].begin() + j);
                            break;
                        }
                break;

            case 3:
                if(cautare(v,nr)) fout<<"1\n";
                else    fout<<"0\n";
                break;
        }
    }

fin.close();
fout.close();
return 0;
}
