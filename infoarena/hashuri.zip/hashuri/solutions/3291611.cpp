///MULTUMESC TIMOTEI

#include <iostream>
#include <fstream>
#include <algorithm>
#include <cctype>
#include <cstring>
#include <iomanip>
#include <climits>
#include <cstdio>
#include <stdio.h>
#include <cmath>
#include <math.h>
#include <windows.h>
#include <conio.h>
#include <map>
#include <vector>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <stack>
#include <queue>
#include <deque>
#include <list>
#include <array>
#include <bitset>
#include <time.h>
#include <string>
#include <sstream>
#include <tuple>

#define pb push_back

std::ifstream f("hashuri.in");
std::ofstream g("hashuri.out");

using namespace std;

const int nMax = 666013;

int n, p;
vector<int> h[nMax];
vector<int> :: iterator it;

vector<int> :: iterator findX(int x)
{
    for (it = h[p].begin();it != h[p].end();it++)if (*it == x)return it;
    return it;
}

void add(int x)
{
    if (it == h[p].end())h[p].pb(x);
}

void delete1()
{
    if (it != h[p].end())h[p].erase(it);
}

void print(int x)
{
    if (it == h[p].end())g << 0 << '\n';
    else g << 1 << '\n';
}

int main()
{
    f >> n;
    for (int i = 1;i <= n;i++){
        int tip, x;
        f >> tip >> x;
        p = x % nMax;
        it = findX(x);
        if (tip == 1)add(x);
        else if (tip == 2)delete1();
        else print(x);
    }
}
