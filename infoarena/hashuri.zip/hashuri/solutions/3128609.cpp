#include<iostream>
#include<fstream>
#include<vector>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

bool cautare(vector<vector<int>>v ,int nr ){
    for(int j = 0 ; j < v[nr%666103].size() ; j++)
        if(v[nr%666103][j] == nr) return 1;
    return 0;
}

int main(){
    vector<vector<int>>v(666103);
    int n,k,nr;
    fin>>n;
    for(int i = 0 ; i < n ; i++){
        fin>>k>>nr;
        switch(k){

            case 1:
                v[nr%666103].push_back(nr);
                break;

            case 2:
                for(int j = 0 ; j < v[nr%666103].size() ; j++)
                    if(v[nr%666103][j] == nr){
                        v[nr%666103].erase(v[nr%666103].begin() + j);
                        break;
                    }
                break;

            case 3:
                fout<<cautare(v,nr)<<endl;
                break;
        }
    }

fin.close();
fout.close();
return 0;
}
