#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
vector <long long> v;
int de_scos;
bool cautare(int x){
    int ok=0;
    for(int i=0;i<v.size() && ok==0 ;i++)
        if(v[i]==x){
            ok=1;de_scos=i;
        }
    if(ok==1)
        return true;
    else
        return false;
}
int main(){
    int n;
    fin>>n;
    for(int i=1;i<=n;i++){
        int op, x;
        fin>>op>>x;
        int MOD=666013;
        long long int nr, p=13, pow=1,sum=0;

        while(x){
            nr=x%10;
            pow*=p;
            sum+=nr*pow;
            sum%=MOD;
            x=x/10;
        }

        if(op==1){
             if(cautare(sum)==false)
                v.push_back(sum);
        }
        else if(op==2){
             if(cautare(sum)==true)
                v.erase(v.begin()+de_scos);
        }
        else if(op==3){
            if(cautare(sum)==true)
                fout<<1<<'\n';
            else
                fout<<0<<'\n';
        }
/**
            for(int i=0;i<v.size();i++)
               cout<<v[i]<<' ';

            cout<<endl;*/

           // v.clear();

    }


    return 0;
}
