#include <bits/stdc++.h>

using namespace std;
std::ifstream fin("hashuri.in");
std::ofstream fout("hashuri.out");
const int p = 1e6 + 7;
int v[p + 1];
int q;
int main()
{
    fin >> q;
    for(int t =  0 ; t < q ; ++t)
    {
        long long op , x;
        fin >> op >> x;
        if(op == 1)
        {
            x = (1LL)*(x % p);
            v[x] = 1;
        }
        else if(op == 2)
        {
            x = (1LL) * (x % p);
            v[x] = 0;
        }
        else
        {
            x = (1LL) * (x % p);
            if(v[x] == 1)fout << "1\n";
            else fout << "0\n";
        }
    }
}
