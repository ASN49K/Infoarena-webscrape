#include <iostream>
#include <fstream>
#include <vector>
#define N 666013

using namespace std;

ifstream input("hashuri.in");
ofstream output("hashuri.out");

vector<int> crazy_hash[N+2];

// am incercat o versiune fara iterator insa nu inteleg de ce aveam problema la timing... pe codul anterior cu iterator :(

int main()
{
    int n, op, i, x, j;
    int clasa;
    input >> n;
    for(i = 1; i <= n; i++)
    {
        input >> op >> x;
        bool found = 0;
        clasa = x % N;
        for(j = 0; j < crazy_hash[clasa].size(); j++)
            if(crazy_hash[clasa][j] == x)
            {
                found = 1;
                break;
            }
        if(op == 1)
        {
            if(found == 0)
                crazy_hash[clasa].push_back(x);
        }
        else if(op == 2)
        {
            if(found == 1)
            {
                swap(crazy_hash[clasa][j], crazy_hash[clasa].back());
                crazy_hash[clasa].pop_back();
            }
        }
        else if(op == 3)
        {
            output << found << "\n";
        }
    }
}















//#include <iostream>
//#include <fstream>
//#include <vector>
//#define MOD  666013
//
//using namespace std;
//vector<int> hashul_nebun[MOD+2];
//
//inline vector<int>::iterator find_value(int x)
//{
//    int clasa_find = x % MOD;
//    vector<int>::iterator it;
//
//    for (it = hashul_nebun[clasa_find].begin(); it != hashul_nebun[clasa_find].end(); it++)
//// dereferentiez astfel incat sa preiau valoarea de la acea adresa
//        if (*it == x)
//            return it;
//    return hashul_nebun[clasa_find].end();
//}
//
//
//int main()
//{
//    int n, op, x;
//
//    ifstream input("hashuri.in");
//    ofstream output("hashuri.out");
//    input >> n;
//
//    for(int i = 1; i <= n; i++) {
//        input >> op >> x;
//        int clasa = x % MOD;
//
//        if (op == 1) {
//            if (find_value(x) == hashul_nebun[clasa].end())
//                hashul_nebun[clasa].push_back(x);
////            continue;
//        }
//        else if (op == 2) {
//            // iteratorul valorii x este preluat si este cautat valoarea
//            vector<int>::iterator it;
//            it = find_value(x);
//
//            // daca este gasita valoarea, deci se ajunge la finalul hashului cu o val existenta  atunci o sterg
//            if (it != hashul_nebun[clasa].end())
//                hashul_nebun[clasa].erase(it);
////            continue;
//        }
//        else if (op == 3) {
//            int found = 0;
//
////            // daca este gasita valoarea atunci imi iau un flag de found pe care il si afisez
////            for (it = hashul_nebun[clasa].begin(); it != hashul_nebun[clasa].end(); ++it)
//            if (find_value(x) != hashul_nebun[clasa].end()) {
//                found = 1;
//            }
//            output << found << endl;
//        }
//    }
//    return 0;
//}