use std::fs;
use std::collections::HashSet;

fn main(){
  let content=
    fs::read_to_string("hashuri.in")
      .expect("Should have been able to read the file");
  let lines=content.lines();
  let mut instrunctions: Vec<_>=
    lines
      .clone()
      .map(|x| x.trim().split_whitespace().collect::<Vec<&str>>())
      .collect();
  instrunctions.remove(0);
  let mut set: HashSet<i32>=HashSet::new();
  let mut file_content=String::new();
  for instrunction in &instrunctions{
    if let Some((number,element))=instrunction.split_first(){
      let number=number.parse::<i32>().unwrap();
      let element=element[0].parse::<i32>().unwrap();
      if number==1{
        set.insert(element);
      }
      else if number==2{
        set.remove(&element);
      }
      else{
        file_content+=if set.contains(&element) {"1\n"} else {"0\n"}
      }
    }
  }
  fs::write("hashuri.out",file_content)
    .expect("Unable to write file");
}