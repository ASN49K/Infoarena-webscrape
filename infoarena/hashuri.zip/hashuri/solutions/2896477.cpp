#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");

const int nrprim = 500069;

vector <int> h[nrprim];

bool gaseste(int x)
{
    int nr = x % nrprim;

    for(int i : h[nr])
        if(i == x) return 1;
    return 0;
}



int main()
{

    int n, i, x, k;

    f>>n;

    for(i=0;i<n;i++)
    {
        f>>k>>x;
        if(k==1)
        {
            if(!gaseste(x)) h[x%nrprim].push_back(x);
        }
        else if(k==2)
        {
            if(gaseste(x))
            {
                int nr = x % nrprim;
                for(int i=0;i<h[nr].size();i++)
                    if(h[nr][i]==x)
                {
                    int ultima_poz = h[nr].size()-1;
                    swap(h[nr][i], h[nr][ultima_poz]);
                    break;
                }
                h[nr].pop_back();
            }
        }
        else if(k==3) g<<gaseste(x)<<endl;
    }

}
