#include <iostream>
#include <vector>
#include <fstream>
 
#define hsh 54767
 
using namespace std;
 
ifstream fcin("hashuri.in");
ofstream fcout("hashuri.out");
 
int n, cod, val;
//const int hsh = 54767;
vector <int> vhsh[hsh+1];
 
int main()
{
    fcin>>n;
    for(int i=0; i<n; i++)
    {
        fcin>>cod>>val;
        int pozitie = val%hsh;
        // adaugare
        if(cod == 1)
            vhsh[pozitie].push_back(val);
            
        // stergere
        else if(cod == 2) {
            for(int j = 0; j<vhsh[pozitie].size(); j++)
                if(vhsh[pozitie][j] == val)
                    vhsh[pozitie].erase(vhsh[pozitie].begin()+j);
        }
        //cautare
        else if(cod == 3) {
            int gasit = 0;
            for(int j=0; j<vhsh[pozitie].size() && gasit==0; j++)
                if(vhsh[pozitie][j] == val)
                {
                    fcout<<"1\n";
                    gasit = 1;
                }
            if(gasit == 0)
                fcout<< "0\n";
        }
    }
    fcin.close();
    fcout.close();
    return 0;
}


/*
#include <iostream>
#include <vector>
#include <fstream>

#define hsh 54767

using namespace std;

ifstream fcin("hashuri.in");
ofstream fcout("hashuri.out");

int n, cod, val;
//const int hsh = 54767;
vector <int> vhsh[hsh];

int main()
{
    fcin>>n;

    for(int i=0; i<n; i++)
    {
        fcin>>cod>>val;
        int pozitie = val%hsh;
        switch (cod)
        {
            case 1:
                vhsh[pozitie].push_back(val);
                break;
            case 2:
                for(int j=0; j<vhsh[pozitie].size(); j++)
                    if(vhsh[pozitie][j] == val)
                        vhsh[pozitie].erase(vhsh[pozitie].begin()+j);
                break;
            case 3:
                int gasit = 0;
                for(int j=0; j<vhsh[pozitie].size(); j++)
                    if(vhsh[pozitie][j]==val)
                    {
                        fcout<<"1\n";
                        gasit = 1;
                    }
                if(gasit == 0)
                    fcout
        }
    }

    fcin.close();
    fcout.close();
    return 0;
} */