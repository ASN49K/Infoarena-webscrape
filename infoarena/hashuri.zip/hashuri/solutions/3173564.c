/**
 *  Hash Table Data Structure
 */
#include <stdio.h>
#include <malloc.h>
#define FIN "hashuri.in"
#define FOUT "hashuri.out"
#define ins 1
#define del 2
#define find 3

struct set {
   int key,
       value;
};

struct set *array;

int size = 0;
int capacity = 666013;

int hashFunction(int key) {

    return key % capacity;
}

int checkPrime(int n) {

}

int getPrime(int n) {

    return n;
}

void init() {

  capacity = getPrime( capacity );

  array = (struct set*)malloc(2000000 * sizeof(struct set)) ;

  for ( size_t i = 0; i <= 2000000; i++ ) {

    array[i].key = 0;

    array[i].value = 0;
  }
}

void insert_value(int key, int value) {

     int index = hashFunction( key );

     if(array[index].key == 0) {

        array[index].key = key;
        array[index].value = value;
        size++;

     } else if(array[index].key == key) {

            array[index].value = value;

     } else {

            printf("%s\n", "Collision occured!");
     }
}

void remove_element(int key) {

  int index = hashFunction(key);

  array[index].key = 0;
  array[index].value = 0;

}

int size_hashtable() {

    return size;
}

int search(int key) {

    int index = hashFunction(key);

    return array[index].key != 0;
}

int get(int key) {

   int index = hashFunction(key);

   return array[index].value;
}

void display() {

     for(int i = 0; i < capacity; ++i) {

     if(array[i].value == 0) {
       printf("array[%d]: __ \n", i);
     } else {
       printf("key: %d; value: %d \n", array[ i ].key, array[ i ].value);
     }
   }
}

int main(int argc, char const *argv[]) {

  init();

  int N, op, x;
  freopen(FIN, "r", stdin);
  freopen(FOUT, "w", stdout);

  scanf("%d\n", &N);

  while(N--) {

    scanf("%d %d", &op, &x);
    if(op == ins) {
       insert_value(x,x);
    } else if(op == del) {
       remove_element(x);
    } else if(op == find) {
       printf("%d\n",search(x));
    }
  }

  return 0;
}
