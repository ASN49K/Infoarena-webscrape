#include <fstream>
#include <set>

using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hashuri.out");
set <int> M[666013];
int main()
{
    int n,a,b;
    cin>>n;
    for (int i=1; i<=n; i++)
    {
        cin>>a>>b;
        if (a==1)
            M[b%666013].insert(b);
        if (a==2)
            M[b%666013].erase(b);
        if (a==3)
        {
            if(M[b%666013].find(b)!=M[b%666013].end())
                cout<<1<<'\n';
            else cout<<0<<'\n';
        }
    }

    return 0;
}
