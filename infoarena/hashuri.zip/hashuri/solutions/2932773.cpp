#include <fstream>
#include <vector>
#define MOD 700001
 
using namespace std;
 
ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");
 
vector<int> h[MOD];
int n;
 
void op1(int x) {
    h[x % MOD].push_back(x);
}
 
void op2(int x) {
    for(int i = 0; i < (int)h[x % MOD].size(); i++) {
        if(h[x % MOD][i] == x) {
            h[x % MOD].erase(h[x % MOD].begin() + i);
            return;
        }
    }
}
 
int op3(int x) {
    for(int i = 0; i < (int)h[x % MOD].size(); i++) {
        if(h[x % MOD][i] == x)
            return 1;
    }
    return 0;
}
 
int main()
{
    int nrop, x;
 
    fin >> n;
 
    for(int i = 1; i <= n; i++) {
        fin >> nrop >> x;
 
        if(nrop == 1)
            op1(x);
        if(nrop == 2)
            op2(x);
        if(nrop == 3)
            fout << op3(x) << "\n";
    }
 
    fin.close();
    fout.close();
    return 0;
}