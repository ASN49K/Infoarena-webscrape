#include <bits/stdc++.h>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int N, operatie;

long long numar;

vector <int> v;

void op1(int numar){
    int ok1=0;
    for(int j=0;j<v.size();j++)
        if(v[j]==numar)
        {
            ok1=1;
            break;
        }
    if(ok1==0)
        v.push_back(numar);
}

void op2(int numar){
    int pozitie=-1;
    for(int k=0;k<v.size();k++)
        if(v[k]== numar)
        {
            pozitie=k;
            break;
        }
    if(pozitie!=-1)
    {
        swap(v[pozitie],v[v.size()-1]);
        v.pop_back();
    }
}

int op3(int numar){
    int ok3=0;
    for(int j=0;j<v.size();j++)
        if(v[j]==numar)
        {
            ok3=1;
            break;
        }
    return ok3;
}


int main()
{
    fin>>N;
    vector <int> v[N];
    for(int i=0;i<N;i++)
    {
        fin>>operatie>>numar;
        if(operatie==1)
            op1(numar);
        else
            if(operatie==2)
                op2(numar);
            else
                fout<<op3(numar)<<'\n';
    }
    return 0;
}
