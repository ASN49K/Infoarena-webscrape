#include <iostream>
//64kb max!

class node {
public:
	node(int x) {
		nextt = NULL;
		val = x;
	}
	int val;
	node *nextt;
};

class listt {
public:
	listt() {
		start = NULL;
	}
	~listt() {
		while (start != NULL) {
			node *next = start->nextt;
			delete(start);
			start = next;
		}
	}
	void add(int x) {
		if (start == NULL)
			start = new node(x);
		else {
			node *current = start;
			while (current->nextt != NULL)
				current = current->nextt;
			current->nextt = new node(x);
		}
	}
	void deletee(int x) {
		if (start == NULL)
			return;
		if (start->val == x) {
			node *nextt = start->nextt;
			delete(start);
			start = nextt;
			return;
		}
		node *current = start;
		while (current->nextt != NULL && current->nextt->val != x)
			current = current->nextt;
		if (current->nextt == NULL)
			return;
		node *nextt = current->nextt->nextt;
		delete(current->nextt);
		current->nextt = nextt;
	}
	bool find(int x) {
		node *current = start;
		while (current != NULL) {
			if (current->val == x)
				return true;
			current = current->nextt;
		}
		return false;
	}
private:
	node *start;
};

class hashtable {	
public:
	hashtable(int siz) {
		size = siz;
		l = new listt[siz];
	}
	~hashtable() {
		delete[](l);
	}
	void add(int x) {
		l[x % size].add(x);
	}
	void deletee(int x) {
		l[x % size].deletee(x);
	}
	bool find(int x) {
		return l[x % size].find(x);
	}
private:
	int size;
	listt *l;
};


hashtable h = hashtable(4000000);
int main()
{
	FILE *fin = fopen("hashuri.in", "r");
	FILE *fout = fopen("hashuri.out", "w");
	int n;
	fscanf(fin, "%d", &n);
	for (int i = 0; i < n; i++) {
		int t, x;
		fscanf(fin, "%d %d\n", &t, &x);
		if (t == 1) {
			// add
			h.add(x);
		} else if (t == 2) {
			// delete
			h.deletee(x);
		} else {
			// search
			fprintf(fout, "%d\n", h.find(x));
		}
	}
	fclose(fin);
	fclose(fout);
}
