#include <cstdio>
#include <vector>
#include <algorithm>

using namespace std;

FILE *fin, *fout;

const int MOD = 666019;
const int B = 31;

vector<int> Hash[MOD + 5];

int hash_value(int n)
{
    int b = 1, s = 0;

    while(n)
    {
        int last = n % 10;

        s = (s + (last * b)) % MOD;

        b = (b * B) % MOD;

        n /= 10;
    }

    return s;
}

int main()
{
    fin = fopen("hashuri.in", "r");
    fout = fopen("hashuri.out", "w");

    int n;
    fscanf(fin, "%d", &n);

    for(int i = 1; i <= n; i++)
    {
        int op, nr;
        fscanf(fin, "%d%d",&op, &nr);

        if(op == 1)
        {
            Hash[hash_value(nr)].push_back(nr);
        }
        else if(op == 2)
        {
            int h = hash_value(nr);

            auto it = find(Hash[h].begin(), Hash[h].end(), nr);

            if(it != Hash[h].end())
                Hash[h].erase(it);
        }
        else
        {
            int h = hash_value(nr);

            auto it = find(Hash[h].begin(),Hash[h].end(), nr);

            if(it != Hash[h].end())
                fprintf(fout, "1");
            else fprintf(fout, "0");

            fprintf(fout, "\n");

        }
    }

    fclose(fin);
    fclose(fout);
    return 0;
}
