#include <fstream>
#include <vector>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

const unsigned long long int MAX = 49999991;

vector<vector<bool>> fr;

int main() {
    unsigned long long int n, i, x, y;
    f >> n;

    for (i = 0; i < n; i++)
    {
        f >> x >> y;
        if (x == 1)
        {
            i = 0;
            while (fr[y % 49999991][i] == true)
                i++;
            fr[y % 49999991][i] = true;
        }
        else if (x == 2)
        {
            i = 0;
            while (fr[y % 49999991][i] == true)
                i++;
            fr[y % 49999991][i - 1] = false;
        }
        else if (x == 3)
        {
            if (fr[y % 49999991][0] == false)
            {
                g << "1" << '\n';
            }
            else
            {
                g << "0" << '\n';
            }
        }
    }

    return 0;
}