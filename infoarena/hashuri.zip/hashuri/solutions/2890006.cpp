
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;
vector<bool> v(1000001);
int main()
{

    ofstream cout("hashuri.out");
    ifstream cin("hashuri.in");

    // ifstream cin("para.py");
    int n, s, kk = 0;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        cin >> s >> kk;
        if (s == 1)
        {
            v[kk] = 1;
        }
        else if (s == 2)
        {
            v[kk] = false;
        }
        else
        {
            cout << v[kk] << "\n";
        }
    }

    return 0;
}