#include <fstream>
#include <list>

using namespace std;

const int mod = 702113;

list<int> v[mod];

list<int>::iterator my_find(int nr, int *poz) {
    *poz = nr % mod;
    for ( auto it = v[*poz].begin();it != v[*poz].end();it++) {
        if (*it == nr)
            return it;
    }
    return v[*poz].end();
}

void adauga(int nr) {
    int poz;
    auto it = my_find(nr, &poz);
    if (it == v[poz].end()) {
        v[poz].push_back(nr);
    }
}

void sterge(int nr) {
    int poz;
    auto it = my_find(nr, &poz);
    if (it != v[poz].end()) {
        v[poz].erase(it);
    }
}

bool gasete(int nr) {
    int poz;
    auto it = my_find(nr, &poz);
    return it != v[poz].end();
}

int main() {
    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");
    int op, nr, n;
    fin >> n;
    for (int i = 0; i < n; i++) {
        fin >> op >> nr;
        switch (op) {
            case 1:
                adauga(nr);
                break;
            case 2:
                sterge(nr);
                break;
            case 3:
                fout << gasete(nr) << '\n';
                break;
            default:
                break;
        }
    }
    fin.close();
    fout.close();
    return 0;
}
