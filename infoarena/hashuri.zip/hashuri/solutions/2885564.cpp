#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream f ("hashuri.in");
ofstream g ("hashuri.out");

int k=666013,n,x,i,tip,j,clasa,ok;

int main()
{
    vector < vector<int> > hashmap (k+3);

    f>>n;

    for (i=0;i<n;i++)
    {
        f>>tip;
        f>>x;
        clasa=x%k;
        if (tip==1)
            hashmap[clasa].push_back(x);

        if (tip==2)
        {
            for (int j=0;j<hashmap[clasa].size();j++)
                if (hashmap[clasa][j]==x)
                {
                    swap(hashmap[clasa][j],hashmap[clasa][hashmap[clasa].size()-1]);
                    hashmap[clasa].pop_back();
                    break;
                }
        }

        if (tip==3)
        {
            ok=0;
            for (int j=0;j<hashmap[clasa].size();j++)
                if (hashmap[clasa][j]==x)
                {
                    g<<1<<'\n';

                    ok=1;
                    break;
                }
            if(ok==0)
                g<<0<<'\n';
        }

    }

    return 0;
}
