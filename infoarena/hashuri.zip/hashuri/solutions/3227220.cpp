#include <bits/stdc++.h>

using namespace std;

ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");

const int MOD = 1875943;
vector <int> f[MOD];

void Insert(int x){
    int key = x%MOD;
    f[key].push_back(x);
}

bool Find(int x){
    int key = x%MOD;
    for (auto v:f[key]){
        if (v==x) return 1;
    }
    return 0;
}

void Erase(int x){
    int key = x%MOD;
    vector <int> filtrat;
    for (auto v:f[key]){
        if (v!=x){
            filtrat.push_back(v);
        }
    }
    f[key] = filtrat;
}

int main()
{
    int n;
    fin >> n;
    for (int i=1;i<=n;++i){
        int t,x;
        fin >> t >> x;
        if (t==1){
            Insert(x);
        }else if (t==2){
            Erase(x);
        }else{
            fout << Find(x) << '\n';
        }
    }
    return 0;
}
