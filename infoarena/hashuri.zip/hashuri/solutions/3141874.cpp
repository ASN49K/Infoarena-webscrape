#include <bits/stdc++.h>

using namespace std;

const int dim = 1237;

ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");

struct Nod
    {
        int info;
        Nod *leg;
    };

class HashTable
{
    Nod * hash_table[dim];
    template <typename T>
    int HashFunction (T value)
        {
            return value % dim;
        }

public:
    void Init()
        {
            for(int i = 0 ; i < dim ; ++i)
                hash_table[i] = NULL;
        }
    template <typename T>
    void Insert (T value)
        {
              if(Search(value) == true) return;
              int key = HashFunction(value);
              Nod *nou = new Nod;
              nou->info = value;
              nou->leg = hash_table[key];
              hash_table[key] = nou;
        }
    template <typename T>
    bool Search (T value)
        {
            int key = HashFunction(value);
            for(Nod *q = hash_table[key] ; q != NULL ; q = q->leg)
                if(q->info == value)
                    return true;
            return false;
        }
    template <typename T>
    void Erase (T value)
        {
            int key = HashFunction(value);
            if(hash_table[key] == NULL) return;
            if(hash_table[key]->info == value)
                {
                    Nod *c = hash_table[key];
                    hash_table[key] = hash_table[key]->leg;
                    delete c;
                }
            else
                {
                    for(Nod *q = hash_table[key] ; q->leg != NULL ; q = q->leg)
                        if(q->leg->info == value)
                        {
                            Nod *c = q->leg;
                            q->leg = q->leg->leg;
                            delete c;
                            return;
                        }

                }
        }
};
int main()
{
    HashTable HT;
    HT.Init();
    int q , op , num;
    fin >> q;
    while(q--)
       {
            fin >> op >> num;
            if(op == 1)
               HT.Insert(num);
            else if(op == 2)
               HT.Erase(num);
            else
                fout << HT.Search(num) << '\n';
        }
}
