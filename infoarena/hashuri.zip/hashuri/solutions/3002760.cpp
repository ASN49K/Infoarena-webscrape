#include <bits/stdc++.h>
#define p 123457

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int n, op, q;
vector <int> a[p + 5];

void Add(int x)
{
    int r = x % p;
    for (int i : a[r])
        if (i == x)
        return;
    a[r].push_back(x);
}

void Delete(int x)
{
    int r = x % p, ok = 0;
    auto it = a[r].find(x);
    if (it != NULL) a[r].erase(it);
}

int Find(int x)
{
    int r = x % p;
    for (int i : a[r])
        if (i == x)
        return 1;
    return 0;
}

int main()
{
    int i, x;
    fin >> q;
    while (q--)
    {
        fin >> op >> n;
        if (op == 1)
            Add(x);
        else if (op == 2)
            Delete(x);
        else
            fout << Find(x) << "\n";
    }


    return 0;
}
