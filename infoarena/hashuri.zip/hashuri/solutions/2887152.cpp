#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

#define k 666013
vector <int> has[k];

int main()
{int n, c, x, gasit, i, j;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
f >> n;
for(i = 0; i < n; i++)
{
f >> c >> x;
gasit = 0;
if(c == 1)
    {
        for(j = 0; j < has[x % k].size() && !gasit; j++)
            if(has[x % k][j] == x) gasit = 1;
        if(!gasit) has[x % k].push_back(x);
    }
else if(c == 2)
    {
        for(j = 0; j < has[x % k].size(); j++)
            if(has[x % k][j] == x)
            {
                swap(has[x % k][j], has[x % k][has[x % k].size() - 1]);
                has[x % k].pop_back();
            }
    }
else
    {
        for(j = 0; j < has[x % k].size() && !gasit; j++)
            if(has[x % k][j] == x) gasit = 1;
        g << gasit << '\n';
    }
}
f.close();
g.close();
return 0;
}
