/*
7
1 3
1 20
2 7
3 4
3 20
2 20
3 20
*/
#include <iostream>
#include <fstream>
#include <vector>
#define FIN "hashuri.in"
#define FOUT "hashuri.out"
#define MOD 700000
#define ins 1
#define del 2
#define search_op 3

using namespace std;

//Hash Table Data Structure
vector< long > Hash[ MOD ];
//Hash [
//   [0] [1] [2] [3]
//   ]

// Hash[ key ].push_back( VALUE )

// Hash[ 0 ].push_back( 16 )
// Hash[ 3 ].push_back( 11 )
// Hash[ 3 ].push_back( 27 )
// Hash[ 3 ].push_back( 19 )
// Hash[ 3 ].push_back( 11,28,19 )
//Hash.insert(Hash.end(), { 11, 28, 19} );


ifstream fin(FIN);
ofstream fout(FOUT);

vector<long>::iterator seek(long value) {

     vector<long>::iterator it;

     // key = 3 % 100000
     long key = value % MOD;

     for(it = Hash[ key ].begin(); it != Hash[ key ].end(); it++) {

         if(*it == value) return it;
     }

     return Hash[ key ].end();
}

void insert(long value) {

    vector<long>::iterator it;

    it = seek( value );

    long key = value % MOD;

    if(it == Hash[key].end() ) Hash[key].push_back( value );
}

int search(long value) {

    vector<long>::iterator it;

    long key = value % MOD;

    it = seek( value );

    if(it != Hash[key].end()) return 1;

          else
                              return 0;
}

void remove(long value) {

     vector<long>::iterator it;

     long key = value % MOD;

     it = seek( value );

     if( it != Hash[ key ].end() ) Hash[ key ].erase( it );
}

int research(long value) {

    vector<long>::iterator it;

    long key = value % MOD;

    it = seek( value );

    if( it != Hash[ key ].end() ) return 1;

                else
                                  return 0;
}
int main(int argc, char const *argv[]) {

    int N; //numarul de operatii
    int op,
        el;

    //Hash[0].push_back(11);
    //Hash[0].push_back(28);
    //Hash[0].push_back(19);
    //Hash[0].insert(Hash[0].end(), { 11, 28, 19} );

    //for(vector<long>::iterator it = Hash[0].begin(); it != Hash[0].end(); it++) {
        //cout<<*it<<" ";
    //}
    fin>>N;//daca N = 3 citit din fisier
    /*
    while(N) {
      //executa instructiunea
      N--
    }

    for( ; N; N--) {
      //3 != 0
      //executa instructiunea
      //N = N - 1= 3 -1 = 2
      //N = 2
      //N != 0? adica 2 != 0: da
      //executa instructiunea
      //N = N - 1; N = 1
      //N != 0? 1 != 0: da
      //executa
      //N = N - 1 => N = 0
    }

    while(N--) {

    }
    */

    for( ;N; N--) {

        fin>>op>>el;//citim operatia si elementul multimii

        if( op == ins ) {

            //insert(3)
            insert( el  );

        } else if(op == del) {

            remove( el );

        } else if( op == search_op ) {

             int ans = research( el );

             if(ans == 1) fout<<"1\n";

                   else
                          fout<<"0\n";
        }
    }

    return 0;
}
