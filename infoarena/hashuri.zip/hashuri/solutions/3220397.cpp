#include <fstream>
#include <unordered_map>
using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hashuri.out");
unordered_map<int,int> frv;
int main()
{
    int n,i,cer,a;cin>>n;
    for(i=0;i<n;i++){cin>>cer>>a;
        if(cer==1) frv[a]++;
        else if(cer==2&&frv[a]) frv[a]--;
        else if(cer==3) cout<<(frv[a]!=0)<<"\n";
    }
    return 0;
}
