
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");
int main()
{
    int op;
    long n, x, clasa;
    int key = 666013;
    vector<vector<int>> hasht(key + 3);
    in>>n;
    while(n)
    {
        in>>op>>x;
        if(op == 1)
            {
               clasa =  x % key;
               hasht[clasa].push_back(x);
            }
        else if(op == 2)
            {
               clasa =  x % key;
               for(int i = 0; i < hasht[clasa].size(); i++)
                  if(hasht[clasa][i] == x)
                     {
                      swap(hasht[clasa][i], hasht[clasa][hasht[clasa].size()-1]);
                      hasht[clasa].pop_back();
                     }
            }
           else if(op == 3)
            {
               clasa =  x % key;
               int ok = 0;
               for(int i = 0; i < hasht[clasa].size(); i++)
                  if(hasht[clasa][i] == x)
                      {ok = 1;
                       out<<1<<"\n";
                       break;}
               if(ok == 0)out<<0<<"\n";
            }
        n--;
    }
    in.close();
    out.close();
    return 0;
}
