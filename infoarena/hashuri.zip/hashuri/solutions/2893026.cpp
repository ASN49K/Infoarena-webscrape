#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");
const int prim = 666013;
int operatie, n, gasit;
long long element;
vector <int> v[prim];
vector <int>::iterator it;

int main(){
    f >> n;
    for(int i = 1; i <= n; i++)
    {
        f >> operatie >> element;
        gasit = 0;
        int nr = element % prim;
        for(it = v[nr].begin(); it != v[nr].end(); it++)
            if(*it == element){
                gasit = 1;
                break;
        }
        if(operatie == 1){
            if(gasit == 0)
                v[nr].push_back(element);
        }

        else if(operatie == 2){
            if(gasit == 1)
                v[nr].erase(it);
        }
        else if(operatie == 3)
            g<<gasit<<'\n';
    }
    f.close();
    g.close();
    return 0;
}
