#include <fstream>
#include <vector>
using namespace std;
ifstream cin("hashuri.in");
ofstream cout ("hashuri.out");
const int mod=2500033;
const int base=11;
int powers[10];
void powermaker()
{
    int check=1;
    for(int i=1;i<=9;i++)
    {
        powers[i]=check;
        check*=base;
    }
}
vector <vector<int>> v;
int hasher(int x)
{
    long long newx=0;
    int p=1;
    while(x)
    {
        newx+=powers[p]*(x%10);
        p++;
        x/=10;
    }
    return newx%mod;
}
int main()
{
    int n;
    cin>>n;
v.resize(mod + 1);
    for(int k=1;k<=n;k++)
    {
        int c;
        cin>>c;
        int val,hashed;
        cin>>val;
        hashed=hasher(val);
        if(c==1)
            v[hashed].push_back(val);
        if(c==2)
        {
            for(int i=0;i<v[hashed].size();i++)
                if(v[hashed][i]==val){
                {
                    int last_idx = v[hashed].size() - 1;
                    swap(v[hashed][i],v[hashed][last_idx]);
                    v[hashed].pop_back();
                    break;
                }
            }
        }
        if(c==3)
            {
                bool flag=true;
                for(int i=0;i<v[hashed].size();i++)
                    if(v[hashed][i]==val){
                        cout<<"1\n";
                        flag=false;
                    }
                if(flag)
                    cout<<"0\n";
            }
           
        }
        return 0;
    }