#include <iostream>
#include<vector>
#include<fstream>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
#define k 666013
vector <int> my_hash[k+5];
int main()
{
    int N, i, operatie,clasa,x,j;
    bool found;
    f>>N;
    for (i=1; i<=N; i++)
    {
        f>>operatie;
        f>>x;
        clasa=x%k;
        found=false;
        for(j=0; j<my_hash[clasa].size(); j++)
            if(my_hash[clasa][j]==x)
            {
                found=1;
                break;
            }
            if(operatie==1)
            {
                //if (found==0)
                    my_hash[clasa].push_back(x);
            }
            else if(operatie==2)
            {
                //if(found==true)
                {
                    swap(my_hash[clasa][j],my_hash[clasa].back());
                    my_hash[clasa].pop_back();
                }
            }
            else if(operatie==3)
                g<<found<<endl;
        }


    return 0;
}



