#include <iostream>
#include <fstream>
#include <vector>

#define val  666013

using namespace std;


ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector <int> M[val];

inline vector<int> ::iterator verificare(int x){
    int l = x % val;
    vector<int>::iterator pos;

    for  (pos = M[l].begin(); pos != M[l].end(); ++pos)
        if(*pos == x)
            return pos;
    return M[l].end();
}


inline void inserare (int x){
    int l = x % val;
    if (verificare(x) == M[l].end())
        M[l].push_back(x);

}

inline void stergere(int x){
    int l  = x % val;
    vector<int>::iterator pos = verificare(x);

    if (pos != M[l].end())
        M[l].erase(pos);
}


int main() {
    int N, operatie, parametru;
    fin >> N;
    for (int i = 0; i < N; i++) {
        fin >> operatie >> parametru;
        if (operatie == 1)
            inserare(parametru);
        else if (operatie == 2)
            stergere(parametru);
        else fout << (verificare(parametru) != M[parametru%val].end()) << endl;

    }
    return 0;
}