#include <fstream>
#include <iostream>
#include <queue>

using namespace std;
const int mod=500113;

vector<int> hashtable[mod];

int find(int x){
    int ind;
    ind=x%mod;
    for(auto &e : hashtable[ind])
        if(e==x)
            return true;
    return false;
}

void insert(int x){
    int ind;
    ind=x%mod;
    if(find(x)==false)
        hashtable[ind].push_back(x);
}

void erase(int x){
    int ind, i, j;
    ind=x%mod;
    if(find(x)==true){
        i=0;
        while(i<hashtable[ind].size() && hashtable[ind][i]!=x)
            i++;
        if(hashtable[ind][i]==x){
            for(j=i+1; j<hashtable[ind].size(); j++)
                hashtable[ind][j-1]=hashtable[ind][j];
            hashtable[ind].pop_back();
        }
    }
}
int main(){
    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");
    int n, i, tip, x;
    fin>>n;
    for(i=0; i<n; i++){
        fin>>tip>>x;
        if(tip==1)
            insert(x);
        else if(tip==2)
            erase(x);
        else
            fout<<find(x)<<"\n";
    }
    return 0;
}
