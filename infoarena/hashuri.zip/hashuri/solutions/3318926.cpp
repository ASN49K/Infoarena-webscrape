#include <bits/stdc++.h>

using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
unordered_map<int,bool> mapa;
int n,x,op;
int main()
{
    fin>>n;
    while (n--)
    {
        fin>>op>>x;
        if (op==1) mapa[x]=1;
        else if (op==2) mapa[x]=0;
        else fout<<mapa[x]<<'\n';
    }
    return 0;
}
