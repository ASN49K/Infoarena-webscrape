#include <cstdio>
using namespace std;

const int MOD1 = 1e9 + 7;
const int MOD2 = 1e9 + 9;
const int NMAX = 1e7;

int hash1[NMAX + 1], hash2[NMAX + 1];

void Add(int number) {
    hash1[number % MOD1] = 1;
    hash2[number % MOD2] = 1;
}
void Delete(int number) {
    hash1[number % MOD1] = 0;
    hash2[number % MOD2] = 0;
}

bool Exists(int number) {
    return (hash1[number % MOD1] == 1 && hash2[number % MOD2] == 1);
}
int main() {
    freopen("hashuri.in", "r", stdin);
    freopen("hashuri.out", "w", stdout);

    int operations;

    scanf("%d", &operations);

    for (; operations > 0; operations--) {
        int operation, number;
        scanf("%d %d", &operation, &number);
        if (operation == 1) {
            Add(number);
        }
        else if (operation == 2) {
            Delete(number);
        }
        else {
            printf("%d\n", Exists(number));
        }
    }
    return 0;
}