#include <bits/stdc++.h>

using namespace std;

int main(){

    ifstream f("hashuri.in");
    ofstream g("hashuri.out");

    int n, nr;
    map<int, int> M = {};

    f >> n;

    for(int i = 1; i <= n; ++i){
        int op, x;

        f >> op >> x;
        if(op == 1 && M.find(x) == M.end())
            M[x] = ++nr;
        else if(op == 2)
            M.erase(x);
        else
            g << (M.find(x) != M.end()) << '\n';
    }

    f.close();
    g.close();

    return 0;
}