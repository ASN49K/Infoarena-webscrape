#include <iostream>
#include <unordered_map>
#include <fstream>
using namespace std;
int main(){
    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");
    int N, op, x;
    unordered_map<int,int>HashTable;
    fin>>N;
    for(int i=0;i<N;i++){
        fin>>op;
        fin>>x;
        if (HashTable.count(x)==0 and op==1){
            HashTable[x]=1;
        }
        else 
        if(HashTable.count(x)==1 and op==2){
            HashTable.erase(x);
        }
        else if(HashTable.count(x)==1 and op==3){
            fout<<1<<"\n";
        }
        else if(HashTable.count(x)==0 and op==3){
            fout<<0<<"\n";
        }
    }
    fin.close();
    fout.close();
    return 0;
}