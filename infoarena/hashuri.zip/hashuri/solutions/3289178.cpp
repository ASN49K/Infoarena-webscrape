#include <bits/stdc++.h>
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

signed main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr);

    unordered_set<int> ap;
    int n;
    fin >> n;
    while(n--)
    {
        int op, x;
        fin >> op >> x;
        if(op == 1)
            ap.insert(x);
        else if(op == 2)
            ap.erase(x);
        else
            fout << ap.count(x) << '\n';
    }

    return 0;
}
