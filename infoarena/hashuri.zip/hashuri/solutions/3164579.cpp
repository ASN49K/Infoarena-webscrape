#include <iostream>
#include <fstream>
#include <unordered_set>
using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");


int N, op, x;
unordered_set <int> us;

int main()
{
    in >> N;
    for(int i = 1; i <= N; i++)
    {
        in >> op>> x;;
        if(op == 1)
        {
           us.insert(x);
        }
        else if(op == 2)
        {
            us.erase(x);
        }
        else {
            if(us.count(x) == 1)
            {
                out << 1 <<  '\n';
            }
            else out << 0 << '\n';
        }
    }
}