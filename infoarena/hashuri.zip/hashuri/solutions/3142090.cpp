#include <bits/stdc++.h>
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
#define MOD 666013
int n,op,x;
vector<int> G[MOD];
inline vector<int>::iterator find_value(int x){
    int list=x%MOD;
    vector<int>::iterator it;
    for(it=G[list].begin();it!=G[list].end();it++)
        if(*it==x)
            return it;
    return G[list].end();
}
inline vector<int>::iterator insert_value(int x){
    int list=x%MOD;
    if(find_value(x)==G[list].end())
        G[list].push_back(x);
}
inline vector<int>::iterator erase_value(int x){
    int list=x%MOD;
    vector<int>::iterator it=find_value(x);
    if(it!=G[list].end())
        G[list].erase(it);
}
int main()
{
    cin>>n;
    for(int i=1;i<=n;++i){
        cin>>op>>x;
        if(op==1){
            insert_value(x);
        }
        else if(op==2){
            erase_value(x);
        }
        else
            printf("%d\n", find_value(x) != G[x % MOD].end());
    }

}
