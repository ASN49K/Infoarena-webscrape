#include <bits/stdc++.h>

#define MOD 700001

using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");

int N, op, x;

vector <int> G[MOD];

vector <int> :: iterator gaseste(int x)
{
    for(vector <int>::iterator it = G[x % MOD].begin(); it != G[x % MOD].end(); it ++)
        if( *it == x )
            return it;
    return G[x % MOD].end();
}

void ad(int x)
{
    if(gaseste(x) == G[x % MOD].end())
        G[x % MOD].push_back(x);
}

void del(int x)
{
    vector <int> :: iterator it = gaseste(x);
    if(it != G[x % MOD].end())
        G[x % MOD].erase(it);
}



int main()
{
    f >> N;
    for(int i = 1; i <= N; i ++)
    {
        f >> op >> x;
        if(op == 1)
            ad(x);
        else if(op == 2)
            del(x);
        else
        {
            if(gaseste(x) != G[x % MOD].end())
                g << 1 << '\n';
            else g << 0 << '\n';
        }
    }
    return 0;
}
