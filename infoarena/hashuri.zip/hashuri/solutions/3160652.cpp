#include <fstream>
#include <unordered_map>

ifstream cin("hashuri.in");
ifstream cout("hashuri.out");

using namespace std;

int main() {
    int n;
    cin >> n;

    unordered_map<int, bool> m;
    for (int i = 0; i < n; ++i) {
        int p, x;
        cin >> p >> x;

        if (p == 1) m[x] = true;
        else if (p == 2) m[x] = false;
        else {
            cout << m[x] << '\n';
        }
    }
    return 0;
}
