#include <fstream>

using namespace std;

typedef struct nod {
        int v;
        nod * next;
} *pnod, nod;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
int n, mod = 100003;
pnod m[100003];

bool Find(int x, pnod l){
    for(pnod i = l; i != nullptr; i = i->next) if(i->v == x) return true;
    return false;
}

void Add(int x, pnod &l){
    pnod t = new nod;
    t->v = x;
    t->next = l;
    l = t;
}

void Erase(int x, pnod &l){
    if(l != nullptr && l->v == x){
        l = l->next;
    }
    pnod p = nullptr;
    for(pnod i = l; i != nullptr; i = i->next){
        if(i->next != nullptr && i->next->v == x){
            p = i;
            break;
        }
    }
    if(p == nullptr) return;
    pnod t = p->next;
    p->next = t->next;
    delete t;
}

int main(){
    fin >> n;
    for(int i = 1; i <= n; i++){
        int c, x;
        fin >> c >> x;
        if(c == 1) if(!Find(x, m[x % mod])) Add(x, m[x % mod]);
        if(c == 2) if(Find(x, m[x % mod])) Erase(x, m[x % mod]);
        if(c == 3) fout << Find(x, m[x % mod]) << '\n';
    }
    fin.close();
    fout.close();
    return 0;
}