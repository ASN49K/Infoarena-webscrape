#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
const int MOD=666019;
int n, a, x, i;
vector<int> v[666020];

bool check(int x){
    bool ok=0;

    for(int j=0;j<v[x%MOD].size();j++){
        if(v[x%MOD][j]==x){
            ok=1;
            break;
        }
    }

    return ok;
}

void insrt(int x){
    v[x%MOD].push_back(x);
}

void sterge(int x){
    for(int j=0;j<v[x%MOD].size();j++){
        if(v[x%MOD][j]==x){
            swap(v[x%MOD][j], v[x%MOD][v[x%MOD].size()-1]);
            v[x%MOD].pop_back();
            break;
        }
    }
}

int main()
{
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>a>>x;

        if(a==1){
            if(check(x)==0){
                insrt(x);
            }
        }
        if(a==2){
            if(check(x)){
                sterge(x);
            }
        }
        if(a==3){
            fout<<check(x)<<'\n';
        }
    }



    return 0;
}
