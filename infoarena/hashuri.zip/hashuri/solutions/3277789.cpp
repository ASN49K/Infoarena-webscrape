#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <unordered_set>
using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");
const int MOD = 869017;
const int MAX = MOD+5;
const int baz = 17;

int hashi (int nr)
{
    int bucket=0, put=1;
    while(nr>0)
    {
        bucket = (bucket+(nr%10)*put)%MOD;
        nr=nr/10;
        put=put*baz;
    }
    return bucket;
}

unordered_set<int> v[MAX];
int main()
{
    int n;
    in>>n;
    for(int k=0; k<n; ++k)
    {
        int op, x;
        in>>op>>x;
        int cate=hashi(x), ok;
        if(op==1) //se adauga daca nu e
        {
           /* ok=0;
            for(int i=0; i<v[cate].size(); ++i)
            {
                if(v[cate][i]==x)
                    ok=1;
            }
            if(ok==0)//daca nu e
                v[cate].push_back(x);*/
            v[cate].insert(x);
        }
        else if(op==2) //se sterge daca nu e
        {
         /*   for(int i=0; i<v[cate].size(); ++i)
            {
                if(v[cate][i]==x)
                {
                    swap(v[cate][i], v[cate][v[cate].size()-1]);
                    v[cate].pop_back();
                }
            }*/
            v[cate].erase(x);

        }
        else //afis 1 daca e in multime, 0 daca nu
        {
            /*ok=0;
            for(int i=0; i<v[cate].size(); ++i)
            {
                if(v[cate][i]==x)
                    ok=1;
            }*/
            if(v[cate].count(x))
                out<<1<<'\n';
            else
                out<<0<<'\n';
        }
    }
    return 0;
}
