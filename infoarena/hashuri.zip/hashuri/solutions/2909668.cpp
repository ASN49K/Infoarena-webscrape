#include<iostream>
#include<fstream>

using namespace std;

const int mx = 1001459;
int table[mx];

int f(int x) {
    return x % mx;
}

void insert(int x) {
    int index = f(x);
    while (table[index] != 0) {
        index = (index + 1) % mx;
    }
    table[index] = x;
}


//Returns the index in the map where the element is placed, -1 if it does not exist.
int find(int x) {
    int index = f(x);
    while (table[index] != 0) {
        if (table[index] == x) {
            return index;
        }
        index = (index + 1) % mx;
    }
    return -1;
}

void erase(int x) {
    int here = find(x);
    if (here == -1) {
        return;
    }
    while (f(table[(here + 1) % mx]) != (here + 1) % mx) {
        table[here] = table[(here + 1) % mx];
        here = (here + 1) % mx;
    }
    table[here] = 0;
}


int main() {
    ifstream in("hashuri.in");
    ofstream out("hashuri.out");
    int n, a, b;
    in >> n;
    while (n--) {
        in >> a >> b;
        if (a == 1) {
            insert(b);
        } else if (a == 2) {
            erase(b);
        } else {
            if (find(b) == -1) {
                out << "0\n";
            } else {
                out << "1\n";
            }
        }
    }

    return 0;
}
