#include <fstream>
#include <map>
#include <unordered_map>
#include <deque>
#include <vector>

using namespace std;

ifstream cin ("hashuri.in");
ofstream cout ("hashuri.out");

long long int t,n,m,i,j,sum,k,x,y,x2,y2,b[200005],l,r,nrp,nrn,ans,mini,ok,nr,ans2;
char s[200005],s2[200005];
const int MOD=666013;
deque<long long int>q;
unordered_map<int, bool>fr;
vector<int>hashuri[MOD];

inline vector<int>::iterator gasesc(int x)
{
    t=x%MOD;
    vector<int>::iterator it;
    for(it=hashuri[t].begin();it!=hashuri[t].end();it++)
        if(*it==x)
            return it;
    return hashuri[t].end();
}

void adaug(int x)
{
    t=x%MOD;
    if(gasesc(x)==hashuri[t].end())
        hashuri[t].push_back(x);
}

void sterg(int x)
{
    t=x%MOD;
    if(gasesc(x)!=hashuri[t].end())
        hashuri[t].erase(gasesc(x));
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>k>>x;
        if(k==1)
            adaug(x);
        if(k==2)
            sterg(x);
        if(k==3)
        {
            if(gasesc(x)!=hashuri[x%MOD].end())
                cout<<1<<'\n';
            else
                cout<<0<<'\n';
        }
    }
    return 0;
}
