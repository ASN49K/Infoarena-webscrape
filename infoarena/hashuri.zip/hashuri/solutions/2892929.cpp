#include <bits/stdc++.h>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

unordered_map<int, int> elemente;

int main() {
    int nrOperatii, index, operatie, numar;
    fin >> nrOperatii;
    for (index = 0; index < nrOperatii; index += 1) {
        fin >> operatie >> numar;
        if (operatie == 1) {
            if(elemente.find(numar) == elemente.end()){
                elemente[numar] = 1;
            }
        }
        if (operatie == 2) {
            if(elemente.find(numar) != elemente.end()){
                elemente.erase(numar);
            }
        }
        if (operatie == 3) {
            fout<<(elemente.find(numar) != elemente.end() ? 1 : 0)<<"\n";
        }
    }
    return 0;
}