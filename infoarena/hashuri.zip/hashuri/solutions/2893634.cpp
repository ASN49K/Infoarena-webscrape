#include <iostream>
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

long n,x;
int rez,op;

int main() {

    set<long>hash;
    f>>n;
    while(n!=0){
        f>>op>>x;
        auto poz = hash.find(x);
        if(op==1 && *poz == hash.size()){
            hash.insert(x);
        }
        if(op==2 && *poz != hash.size()){
            hash.erase(poz);
        }
        if(op==3){
            if(*poz != hash.size()){rez = 1;}
            else rez = 0;
            g<<rez<<endl;
        }
        n--;
    }

    return 0;
}
