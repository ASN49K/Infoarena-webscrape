#include <bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int n;
unordered_map<int, int> M;

int main()
{
    fin >> n;
    for(int i = 1; i <= n; ++i)
    {
        int op, x;
        int ok = 1;
        fin >> op >> x;
        if(op == 1)
        {
            if(M.find(x) == M.end())
                M[x] = 1;
        }
        if(op == 2)
        {
            if(M.find(x) != M.end())
                M.erase(x);
        }
        if(op == 3)
        {
            ok = 0;
            if(M.find(x) != M.end())
                ok = 1;

            fout << ok << '\n';
        }
    }
}
