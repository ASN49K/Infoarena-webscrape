#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    freopen("hashuri.in", "r", stdin);
    freopen("hashuri.out", "w", stdout);
    int n, op, el;
    map<int, int> m;
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>op>>el;
        if(op==1)
            m[el]=1;
        if(op==2)
            m[el]=0;
        if(op==3)
            cout<<m[el]<<'\n';
    }
    return 0;
}
