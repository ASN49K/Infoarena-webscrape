#include <fstream>
#include <iostream>
#include <vector>
#include <list>

using namespace std;


class EasyHash
{
private:
	vector<list<long long>> storage;
public:
	EasyHash() : storage(2000000) {};
	long long& operator[](const long long& nr)
	{
		long long index = nr % 834941;
		for(auto& el : storage[index])
		{
			if (el == nr)
				return el;
		}
		storage[index].emplace_front(0);
	}
};

int main()
{
	ifstream in("hashuri.in");
	ofstream out("hashuri.out");
	EasyHash set;
	int operations;
	long long parameter;
	short command;
	in >> operations;
	for(int i=0;i<operations;++i)
	{
		in >> command >> parameter;
		switch(command)
		{
		case 1:
			set[parameter] = parameter;
			break;
		case 2:
			set[parameter] = 0;
			break;
		case 3:
			out <<( (set[parameter] != 0) ? 1 : 0 )<< "\n";

		}
	}
	in.close();
	out.close();

	
}