#include <bits/stdc++.h>

using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
unordered_set<int> s;
int n,t,x;
int main()
{
    f>>n;
    for( ; n; n--)
    {
        f>>t>>x;
        if(t == 1)
            s.insert(x);
        else if (t == 2)
            s.erase(x);
        else if (s.find(x) == s.end ())
            g<< "0\n";
        else
            g<<"1\n";
    }
    return 0;
}
