#include <fstream>
#include <set>

using namespace std;

set<int> mySet;

int main() {
	ifstream f("hashuri.in");
	ofstream g("hashuri.out");
	int n, op, x;
	f >> n;
	while(n--) {
		f >> op >> x;
		if (op == 1) {
			mySet.insert(x);
		}
		else {
			if (op == 2) {
				mySet.erase(x);
			}
			else {
				g << (mySet.find(x) != mySet.end()) << "\n";
			}
		}
	}

	
	f.close();
	g.close();
	return 0;
}