#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
const int N = 1e6 + 10;
vector <int> v[N];
ifstream f("hashuri.in");
ofstream g("hashuri.out");
int main()
{
    int n, key;
    f >> n;
    while(n){
        int x;
        f >> x;
        switch(x){
        case 1:
            f >> x;
            key = x % N;
            v[key].push_back(x);
            break;
        case 2:
            f >> x;
            key = x % N;
            for(int i = 0; i < v[key].size(); i++)
                if(v[key][i] == x){
                    v[key].erase(v[key].begin() + i);
                }
            break;
        case 3:
            f >> x;
            key = x % N;
            bool gasit = false;
            for(int i = 0; i < v[key].size(); i++)
                if(v[key][i] == x){
                    g << "1\n";
                    gasit = true;
                    break;
                }
            if(!gasit)
                g << "0\n";
            break;
        };
        n--;
    }
    return 0;
}
