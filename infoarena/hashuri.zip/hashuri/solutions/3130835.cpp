//
// Created by Octavian Farcasi on 18.05.2023.
//
#include<iostream>
#include<fstream>

struct nod_lista{
    int valoare=-1;
    nod_lista *next= nullptr;

};

class Hash{
    private:
    nod_lista *hash[65521];
    public:
        Hash(){
            for(int i=0; i<65521;i++)
                hash[i]= nullptr;
        }

        void inserare(int valoare){
            int index=valoare%65521;
            if(hash[index]== nullptr){
                hash[index]=new nod_lista;
                hash[index]->valoare=valoare;
            }else{
                nod_lista *ptr=hash[index];
                while(ptr->next!= nullptr && ptr->valoare!=valoare)
                    ptr=ptr->next;
                if(ptr->valoare!=valoare){
                    ptr->next=new nod_lista;
                    ptr->next->next= nullptr;
                    ptr->next->valoare=valoare;
                }
            }
        }

        void stergere(int valoare){
            int index=valoare%65521;
            nod_lista *ptr;
            if(hash[index]!= nullptr && hash[index]->valoare==valoare){
                ptr=hash[index]->next;
                delete hash[index];
                hash[index]=ptr;
            }
            else
                if(hash[index]!= nullptr && hash[index]->valoare!=valoare && hash[index]->next!= nullptr){
                    ptr=hash[index];
                    int ok=0;
                    while(ptr->valoare!=valoare && ptr->next!= nullptr){
                        if(ptr->next->valoare==valoare){
                            ok=1;
                            break;
                        }
                        ptr=ptr->next;
                    }
                    if(ok==1){
                        nod_lista *ptr2=ptr->next->next;
                        delete ptr->next;
                        ptr->next=ptr2;
                    }

                }
        }


        int find(int valoare){
            int index= valoare%65521;
            nod_lista *ptr=hash[index];
            while(ptr!=nullptr && ptr->valoare!=valoare)
                ptr=ptr->next;
            if(ptr!= nullptr)
                return 1;
            return 0;
        }

        void golire(){
            for(int i=0; i<65521;i++)
                while(hash[i]!= nullptr)
                    stergere(hash[i]->valoare);
        }

};



int main(){

    std::ifstream f("hashuri.in");
    std::ofstream g("hashuri.out");

    int operatie,valoare,n,ok=0;
    Hash table;

    f>>n;
    while(n>0){
        f>>operatie>>valoare;
        switch (operatie) {
            case 1:
                table.inserare(valoare);
                break;
            case 2:
                table.stergere(valoare);
                break;
            case 3:
                if(ok)
                    g<<"\n";
                g<<table.find(valoare);
                ok=1;
                break;
        }
        n--;
    }



    table.golire();

    f.close();
    g.close();

    return 0;
}