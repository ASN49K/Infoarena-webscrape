#include<iostream>
#include<vector>
#include<fstream>
using namespace std;



int main()
{
    int k=666013;
    vector<vector<int>> hashuri(k+3);

    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");
    int n;
    fin>>n;
    for(int i=0;i<n;i++){
        int op, x;
        fin>>op>>x;
        switch(op){
            case 1:
                hashuri[x%k].push_back(x);
                break;
            case 2:
                for(auto i = hashuri[x%k].begin(); i!=hashuri[x%k].end(); i++){
                    if(*i==x){
                        hashuri[x%k].erase(i);
                        break;
                    }
                }
                break;
            case 3:
                int gasit=0;
                for(auto i = hashuri[x%k].begin(); i!=hashuri[x%k].end(); i++){
                    if(*i==x){
                        fout<<"1\n";
                        gasit=1;
                        break;
                    }
                }
                if(!gasit)
                    fout<<"0\n";
        }
    }
    fout.close();
    fin.close();

    return 0;
}
