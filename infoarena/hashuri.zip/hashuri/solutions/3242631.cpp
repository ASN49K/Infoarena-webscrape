#include <fstream>
#include <vector>
using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hashuri.out");
#define MOD 666013
vector <int> v[MOD];
vector <int> :: iterator it;
int h(int n)
{
    return n%MOD;
}
int check(int poz, int nr)
{
    for(it=v[poz].begin();it!=v[poz].end();it++)
        if(*it==nr)
            return 1;
    return 0;
}
void add(int poz, int nr)
{
    if(!check(poz,nr))
        v[poz].push_back(nr);
}
void del(int poz, int nr)
{
    for(it=v[poz].begin();it!=v[poz].end();it++)
        if(*it==nr)
        {
            v[poz].erase(it);
            return;
        }
}
int main()
{
    int n,i,t,nr;
    cin>>n;
    for(i=1;i<=n;i++)
    {
        cin>>t>>nr;
        if(t==1)
            add(h(nr),nr);
        else
        if(t==2)
            del(h(nr),nr);
        else
            cout<<check(h(nr),nr)<<'\n';
    }
    return 0;
}
