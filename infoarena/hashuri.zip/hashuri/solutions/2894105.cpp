#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");
#define P 666013

vector<int>V[P];

vector<int>::iterator find(int x){
    int mod;
    mod = x%P;
    
    vector<int>::iterator ptr;

    for(ptr=V[mod].begin(); ptr!=V[mod].end(); ptr++){
        if(*ptr==x){return ptr;}
    }
    return V[mod].end();
}

void insert(int x){
    int mod;
    mod = x%P;
    if(find(x) == V[mod].end()){
        V[mod].push_back(x);
    }
}

void erase(int x){
    int mod;
    mod = x%P;
    if(find(x)!=V[mod].end()) {
        V[mod].erase(find(x));
    }
}

int verif(int x){
    int mod;
    mod = x%P;
    if(find(x)==V[mod].end()){
        return 0;
    }
    return 1;
}

int main(){

    int n,x,op;
    f>>n;
    while(n!=0){

        f>>op>>x;
        if(op==1){
            insert(x);
            cout<<"in ";
        }
        else if(op==2){
            erase(x);
            cout<<"er ";
        }
        else if(op==3){
            g<<verif(x)<<"\n";
            cout<<"ver ";
        }
        n--;
    }

    return 0;
}

