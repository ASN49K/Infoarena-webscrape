#include <iostream>
#include <unordered_set>

using namespace std;

unordered_set<int> m;

int main()
{
    freopen("hashuri.in", "r", stdin);
    freopen("hashuri.out", "w", stdout);
    cin.tie(nullptr)->sync_with_stdio(0);

    int q;
    cin >> q;
    while(q--) {
        int tip;
        cin >> tip;
        if(tip == 1) {
            int x;
            cin >> x;
            m.insert(x);
        }
        else if(tip == 2) {
            int x;
            cin >> x;
            m.erase(x);
        }
        else {
            int x;
            cin >> x;
            cout << m.count(x) << '\n';
        }
    }
    return 0;
}
