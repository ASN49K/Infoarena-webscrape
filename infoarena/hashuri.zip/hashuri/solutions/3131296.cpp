#include <iostream>
#include <unordered_set>
#include <fstream>

using namespace std;

int main() {
    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");

    int n;
    fin >> n;

    unordered_set<int> hashSet;

    for (int i = 0; i < n; i++) {
        int operation, x;
        fin >> operation >> x;

        if (operation == 1) {
            hashSet.insert(x);
        } else if (operation == 2) {
            hashSet.erase(x);
        } else if (operation == 3) {
            if (hashSet.find(x) != hashSet.end()) {
                fout << "1\n";
            } else {
                fout << "0\n";
            }
        }
    }

    fin.close();
    fout.close();

    return 0;
}

