#include <iostream>
#include <fstream>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
int n,op,x,baza,optim,heshu[9973][1000];
int main()
{   f>>n;
    baza=9973;
    for(int i=1;i<=n;i++)
    {   f>>op>>x;
        optim=x%baza;
        int ok=0;
        int poz=-1;
        if(op==1)
        {   for(int j=1;j<=heshu[optim][0];j++)
                if(heshu[optim][j]==x)
                    ok=1;
            if(ok!=1)
            {   heshu[optim][0]++;
                heshu[optim][heshu[optim][0]]=x;
            }
        }
        if(op==2)
        {   for(int j=1;j<=heshu[optim][0];j++)
                if(heshu[optim][j]==x)
                {   ok=1;
                    poz=j;
                }
            if(ok==1)
            {   for(int j=poz;j<heshu[optim][0];j++)
                    heshu[optim][j]=heshu[optim][j+1];
                heshu[optim][0]--;
            }
        }
        if(op==3)
        {   for(int j=1;j<=heshu[optim][0];j++)
                if(heshu[optim][j]==x)
                    ok=1;
            g<<ok<<'\n';
        }
    }
    f.close();
    g.close();
    return 0;
}
