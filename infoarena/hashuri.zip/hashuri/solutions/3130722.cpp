#include <fstream>
#include <vector>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

const unsigned long long int MAX = 49999991;

vector<bool> fr(MAX + 1, false);

int main() {
    unsigned long long int n, i, x, y;
    f >> n;

    for (i = 0; i < n; i++)
    {
        f >> x >> y;
        if (x == 1)
        {
            fr[y% 49999991] = true;
        }
        else if (x == 2)
        {
            fr[y% 49999991] = false;
        }
        else if (x == 3)
        {
            if (fr[y% 49999991])
            {
                g << "1" << '\n';
            }
            else
            {
                g << "0" << '\n';
            }
        }
    }

    return 0;
}