#include <iostream>
#include <map>
#include <fstream>

using namespace std;

ifstream f ("hashuri.in");
ofstream g ("hashuri.out");

map < long long , long long > m;

int n , c , x;

int main()
{
    f >> n;
    for (int i = 1 ; i <= n ; i++)
    {
        f >> c >> x;
        if (c == 1)
            m[x] = 1;
        else
           if (c == 2)
              m[x] = 0;
        else
            if (c == 3)
               if (m[x] == 1)
               g << 1 << '\n';
        else
            g << 0 << '\n';
    }
    return 0;
}
