#include <fstream>
#include <algorithm>
#include <vector>

#define MOD 666013

using namespace std;

ifstream cin("hashuri.in");
ofstream cout("hashuri.out");

int n;
vector<int> h[MOD + 3];

vector<int>::interator find_value_hash(int x);
void insert_value_hash(int x);
void erase_value_hash(int x);

int main() {
  int nrop; cin >> nrop;
  while(nrop--) {
    int op, x; cin >> op >> x;
    if(op == 1) {
      insert_value_hash(x);
    }
    else if(op == 2) {
      erase_value_hash(x);
    }
    else {
      cout << (find_value_hash(x) != h[x % MOD].end()) << '\n';
    }
  }
}

vector<int>::iterator find_value_hash(int x) {
  int nrhash = x % MOD;
  vector<int>::interator it;
  for(auto it : h[nrhash]) {
    if(it == x) {
      return it;
    }
  }
  return h[nrhash].end();
}

void insert_value_hash(int x) {
    int nrhash = x % MOD;
    if(find_value_hash(x) == h[nrhash].end()) {
      h[nrhash].push_back(x);
    }
}

void erase_value_hash(int x) {
  int nrhash = x % MOD;
  vector<int>::iterator it = find_value_hash(x);
  if(it != h[nrhash].end()) {
    h[nrhash].erase(x);
  }
}
