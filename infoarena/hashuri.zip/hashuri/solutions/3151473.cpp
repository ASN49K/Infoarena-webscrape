#include <fstream>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

const int K=1<<19;
const int N=1e6;

int lst[K],val[N+1],urm[N+1],nr;

int pozitie(int cat,int x)
{
    for(int p=lst[cat];p!=0;p=urm[p])
    {
        if(val[p] == x)
            return p;
    }
    return -1;
}

void adauga(int x)
{
    int cat=x&(K-1); //x % K merge doar la K (putere a lui 2) - 1, (ultimii biti sunt 1)
    int p=pozitie(cat,x);
    if(p==-1)
    {
        nr++;
        val[nr]=x;
        urm[nr]=lst[cat];
        lst[cat]=nr;
    }
}

void stergere(int x)
{
    int cat=x&(K-1);
    int p=pozitie(cat,x);
    if(p!=-1)
    {
        val[p] = val[lst[cat]];
        lst[cat]=urm[lst[cat]];
    }
}

bool exista(int x)
{
    int cat=x&(K-1);
    return (pozitie(cat,x)!=-1);
}

int main()
{
    int t;
    fin>>t;
    for(int i=0;i<t;i++)
    {
        int tip,x;
        fin>>tip>>x;
        if(tip == 1)
            adauga(x);
        else if(tip == 2)
            stergere(x);
        else fout<< exista(x)<<'\n';
    }
    return 0;
}
