#include <bits/stdc++.h>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

#define nmax 999983
vector <int> table[nmax];

int ntask;

void task1(int x){
    int bucket = x % nmax;
    int ok = 0;
    for(auto it : table[bucket]){
        if(it == x){
            ok = 1;
            break;
        }
    }
    if(ok == 0){
        table[bucket]. push_back(x);
    }
}

void task2(int x){
    int bucket = x % nmax;
    for(auto it = table[bucket].begin(); it != table[bucket].end(); it++){
        if(*it == x){
            table[bucket].erase(it);
            break;
        }
    }
}

int task3(int x){
    int bucket = x % nmax;
    int ok = 0;

    for(auto it : table[bucket]){
        if(it == x){
            ok = 1;
            break;
        }
    }

    if(ok == 1)
        return 1;

    return 0;
}

int main()
{
    fin >> ntask;
    while(ntask--){
        int tasknum;
        fin >> tasknum;
        if(tasknum == 1){
            int x;
            fin >> x;
            task1(x);
        }
        else if(tasknum == 2){
            int x;
            fin >> x;
            task2(x);
        }
        else if(tasknum == 3){
            int x;
            fin >> x;
            fout << task3(x) << '\n';
        }
    }
    return 0;
}
