#include <iostream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");

vector<int> mp[2000000];


int este(int nr)
{
    for(int i=0;i<mp[nr/1000].size();i++)
        if(mp[nr/1000][i]==nr)
            return i+1;
    return 0;
}

int main()
{
    int n,m,i,j,k,t,q,nr,minim,maxim;
    fin>>n;
    while(n--)
    {
        fin>>i>>j;
        if(i==1)
        {
            if(este(j)==0)
                mp[j/1000].push_back(j);
        }
        else if(i==2)
        {
            nr=este(j);
            if(nr)
            {
                mp[j/1000].erase(mp[j/1000].begin() + nr-1);
            }
        }
        else
        {
            nr=este(j);
            if(nr)
                fout<<"1\n";
            else
                fout<<"0\n";
        }
    }
    return 0;
}
