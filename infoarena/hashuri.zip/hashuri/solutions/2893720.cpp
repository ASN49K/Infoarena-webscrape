#include <bits/stdc++.h>
#include <fstream>

using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");

int n, p = 666013, i, x, operatie, hashedX, ok, j, vSize;
vector<vector<int>> hashMatrix(666015);  //avem cate o lista pentru fiecare rest de la 0 la p - 1

int main()
{
    in>>n;

    for(i = 0; i < n; i++)
    {
        in>>operatie>>x;
        hashedX = x % p;
         vSize = hashMatrix[hashedX].size();

        if(operatie == 1)
        {
            ok = 0;

            for(j = 0; j < vSize; j++)
                if(hashMatrix[hashedX][j] == x)
                {
                    ok = 1;
                    break;
                }

            if(!ok)
                hashMatrix[hashedX].push_back(x);
        }
        else if(operatie == 2)
        {
            for(j = 0; j < vSize; j++)
                if(hashMatrix[hashedX][j] == x)
                {
                    hashMatrix[hashedX][j] = hashMatrix[hashedX][vSize - 1];
                    hashMatrix[hashedX].pop_back();
                    break;
                }

        }
        else
        {
            ok = 0;

            for(j = 0; j < vSize; j++)
                if(hashMatrix[hashedX][j] == x)
                {
                    ok = 1;
                    break;
                }

            out<<ok<<endl;
        }
    }


    return 0;
}
