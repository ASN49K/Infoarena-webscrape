#include <bits/stdc++.h>
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
map<int, int> ap;

signed main()
{
    int n;
    fin >> n;
    while(n--)
    {
        int op, x;
        fin >> op >> x;
        if(op == 1)
            ap[x] = 1;
        else if(op == 2)
            ap[x] = 0;
        else
            fout << ap[x] << '\n';
    }

    return 0;
}
