#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>

using namespace std;

ifstream cin("hashuri.in");
ofstream cout("hashuri.out");

const int N = 1e6;
const int MOD = 666013;
const int baza = 31;
vector<int> H[MOD + 5];

int Hash(int number){
    int sum = 0;
    while(number){
        sum = (sum * baza + (number % 10) * baza) % MOD;
        number /= 10;
    }
    return sum;
}

int main() {
    int n;
    cin >> n;
    for (int i = 0; i < n; ++i) {
        char op;
        int number;
        cin >> op >> number;
        auto it = find(H[Hash(number)].begin(), H[Hash(number)].end(), number);
        if(op == '1')
            H[Hash(number)].push_back(number);
        else if(op == '2') {
            if (it != H[Hash(number)].end())
                H[Hash(number)].erase(it);
        }
        else
            cout << bool(it != H[Hash(number)].end()) << '\n';
    }
    return 0;
}
