#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
using namespace std;
#define size 666079
vector<long long >h[size];

int main() {
    ifstream f("hashuri.in");
    ofstream g("hashuri.out");
    long long n,op,x;
    f>>n;
    while (f>>op>>x)
    {
        vector<long long > ::iterator i;

         if(op == 1)
         {
             for ( i = h[x%size].begin();i != h[x%size].end();++i)
                if(*i == x)
                    break;
             if(i == h[x%size].end())
                 h[x%size].push_back(x);
         }
         else if(op == 2)
        {
            for ( i = h[x%size].begin();i != h[x%size].end();++i)
                if(*i == x) { h[x % size].erase(i); break;}
        }
         else
         {
             int ok = 0;
             for ( i = h[x%size].begin();i != h[x%size].end() && ok == 0;++i)
                 if(*i == x)
                 {g<<1<<'\n';ok = 1;}
             if(ok == 0)
                 g<<0<<'\n';
         }
    }

    f.close();g.close();
    return 0;
}