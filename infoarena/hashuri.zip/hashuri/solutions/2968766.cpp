#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");

const int MOD = 666019;
int baza;
vector<int>hashh[MOD+1];

int prim(long long nr)
{
    for(int d=2;d*d<=nr;d++)
        if(nr%d==0)
            return 0;
    return 1;
}


int hashuri(int nr)
{
    int hashul=0;
    int p=1;
    while(nr)
    {
        int cif=nr%10;
        hashul=(hashul%MOD)+((cif*p)%MOD)%MOD;
        p=(p*baza)%MOD;
        nr/=10;
    }
    return hashul;
}

int main()
{

    for(int i=500000;i<600000;i++)
        if(prim(i)==1)
            baza=i;
    int n;
    in>>n;
    for(int i=1;i<=n;i++)
    {
        int op,val;
        in>>op>>val;
        int hashnr=hashuri(val);

        auto find_elem=find(hashh[hashnr].begin(),hashh[hashnr].end(),val);//gaseste elem val din multime

        if(op==1 && find_elem==hashh[hashnr].end())//nu exista in multime)
        {
           hashh[hashnr].push_back(val);
        }

        if(op==2 && find_elem!=hashh[hashnr].end())//exista in multime)
        {
            hashh[hashnr].erase(find_elem);

        }
        if(op==3)
        {
            if(find_elem!=hashh[hashnr].end())
                out<<"1"<<'\n';
            else
                out<<"0"<<'\n';
        }

    }
    return 0;
}
