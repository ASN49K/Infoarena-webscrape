#include <fstream>
#include <vector>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

vector <bool> fr;

int main() {
    long long int n, i, x, y;
    f >> n;
    fr.resize(n + 5);
    for (i = 0; i < n; i++)
    {
        f >> x >> y;
        if (x == 1)
        {
            fr[y] = 1;
        }
        if (x == 2)
        {
            fr[y] = 0;
        }
        if (x == 3)
        {
            if (fr[y] == 1)
            {
                g << "1" << '\n';
            }
            else
                g << "0" << '\n';
        }
    }

    return 0;
}
