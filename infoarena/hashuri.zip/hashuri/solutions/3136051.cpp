#include <bits/stdc++.h>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
set<int> S;
int n,tip,x;
int main()
{
    f>>n;
    for(;n;n--)/// de T ori
    {
        f>>tip>>x;
        if(tip==1)
            S.insert(x);
        else if(tip==2)
            S.erase(x);
        else
            if(S.find(x)==S.end())
                g<<"0\n";
            else
                g<<"1\n";
    }
    return 0;
}
