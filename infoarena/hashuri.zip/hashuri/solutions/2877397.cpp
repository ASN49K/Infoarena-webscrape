#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

const int m = 666013;


const long long p1 = 872742023, p2 = 489174503;
const long long a1 = 324892358, b1 = 728741242;
const long long a2 = 817247897, b2 = 682739174;


int hashfunc1(long long x) {
	return ((long long)(a1 * x + b1)) % m;
}

int hashfunc2(long long x) {
	return ((long long)(a2 * x + b2)) % m;
}


long long T1[m], T2[m];


bool Exists(long long x) {
	return (T1[hashfunc1(x)] == x || T2[hashfunc2(x)] == x);
}


void Insert(long long x) {
	if (Exists(x))
		return;

	int hash1 = hashfunc1(x);
	int hash2 = hashfunc2(x);
	while (true) {
		if (T1[hash1] == 0) {
			T1[hash1] = x;
			return;
		}

		swap(x, T1[hash1]);
		hash1 = hashfunc1(x);
		hash2 = hashfunc2(x);

		if (T2[hash2] == 0) {
			T2[hash2] = x;
			return;
		}

		swap(x, T2[hash2]);
		hash1 = hashfunc1(x);
		hash2 = hashfunc2(x);
	}
	return;
}


void Delete(long long int x) {
	int hash1 = hashfunc1(x);
	int hash2 = hashfunc2(x);

	if (T1[hash1] == x) {
		T1[hash1] = 0;
	}

	if (T2[hash2] == x) {
		T2[hash2] = 0;
	}
	return;
}

int main() {
	long long int n, c, x;
	in >> n;
	for (int i{}; i < n; ++i) {
		in >> c >> x;
		if (c == 1) {
			Insert(x);
		}
		else if (c == 2) {
			Delete(x);
		}
		else {
			out << Exists(x) << "\n";
		}
	}
	return 0;
}