#include <bits/stdc++.h>
#define p 666013

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int n, op,q;
vector <int> a[p];
void Add(int x)
{
    int i;
    int r = x % p;
    for (i = 0; i < a[r].size(); i++)
        if (a[r][i] == x)
        return;
    a[r].push_back(x);
}

void Delete(int x)
{
    int i,r = x % p;
    for (i = 0; i < a[r].size(); i++)
        if (a[r][i] == x)
        {
            a[r][i] = a[r][i - 1];
            a[r].pop_back();
            return;
        }
}
int Find(int x)
{
    int i, r = x % p;
    for (i = 0; i < a[r].size(); i++)
        if (a[r][i] == x)
        return 1;
    return 0;
}
int main()
{
    int i, x;
    fin >> q;
    while (q--)
    {
        fin >> op >> x;
        if (op == 1)
            Add(x);
        else if (op == 2)
            Delete(x);
        else
            fout << Find(x) << "\n";
    }
    return 0;
}
