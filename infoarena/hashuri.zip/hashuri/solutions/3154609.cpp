#include <fstream>

using namespace std;

const int K = 1 << 20;
const int N = 1e6;

int lst[K], val[N+1], urm[N+1], nr;

int pozitie(int cat, int x)
{
    for (int p = lst[cat]; p != 0; p = urm[p])
    {
        if (val[p] == x)
        {
            return p;
        }
    }
    return  -1;
}

void adauga(int x)
{
    int cat = x & (K - 1);//x % K;
    int  p = pozitie(cat, x);
    if (p == -1)
    {
        nr++;
        val[nr] = x;
        urm[nr] = lst[cat];
        lst[cat] = nr;
    }
}

void sterge(int x)
{
    int cat = x & (K - 1);//x % K;
    int  p = pozitie(cat, x);
    if (p != -1)
    {
        val[p] = val[lst[cat]];
        lst[cat] = urm[lst[cat]];
    }
}

bool cauta(int x)
{
    int cat = x & (K - 1);//x % K;
    return (pozitie(cat, x) != -1);
}

int main()
{
    ifstream in("hashuri.in");
    ofstream out("hashuri.out");
    int nq;
    in >> nq;
    for (int i = 0; i < nq; i++)
    {
        int tip, x;
        in >> tip >> x;
        if (tip == 1)
        {
            adauga(x);
        }
        else if (tip == 2)
        {
            sterge(x);
        }
        else
        {
            out << cauta(x) << "\n";
        }
    }
    in.close();
    out.close();
    return 0;
}
