#include <iostream>
#include <fstream>
#include <vector>

std::ifstream f("hashuri.in");
std::ofstream g("hashuri.out");

#define MOD 666013
std::vector<int> hash[MOD];

int exists(int x)
{
    int hi = x%MOD;
    for (int i = 0; i < hash[hi].size(); ++i) {
        if (hash[hi][i] == x) {
            return 1;
        }
    }
    return 0;
}

void insert(int x)
{
    if (exists(x)) { return; }
    hash[x%MOD].push_back(x);
}

void remove(int x)
{
    int hi = x%MOD;
    for (int i = 0; i < hash[hi].size(); ++i) {
        if (hash[hi][i] == x) {
            hash[hi][i] = hash[hi][hash[hi].size() - 1];
            hash[hi].pop_back();
            return;
        }
    }
}


int main()
{
    int t;
    f >> t;
    std::cout << t << std::endl;
    for (int i = 0; i < t; ++i) {
        int op, x;
        f >> op >> x;

        switch (op) {
            case 1: {
                insert(x);
            } break;

            case 2: {
                remove(x);
            } break;

            case 3: {
                g << exists(x) << '\n';
            } break;
        }
    }

    return 0;
}