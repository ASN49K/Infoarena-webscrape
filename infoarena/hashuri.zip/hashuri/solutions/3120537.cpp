#include<bits/stdc++.h>
using namespace std;
ifstream F("hashuri.in");
ofstream G("hashuri.out");
int m=9973,k,c,n;
vector<int> v[9973];
vector<int>::iterator i;
int main()
{
    for(F>>n;n--;)
        if(F>>c>>k,i=find(v[k%m].begin(),v[k%m].end(),k),c==1&&i==v[k%m].end())
            v[k%m].push_back(k);
        else if(c==2&&i!=v[k%m].end())
            v[k%m].erase(i);
        else if(c==3)
            G<<(i!=v[k%m].end())<<'\n';
    return 0;
}
