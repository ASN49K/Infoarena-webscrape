#include <stdio.h>

#define BAZA 31
#define MOD 100000007

char f[MOD];

int main()
{
    //FILE *fin = fopen("D:/GitHub_Repos/AlgoArchive/Algo_v2/InfoArena/Hashuri/hashuri.in", "r");
    //FILE *fout = fopen("D:/GitHub_Repos/AlgoArchive/Algo_v2/InfoArena/Hashuri/hashuri.out", "w");
    FILE *fin = fopen("hashuri.in", "r");
    FILE *fout = fopen("hashuri.out", "w");

    int q, t, i;
    char ch;
    unsigned long long enc;

    fscanf(fin, "%d", &q);
    for(i=0; i<q; i++) {
        fscanf(fin, "%d ", &t);
        ch = fgetc(fin);
        enc = 0;
        while(ch!='\n' && ch!=EOF) {
            enc = (enc*BAZA%MOD+(ch-'('))%MOD;
            ch = fgetc(fin);
        }
        if(t==1)
            f[enc] = 1;
        else if(t==2)
            f[enc] = 0;
        else 
            fprintf(fout, "%d\n", f[enc]);
    }
    fclose(fin);
    fclose(fout);
    return 0;
}