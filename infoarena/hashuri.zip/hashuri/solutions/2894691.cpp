
#include <fstream>
#include<vector>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

vector<int> myhash[666018];

int main()
{
    int k=666018;
    int n, operatie, element;
    f>>n;
    int clasa;
    for(int i=1;i<=n;i++)
        {f>>operatie>>element;
        clasa=element%k;
        int found=0;
        for(unsigned int j=0;j<myhash[clasa].size();j++)
            if (myhash[clasa][j]==element)
            {
                found = 1;
                break;
            }
        if(operatie==1)

        {  if (found==0)
                myhash[clasa].push_back(element);
        }

        if(operatie==2)
        {  if (found==1)
            {
                swap(element, myhash[clasa].back());
                myhash[clasa].pop_back();
            }

        }

        if(operatie==3)
        {
            g<<found<<'\n';

        }


        }

}
