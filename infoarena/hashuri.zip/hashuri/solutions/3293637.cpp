#include <fstream>
#include <map>
#include <unordered_map>
using namespace std;
ifstream cin ("hashuri.in");
ofstream cout ("hashuri.out");
int main()
{
    unordered_map <int,int> m;
    int n;
    cin>>n;
    int c,x;
    for (int i=1;i<=n;i++)
    {
        cin>>c>>x;
        if (c==1)
        {
            m[x]=1;
        }
        if (c==2)
        {
            m[x]=0;
        }
        if (c==3)
        {
            if (m[x]==1)
            {
                cout<<"1"<<'\n';
            }
            else
                cout<<"0"<<'\n';
        }
    }
    return 0;
}
