//#include <iostream>
#include <vector>
#include <fstream>
//using namespace std;
std::ifstream cin("hashuri.in");
std::ofstream cout("hashuri.out");
template<const int size>
class Hash{
    std::vector<long long> vals;
    std::vector<long long> next;
    std::vector<long long> start;
    std::vector<long long> liber;
public:
    Hash(){vals.resize(1);
        next.resize(1);
        start.resize(size);
        liber.clear();
    }
    void add(long long val){
        long long h = val % size;
        long long poz;
        if(!liber.empty()){
            poz = liber.back();
            liber.pop_back();
            vals[poz] = val;
            next[poz] = start[h];
        }else{
            vals.push_back(val);
            next.push_back(start[h]);
            poz = vals.size() -1;
        }
        start[h] = poz;
    }
    void erase(long long val){
        long long h = val % size;
        long long poz = start[h];
        if(vals[poz] == val){
            start[h] = next[poz];
            liber.push_back(poz);
            return;
        }
        while(next[poz]){
            if(vals[next[poz]]==val){
                liber.push_back(next[poz]);
                next[poz] = next[next[poz]];
                break;
            }
            poz = next[poz];
        }
    }
    bool find(long long val){
        long long h = val % size;
        long long poz = start[h];
        while(poz){
            if(vals[poz]==val){
                return true;
            }
            poz = next[poz];
        }
        return false;
    }
};

int main() {
    long long n;
    cin>>n;
    Hash<666013> hash;
    for(long long i=0;i<n;i++){
        long long comanda, nr;
        cin>>comanda>>nr;
        switch (comanda) {
            case 1:{hash.add(nr);break;}
            case 2:{hash.erase(nr);break;}
            case 3:{cout<<hash.find(nr)<<'\n';break;}
            default:{}
        }
    }
    return 0;
}
