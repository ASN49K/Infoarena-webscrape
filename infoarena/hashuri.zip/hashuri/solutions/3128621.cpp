#include<iostream>
#include<fstream>
#include<vector>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int cautare(vector<vector<int>>v ,int nr ){
    int mod = nr%666103;
    for(unsigned int j = 0 ; j < v[mod].size() ; j++)
        if(v[mod][j] == nr) return j+1;
    return 0;
}

int main(){
    vector<vector<int>>v(666103);
    int n,k,nr;
    fin>>n;
    for(int i = 0 ; i < n ; i++){
        fin>>k>>nr;
        int mod = nr%666103;
        switch(k){

            case 1:
                if(!cautare(v,nr))
                    v[mod].push_back(nr);
                break;

            case 2:
                if(cautare(v,nr))
                    for(unsigned int j = 0 ; j < v[mod].size() ; j++)
                        if(v[mod][j] == nr){
                            v[mod].erase(v[mod].begin() + j);
                            break;
                        }
                break;

            case 3:
                if(cautare(v,nr)) fout<<"1\n";
                else    fout<<"0\n";
                break;
        }
    }

fin.close();
fout.close();
return 0;
}
