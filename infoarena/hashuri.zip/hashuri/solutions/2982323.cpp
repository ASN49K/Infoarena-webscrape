#include <iostream>
#include <map>
#include <fstream>

using namespace std;

ifstream f ("hashuri.in");
ofstream g ("hashuri.out");

map < int , int > m;

int n , c , x;

int main()
{
    f >> n;
    for (int i = 1 ; i <= n ; i++)
    {
        f >> c >> x;
        if (c == 1 && m.find(x) == m.end())
            m[x] = 1;
        else
           if (c == 2)
              m.erase(x);
        else
            if (c == 3)
            g << (m.find(x)!=m.end()) << '\n';;

    }
    return 0;
}
