#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("hasuri.in");
ofstream fout ("hasuri.out");

int multime[100000000000], l=0, N;

int gaseste(int x){
    for(int i=0; i<l; i++)
        if (multime[i]==x)
            return i;
    return -1;
}

void inserare(int x){
    if(gaseste(x) == -1) {
        multime[l] = x;
        l++;
    }
}

inline void stergere(int x)
{
    if (gaseste(x)!=-1) {
        for (int i = gaseste(x); i < l; i++)
            multime[i] = multime[i + 1];
        l = l - 1;
    }
}

int main() {
    int op, x;
    fin >> N;

    for (int i = 0; i<N; i++) {
        fin >> op >>x;
        if (op == 1)
            inserare(x);

        if (op == 2)
            stergere(x);

        if (op == 3)
            if (gaseste(x) == -1)
                fout << 0 <<endl;
            else fout << 1<< endl;

    }

    return 0;
}