#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector<int> has[535607];

int verificare(int x, int key){
    for(int i = 0; i<has[key].size(); i++){
        if(has[key][i] == x){
            return i;
        }
    }
    return -1;
}

void stergere(int x, int key){
    for(int i = 0; i<has[key].size(); i++){
        if(has[key][i] == x) {
            has[key].erase(has[key].begin() + i);
            break;
        }
    }
}
int main() {
    int N;
   fin>>N;
   for(int i = 0; i<N; i++){
       int op, x;
       fin>>op>>x;
       int key = x % 535607;
       if(op == 1){
           int OK = verificare(x, key);
           if(OK == -1)
               has[key].push_back(x);
       }
       else
           if(op == 2){
               stergere(x, key);
           }
           else{
                int OK = verificare(x, key);
                if(OK !=-1)
                    fout<<1<<endl;
                else
                    fout<<0<<endl;
           }
   }
    return 0;
}
