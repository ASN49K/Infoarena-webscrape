#include <fstream>
#include <string>
#include <stdio.h>
#include <vector>
#include <algorithm>
#include <math.h>
#include <set>
#include <map>
#include <string.h>
#include <queue>
#include <stack>
#include <iostream>

#define INF 0x3f3f3f3f

using namespace std;

#ifdef DEBUG
string name = "data";
#else
string name = "hashuri";
#endif

class InParser {
    vector<char> str;
    int ptr;
    ifstream fin;

    char getChar() {
        if (ptr == int(str.size())) {
            fin.read(str.data(), str.size());
            ptr = 0;
        }
        return str[ptr++];
    }

    template<class T>
    T getInt() {
        char chr = getChar();
        while (!isdigit(chr) && chr != '-')
            chr = getChar();
        int sgn = +1;
        if (chr == '-') {
            sgn = -1;
            chr = getChar();
        }
        T num = 0;
        while (isdigit(chr)) {
            num = num * 10 + chr - '0';
            chr = getChar();
        }
        return sgn * num;
    }

public:
    InParser(const char* name) : str(1e5), ptr(str.size()), fin(name) { }
    ~InParser() { fin.close(); }

    template<class T>
    friend InParser& operator>>(InParser& in, T& num) {
        num = in.getInt<T>();
        return in;
    }
};
class OutParser {
    vector<char> str;
    int ptr;
    ofstream fout;

    void putChar(char chr) {
        if (ptr == int(str.size())) {
            fout.write(str.data(), str.size());
            ptr = 0;
        }
        str[ptr++] = chr;
    }

    template<class T>
    void putInt(T num) {
        if (num < 0) {
            putChar('-');
            num *= -1;
        }
        if (num > 9)
            putInt(num / 10);
        putChar(num % 10 + '0');
    }

public:
    OutParser(const char* name) : str(1e5), ptr(0), fout(name) { }
    ~OutParser() { fout.write(str.data(), ptr); fout.close(); }

    template<class T>
    friend OutParser& operator<<(OutParser& out, const T num) {
        out.putInt(num);
        return out;
    }

    friend OutParser& operator<<(OutParser& out, const char chr) {
        out.putChar(chr);
        return out;
    }

    friend OutParser& operator<<(OutParser& out, const char* str) {
        for (int i = 0; str[i]; i++)
            out.putChar(str[i]);
        return out;
    }
};

InParser fin("hashuri.in");
OutParser fout("hashuri.out");

#define MAXN 4000000

int h[MAXN];

// linear probing

void insert(int x) {
    int k = x % MAXN;
    
    for (int i = k; i < MAXN; ++i) {
        if (h[i] == 0) {
            h[i] = x;
            return;
        }
    }
    
    for (int i = 0; i < k; ++i) {
        if (h[i] == 0) {
            h[i] = x;
            return;
        }
    }
}

void del(int x) {
    int k = x % MAXN;
        
    for (int i = k; i < MAXN; ++i) {
        if (h[i] == 0) {
            return;
        }
        
        if (h[i] == x) {
            h[i] = 0;
            return;
        }
    }
    
    for (int i = 0; i < k; ++i) {
        if (h[i] == 0) {
            return;
        }
        
        if (h[i] == x) {
            h[i] = 0;
            return;
        }
    }

}

int find(int x) {
    int k = x % MAXN;
        
    for (int i = k; i < MAXN; ++i) {
        if (h[i] == 0) {
            return 0;
        }
        
        if (h[i] == x) {
            return 1;
        }
    }
    
    for (int i = 0; i < k; ++i) {
        if (h[i] == 0) {
            return 0;
        }
        
        if (h[i] == x) {
            return 1;
        }
    }
    
    return 0;
}

int main() {
    int n;
    fin >> n;
    for (int i = 0; i < n; ++i) {
        int op, x;
        fin >> op >> x;
        
        if (op == 1) {
            insert(x);
        }
        if (op == 2) {
            del(x);
        }
        if (op == 3) {
            fout << find(x) << "\n";
        }
    }
    
   
    
    return 0;
}
