#include <fstream>
#include <vector>
#include <iostream>
#define MOD 666013
using namespace std;

vector <int> H[MOD];

int n;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

bool check(int nr) {
    int poz = nr % MOD;
    vector<int>::iterator pas;

    for (auto pas = H[poz].begin(); pas != H[poz].end(); ++pas)
        if (*pas == nr)
            return 1;
    return 0;
}

void eliminate(int nr) {
    int poz = nr % MOD;
    vector<int>::iterator pas;

    for (auto pas = H[poz].begin(); pas != H[poz].end(); ++pas)
        if (*pas == nr) {
            H[poz].erase(pas);
            break;
        }

}

void insert(int nr) {
    int poz = nr % MOD;
    if (!check(nr))
        H[poz].push_back(nr);
}






int main()
{
    int  nr, op;
    fin >> n;
    for (int i = 0; i < n; i++) {
        fin >> op >> nr;
        if (op == 1)
        {

            insert(nr);
            continue;
        }
        if (op == 2) {
            eliminate(nr);
            continue;
        }
        if (op == 3)
        {
            fout << check(nr) << '\n';
            continue;
        }
    }
    return 0;

}