#include <fstream>
#include <vector>
#define MOD 666013

using namespace std;

class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;

	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}

	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

	InParser& operator >> (long long &n) {
		char c;
		n = 0;
		while (!isdigit(c = read_ch()) && c != '-');
		long long sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
} f("hashuri.in");

class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
} g("hashuri.out");

int n, op, x;

vector <int> hashMap[MOD];

inline void insertHash(int k)
{
    int key = k % MOD;

    for (auto it : hashMap[key]) {
        if (it == k) {
            return;
        }
    }

    hashMap[key].push_back(k);
}

inline void eraseHash(int k)
{
    int key = k % MOD;

    for (int i = 0; i < (int) hashMap[key].size(); ++i) {
        if (hashMap[key][i] == k) {
            hashMap[key].erase(hashMap[key].begin() + i);
            return;
        }
    }
}

inline bool searchHash(int k)
{
    int key = k % MOD;

    for (auto it : hashMap[key]) {
        if (it == k) {
            return 1;
        }
    }

    return 0;
}

int main()
{
    f >> n;

    while (n--) {
        f >> op >> x;

        if (op == 1) {
            insertHash(x);
        }
        else if (op == 2) {
            eraseHash(x);
        }
        else {
            g << searchHash(x) << '\n';
        }
    }

    return 0;
}
