#include <iostream>
#include <unordered_map>
#include <fstream>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");

int main()
{
    int n,aux,aux2;
    f >> n;
    unordered_map<int, int> h;
    while (f >> aux >> aux2) {

        switch (aux) {
            case 1:
                if (!h.count(aux2)) {
                    h[aux2] = 1;
                }
                break;
            case 2:
                if(h.count(aux2) == 1)
                    h.erase(aux2);
                break;
            case 3:
                if(h.count(aux2) == 1)
                    g << 1 << endl;
                else if (h.count(aux)==0)
                    g<<0<<endl;
                break;
        }
    }

    f.close();
    g.close();

    return 0;
}
