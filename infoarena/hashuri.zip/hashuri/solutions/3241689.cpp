#include <fstream>
#include <map>
using namespace std;
ifstream  fin("hashuri.in");
ofstream fout("hashuri.out");
int N,i,op,x,nr;
map <int,int> M;
int main()
{
    fin>>N;

    nr=0;
    for(i=1; i<=N; i++)
    {
        fin>>op>>x;

        if(op==1 && M.find(x)==M.end())
        {
            M[x]=++nr;
        }

        if(op==2)
        {
            M.erase(x);
        }

        if(op==3)
        {
            if(M.find(x)!=M.end())
            {
                fout<< 1 << "\n";
            }
            else
            {
                fout<< 0 << "\n";
            }
        }
    }

    return 0;
}
