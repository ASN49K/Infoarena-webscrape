#include <iostream>
#include <vector>
using namespace std;
int n,a,ok;
vector< vector<int> > matrix;
vector<int> v;

int binarySearch( int p, int r, int num) {
   if(p==r)
   {
       return p;
   }
   if (p < r) {
      int mid = (p + r)/2;
      if (matrix[mid].back() < num)
         return binarySearch(p, mid, num);
    return binarySearch( mid+1, r, num);
   }
}

int main()
{
    cin>>n;
    cin>>a;
    v.push_back(a);
    matrix.push_back(v);

    for (int i=1;i<n;i++)
    {
            cin>>a;
            ok=0;
            int j=binarySearch(0,matrix.size()-1,a);
            if(matrix[j].back() < a)
            {
                        matrix[j].push_back(a);
                        ok=1;
            }
            if(ok==0)
            {
                v.clear();
                v.push_back(a);
                matrix.push_back(v);
            }

    }
    for(int i=0;i<(int) matrix.size();i++)
    {
        for(int j=0;j< (int) matrix[i].size();j++)
            cout<<matrix[i][j]<<' ';
        cout<<endl;
    }
    return 0;
}

