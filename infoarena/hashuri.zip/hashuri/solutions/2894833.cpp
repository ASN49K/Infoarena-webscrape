#include <iostream>
#include <fstream>
#include <vector>
#define val  666013

using namespace std;


ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector <int> M[val];

int check(int x){
    int l = x % val;
    vector <int> :: iterator pos;
    for  (pos = M[l].begin(); pos != M[l].end(); ++pos)
        if(*pos == x)
            return 1;
    return 0;
}

void inserare (int x){
    int l = x % val;
    if (check(x) == 0)
        M[l].push_back(x);

}

void stergere(int x){
    int l  = x % val;
    vector <int> :: iterator pos;
    for (pos = M[l].begin(); pos != M[l].end(); pos++)
        if (*pos == x) {
            M[l].erase(pos);
            break;
        }
}


int main() {
    int N, operatie, parametru;
    fin >> N;
    for (int i = 0; i < N; i++) {
        fin >> operatie >> parametru;
        if (operatie == 1)
            inserare(parametru);
        else if (operatie == 2)
            stergere(parametru);
        else fout << check(parametru) << endl;

    }
    return 0;
}