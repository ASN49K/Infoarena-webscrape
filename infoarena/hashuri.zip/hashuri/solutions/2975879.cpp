#include <bits/stdc++.h>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int main()
{
    int n;
    fin >> n;

    map<int, bool> m;
    for(int i = 1; i <= n; i++)
    {
        int type, x;
        fin >> type >> x;
        if(type == 1)
        {
            m[x] = true;
        }
        else if(type == 2)
        {
            m[x] = false;
        }
        else
        {
            if(m[x])
            {
                fout << "1\n";
            }
            else
            {
                fout << "0\n";
            }
        }
    }
    return 0;
}
