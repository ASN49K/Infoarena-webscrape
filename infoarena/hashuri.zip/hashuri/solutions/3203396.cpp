#include <bits/stdc++.h>

using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

multiset<int> s;
int n;

int main() {
    in >> n;

    for(int i = 0; i < n;i++){
        int task;
        int x;
        in >> task >> x;
        if(task == 1){
            s.insert(x);
        } else if(task == 2){
            s.erase(x);
        } else if(task == 3){
            if(s.find(x) != s.end()){
                out << 1 << '\n';
            } else {
                out << 0 << '\n';
            }
        }
    }

    return 0;
}
