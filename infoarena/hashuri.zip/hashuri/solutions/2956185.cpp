#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

const int NMAX = 1000000;

struct nod {
    int val;
    nod* next;
};

struct lista {

    nod* head;
    nod* tail;

    void addfirstitem( int x )
    {
        nod * newitem = new nod;
        newitem->val = x;
        newitem->next = NULL;
        head = newitem;
        tail = newitem;

    }

    void additem ( int x )
    {
        nod * newitem = new nod;
        tail->next = newitem;
        newitem->val = x;
        newitem->next = NULL;
        tail = newitem;

    }

    void deleteitem( int x )
    {
        nod * current = head;
        nod *deleted_el;
        if( head->val == x )
        {

            deleted_el = head;
            head = head->next;
        }
        else
        {

            while( current->next !=NULL && current->next->val != x )
                current = current->next;
            if( current->next !=NULL )
            {
                deleted_el = current->next;
                current->next = current->next->next;
            }

        }

        delete deleted_el;
        deleted_el = NULL;
    }


};

bool findEl(lista* l, int x) {

    if( l->head == NULL ) return 0;
    nod * current = l->head;
    while ( current->val != x ) {
        current = current->next;
    }
    return ( current != NULL );
}

lista* v[NMAX];

int main() {


    for( int i = 0; i < NMAX; i++ )
    {
        v[i] = new lista;
        v[i]->head = NULL;
        v[i]->tail = NULL;
    }
    int N;
    fin >> N;
    for (int i = 0; i < N; i++) {
        int op, x;
        fin >> op >> x;
        if (op == 1) {
            if ( !findEl(v[x % NMAX], x)) { // daca nu-l gasesc
                // adauga la lista
                    if( v[x % NMAX]->head == NULL ) v[x % NMAX]->addfirstitem(x);
                    else v[x % NMAX]->additem(x);

            }
        }
        if (op == 2) {
            if ( findEl(v[x % NMAX], x) ) { // daca il gasesc
                // sterge din lista

                v[x%NMAX]->deleteitem(x);
            }
        }
        if (op == 3) {
            { fout << findEl(v[x % NMAX], x) << '\n';

            }
        }
    }
    return 0;


}




