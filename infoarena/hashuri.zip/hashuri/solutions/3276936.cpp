#include <bits/stdc++.h>

using namespace std;

ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");

unordered_set <int> uset;

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    int n; fin>>n;
    for (int i=1; i<=n; i++) {
        int op, x; fin>>op>>x;
        if (op==1) uset.insert(x);
        if (op==2) uset.erase(x);
        if (op==3) fout<<uset.count(x)<<'\n';
    }
    return 0;
}