#include<bits/stdc++.h>
#define MOD 666013
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
vector <int> h[MOD];
int i, task, n, query;
int freq_val(int n){
    int nod = n % MOD;
    for(int i=0;i<h[nod].size();i++)
        if(n == h[nod][i])
            return 1;
    return 0;
}
void insert_val(int n){
    int nod = n % MOD;
    if(freq_val(n))
        return ;
    h[nod].push_back(n);
}
void erase_val(int n){
    int nod = n % MOD;
    if(!freq_val(n))
        return ;
    for(int i=0;i<h[nod].size();i++)
        if(n == h[nod][i])
            h[nod][i] = -1;
}
int main(){
    fin >> query;
    while(query--){
        fin >> task >> n;
        if(task == 1)
            insert_val(n);
        if(task == 2)
            erase_val(n);
        if(task == 3)
            fout << freq_val(n) << "\n";
    }
}
