#include <bits/stdc++.h>

using namespace std;
const int NR = 1e6 + 5;
const int MOD = 666013;
ifstream in("hashuri.in");
ofstream out("hashuri.out");
int n, tip, x, stackSize, s;
vector<int> st;
vector<int> h(MOD, -1);
struct hash {
    int v{}, n{};
} l[NR];

inline void insert(const int &y) {
    int hash = y - (y / MOD) * MOD;
    int p;
    if (!st.empty()) {
        p = st.back();
        st.pop_back();
    } else {
        p = stackSize++;
    }
    l[p].v = y;
    l[p].n = h[hash];
    h[hash] = p;
}

inline bool find(const int &y) {
    int i = h[y - (y / MOD) * MOD];
    while (i != -1 && l[i].v != y) {
        i = l[i].n;
    }
    return i != -1;
}

inline void erase(const int &y) {
    int hash = y - (y / MOD) * MOD;
    int i = h[hash];
    if (i == -1) {
        return;
    }
    if (l[i].v == y) {
        st.emplace_back(i);
        h[hash] = l[i].n;
    } else {
        while (l[i].n != -1 && l[l[i].n].v != y) {
            i = l[i].n;
        }
        if (l[i].n != -1) {
            st.emplace_back(l[i].n);
            l[i].n = l[l[i].n].n;
        }
    }
}

signed main() {
    ios::sync_with_stdio(false);
    in.tie();
    out.tie();
    in >> n;
    for (; n; --n) {
        in >> tip >> x;
        if (tip == 1) {
            insert(x);
        }
        if (tip == 2) {
            erase(x);
        }
        if (tip == 3) {
            out << find(x) << '\n';
        }
    }
    return 0;
}