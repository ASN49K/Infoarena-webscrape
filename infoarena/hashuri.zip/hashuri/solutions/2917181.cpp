#include <iostream>
#include <fstream>
#include <set>
using namespace std;

ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");

const int maxN = 1e6;
const int mod = 680059;
multiset <int> s[maxN];

void add (int val, int h) {
    s[h].insert(val);
}

int main()
{
    int n; fin >> n;

    for(int i = 1; i <= n; ++i) {
        int op; fin >> op;
        int x; fin >> x;
        if(op == 1) {
            add(x, x % mod);
        } else if(op == 2) {
            if(s[x%mod].find(x) != s[x%mod].end())
                s[x%mod].erase(s[x%mod].find(x));
        } else {
            if(s[x%mod].find(x) != s[x%mod].end())
                fout << "1\n";
            else
                fout << "0\n";
        }
    }

    return 0;
}
