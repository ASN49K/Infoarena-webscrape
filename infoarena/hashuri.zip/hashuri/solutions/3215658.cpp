#include <fstream>
#include <unordered_map>
using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hashuri.out");

unordered_map<int,bool> mp;
int q, op, x;


int main()
{
    cin>>q;
    while(q--)
    {
        cin>>op>>x;
        if(op==1){
            mp[x]=1;
        }
        if(op==2){
            if(mp.find(x)!=mp.end()){
                mp.erase(mp.find(x));
            }
        }
        if(op==3){
            if(mp.find(x)!=mp.end()){
                cout<<1<<'\n';
            }
            else cout<<0<<'\n';
        }
    }
}
