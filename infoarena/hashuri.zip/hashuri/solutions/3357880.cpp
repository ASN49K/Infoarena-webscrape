#include <iostream>
#include <fstream>
#include <unordered_set>

int main() {
    std::ifstream input("hashuri.in");
    std::ofstream output("hashuri.out");

    std::unordered_set<int> hash;

    int n;
    input >> n;
    while (n--) {
        int type, x;
        input >> type >> x;
        if (type == 1) hash.insert(x);
        else if (type == 2) hash.erase(x);
        else output << (hash.find(x) != hash.end()) << '\n';
    }

    return 0;
}