#include <iostream>
#define lol long long
#define modulo 4000000

struct listt {
	int current;
	listt *nextt;
};

listt *hash[modulo];

void hashdelete(lol a)
{
	int pos = a % modulo;
	if (hash[pos] == NULL)
		return;
	if (hash[pos]->current == a) {
		auto nextt = hash[pos]->nextt;
		free(hash[pos]);
		hash[pos] = nextt;
		return;
	}
	listt *current = hash[pos];
	while (current->nextt != NULL && current->nextt->current != a)
		current = current->nextt;
	if (current->nextt == NULL) {
		return;
	}
	auto nextt = current->nextt->nextt;
	free(current->nextt);
	current->nextt = nextt;
}

int hashfind(lol a)
{
	int pos = a % modulo;
	listt *current = hash[pos];
	while (current != NULL) {
		if (current->current == a)
			return true;
		current = current->nextt;
	}
	return false;
}

void hashadd(lol a)
{
	if (hashfind(a))
		return;
	int pos = a % modulo;
	if (hash[pos] == NULL) {
		hash[pos] = (listt *) malloc(sizeof(*hash[pos]));
		hash[pos]->current = a;
		hash[pos]->nextt = NULL;
	} else {
		listt *current = hash[pos];
		while (current->nextt != NULL)
			current = current->nextt;
		current->nextt = (listt *) malloc(sizeof(*hash[pos]));
		current->nextt->current = a;
		current->nextt->nextt = NULL;
	}
}


int main()
{
	FILE *fin = fopen("hashuri.in", "r");
	FILE *fout = fopen("hashuri.out", "w");
	int n;
	fscanf(fin, "%d", &n);
	for (int i = 0; i < n; i++) {
		int t, x;
		fscanf(fin, "%d %d", &t, &x);
		if (t == 1) {
			hashadd(x);
		} else if (t == 2) {
			hashdelete(x);
		} else {
			fprintf(fout, "%d\n", hashfind(x));
		}
	}
}
