#include <iostream>
#include <cstdlib>
#include <fstream>

using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

const int p = 1500041;
const int m = 3e6;

long long int a1, b1;

int calculate_hash_function_1(long long int x) {
    return ((long long)(a1 * x + b1) % p) % m;
}

long long int a2, b2;

int calculate_hash_function_2(long long int x) {
    return ((long long )(a2 * x + b2) % p) % m;
}

long long int T1[m], T2[m];

bool Search(long long int x) {
    return (T1[calculate_hash_function_1(x)] == x || T2[calculate_hash_function_2(x)] == x);
}

void Insert(long long int x) {
    long long int y, z;
    int h1 = calculate_hash_function_1(x);
    if (T1[h1] == 0 || T1[h1] == x) {
        T1[h1] = x;
        return;
    } else {
        y = T1[h1];
        T1[h1] = x;
    }
    int h2 = calculate_hash_function_2(y);
    if (T2[h2] == 0 || T2[h2] == y) {
        T2[h2] = y;
        return;
    } else {
        z = T2[h2];
        T2[h2] = y;
    }
    Insert(z);
}

void Delete(long long int x) {
    int h1 = calculate_hash_function_1(x);
    int h2 = calculate_hash_function_2(x);
    if (T1[h1] == x) {
        T1[h1] = 0;
    } else if (T2[h2] == x) {
        T2[h2] = 0;
    }
}

int main() {

    srand(time(nullptr));
    a1 = rand()%p;
    b1 = rand()%p;
    a2 = rand()%p;
    b2 = rand()%p;

    long long int n, op, x;
    in >> n;
    while (n--) {
        in >> op >> x;
        if (op == 1) {
            Insert(x);
        } else if (op == 2) {
            Delete(x);
        } else {
            out << Search(x) << "\n";
        }
    }


    return 0;
}