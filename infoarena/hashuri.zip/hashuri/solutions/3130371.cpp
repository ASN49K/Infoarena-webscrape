#include <vector>
#include<fstream>
#include<iostream>
using namespace std;

int N, NR;
int modd=666100;
vector<vector<int>> haash;

int find(int x)
{
    int i, j, ok = 0;

    for (i = 0; i < haash[x % modd].size(); i++){
        // cout << "seek";
        if (haash[x % modd][i] == x)
            return i;
    }
        // cout <<haash[x % modd].size()<< endl;
    return -3;
}

int main()
{
	ifstream in("hashuri.in");
    ofstream out("hashuri.out");

	int i, tip, x;

	in >> N;
    haash.resize(modd);
	for (i = 1; i <= N; i++) 
	{
		in >> tip >> x;

		if (tip == 1){
            if(find(x) == -3)
                haash[x % modd].push_back(x);
        }
		if (tip == 2) {
            if(find(x) != -3)
                haash[x % modd].erase(haash[x % modd].begin()+find(x));

        }
		if (tip == 3){
            if(find(x) != -3)
                out << "1\n";
            else
                out << "0\n";
        }
        
	}
    

	return 0;
}