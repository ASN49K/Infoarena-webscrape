#include <fstream>
#include <vector>

using namespace std;

const int hash_size = 54767;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
int tip_operatie, valoare, nr_operatii;
vector<int> hashtable[hash_size];


int main()
{
	f >> nr_operatii;
	for (int i = 0; i < nr_operatii; i++)
	{
		f >> tip_operatie >> valoare;
		int hash_value = valoare % hash_size;
		if (tip_operatie == 1)
			hashtable[hash_value].push_back(valoare);
		else if (tip_operatie == 2)
		{
			for (int index = 0; index < hashtable[hash_value].size(); index++)
				if (hashtable[hash_value][index] == valoare)
					hashtable[hash_value].erase(hashtable[hash_value].begin() + index);
		}
		else if (tip_operatie == 3)
		{
			int found = 0;
			for (int index = 0; index < hashtable[hash_value].size();index++)
				if (hashtable[hash_value][index] == valoare)
				{
					g << 1 << endl;
					found = 1;
					break;
				}
			if (!found)
				g << 0 << endl;
		}
	}
}