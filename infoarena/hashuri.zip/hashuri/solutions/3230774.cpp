#include <bits/stdc++.h>
#define P 123457
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");


struct Nod
{
    int key;
    int val;
    Nod *ant, *urm;
    Nod(int key, int val)
    {
        this->val = val;
        this->key = key;
        ant = urm = NULL;
    }
};

Nod **H, **head;

class HashTable
{
public :
    int n;
    HashTable(int n)
    {
        this->n = n;
        H = new Nod * [n];
        head = new Nod * [n];
        for(int i = 0; i < n; i++)
            H[i] = head[i] = NULL;
    }
    ~HashTable()
    {
        delete[] H;
        delete[] head;
    }
    int Modulo(int x)
    {
        return x % n;
    }
    virtual void Insert(int index, int x)
    {
        int nr = Modulo(index);
        Nod *p = H[nr];
        if(p == NULL)
        {
            p = new Nod(index, x);
            H[nr] = p;
            head[nr] = p;
        }
        else
        {
            while(p != NULL)
                p = p->urm;
            p = new Nod(index, x);
            p->ant = head[nr];
            head[nr]->urm = p;
            head[nr] = p;
        }
    }
    virtual void Afis(int index)
    {
        int nr = Modulo(index);
        Nod *p = H[nr];
        if(p == NULL) return;
        while(p != NULL)
        {
            cout << p->val << " ";
            p = p->urm;
        }
        cout << "\n";
    }
    virtual void Search(int index, int x)
    {
        int nr = Modulo(index);
        Nod *p = H[nr];
        if(p != NULL)
        {
            while(p != NULL && p->val != x)
                p = p->urm;
            if(p != NULL)
            {
                fout << "1\n";
                return;
            }
        }
        fout << "0\n";
    }
    virtual void Remove(int index, int x)
    {
        int nr = Modulo(index);
        Nod *p = H[nr];
        if(p == NULL) return;
        while(p != NULL && p->val != x)
            p = p -> urm;
        if(p == NULL) return;
        if (p->ant == NULL)
        {
            H[nr] = NULL;
            head[nr] = NULL;
            delete p;
        }
        else
        {
            head[nr] = p->ant;
            head[nr]->urm = NULL;
            delete p;
            p = head[nr];
        }
    }

};


int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int n, i, x, op;
    fin >> n;
    HashTable A(P);
    for(i=1;i<=n;i++)
    {
        fin >> op >> x;
        if(op == 1) A.Insert(x, x);
        else if(op == 2) A.Remove(x, x);
        else A.Search(x, x);
    }
    fin.close();
    fout.close();
    return 0;
}
