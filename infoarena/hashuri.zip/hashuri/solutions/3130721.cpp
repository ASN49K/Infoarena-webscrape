#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");

vector<vector<int>> dict;


int ffind(int x)
{
    for(int i=0;i<dict[x%666013].size();i++)
        if(dict[x%666013][i]==x)
            return true;

    return false;
}



int main()
{
    int n,i,op,val;
    dict.resize(666013);
    in>>n;

    for(i=0;i<n;i++)
    {
        in>>op;
        in>>val;

        if(op==1 && ffind(val)==false)
            dict[val%666013].push_back(val);


        if(op==2 && ffind(val)==true)
            for(int j=0;j<dict[val%666013].size();j++)
                if(dict[val%666013][j]==val)
                {
                   dict[val%666013].erase(dict[val%666013].begin()+j);
                   break;
                }

        if(op==3)
            out<<ffind(val)<<endl;


    }


    return 0;
}
