#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

const int p = 44729;

int main()
{
    int n, i, op, par,ok,j;
    vector<vector<int>>v(p);

    fin>>n;
    cout<<n<<"\n";

    for(i=0;i<n;i++)
    {
        fin>>op>>par;

        if(op==1)
                v[par%p].push_back(par);
        else
            if(op==2)
                {for(j=0;j<v[par%p].size();j++)
                    if(v[par%p][j] == par)
                    {
                        swap(v[par%p][j], v[par%p][v[par%p].size()-1]);
                        v[par%p].pop_back();
                    }
                }
            else
            {
                ok=0;
                for(j=0;j<v[par%p].size();j++)
                    if(v[par%p][j] == par)
                    {
                        fout<<1<<"\n";
                        ok=1;
                        break;
                    }

                if(ok==0)
                    fout<<0<<"\n";
            }
    }

    fin.close();
    fout.close();
    return 0;
}
