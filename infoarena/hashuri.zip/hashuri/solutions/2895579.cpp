#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

const int val_hash = 600000;
vector<int> vhash[val_hash];
int n, op, val;
bool gasit;

int main() {
    in>>n;
    for (int i = 0; i < n; i++)
    {
        in>>op>>val;
        int poz = val % val_hash;
        gasit = 0;
        if (op == 1)
        {
            for (int i = 0 ; i < vhash[poz].size() && !gasit; i++)
                if (vhash[poz][i] == val)
                    gasit = 1;

            if (!gasit)
                vhash[poz].push_back(val);
        }
        if (op == 2)
        {
            for (int i = 0 ; i < vhash[poz].size() && !gasit; i++)
                if (vhash[poz][i] == val){
                    vhash[poz][i] = 0;
                    gasit = 1;
                }
        }
        if(op == 3)
        {
            for (int i = 0 ; i < vhash[poz].size() && !gasit; i++)
                if (vhash[poz][i] == val)
                    gasit = 1;
            if (gasit)
                out<<1<<endl;
            else out<<0<<endl;
        }
    }
}
