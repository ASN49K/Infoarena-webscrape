#include<fstream>
#include<cmath>
#include<vector>
//#include<iostream>
using namespace std;
class InParser {
    vector<char> str;
    int ptr;
    ifstream fin;

    char getChar() {
        if (ptr == int(str.size())) {
            fin.read(str.data(), str.size());
            ptr = 0;
        }
        return str[ptr++];
    }

    template<class T>
    T getInt() {
        char chr = getChar();
        while (!isdigit(chr) && chr != '-')
            chr = getChar();
        int sgn = +1;
        if (chr == '-') {
            sgn = -1;
            chr = getChar();
        }
        T num = 0;
        while (isdigit(chr)) {
            num = num * 10 + chr - '0';
            chr = getChar();
        }
        return sgn * num;
    }

public:
    InParser(const char* name) : str(1e5), ptr(str.size()), fin(name) { }
    ~InParser() { fin.close(); }

    template<class T>
    friend InParser& operator>>(InParser& in, T& num) {
        num = in.getInt<T>();
        return in;
    }
};
class OutParser {
    vector<char> str;
    int ptr;
    ofstream fout;

    void putChar(char chr) {
        if (ptr == int(str.size())) {
            fout.write(str.data(), str.size());
            ptr = 0;
        }
        str[ptr++] = chr;
    }

    template<class T>
    void putInt(T num) {
        if (num < 0) {
            putChar('-');
            num *= -1;
        }
        if (num > 9)
            putInt(num / 10);
        putChar(num % 10 + '0');
    }

public:
    OutParser(const char* name) : str(1e5), ptr(0), fout(name) { }
    ~OutParser() { fout.write(str.data(), ptr); fout.close(); }

    template<class T>
    friend OutParser& operator<<(OutParser& out, const T num) {
        out.putInt(num);
        return out;
    }

    friend OutParser& operator<<(OutParser& out, const char chr) {
        out.putChar(chr);
        return out;
    }

    friend OutParser& operator<<(OutParser& out, const char* str) {
        for (int i = 0; str[i]; i++)
            out.putChar(str[i]);
        return out;
    }
};
InParser cin("hashuri.in");
OutParser cout("hashuri.out");
double y=(sqrt(5)-1)/2;
int m;
struct nod{
    int info=0;
    nod *urm=NULL;
}*h[1200002];
void inserare(nod *&prim,int val)
{
    nod*t=new nod;
    t->info=val;
    t->urm=prim;
    prim=t;
}
int get_index(int x)
{

    return m*(x*y-floor(x*y));

}
void cautare(nod *prim,int val)
{

    if(prim==NULL)
        cout<<"0\n";
    else
    { int gasit=0;
        nod *p=prim;
        while(p!=NULL)
        {
            if(p->info==val)
            {gasit=1;break;}
            p=p->urm;
        }
        if(gasit==1)
            cout<<"1\n";
        else
            cout<<"0\n";

    }
}
void stergere(nod *&prim,int val)
{
    if(prim==NULL)
        return ;
    nod *t;
    if(prim->info==val)
    {
        t=prim;
        prim=prim->urm;
        delete t;
        return ;
    }
    t=prim;
    while(t->info!=val&&t->urm!=NULL)
    {
        t=t->urm;
    }
    if(t->info!=val)
        return;
    nod *p=t;
    p=p->urm;
    delete t;



}
int main()
{
    int n;
    m=1200000;
    cin>>n;
    int x,j;
    for(;n;n--)
    {
        cin>>x>>j;
        if(x==1)
            inserare(h[get_index(j)],j);
        else
        if(x==2)
        {
            stergere(h[get_index(j)],j);
        }
        else if(x==3)
            cautare(h[get_index(j)],j);
    }

}