#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
vector<int>Hash[666000];
int main(){
    int k=666000,N,op,e,c,i,j;
    bool gasit=false;
    fin>>N;
    for(i=0;i<N;i++){
        fin>>op>>e;
        c=e%k;
        for(j=0;j<Hash[c].size();j++)
            if(Hash[c][j]==e){
                gasit=true;
                break;
            }

        if(op==1)
            if(!gasit)
                Hash[c].push_back(e);
        else if(op==2)
            if(gasit){
                swap(Hash[c][j],Hash[c].back());
                Hash[c].pop_back();
            }
        else if(gasit)
            fout<<1<<endl;;
        else
            fout<<0<<endl;

    }
    f.close();
    g.close();
    return 0;
}
