#include <bits/stdc++.h>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int n;
set<int> M;

int main()
{
    int i;
    fin >> n;
    int task, x;
    for( i=1; i<=n; i++ )
    {
        fin >> task >> x;
        if( task == 1 )
            M.insert(x);
        if( task == 2 )
            M.erase(x);
        if( task == 3 )
            if( M.find(x) != M.end() ) fout << "1\n";
            else fout << "0\n";
    }
    return 0;
}
