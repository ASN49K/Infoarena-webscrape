#include <fstream>
using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hashuri.out");
int n,x,mat[11][10000],op;
void adauga(int a)
{
    mat[a][0]++;
    mat[a][mat[a][0]]=x;
}
void elimina(int a)
{
    int i=1;
    while(mat[a][i]!=x && i<=mat[a][0])
        i++;
    if(i<=mat[a][0])
    {
    for(int j=i;j<mat[a][0];j++)
        mat[a][j]=mat[a][j+1];
    mat[a][0]--;
    }
}
int cauta(int a)
{
    int i;
    for(i=1;i<=mat[a][0];i++)
        if(mat[a][i]==x)
        return 1;
    return 0;
}
int main()
{
   cin>>n;
   int i,j;
   for(i=1;i<=n;i++)
   {
       cin>>op>>x;
       if(op==1) adauga(x%11);
       if(op==2) elimina(x%11);
       if(op==3) cout<<cauta(x%11)<<' ';
   }
   /*for(i=0;i<=10;i++)
   {
    for(j=0;j<=n;j++)
    cout<<mat[i][j]<<' ';
    cout<<endl;
   }*/
	return 0;
}
