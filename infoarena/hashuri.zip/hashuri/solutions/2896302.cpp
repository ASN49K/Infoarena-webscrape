#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");

const int prim = 100019;


int gaseste(vector <int> h[100019], int x)
{
    int nr = x % prim, i;

    for(i=0;i<h[nr].size();i++)
    {
        if(h[nr][i] == x) return i;
    }

    return -1;
}

void elimina (vector <int> h[100019], int x)
{
    int nr = x % prim;

    if(gaseste(h, x) != -1)
       {
           h[nr][gaseste(h,x)]=-1;
       }

}

void adauga (vector <int> h[100019], int x)
{
    int nr = x % prim, i;

    if(gaseste(h, x)==-1)
    h[nr].push_back(x);
}

bool verifica (vector <int> h[100019], int x)
{
    if(gaseste(h, x)!=-1)
        return 1;
    else return 0;
}

int main()
{

    vector <int> hasht[100019];

    int i, n, x;

    f>>n;

    for(i=0;i<n;i++)
    {
        int y;
        f>>x>>y;
        if(x==1)
        {
           // cin>>x;
            int nr = y % 100019, i;

            if(gaseste(hasht, y)==-1)
            hasht[nr].push_back(y);
        }
        else if(x==2)
        {

            elimina(hasht, y);
        }
        else if(x==3)
        {
            //cin>>x;
            g<<verifica(hasht, y)<<endl;
        }
    }

}
