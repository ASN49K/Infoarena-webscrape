#include <bits/stdc++.h>
using namespace std;
const int mod1 = 1e9 + 7, mod2 = 1e9 + 13;
set<int> s;
int main(){
    cin.tie(0)->sync_with_stdio(0);
    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");
    int n;
    fin >> n;

    while(n--){
        int t, x;
        fin >> t >> x;
        if(t == 1){
            s.insert(x);
        }
        else if(t == 2){
            s.erase(x);
        }
        else{
            auto it = s.find(x);
            if(it != s.end()){
                fout << 1 << '\n';
            }
            else{
                fout << 0 << '\n';
            }
        }
    }
}