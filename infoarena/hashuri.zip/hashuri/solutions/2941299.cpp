#include <fstream>
#include <map>
#include <vector>
#define MODULO 250000
using namespace std;

class HashMap {
private:
	map<int, vector<int>> hash_map;

public:
	bool key_exists(int key) {
		return hash_map.find(key) != hash_map.end();
	}

	void insert_element(int key, int number) {
		if (key_exists(key) == false) {
			vector<int> mapped_values;
			mapped_values.push_back(number);
			hash_map.insert({ key, mapped_values });
		} else {
			vector<int>& mapped_values = hash_map.at(key);
			int length = mapped_values.size();
			for (int i = 0; i < length; ++i) {
				if (mapped_values[i] == number) {
					return;
				}
			}
			mapped_values.push_back(number);
		}
	}

	void delete_element(int key, int number) {
		if (key_exists(key)) {
			vector<int>& mapped_values = hash_map.at(key);
			int length = mapped_values.size();
			for (int i = 0; i < length; ++i) {
				if (mapped_values[i] == number) {
					mapped_values.erase(mapped_values.begin() + i);
					return;
				}
			}
		}
	}

	int find_element(int key, int number) {
		if (!key_exists(key)) {
			return 0;
		}
		vector<int> mapped_values = hash_map.at(key);
		int length = mapped_values.size();
		for (int i = 0; i < length; ++i) {
			if (mapped_values[i] == number) {
				return 1;
			}
		}
		return 0;
	}
};

int main() {
	ifstream fin("hashuri.in");
	ofstream fout("hashuri.out");
	HashMap hash_map;
	int nr_operations, operation_type, number;
	fin >> nr_operations;
	for (int i = 0; i < nr_operations; ++i) {
		fin >> operation_type >> number;
		int key = number % MODULO;
		if (operation_type == 1) {
			hash_map.insert_element(key, number);
		} else if (operation_type == 2) {
			hash_map.delete_element(key, number);
		} else {
			fout << hash_map.find_element(key, number) << '\n';
		}
	}
	return 0;
}