#include <bits/stdc++.h>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");

const int mod = 666013;
int n, op, x;
vector <int> v[666020];

int Find(int val) {
    int rest = val % mod;
    for (int i=0; i<v[rest].size(); ++i)
        if (v[rest][i] == val)
            return i;
    return -1;
}

void Add (int val) {
    int rest = val % mod;
    int it = Find(val);
    if (it == -1)
        v[rest].push_back (val);
}

void Erase (int val) {
    int rest = val % mod;
    int it = Find(val);
    if (it != -1) {
        int sz = v[rest].size();
        for (int i=0; i<sz; ++i)
            if (v[rest][i] == val) {
                v[rest][i] = v[rest][sz-1];
                v[rest].pop_back();
            }
    }
}

int main()
{
    f >> n;
    for (int i=1; i<=n; ++i) {
        f >> op >> x;
        int rest = x % mod;

        if (op == 1) {
            Add (x);
        }
        if (op == 2) {
            Erase (x);
        }
        if (op == 3) {
            if (Find (x) == -1)
                g << 0 << '\n';
            else
                g << 1 << '\n';
        }
    }
    return 0;
}
