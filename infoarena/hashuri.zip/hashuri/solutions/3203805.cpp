#include <bits/stdc++.h>

using namespace std;
#define int long long
ifstream f("hashuri.in");
ofstream g("hashuri.out");
int nr;
int32_t main()
{ unordered_map <int , int > mp;
int n ,i,x;
f>>n;
for(int j=1;j<=n;j++)
{
    f>>i>>x;
    if(i==1 && mp.find(x)==mp.end())
    mp[x]=++nr;
    if(i==2)
        mp.erase(x);
    if(i==3)
      g<<(mp.find(x)!=mp.end())<<'\n';


}
    return 0;
}
