#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector <vector <int> > v(666015);

int main()
{
    ///retinem perechi de forma (x, x%666013).
    int tip, x, n;
    fin>>n;
    for(int i = 0; i < n; i++)
    {
        fin>>tip>>x;
        switch (tip)
        {
        case 1:         ///se adauga elem x in multime daca nu exista deja
        {
            v[x%666013].push_back(x);
            break;
        }
        case 2:         ///se sterge elem x din multime
        {
            for(int k = 0; k < v[x%666013].size(); k++)
                if(v[x%666013][k] == x)
                {
                    swap(v[x%666013][k], v[x%666013][v[x%666013].size()-1]);
                    v[x%666013].pop_back();
                }
            break;
        }
        case 3:         ///returneaza 1 daca x e in multime si 0 in caz  contrar
        {
            bool ok = 0;
            for(int k = 0; k < v[x%666013].size(); k++)
                if(v[x%666013][k] == x)
                {
                    fout<<1<<'\n';
                    ok = 1;
                    break;
                }
            if(!ok)
                fout<<0<<'\n';
            break;
        }
        }
    }
    return 0;
}
