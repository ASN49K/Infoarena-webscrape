include <bits/stdc++.h>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

const int mod=666013;
vector <int> h[mod];

int n,r;

bool findx (int x)
{
    for (auto a:h[r] )
        if ( a==x )
           return true;

    return false;
}

void insertx (int x)
{
    h[r].push_back(x);
}

void erasex (int x)
{
    vector <int> cpy;

    for (auto a:h[r] )
        if ( a!=x )
           cpy.push_back(a);

    h[r]=cpy;
}


int main()
{
    f >> n;

    for (int i=1; i<=n; i++ )
    {
        int c,x;
        f >> c >> x;

        r=x%mod;

        if ( c==1 )
            insertx(x);

        if ( c==2 )
            erasex(x);

        if ( c==3 )
            g << findx(x) << '\n';
    }

    return 0;
}
