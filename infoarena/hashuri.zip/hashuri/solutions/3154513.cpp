#include <iostream>
#include <fstream>

using namespace std;

const int NMAX = 1e6+1;
const int K = 1 << 19;

int lst[K+1], urm[NMAX], val[NMAX], nr;

int pozitie(int x, int cat){
    for(int p = lst[cat]; p != 0; p = urm[p]){
        if(val[p] == x){
            return p;
        }
    }
    return -1;
}

void adauga(int x){
    int cat = x & (K - 1);
    int p = pozitie(x, cat);
    if(p == -1){
        nr++;
        val[nr] = x;
        urm[nr] = lst[cat];
        lst[cat] = nr;
    }
}

void sterge(int x){
    int cat = x & (K - 1);
    int p = pozitie(x, cat);
    if(p != -1){
        val[p] = val[lst[p]];
        lst[cat] = urm[lst[cat]];
    }
}

bool cauta(int x){
    int cat = x & (K - 1);
    return (pozitie(x, cat) != -1);
}

int main()
{
    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");

    int n;
    fin >> n;
    for(int i = 1; i <= n; i++){
        int op, x;
        fin >> op >> x;
        if(op == 1){
            adauga(x);
        }else if(op == 2){
            sterge(x);
        }else{
            fout << cauta(x) << "\n";
        }
    }

    fin.close();
    fout.close();
    return 0;
}
