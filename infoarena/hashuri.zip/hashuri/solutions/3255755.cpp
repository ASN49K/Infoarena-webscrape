#include <iostream>
#include <bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

const int nmax=1000000;
int x,y,ym,adv,ie,ia,n;

vector < vector<int> >ha;



int main()
{
    fin>>n;
    ha.assign(nmax,vector<int>());
    for(int i=0;i<n;i++){
        adv=0;
        fin>>x>>y;
        ym=y%nmax;
        for(int j=0;j<ha[ym].size();j++){
            if(ha[ym][j]==y){
                adv=1;
                ie=j;
            }
        }
        if(x==1){
            if(!adv){
              ha[ym].push_back(y);
            }
        }
        else if(x==2){
            ha[ym].erase(ha[ym].begin()+ia-1);
        }

        else{
            if(adv)fout<<1<<'\n';
            else fout<<0<<'\n';
        }

    }
}
