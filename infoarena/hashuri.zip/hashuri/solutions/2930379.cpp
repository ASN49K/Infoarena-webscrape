#include <fstream>
#include <set>
#define MOD 1000000
using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hashuri.out");
set <int> M[MOD];
int main()
{
    int n,a,b;
    cin>>n;
    for (int i=1; i<=n; i++)
    {
        cin>>a>>b;
        if (a==1)
            M[b%MOD].insert(b);
        if (a==2)
            M[b%MOD].erase(b);
        if (a==3)
        {
            if(M[b%MOD].find(b)!=M[b%MOD].end())
                cout<<1<<'\n';
            else cout<<0<<'\n';
        }
    }

    return 0;
}
