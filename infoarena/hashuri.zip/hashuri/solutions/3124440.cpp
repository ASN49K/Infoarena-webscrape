#include <fstream>
#include <vector>

using namespace std;

ifstream cin("hashuri.in");
ofstream cout("hashuri.out");

const int MOD = 666013;
int n;
vector<int> Hash[MOD];

void Inserare(int x)
{
    int MOD_curent = x % MOD;
    for(int Value : Hash[MOD_curent])
        if(Value == x)
            return;
    Hash[MOD_curent].push_back(x);
}

void Stergere(int x)
{
    int MOD_curent = x % MOD;
    for(int i = 0; i < Hash[MOD_curent].size(); i++)
        if(Hash[MOD_curent][i] == x)
            Hash[MOD_curent].erase(Hash[MOD_curent].begin() + i);
}

bool In_Multime(int x)
{
    int MOD_curent = x % MOD;
    for(int Value : Hash[MOD_curent])
        if(Value == x)
            return true;
    return false;
}

int main()
{
    cin >> n;
    for(int i = 1; i <= n; i++)
    {
        int tip, x;
        cin >> tip >> x;
        if(tip == 1)
            Inserare(x);
        else if(tip == 2)
            Stergere(x);
        else
            cout << In_Multime(x) << '\n';
    }

    return 0;
}