#include <fstream>
#include <vector>

using namespace std;

ifstream cin("hashuri.in");
ofstream cout("hashuri.out");

int n;
vector<vector<int>> h;

void read() {
    cin>>n;
    h.resize(666013+1);
}

int makeHash(int nr) {
    int res=0;
    while(nr>0) {
        res+=(nr%10)%666013;
        nr/=10;
    }
    return res;
}

void solve() {
    int op,nr;
    for(int i=1;i<=n;i++) {
        cin>>op>>nr;
        if(op==1) {
            h[makeHash(nr)].push_back(nr);
        }
        else if(op==2) {
            auto it=find(h[makeHash(nr)].begin(),h[makeHash(nr)].end(),nr);
            if(it!=h[makeHash(nr)].end()) {
                h[makeHash(nr)].erase(it);
            }
        }
        else {
            cout<<((h[makeHash(nr)].size()>0)?1:0)<<"\n";
        }
    }
}

int main() {
 
    read();
    solve();
    return 0;
}