#include <iostream>
#include <fstream>
#include <vector>


using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");
#define P 666013
vector<int>List[P];

int find(int x){
    int mod;
    mod = x%P;
    for(int i=0;i<List[mod].size();i++)
    {
        if(List[mod][i]==x){
            return i;
        }
    }
    return -1;
}

void insert(int x){
    int mod,i;
    mod = x%P;
    if(find(x) == -1){
        List[mod].push_back(x);
    }
}

void erase(int x){
    int mod,i;
    mod = x%P;
    if(find(x)!=-1) {
        for (i = find(x)+1; i <List[mod].size(); i++) {
            swap(List[mod][i - 1],List[mod][i]);
        }
        List[mod].pop_back();
    }
}

int main(){

    int n,x,op;
    f>>n;
    while(n!=0){

        f>>op>>x;
        if(op==1){
            insert(x);
        }
        else if(op==2){
            erase(x);
        }
        else if(op==3){
            int rez = find(x);
            if(rez == -1){g<<0<<endl;}
            else{g<<1<<endl;}
        }
        n--;
    }

    return 0;
}

