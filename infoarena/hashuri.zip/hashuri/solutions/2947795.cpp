#include <fstream>
#include <list>
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
int n, m, i, j, x, q, tip;
const int mod = 44729;
list <int> h[mod];
bool check (int x)
{
    for (auto i : h[x%mod])
        if (i == x)
            return 0;
    return 1;
}
void del (int x)
{
    list<int>::iterator it;
    for (it = h[x%mod].begin(); it != h[x%mod].end(); it++)
        if (*it == x)
            break;
    if (it != h[x%mod].end()) h[x%mod].erase(it);
}
int main()
{
    fin >> q;
    for (int qi = 1; qi <= q; qi++)
    {
        fin >> tip >> x;
        if (tip == 1)
        {
            if (check(x))
                h[x%mod].push_back(x);
        }
        else if (tip == 2)
            del(x);
        else if (tip == 3)
            fout << !check(x) << "\n";
    }
    return 0;
}
