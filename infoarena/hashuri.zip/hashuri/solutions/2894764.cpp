#include <iostream>
#include <fstream>
#include <vector>
using namespace std;


ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector <int> M[666013];

int verificare(int x){
    int pozitie = x % 666013;
    vector <int> :: iterator i;
    for  (i = M[pozitie].begin(); i != M[pozitie].end(); i++)
        if(*i == x)
            return 1;
    return 0;
}

void inserare (int x){
    int pozitie = x % 666013;
    if (verificare(x) == 0)
        M[pozitie].push_back(x);

}


void stergere(int x){
    int pozitie  = x % 666013;
    vector <int> :: iterator i;
    for (i = M[pozitie].begin(); i != M[pozitie].end(); i++)
        if (*i == x) {
            M[pozitie].erase(i);
            break;
        }
}


int main() {
    int N, operatie, parametru;
    fin >> N;
    for (int i=0; i<N; i++){
        fin >> operatie >> parametru;
        if (operatie == 1)
            inserare(parametru);
        else if (operatie == 2)
            stergere(parametru);
        else fout << verificare(parametru) << endl;

    }
    return 0;
}
