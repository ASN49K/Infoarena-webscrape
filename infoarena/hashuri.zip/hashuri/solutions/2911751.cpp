#include <iostream>
#include <fstream>
#include <cstdlib>

using namespace std; 

int v[1000000];
int cnt = 0;

bool traverse(int x){	
	int i;
	for(i = 0; i<cnt; i++)
		if(x == v[i]) return true;
	return false;
}

void deleteItem(int x){
	int i, j;
	for(i = 0; i<cnt; i++)
		if(x == v[i])
			for(j = i; j<cnt-1; j++)
				v[j] = v[j+1];
	cnt--;
}

int main(){
	ifstream fin;
	fin.open("hashuri.in");
	int N, x, y, i;
	fin >> N;
	for(i = 0; i<N; i++){
		fin >> x >> y;
		if(x == 1){
			if(traverse(y) == false){
				v[cnt] = y;
				cnt++;
			}	
		}
		else if(x == 2){
			if(traverse(y)){
				deleteItem(y);
			}
		}
		else{
			
			if(traverse(y)) 
				cout << 1 <<"\n";
			else
				cout << 0 << "\n";
		}
	}
	fin.close();
	return 0;
}
