#include <bits/stdc++.h>

#define nrprim 199933

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

vector <int> v[nrprim+1];

int verificare(int x)
{

    int i, p;
    p=nrprim%x;
    for(i=0; i<v[p].size(); i++)
    {
        if(v[p][i]==x)
            return 1;
    }
    return 0;

}

void adaugare(int x)
{
    int p=nrprim%x;
    if(verificare(x)==0)
        v[p].push_back(x);
}

void stergere(int x)
{
    int i, p=nrprim%x;
    for(i=0; i<v[p].size(); i++)
    {
        if(v[p][i]==x)
        {
            v[p][i]=-1;
            return;
        }
    }


}


int main()
{
    int N, i, operatie, x;
    f>>N;
    for(i=0; i<N; i++)
    {
        f>>operatie>>x;
        if(operatie==1)
            adaugare(x);
        if(operatie==2)
            stergere(x);
        if(operatie==3)
            g<<verificare(x)<<'\n';

    }
}
