#include <bits/stdc++.h>

using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
unordered_map<int,int> fr;
int n,x,y;
int main()
{   fin>>n;
    for(int i=1;i<=n;i++){
        fin>>x>>y;
        if(x==1) fr[y]=1;
        else if(x==2) fr[y]=0;
        else fout<<fr[y]<<"\n";
    }
    return 0;
}