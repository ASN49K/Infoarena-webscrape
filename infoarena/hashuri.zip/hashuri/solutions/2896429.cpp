#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");

int nrprim = 100019;

vector <int> h[100019];

bool gaseste(int x)
{
    int nr = x % nrprim;

    for(int i : h[nr])
        if(i==x) return 1;
    return 0;
}

void sterge (int x)
{
    int nr = x % nrprim;
   // if(gaseste(x))
        for(int i = 0; i < h[nr].size(); i++)
        if(h[nr][i] == x)
    {
        h[nr][i] = -1;
        break;
    }
}


int main()
{

    int n, i, x, k;

    f>>n;

    for(i=0;i<n;i++)
    {
        f>>k>>x;
        if(k==1)
        {
            if(!gaseste(x)) h[x % nrprim].push_back(x);
        }
        else if(k==2)
        {
            sterge(x);
        }
        else if(k==3) g<<gaseste(x)<<endl;
    }

}
