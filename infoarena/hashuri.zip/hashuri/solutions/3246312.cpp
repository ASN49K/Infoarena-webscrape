#include <iostream>
#include <fstream>
#include <vector>
#define MOD 1048576
#define H(x) (x%MOD)
using namespace std;
vector<int> HASH[MOD];
vector<int>::iterator find(int x)
{
    int key=H(x);
    vector<int>::iterator I;
    for(I=HASH[key].begin();I!=HASH[key].end();I++)
        if(*I==x)
            return I;
    return HASH[key].end();
}
void insert(int x)
{
    int key=H(x);
    if(find(x)==HASH[key].end())///elementul nu se gaseste in multime
        HASH[key].push_back(x);
    return;
}
void erase(int x)
{
    int key=H(x);
    vector<int>::iterator I=find(x);
    if(I!=HASH[key].end())///elementul se gaseste in multime
        HASH[key].erase(I);
    return;
}
int main()
{
    int n,op,x;
    ifstream f;
    ofstream g;
    f.open("hashuri.in",ios::in);
    g.open("hashuri.out",ios::out);
    f>>n;
    for(int i=1;i<=n;i++)
    {
        f>>op>>x;
        switch(op)
        {
            case 1:{
                insert(x);
            }break;
            case 2:{
                erase(x);
            }break;
            case 3:{
                if(find(x)!=HASH[H(x)].end())///se gaseste
                    g<<1<<'\n';
                else g<<0<<'\n';
            }
        }
    }
    f.close();
    g.close();
    return 0;
}