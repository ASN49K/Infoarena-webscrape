#include<vector>
#include<fstream>
#include<iostream>

using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

struct node {
	int key;
	node *next;
};


class Hashmap{
	private:
		vector<node*> buckets;
		int capacity;

	public:
		Hashmap(int capacity=87943) {
			this->capacity = capacity;
			buckets = vector<node*>(capacity, NULL);
		}

		void insert(int key) {
			int bucket = key % capacity;

			node *to_insert = new node{key, NULL};
			node *current = buckets[bucket];

			if (current == NULL) {
				buckets[bucket] = to_insert;
				return;
			}

			while(current->next != NULL){
				if (current->key == key)
					return;
				current = current->next;
			}

			if (current->key != key) {
				current->next = to_insert;
			}
		}

		void erase(int key) {
			int bucket = key % capacity;
			node *current = buckets[bucket];

			if (current == NULL) {
				return;
			}

			if (current->key == key){
				buckets[bucket] = current->next;
				delete current;
				return;
			}

			node *last = current;
			current = current->next;

			while (current != NULL) {
				if (current->key == key){
					last->next = current->next;
					delete current;
					return;
				}
				last = current;
				current = current->next;
			}
		}

		bool exists(int key) {
			int bucket = key % capacity;
			node *current = buckets[bucket];

			while (current != NULL){
				if (current->key == key) {
					return true;
				}
				current = current->next;
			}
			return false;
		}


		~Hashmap() {
			for(node* n: buckets) {
				while (n != NULL){
					node * next = n->next;
					delete n;
					n = next;
				}
			}
		}
};

int main(){
	int n;
	int q, v;
	in>>n;
	Hashmap map;
	while(n--){
		in>>q>>v;
		if (q==1) {
			map.insert(v);
		} else if (q == 2) {
			map.erase(v);
		} else{
			out<<map.exists(v)<<'\n';
		}
	}
}

