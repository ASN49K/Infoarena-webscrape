#include <iostream>
#include <unordered_map>
#include <fstream>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int main() {

    int n;
    fin >> n;

    unordered_map<int, int> hash;

    for (int i = 0; i < n; i++)
    {
        int operatie, x;
        fin >> operatie >> x;

        if (operatie == 1)
        {
            hash[x] = 1;
        }
        else
            if (operatie == 2)
            {
                hash.erase(x);
            }
            else
                if (operatie == 3)
                {
                    fout << hash.count(x) << "\n";
                }
    }

    return 0;
}
