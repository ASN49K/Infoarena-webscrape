#include <iostream>
#include <fstream>
#include <unordered_set>
using namespace std;
ifstream f("hasuri.in");
ofstream g("hasuri.out");
int main() {
    int n,op,x;
    f>>n;
    unordered_set<int> v;
    for (int i=1;i<=n;i++) {
        f>>op>>x;
        if(op==1) {
            auto it =v.find(x);
            if(it==v.end()) {
                v.insert(x);
            }
        } else if(op==2) {
            auto it=v.find(x);
            if (it!=v.end()) {
                v.erase(it);
            }
        } else if(op==3) {
            g<<v.count(x)<<endl;
        }
    }

    return 0;
}