#include <iostream>
#include <vector>
#include <fstream>

using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");

int n, p = 999331, i, x, op, hashedX, ok, j;
vector<vector<int>> hashMatrix;

int main()
{
    hashMatrix.resize(p); //avem cate o lista pentru fiecare rest de la 0 la p - 1
    in>>n;

    for(i = 1; i <= n; i++)
    {
        in>>op>>x;
        hashedX = x % p;

        switch(op)
        {
        case 1:
            ok = 0;
            for(j = 0; j < hashMatrix[hashedX].size(); j++)
                if(hashMatrix[hashedX][j] == x)
                {
                    ok = 1;
                    break;
                }

            if(ok == 0)
                hashMatrix[hashedX].push_back(x);

            break;

        case 2:
            for(j = 0; j < hashMatrix[hashedX].size(); j++)
                if(hashMatrix[hashedX][j] == x)
                {
                    hashMatrix[hashedX][j] = hashMatrix[hashedX].back();
                    hashMatrix[hashedX].pop_back();
                    break;
                }

            break;
        case 3:
            ok = 0;
            for(j = 0; j < hashMatrix[hashedX].size(); j++)
                if(hashMatrix[hashedX][j] == x)
                {
                    ok = 1;
                    break;
                }

            out<<ok<<endl;
            break;
        default:
            break;
        }
    }

    return 0;
}
