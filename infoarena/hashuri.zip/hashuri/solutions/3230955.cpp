#include <bits/stdc++.h>
#define P 10000019
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");


struct Nod
{
    int key;
    int val;
    Nod *ant, *urm;
    Nod(int key, int val)
    {
        this->val = val;
        this->key = key;
        this->ant = NULL;
        this->urm = NULL;
    }
};

Nod **H, **head;

class HashTable
{
public :
    int n;
    HashTable(int _n)
    {
        n = _n;
        H = new Nod * [n + 1];
        head = new Nod * [n + 1];
        for(int i = 0; i < n; i++)
            H[i] = head[i] = NULL;
    }
    ~HashTable()
    {
        delete[] H;
    }
    int Modulo(int x)
    {
        return x % n;
    }
    virtual void Insert(int index, int x)
    {
        int nr = Modulo(index);
        Nod *p = H[nr];
        if(p == NULL)
        {
            p = new Nod(index, x);
            H[nr] = p;
            head[nr] = p;
        }
        else
        {
            while(p != NULL)
            {
                if(p->val == x) return;
                p = p->urm;
            }
            p = new Nod(index, x);
            p->ant = head[nr];
            head[nr]->urm = p;
            head[nr] = p;
        }
    }
    virtual void Afis(int index)
    {
        int nr = Modulo(index);
        Nod *p = H[nr];
        if(p == NULL) return;
        while(p != NULL)
        {
            fout << p->val << " ";
            p = p->urm;
        }
        fout << "\n";
    }
    virtual void Search(int index, int x)
    {
        int nr = Modulo(index);
        Nod *p = H[nr];
        if(p != NULL)
        {
            while(p != NULL && p->val != x)
                p = p->urm;
            if(p != NULL && p->key == index)
            {
                fout << "1\n";
                return;
            }
        }
        fout << "0\n";
    }
    virtual void Remove(int index, int x)
    {
        int nr = Modulo(index);
        Nod *p = H[nr];
        if(p == NULL) return;
        while(p != NULL && p->val != x)
            p = p -> urm;
        if(p == NULL) return;
        if(p->urm == NULL)
        {
            if (p->ant == NULL)
            {
                H[nr] = NULL;
                head[nr] = NULL;
                delete p;
                return;
            }
            else
            {
                head[nr] = p->ant;
                head[nr]->urm = NULL;
                delete p;
                return;
            }
        }
        if(p->ant != NULL && p->urm != NULL)
        {
            p->ant->urm = p->urm;
            p->urm->ant = p->ant;
            delete p;
            return;
        }
    }
};


int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int n, i, x, op;
    fin >> n;
    HashTable A(P);
    for(i=1; i<=n; i++)
    {
        fin >> op >> x;
        /**
        if(op == 3) nr++;
        if(nr == 3750)
        {
            fout <<
        }
        */
        if(op == 1) A.Insert(x, x);
        else if(op == 2) A.Remove(x, x);
        else A.Search(x, x);
    }
    fin.close();
    fout.close();
    return 0;
}
