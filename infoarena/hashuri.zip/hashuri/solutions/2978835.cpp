#include <fstream>
#include <unordered_map>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
int n,t,x;
unordered_map <int,bool>a;
int main()
{
    f>>n;
    while(n--)
    {
        f>>t>>x;
        if(t==1)
        {
            auto it = a.find(x);
            if(it==a.end())
            a.insert({x,1});
        }
        else
        if(t==2)
        {
            auto it = a.find(x);
            if(it!=a.end())
                a.erase(x);
        }
        else
        {
            auto it =a.find(x);
            if(it!=a.end())
                g<<1<<'\n';
            else
                g<<0<<'\n';
        }
    }
    return 0;
}
