#include <fstream>
#include <map>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

const int mod = 666013;
int n;
map<int, int> a;

int main()
{
    f >> n;
    for(int i = 1; i <= n; i ++)
    {
        int op, x; f >> op >> x;

        if(op == 1)
            a[x % mod] ++;

        else if(op == 2)
            a[x % mod] --;

        else
            g << (a[x % mod]) << '\n';
    }
    return 0;
}
