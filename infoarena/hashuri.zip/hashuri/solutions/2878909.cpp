#include <bits/stdc++.h>

using namespace std;

const int modulo=666013;
list<int> l[modulo];

void op1(int n){
    int rest=n%modulo;
    l[rest].push_back(n);
}

void op2(int n){
    int rest=n%modulo;
    list<int>::iterator x;
    for(x=l[rest].begin(); x!=l[rest].end(); ++x)
        if(*x==n)    l[rest].erase(x);
}

bool op3(int n){
    int rest=n%modulo;
    list<int>::iterator x;
    for(x=l[rest].begin(); x!=l[rest].end(); ++x)
        if(*x==n)    return 1;
    return 0;
}

int main()
{
    ifstream fin("hashuri.in");
    ofstream fout("hashuri.out");
    int nrop, op, nr;
    cin>>nrop;
    for(int i=1; i<=nrop; ++i){
        cin>>op>>nr;
        switch(op){
            case 1: if(!op3(nr)) op1(nr);
                    break;
            case 2: op2(nr);
                    break;
            case 3: cout<<op3(nr)<<'\n';
                    break;
        }
    }
    return 0;
}
