#include <iostream>
#include <fstream>
#include <vector>
#include <iterator>
using namespace std;
vector<long long >h[666073];
auto cauta(long long x)
{
    vector<long long > ::iterator i;
    for ( i = h[x%666073].begin();i != h[x%666073].end();++i)
        if(*i == x)
            return i;
    return h[x%666073].end();
}
void adauga(long long x)
{
    if(cauta(x) != h[x%666073].end())
        return;
    else
        h[x%666073].push_back(x);
}
void sterge(long long x)
{
    if(cauta(x) != h[x%666073].end())
        h[x%666073].erase(cauta(x));
    else
        return;
}
int main() {
    ifstream f("hashuri.in");
    ofstream g("hashuri.out");
    long long n,op,x;
    f>>n;
    while (f>>op>>x)
    {
         if(op == 1)
                adauga(x);
         else if(op == 2)
                sterge(x);
         else
            if(cauta(x) == h[x%666073].end())
                g<<0<<'\n';
            else
                g<<1<<'\n';

    }

    f.close();g.close();
    return 0;
}