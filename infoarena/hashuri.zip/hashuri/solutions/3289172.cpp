#include <bits/stdc++.h>
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
unordered_map<int, bool> ap;
int n, op, x;

signed main()
{
    fin >> n;
    while(n--)
    {
        fin >> op >> x;
        if(op == 1)
            ap[x] = 1;
        else if(op == 2)
            ap[x] = 0;
        else
            fout << ap[x] << '\n';
    }

    return 0;
}
