#include<bits/stdc++.h>
using namespace std;
ifstream F("hashuri.in");
ofstream G("hashuri.out");
vector<int> v[997];
vector<int>::iterator c;
int m=997,a,b;
int main()
{
    for(F>>a;F>>a>>b;)
        if(c=find(v[b%m].begin(),v[b%m].end(),b),a==1&&c==v[b%m].end())
            v[b%m].push_back(b);
        else if(a==2&&c!=v[b%m].end())
            v[b%m].erase(c);
        else if(a==3)
            G<<(c!=v[b%m].end())<<'\n';
    return 0;
}
