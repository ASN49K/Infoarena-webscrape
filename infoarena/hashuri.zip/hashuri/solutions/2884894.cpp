#include <iostream>
#include <map>

using namespace std;

ifstream cin("hashuri.in");
ofstream cout("hashuri.out");

map<int, int> mapa;

int main()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++){
        int cod, x;
        cin >> cod >> x;

        if (cod == 1){
            mapa[x] = 1;
        }

        if (cod == 2){
            mapa[x] = 0;
        }

        if (cod == 3){
            cout << mapa[x] << '\n';
        }
    }

    return 0;
}
