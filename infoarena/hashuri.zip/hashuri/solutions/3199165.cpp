#include<iostream>
#include<fstream>
#include<vector>
#define MOD 10000
#define FIN "hashuri.in"
#define FOUT "hashuri.out"
#define ins 1
#define del 2
#define sea 3

using namespace std;

ifstream fin(FIN);
ofstream fout(FOUT);

vector<long> Hash[MOD];

vector<long>::iterator seek(int value) {
	long key = value % MOD;
	vector<long>::iterator it;

	for(it = Hash[key].begin(); it != Hash[key].end(); it++)
		if(key == *it) return it;

	return Hash[key].end();
}

void insert(int value) {
	long key = value % MOD;
	vector<long>::iterator it;
	it = seek( value );

	if(it == Hash[key].end()) Hash[key].push_back(value);	 	
}
void remove(int value) {
	long key = value % MOD;
	vector<long>::iterator it;
	it = seek( value );

	if(it != Hash[key].end() ) Hash[key].erase( it );
}
int search(int value) {
	long key = value % MOD;
	vector<long>::iterator it;
	it = seek( value );

	if(it!=Hash[key].end())
		return 1;
	else return 0;	
}
int main()
{
	int N, op, el;
	fin>>N;
	for( ; N; N--) {
		fin>>op>>el;
		if( op == ins ) 
			insert(el);
		else if(op == del)
			remove(el);
		else {
		// 	int ans = search(el);
		// 	if(ans == 1) cout<<1;
		// 	else cout<<"0";
		fout<<search(el)<<"\n";
		 }
	}		
}