#include <bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

map<int,int>fr;
int n;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    fin >> n;
    while(n--)
    {
        int op,x;
        fin >> op >> x;
        if(op == 1)
        {
            if(fr.count(x) == 0)
                fr[x] = 1;
        }
        else if(op == 2)
        {
            fr.erase(x);
        }
        else
        {
            if(fr.count(x))
                fout << 1;
            else
                fout << 0;
            fout << '\n';
        }
    }
    return 0;
}
