#include <fstream>
#include <vector>
using namespace std;
#define MOD 983875
vector <int> v[1000000];
int main(){
	int n, i, tip, x, poz1, poz2;
	ifstream fin( "hashuri.in" );
	ofstream fout( "hashuri.out" );
	fin >> n;
	for( i = 0; i < n; i++ ){
		fin >> tip >> x;
		poz1 = x % MOD;
		poz2 = 0;
		while( poz2 < v[poz1].size() && v[poz1][poz2] != x ){
			poz2++;
		}
		if( tip == 1 && poz2 == v[poz1].size() ){
			v[poz1].push_back( x );
		}
		else if( tip == 2 && poz2 < v[poz1].size() ){
			v[poz1].erase( v[poz1].begin() + poz2 );
		}
		else if( tip == 3 ){
			if( poz2 < v[poz1].size() ){
				fout << 1 << '\n';
			}
			else{
				fout << 0 << '\n';
			}
		}
	}
	return 0;
}