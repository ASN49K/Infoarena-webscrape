#include <bits/stdc++.h>

using namespace std;

ifstream f ("hashuri.in");
ofstream g ("hashuri.out");

const int mod = 666013;

int tip, n, a;
vector <int> v[mod + 1];

int caut(int x)
{
    int t = x % mod;
    for (int i = 0; i < v[t].size(); ++i)
        if (v[t][i] == x)
            return i + 1;

    return 0;
}

void add(int x)
{
    int t = x % mod;
    if (caut(x))
        return;

    v[t].push_back(x);
}

void sterge(int x)
{
    int t = x % mod;
    int poz = caut(x);

    if (!poz)
        return;

    --poz;

    swap(v[t][poz], v[t][v[t].size() - 1]);
    v[t].pop_back();
}

int main()
{
    f >> n;

    while (n--)
    {
        f >> tip >> a;

        if (tip == 1)
        {
            add(a);
            continue;
        }

        if (tip == 2)
        {
            sterge(a);
            continue;
        }

        if (tip == 3)
        {
            g << (caut(a) > 0) << '\n';
        }
    }

    return 0;
}
