#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
vector<int>v[666666];

int main()
{
    int n;
    fin>>n;
    while(n--){
        int op;
        fin>>op;
        int nr;
        fin>>nr;
        int cnr=nr;
        int prim=13;
        long long s=0;
        int mod=66013;
        while(cnr){
            s+=cnr%10*prim%66013;
            prim*=prim;
            cnr/=10;
            s%=mod;
        }
        //cout<<s<<endl;
        bool este=false;
        for(int i=0;i<v[s].size();i++){
            if(v[s][i]==nr)
                este=true;
        }
        //cout<<nr<<" "<<este<<endl;
        if(op==1){
            if(este==false)
                v[s].push_back(nr);
}
        else if(op==2){
            for(int i=0;i<v[s].size();i++){
                if(v[s][i]==nr){
                    v[s].erase(v[s].begin()+i);
                }
            }
        }
         else{
            if(este==true)
                fout<<1<<'\n';
            else
                fout<<0<<'\n';
        }

    }


    return 0;
}
