#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

int main() {
    int nrOP, operation, x;
    int fixedNumber = 666013;
    int found, key;
    vector<vector<int>> hash(fixedNumber+5);

    f >> nrOP;
    for (int i = 0; i < nrOP; i++) {
        f >> operation;
        f >> x;
        key = x % fixedNumber;
        found = 0;
        int j;
        for (j = 0; j < hash[key].size() && !found; j++) {
            if (hash[key][j] == x)
                found = 1;
        }

        if (operation == 1 && !found) hash[key].push_back(x);

        if (operation == 2) {
            if (found) {
                swap(hash[key][j-1], hash[key].back());
                hash[key].pop_back();
            }
        }

        if (operation == 3) g << found << '\n';
    }
    return 0;
}
