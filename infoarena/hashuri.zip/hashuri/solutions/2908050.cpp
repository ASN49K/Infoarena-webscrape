#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

struct nod
{
	int val;
	nod* l;
};

nod* v[666013];

bool parcurgere(int x)
{
	int index = x % 666013;
	nod* head = v[index];
	while (head != NULL)
	{
		if (head->val == x)
			return 1;
		head = head->l;
	}
	return 0;
}

void insereaza( int x)
{
	if (parcurgere(x) == 1)
		return;
	int index= x% 666013;
	if (v[index] == NULL)
	{
		v[index] = new nod;
		v[index]->val = x;
		v[index]->l = NULL;
	}
	else
	{
		nod* k = new nod;
		k->val = x;
		k->l = v[index];
		v[index] = k;
	}
}

void stergere(int x)
{
	if (parcurgere(x) == 0)
		return;
	int index = x % 666013;
	nod* head = v[index];
	nod* before = NULL;
	nod* after = NULL;

	while (head != NULL)
	{
		if (head->val == x)
		{
			after = head->l;
			break;
		}
		before = head;
		head = head->l;

	}

	if(before!=NULL)
		before->l = after;
	else
	{
		v[index] = after;
	}

	delete head;
	
}

int main()
{
	int n,q,x;
	fin >> n;
	for (int i = 1; i <= n; i++)
	{
		fin >> q >> x;
		if (q == 1)
		{
			insereaza(x);
		}
		if (q == 2)
		{
			stergere(x);
		}
		if (q == 3)
		{
			fout << parcurgere(x) << endl;
		}

	}

	for (int i = 0; i < 666013; i++)
	{
		nod* head = NULL;
		nod* next = v[i];
		while (next != NULL)
		{
			head = next;
			next = head->l;
			delete head;
		}
	}

	
}