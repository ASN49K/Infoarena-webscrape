#include <bits/stdc++.h>
using namespace std ;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
#define mod 666013
std::vector <int> h[mod];
std::vector <int> :: iterator it;
int ind , n , c , x ;
std::vector <int> ::iterator findx ( int x )
{
    for ( it = h[ind].begin(); it != h[ind].end() ; it ++ )
        if ( *it == x )
            return it ;
    return it ;
}
void add ( int x )
{
    if ( it == h[ind].end() )
        h[ind].push_back(x) ;
}
void deletex ()
{
    if ( it != h[ind].end() )
        h[ind].erase(it) ;
}
bool show ( int x )
{
    if ( it != h[ind].end() )
        return 1 ;
    return 0 ;
}
int main ()
{
    fin >> n ;
    while ( n )
    {
        fin >> c >> x ;
        ind = x % mod ;
        it = findx (x) ;
        if ( c == 1 )
            add(x) ;
        else if ( c == 2 )
            deletex() ;
        else
            fout << show(x) << '\n' ;
        n --;

    }

    return 0 ;
}
