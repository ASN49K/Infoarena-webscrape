#include <fstream>
#include <map>
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
int n,op,x;
map<int,int> M;
int main()
{
    fin >> n;
    for(int i=1;i<=n;i++)
    {
        fin >> op >> x;
        if(op==1)
        {
            M[x]++;
        }
        else if(op==2)
        {
            if(M[x]!=0) M[x]--;
        }
        else
        {
            if(M[x]==1) fout << "1\n";
            else fout << "0\n";
        }
    }
    return 0;
}

