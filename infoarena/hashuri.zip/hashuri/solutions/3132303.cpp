#include <iostream>
#include <fstream>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

struct node{
    node* next;
    int info;
}*h[1000001];

int n, op, val;
node *x, *temp;

int main()
{
    f>>n;
    for (int i=1;i<=n;i++)
    { f>>op>>val;
      x=h[val%1000000];
      switch(op)
      { case 1:
            temp=new node;
            temp->info=val;
            temp->next=x;
            h[val%1000000]=temp;
            break;
        case 2:
            if (!x)
                break;
            if (x->info==val)
                h[val%1000000]=x->next;
            else
            { while (x->next && x->next->info!=val)
                x=x->next;
              if (x->next)
              { temp=x->next;
                x->next=x->next->next;
                delete temp;
              }  
            }
            break;
        case 3:
            while (x && x->info!=val)
                x=x->next;
            if (x) g<<1<<'\n';
            else g<<0<<'\n';
      }

    }
}