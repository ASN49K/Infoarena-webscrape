//package hashuri;

import java.io.*;
import java.util.*;

public class Main {
    static final String INPUT_FILE = "hashuri.in";
    static final String OUTPUT_FILE = "hashuri.out";

    public static void main(String[] args) throws IOException {
        Scanner reader = new Scanner(new FileReader(INPUT_FILE));
        PrintWriter writer = new PrintWriter(OUTPUT_FILE);
        solve(reader, writer);
        reader.close();
        writer.flush();
        writer.close();
    }

    public static void solve(Scanner reader,
                             PrintWriter writer) {
        int n = reader.nextInt();
        Set<Integer> map = new HashSet<>();
        while (n-- > 0) {
            int op = reader.nextInt();
            int el = reader.nextInt();
            if (op == 1) {
                map.add(el);
            } else if (op == 2) {
                map.remove(el);
            } else if (op == 3) {
                writer.println(map.contains(el) ? 1 : 0);
            }
        }
    }
}