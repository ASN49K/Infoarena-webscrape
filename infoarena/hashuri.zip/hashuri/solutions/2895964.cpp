
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

long long nr;
vector <int> v[666014];
vector <int>::iterator i;

int main()
{
    int c,x,k, prim = 666013;
    in>>nr;
    for (int ii=0 ; ii<nr; ii++)
    {
        in>>c>>x;
        int j=x%prim;
        k=0;

        for(i=v[j].begin();i!=v[j].end();i++)
            if(*i==x)
        {
            k=1;
            break;
        }

        if (c == 1 && k==0)
        {
            v[j].push_back(x);
        }

        else if (c==2 && k!=0)
        {
            v[j].erase(i);
        }
        else if(c==3)
            out<<k<<"\n";
    }

    in.close();
    out.close();
    return 0;
}
