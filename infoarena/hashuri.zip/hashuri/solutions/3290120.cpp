#include <bits/stdc++.h>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int n,x,t;
map<int,bool> M;

int main()
{
    fin>>n;
    while(n--)
    {
        fin>>t>>x;
        if(t==1)
            M[x]=1;
        else if(t==2)
            M[x]=0;
        else
            fout<<M[x]<<endl;
    }
    return 0;
}
