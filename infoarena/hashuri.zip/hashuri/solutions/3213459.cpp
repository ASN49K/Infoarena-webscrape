#include <bits/stdc++.h>

#define ll long long

//#define fin cin
//#define fout cout

using namespace std;

ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");

map <int, int> hash_table;

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    int n, a, b; fin>>n;
    for (int i=1; i<=n; i++) {
        fin>>a>>b;
        if (a==1) {
            hash_table[b]=69420;
        }
        if (a==2) {
            hash_table.erase(b);
        }
        if (a==3) {
            fout<<hash_table.count(b)<<'\n';
        }
    }
    return 0;
}