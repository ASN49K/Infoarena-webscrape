#include <iostream>
#include <fstream>
#include <unordered_map>

using namespace std;

ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");

unordered_map <int,int> mp;

int main(){
    
    int nr , t, h;

    fin >> nr;

    for(int i = 1; i <= nr; i++){
        fin >> t >> h;
        
        switch (t)
        {
        case 1:
            mp[h]=1;
        break;
        
        case 2:
            mp[h]=0;
        break;

        case 3:
            fout << mp[h] <<'\n';
        break;
        }

        
    }
}