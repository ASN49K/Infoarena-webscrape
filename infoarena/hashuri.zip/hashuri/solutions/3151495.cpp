#include <fstream>
#include <vector>
#include <queue>
#include <bitset>
#include <cstdlib>
using namespace std;
string file = "hashuri";
ifstream cin(file + ".in");
ofstream cout(file + ".out");
const int k = 1<<19,N = 1e6;

int lst[k], val[N], urm[N],nr;

int pozitie(int cat, int x)
{
    for (int p = lst[cat]; p!= 0; p = urm[p])
    {
        if (val[p] == x)
            return p;
    }
    return -1;
}

void adauga(int x)
{
    int cat = x % k; // x % k

    int p = pozitie(cat,x);
    if (p==-1)
    {
        ++nr;
        val[nr] = x;
        urm[nr] = lst[cat];
        lst[cat] = nr;
    }
}

void sterge(int x)
{
    int cat = x % k; // x % k
    int p = pozitie(cat,x);
    if (p != -1)
    {
        val[p] = val[lst[cat]];
        lst[cat] = urm[lst[cat]];
    }
}

int main()
{
    int n, op, x;
    cin >> n;
    for (int i=1; i<=n; i++)
    {
        cin >> op >> x;
        if (op == 1)
        {
            adauga(x);
        }
        else if (op == 2)
        {
            sterge(x);
        }
        else
        {
            if (pozitie(x % k, x) != -1)
                cout << "1\n";
            else
                cout << "0\n";
        }
    }
}
