#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <vector>

using namespace std; 

#define MOD 666013

int N;
vector<int> G[MOD];

inline vector<int>::iterator find_value(int x){
	int list = x % MOD;
	vector<int>::iterator it;
	for(it = G[list].begin(); it != G[list].end(); ++it)
		if(*it == x)
			return it;
	return G[list].end();
}	

inline void insert_value(int x){	
	int list = x % MOD;
	if(find_value(x) == G[list].end())
		G[list].push_back(x);
}

inline void erase_value(int x){
	int list = x % MOD;
	vector<int>::iterator it = find_value(x);
	if(it != G[list].end())
		G[list].erase(it);
}

int main(){
	freopen("hashuri.in", "r", stdin);
	freopen("hashuri.out", "w", stdout);
	
	int N, x, y;

	for(scanf("%d", &N); N; N--){
		scanf("%d %d", &x, &y);
		if(x == 1){
			insert_value(x);
			continue;
		}

		if(x == 2){
			erase_value(x);
			continue;
		}
		
		printf("%d\n", find_value(x) != G[x % MOD].end()); 
	}

	return 0;
}
