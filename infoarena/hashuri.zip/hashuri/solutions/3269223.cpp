#include <fstream>
#include <unordered_map>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

int n, op, x;

unordered_map <int, bool> m;

int main()
{
    f >> n;

    while (n--) {
        f >> op >> x;

        if (op == 1) {
            m[x] = 1;
        }
        else if (op == 2) {
            m.erase(x);
        }
        else {
            g << (m.find(x) != m.end()) << '\n';
        }
    }

    return 0;
}
