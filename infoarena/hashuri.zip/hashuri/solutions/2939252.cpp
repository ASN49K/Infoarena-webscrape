#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream cin("hashuri.in");
ofstream cout("hashuri.out");

#define prime 29

int n;
vector<vector<int>> h;

void read() {
    cin>>n;
    h.resize(666013+1);
}

int makeHash(int nr) {
    int res=0,pow=1;
    while(nr>0) {
        res+=((nr%10)*pow)%prime;
        res%=prime;
        pow*=prime;
        nr/=10;
    }
    return res%666013;
}

void solve() {
    int op,nr;
    for(int i=1;i<=n;i++) {
        cin>>op>>nr;
        int temp=makeHash(nr);
        if(op==1) {
            h[temp].push_back(nr);
        }
        else if(op==2) {
            auto it=find(h[temp].begin(),h[temp].end(),nr);
            if(it!=h[temp].end()) {
                h[temp].erase(it);
            }
        }
        else {
            auto it=find(h[temp].begin(),h[temp].end(),nr);
            cout<<((it!=h[temp].end())?1:0)<<"\n";
        }
    }
}

int main() {
 
    read();
    solve();
    return 0;
}