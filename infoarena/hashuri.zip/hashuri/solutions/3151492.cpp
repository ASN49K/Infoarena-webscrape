#include <fstream>
using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");
int n_op , tip , elem , nr;
const int K = 524287;
const int N = 1e6;
int lst_last_elem_added[K] , urm[N + 1] , val[N + 1];
int pozitie(int cat , int x){
    for(int p = lst_last_elem_added[cat] ; p != 0 ; p = urm[p]){
        if(val[p] == x){
            return p;
        }
    }
    return -1;
}
int adauga(int x){
    int cat = x % K; // aflam categoria
    int p = pozitie(cat , x); // practic verificam daca exista deja
    if(p == -1){ // daca nu
        nr++;
        val[nr] = x;
        urm[nr] = lst_last_elem_added[cat];
        lst_last_elem_added[cat] = nr;
    }
}
void stergere(int x){
    int cat = x % K;
    int p = pozitie(cat , x);
    if(p != -1){
        val[p] = val[lst_last_elem_added[cat]];
        lst_last_elem_added[cat] = urm[lst_last_elem_added[cat]];
    }
}
bool exista(int x){
    int cat = x % K;
    return (pozitie(cat , x) != -1);
}
int main(){
    int n;
    in >> n;
    for(int i = 1 ; i <= n ; i++){
        in >> tip >> elem;
        if(tip == 1){
            adauga(elem);
        }
        if(tip == 2){
            stergere(elem);
        }
        if(tip == 3){
            if(exista(elem)){
                out << 1 << '\n';
            }
            else{
                out << 0 << '\n';
            }
        }
    }
}
