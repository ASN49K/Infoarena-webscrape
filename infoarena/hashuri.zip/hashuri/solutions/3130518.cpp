#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>

const int prim = 700433;

int main(){
    std::ifstream f("hashuri.in");
    std::ofstream g("hashuri.out");

    std::vector<std::vector<int>> hashTable;

    int n, operatie, x;
    f >> n;
    while(n){
        f >> operatie >> x;
        int y = x % prim;
        while(hashTable.size() <= y)
            hashTable.push_back({});

        switch(operatie){
            case 1:{
                if(find(hashTable[y].begin(), hashTable[y].end(), x) == hashTable[y].end())
                hashTable[y].push_back(x);
                break;
            }
            
            case 2:{
                for(auto it = hashTable[y].begin(); it != hashTable[y].end(); it++)
                    if(*it == x){
                        hashTable[y].erase(it);
                        break;
                    }
                break;
            }

            case 3:{
                if(find(hashTable[y].begin(), hashTable[y].end(), x) != hashTable[y].end())
                    g << 1 << '\n';
                else
                    g << 0 << '\n';
                break;
            }
        }
        --n;
    }
    return 0;
}