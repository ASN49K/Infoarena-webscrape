#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

class Hash{

    private:
        int hash_mod;
        vector<int>* hash_array;
    
    public:

        Hash(int hash_mod = 666013){
            this->hash_mod = hash_mod;
            hash_array = new vector<int>[hash_mod];
        }

        size_t is_in(int n){

            int pos = n % hash_mod;

            for(size_t i = 0; i < hash_array[pos].size(); i++)
                if(hash_array[pos][i] == n)
                    return i;

            return -1;
        }

        void insert(int n){

            if(is_in(n) != -1) 
                return;
            else{
                int pos = n % hash_mod;
                hash_array[pos].push_back(n);
            }
        }

        void remove(int n){

            size_t result = is_in(n);
            if(result == -1)
                return;
            else{
                int pos = n % hash_mod;
                
                while(result < hash_array[pos].size()){
                    hash_array[pos][result] = hash_array[pos][result + 1];
                    result++;
                }

                hash_array[pos].pop_back();
            }
        }
};

fstream f("hashuri.in");
ofstream g("hashuri.out");

int main(){ 

    Hash hash;

    int n, op, no;
    f >> n;

    while(n){
        f >> op >> no;

        if(op == 1){
            hash.insert(no);
        }
        else if(op == 2){
            hash.remove(no);
        }
        else{
            g << (hash.is_in(no) ? 0 : 1) << endl;
        }

        n--;
    }

    return 0;
}