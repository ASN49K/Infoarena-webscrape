#include <iostream>


class listt {
	public:
	listt();
	~listt();
	void add(int a);
	void deletee(int a);
	bool find(int a);

private:
	int val;
	listt *nextt;
};

class hash
{
public:
	hash(int s);
	~hash();
	void deletee(int a);
	void add(int a);
	bool find(int a);
private:
	listt *v;
	int size;
};

listt::listt()
{
	nextt = NULL;
}

listt::~listt()
{
	while (nextt != NULL) {
		listt * realNextt = nextt->nextt;
		free(nextt);
		nextt = realNextt;
	}
}

void listt::add(int a)
{
	listt *current = this;
	while (current->nextt != NULL)
		current = current->nextt;
	current->nextt = (listt *) malloc(sizeof(*(current->nextt)));
	current->nextt->val = a;
	current->nextt->nextt = NULL;
}

void listt::deletee(int a)
{
	listt *current = this;
	while (current->nextt != NULL && current->nextt->val != a)
		current = current->nextt;
	if (current->nextt == NULL)
		return;

	listt *deleted = current->nextt;
	current->nextt = deleted->nextt;
	free(deleted);
}

bool listt::find(int a)
{
	listt *current = this;
	while (current->nextt != NULL) {
		if (current->nextt->val == a)
			return true;
		current = current->nextt;
	}
	return false;
}

void hash::deletee(int a)
{
	int pos = a % size;
	v[pos].deletee(a);
}
void hash::add(int a)
{
	int pos = a % size;
	v[pos].add(a);
}
bool hash::find(int a)
{
	int pos = a % size;
	return v[pos].find(a);
}

hash::hash(int s)
{
	v = (listt *)malloc(s * sizeof(*v));
	for (int i = 0; i < s; i++)
		v[i] = listt();
	size = s;
}

hash::~hash()
{
	free(v);
}

hash h = hash(2000000);

int main()
{
	FILE *fin = fopen("hashuri.in", "r");
	FILE *fout = fopen("hashuri.out", "w");
	int n;
	fscanf(fin, "%d", &n);
	for (int i = 0; i < n; i++) {
		int t, x;
		fscanf(fin, "%d %d", &t, &x);
		if (t == 1) {
			h.add(x);
		} else if (t == 2) {
			h.deletee(x);
		} else {
			fprintf(fout, "%d\n", h.find(x));
		}
	}
}
