#include <fstream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <map>
#include <set>
#include <cmath>
#include <algorithm>
#include <functional>
#include <cassert>
#include <stack>
#include <deque>
#include <RANDOM>
//#include <ext/pb_ds/assoc_container.hpp>
//using namespace __gnu_pbds;
using namespace std;
const int INF=(1<<30);
uniform_int_distribution<int>u(1,INF);
mt19937 G;
int randd()
{
    return u(G);
}
class TREAP
{
    struct node
    {
        int v,p;
        node *l,*r;
        node(int x,int y,node* s,node* d)
        {
            v=x;
            p=y;
            l=s;
            r=d;
        }
    }*leaf=new node(-INF,0,nullptr,nullptr),*S=leaf;
    void balancel(node *&s)
    {
        node* aux=s->l;
        s->l=aux->r;
        aux->r=s;
        s=aux;
    }
    void balancer(node *&s)
    {
        node* aux=s->r;
        s->r=aux->l;
        aux->l=s;
        s=aux;
    }
    void balance(node *&s)
    {
        if(s->p < s->l->p)
        {
            balancel(s);
        }
        if(s->p < s->r->p)
        {
            balancer(s);
        }
    }
    void insert(node *&s,int val)
    {
        if(s->v==val)return;
        if(s==leaf)
        {
            s=new node(val,randd(),leaf,leaf);
        }
        else
        {
            if(s->v>val)
            {
                insert(s->l,val);
            }
            else
            {
                insert(s->r,val);
            }
            balance(s);
        }

    }
    void erase(node *&s,int val)
    {
        if(s==leaf)return;
        if(s->v>val)
        {
            erase(s->l,val);
        }
        else if(s->v<val)
        {
            erase(s->r,val);
        }
        else
        {
            if(s->l==leaf && s->r==leaf)
            {
                delete(s);
                return;
            }
            if(s->l->p > s->r->p)
            {
                balancel(s);
            }
            else
            {
                balancer(s);
            }
            erase(s,val);
        }

    }
    bool find(node *s,int val)
    {
        if(s==leaf)return 0;
        if(s->v==val)
        {
            return 1;
        }
        if(s->v>val)
        {
            return find(s->l,val);
        }
        else
        {
            return find(s->r,val);
        }
    }
public:
    void insert(int x)
    {
        insert(S,x);
    }
    void erase(int x)
    {
        erase(S,x);
    }
    bool find(int x)
    {
        return find(S,x);
    }

};
void solve()
{
    ifstream cin("hashuri.in");
    ofstream cout("hashuri.out");
    TREAP mp;
    int q;
    cin>>q;
    while(q--)
    {
        int a,b;
        cin>>a>>b;
        if(a==1)
        {
            mp.insert(b);
        }
        else if(a==2)
        {
            mp.erase(b);
        }
        else
        {
            cout<<mp.find(b)<<'\n';
        }
    }

}
int32_t main()
{
    function<string(bool)>sol=[&](bool x)
    {
        if(x)return "YES";
        return "NO";
    };
    int _=1;
    //cin>>_;
    while(_--)
    {
        solve();
    }
}
