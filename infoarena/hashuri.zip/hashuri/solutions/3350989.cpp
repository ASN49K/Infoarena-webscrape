#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
#define MOD 666013
vector<int> H[MOD];
vector<int>::iterator find_element(int x){
    int hx = x % MOD;
    for(auto it = H[hx].begin(); it != H[hx].end(); it++){
        if(*it == x) return it;
    }
    return H[hx].end();
}
void insert_element(int x){
    int hx = x%MOD;
    if(find_element(x) == H[hx].end()) H[hx].push_back(x);
}
void delete_element(int x){
    int hx = x%MOD;
    auto it = find_element(x);
    if(it != H[hx].end()) H[hx].erase(it);
}
int main(){
    int n;
    fin >> n;
    while(n--){
        int c,x;
        fin >> c >> x;
        if(c == 1){
            insert_element(x);
            continue;
        }
        if(c == 2){
            delete_element(x);
            continue;
        }
        cout << (find_element(x) != H[x%MOD].end()) << '\n';
    }

    return 0;
}