#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#define M 1<<20

std::ifstream in("hashuri.in");
std::ofstream out("hashuri.out");

std::vector<int> Hash[M];

inline std::vector<int>::iterator find_value(int x){
    int index = x % M;
    std::vector<int>::iterator it;
    for(it = Hash[index].begin(); it != Hash[index].end(); it++)
        if(*it == x)
            return it;
    return Hash[index].end();
}

inline void insert(int v){
    int index = v % M;
    if(find_value(v) != Hash[index].end()) return; 
    Hash[index].push_back(v);
}

inline void rem(int v){
    int index = v % M;
    std::vector<int>::iterator it = find_value(v);
    if(it == Hash[index].end()) return;
    Hash[index].erase(it);
}


int main(){
    int n;
    in >> n;
    for(int i = 0; i<n; i++){
        int op, v;
        in >> op >> v;
        if(op == 1)
            insert(v);
        else if(op == 2){
            rem(v);
        }
        else{
            int index = v % M;
            out << (find_value(v) != Hash[index].end()) <<"\n";
        }
    }
}