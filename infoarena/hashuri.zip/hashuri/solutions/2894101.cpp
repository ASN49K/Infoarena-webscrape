#include <iostream>
#include <fstream>
#include <vector>
#define nrmare 666013
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
vector<int> hashuri[nrmare];
bool cautare(int x){
    for(auto i = 0; i < hashuri[x%nrmare].size();i++) {
        if (hashuri[x%nrmare][i] == x)
            return 1;
    }
    return 0;
}
void stergere(int x) {
    for (auto i = 0; i < hashuri[x % nrmare].size(); i++) {
        if (hashuri[x%nrmare][i] == x) {
            for(int j = i; j < hashuri[x % nrmare].size(); j++)
                hashuri[x % nrmare][j] = hashuri[x % nrmare][j + 1];
            hashuri[x % nrmare].pop_back();
            break;
        }
    }
}
void adaugare(int x) {
    if (!cautare(x)) {
        hashuri[x%nrmare].push_back(x);
    }
}

int main() {
    int i;
    f>>i;
    while(i>0){
        int aux,x;
        f>>aux>>x;
        if(aux == 1){
            adaugare(x);
        }
        if(aux == 2){
            stergere(x);
        }
        if(aux == 3){
            g<<cautare(x)<<'\n';
        }
        --i;
    }
    return 0;
}
