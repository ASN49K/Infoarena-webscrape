#include <bits/stdc++.h>
#include <type_traits>
using namespace std;

#pragma GCC optimize("Ofast")
#pragma GCC target("avx,avx2,fma")
#pragma GCC optimization("unroll-loops")

// ============ Macros starts here ============
int recur_depth = 0;
#ifdef DEBUG
#define dbg(x) {++recur_depth; auto x_=x; --recur_depth; cerr<<string(recur_depth, '\t')<<"\e[91m"<<__func__<<":"<<__LINE__<<"\t"<<#x<<" = "<<x_<<"\e[39m"<<endl;}
#else
#define dbg(x)
#endif // DEBUG
template<typename Ostream, typename Cont>
typename enable_if<is_same<Ostream, ostream>::value, Ostream&>::type operator<<(Ostream& os, const Cont& v) {
    os << "[";
    for (auto& x : v) { os << x << ", "; }
    return os << "]";
}
template<typename Ostream, typename ...Ts>
Ostream& operator<<(Ostream& os, const pair<Ts...>& p) {
    return os << "{" << p.first << ", " << p.second << "}";
}

#define readFast                      \
    ios_base::sync_with_stdio(false); \
    cin.tie(0);                       \
    cout.tie(0);
#ifdef LOCAL
#define read() ifstream fin("date.in.txt")
#else
#define read() readFast
#endif // LOCAL
// ============ Macros ends here ============

#define fin cin
#define ll long long
#define sz(x) (int)(x).size()
#define all(v) v.begin(), v.end()
#define output(x) (((int)(x) && cout << "YES\n") || cout << "NO\n")
#define LSB(x) (x & (-x))
#define test cout << "WORKS\n";

const int N = 2e5 + 27;
const int MOD = 1e9 + 7;

class Hashset {
public:
    Hashset() {
        hashset = vector<list<int>>(1000);
    }
    int hash(int key) {
        return key % 1000;
    }
    void add(int key) {
        int h = hash(key);
        if (find(all(hashset[h]), key) == hashset[h].end()) {
            hashset[h].push_back(key);
        }
    }
    void remove(int key) {
        int h = hash(key);
        auto it = find(all(hashset[h]), key);
        if (it != hashset[h].end()) {
            hashset[h].erase(it);
        }
    }
    bool contains(int key) {
        int h = hash(key);
        return find(all(hashset[h]), key) != hashset[h].end();
    }
private:
    vector<list<int>> hashset;
};

int main() {
    ifstream fin("hash.in");
    ofstream fout("hash.out");
    Hashset hashset;
    int n;
    fin >> n;
    while (n--) {
        int t, nr;
        fin >> t >> nr;
        if (t == 1) {
            hashset.add(nr);
        } else if (t == 2) {
            hashset.remove(nr);
        } else {
            fout << hashset.contains(nr) << '\n';
        }
    }
    return 0;
} /*stuff you should look for !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   * test the solution with the given example
   * int overflow, array bounds, matrix bounds
   * special cases (n=1?)
   * do smth instead of nothing and stay organized
   * WRITE STUFF DOWN
   * DON'T GET STUCK ON ONE APPROACH
~Benq~*/