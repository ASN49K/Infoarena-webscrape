#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

long long nr;

vector <int> v[666014];
vector <int>::iterator poz;

int main()
{
    int prim = 666013;
    int op,x;
    int k;

    f>>nr;
    for (int i= 0; i<nr; i++)
    {
        f>>op>>x;
        int j = x%prim;
        k=0;

        for(poz=v[j].begin();poz!=v[j].end();poz++)
            if(*poz==x)
        {
            k=1;
            break;
        }

        if (op == 1)
        {
            if(!k)
            v[j].push_back(x);
        }

        if (op==2)
        {
            if(k)
            v[j].erase(poz);
        }

        if(op==3)
        g<<k<<"\n";
    }

    f.close();
    g.close();
    return 0;
}
