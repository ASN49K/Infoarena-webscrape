#include <fstream>
#include <vector>
#include <iterator>
#define MOD 1000007
using namespace std;
ifstream cin("hashuri.in");
ofstream cout("hashuri.out");
int i, j, n, m, k, ok, op, x;
vector <int> v[MOD+2];
vector <int> :: iterator it;
int main() {
    cin>>n;
    for(i=1;i<=n;i++){
        cin>>op>>x;
        if(op==1){
            ok=1;
            for(it=v[x%MOD].begin();it!=v[x%MOD].end();it++){
                if(*it==x){
                    ok=0;
                    break;
                }
            }
            if(ok==1)
                v[x%MOD].push_back(x);
        }
        if(op==2){
            for(it=v[x%MOD].begin();it!=v[x%MOD].end();it++){
                if(*it==x){
                    v[x%MOD].erase(it);
                    break;
                }
            }
        }
        if(op==3){
            ok=1;
            for(it=v[x%MOD].begin();it!=v[x%MOD].end();it++){
                if(*it==x){
                    ok=0;
                    break;
                }
            }
            if(ok==0)
                cout<<1<<"\n";
            else
                cout<<0<<"\n";
        }
    }



}
