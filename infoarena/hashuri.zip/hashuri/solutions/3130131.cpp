#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

class HashTable{
private:
    vector<vector<int>> hash; // we must use vector<vector<int>> in order to support collisions 
    int hashValue; 
public:
    HashTable(){
        hashValue = 777013; //big prime number
        hash.resize(hashValue);
    }
    // returns the position of the element in the hashed vector from the hash if it exists, else -1
    int findPos(int x){
        int hashed = x % hashValue;
        for (int i = 0; i < hash[hashed].size(); i++)
            if(hash[hashed][i] == x)
                return i;
        return -1;
    }
    bool exists(int x){
        if(findPos(x) == -1)
            return 0;
        return 1;
    }
    void insert(int x){
        // we use a simple hash function to map the element x to a position in the vector (to the vector at the position i)
        int i = x % hashValue;
        if(!this->exists(x)){
            hash[i].push_back(x);
        }
    }
    void del(int x){
        if(this->exists(x)){
            int i = x % hashValue;
            int pos = findPos(x);
            hash[i].erase(hash[i].begin() + pos);
        }
    }
};



int main(){ 
    ifstream f("hashuri.in");
    ofstream g("hashuri.out");
    HashTable h;

    int n, a, b;
    f >> n;
    while(n--){
        f >> a >> b;
        switch(a){
            case 1:{
                h.insert(b);
                break;
            }
            case 2:{
                h.del(b);
                break;
            }
            case 3:{
                g<<h.exists(b)<<endl;
                break;
            }
            default:{
                break;
            }
        }
    }
    f.close();
    g.close();
    return 0;
}