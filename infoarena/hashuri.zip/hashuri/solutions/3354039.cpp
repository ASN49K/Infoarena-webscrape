#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;

struct Node {
  int val;
  Node* next;
  
  Node(int val, Node* next) {
    this->val = val;
    this->next = next;
  }
};

const int MX = 1000001;
Node* hashmap[MX];

void push(Node* &head, int val) {
  if (head == nullptr) {
    head = new Node(val, nullptr);
    return;
  }
  
  Node* aux = head;
  while (aux->next != nullptr) {
    aux = aux->next;
  }
  
  aux->next = new Node(val, nullptr);
};

bool isval(Node* &head, int val) {
  Node* curr = head;
  
  while (curr != nullptr) {
    if (curr->val == val) {
      return true;
    }
    
    curr = curr->next;
  }
  
  return false;
}

void ersval(Node* &head, int val) {
  if (head == nullptr) return;
  if (!isval(head, val)) return;
  
  Node* prev = nullptr;
  Node* curr = head;
  
  while (curr != nullptr) {
    if (curr->val != val) {
      prev = curr;
      curr = curr->next;
    } else {
      break;
    }
  }
  
  if (prev == nullptr) {
    head = nullptr;
  } else {
    prev->next = curr->next;
  }
}

int main() {
    freopen("hash.in", "r", stdin);
    freopen("hash.out", "w", stdout);

    for (int i = 0; i < MX; i++) {
      hashmap[i] = nullptr;
    }
    
    int n;
    cin >> n;
    
    int op, v;
    int hashed = -1;
    for (int i = 0; i < n; i++) {
      cin >> op >> v;
      
      hashed = v / 20;
      if (op == 1) {
        if (!isval(hashmap[hashed], v)) {
          push(hashmap[hashed], v);
        }
      } else if (op == 2) {
        ersval(hashmap[hashed], v);
      } else if (op == 3) {
        if (isval(hashmap[hashed], v)) {
          cout << 1 << "\n";
        } else {
          cout << 0 << "\n";
        }
      }
    }
    
    return 0;
}
