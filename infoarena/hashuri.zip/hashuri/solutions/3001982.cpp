#include <fstream>
#include <vector>
#define mod 666013
using namespace std;

ifstream cin ("hashuri.in");
ofstream cout ("hashuri.out");

vector < vector <int> > tabel(mod);

vector <int> :: iterator Cauta (int valoare)
{
    int lista = valoare % mod;
    for (vector <int> :: iterator element = tabel[lista].begin() ; element < tabel[lista].end() ; element++)
        if (*element == valoare)
            return element;

    return tabel[lista].end();
}

void Adauga (int valoare)
{
    int lista = valoare % mod;
    if (Cauta(valoare) == tabel[lista].end())
        tabel[lista].push_back(valoare);
}

void Sterge (int valoare)
{
    int lista = valoare % mod;
    vector <int> :: iterator pozitie = Cauta(valoare);
    if (pozitie != tabel[lista].end())
        tabel[lista].erase(pozitie);
}

int main ()
{
    int operatii , tip , valoare;
    for (cin >> operatii ; operatii ; operatii--)
    {
        cin >> tip >> valoare;

        switch (tip)
        {
            case 1:
                Adauga(valoare);
            break;

            case 2:
                Sterge(valoare);
            break;

            case 3:
                cout << (Cauta(valoare) != tabel[valoare % mod].end() ? 1 : 0) << '\n';
            break; 
        }
    }

    cout.close(); cin.close();
    return 0;
}