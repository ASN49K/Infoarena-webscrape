#include<bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
///hashuri
///preordine

class Hash
{
public:
    int n;
    list<int> *H;
    list<string> *Hs;
    list<string> *Prefix;
    Hash(int n)
    {
        this->n = n;
        H = new list<int>[n+5];
        Hs = new list<string>[n+5];
        Prefix = new list<string>[n+5];
    }
    ~Hash()
    {
        delete []H;
        delete []Hs;
        delete []Prefix;
    }
    int Modulo(int x)
    {
        return x % n;
    }
    int Modulo_String(string x)
    {
        int i;
        long long p, nr;
        nr = 0;
        p = 1;
        for(i=0; x[i]!=0; i++)
        {
            nr = (nr + (x[i] - 'a' + 1) * p) % n;
            p = (p * 64) % n;
        }
        return nr;
    }
    virtual void Insert(int x)
    {
        int index = Modulo(x);
        H[index].push_back(x);
    }
    void Insert_String(string x)
    {
        int index = Modulo_String(x);
        Hs[index].push_back(x);
    }
    virtual void Delete(int x)
    {
        int index = Modulo(x);
        list <int> :: iterator it;
        for (it = H[index].begin(); it != H[index].end() && *it != x; it++)
            ;
        if(it != H[index].end()) H[index].erase(it);
    }
    void Delete_String(string x)
    {
        int index = Modulo_String(x);
        list <string> :: iterator it;
        for (it = Hs[index].begin(); it != Hs[index].end() && *it != x; it++)
            ;
        if(it != Hs[index].end()) Hs[index].erase(it);
    }
    void Delete_Prefix(string x)
    {
        list <string> :: iterator it;
        int i;
        long long p, nr;
        nr = 0;
        p = 1;
        for(i=0; x[i]!=0; i++)
        {
            nr = (nr + (x[i] - 'a' + 1) * p) % n;
            p = (p * 64) % n;
            for (it = Prefix[nr].begin(); it != Prefix[nr].end() && *it != x; it++)
                ;
            if(it != Prefix[nr].end()) Prefix[nr].erase(it);
        }
    }
    void Afisare()
    {
        int i;
        for (i = 0; i < n; i++)
        {
            for (auto w : H[i])
                cout << w << " ";
            cout << "\n";
        }
    }
    void Afisare_String()
    {
        int i;
        for (i = 0; i < n; i++)
        {
            for (auto w : Hs[i])
                cout << w << " ";
            cout << "\n";
        }
    }
    virtual bool Find(int x)
    {
        int index = Modulo(x);
        list<int>::iterator it;
        for (it = H[index].begin(); it != H[index].end(); it++)
            if (*it == x) return true;
        return false;
    }
    int Find_Fr(string x)
    {
        int index = Modulo_String(x);
        list<string>::iterator it;
        int nr = 0;
        for (it = Hs[index].begin(); it != Hs[index].end(); it++)
            if (*it == x) nr++;
        return nr;
    }
    bool Find_String(string x)
    {
        int index = Modulo_String(x);
        list<string>::iterator it;
        for (it = Hs[index].begin(); it != Hs[index].end(); it++)
            if (*it == x) return true;
        return false;
    }
    bool Find_Prefix(string x)
    {
        int index = Modulo_String(x);
        list<string>::iterator it;
        for (it = Prefix[index].begin(); it != Prefix[index].end(); it++)
            if (*it == x) return true;
        return false;
    }
    virtual void Add_Prefix(string x)
    {
        string s;
        int i;
        long long p, nr;
        nr = 0;
        p = 1;
        for(i=0; x[i]!=0; i++)
        {
            nr = (nr + (x[i] - 'a' + 1) * p) % n;
            p = (p * 64) % n;
            s.push_back(x[i]);
            Prefix[nr].push_back(s);
        }
    }
    void Find_Root(string x)
    {
        string s, aux;
        int i, lg;
        long long p, nr;
        nr = lg = 0;
        p = 1;
        aux = x;
        for(i=0; x[i]!=0; i++)
        {
            nr = (nr + (x[i] - 'a' + 1) * p) % n;
            p = (p * 64) % n;
            s.push_back(x[i]);
            if(Prefix[nr].size() != 0 && Find_Prefix(s) == true)
            {
                lg = i + 1;
                aux = s;
            }
        }
        cout << aux << " ";
    }
};

class Hashuri : public Hash
{
public:
    Hashuri(int _n = 123457) : Hash(_n)
    { }
    void Rezolvare()
    {
        int op, n, i, x;
        fin >> n;
        for(i=1; i<=n; i++)
        {
            fin >> op >> x;
            if(op == 1) Insert(x);
            else if(op == 2) Delete(x);
            else fout << Find(x)  << "\n";
        }
    }
};

int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    Hashuri A;
    A.Rezolvare();
    fin.close();
    fout.close();
    return 0;
}
