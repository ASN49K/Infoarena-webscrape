#include <bits/stdc++.h>
using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");

map<long long ,long long> mp;


int main()
{
    int q ;
    in >> q;

    for ( int i = 1; i <= q; i ++ )
    {
        int tip;
        in >> tip ;

        if ( tip == 1)
        {
            long long  x;
            in >> x ;
            mp [ x ] = 1;
        }
        else
            if ( tip == 2 )
        {
            long long x ;
            in >> x ;
            mp [ x] = 0 ;
        }
        else
        {
            long long  x;
            in >> x ;
            out << mp [ x ] << '\n';
        }
    }





    return 0;
}
