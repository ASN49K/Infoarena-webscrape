#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <iostream>
#define M 666013

using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

typedef struct Node{
	int value;
	struct Node* next;
}Node;

Node* Hash[M];

void insert(int v){
	int index = v % M;
	Node *p = Hash[index];
	while(p != NULL){
		if(p->value == v)
			return;
		p = p->next;
	}

	Node* node = (Node*) malloc(sizeof(Node));
	node->value = v;
	node->next = NULL;
	
	if(Hash[index] == NULL)
		Hash[index] = node;
	else
		Hash[index]->next = node;
}

void sterge(int v){
	int index = v % M;
	Node *p = Hash[index];
	if(p == NULL)
		return;
	if(p->value == v && p->next == NULL){
		free(p);
		Hash[index] = NULL;
		return;
	}

	if(p->value == v && p->next != NULL){
		Node *aux = p;
		Hash[index] = p->next;
		free(aux);
		return;
	}
	
	while(p->next != NULL){
		if(p->next->value == v){
			Node* aux = p->next;
			p->next = p->next->next;
			free(aux);
			return;
		}
		p = p->next;
	}

	if(p->value == v){
		free(p);
	}
}

void prezent(int v){
	int index = v % M;
	int cond = 0;
	Node *p = Hash[index];
	while(p != NULL){
		if(p->value == v){
			cond = 1;
			break;
		}
		p = p->next;
	}
	if(cond == 1)
		out << 1 << endl;
	else
		out << 0 << endl;
}

int main(){
	int n;
	in >> n;
	for(int i = 0; i<n; i++){
		int op, v;
		in >> op >> v;
		if(op == 1)
			insert(v);
		else if(op == 2)
			sterge(v);
		else
			prezent(v);
	}
}