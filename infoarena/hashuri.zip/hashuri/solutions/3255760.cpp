#include <iostream>
#include <bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

vector<int>::iterator ie,j;


const int nmax=1000;
int x,y,ym,adv,n;

vector < vector<int> >ha;



int main()
{
    fin>>n;
    ha.assign(nmax,vector<int>());
    for(int i=0;i<n;i++){
        adv=0;
        fin>>x>>y;
        ym=y%nmax;
        for(j=ha[ym].begin();j<ha[ym].end();++j){
            if(*j==y){
                adv=1;
                ie=j;
            }
        }
        if(x==1){
            if(!adv){
              ha[ym].push_back(y);
            }
        }
        else if(x==2){
            if(adv)
            ha[ym].erase(ie);
        }

        else{
            if(adv)fout<<1<<'\n';
            else fout<<0<<'\n';
        }

    }
}
