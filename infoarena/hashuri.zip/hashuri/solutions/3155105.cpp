#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#define M 1<<20

std::ifstream in("hashuri.in");
std::ofstream out("hashuri.out");

std::vector<int> Hash[M];

void insert(int v){
    int index = v % M;
    std::vector<int>::iterator it;
    it = std::find(Hash[index].begin(), Hash[index].end(), v);
    if(it != Hash[index].end()) return;
    
    Hash[index].push_back(v);
}

void rem(int v){
    int index = v % M;
    std::vector<int>::iterator it;
    it = std::find(Hash[index].begin(), Hash[index].end(), v);
    if(it == Hash[index].end()) return;
    Hash[index].erase(it);
}

void afis(int v){
    int index = v % M;
    bool cond = false;
    std::vector<int>::iterator it = Hash[index].begin();
    while(it != Hash[index].end()){
        if(*it == v){
            out << 1 << "\n";
            return;
        }
        it++;
    }
    out << 0 << "\n";
    return;
}

int main(){
    int n;
    in >> n;
    for(int i = 0; i<n; i++){
        int op, v;
        in >> op >> v;
        if(op == 1)
            insert(v);
        else if(op == 2){
            rem(v);
        }
        else{
            afis(v);
        }
    }
}