#include <bits/stdc++.h>
#define Mod 666013
using namespace std;
map <int , int> a
int n,x,op;
ifstream ci("hashuri.in");
ofstream cou("hashuri.out");
{ci >> n;
for(int i=1;i<-n;i++){
ci >> op >> x;
if(op==1)
a[x%Mod]==1
if(op==2)
a[x%Mod]==0
if(op==3)
cou << a[x%Mod] << '\n';
}

    return 0;
}
