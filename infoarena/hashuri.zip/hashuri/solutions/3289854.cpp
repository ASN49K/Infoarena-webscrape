#include <bits/stdc++.h>

using namespace std;

ifstream fin ( "hashuri.in" );
ofstream fout ( "hashuri.out" );

#define cin fin
#define cout fout

#define FR( a, b ) for( int a = 0; a < (int) b; a ++ )
#define FOR( a, c, b ) for( int a = c; a < (int) b; a ++ )
#define PB push_back

typedef pair< int, int> pii;

int mod;
vector< int > v[200000];

void inserare( int x ) {
  int bucket = x % mod;
  FR( i, v[bucket].size() )
    if( v[bucket][i] == x )
      return;

  v[bucket].PB( x );
}

void sterge( int x ) {
  int bucket = x % mod;
  FR( i, v[bucket].size() )
    if( v[bucket][i] == x ) {
      v[bucket].erase( v[bucket].begin() + i );
      return;
    }
}

int apare( int x ) {
  int bucket = x % mod;
  FR( i, v[bucket].size() )
    if( v[bucket][i] == x )
      return 1;

  return 0;
}

int main()
{
    int queries, tip, i, val;

    cin >> queries;

    mod = ( rand() % 10000 ) + 100000;

    for( i = 0; i < queries; i ++ )  {
      cin >> tip >> val;
      if( tip == 1 )
        inserare( val );
      else if ( tip == 2 )
        sterge( val );
      else
        cout << apare( val ) << '\n';
    }
    return 0;
}
