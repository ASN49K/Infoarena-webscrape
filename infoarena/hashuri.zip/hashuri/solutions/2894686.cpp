
#include <fstream>
#include<vector>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

vector<int> myhash[666018];

int main()
{
    int k=666018;
    int n, operatie, element;
    f>>n;
    int clasa;
    for(int i=1;i<=n;i++)
        {f>>operatie>>element;
        clasa=element%k;
        if(operatie==1)

        {   int found=0;
            for(unsigned int j=0;j<myhash[clasa].size();j++)
                if (myhash[clasa][j]==element)
            {
                found = 1;
            }
            if (found==0)
                myhash[clasa].push_back(element);
        }

        if(operatie==3)
        {
            int found=0;
            for(unsigned int j=0;j<myhash[clasa].size();j++)
                if (myhash[clasa][j]==element)
            {
                found = 1;
                break;
            }
            g<<found<<'\n';

        }

        if(operatie==2)
        { for(unsigned int j=0;j<myhash[clasa].size();j++)
                if (myhash[clasa][j]==element)
            {
                swap(element, myhash[clasa][myhash[clasa].size()-1]);
                myhash[clasa].pop_back();
                break;
            }

        }
        }

}
