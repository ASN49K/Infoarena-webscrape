#include <bits/stdc++.h>
using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

const int M = 666013;

int n;
vector<int> sets[M];

int f(int x) {
	return x % M;
}

bool is(int x) {
	int where = f(x);
	//for (int i = 0; i < (int)sets[where].size(); i++) {
		//if (sets[where][i] == x) {
			//return true;
		//}
	//}
	for (int value : sets[where]) {
		if (value == x) {
			return true;
		}
	}
	return false;
}

void add(int x) {
	if (is(x)) {
		return;
	}
	sets[f(x)].push_back(x);
}

void del(int x) {
	if (is(x)) {
		return;
	}
	int where = f(x), pos = -1;
	// erase x in sets[where]
	for (int i = 0; i < (int)sets[where].size(); i++) {
		if (x == sets[where][i]) {
			pos = i;
		}
	}
	sets[where].erase(sets[where].begin() + pos);
}

int main() {
	in >> n;
	for (int i = 0; i < n; i++) {
		int op, x; in >> op >> x;
		if (op == 1) {
			add(x);
		} else if (op == 2) {
			del(x);
		} else {
			out << is(x) << "\n";
		}
	}
	return 0;
}
