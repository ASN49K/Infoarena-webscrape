#include <fstream>
#include <vector>

using namespace std;

ifstream in ("hashuri.in");
ofstream out ("hashuri.out");

const int mod = 666013;

vector <int> hsh[mod + 1];

vector <int> :: iterator gaseste (int x)
{
    int baza = x % mod;
    for (vector <int> :: iterator it = hsh[baza].begin(); it != hsh[baza].end(); it++)
    {
        if (*it == x)
        {
            return it;
        }
    }
    return hsh[baza].end();
}

void insereaza (int x)
{
    int baza = x % mod;
    if (gaseste(x) == hsh[baza].end())
    {
        hsh[baza].push_back(x);
    }
}

void sterge (int x)
{
    int baza = x % mod;
    vector <int> :: iterator it = gaseste(x);
    if (it != hsh[baza].end())
    {
        hsh[baza].erase(it);
    }
}

int main ()
{
    int q;
    in >> q;
    while (q--)
    {
        int op, x;
        in >> op >> x;
        if (op == 1)
        {
            insereaza(x);
        }
        if (op == 2)
        {
            sterge(x);
        }
        if (op == 3)
        {
            if (gaseste(x) != hsh[x % mod].end())
            {
                out << 1;
            }
            else
            {
                out << 0;
            }
            out << '\n';
        }
    }
    in.close();
    out.close();
    return 0;
}
