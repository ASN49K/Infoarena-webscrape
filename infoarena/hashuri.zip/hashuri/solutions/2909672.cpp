#include<iostream>
#include<fstream>
#include <stdio.h>
#include <ctype.h>
#include<cassert>

class InParser {
private:
    FILE *fin;
    char *buff;
    int sp;

    char read_ch() {
        ++sp;
        if (sp == 4096) {
            sp = 0;
            fread(buff, 1, 4096, fin);
        }
        return buff[sp];
    }

public:
    InParser(const char *nume) {
        fin = fopen(nume, "r");
        buff = new char[4096]();
        sp = 4095;
    }

    InParser &operator>>(int &n) {
        char c;
        while (!isdigit(c = read_ch()) && c != '-');
        int sgn = 1;
        if (c == '-') {
            n = 0;
            sgn = -1;
        } else {
            n = c - '0';
        }
        while (isdigit(c = read_ch())) {
            n = 10 * n + c - '0';
        }
        n *= sgn;
        return *this;
    }


};

using namespace std;

const int mx = 1001459;
int table[mx];

int f(int x) {
    return x % mx;
}

void insert(int x) {
    int index = f(x);
    while (table[index] != 0) {
        index = (index + 1) % mx;
    }
    table[index] = x;
}


//Returns the index in the map where the element is placed, -1 if it does not exist.
int find(int x) {
    int index = f(x);
    while (table[index] != 0) {
        if (table[index] == x) {
            return index;
        }
        index = (index + 1) % mx;
    }
    return -1;
}

void erase(int x) {
    int here = find(x);
    if (here == -1) {
        return;
    }
    while (f(table[(here + 1) % mx]) != (here + 1) % mx) {
        table[here] = table[(here + 1) % mx];
        here = (here + 1) % mx;
    }
    table[here] = 0;
}


int main() {
    ifstream in("hashuri.in");
    ofstream out("hashuri.out");
    int n, a, b;
    in >> n;
    while (n--) {
        in >> a >> b;
        if (a == 1) {
            insert(b);
        } else if (a == 2) {
            erase(b);
        } else {
            if (find(b) == -1) {
                out << "0\n";
            } else {
                out << "1\n";
            }
        }
    }

    return 0;
}
