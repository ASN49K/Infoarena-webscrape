#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define N 1000000
#define K 666019
#define NIL -1

typedef struct
{
    int val, urm;
} element;

int lst[K], n_v;
element v[N];

void init_h()
{
    n_v = 0;
    for (int i = 0; i < K; i++)
    {
        lst[i] = NIL;
    }
}

int pozitie(int x, int categorie)
{
    for (int p = lst[categorie]; p != NIL; p = v[p].urm)
    {
        if (v[p].val == x)
        {
            return p;
        }
    }
    return NIL;
}

bool apartine(int x)
{
    int categorie = x % K;
    return (pozitie(x, categorie) != NIL);
}

void sterge(int x)
{
    int categorie = x % K;
    int p = pozitie(x, categorie);
    if (p == NIL)
    {
        return;
    }
    v[p].val = v[lst[categorie]].val;
    lst[categorie] = v[lst[categorie]].urm;
}

void adauga(int x)
{
    int categorie = x % K;
    if (pozitie(x, categorie) != NIL)
    {
        return;
    }
    v[n_v].val = x;
    v[n_v].urm = lst[categorie];
    lst[categorie] = n_v;
    n_v++;
}

int main()
{
    init_h();
    FILE *in, *out;
    in = fopen("hashuri.in", "r");
    out = fopen("hashuri.out", "w");
    int n;
    fscanf(in, "%d", &n);
    for (int i = 0; i < n; i++)
    {
        int tip, x;
        fscanf(in, "%d%d", &tip, &x);
        if (tip == 1)
        {
            adauga(x);
        }
        else if (tip == 2)
        {
            sterge(x);
        }
        else
        {
            fprintf(out, "%d\n", apartine(x));
        }
    }
    fclose(in);
    fclose(out);
    return 0;
}
