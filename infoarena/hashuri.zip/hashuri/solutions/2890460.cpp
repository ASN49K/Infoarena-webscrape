#include <iostream>
#include <fstream>
#include <unordered_map>
using namespace std;
unordered_map <int, int> lista;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
int main(){
    int n,nr=0;
    fin>>n;
    for(int i=0;i<n;i++)
    {
        int a,b;
        fin>>a>>b;
//        if(a==1){
//            lista[b]=nr++;
//        }
//        else if(a==2){
//            lista.erase(b);
//        }
//        else if (a==3){
//            if (lista.find(b)==lista.end())
//                fout<<0<<endl;
//            else fout<<1<<endl;
//        }
        switch(a) {

            case 1 :  lista[b]=nr++; break;

            case 2 :  lista.erase(b); break;

            case 3 : fout<< (lista.find(b)!=lista.end()) <<endl;

        };

    }
    fin.close();
    fout.close();
    return 0;

}