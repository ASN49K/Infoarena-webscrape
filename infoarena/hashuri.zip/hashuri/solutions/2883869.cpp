#include <fstream>
#include <map>
using namespace std;
ifstream fin("nr4.in");
ofstream fout("nr4.out");
int n,op,x;
map<int,int> M;
int main()
{
    fin >> n;
    for(int i=1;i<=n;i++)
    {
        fin >> op >> x;
        if(op==1)
        {
            if(M[x]==0) M[x]++;
        }
        else if(op==2)
        {
            if(M[x]!=0) M[x]--;
        }
        else
        {
            if(M[x]==1) fout << "1\n";
            else fout << "0\n";
        }
    }
    return 0;
}

