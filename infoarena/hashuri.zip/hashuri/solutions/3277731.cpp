#include <fstream>
#include <vector>

using namespace std;

ifstream cin("hashuri.in");
ofstream cout("hashuri.out");

const int MOD=999979;
const int BAZA=29;

int hashuri(int x)
{
    int galeata=0;
    long long put=1;

    while(x>0)
    {
        galeata=(galeata+((x%10)*put)%MOD)%MOD;
        x/=10;
        put*=BAZA;
    }

    return galeata;
}

vector <int> v[MOD+5];

int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        int op, nr;
        cin>>op>>nr;
        int g=hashuri(nr);
        if(op==1)
        {
            int ok=0;
            for(int j=0;j<v[g].size();j++)
                if(v[g][j]==nr)
                    ok=1;
            if(ok==0)
                v[g].push_back(nr);
        }
        if(op==2)
        {
            for(int j=0;j<v[g].size();j++)
                if(v[g][j]==nr)
                {
                    swap(v[g][j], v[g][v[g].size()-1]);
                    v[g].pop_back();
                }
        }
        if(op==3)
        {
            int ok=0;
            for(int j=0;j<v[g].size();j++)
                if(v[g][j]==nr)
                    ok=1;
            cout<<ok<<'\n';
        }
    }
    return 0;
}
