#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

class HashTable {
private:
	int size;
	std::vector<std::vector<char>> table;
	int disp;

	int _hash_function(char key) {
		return static_cast<int>(key) % disp;
	}
public:

	HashTable()
		: size(1000000), table(size, std::vector<char>()), disp(100003) {}

	void insert(char value) {
		int index = _hash_function(value);
		table[index].push_back(value);
	}

	void remove(char key) {
		int index = _hash_function(key);
		std::vector<char>& slot = table[index];
		for (int i = 0; i < slot.size(); i++) {
			if (slot[i] == key) {
				slot[i] = '*';
				return;
			}
		}
	}

	int search(char key) {
		int index = _hash_function(key);
		const std::vector<char>& slot = table[index];
		for (int k = 0; k < slot.size(); k++) {
			if (slot[k] == key && slot[k] != '*') {
				return 1;
			}
		}
		return 0;
	}

};


int main()
{
	HashTable hash_table;

	int n;
	f >> n;
	f.ignore();
	
	for (int i = 0; i < n; i++) {
		string line;
		getline(f, line);
		stringstream ss(line);

		int op;
		char key;

		if (ss >> op >> key) {


			if (op == 1) {
				hash_table.insert(key);
			}
			else if (op == 2) {
				hash_table.remove(key);
			}
			else if (op == 3) {
				g << hash_table.search(key) << '\n';
			}
		}
	}

	f.close();
	g.close();


	return 0;
}