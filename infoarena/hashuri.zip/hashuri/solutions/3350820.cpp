#include <stdio.h>

const int kMod = 1000003;

struct elem {
    int V;
    elem *next;
    elem() {
        V = -1;
        next = nullptr;
    }
}hash[kMod];

FILE *fin, *fout;
int n;

void add(int x) {
    elem *p = &hash[x % kMod];
    if((*p).V == x) return;
    while ((*p).next != nullptr) {
        p = (*p).next;
        if((*p).V == x) return;
    }
    (*p).next = new elem;
    (*((*p).next)).V = x;
}

void remove(int x) {
    elem *p = &hash[x % kMod];
    while ((*p).next != nullptr && (*(*p).next).V != x) {
        p = (*p).next;
    }
    if ((*p).next == nullptr) {
        return;
    }
    elem *q = (*p).next;
    (*p).next = (*q).next;
    delete q;
}

bool query(int x) {
    elem *p = &hash[x % kMod];
    while ((*p).next != nullptr && (*p).V != x) {
        p = (*p).next;
    }
    if ((*p).V != x) {
        return false;
    } else {
        return true;
    }
}

int main(void) {
    #ifdef LOCAL
    fin = stdin;
    fout = stdout;
    #else
    fin = fopen("hashuri.in", "r");
    fout = fopen("hashuri.out", "w");
    #endif

    fscanf(fin, "%d", &n);

    for(int i = 0; i < n; ++i) {
        int op, x;
        fscanf(fin, "%d%d", &op, &x);
        if(op == 1)
            add(x);
        else if(op == 2)
            remove(x);
        else
            fprintf(fout, "%d\n", query(x));
    }

    fclose(fin);
    fclose(fout);

    return 0;
}