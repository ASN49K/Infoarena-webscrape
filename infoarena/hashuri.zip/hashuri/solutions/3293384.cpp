#include <bits/stdc++.h>

using namespace std;
ifstream fin ("hashuri.in");
ofstream fout ("hashuri.out");
const int mod=666013;
vector<int>v[666013];
bool ffind(int n)
{
    int key=n%mod;
    for(int i=0; i<v[key].size(); i++)
        if(n==v[key][i])
            return 1;
    return 0;
}
void add(int n)
{
    if(ffind(n))
        return;
    int key=n%mod;
    v[key].push_back(n);
}
void del(int n)
{
    int key=n%mod;
    for(vector<int>::iterator it=v[key].begin(); it!=v[key].end(); it++)
        if(*it==n)
        {
            v[key].erase(it);
            break;
        }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr),cout.tie(nullptr);
    int n,x,y;
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        fin>>x>>y;
        if(x==1)
            add(y);
        else if(x==2)
            del(y);
        else fout<<ffind(y)<<'\n';
    }
    return 0;
}
