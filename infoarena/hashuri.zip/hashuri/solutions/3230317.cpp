#include <fstream>
#include <unordered_map>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
unordered_map<int,int> Fr;
int n,i,op,x;
int main()
{
    f>>n;
    for(i=0; i<n; i++)
    {
        f>>op>>x;
        if(op==1) Fr[x]++;
        else if(op==2&&Fr[x]) Fr[x]--;
        else if(op==3) g<<(Fr[x]!=0)<<"\n";
    }
    return 0;
}
