#include <bits/stdc++.h>

using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

int n,x,op;
unordered_map<int,int>f;

int main()
{
    in>>n;
    for(int i=1;i<=n;i++)
    {
        in>>op>>x;
        if(op==1)
            f[x]++;
        else if(op==2)
            f[x]=max(--f[x],0);
        else
            out<<f[x]%2<<'\n';
    }
    return 0;
}
