#include <fstream>
#include<unordered_map>

using namespace std;

ifstream cin("hashuri.in");
ofstream cout("hashuri.out");

unordered_map<int, int> M;


int main()
{
  int n;
  cin>>n;

  int op, x;
  for(int i=0; i<n; i++)
  {
    cin>>op>>x;

    if(op==1)
      M[x]=1;
    else if(op==2)
      M[x]=0;
    else
      cout<<M[x]<<"\n";
  }
  return 0;
}

