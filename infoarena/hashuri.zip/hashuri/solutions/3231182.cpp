#include<bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

class Hash
{
    int BUCKET;
    list<int> *table;
public:
    Hash(int V);
    void insertItem(int x);
    void deleteItem(int key);
    int hashFunction(int x)
    {
        return (x % BUCKET);
    }
    void displayHash();
    bool Find(int x)
    {
        int index = hashFunction(x);
        list<int>::iterator it;
        for (it = table[index].begin(); it != table[index].end(); ++it)
            if (*it == x) return true;
        return false;
    }
};

Hash::Hash(int b)
{
    this->BUCKET = b;
    table = new list<int>[BUCKET];
}

void Hash::insertItem(int key)
{
    int index = hashFunction(key);
    table[index].push_back(key);
}

void Hash::deleteItem(int key)
{
    int index = hashFunction(key);
    list <int> :: iterator i;
    for (i = table[index].begin(); i != table[index].end() && *i != key; i++)
        ;
    if (i != table[index].end()) table[index].erase(i);
}
void Hash::displayHash()
{
    for (int i = 0; i < BUCKET; i++)
    {
        fout << i;
        for (auto x : table[i])
            fout << " --> " << x;
        fout << "\n";
    }
}

int main()
{
    Hash A(1234577);
    int op, n, i, x;
    fin >> n;
    for(i=1; i<=n; i++)
    {
        fin >> op >> x;
        if(op == 1) A.insertItem(x);
        else if(op == 2) A.deleteItem(x);
        else fout << A.Find(x)  << "\n";
    }
    return 0;
}
