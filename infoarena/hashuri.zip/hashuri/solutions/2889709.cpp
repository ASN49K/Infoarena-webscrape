#include <iostream>
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

ifstream in("hashuri.in");
ofstream out("hashuri.out");

unordered_map <long long, bool> m;
int n, cerinta;
long long x;

int main()
{
    in>>n;
    for(int i=0; i<n; i++)
    {
        in>>cerinta>>x;
        if(cerinta==1 && (m.count(x)==0 || m[x]==0))
        {
            m[x]=1;
        }
        if(cerinta==2)
        {
            if(m[x]==1)
                m[x]=0;
        }
        if(cerinta==3)
        {
            if(m.count(x)==0 || m[x]==0)
                out<<0<<endl;
            else
                out<<1<<endl;
        }

    }

    return 0;
}
