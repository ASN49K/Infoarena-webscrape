#include <fstream>
#include <vector>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
vector<int> a[666013];

int main()
{
    int n,x,op,i,gasit;
    f>>n;
    for(i=1;i<=n;i++)
    {
        f>>op>>x;
        int pos = x%666013;
        if(op==1)
            {
                gasit=0;
                for(int j=0;j<a[pos].size();j++)
                {
                    if(x==a[pos][j])
                        gasit=1;
                }
                if(!gasit)
                    a[pos].push_back(x);
            }
        if(op==2)
                for(int j=0;j<a[pos].size();j++)
                {
                    if(x==a[pos][j])
                        a[pos][j]=-1;
                }
        if(op==3)
        {
            gasit=0;
                for(int j=0;j<a[pos].size();j++)
                {
                    if(x==a[pos][j])
                        gasit=1;
                }
                g<<gasit<<'\n';
        }
    }
    return 0;
}