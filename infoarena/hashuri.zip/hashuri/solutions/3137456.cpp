#include <iostream>
#include <vector>
#include <map>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include <queue>
#include <cmath>
#include <set>
#include <unordered_map>
#include <stack>
#include <iomanip>
#include <random>
#include <climits>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

const int MOD = 800001;

struct Node {
    long long value;
    Node *next;
};

Node *ListNode[MOD];

int hashValue(long long value) {
    return value % MOD;
}

int searchElement(long long value) {
    int index = hashValue(value);

    Node *currentHead = ListNode[index];
    while (currentHead != NULL) {
        if (currentHead->value == value) {
            return 1;
        }
        currentHead = currentHead->next;
    }

    return 0;
}

void insert(long long value) {
    if (searchElement(value) == 1) {
        return;
    }
    int index = hashValue(value);
    Node *newNode = new Node();
    newNode->value = value;
    newNode->next = ListNode[index];

    ListNode[index] = newNode;
}

void deleteElement(long long value) {
    int indexHash = hashValue(value);

    Node *currentHead = ListNode[indexHash];

    int index = 0, foundAt = -1;
    while (currentHead != NULL) {
        if (currentHead->value == value) {
            foundAt = index;
            break;
        }
        ++index;
        currentHead = currentHead->next;
    }
    if (foundAt == -1) {
        return;
    }

    if (foundAt == 0) {
        Node *deletedNode = ListNode[indexHash];
        ListNode[indexHash] = ListNode[indexHash]->next;

        delete deletedNode;
        return;
    }

    currentHead = ListNode[indexHash];
    for (int i = 0; i < foundAt - 1; ++i) {
        currentHead = currentHead->next;
    }

    Node *deletedNode = currentHead;
    currentHead->next = deletedNode->next;

    delete deletedNode;
}

int main() {
    int n;

    fin >> n;

    for (int i = 0; i < MOD; ++i) {
        ListNode[i] = NULL;
    }

    for (int i = 0; i < n; ++i) {
        int type;
        long long value;
        fin >> type >> value;

        if (type == 1) {
            insert(value);
        } else if (type == 2) {
            deleteElement(value);
        } else if (type == 3) {
            fout << searchElement(value);
            fout << "\n";
        }
    }

    return 0;
}