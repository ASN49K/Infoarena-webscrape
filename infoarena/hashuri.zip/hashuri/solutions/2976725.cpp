#include <bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

const int MOD = 967283;

vector<int> vec[MOD + 1];

int main()
{
    int n;
    fin >> n;

    int type, x;
    for (int i = 1; i <= n; i++)
    {
        fin >> type >> x;
        int hash = x % MOD;
        switch (type)
        {
        case 1:
            vec[hash].push_back(x);
            break;

        case 2:
            for (auto it = vec[hash].begin(); it != vec[hash].end(); it++)
                if (*it == x)
                    vec[hash].erase(it), it--;
            break;

        case 3:
            bool found = false;
            for (auto it = vec[hash].begin(); it != vec[hash].end(); it++)
                if (*it == x)
                {
                    found = true;
                    break;
                }

            if (found)
                fout << "1\n";
            else
                fout << "0\n";
            break;
        }
    }

    return 0;
}