#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

vector <int>h[66600];

int main()
{    ifstream f("hashuri.in");
     ofstream g("hashuri.out");
     int n, tip_op, elem, ok,ct,i,k,cst;
     cst=666013;
     f>>n;
    for(i=1;i<=n;i++)
    {
        f>>tip_op>>elem;

        if(tip_op==1)
        {   ct=elem%cst;
            ok=0;
            k=0;
            //verificam daca elementul citit este in multime
            while(k<h[ct].size())
               {
                  if(h[ct][k]==elem)
                {
                    ok=1;
                    break;
                }
                k++;
               }
            //daca elementul nu s-a gasit in multime, il adaugam in multime
            if(ok==0)
            {
                h[ct].push_back(elem);

            }

        }
        else

        if(tip_op==2)
        {   ct=elem%cst;
            k=0;
            //verificam daca elementul pe care dorim sa il stergem se gaseste in multime
            while(k<h[ct].size())
            {
                 if(h[ct][k]==elem)
                {

                    swap(h[ct][k],h[ct][h[ct].size()-1]);
                    h[ct].pop_back();
                    break;

                }
                k++;
            }

        }
        else
        if(tip_op==3)
        {   ct=elem%cst;
            ok=0;
            k=0;
            while(k<h[ct].size())
            {
                if(h[ct][k]==elem)
                {
                    ok=1;
                    break;
                }
                k++;
            }

            g<<ok<<"\n";
        }

    }

    return 0;
}



