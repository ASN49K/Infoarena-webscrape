#include <bits/stdc++.h>
using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");

int n, st, dr;
set<int> s;

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
    {
        fin >> st >> dr;
        if(st==1)
            s.insert(dr);
        else if(st==2)
        {
            if(s.find(dr)!=s.end())
                s.erase(dr);
        }
        else
        {
            if(s.find(dr)==s.end())
                fout << 0 << '\n';
            else
                fout << 1 << '\n';
        }
    }
    return 0;
}
