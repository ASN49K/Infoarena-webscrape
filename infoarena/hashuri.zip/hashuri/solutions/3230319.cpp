#include <bits/stdc++.h>
using namespace std;
ifstream f("hashuri.in");
ofstream g("hashuri.out");
#define mod 666013
vector <int> v[mod];
int c,x,m,k;
bool findx()
{
    int k=x%mod;
    for(auto a:v[k])
    {
        if(a==x) return 1;
    }
    return 0;
}
void inserare()
{
    int k=x%mod;
    v[k].push_back(x);
}
void stergere()
{
    int k=x%mod;
    vector <int> u;
    for(auto a:v[k])
    {
        if(a!=x) u.push_back(x);
    }
    v[k]=u;
}
int main()
{

    f>>m;
    for(int i=1;i<=m;++i)
    {
        f>>c>>x;
        k=i%mod;
        if(c==1) inserare();
        else if(c==2) stergere();
        else g<<findx()<<'\n';
    }
    return 0;
}
