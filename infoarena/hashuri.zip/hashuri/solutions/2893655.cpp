#include <iostream>
#include <vector>
#include <fstream>

using namespace std;
ifstream in("hashuri.in");
ofstream out("hashuri.out");

int n, p = 666013, i, x, op, hashedX, ok, j, vSize;
vector<vector<int>> hashMatrix(666013);  //avem cate o lista pentru fiecare rest de la 0 la p - 1

int main()
{
    in>>n;

    for(i = 1; i <= n; i++)
    {
        in>>op>>x;
        hashedX = x % p;

        if(op == 1)
        {
            hashMatrix[hashedX].push_back(x);
        }
        else if(op == 2)
        {
            vSize = hashMatrix[hashedX].size();
            for(j = 0; j < vSize; j++)
                if(hashMatrix[hashedX][j] == x)
                {
                    hashMatrix[hashedX][j] = hashMatrix[hashedX].back();
                    hashMatrix[hashedX].pop_back();
                    break;
                }

        }
        else
        {
            ok = 0;
            vSize = hashMatrix[hashedX].size();
            for(j = 0; j < vSize; j++)
                if(hashMatrix[hashedX][j] == x)
                {
                    ok = 1;
                    break;
                }

            out<<ok<<endl;
        }
    }


    return 0;
}
