#include <fstream>
#include <set>
using namespace std;

ifstream f("hashuri.in");
ofstream g("hashuri.out");

int n;
const int c = 666013;
set<long long>v[c];

int main(){
    f>>n;
    for (int i=1; i<=n; i++){
        int op, nr;
        f>>op>>nr;

        if (op == 1){
            v[nr % c].insert(nr);
        }
        else if (op == 2){
            if (v[nr % c].find(nr) != v[nr % c].end())
                v[nr % c].erase(nr);
        }
        else if (op == 3){
            if (v[nr % c].find(nr) != v[nr % c].end())
                g<<1<<"\n";
            else
                g<<0<<"\n";
        }
    }

    return 0;
}