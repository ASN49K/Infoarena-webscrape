#include <iostream>
#include <cmath>
#include <algorithm>
using namespace std;

struct Node;

const int MX = 1000001;
const int SPRS = 2000;
Node* hashmap[MX];
Node* srch{nullptr};
Node* aux{nullptr};

struct Node {
  int val;
  Node* next;
  
  Node(int val, Node* next) {
    this->val = val;
    this->next = next;
  }
};

void push(Node* &head, int val) {
  if (head == nullptr) {
    head = new Node(val, nullptr);
    return;
  }
  
  srch = new Node(-1, head);
  while (srch->next != nullptr) {
    srch = srch->next;
  }
  
  srch->next = new Node(val, nullptr);
};

bool isval(Node* &head, int val) {
  srch = new Node(-1, head);
  
  while (srch->next != nullptr) {
    if (srch->next->val == val) {
      return true;
    }
    
    srch = srch->next;
  }
  
  return false;
}

void ersval(Node* &head, int val) {
  srch = new Node(-1, head);
  
  while (srch->next != nullptr) {
    if (srch->next->val == val) {
      aux = srch->next;
      
      srch->next = srch->next->next;
      
      delete aux;
      return;
    }
    
    srch = srch->next;
  }
}

int main() {
    for (int i = 0; i < MX; i++) {
      hashmap[i] = nullptr;
    }
    
    int n;
    cin >> n;
    
    int op, v;
    int hashed = -1;
    for (int i = 0; i < n; i++) {
      cin >> op >> v;
      
      hashed = v / SPRS;
      if (op == 1) {
        if (!isval(hashmap[hashed], v)) {
          push(hashmap[hashed], v);
        }
      } else if (op == 2) {
        ersval(hashmap[hashed], v);
      } else if (op == 3) {
        if (isval(hashmap[hashed], v)) {
          cout << 1 << "\n";
        } else {
          cout << 0 << "\n";
        }
      }
    }
    
    return 0;
}
