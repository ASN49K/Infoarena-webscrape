#include <bits/stdc++.h>
using namespace std;
const int nmax = 62500;

int vf[nmax+5];

int main() {
    ifstream f("hashuri.in");
    ofstream g("hashuri.out");

    int n; f >> n;
    for(int i=1; i<=n; i++) {
        int type, x; f >> type >> x;
        int ind = x / 32;
        int bind = x % 32;
        if(type == 1 and (vf[ind] & (1<<bind)) == 0) vf[ind] += (1<<bind);
        else if(type == 2 and (vf[ind] & (1<<bind)) != 0) vf[ind] -= (1<<bind);
        else if(type == 3) {
            if((vf[ind] & (1<<bind))) g << "1\n";
            else g << "0\n";
        }
    }
    return 0;
}
