#include <bits/stdc++.h>

using namespace std;

#define MOD 666013

vector<int> h[MOD];

int find_poz( int x, int i ){
  int j;
  for( j = 0; j < h[i].size(); j++ ){
    if( h[i][j] == x )
      return j;
  }
  return h[i].size();
}

int main(){
    ifstream cin( "hashuri.in" );
    ofstream cout( "hashuri.out" );
    int n, i, op, x, poz;
    cin >> n;
    for( i = 0; i < n; i++ ){
      cin >> op >> x;
      if( op == 1 )
        h[x % MOD].push_back(x);
      else if( op == 2 ){
        poz = find_poz( x, x % MOD );
        if( poz != h[x % MOD].size() )
          h[x % MOD].erase(h[x % MOD].begin() + poz);
      }
      else{
        if( find_poz( x, x % MOD ) != h[x % MOD].size() )
          cout << "1\n";
        else
          cout << "0\n";
      }
    }
    return 0;
}
