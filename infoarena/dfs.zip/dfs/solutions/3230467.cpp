#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("bac.in");
ofstream fout("zapada.out");

struct nod 
{
    int info;
    nod* urm;
} *G[105];

void citire(nod*& p)
{
    nod* q = new nod, * u = NULL;
    fin >> p->info;
    u = p;

    int nr;
    while (fin >> nr)
    {
        q = new nod;
        q->info = nr;
        q->urm = NULL;

        u->urm = q;
        u = q;
    }
}

void afis(nod* p)
{
    while (p)
    {
        cout << p->info << " ";
        p = p->urm;
    }
}

bool sel[105];

void Dfs(int x)
{
    sel[x] = true;
    for (nod* p = G[x]; p; p = p->urm)
    {
        if (!sel[p->info])
            Dfs(p->info);
    }
}


int main()
{
    int n, m;
    fin >> n >> m;
    int a, b;
    for (int i = 1; i <= m; i++)
    {
        fin >> a >> b;
        nod* p = new nod;
        p->info = b;
        p->urm = G[a];
        G[a] = p;

        p = new nod;
        p->info = a;
        p->urm = G[b];
        G[b] = p;
    }

    int result = 0;
    for (int i = 1; i <= n; i++)
    {
        if (!sel[i])
        {
            result++;
            Dfs(i);
        }
    }

    cout << result;

    
    return 0;
}