#include <fstream>
#include <vector>
#define NMAX 102

using namespace std;

ifstream fin("componenteconexe.in");
ofstream fout("componenteconexe.out");

//graf reprezentat prin liste de adiacenta alocate dinamic cu vector din STL
int n,nrc;
vector<int>A[NMAX];///memoria devine N+M 300 000
//A[x] va fi un vector din stl care retine lista de adiacenta a lui x

int viz[NMAX];

void citire();
void dfs(int x);
void afisare();

int main()
{
    int i;
    citire();
    for(i=1; i<=n; i++)
    {
        if(!viz[i])
        {
            nrc++;
            dfs(i);
        }
    }
    afisare();
    return 0;
}

void citire()
{
    int m,i,x,y;
    fin>>n;
    while(fin>>x>>y)
    {
        //varful y este adaugat la lista de adiacenta a lui x
        A[x].push_back(y);
        //varful x este adaugat la lista de adiacenta a lui y
        A[y].push_back(x);

    }
}
void dfs(int x)
{
    int i;
    viz[x]=nrc;
    //parcurg vecini lui x
    for(i=0; i<A[x].size(); i++)
    {
        if(!viz[A[x][i]])
            dfs(A[x][i]);
    }
}

void afisare()
{
    int i,j;
    fout<<nrc<<'\n';
    /*for(i=1; i<=nrc; i++)
    {
        for(j=1; j<=n; j++)
        {
            if(viz[j]==i)
            {
                fout<<j<<' ';
            }
        }
        fout<<'\n';
    }*/
}
