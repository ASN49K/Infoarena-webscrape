#include <bits/stdc++.h>

#define N_MAX 100005

using namespace std;

ifstream fin("dfs.in");

ofstream fout("dfs.out");

int n, m;

vector<int> l[N_MAX];

bool viz[N_MAX];
void dfs(int nod)
{
    viz[nod]=true;
    for(auto it:l[nod])
    {
        if(!viz[it])
        dfs(it);
    }
}
int main()
{
    fin >> n >> m;
    while (m--)
    {
        int x, y;
        fin >> x >> y;
        l[x].push_back(y);
        l[y].push_back(x);
    }
    int sol=0;
    for(int i=1;i<=n;i++)
    if(!viz[i])
    {dfs(i);
sol++;
}
fout<<sol;
}