#include <iostream>
#include <fstream>
#include <unordered_set>
using namespace std;

#ifdef LOCAL
#define fin cin
#define fout cout
#else
ifstream fin("dfs.in");
ofstream fout("dfs.out");
#endif

unordered_set<int> adj[100001];
bool vizitat[100001];

void dfs(int nod) {
    if (vizitat[nod]) return;
    vizitat[nod] = 1;
    for (auto vecin:adj[nod]) dfs(vecin);
}

int main() {
    int n, m, x, y, cnt=0;
    fin >> n >> m;
    while (m--) {
        fin >> x >> y;
        adj[x].insert(y);
        adj[y].insert(x);
    }
    for (int i=1; i<=n; i++)
        if (!vizitat[i])
            dfs(i), cnt++;
    fout << cnt;
}
