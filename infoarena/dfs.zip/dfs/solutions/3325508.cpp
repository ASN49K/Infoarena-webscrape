/*#include <fstream>
#include <vector>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<vector<int>> G;
vector <int> s;
int viz[200000];
void dfs(int i) {
    s.push_back(i);
    int st = 0, dr = 0;
    viz[i] = 1;
    while(dr - st >= 0)
    {
        int nod = s[st++];
        for(int vecin : G[i])
        {
            if(!viz[vecin])
                viz[vecin] = 1;
            s.push_back(vecin);
        }

    }
}

int main() {

    int n, m;
    fin >> n >> m;
    G.resize(n + 1);
    for (int i = 1; i <= m; i++) {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    int sol = 0;
    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            sol++;
            dfs(i);
        }
    }
    fout << sol;
    return 0;
}
*/
#include <fstream>
#include <vector>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<vector<int>> G;
int viz[200000];
void dfs(int i) {
    viz[i] = true;
    for (int x : G[i]) {
        if (!viz[x])
            dfs(x);
    }
}

int main() {

    int n, m;
    fin >> n >> m;
    G.resize(n + 1);
    for (int i = 1; i <= m; i++) {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    int sol = 0;
    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            sol++;
            dfs(i);
        }
    }
    fout << sol;
    return 0;
}
