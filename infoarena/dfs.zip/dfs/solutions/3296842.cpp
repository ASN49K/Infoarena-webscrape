#include <bits/stdc++.h>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m;
vector<int> v[100005];
bool visited[100005];


void DFS(int node) {
    if (!visited[node]) {
        visited[node] = true;
        for (auto urm : v[node]) {
            if (!visited[urm]) {
                DFS(urm);
            }
        }
    }
}



int main() {
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);

    fin >> n >> m;
    int a, b;
    for (int i = 0; i < m; i++) {
        fin >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }

    int ct = 0;
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            DFS(i);
            ct++;
        }
    }

    fout << ct << '\n';
    return 0;
}