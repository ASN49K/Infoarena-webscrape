#include <bits/stdc++.h>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
bool fr[500100];
vector<int> v[500100];
void dfs(int nod)
{
    fr[nod]=1;
    for(auto i:v[nod])
        if(fr[i]==0)
            dfs(i);
}

int n, m ,nr,x,y;
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;++i)
    {
        fin>>x>>y;
        v[x].push_back(y);
    }

    for(int i=1;i<=n;++i)
        if(fr[i]==0)
        {
            dfs(i);
            ++nr;
        }

    fout<<nr;

    return 0;
}
