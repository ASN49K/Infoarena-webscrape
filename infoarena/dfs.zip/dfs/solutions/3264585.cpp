#include <bits/stdc++.h>
#define nmax 100005
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n,m,nrc;
vector<int>L[nmax];
int viz[nmax];
void dfs(int pas)
{
    viz[pas]=nrc;
    for(auto i:L[pas])
        if(viz[i]==0)
            dfs(i);
}
int main()
{
    fin>>n>>m;
    while(m--)
    {
        int x,y;
        fin>>x>>y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(viz[i]==0)
        {
            nrc++;
            dfs(i);
        }
    fout<<nrc;
    return 0;
}
