#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<vector<int>>G;

int vis[10005];

void DFS (int NOD){
    vis[NOD]= true;
    for(int i = 0;i<G[NOD].size();i++){
            int vec = G[NOD][i];
            if(vis[vec]==false){
                DFS(vec);
            }
    }
}

int main()
{
    int n, m;
    fin >> n >> m;
    G.resize(n+1);
    for(int i = 1;i<=m;i++){
        int a, b;
        fin >> a >> b;
        G[a].push_back(b);
        G[b].push_back(a);
    }
    int cnt = 0;
    for(int i = 1;i<=n;i++){
        if(vis[i]==false){
            DFS(i);
            cnt++;
        }
    }

    fout << cnt;

    return 0;
}
