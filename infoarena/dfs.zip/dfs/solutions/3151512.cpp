#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

queue<int> q;
vector<int> G[100002];
int viz[100002];

void connect(int x)
{
    q.push(x);
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        if(viz[nod])continue;
        viz[nod]=1;
        for(int i=0;i<G[nod].size();i++)
            q.push(G[nod][i]);
    }

}


int main()
{
    ifstream fin("dfs.in");
    ofstream fout("dfs.out");
    int n,m,i,nr=0;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);


    }

    for(i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            connect(i);
            nr++;
        }
    }
    fout<<nr;

    return 0;
}
