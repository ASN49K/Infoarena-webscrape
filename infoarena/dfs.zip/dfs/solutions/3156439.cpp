#include<iostream> 
#include<vector>
#include<fstream> 
using namespace std;
const int NMAX = 10e5;
vector<int> G[NMAX];
int vis[NMAX + 1];

void DFS(int x) { 
    cout << x << " ";
    vis[x] = 1;
    for(auto next: G[x]) { 
        if(!vis[next])
        DFS(next);
    }
}
int main() { 
    int n, m; 
    cin >> n >> m;
    for(int i = 1; i <= m; i++) {
        int x, y;
        cin >> x >> y; 
        G[x].push_back(y); 
        G[y].push_back(x);
    }
    int cc = 0; 
    for(int i = 0; i <= n; i++) { 
        if(!vis[i]) { 
            cc++; 
            DFS(i);
        }
    }
cout << cc;

}
