#include <bits/stdc++.h>

using namespace std;

ifstream in("dfs.in");
ofstream out("dfs.out");

int n, m;
vector<vector<int>> a;
vector<int> v;

void dfs(int k)
{
    v[k] = 1;
    for(int i = 1 ; i <= n; i++)
    {
        if(a[i][k] == 1 && v[i] == 0)
        {
            dfs(i);
        }
    }
}

int main()
{
    in >> n >> m;
    a.resize(n + 1);
    for(int i = 1; i <= n ; i ++)
    {
        a[i].resize(n + 1);
    }
    v.resize(n + 1);
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        in >> x >> y;
        a[x][y] = a[y][x] = 1;
    }
    int cnt = 0;
    for(int i = 1 ; i <= n; i++)
    {
        if(v[i] == 0)
        {
            dfs(i);
            cnt ++;
        }
    }
    out << cnt;
    return 0;
}
