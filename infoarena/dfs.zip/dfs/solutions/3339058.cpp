#include <bits/stdc++.h>
using namespace std;

bitset<100000> viz;
vector<int> adj[100000];

void dfs(int c) {
    viz[c] = true;
    for(auto& i : adj[c]) {
        if(!viz[i]) {
            dfs(i);
        }
    }
}

signed main() {
    cin.tie(nullptr)->sync_with_stdio(false);
#ifndef LOCAL
    freopen("dfs.in", "r", stdin);
    freopen("dfs.out", "w", stdout);
#endif

    int n, m; cin >> n >> m;
    for(int i = 0; i < m; ++i) {
        int x, y; cin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    int cnt = 0;
    for(int i = 1; i <= n; ++i) {
        if(!viz[i]) {
            dfs(i);
            ++cnt;
        }
    }

    cout << cnt;

    return 0;
}