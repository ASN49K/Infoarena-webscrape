#include<bits/stdc++.h>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int MAX = 1e5 + 5;
int n, m, cnt;
vector<int> G[MAX];
bitset<MAX> viz;

void dfs(int node){
    viz[node] = true;
    for(int x : G[node])
        if(!viz[x])
            dfs(x);
}

int main(){
    fin >> n >> m;

    for(;m--;){
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    for(int i = 1; i <= n; ++i)
    if(!viz[i]){
        ++cnt;
        dfs(i);
    }

    fout << cnt;
}
