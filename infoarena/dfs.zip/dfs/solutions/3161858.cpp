#include <iostream>
#include <vector>
#include <cstdio>

using namespace std;

vector<int> edges[100005];
bool visited[100005];

int dfs (int nod)
{
    visited[nod] = 1;
    for (auto u: edges[nod])
        if (!visited[u])
            dfs(u);
}

int main(int argc, char const *argv[])
{
    freopen("dfs.in", "r", stdin);
    freopen("dfs.out", "w", stdout);
    int conex = 0;
    int n, m;
    cin >> n >> m;
    while (m--)
    {
        int x, y;
        cin >> x >> y;
        edges[x].push_back(y);
        edges[y].push_back(x);
    }

    for (int nod = 1; nod <= n; nod++)
    {
        if (!visited[nod])
        {
            conex++;
            dfs(nod);
        }
    }

    cout << conex;
    return 0;
}