#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
int f[100005];
vector <int> g[100005];
void dfs(int poz)
{
    if(f[poz])
        return;
    f[poz]=1;
        int n=g[poz].size();
    for(int i=0;i<n;i++)
    {
        dfs(g[poz][i]);
    }
}
int main()
{
    ifstream cin("dfs.in");
    ofstream cout("dfs.out");
    int n,m;
    cin>>n>>m;

    for(int i=0;i<m;i++)
    {
        int x,y;
        cin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    int s=0;
    for(int i=1;i<=n;i++)
    {
        if(!f[i])
        {
            s++;
            dfs(i);
        }
    }
    cout<<s;
    return 0;
}
