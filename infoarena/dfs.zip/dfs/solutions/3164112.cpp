#include <bits/stdc++.h>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<vector<int> > ad;
vector<int> ap;

void DFS(int ind)
{
    if(ap[ind] == 1)
        return;
    ap[ind] = 1;
    for(int i = 0; i < ad[ind].size(); i++)
        DFS(ad[ind][i]);
}

int main()
{
    int n, m;
    fin >> n >> m;
    ad.resize(n+1);
    ap.resize(n+1, 0);
    for(int i = 0; i < m; i++)
    {
        int x, y;
        fin >> x >> y;
        ad[x].push_back(y);
        ad[y].push_back(x);
    }
    int nr = 0;
    for(int i = 1; i <= n; i++)
    {
        if(!ap[i])
        {
            DFS(i);
            nr++;
        }
    }
    fout << nr;
    return 0;
}
