#include <fstream>
#include <vector>
#define NMAX 100002

using namespace std;
ifstream fin ("dfs.in");
ofstream fout("dfs.out");

int n, nrc;

//vector<int> A;
//am declarat un vector din STL cu 0 elem de tip int numit A

vector<int> A[NMAX];
//am declarat un vector cu NMAX elem
//de tip STL cu 0 elem de tip int numit A
bool viz[NMAX]; //viz[x]=1 daca a fost vizitat

void citire();
void afisare_lad();
void dfs (int x);

int main()
{
    int i;
    citire();
    for (i=1; i<=n; i++)
        if (viz[i]==0)
        {
            nrc++;
            dfs(i);
        }
    fout<<nrc<<'\n';
    return 0;
}

void citire()
{
    int i, m, x, y;
    fin>>n>>m;
    for (i=0; i<m; i++)
    {
        fin>>x>>y;
        //adaug pe y in lista de adiacenta a lui x
        A[x].push_back(y);
        //doar pt neorientate adaug si pe x in lad a lui y
        A[y].push_back(x);
    }
}

void dfs (int x)
{
    int i;
    //parcurg graful incepand din varful x
    viz[x]=1;
    //parcurg vecinii lui x
    for (i=0; i<A[x].size(); i++)
        if (!viz[A[x][i]]) //exista muchia [x, A[x][i]]/(x, A[x][i]) si A[x][i] nevizitat
            dfs(A[x][i]);
}
