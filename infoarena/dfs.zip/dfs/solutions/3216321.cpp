#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n,m;
vector<int> L[100005];
bool viz[100005];
void dfs(int node)
{
    viz[node]=true;
    for(auto vec:L[node])
    {
        if(viz[vec]==false)
        {
            dfs(vec);
        }
    }
}

int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    int nr=0;
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==false)
        {
            dfs(i);
            nr++;
        }
    }
    fout<<nr;
    return 0;
}
