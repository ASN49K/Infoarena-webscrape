#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int NMAX = 100005;

vector <int> g[NMAX];

bool viz[NMAX];

int cc;

void DFS(int node){
    viz[node] = cc;
    for(int j = 0; j < g[node].size(); ++j){
        int to = g[node][j];
        if(!viz[to]){
            viz[to] = cc;
            DFS(to);
        }
    }
}

void solve(){
    int n, m;
    fin >> n >> m;
    for(int i = 1; i <= m; ++i){
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    for(int i = 1; i <= n; ++i){
        if(!viz[i]){
            cc ++;
            DFS(i);
        }
    }
    fout << cc;
}

int main()
{
    solve();
    return 0;
}
