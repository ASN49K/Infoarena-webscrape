#pragma GCC optimize("Ofast,inline,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
#include <bits/stdc++.h>
#include <nmmintrin.h>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int t[100002];
int h[100002];
int findr(int x){
    int r = x;
    while(r != t[r]) r = t[r];
    while(x != r){
        int d = t[x];
        t[x] = r;
        x = d;
    }
    return r;
}
void dsu(int x, int y){
    int rx = findr(x), ry = findr(y);
    if(h[rx] > h[ry]) t[ry] = rx;
    else{
        t[rx] = ry;
        if(h[rx] == h[ry]) h[ry]++;
    }
}
int main()
{
    int n,m,i,u,v,k = 0;
    fin >> n >> m;
    for(i = 1; i <= n; i++) t[i] = i;
    for(i = 1; i <= m; i++){
        fin >> u >> v;
        if(findr(u) != findr(v)) dsu(u,v);
    }
    for(i = 1; i <= n; i++) if(t[i] == i) k++;
    fout << k;
    return 0;
}
