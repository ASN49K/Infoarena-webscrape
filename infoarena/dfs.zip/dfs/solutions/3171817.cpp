#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

int v[100005];
vector<vector <int> > p;

void dfs(int n)
{
    v[n]=1;

    for(int i=0;i< p[n].size(); i++)
    {
        if(v[p[n][i]]==0)
        {
            dfs(p[n][i]);
        }
    }


}


int main()
{

    int n, m;
    f>>n>>m;
    int x, y;


    p.resize(n+1);

    for(int i=0;i < m; i++)
    {
        f>>x>>y;
        p[x].push_back(y);
        p[y].push_back(x);

    }
    int co=0;
    for(int i=1; i< n+1; i++)
    {

        if(v[i]==0)
        {
            dfs(i);
            co++;
        }

    }
    g<<co;


}
