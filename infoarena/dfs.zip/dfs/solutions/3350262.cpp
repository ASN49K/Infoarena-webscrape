#include <bits/stdc++.h>
#define pi pair<int,int>
using namespace std;

ifstream fin ("dfs.in") ;
ofstream fout ("dfs.out") ;

vector < int > g[100005] ;
bool sel[100005] ;

void dfs ( int nod )
{
    sel[nod] = 1 ;
    for ( auto it : g[nod] )
        if ( sel[it] == 0 )
            dfs ( it ) ;
}

void solve ()
{
    int n , m , k ;
    fin >> n >> m ;
    for ( int i = 1 ; i <= m ; i ++ )
    {
        int x , y ;
        fin >> x >> y ;
        g[x].push_back(y) ;
        g[y].push_back(x) ;
    }

    int cnt = 0 ;

    for ( int i = 1 ; i <= n ; i ++ )
        if ( ! sel[i] )
        {
            cnt ++ ;
            dfs ( i ) ;
        }

    fout << cnt ;
}

int main()
{
    std :: ios_base :: sync_with_stdio ( false ) ;
    fin.tie(0) ;
    fout.tie(0) ;
    solve() ;

    return 0;
}
