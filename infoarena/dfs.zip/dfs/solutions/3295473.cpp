#include <iostream>
#include <vector>

using namespace std;

void dfs(int node, vector<vector<int> > adj, vector<int> &parent) {
    for(int neigh : adj[node]) {
        if(parent[neigh] == 0) {
            parent[neigh] = node;
            dfs(neigh, adj, parent);
        }
    }
}

int main() {

    int n, m;
    cin >> n >> m;

    vector<vector<int> > adj(n + 1);
    for(int i = 0; i < m; i++) {
        int x, y;
        cin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    vector<int> parent(n + 1, 0);
    int num_components = 0;

    for (int i = 1; i <= n; i ++) {
        if (parent[i] == 0) {
            num_components ++;
            dfs(i, adj, parent);
        }
    }

    cout << num_components;

    return 0;

}