#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int n,m;

ifstream f("DFS.in");
ofstream g("DFS.out");

vector<vector<int>> lista;
vector<bool> verif;

void dfs(int nod)
{
   if(verif[nod])return;
   verif[nod] = true;
   for(auto vecin: lista[nod])
   {
       dfs(vecin);
   }
}

int main()
{
   int x,y;
   f >> n >> m;
   lista.resize(n+1,{});
   verif.resize(n+1, false);
   while(f >> x >> y)
   {
       lista[x].push_back(y);
       lista[y].push_back(x);
   }

   int nrComp = 0;
   for(int i = 1; i<=n; i++)
   {
       if(!verif[i])
       {
           nrComp++;
           dfs(i);
       }
   }

   g << nrComp;

   f.close();
   g.close();

   return 0;
}