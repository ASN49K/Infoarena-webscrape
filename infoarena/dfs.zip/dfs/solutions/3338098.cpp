#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int N, M;
int f[100001];
vector<int>g[100001];

void dfs(int node){
  f[node]=1;
  for(int i=0; i<g[node].size(); i++){
  int newnode=g[node][i];
  if(f[newnode]==0)
    dfs(newnode);
  }
}
int main()
{
  fin>>N>>M;
  int x,y;
  for(int i=1; i<=M; i++){
    fin>>x>>y;
    g[x].push_back(y);
    g[y].push_back(x);
  }
  int c=0;
  for(int i=1; i<=N; i++){
    if(f[i]==0){
      c++;
      dfs(i);
    }
  }
  fout<<c;
  return 0;
}


