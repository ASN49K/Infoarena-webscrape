#include <bits/stdc++.h>
using namespace std;
ifstream fin ("dfs.in");
ofstream fout ("dfs.out");

vector <int> g[100001];
bool viz[100001];
int n, m;

void dfs(int sursa)
{
    viz[sursa] = true;
    for (auto vecin : g[sursa])
        if (!viz[vecin])
        {
            viz[vecin] = true;
            dfs(vecin);
        }
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }

    int componente = 0;
    for (int i = 1; i <= n; i++)
        if (!viz[i])
        {
            dfs(i);
            componente++;
        }

    fout << componente;
    return 0;
}
