﻿#include <fstream>
#include <vector>

using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

vector<int> a[100005];
bool f[100005];
int n, m, componente;

void dfs(int nod)
{
	f[nod] = true;
	for (int i = 0; i < a[nod].size(); i++)
	{
		if (f[a[nod][i]] == false)
		{
			dfs(a[nod][i]);
		}
	}
}

int main()
{
	cin >> n >> m;
	for (int i = 1; i <= m; i++)
	{
		int x, y;
		cin >> x >> y;
		a[x].push_back(y);
		a[y].push_back(x);
	}
	for (int i = 1; i <= n; i++)
	{
		if (f[i] == false)
		{
			componente++;
			dfs(i);
		}
	}
	cout << componente;
}