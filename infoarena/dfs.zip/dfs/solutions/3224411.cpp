#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

#define NODES 100000

int VIZ[NODES];
vector <int> Edges[NODES];

void dfs(int node,int component){
    VIZ[node]=component;
    for(auto neighbour:Edges[node]){
        if(VIZ[neighbour]==0){
            dfs(neighbour,component);
        }
    }
}


int main(){
    int n,m;
    fin>>n>>m;
    for(int i=0;i<m;i++){
        int x,y;
        fin>>x>>y;

        Edges[x].push_back(y);
        Edges[y].push_back(x);
    }
    int el_connex=0;

    for(int i=1;i<=n;i++){
        if(VIZ[i]==0){
            el_connex++;
            dfs(i,el_connex);
        }
    }

    fout<<el_connex;

}