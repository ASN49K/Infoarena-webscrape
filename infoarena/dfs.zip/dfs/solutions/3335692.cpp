#include <bits/stdc++.h>
#define oo 2000000
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<int> g[100001];
int viz[100001];
int n, m, nrcc;

void Citire()
{
    int i, j, p;
    fin >> n >> m;
    for (p = 1; p <= m; p++)
    {
        fin >> i >> j;
        g[i].push_back(j);
        g[j].push_back(i);
    }
}

void DFS(int k)
{
    viz[k] = 1;
    for (int i : g[k])
        if (viz[i] == 0) DFS(i);
}

void Afis()
{
    for (int i = 1; i <= n; i++)
        if (viz[i] == 0){
            nrcc++;
            DFS(i);
        }
    fout << nrcc << "\n";
}

int main()
{
    Citire();
    Afis();
    return 0;
}
