#include <bits/stdc++.h>
#define ll long long
#define pb push_back
#define F first
#define S second
#define endl '\n'
#define all(a) (a).begin(),(a).end()
using namespace std;
const int maxn=1e5+5;
const ll mod = 1999999973;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

void dfs(int v, const vector<vector<int>>& adj, vector<int>& vis) {
    vis[v] = 1;
    for (auto u : adj[v]) {
        if (!vis[u]) {
            dfs(u, adj, vis);
        }
    }
}

void solve() {
    int n, m;
    fin >> n >> m;
    vector<vector<int>> adj(n, vector<int>());
    while (m--) {
        int x, y;
        fin >> x >> y;
        x--;
        y--;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    int counter = 0;
    vector<int> vis(n, 0);
    for (int i = 0; i < n; i++) {
        if (!vis[i]) {
            dfs(i, adj, vis);
            counter++;
        }
    }
    fout << counter << endl;
}

int main() {
    int t = 1;
    //cin >> t;
    while (t--) {
        solve();
    }
}
