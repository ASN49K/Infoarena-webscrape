#include <bits/stdc++.h>
using namespace std;
ifstream fin ("dfs.in");
ofstream fout("dfs.out");
const int dim = 100002;
vector<int> a[dim];
bool viz[dim];

/*
    for (int j = 0; j < a[x].size(); j++)
    {
        y = a[x][j];
        if(viz[y] == 0)
            dfs(y);
    }
*/

void dfs(int x)
{
    viz[x] = 1;
    for (int y : a[x]) ///enhaced-for
        if(viz[y] == 0)
            dfs(y);

}

int main()
{
    int n, m, x, y;
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }

    int nr_comp = 0;
    for (int i = 1; i <= n; i++)
        if (viz[i] == 0)
        {
            nr_comp++;
            dfs(i);
        }

    fout << nr_comp;
    return 0;
}
