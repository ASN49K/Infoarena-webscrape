#include <iostream>
#include <fstream>
#include <vector>
#include <list>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<vector<int>> lists(100001);
vector<bool> visited(100001, false);
void dfs(int s){
    visited[s] = true;
    for (int vecin : lists[s]){
        if (!visited[vecin]){
            // visited[vecin] = true;
            dfs(vecin);
        }
    }
}

int main(){
    int n, m;
    fin >> n >> m;

    int x, y;
    while (fin >> x >> y){
        lists[x].push_back(y);
        lists[y].push_back(x);
    }

    int cnt;
    for (int i = 1; i <= n; ++i){
        if (visited[i]){
            continue;
        }

        // dfs din nodul i
        dfs(i);
        cnt++;
    }
    fout << cnt;

    return 0;
}