#include<iostream>
#include<fstream>
#include<algorithm>
#include<vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
vector<vector<int>>graf;
bool vis[1005];
int cnt=0;
void DFS(int nod){
    vis[nod]=true;
    cnt++;
    for(int vec:graf[nod]){
        if(!vis[vec]){
            DFS(vec);
        }
    }
}
int main()
{
    int n,m;
    fin>>n>>m;
    graf.resize(n+1);
    for(int i=0;i<m;i++){
        int nod1,nod2;
        fin>>nod1>>nod2;
    }
    for(int i=1;i<=m;i++){
        DFS(i);
    }
    fout<<cnt;
}
