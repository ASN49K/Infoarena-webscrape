#include <iostream>
#include <fstream>
#include <vector>
std::ifstream in("dfs.in");
std::ofstream out("dfs.out");

const int NMAX = 100000;
int vis[NMAX + 1];
std::vector<int> la[NMAX + 1];

void DFS(int nod) {
    vis[nod] = 1;
    for(int x : la[nod]) {
        if(vis[x] == 0) DFS(x);
    }
}

int main() {
    int n, m, x, y, nr = 0; 
    in >> n >> m;
    for(int i = 0; i < m; i++) {
        in >> x >> y;
        la[x].push_back(y);
        la[y].push_back(x);
    }
    for(int i = 1; i <= n; i++)
    {
        if(vis[i] == 0) {
            nr++;
            DFS(x);
        }
    }
    out << nr;
    return 0;
}