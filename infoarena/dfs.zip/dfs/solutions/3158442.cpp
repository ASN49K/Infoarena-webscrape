#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;
ifstream in("dfs.in");
ofstream out("dfs.out");

int timp = 0;
int viz[100005];
vector<int>ls[100005];
void dfs(vector<int>ls[], int s) {
	viz[s] = 1;
	
	for (int x : ls[s]) {
		if (viz[x] == 0) {
			dfs(ls,x);
		}
		
	}
	

}


int main() {
	int n, m;
	in >> n >> m;
	int contor = 0;
	while (m--) {
		int a, b;
		in >> a >> b;
		ls[a].push_back(b);
		ls[b].push_back(a);
	}
	
	for (int i = 1; i <=n; i++)
	{
		if (viz[i] == 0)
		{
			dfs( ls,i);
			contor++;
		}
	}
	out << contor;
	return 0;
}