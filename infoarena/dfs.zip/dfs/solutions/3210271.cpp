#include <fstream>
#include <vector>

using namespace std;

const int N = 1e5;

vector <int> a[N+1];
bool viz[N+1];

void dfs(int x)
{
    viz[x] = 1;
    for (auto y: a[x])
    {
        if (!viz[y])
        {
            dfs(y);
        }
    }
}

int main()
{
    ifstream in("dfs.in");
    ofstream out("dfs.out");
    int n, m;
    in >> n >> m;
    for (int i = 0; i < m; i++)
    {
        int x, y;
        in >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    int nr_comp = 0;
    for (int i = 1; i <= n; i++)
    {
        if (!viz[i])///i nu face parte inca din nicio comp. conexa
        {
            nr_comp++;
            dfs(i);
        }
    }
    out << nr_comp << "\n";
    in.close();
    out.close();
    return 0;
}
