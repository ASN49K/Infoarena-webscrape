#include <bits/stdc++.h>
using namespace std;
int n, m, v[100005], a[10000][10000];
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int x,y;
void dfs(int start)
{
    stack <int> s;
    s.push(start);
    while(!s.empty())
    {
        int nod_curent=s.top();
        bool gasit=false;
        for(int i=1;i<=n;i++)
        {
            if(v[i]==0 && a[nod_curent][i]==1)
            {
                gasit=true;
                s.push(i);
                v[i]=1;
                break;
            }
        }
        if(!gasit)
            s.pop();
    }
}
int main()
{
    int cnt=0;
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
       fin>>x>>y;
       a[x][y]=1;
       a[y][x]=1;
    }

    for(int i=1;i<=n;i++)
    {
        if(v[i]==0)
        {
            cnt++;
            dfs(i);
        }
    }
    fout<<cnt;
    return 0;
}
