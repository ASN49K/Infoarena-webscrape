#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
bool f[100001];

struct nod
{
    int info;
    nod *urm;
} *v[100005];


void add(int x,int y)
{
     nod *p;
     p=new nod;
     p->info=y;
     p->urm=v[x]->urm;
     v[x]->urm=p;
}

void DFS(int x)
{
    f[x]=1;
    for(nod *p=v[x]->urm;p!=NULL;p=p->urm)
        if(!f[p->info]) DFS(p->info);
}

int main()
{
    int n,m,x,y,i,k=0;
    fin>>n>>m;
    for(i=1;i<=n;++i)
    {
        v[i]=new nod; v[i]->urm=NULL;
    }

    for(i=1;i<=m;++i)
    {
        fin>>x>>y;
        add(x,y);
        add(y,x);
    }

    for(i=1;i<=n;++i)
      if(!f[i]) {++k; DFS(i);}

    fout<<k;
    return 0;
}
