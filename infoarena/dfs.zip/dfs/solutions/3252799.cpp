#include <fstream>
#include <vector>
#include <climits>

using namespace std ;

ifstream cin ("dfs.in") ;
ofstream cout ("dfs.out") ;

int n, m, ans ;
vector < int > v[100005] ;
bool visited[100005] ;

void dfs (int node)
{

    visited[node] = true ;
    ans ++ ;

    for (auto item : v[node])
        if (!visited[item])
            dfs (item) ;

}

int main()
{

    int x, y ;

    cin >> n >> m ;

    for (int i = 1 ; i <= m ; i ++)
        cin >> x >> y, v[x].push_back (y), v[y].push_back (x) ;

    dfs (1) ;

    cout << ans ;

    return 0 ;

}
