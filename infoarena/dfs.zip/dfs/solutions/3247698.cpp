#include <fstream>
#include <climits>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");
int n,m;
struct per
{
    vector <int> p;
}v[100005];
bool viz[100005];

int dfs(int nod,int tat=-1)
{
    for(auto i:v[nod].p)
    {
        if(i!=tat)
        {
            viz[i]=1;
            dfs(i,nod);
        }
    }
}


int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
          int x,y;
          cin>>x>>y;
          v[x].p.push_back(y);
          v[y].p.push_back(x);
    }
    int cnt=0;
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            dfs(i);
            cnt++;
        }
    }
    cout<<cnt;


    return 0;
}
