#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int v[100],a[100][100]={0},N,M,x,y,p[100],k=0;;
void DF(int i)
{
    v[i]=k;
    for(int j=1;j<=N;j++)
    {
        if(a[i][j]==1 && v[j]==0)
            DF(j);
    }
}
void compconex()
{
    for(int i=1;i<=N;i++)
        if(v[i]==0)
    {
        k++;
        DF(i);
    }
    cout<<k;
}
int main()
{
    cin>>N>>M;
    for(int i=1;i<=M;i++)
    {
        cin>>x>>y;
        a[x][y]=1;
        a[y][x]=1;
    }
    compconex();
    return 0;
}
