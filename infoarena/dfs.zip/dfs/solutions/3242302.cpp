#include <iostream>
#include <fstream>
#include <vector>
#include <set>
using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

vector < set <int>> a(2000001);
int n, x, y, maxi, nr;
bool viz[200001], vf[200001];

void dfs(int x)
{
    viz[x] = true;
    for(auto i=a[x].begin(); i!=a[x].end(); i++)
        if(!viz[*i])
            dfs(*i);
}
int main()
{
    while(f >> x >> y)
    {   maxi = max(maxi, x);
        maxi = max(maxi, y);
        a[x].insert(y);
        a[y].insert(x);
    }
    for(int i=0; i<=maxi; i++)
        if(!viz[i])
    {
        dfs(i);
        nr++;
    }
    g << nr;
    return 0;
}
