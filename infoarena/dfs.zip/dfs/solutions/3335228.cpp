#include <bits/stdc++.h>

using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

const int NMAX = 100005;

vector <int> G[NMAX];

int n,m;
bool viz[NMAX];
int nrc;

void DFS(int start){
    viz[start]=true;
    for (auto vecin : G[start]){
        if (viz[vecin]==false)
            DFS(vecin);
    }
}

int main(){
    f>>n>>m;
    for (int i=1;i<=m;i++){
        int nod1, nod2;
        f>>nod1>>nod2;
        G[nod1].push_back(nod2);
        G[nod2].push_back(nod1);
    }

    for (int i=1;i<=n;i++){
        if (viz[i]==false){
            nrc++;
            DFS(i);
        }
    }

    g<<nrc;
}
