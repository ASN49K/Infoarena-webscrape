#include <bits/stdc++.h>
using namespace std;
const int nmax = 1e5 + 5;

int N, M, vis[nmax], ans;
vector < int > adj[nmax];

ifstream fin("dfs.in");
ofstream fout("dfs.out");


void dfs(int node){
    vis[node] = 1;
    
    for(auto elem : adj[node]){
        if(vis[elem] == 0){
            dfs(elem);
        }
    }
}

int main()
{
    fin>>N>>M;
    
    for(int i=1;i<=M;i++){
        int x, y;
        fin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    
    for(int i=1;i<=N;i++){
        if(vis[i] == 0){
            ans++;
            dfs(i);
        }
    }
    
    
    fout<<ans;
    
    
}