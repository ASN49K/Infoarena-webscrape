#include <bits/stdc++.h>

using namespace std;

const int NMAX=1e5+2;
vector<int> adj[NMAX];
bool viz[NMAX];

void dfs(int nod)
{
    viz[nod]=1;
    //for(auto& to : adj[nod])
    for(int i=0; i<adj[nod].size(); i++)
    {
        int to=adj[nod][i];
        if(!viz[to])
        {
            dfs(to);
        }
    }
}
int main()
{
    int n, m; cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x, y; cin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    int nrcomponente=0;
    for(int nod=1; nod<=n; nod++)
    {
        if(!viz[nod])
        {
            dfs(nod);
            nrcomponente++;
        }
    }
    cout<<nrcomponente;
    return 0;
}
