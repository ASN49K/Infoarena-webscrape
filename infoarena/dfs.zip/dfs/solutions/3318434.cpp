#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;

vector<vector<int>> L;
vector<int> viz;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

void dfs(int nod) {
    viz[nod] = 1;
    for (int vecin : L[nod]) {
        if (viz[vecin] == 0) {
            dfs(vecin);
        }
    }
}

int main () {
    int cc = 0;
    int n, m;
    fin >> n >> m;
    L.resize(n + 1);
    viz.resize(n + 1);
    int x, y;
    for (int i = 0; i < m; i++) {
        fin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    for (int i = 1; i<=n; i++) {
        if (viz[i] == 0) {
            dfs(i);
            cc++;
        }
    }
    fout << cc << "\n";

    return 0;
}