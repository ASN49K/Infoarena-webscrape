#include <bits/stdc++.h>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n,m;
vector<int> v[100003];
int a;
bool ap[100003];
void dfs(int nod)
{
    ap[nod]=true;
    for (int i=0;i<v[nod].size();i++)
    {
        if (ap[v[nod][i]]==false)
        {
            dfs(v[nod][i]);
        }
    }
}
int main()
{
    fin>>n>>m;
    for (int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    for (int i=1;i<=n;i++)
    {
        if (ap[i]==false)
        {
            a++;
            dfs(i);
        }
    }
    fout<<a;
    return 0;
}
