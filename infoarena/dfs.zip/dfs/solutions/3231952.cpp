#include <fstream>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");
struct nod{
    int info;
    nod* urm;
};
nod* v[100001];
bool viz[100001];
void dfs(int x)
{
    viz[x]=1;
    for(nod* p=v[x];p;p=p->urm)
        if(viz[p->info]==0)
            dfs(p->info);
}
int main()
{
   int x,y,nn,mm;
   f>>nn>>mm;
   for(int i=1;i<=mm;i++)
   {
        f>>x>>y;
        nod *p=new nod;
        p->info=y;
        p->urm=v[x];
        v[x]=p;
        nod *o=new nod;
        o->info=x;
        o->urm=v[y];
        v[y]=o;
   }
   int cnt=0;
   for(int i=1;i<=nn;i++)
   {
       if(viz[i]==0)
        {dfs(i);
        cnt++;}
   }
   g<<cnt;
    return 0;
}