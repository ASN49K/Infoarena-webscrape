#include <fstream>
#include <queue>

using namespace std;

fstream cin("dfs.in");
ofstream cout("dfs.out");

int n, m, s;

vector<int> g[100001];
int res;

bool viz[100001];
void dfs(int nod) {
    viz[nod] = 1;
    for (auto i : g[nod])
        if (!viz[i])
            dfs(i);
}

int main() {
    cin >> n >> m;
    for (int i = 1; i <= m; ++i) {
        int a, b;
        cin >> a >> b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    
    for (int i = 1; i <= n; ++i)
        if (!viz[i]) {
            ++res;
            dfs(i);
        }

    cout << res;

    return 0;
}