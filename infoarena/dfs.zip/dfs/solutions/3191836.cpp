#include <fstream>
#include <vector>
#include <iostream>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<int> G[100001];

int n, m, x, y, viz[100001], nr;

void citire() {
    fin>>n>>m;
    for (int i=1; i<=m; i++) {
        fin>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
}

void dfs(int nod) {
    viz[nod]=1;
    for (auto i:G[nod]) {
        if (viz[i]==0)
            dfs(i);
    }
}

int main() {
    citire();
    for (int i=1; i<=n; i++)
        if (viz[i]==0) {
            nr++;
            dfs(i);
        }
    fout<<nr;
    return 0;
}
