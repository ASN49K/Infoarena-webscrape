#include <iostream>
#include <vector>
#define Nmax 100000
#include <fstream>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
vector<int> v[Nmax + 5];
int k=1;
int viz[Nmax + 5];
void dfs(int x)
{
    viz[x]=1;
    for(auto i : v[x])
    {
        if(viz[i]==0)
            dfs(i);
    }
}
int main()
{
    int n,m,x,y;
    fin>>n>>m;
    for(int i=0;i<m;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            dfs(i);
            k++;
        }
    }
    fout<<k-1;
    return 0;
}
