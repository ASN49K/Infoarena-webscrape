#include <fstream>
#include <vector>

using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

vector < vector < int > > g;
vector < bool > vis;

void DFS(int nod) {
    vis[nod] = true;
    for(int i : g[nod]) {
        if(!vis[i]) {
            DFS(i);
        }
    }
}

int main() {
    g.resize(100001);
    vis.resize(100001);
    int n, m;
    cin >> n >> m;
    for(int i = 0; i < m; i++) {
        int nod1, nod2;
        cin >> nod1 >> nod2;
        g[nod1].push_back(nod2);
        g[nod2].push_back(nod1);
    }
    int cnt = 0;
    for(int i = 1; i <= n; i++) {
        if(!vis[i]) {
            cnt++;
            DFS(i);
        }
    }
    cout << cnt;
    return 0;
}
