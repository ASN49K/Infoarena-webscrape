#include <fstream>
#include <vector>
#include <climits>
#include <queue>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int DIM = 100010;

int n, m, s, x, y;
vector<int> l[DIM];
bool visited[DIM];

void dfs(int node) {
    visited[node] = true;
    for (auto adjNode : l[node])
        if (!visited[adjNode])
            dfs(adjNode);
}

int main() {
    fin >> n >> m >> s;
    for (int i = 1; i <= m; i++) {
        fin >> x >> y;
        l[x].push_back(y);
        l[y].push_back(x);
    }

    int conCompCnt = 0;
    for (int node = 1; node <= n; node++) {
        if (!visited[node]) {
            conCompCnt++;
            dfs(node);
        }
    }

    fout << conCompCnt;

    return 0;
}