#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

vector<int> l[101];
bool viz[101];
void dfs(int node){
    for(int n:l[node]){
        if(viz[n]==false){
            viz[n]=true;
            dfs(n);
        }
    }
}

int main() {
    ifstream fin("dfs.in");
    ofstream fout("dfs.out");

    int n,m,x,y;
    fin>>n>>m;
    for(int i=1;i<=m;i++){
        fin>>x>>y;
        l[x].push_back(y);
        l[y].push_back(x);
    }
    int s=0;
    for(int i=1;i<=n;i++){
        if(viz[i]==false)
            dfs(i),s++;
    }
    fout<<s;
}
