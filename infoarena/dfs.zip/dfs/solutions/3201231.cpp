
#include <fstream>
#include <vector>
using namespace std;
ifstream cin("dfs.in");
ofstream cout("dfs.out");
int n,m;
vector<vector<int> > A;
vector<bool> fr;
int nr;
int x,y;
void dfs(int nod)
{
    for(int i=0;i<A[nod].size();i++)
    {
        int vecin=A[nod][i];
        if(!fr[vecin])
         {
             fr[vecin]=1;
             dfs(vecin);
         }
    }
}
int main()
{
    cin>>n>>m;
    A.resize(n+1);
    fr.resize(n+1);
    for(int i=0;i<m;i++)
    {
        cin>>x>>y;
        A[x].push_back(y);
        A[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
      if(!fr[i])
      {
          fr[i]=1;
          nr++;
          dfs(i);
      }
    cout<<nr;
    return 0;
}
