#include <iostream>
#include <vector>
#include <fstream>
#include <queue>
using namespace std;
ifstream f("graf.in");
ifstream fin("bfs.in");
ofstream g("bfs.out");
ifstream ff("dfs.in");
ofstream gg("dfs.out");
const int NMAX=100001;
int d[NMAX];
//int mat[NMAX+1][NMAX+1];
bool vs[NMAX];
vector<int> G[NMAX+1];
void citire_lista()
{
    int n,m;
    ifstream f("graf.in");
    f>>n>>m;
    while(m--)
    {
        int x,y;
        f>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
}
void bfs(int x)
{
    queue<int> q;
    q.push(x);
    d[x]=0;
    vs[x]=1;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(auto next : G[nod])
        {
            if(!vs[next])
            {
                q.push(next);
                d[next]=d[nod]+1;
                vs[next]=1;
            }
        }
    }
}
void dfs(int x)
{
    vs[x]=1;
    for(auto next: G[x])
    {
        if(!vs[next])
            dfs(next);
    }
}
void conex(int n)
{
    int nr_conex=0;
    for(int i=0; i<=n; i++)
    {
        if(!vs[i])
        {
            nr_conex++;
            dfs(i);
        }
    }
    nr_conex--;
    gg<<nr_conex;
}


int main()
{
    int n,m,x,y;
    ff>>n>>m;
    int m1=m;
    while(m1--)
    {
        ff>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    //bfs(s);
    conex(n);
    return 0;
}

