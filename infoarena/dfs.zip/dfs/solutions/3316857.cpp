
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

// DFS

int viz[101];

int nr;

int DFS(int n, int i){


    viz[L[i][0]]=1;

    for(int j=0; j<L[i].size(); j++){
        if (viz[L[i][j]]==0){
            nr++;
            DFS(n, j);
        }
            
    }

    return nr;
}


vector<int> L[101];

int main()
{
    ifstream cin("dfs.in");
    ofstream cout("dfs.out");

    int n, m;
    cin>>n>>m;
    int x, y;
    while (cin >> x >> y) {
        L[x].push_back(y);
        L[y].push_back(x);
    }

    int ok = DFS(n, 0);

    cout<<ok;

}

