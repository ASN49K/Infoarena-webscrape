#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector <int> l[100001];
int viz[100001];

void dfs(int nod)
{
    for(int i=0;i<l[nod].size();i++)
    {
        int vecin=l[nod][i];
        if(viz[vecin]==0)
        {
            viz[vecin]=1;
            dfs(vecin);
        }
    }
}

int main()
{
    int n, m, nr=0, x, y;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        l[x].push_back(y);
        l[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            dfs(i);
            nr++;
        }
    }
    fout<<nr;
}
