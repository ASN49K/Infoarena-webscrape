#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

vector<vector<int>> L;
int n, m;

vector<bool> viz;

void dfs(int node)
{
    viz[node] = true;
    for (auto v : L[node])
        if (!viz[v])
            dfs(v);
}

int main()
{
    ifstream f("dfs.in");
    f >> n >> m;
    L.resize(n + 1);
    viz.resize(n + 1, false);
    for (int i = 1; i <= m; ++i)
    {
        int a, b;
        f >> a >> b;
        L[a].push_back(b);
        L[b].push_back(a);
    }
    f.close();

    int nr_componente_conexe = 0;
    for (int i = 1; i <= n; ++i)
    {
        if (!viz[i])
        {
            ++nr_componente_conexe;
            dfs(i);
        }
    }

    ofstream g("dfs.out");
    g << nr_componente_conexe << '\n';
    g.close();

    return 0;
}