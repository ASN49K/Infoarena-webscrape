#include <iostream>
#include <fstream>
#include <vector>
#include <stdint.h>

const int32_t MAX_N = 100000;

std::vector<int32_t> adj[MAX_N];
bool used[MAX_N];

void DFS(int32_t node) {
	used[node] = true;

	for(int32_t next : adj[node]) {
		if(!used[next])
			DFS(next);
	}
}

int main() {
	std::ifstream fin("dfs.in");
	std::ofstream fout("dfs.out");

	int32_t n, m;
	fin >> n >> m;

	for(int32_t i = 0; i != m; ++i) {
		int32_t x, y;
		fin >> x >> y;
		--x; --y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}

	int32_t count = 0;
	for(int32_t i = 0; i != n; ++i) {
		if(used[i])
			continue;
		++count;
		DFS(i);
	}

	fout << count;

	fin.close();
	fout.close();

	return 0;
}