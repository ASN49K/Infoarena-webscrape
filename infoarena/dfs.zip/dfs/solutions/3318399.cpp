#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");
int n,m,x,nrc,i,a[101][101],x1,x2,vizita[100001];
vector <int> L[100001];
void dfs(int x)
{

    vizita[x]=1;
   for(auto nod:L[x])
        if(vizita[nod]==0)
        {
            //g<<i<<' ';
            vizita[nod]=1;
            dfs(nod);
        }
}
int main()
{
   f>>n>>m;
   for(int i=1;i<=m;++i)
   {
      f>>x1>>x2;
      L[x1].push_back(x2);

   }
  for(i=1;i<=n;++i)
  {
      if(vizita[i]==0)
      {
          dfs(i);
          ++nrc;
      }

  }
  g<<nrc;

    return 0;
}
