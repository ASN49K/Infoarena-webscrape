#include<fstream>
#include<queue>
#include<vector>
using namespace std;
int v[100001];
vector <int> graf[100001];

void fill(int nod){
  for(int vecin:graf[nod]){
    if(v[vecin]==0){
      v[vecin]=1;
      fill(vecin);
    }
  }
}
int main(){
  ifstream fin("dfs.in");
  ofstream fout("dfs.out");
  int n, m, x, y, cnt=0;
  fin>>n>>m;
  for(int i=0; i<m; i++){
    fin>>x>>y;
    graf[x].push_back(y);
  }
  for(int i=1; i<=n; i++){
    if(v[i]==0)
      fill(i), cnt++;
  }
  fout<<cnt;

  return 0;
}
