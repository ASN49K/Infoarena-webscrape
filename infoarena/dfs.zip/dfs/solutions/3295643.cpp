#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");


void DFS(int node, vector<bool> &visited,vector<vector<int>> &adj)
{
    if (visited[node] == true)
        return;

    for (auto neigh : adj[node]) {
        if (!visited[neigh]) {
            visited[neigh] = true;
            DFS(neigh, visited, adj);
        }
    }
}

int main()
{
    int N, M;
    fin >> N >> M;
    vector<vector<int>> adj(N + 1, vector<int>());
    for (int i = 0; i < M; ++i) {
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    int count = 0;
    vector<bool> visited(N + 1, false);

    for (int i = 1; i <= N; ++i) {
        if (visited[i] == false) {
            count++;
            DFS(i, visited, adj);
        }
    }

    fout << count <<'\n';
    
    return 0;
}