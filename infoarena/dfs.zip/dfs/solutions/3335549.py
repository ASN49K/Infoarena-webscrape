import sys
problema = "dfs"
f_in = problema + ".in"
f_out = problema + ".out"
sys.setrecursionlimit(1000000)


adiacenta = []
vizitati = set()


def dfs(node):
    vizitati.add(node)
    for vecin in adiacenta[node]:
        if vecin not in vizitati:
            dfs(vecin)

with open(f_in, "r") as f:
    n, m = [int(x) for x in next(f).split()]
    for i in range(1,n+1):
        adiacenta[i] = []
    for l in f:
        x, y = [int(a) for a in l.split()]
        
        adiacenta[x].append(y)
        adiacenta[y].append(x)

nr_conexe = 0;
for n in adiacenta:
    if n not in vizitati:
        nr_conexe += 1
        dfs(n)


with(open(f_out, "x")) as f:
     f.write(str(nr_conexe))
# print(nr_conexe)
