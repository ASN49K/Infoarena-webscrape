#include <vector>
#include <fstream>
#include <bitset>
#include <queue>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n, m;
vector<int> L[100004];
bitset<100000> viz;
void dfs(int nod)
{
    viz[nod] = 1;
    for (auto it : L[nod])
        if (!viz[it])
            dfs(it);
}
int main()
{
    int cnt = 0;
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    for (int i = 1; i <= n; i++)
        if (!viz[i])
            cnt++,dfs(i);
    fout << cnt;
    return 0;
}