#include <bits/stdc++.h>
#include <queue>
#include <vector>
#include <fstream>
using namespace std;
ifstream cin("dfs.in");
ofstream cout("dfs.out");
vector <int> L[100001];
int vis[100001];

void dfs(int x) {
    vis[x] = 1;

    for (int v : L[x]) {
        if (vis[v] == 0) {
            dfs(v);
        }
    }
}
int main()
{
    int n, m, cnt = 0;
    cin >> n >> m;
    int x, y;
    while (cin >> x >> y) {
        L[x].push_back(y);
        L[y].push_back(x);
    }

    for (int i = 1; i <= n; i++) {
        if (vis[i] == 0) {
            cnt++;
            dfs(i);
        }
    }
    cout << cnt;
}



