#include <fstream>
#include <vector>

using namespace std;

ifstream be("dfs.in");
ofstream ki("dfs.out");

void dfs(const vector<vector<bool>> &adj, vector<bool> &vis, const int &start)
{
    vis[start] = 1;

    for(int i = 1; i < (int)adj.size(); i++)
    {
        if(adj[start][i])
        {
            dfs(adj, vis, i);
        }
    }
}

int main()
{
    int n, m;
    be >> n >> m;

    vector<bool> vis(n + 1);
    vector<vector<bool>> adj(n + 1, vector<bool>(n + 1));

    int x, y;

    for(int i = 1; i <= m; i++)
    {
        be >> x >> y;

        adj[x][y] = 1;
    }

    int cnt = 0;

    for(int i = 1; i <= n; i++)
    {
        if(!vis[i])
        {
            dfs(adj, vis, i);
            cnt++;
        }
    }

    ki << cnt;

    return 0;
}