#include <fstream>
#include <vector>

using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

#define MAXN 100000
vector<int> mat[MAXN+1];
bool ok[MAXN+1];
int n, m;

void dfs(int poz) {
    ok[poz]=1;
    for(auto i:mat[poz])
        if(ok[i]==0) dfs(i);
}

int main() {
    cin>>n>>m;
    int i, x, y;
    for(i=0; i<m; i++) {
        cin>>x>>y;
        mat[x].push_back(y);
        mat[y].push_back(x);
    }
    int cnt;
    cnt=0;
    for(i=1; i<=n; i++)
        if(ok[i]==0) {
            dfs(i);
            cnt++;
        }
    cout<<cnt;
}
