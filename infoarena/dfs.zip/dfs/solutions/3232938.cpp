#include<fstream>
using namespace std;
ifstream F("dfs.in");
ofstream G("dfs.out");
int i,n,a[100001],j,k,l;
int main()
{
    for(F>>n>>j;F>>i>>j;) {
        for(;a[i];i=a[i]);
        for(;a[j];j=a[j]);
        if(i!=j)
            ++l,a[i]=j;
    }
    return G<<n-l,0;
}
