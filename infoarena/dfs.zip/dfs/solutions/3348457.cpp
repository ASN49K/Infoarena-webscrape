#include <iostream>
#include <vector>
#include <fstream>

using namespace std;
const int NMAX = 100000;
int n, m;
bool vizitat[NMAX];
vector<vector<int>>v;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

void parcurgere(int nod )
{
    if( vizitat[nod] )
        return ;
    vizitat[nod] = true;
    for( auto next: v[nod] ){
        parcurgere(next);
    }
}
int main()
{
    fin >> n >> m;
    int x, y;
    for(int i = 0; i < m; i++)
    {
        fin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    int componente = 0;
    for(int i = 0; i < n; i++) 
    {
        if(!vizitat[i]) 
        {
            parcurgere(i);
            componente++;
        }
    }
    fout << componente;
    return 0;
}
