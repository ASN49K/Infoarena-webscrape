#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector <int> v[100001];
int viz[100001], c[100001];
 
int main()
{ 
   int n, m, x,y;
   fin >> n>>m;
   for(int i = 1; i <=m; i++){
     fin >> x >>y;
     v[x].push_back(y);
    v[y].push_back(x);
   }
   int nrcomp=0;
   for(int i = 1; i<=n; i++){
     if(viz[i] == 0){
       nrcomp ++;
       int u = 1, p = 1;
       c[p] = i;
       while(p<=u){
         int vf=c[p];
         p++;
         int l=v[vf].size();
         for(int j=1;j<=l;j++){
           if(viz[v[vf][j]]==0){
             viz[v[vf][j]]=1;
             u++;
             c[u]=v[vf][j];
           }
         }
       }
     }
   }
   fout<<nrcomp;
   
  return 0;
}

 