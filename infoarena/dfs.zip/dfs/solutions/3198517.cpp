#include <bits/stdc++.h>

using namespace std;

int n, m, lim[100001];
set <int> s[100001];

ifstream f("dfs.in");
ofstream g("dfs.out");

void citire()
{
    f >> n >> m;
    for(int i = 1;i <= m;i ++)
    {
        int x , y;
        f >>x >>y;
        s[x].insert(y);
        s[y].insert(x);
    }
}

void dfs(int nod)
{
    lim[nod] = 1;
    for(auto i : s[nod])
        if(!lim[i])
            dfs(i);
}

void rez()
{
    int nr = 0;
    for(int i = 1;i <= n;i ++)
        if(!lim[i])
            nr ++,dfs(i);
            
    g << nr;
}
int main()
{
    citire();
    rez();

    return 0;
}
