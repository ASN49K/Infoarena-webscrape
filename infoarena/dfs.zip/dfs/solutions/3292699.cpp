#include <bits/stdc++.h>

using namespace std;

ifstream f("dfs.in");
ofstream gg("dfs.out");

vector <int> g[100005];
bool viz[100005];
int n,m;

void dfs (int nod)
{
    viz[nod]=true;
    for (auto vec:g[nod] )
        if ( !viz[vec] )
            dfs(vec);
}

int main()
{
    f >> n >> m;
    for (int i=1; i<=m; i++ )
    {
        int x,y;
        f >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }

    int cnx=0;
    for (int i=1; i<=n; i++ )
        if ( !viz[i] )
             {dfs(i),cnx++;}

    gg << cnx;
    return 0;
}
