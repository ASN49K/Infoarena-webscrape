#include <bits/stdc++.h>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m;
const int nmax=1e5+1, mmax=2e5+5;

vector<int> G[nmax+1];
bool vizitat[nmax+1];
stack<int> dfs;

int main()
{
    fin >> n >> m;
    int x, y;
    for(int i=0; i<m; i++)
    {
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    int t, ans=0;
    for(int i=1; i<=n; i++)
    {
        if(vizitat[i])
            continue;
        ans++;
        vizitat[i]=true;
        dfs.push(i);
        while(!dfs.empty())
        {
            t=dfs.top();
            dfs.pop();
            for(auto x: G[t])
                if(!vizitat[x])
                {
                    vizitat[x]=true;
                    dfs.push(x);
                }
        }
    }
    fout << ans;
    return 0;
}
