#include <fstream>
#include <vector>
using namespace std;
ifstream cin("dfs.in");
ofstream cout("dfs.out");
vector<vector<int>> v;
int n,m;
bool viz[100001];
void dfs(int node)
{
    viz[node]=true;
    for(int vec:v[node])
    {
        if(viz[vec]==false)
            dfs(vec);
    }
}
int main()
{
    cin>>n>>m;
    v.resize(n+1);
    for(int i=1;i<=m;i++)
    {
        int a,b;
        cin>>a>>b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    int k=0;
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==false)
           {
               dfs(i);
                k++;
           }
    }
    cout<<k;
    return 0;
}
