#include <bits/stdc++.h>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int N=1005;
vector<int> adj[N];
int viz[N];
void DFS(int u)
{
    viz[u] = 1;
    for(int v : adj[u])
    {
        if(viz[v]==0)
            DFS(v);
    }
}
int main()
{
    int n,m;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    int cc = 0;
    for(int i=1;i<=n;i++)
        if(viz[i]==0){
            DFS(i);
            cc++;
        }
    fout<<cc;
    return 0;
}