#include <fstream>
#include <vector>

#define pb push_back

using namespace std;
ifstream in("dfs.in");
ofstream out("dfs.out");
const int N = 1e5 + 5;

int n, m;
bool vzt[N];
vector<int> g[N];

void DFS(int nod) {
    vzt[nod] = 1;

    for(auto nxt : g[nod])
        if(!vzt[nxt])
            DFS(nxt);
}

int main()
{
    in >> n >> m;
    for(int i=1; i<=m; i++) {
        int x, y;
        in >> x >> y;
        g[x].pb(y);
        g[y].pb(x);
    }

    int ans = 0;
    for(int i=1; i<=n; i++)
        if(!vzt[i]) {
            ans++;
            DFS(i);
        }

    out << ans;
    return 0;
}
