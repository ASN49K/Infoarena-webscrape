#include <fstream>
#include <vector>

using namespace std;

void dfs(int x, vector <vector <int>> &a, vector <bool> &viz) {
    viz[x] = true;
    for (auto y: a[x]) {
        if (!viz[y]) {
            dfs(y, a, viz);
        }
    }
}

int main() {
    ifstream in("dfs.in");
    ofstream out("dfs.out");
    int n, m;
    in >> n >> m;
    vector <vector <int>> a(n + 1);
    vector <bool> viz(n + 1, false);
    for (int i = 0; i < m; i++) {
        int x, y;
        in >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    in.close();
    int nrc = 0;
    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            nrc++;
            dfs(i, a, viz);
        }
    }
    out << nrc << "\n";
    out.close();
    return 0;
}