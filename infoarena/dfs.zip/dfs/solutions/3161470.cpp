#include <iostream>
#include <fstream>
#include <vector>
using namespace std;


ifstream fin("dfs.in");
ofstream fout("dfs.out");


int n,m,x,y,sol;
vector <int> vecini[100005];
bool viz[100005];


void dfs(int nod)
{
    viz[nod]=1;
    int k=vecini[x].size();
    for(int i=0;i<k;i++)
    {
        if(!viz[vecini[x][i]])
        {
            dfs(vecini[x][i]);
        }
    }
}


int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        vecini[x].push_back(y);
        vecini[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
    {
        if(!viz[x])
        {
            sol++;
            dfs(x);
        }
    }
    fout<<sol;
    return 0;
}
