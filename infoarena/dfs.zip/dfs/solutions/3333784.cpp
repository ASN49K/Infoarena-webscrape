#include <bits/stdc++.h>
#define NMAX 100002

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n,m,start,nrc;

vector<int> A[NMAX]; //am declarat un vector cu NMAX celem de tip vector din STL numit A
bool viz[NMAX];

void citire();
void afisare_lad();
void dfs(int x);
int main()
{
    citire();
    for(int i=1;i<=n;i++){
        if(viz[i]==0){
            nrc++;
            dfs(i);
        }
    }
    fout<<nrc<<'\n';
    return 0;
}
void citire(){
    int i,x,y;
    fin>>n>>m;
    for(i=0;i<m;i++){
        fin>>x>>y;
        //adaug pe y in lista de adiacenta a lui x
        A[x].push_back(y);
        //doar pentru neorientate adaug si pe x in lista de adiacenta a lui y
        A[y].push_back(x);
    }
}
void afisare_lad(){
    int i,j;
    for(i=1;i<=n;i++){
        for(j=0;j<A[i].size();j++){
            fout<<A[i][j]<<' ';
        }
        fout<<'\n';
    }
}
void dfs(int x){
    int i;
    //parcurg graful incepand din varful x
    viz[x] = 1;
    //parcurg vecinii lui x
    for(i=0;i<A[x].size();i++){
        if(!viz[A[x][i]]){
            //exista [x,A[x]]/(x,A[x]) si i nevizitat
            dfs(A[x][i]);
        }
    }
}
//graf stl
