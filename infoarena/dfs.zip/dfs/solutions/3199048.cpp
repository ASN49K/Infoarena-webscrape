#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin ("dfs.in");
ofstream fout ("dfs.out");
vector<vector<int>>G;
bool vis[100005];
void DFS(int node)
{
    vis[node]=true;
    for(int i=0;i<G[node].size();i++)
    {
        int ngb=G[node][i];
        if(!vis[ngb])
            DFS(ngb);
    }
}
int main()
{
    int n,m;
    fin>>n>>m;
    G.resize(n+1);
    for(int i=0;i<m;i++)
    {
        int node1, node2;
        fin>>node1>>node2;
        G[node1].push_back(node2);
        G[node2].push_back(node1);
    }
    int cnt=0;
    for(int i=1;i<=n;i++)
    {
        if(!vis[i])
        {
            DFS(i);
            cnt++;
        }
    }
    fout<<cnt;
}