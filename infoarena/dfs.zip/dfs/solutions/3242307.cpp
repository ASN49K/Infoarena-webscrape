#include <iostream>
#include <fstream>
#include <vector>
#include <set>
using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

vector < set <int>> a(100001);
int n, m, x, y, maxi, nr;
bool viz[100001];

void dfs(int x)
{
    viz[x] = true;
    for(auto i=a[x].begin(); i!=a[x].end(); i++)
        if(!viz[*i])
            dfs(*i);
}
int main()
{   f >> n >> m;
    while(f >> x >> y)
    {
        a[x].insert(y);
        a[y].insert(x);
    }
    for(int i=0; i<=m; i++)
        if(!viz[i])
    {
        dfs(i);
        nr++;
    }
    g << nr;
    return 0;
}
