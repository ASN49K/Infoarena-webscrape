//DFS
#include <iostream>
#include <vector>
#include <bits/stdc++.h>
#include <fstream>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<int> L[100000];
int viz[100000];
int nr = 0;
void DFS(int nod) {
    viz[nod] = 1;
    for (int vecin : L[nod]) {
        if (viz[vecin] == 0) {
            DFS(vecin);
        }
    }

}

void conexe(int n) {
    for (int i = 1; i <= n; i++)
        if (viz[i] == 0) {
            nr++;
            DFS(i);
        }
}

int main() {
    int n, m, x, y, i = 0;
    cin >> n >> m;
    while(i < m){
        cin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
        i++;
    }
    for (int i = 1; i <= n; i++){
        sort(L[i].begin(), L[i].end());
        L[i].erase(unique(L[i].begin(), L[i].end()), L[i].end());
        //cout << L[i].size() << " ";
        for (int j = 0; j < L[i].size(); j++){
            cout << L[i][j] << " ";
        }
        cout << '\n';
    }
    conexe(n);
    fout << nr;
}

