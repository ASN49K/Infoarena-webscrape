#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    ifstream in("subsecvente.in");
    ofstream out("subsecvente.out");

    int n;
    cin >> n;

    vector<int> v(n + 1);
    for(int i = 1; i <= n; i++) {
        cin >> v[i];
    }
    return 0;
}
