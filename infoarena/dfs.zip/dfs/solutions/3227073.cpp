#include <bits/stdc++.h>
using namespace std;

class Task {
public:
    void solve() {
        read_input();
        print_output(get_result());
    }

private:
    // numarul maxim de noduri
    static constexpr int NMAX = (int)1e5 + 5; // 10^5 + 5 = 100.005

    // n = numar de noduri, m = numar de muchii/arce
    int n, m;

    // adj[node] = lista de adiacenta a nodului node
    // exemplu: daca adj[node] = {..., neigh, ...} => exista arcul (node, neigh)
    vector<int> adj[NMAX];

    void read_input() {
        ifstream fin("dfs.in");
        fin >> n >> m;
        for (int i = 1, x, y; i <= m; i++) {
            fin >> x >> y; // arc (x, y)
            adj[x].push_back(y);
            adj[y].push_back(x);
        }
        fin.close();
    }

    vector<vector<int>> get_result() {
        // Gasiti toate componentele conexe ale unui graf neorientat.

        return solve_dfs(); // DFS: O(n + m);
    }

    vector<vector<int>> solve_dfs() {
        // vector cu toate componentele conexe 
        vector<vector<int>> ccs;

        // used[node] = 1 daca node a fost deja vizitat, 0 altfel
        vector<int> used(n + 1, 0);

        // pentru fiecare nod
        for (int node = 1; node <= n; ++node) {
            // daca nodul este nevizitat, pornim o parcurgere
            if (!used[node]) {
                // incepem o noua componenta conexa
                vector<int> cc;
                dfs(node, used, cc);
                
                ccs.push_back(cc);
            }
        }

        return ccs;
    }

    // porneste o parcurgere DFS din node
    // foloseste vectorul used pentru a marca nodurile vizitate
    void dfs(int node, vector<int>& used, vector<int>& cc) {
        used[node] = 1; // marcheze nodul ca fiind vizitat
        cc.push_back(node);

        // parcurg vecinii
        for (auto& neigh : adj[node]) {
            if (!used[neigh]) {
                dfs(neigh, used, cc);
            }
        }
    }

    void print_output(const vector<vector<int>>& ccs) {
        ofstream fout("dfs.out");
        fout << ccs.size() << "\n";
        // for (auto& cc : ccs) {
        //     for (auto node : cc) {
        //        fout << node << ' ';
        //     }
        //     fout << '\n';
        // }
        fout << '\n';
        fout.close();
    }
};

// [ATENTIE] NU modifica functia main!
int main() {
    // * se aloca un obiect Task pe heap
    // (se presupune ca e prea mare pentru a fi alocat pe stiva)
    // * se apeleaza metoda solve()
    // (citire, rezolvare, printare)
    // * se distruge obiectul si se elibereaza memoria
    auto* task = new (nothrow) Task(); // hint: cppreference/nothrow
    if (!task) {
        cerr << "new failed: WTF are you doing? Throw your PC!\n";
        return -1;
    }
    task->solve();
    delete task;
    return 0;
}
