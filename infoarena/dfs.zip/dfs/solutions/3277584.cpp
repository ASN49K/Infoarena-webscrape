#include <fstream>
using namespace std;
ifstream cin("dfs.in");
ofstream cout("dfs.out");
struct nod
{
    int vf;
    nod *urm;
}*v[100001];
int n,m,viz[101],k;
void add(nod *&prim,int x)
{
    nod *q=new nod;
    q->vf=x;
    q->urm=prim;
    prim=q;
}
void read()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        int x,y;
        cin>>x>>y;
        add(v[x],y);
        add(v[y],x);
    }
}
void dfs(int p)
{
    viz[p]=k;
    for(nod *q=v[p];q;q->urm)
        if(viz[q->vf]==0)
            dfs(q->vf);
}
int main()
{
    read();
    for(int i=1;i<n;i++)
        if(viz[i]==0)
        {
            k++;
            dfs(i);
        }
    cout<<k;
    return 0;
}