#include <fstream>
#include <vector>
static constexpr int NMAX = (int)1e5 + 5; // 10^5 + 5 = 100.005

void DFS(int node, int n, std::vector<int> adj[NMAX], std::vector<bool>& p) {
    //start[node] = ++timestamp;                      // start visiting its subtree
    // [optional] color[node] = gray; 

    for (auto& vecin : adj[node]) {                      // for each neighbour
        if (p[vecin] == false) {                     // or [optional] color[neigh] = white;
            p[vecin] = node;                        // save parent
            DFS(vecin, n, adj, p);  // continue traversal
        }
    }
    // finish visiting its subtree
}

int get_result(int n, std::vector<int> adj[NMAX]) {
    // TODO: Faceti sortarea topologica a grafului stocat cu liste de adiacenta din adj.
    // *******
    // ATENTIE: nodurile sunt indexate de la 1 la n.
    // *******
    std::vector<bool> p(n + 1, false);
    int count = 0;
    for (int i = 1; i <= n; i++) {
        if (p[i] == false) {
            count++;
            p[i] = true;
            DFS(i, n, adj, p);
        }
    }
    return count;
}

int main() {
	std::ifstream fin("dfs.in");
	std::ofstream fout("dfs.out");
    std::vector<int> adj[NMAX];

    int n = 0;
    int x, y;
    while (fin >> x >> y) {
        n++;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    fout << get_result(n, adj);

}