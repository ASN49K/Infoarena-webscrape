#include <iostream>
#include <algorithm>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");



void DFS(int nod,vector<bool> &v,vector<vector<int>> &nd) {
	v[nod] = true;
	for (int x : nd[nod])
		if (not v[x])
			DFS(x, v, nd);

}

int main()
{
	int n, m;
	fin >> n >> m;
	int x, y;
	vector<bool> visited(n+1,false);
	vector<vector<int>> noduri(n+1);
	for (int i = 0;i < m;i++)
	{
		fin >> x >> y;
		noduri[x].push_back(y);
		noduri[y].push_back(x);
	}
	int cc = 0;
	for (int i = 1;i <= n;i++)
	{
		if (not visited[i]) {
			DFS(i, visited, noduri);
			cc++;
		}
	}
	fout << cc;
	
}

