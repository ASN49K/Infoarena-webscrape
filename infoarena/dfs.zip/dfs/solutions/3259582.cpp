#include <iostream>
#include <fstream>
#include <cstring>
#include <queue>
using namespace std;
ifstream fin("dfs.in");
ofstream gout("dfs.out");
int main()
{
    int n,m,x,i,j;
    fin>>n>>m>>x;
    bool v[n][n];
    memset(v,0,sizeof(v));
    while(m--)
    {
        fin>>i>>j;
        v[i-1][j-1]=v[j-1][i-1]=1;
    }
    bool ap[n];
    memset(ap,0,sizeof(ap));
    vector<int>q;
    q.push_back(x-1);
    ap[x-1]=1;
    gout<<x<<' ';
    bool gasit;
    while(!q.empty())
    {
        gasit=false;
        for(i=0; i<n&&!gasit; ++i)if(ap[i]==0&&v[q.back()][i])
            {
                gasit=true;
                ap[i]=1;
                q.push_back(i);
                gout<<1+i<<' ';
            }
        if(!gasit)q.pop_back();
    }
    return 0;
}
