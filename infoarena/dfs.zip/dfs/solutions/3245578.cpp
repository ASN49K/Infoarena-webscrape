#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void dfs(vector<vector<int>> graph, int mark[], int node){
    if(mark[node] == 1){
        mark[node] = 2;
        for(int k : graph[node]){
            dfs(graph, mark, k);
        }
    }
}

int main(){
    ifstream fin("dfs.in");
    ofstream fout("dfs.out");
    const int Nmax = 100005;
    int n, m;
    fin >> n >> m;
    vector<vector<int>> graph(n, vector<int>());
    int mark[Nmax];
    for(int i = 1; i <= Nmax; i++){
        mark[i] = 0;
    }
    for(int i = 1; i <= m; i++){
        int x, y;
        fin >> x >> y;
        graph[x].push_back(y);
        graph[y].push_back(x);
        mark[x] = mark[y] = 1;
    }

    int cnt = 0;
    for(int i = 1; i <= Nmax; i++){
        if(mark[i] == 1){
            dfs(graph, mark, i);
            cnt++;
        }
    }
    fout << cnt;
    return 0;
}
