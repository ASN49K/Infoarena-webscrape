#include <bits/stdc++.h>

using namespace std;

int main() {
    ifstream fin("dfs.in");
    ofstream fout("dfs.out");
    int n, m;
    fin >> n >> m;
    vector<vector<int>> adj(n + 1);
    vector<bool> visited(n + 1);
    for (int i = 1, x, y; i <= m; ++i) {
        fin >> x >> y;
        adj[x].push_back(y);
    }

    function<void(int)> dfs = [&](int nod) -> void {
        visited[nod] = true;
        for (int vecin : adj[nod]) {
            if (!visited[vecin]) {
                dfs(vecin);
            }
        }
    };

    int cnt = 0;
    for (int i = 1; i <= n; ++i) {
        if (!visited[i]) {
            dfs(i);
            ++cnt;
        }
    }
    fout << cnt << '\n';

    return 0;
}