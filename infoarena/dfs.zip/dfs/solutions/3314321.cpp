#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("dfs.in");
ofstream out("dfs.out");

vector<int> a[100005];
int viz[100005];

void dfs(int nod)
{
    viz[nod] = 1;
    for (auto w : a[nod])
    {
        if (!viz[w])
            dfs(w);
    }
}

int main()
{
    int n, m, s;
    in >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        in >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    int cnt = 0;
    for (int i = 1; i <= n; i++)
    {
        if (viz[i] == 0)
        {
            dfs(i);
            cnt++;
        }
    }
    out << cnt << '\n';
    return 0;
}