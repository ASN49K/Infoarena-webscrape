#include <fstream>

using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");
int n,m,x,y,viz[1001],a[1001][1001];
void parc(int k)
{
    int i;
    viz[k]=1;
    for(i=1;i<=n;i++)
    {
        if(a[i][k]==1&&viz[k]==0)parc(i);
    }
}

int main()
{
    int i;
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y;
        a[x][y]=1;
        a[y][x]=1;
    }
    int nr=0;
    for(i=1;i<=n;i++)
    {
        if(viz[i]==0){nr++;parc(i);}
    }
    g<<nr;
    return 0;
}
