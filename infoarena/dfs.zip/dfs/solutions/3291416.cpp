#include <fstream>
#include <vector>

using namespace std;

ifstream fin ("dfs.in");
ofstream fout ("dfs.out");

int n, m, x, y, cc, f[100005];
vector<int> L[100005];

void dfs (int nod) {
    f[nod] = 1;
    for (auto it : L[nod]) {
        if (f[it] == 0) {
            dfs(it);
        }
    }
}

int main(){
    fin >> n >> m;
    for (int i=0; i<m; i++){
        fin >> x >> y;
        L[x].push_back(y);
    }
    for (int i=1; i<=n; i++){
        if (f[i] == 0) {
            dfs(i);
            cc++;
        }
    }
    fout << cc;
    return 0;
}
