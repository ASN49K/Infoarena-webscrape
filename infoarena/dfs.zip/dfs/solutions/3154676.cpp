#include <fstream>

using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

bool viz[10005];
int cnt, n, m, x, a[10005][10005];

void dfs(int nod)
{
    viz[nod] = 1;

    for (int i = 1; i <= n; ++i) {
        if (a[nod][i] == 1 && !viz[i]) {
            dfs(i);
        }
    }
}

int main()
{
    f >> n >> m >> x;

    for (int i = 1; i <= m; ++i) {
        int x, y;
        f >> x >> y;
        a[x][y] = 1;
        a[y][x] = 1;
    }

    for (int i = 1; i <= n; ++i) {
        if(!viz[i]) {
            cnt++;
            dfs(i);
        }
    }

    g << cnt;

    return 0;
}
