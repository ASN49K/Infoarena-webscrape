#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <stack>

using namespace std;

//se da un graf neorientat cu n - nr varfuri, m - nr muchii si muchiile , afisati numarul de componente conexe ale grafului

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int main() {
	int n, m;
	fin >> n >> m;

	vector<vector<int>> vecini(n + 1);

	for (int i = 1; i <= m; i++) {
		int x, y;
		fin >> x >> y;

		vecini[x].push_back(y);
		vecini[y].push_back(x);
	}

	// avem lista de vecini pt fiecare nod, sa trecem la treaba

	int componente = 0;

	//sortam toti vecinii descrescator
	for (int i = 1; i <= n; i++) {
		sort(vecini[i].begin(), vecini[i].end(), greater<int>());
	}

	//pt a determina nr de componente conexe, o sa facem DFS-uri , si numarul de DFS-uri necesare pt a parcurge toate nodurile va fi nr de comp conexe

	vector<int> vizitate;
	vector<int> de_vizitat;
	stack<int> stiva;

	for (int i = 1; i <= n; i++) {
		//Doar daca nodul i nu e vizitat

		bool valid = true;
		for (auto v : vizitate) {
			if (v == i) {
				valid = false;
			}
		}
		if (!valid) continue;
		//facem DFS pornind din nodul i

		//punem primul in stiva
		stiva.push(i);
		de_vizitat.push_back(i);

		while (!stiva.empty()) {
			//adaugam nodul curent la vizitate si il scoatem din stiva

			int nod_curent = stiva.top();

			vizitate.push_back(nod_curent);

			stiva.pop();

			//scatem nod curent din de vizitat

			auto it = find(de_vizitat.begin(), de_vizitat.end(), nod_curent);
			if (it != de_vizitat.end()) {
				de_vizitat.erase(it);
			}

			//adaugam in stiva toti vecinii lui nevizitati CARE nu sunt nici pe lista de vizitat

			for (auto vecin : vecini[nod_curent]) {
				bool adaugabil = true;
				for (auto v : de_vizitat) {
					if (v == vecin) {
						adaugabil = false;
					}
				}
				for (auto v : vizitate) {
					if (v == vecin) {
						adaugabil = false;
					}
				}
				if (adaugabil) {
					stiva.push(vecin);
					de_vizitat.push_back(vecin);
				}
			}
		}
		componente++;
	}

	fout << componente;
}