#include<bits/stdc++.h>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<int> graf[100005];
bool vizitat[100001];

void dfs(int nod){
    vizitat[nod]=true;
    int i;
    for(auto i : graf[nod]){
        if(vizitat[i]==false){
            dfs(i);
        }
    }

    
}

int main()
{
 
    int n,m,x,y,nr=0;
    fin>>n>>m;

    for(int i=1;i<=m;i++){
        fin>>x>>y;
        graf[x].push_back(y);
        graf[y].push_back(x);
    }
    for(int i=1;i<=n;i++){
        if(vizitat[i]==false){
            nr++;
            dfs(i);
        }
    }
    fout<<nr;
    
    return 0;
}