#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<vector<int>> listaMuchii;
vector<int> viz;

void dfs(int nodInceput) {
    viz[nodInceput] = 1;
    for (int nod : listaMuchii[nodInceput]) {
        if (viz[nod] == 0) {
            dfs(nod);
        }
    }

}

int main() {
    int n;
    fin >> n;
    listaMuchii.resize(n+1);
    viz.resize(n+1, 0);
    int m;
    fin >> m;

    for (int i=1; i<=m; i++) {
        int a,b;
        fin >> a >> b;

        listaMuchii[a].push_back(b);
        listaMuchii[b].push_back(a);
    }

    int nrCompConexe = 0;

    for (int i=1; i<=n; i++) {
        if (viz[i] == 0) {
            nrCompConexe++;
            dfs(i);
        }
    }

    fout << nrCompConexe;


}