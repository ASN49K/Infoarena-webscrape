#include <fstream>
#include <vector>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<vector<int>> G;
vector <int> st;
int viz[200000];
void dfs(int start) {

    st.push_back(start);
    viz[start] = 1;

    while (!st.empty()) {
        int nod = st.back();
        st.pop_back();

        for (int vecin : G[nod]) {
            if (!viz[vecin]) {
                viz[vecin] = 1;
                st.push_back(vecin);
            }
        }
    }
}


int main() {

    int n, m;
    fin >> n >> m;
    G.resize(n + 1);
    for (int i = 1; i <= m; i++) {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    int sol = 0;
    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            sol++;
            dfs(i);
        }
    }
    fout << sol;
    return 0;
}

