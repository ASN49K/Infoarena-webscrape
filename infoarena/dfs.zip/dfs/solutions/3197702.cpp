#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<vector<int>>graf;
bool vis[100005];

void DFS(int nod){
    vis[nod]=true;
    for(int vec: graf[nod]){// ac lucru cu un for de la 0 la graf[nod.size()] in care vec ia val lui graf[nod][i]
        if(!vis[vec]){
            DFS(vec);
        }
    }
}

int main()
{
    int n,m;
    fin>>n>>m;
    graf.resize(n+1);
    for(int i=0;i<m;i++){
        int nod1,nod2;
        fin>>nod1>>nod2;
        graf[nod1].push_back(nod2);
        graf[nod2].push_back(nod1);//daca e orientat nu mai am asta
    }
    int cont=0;
    for(int nod=0;nod<n;nod++){
        if(!vis[nod]){
            cont++;
            DFS(nod);
        }
    }
    fout<<cont;

    return 0;
}
