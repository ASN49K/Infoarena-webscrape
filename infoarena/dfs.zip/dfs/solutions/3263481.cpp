#include <fstream>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

#define NMAX 100005

vector<int> G[NMAX];
bool viz[NMAX];

void dfs(int nod) {
    viz[nod] = 1;

    for (auto it : G[nod]) {
        if (!viz[it]) {
            dfs(it);
        }
    }
}

int main() {
    int n, m;
    fin >> n >> m;
    while (m--) {
        int x, y;
        fin >> x >> y;

        G[x].push_back(y);
        G[y].push_back(x);
    }

    int nr = 0;
    for (int i = 1; i <= n; ++i) {
        if (!viz[i]) {
            nr++;
            dfs(i);
        }
    }

    fout << nr;
    return 0;
}
