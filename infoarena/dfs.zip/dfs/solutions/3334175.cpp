#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
#include <list>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n,m,sol;
const int M=100005;
list<int>vecini[100005];
bitset<M> v;
void dfs(int x)
{
    cout<<x;
    v[x]=1;
    for(auto node : vecini[x])
    {
        if(v[node]==0)
            dfs(node);

    }
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        vecini[x].push_back(y);
        vecini[y].push_back(x);
    }
    cout<<"ok";
    for(int i=1;i<=n;i++)
    {
        if(v[i]==0)
        {
            sol++;
        dfs(i);
        }

    }
    fout<<sol;
    return 0;
}
