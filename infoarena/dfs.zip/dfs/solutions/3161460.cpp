#include<fstream>
#include<vector>
#define dim 100001
using namespace std;
ifstream in ("dfs.in");
ofstream out("dfs.out");
vector<int> graf[dim];
bool viz[dim];
int n, m, x, y, nr;
void dfs(int k) {
    viz[k] = 1;
    /// parcurg lista de adiacenta a lui k
    for (int i = 0; i < graf[k].size(); i++) {
        int vecin = graf[k][i];
        if (viz[vecin] == 0)
            dfs(vecin);
    }
}
int main() {
    in >> n >> m;
    for (int i = 1; i <= m; i++) {
        in >> x >> y;
        graf[x].push_back(y);
        graf[y].push_back(x);
    }
    for (int i = 1; i <= n; i++)
        if (viz[i] == 0) { /// gasesc o noua componenta conexa
            nr++;
            dfs(i);
        }
    out << nr;
}
