#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
vector <int> v[100005];
queue <int> q;
int d[100005],n,m,s;
void dfs(int s)
{
    //q.push(s);
        for (int i : v[s])
        {
            if (d[i]==0)
            {
                d[i]=1;
                dfs(i);
            }
        }
}
int main()
{
    fin>>n>>m>>s;
    for (int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    int ans=0;
    for (int i=1;i<=n;i++)
    {
        if (!d[i]) d[i]=1,ans++,dfs(i);
    }
    fout<<ans;
    return 0;
}
