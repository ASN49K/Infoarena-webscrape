#include <fstream>
#include <vector>

using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

int n,m,x,y,comp = 0;
vector<int> visited;
vector<vector<int>> adj;

void dfs(int nod){
    visited[nod] = 1;
    for(auto& neigh: adj[nod]){
        if(visited[neigh] == 0){
            dfs(neigh);
        }
    }
}
int main(){
    f >> n >> m;
    adj.resize(n+1, vector<int>());
    visited.resize(n+1, 0);
    for(int i=1; i<=m; i++){
        f >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    for(int i=1; i<=n; i++){
        if(visited[i] == 0){
            comp++;
            dfs(i);
        }
    }
    g << comp;

    return 0;
}