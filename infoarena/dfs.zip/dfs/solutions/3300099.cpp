#include <bits/stdc++.h>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");

const int maxn = 100000;
vector<int> adj[maxn];
bool vis[maxn];

void dfs( int parinte )
{
    for( auto copil : adj[parinte] )
    {
        if( vis[copil] == false )
        {
            vis[copil] = true;
            dfs( copil );
        }
    }
}

int main()
{
    int n, m;
    f >> n >> m;
    for( int i = 1; i <= n; ++i )
        vis[i] = false;
    for( int i = 1; i <= m; ++i )
    {
        int x, y;
        f >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    int ans = 0;
    for( int i = 1; i <= n; ++i )
    {
        if( vis[i] == false )
        {
            ++ans;
            dfs(i);
        }
    }
    g << ans;
	return 0;
}
