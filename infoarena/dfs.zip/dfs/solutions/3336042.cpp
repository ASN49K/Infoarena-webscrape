#include <fstream>
#include <queue>
using namespace std;
ifstream cin("dfs.in");
ofstream cout("dfs.out");

vector<vector<int>> la;
queue<int> q;
vector<bool> visited;
vector<int> niv;

void dfs(int s, int n) {
    visited[s] = true; 
    for(int neighbour : la[s]) {
        if(!visited[neighbour]) {
            dfs(neighbour, n);
        }
    }
}

int main() {
    int n, m, x, y;
    cin >> n >> m;
    la.assign(n + 1, {});
    visited.assign(n + 1, 0);

    for(int i = 1; i <= m; i++) {
        cin >> x >> y;
        la[x].push_back(y);
        la[y].push_back(x);
    }

    int c = 0;
    for(int s = 1; s <= n; s++) 
        if(!visited[s]) {
            dfs(s, n);
            c++;
        }

    cout << c;
    return 0;
}