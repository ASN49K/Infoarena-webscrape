// BFS si DFS
#include <bits/stdc++.h>
#define NMAX 1e7
using namespace std;
ifstream fin ("dfs.in");
ofstream fout ("dfs.out");
int N, M, S;
vector<vector<int>> A;
vector<int> k; //nr de cate ori a fost vizitat
queue<int> Q;

void read() {
    fin>>N>>M;
    A.resize(N+1);
    k.resize(N+1, -1);
    for (int i=1; i<=M; i++) {
        int x, y;
        fin>>x>>y;
        A[x].push_back(y);
        A[y].push_back(x);

    }
}

void bfs(int s) {
    Q.push(s);
    k[s] = 0;
    int current = s;
    while(!Q.empty()) {
        current = Q.front();
        Q.pop();
        for(int neighbor:A[current]) {
            if(k[neighbor] == -1) {
                Q.push(neighbor);
                k[neighbor] = k[current] + 1;
            }
        }
    }
}


void dfs(int s) {
    for (int i:A[s]) {
        if(k[i] == -1) {
            k[i] = k[s] + 1;
            dfs(i); 
        }
    }
}

int main() {

    read();
    int cc = 0; //componente conexe
    
    for(int i=1;i<=N;i++) {
        if(k[i] == -1) {
            k[i] = 0;
            dfs(i);
            cc++;
        }
    }
    fout << cc;

    return 0;

}