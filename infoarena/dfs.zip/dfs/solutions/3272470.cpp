#include <fstream>
#include <queue>

using namespace std;

const int nmax=100001;

struct nod
{
    int vec;
    nod *urm;
};

int n,nrcc;
nod *L[nmax];
bool viz[nmax];
queue<int> q;

ifstream f("dfs.in");
ofstream g("dfs.out");

void add_nod(int x,int y)
{
    nod *p=new nod;
    p->vec=y;
    p->urm =L[x];
    L[x]=p;
}

void citire()
{
    int m,x,y;
    f>>n>>m;
    while(m--)
    {
        f>>x>>y;
        add_nod(x,y);
        add_nod(y,x);
    }
}

void DFS(int i)
{
    viz[i]=1;
    for(nod *p =L[i];p!=NULL;p=p->urm)
        if(viz[p->vec]==0)
            DFS(p->vec);
}

int main()
{
    citire();
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            nrcc++;
            DFS(i);
        }
    }
    g<<nrcc;
    f.close();
    g.close();
    return 0;
}
