#include <fstream>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int N = 100005;
vector<int> G[N];
bool viz[N];
int n, m;

void dfs(int nod) {
    viz[nod] = true;
    for (int vecin : G[nod])
        if (!viz[vecin])
            dfs(vecin);
}

int main() {
    fin >> n >> m;
    for (int i = 0; i < m; i++) {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    int componente = 0;
    for (int i = 1; i <= n; ++i) {
        if (!viz[i]) {
            componente++;
            dfs(i);
        }
    }

    fout << componente << "\n";
    return 0;
}