#include <fstream>
using namespace std;
ifstream fin ("dfs.in");
ofstream fout ("dfs.out");
int main()
{
    long long n,m,a,b,i,raspuns=0;
    fin >> n >> m;
    int g[n+1][m+1];
    for (i=1;i<=n;i++)
    {
        g[i][i]=1;
    }
    for (i=1;i<=m;i++)
    {
        fin >> a >> b;
        g[a][b]=1;
        g[b][a]=1;
        g[a][a]=0;
        g[b][b]=0;
    }
    for (i=1;i<=n;i++)
    {
        for (int j=1;j<=n;j++)
        {
            if (g[i][j]==1 && j<i)
            {
                break;
            }
            else if (g[i][j]==1 && i<=j)
            {
                raspuns++;
                break;
            }
        }
    }
    fout << raspuns;
    return 0;
}
