#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;
ifstream cin ("dfs.in");
ofstream cout ("dfs.out");

void dfs(vector<vector<int>> &adiacenta, int startNode, vector<int> &viz){
    viz[startNode] = 1;
    for (auto x : adiacenta[startNode]){
        if (viz[x]==0)
        dfs(adiacenta, x, viz);
    }
}

int main(){
    int nrNoduri,i,j,cc=0, nrMuchii;
    cin>>nrNoduri>>nrMuchii;
    vector<vector<int>> adc(nrNoduri+1);
    vector<int>viz(nrNoduri+1,0);
    while(cin>>i>>j){
        if (find(adc[i].begin(), adc[i].end(),j)==adc[i].end()){
            adc[i].push_back(j);
            adc[j].push_back(i);
        }
    }
    for (i=1; i<adc.size(); i++){
        if (viz[i]==0){
            cc++;
            dfs(adc,i,viz);
        }
    }
    cout<<cc;
    return 0;
}