#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
vector<int> viz;
vector<vector<int>> adj;
void dfs(int start){
    viz[start] = 1;
    for(int vecin : adj[start]){
        if(!viz[vecin]){
            dfs(vecin);
        }
    }
}
int main(){
    int n,m;
    fin >> n >> m;
    adj.resize(n+1);
    viz.resize(n+1, 0);
    while(m--){
        int a,b;
        fin >> a >> b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    int cnt = 0;
    for(int i = 1; i<=n; i++){
        if(viz[i] == 0) {
            dfs(i);
            cnt++;
        }
    }
    fout << cnt;
    return 0;
}