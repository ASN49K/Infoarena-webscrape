#include <fstream>
#include <queue>
using namespace std;

ifstream cin ("dfs.in");
ofstream cout ("dfs.out");

struct nod {
    int nr;
    nod *urm;
};

nod *gf[100002];

int n,m,xy,zz,nrcnx;
int viz[100002];
queue<int> q;

void adaug(int x,int y) {
    nod *q=new nod;
    q->nr=y;
    q->urm=gf[x];
    gf[x]=q;
}

int vizitare(int &zz) {
    for (int i=zz; i<=n; i++) {
        if (!viz[i]) {
            zz=i;
            return i;
        }
    }
    return 0;
}

void bfs() {
    nrcnx=0;
    zz=1;
    xy=vizitare(zz);
    while (xy) {
        q.push(xy);
        viz[xy]=1;
        while (!q.empty()) {
            int vf=q.front();
            q.pop();
            for (nod *o=gf[vf]; o; o=o->urm) {
                if (!viz[o->nr])  {
                    viz[o->nr]=1;
                    q.push(o->nr);
                }
            }
        }
        nrcnx++;
        xy=vizitare(zz);
    }
}

int main() {
    int x,y;
    cin>>n>>m;
    for (int i=0; i<m; i++) {
        cin>>x>>y;
        adaug(x,y);
        adaug(y,x);
    }
    bfs();
    cout<<nrcnx;
}