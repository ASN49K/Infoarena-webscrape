#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin ("dfs.in");
ofstream fout ("dfs.out");

int n,m;
bool viz[100002];
vector <int> adj[100002];

void dfs(int x)
{
    viz[x]=1;
    for(auto vec : adj[x])
        if(viz[vec]==0)
            dfs(vec);
}

int main()
{
    int i,j,nrcomp=0;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(viz[i]==0)
        {
            nrcomp++;
            dfs(i);
        }
    fout<<nrcomp;
    return 0;
}
