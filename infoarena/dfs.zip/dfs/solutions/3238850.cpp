#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

long long n, m, x, y, cnt, viz[100002];

vector<int> v[100002];

void DFS(int st)
{
    viz[st]=1;
    for(auto i:v[st])
    {
        if(!viz[i])
            DFS(i);
    }
}

int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
    {
        if(!viz[i])
        {
            DFS(i);
            cnt++;
        }
    }
    cout<<cnt;
}
