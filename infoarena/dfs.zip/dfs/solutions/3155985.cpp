#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("dfs.in");
ofstream out("dfs.out");

const int NMAX = 1e5 + 1;

vector <int> G[NMAX];

int d[NMAX];

bool vis[NMAX];

void DFS(int x)
{
    vis[x] = true;
    for(auto i : G[x])
    {
        if(!vis[i])
        {
            DFS(i);
        }
    }
}

int main(int argc, const char * argv[]) {
    // insert code here...
    int n,m;
    in >> n >> m;
    for(int i = 0; i < m; i++)
    {
        int x,y;
        in >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    int nc = 0;
    for(int i = 1; i <= n; i++)
    {
        if(!vis[i])
        {
            nc++;
            DFS(i);
        }
    }
    out << nc;
    in.close();
    out.close();
    return 0;
}
