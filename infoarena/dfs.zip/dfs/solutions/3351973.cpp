#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>

using namespace std;

string filename = "dfs";
ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

const int NMAX = 1e5;
vector<int> adj[NMAX + 5];
bool visited[NMAX + 5];

void dfs(int nod)
{
    visited[nod] = true;
    for(auto it : adj[nod])
    {
        if(visited[it]==false)
            dfs(it);
    }
}

int main()
{
    int n,m;
    fin>>n>>m;
    for(int i=1;i<=n;i++)
    {
        int u,v;
        fin>>u>>v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    int ans = 0;
    for(int i=1;i<=n;i++)
    {
        if(visited[i]==false)
        {
            ans++;
            dfs(i);
        }
    }
    fout<<ans;
    return 0;
}
