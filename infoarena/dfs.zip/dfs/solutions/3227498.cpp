#include <iostream>
#include <fstream>
#include <algorithm>
#include <set>
#include <vector>
#define NMAX 100001

using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

int n, m, nc;
vector<vector<int>> v(NMAX);
///vector<set<int>> compcon(NMAX);
vector<bool> viz(NMAX, 0);

void dfs(int x)
{
	viz[x] = 1;
	///compcon[nc].insert(x);
	for (int i = 0; i < v[x].size(); ++i)
		if (!viz[v[x][i]]) dfs(v[x][i]);
}

int main()
{
	int i, x, y;
	f >> n >> m;
	while (m--)
	{
		f >> x >> y;
		v[x].push_back(y);
		v[y].push_back(x);
	}
	for (i = 1; i <= n; i++)
		if (!viz[i])
		{
			++nc;
			dfs(i);
		}
	g << nc << '\n';
	/**for (i = 1; i <= nc; i++)
	{
		for (set<int> :: iterator it = compcon[i].begin(); it != compcon[i].end(); ++it)
			g << *it << ' ';
		g << '\n';
	}*/
	return 0;
}
