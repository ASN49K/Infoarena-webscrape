#include <fstream>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<int> graf[10001];
bool vizitat[10001];
int N, M;

void dfs(int nod) {
    vizitat[nod] = true;

    for (int vecin : graf[nod]) {
        if (!vizitat[vecin]) {
            dfs(vecin);
        }
    }
}

int main() {
    fin>>n>>m;

    for (int i = 0; i < m; i++) {
        int x, y;
        fin >> x >> y;
        graf[x].push_back(y);
        graf[y].push_back(x);
    }

    int componente = 0;
    for (int i = 1; i <= n; i++) {
        if (!vizitat[i]) {
            dfs(i);
            componente++;
        }
    }

    fout << componente << "\n";



    return 0;
}
