#include <bits/stdc++.h>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int nlim=100005;
vector <int> muchii[nlim];
bool viz[nlim];

int n,m,ins=0;

void dfs(int nod)
{
    viz[nod]=true;
    for(unsigned int i=0; i<muchii[nod].size(); i++)
    {
        int vv=muchii[nod][i];
        if(!viz[vv])
        {
            dfs(vv);
        }
    }
}
void citire()
{
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x,y;
        fin>>x>>y;
        muchii[x].push_back(y);
        muchii[y].push_back(x);
    }
    for(int i=1; i<=n; i++)
    {
        if(!viz[i])
        {
            ins++;
            dfs(i);

        }
    }
}
int main()
{
citire();
fout<<ins<<endl;
}
