#include <bits/stdc++.h>

using namespace std;

vector<vector<int>> adj;
vector<int> viz;
int nr;

void dfs(int node)
{
    viz[node]=1;
    nr++;
    for(auto it:adj[node])
    {
        if(!viz[it])
        {
            dfs(it);
        }
    }
}

int main () 
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    freopen("dfs.in","r",stdin);
    freopen("dfs.out","w",stdout);
    int n,m,x,y;
    cin>>n>>m;
    adj.resize(n+1);
    viz.resize(n+1,0);
    for(int i=1; i<=m; i++)
    {
        cin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    dfs(1);
    cout<<nr;
}
