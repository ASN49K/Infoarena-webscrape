#include<iostream>
#include<fstream>
#include<vector>
using namespace std;
const int NMAX=100001;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

bool viz[NMAX];
vector<int>v[NMAX];
int n,m,ok;

void dfs(int x)
{
    viz[x]=1;
    for(const int &i:v[x])
        if(viz[i]==0)
            dfs(i);
}

int main()
{
    int x,y;
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }

    for(int i=1; i<=n; i++)
        if(viz[i]==0)
        {
            ok++;
            dfs(i);
        }

    fout<<ok;

    fin.close();
    fout.close();
    return 0;
}
