import sys
sys.setrecursionlimit(1000_000)

def dfs(node, graph, visited):
    if node in visited:
        return
    visited.add(node)
    for neighbour in graph[node]:
        dfs(neighbour, graph, visited)


def main():
    fin = open('dfs.in', 'r')
    fout = open('dfs.out', 'w')

    input = fin.readline


    n, m = map(int, input().split())
    graph = [[] for _ in range(n+1)]

    for _ in range(m):
        u, v = map(int, input().split())
        graph[u].append(v)
        graph[v].append(u)
    
    visited = set()
    count = 0
    for node in range(1, n+1):
        if node not in visited:
            dfs(node, graph, visited)
            count += 1

    fout.write(str(count))

    fin.close()
    fout.close()

main()