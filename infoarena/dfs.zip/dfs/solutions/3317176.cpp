#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");


int N, M;
bool vizitat[100000 + 5];
vector<int> lista_adiacenta[100000 + 5];
int nr_componente_conexe;

void dfs(int nod) {
    vizitat[nod] = true;
    for (auto vecin : lista_adiacenta[nod]) {
        if (!vizitat[vecin]) {
            dfs(vecin);
        }
    }
}
int main() {
    fin >> N >> M;
    for (int i = 1; i <= M; i++) {
        int x, y;
        fin >> x >> y;
        lista_adiacenta[x].push_back(y);
        lista_adiacenta[y].push_back(x);
    }
    for (int i = 1; i <= N; i++) {
        if (!vizitat[i]) {
            nr_componente_conexe++;
            dfs(i);
        }
    }
    fout << nr_componente_conexe << "\n";
    return 0;
}

