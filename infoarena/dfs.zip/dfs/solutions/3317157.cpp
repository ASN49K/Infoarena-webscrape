#include <vector>
#include <fstream>
#include <iostream>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int v[100000];
vector<vector<int>> m(100000);
int n,muchii;
void dfs(int nod){
    v[nod] =1;
    for (auto i : m[nod]){
        if (v[i] == 0){
            dfs(i);
        }
    }
}

int main()
{
    fin>>n>>muchii;
    
    for (int i =0; i<muchii; i++){
        
        int x, y;
        fin>>x>>y;
        m[x].push_back(y);
        m[y].push_back(x);
    }
    int cnt=0;
    for (int i=1; i<=n; i++){
        if (v[i] == 0){
            dfs(i);
            cnt++;       
        }
    }
    fout<<cnt;

    return 0;
}