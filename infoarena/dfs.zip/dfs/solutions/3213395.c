#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define N 100000
#define M 200000

typedef struct
{
    int vf, urm;
} element;

element v[2*M+1];
int lst[N+1], nv;
bool viz[N+1];

void adauga(int x, int y)
{
    ///functia il adauga pe y in lista de adiacenta a lui x
    ++nv;
    v[nv].vf = y;
    v[nv].urm = lst[x];
    lst[x] = nv;
}

void dfs(int x)
{
    viz[x] = true;
    ///parcurgem lista vecinilor lui x
    for (int p = lst[x]; p != 0; p = v[p].urm)
    {
        int y = v[p].vf;
        if (!viz[y])
        {
            dfs(y);
        }
    }
}

int main()
{
    FILE *in, *out;
    in = fopen("dfs.in", "r");
    out = fopen("dfs.out", "w");
    int n, m;
    fscanf(in, "%d%d", &n, &m);
    for (int i = 0; i < m; i++)
    {
        int x, y;
        fscanf(in, "%d%d", &x, &y);
        adauga(x, y);
        adauga(y, x);
    }
    int nr_c = 0;
    for (int i = 1; i <= n; i++)
    {
        if (!viz[i])
        {
            ++nr_c;
            dfs(i);
        }
    }
    fprintf(out, "%d\n", nr_c);
    fclose(in);
    fclose(out);
    return 0;
}
