#include <bits/stdc++.h>

using namespace std;

ifstream fin ("dfs.in");
ofstream fout ("dfs.out");

vector <int> v[100005];
int n, m, nr, x, y;
bool fr[100005];


void df (int x)
{
    fr[x]=true;
    for (auto i:v[x])
    {
        if (!fr[i])
            df(i);
    }
}

int main()
{
    fin >> n >> m;
    for (int i=1; i<=m; i++)
    {
        fin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    for (int i=1; i<=n; i++)
    {
        if (!fr[i])
        {
            nr++;
            df(i);
        }
    }
    fout << nr;
    return 0;
}
