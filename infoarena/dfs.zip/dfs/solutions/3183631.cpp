#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");


int viz[100000];
vector<int>v[100000];

void dfs(int x)
{
    viz[x]=1;
    for(int i=0;i<v[x].size();i++)
        if(!viz[v[x][i]])
            dfs(v[x][i]);
}


int main()
{
    int n,m;
    fin>>n>>m;
    
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    
    int cnt=0;
    
    for(int i=1;i<=n;i++)
        if(!viz[i])
        {
            dfs(i);
            cnt++;
        }
    
    fout<<cnt;
}
