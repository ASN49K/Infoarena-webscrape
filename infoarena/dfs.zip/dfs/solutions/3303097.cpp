#include <bits/stdc++.h>

using namespace std;
vector<int>vecini[100005];
bool viz[100005];
int rasp=0;
void dfs(int nod)
{
    queue<int>q;
    q.push(nod);
    rasp++;
    while(!q.empty())
    {
        int nod_curent=q.front();
        viz[nod_curent]=1;
        q.pop();
        for(auto vecin: vecini[nod_curent])
        {
            if(!viz[vecin])
                q.push(vecin);
        }
    }
}
int main()
{
    ifstream cin("dfs.in");
    ofstream cout("dfs.out");
    int noduri, muchii,a,b;
    cin>>noduri>>muchii;
    for(int i=1; i<=muchii; i++)
    {
        cin>>a>>b;
        vecini[a].push_back(b);
        vecini[b].push_back(a);
    }
    for(int i=1; i<=noduri; i++)
    {
        if(!viz[i])
            dfs(i);
    }
    cout<<rasp;
    return 0;
}
