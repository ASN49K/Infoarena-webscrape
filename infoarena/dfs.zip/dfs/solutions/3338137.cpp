#include <fstream>

using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

int n;
bool A[101][101], viz[101];

void citire()
{
    int m, x, y;
    f >> n >> m;
    while (m--)
    {
        f >> x >> y;
        A[x][y] = A[y][x] = 1;
    }
}

void DFS(int nod)
{
    viz[nod] = 1;
    for (int i = 1; i <= n; i++)
        if (A[nod][i] && !viz[i])
            DFS(i);
}

int main()
{
    int nrCC = 0;
    citire();

    for (int i = 1; i <= n; i++)
        if (!viz[i])
        {
            nrCC++;
            DFS(i);
        }

    g << nrCC;

    f.close();
    g.close();
    return 0;
}
