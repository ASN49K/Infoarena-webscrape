#include <iostream>
#include <fstream>
using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

struct GNMA
{
    int n, m;
    int A[100][100];
};

GNMA G;
int viz[100];

void CitireDate()
{
    f >> G.n >> G.m;
    int x, y;
    f >> x >> y;
    while (x != 0 && y != 0)
    {
        G.A[x][y] = 1;
        G.A[y][x] = 1;
        f >> x >> y;
    }
}

void ParcurgereInAdancime(int x, int numarcompConexa)
{
    viz[x] = numarcompConexa;
    for (int nod = 1; nod <= G.n; nod++)
        if (viz[nod] == 0 && G.A[x][nod] == 1)
            ParcurgereInAdancime(nod, numarcompConexa);
}

int main()
{
    CitireDate();

    int numarComponenteConexe = 0;
    for (int nod = 1; nod <= G.n; nod++)
    {
        if (viz[nod] == 0)
        {
            numarComponenteConexe++;
            ParcurgereInAdancime(nod, numarComponenteConexe);
        }
    }

    g << numarComponenteConexe;
}
