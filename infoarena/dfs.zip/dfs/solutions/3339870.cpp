//#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream cin("dfs.in");
ofstream cout("dfs.out");
vector<vector<int>> adj;
vector<bool> viz;
void DFS(int start)
{
    for(int vecin:adj[start])
        if(!viz[vecin])
        {
            viz[vecin] = 1;
            DFS(vecin);
        }
    return;
}
int main()
{
    int n,m,rez=0;
    cin>>n>>m;
    adj.resize(n+1);
    viz.resize(n+1);
    fill(viz.begin(),viz.end(),0);
    for(int i=0;i<m;i++)
    {
        int x,y;
        cin>>x>>y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
    {
        if(!viz[i])
        {
            rez++;
            DFS(i);
        }
    }
    cout<<rez;
    return 0;
}
