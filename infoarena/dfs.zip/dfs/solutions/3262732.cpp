#include <fstream>
#include <vector>
#include <algorithm>
#define NMAX 120

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, start;
vector <int> a[NMAX];
bool viz[NMAX]; //viz[i]=1, daca varful i  a fost vizitat, 0 in caz contrar
void citire();
void dfs(int x);

int main()
{
 citire();
 dfs(start);

    return 0;
}

 void citire()
{int i, j, k, m;
 fin>>n>>m>>start;
 for(k=0; k<m; k++)
    {fin>>i>>j;
     a[i].push_back(j);
     a[j].push_back(i);
    }
 for(i=1; i<=n; i++)
     sort(a[i].begin(), a[i].end());
}

 void dfs(int x)
{int i;
 fout<<x<<' '; viz[x]=1;
 //parcurg vecinii varfului x
 for(i=0; i<a[x].size(); i++)
    if(!viz[a[x][i]]) dfs(a[x][i]);
}
