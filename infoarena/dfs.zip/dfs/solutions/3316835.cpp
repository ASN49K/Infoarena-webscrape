#include <iostream>
#include <fstream>
#define N 101

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int a[N][N], n, m;
bool viz[N];
int p;

void citire()
{   int x, y;
    fin>>n>>m>>p;
    for(int i=1; i<=m; i++)
    {  fin>>x>>y;
        if(!a[x][y]) a[x][y]=a[y][x]=1;
    }
}

void dfs(int x)
{   viz[x]=1;
    fout<<x<<" ";
    for(int i=1; i<=n; i++)
        if(a[x][i] && !viz[i]) dfs(i);
}

int main()
{   citire();
    int componente = 0;
    for(int i=1; i<=n; i++)
        if(!viz[i]) {
            dfs(i);
            componente++;
        }
    fout<<componente;
    return 0;
}