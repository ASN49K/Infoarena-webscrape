#include <fstream>
#include <iostream>
#include <stack>
#include <vector>

using namespace std;

fstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m;
vector<vector<int>> nodes;
vector<int> viz;
stack<int> s;
int cnt = 0;

void dfs(int start) {
  vector<int> index(n + 1, 0);
  stack<int> st;
  st.push(start);
  viz[start] = 1;

  while (!st.empty()) {
    int x = st.top();
    if (index[x] < nodes[x].size()) {
      int neigh = nodes[x][index[x]];
      index[x]++;
      if (!viz[neigh]) {
        viz[neigh] = 1;
        st.push(neigh);
      }
    } else {
      st.pop();
    }
  }
}

void sol() {
  for (int i = 1; i <= n; i++) {
    if (!viz[i]) {
      cnt++;
      dfs(i);
    }
  }
}

int main() {
  fin >> n >> m;

  nodes.resize(n + 1);
  viz.resize(n + 1);

  int x, y;
  for (int i = 1; i <= n; i++) {
    fin >> x >> y;
    nodes[x].push_back(y);
    nodes[y].push_back(x);
  }

  sol();
  fout << cnt << '\n';
}
