#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream in("dfs.in");
ofstream out("dfs.out");
vector<vector<int>> graf;
vector<int> vis;
void DFS (int nod)
{
    vis[nod]=true; //=1
    for(int vec:graf[nod])
        if( !vis[vec] )
        {
            DFS(vec);
        }
}
int main()
{
    int n,m;
    in>>n>>m;
    vis.resize(n+1);
    graf.resize(n+1);
    for(int i=0; i<m; ++i)
    {
        int node1, node2;
        in>>node1>>node2;
        graf[node1].push_back(node2);
        graf[node2].push_back(node1);
    }
    int cnt=0;
    for(int i=1; i<=n; ++i)
    {
        if(!vis[i])
        {
            DFS(i);
            cnt++;
        }
    }
    out<<cnt;
    return 0;
}
