#include <fstream>
#include <vector>
#include <algorithm>
#define NMAX 1000005
using namespace std;
ifstream fin ("dfs.in");
ofstream fout ("dfs.out");

int n, m, nrc;
vector<int> G[NMAX];
bool viz[NMAX]; //viz[i]=1 daca vf i a fost vizitat, 0 in caz contrar

void citire();
void dfs(int x);

int main()
{
    int i;
    citire();
    for (i=1; i<=n; i++)
    if(!viz[i]) {nrc++; dfs(i);}
    fout<<nrc;
    return 0;
}

void citire()
{
    int i, j, k;
    fin>>n>>m;
    for (k=0; k<m; k++)
    {
        fin>>i>>j;
        G[i].push_back(j);
        G[j].push_back(i);
    }
/*for (i=1; i<=n; i++)
    sort(G[i].begin(), G[i].end()); */
}
void dfs(int x)
{
    int i;
    //fout<<x<<' ';
    viz[x]=1;
    //parcurg vecinii vf x
    for (i=0; i<G[x].size(); i++)
        if(!viz[G[x][i]])
           dfs(G[x][i]);
}
