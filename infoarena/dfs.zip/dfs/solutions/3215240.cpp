#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");

const int DMAX = 100001;

vector<int> AdjList[DMAX];
vector<bool> viz(DMAX, false);
int n, m;

void citire()
{
    f >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        f >> x >> y;
        AdjList[x].push_back(y);
        AdjList[y].push_back(x);
    }
}

void DFS(int nod)
{
    viz[nod] = true;
    for (int i = 0; i < AdjList[nod].size(); i++)
        if(viz[AdjList[nod][i]] == false)
            DFS(AdjList[nod][i]);
}

int main()
{
    citire();
    int nrcomp = 0;
    for(int i = 1; i <= n; i++)
        if(viz[i] == 0)
        {
            nrcomp++;
            DFS(i);
        }
    g << nrcomp;
    return 0;
}
