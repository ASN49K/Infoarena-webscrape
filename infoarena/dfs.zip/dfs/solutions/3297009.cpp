#include<bits/stdc++.h>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n,m,vizit[100002];
vector<int> g[100002];

void DFS(int nod){
vizit[nod]=1;
for(auto e : g[nod])
    if(!vizit[e])
        DFS(e);
}

int main(){

    int i,x,y,nr=0;

    fin>>n>>m;

    for(i=1;i<=m;i++){
        fin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }

    for(i=1;i<=n;i++){
        if(!vizit[i]){
            nr++;
            DFS(i);
        }
    }

    fout<<nr;

}
