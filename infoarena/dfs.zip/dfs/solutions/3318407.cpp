#include <fstream>
#include <vector>

#define MAX_N 100005

std::vector<int> adj[MAX_N];
bool visited[MAX_N];
int connected_components = 0;

void dfs(int node) {
    visited[node] = true;

    for (int neighbor : adj[node]) {
        if (!visited[neighbor]) {
            dfs(neighbor);
        }
    }
}

int main() {
    std::ifstream fin("dfs.in");
    std::ofstream fout("dfs.out");

    int n, m;
    fin >> n >> m;

    for (int i = 0; i < m; i++) {
        int u, v;
        fin >> u >> v;

        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    for (int i = 1; i <= n; i++) {
        if (!visited[i]) {
            dfs(i);
            connected_components++;
        }
    }

    fout << connected_components << '\n';

    fin.close();
    fout.close();
}
