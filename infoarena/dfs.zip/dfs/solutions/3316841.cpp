#include <bits/stdc++.h>
#include <fstream>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<int> L[101];
vector<bool> viz(101, false);

void dfs(int nod, int cnt)
{
    viz[nod] = true;
    for(auto vecin: L[nod])
    {
        if(!viz[vecin])
        {
            dfs(vecin, cnt);
        }
    }
}

int main()
{
    int n, m, cnt = 0;

    fin >> n >> m;

    for(int i = 1; i <= m; i ++)
    {
        int x, y;
        fin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }

    for(int i = 1; i <= n; i ++)
    {
        sort(L[i].begin(), L[i].end());
        L[i].erase(unique(L[i].begin(), L[i].end()), L[i].end());
    }

    for(int i = 1; i <= n; i ++)
    {
        if(!viz[i])
            dfs(i, ++cnt);
    }

    fout << cnt;

    return 0;
}