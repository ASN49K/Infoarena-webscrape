#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
const int Nmax = 100005;
int N,M;
vector<int> Muchii[Nmax];
bool vizitat[Nmax];
int insule=0;
void DFS(int nod){
    vizitat[nod]= true;
    for(unsigned int i=0; i <= Muchii[N].size();i++){
        int vecin= Muchii[nod][i];
        if(!vizitat[vecin]){
            DFS(vecin);
        }
    }

}

void citire(){
    fin>>N>>M;
    for(int i=1; i<=M; i++){
        int x,y;
        fin>>x>>y;
        Muchii[x].push_back(y);
        Muchii[y].push_back(x);    }

    for(int i=1; i<=N; i++){
            if(!vizitat[i]){
                insule++;
                DFS(i);
            }
    }
}
int main()
{
    citire();
    fout<<insule<<endl;
    return 0;
}
