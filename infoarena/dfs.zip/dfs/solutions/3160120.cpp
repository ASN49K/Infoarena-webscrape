#include <bits/stdc++.h>
#define N 100000
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m;
vector<int> graf[N + 5];
bitset<N + 5> viz;
int ct_comp;

void Citire()
{
    int x, y;
    fin >> n >> m;
    for(int i = 1; i <= m; ++i)
    {
        fin >> x >> y;
        graf[x].push_back(y);
        graf[y].push_back(x);
    }
}

void DFS(int x)
{
    viz[x] = 1;
    for(int i= 0; i < graf[x].size(); ++i)
        if(!viz[graf[x][i]])
            DFS(graf[x][i]);
}

void Rezolvare()
{
    for(int i = 1; i <= n; ++i)
        if(!viz[i])
    {
        DFS(i);
        ct_comp++;
    }

    fout << ct_comp;
}

int main()
{
   Citire();
   Rezolvare();

    return 0;
}
