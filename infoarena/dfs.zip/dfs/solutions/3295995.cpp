#include <algorithm>
#include <iostream>
#include <fstream>
#include <climits>
#include <vector>
#include <stack>
#include <cmath>
#include <bitset>
// #include <bits/stdc++.h>
#define in  fin
#define out fout

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<int> v[100001];
bitset<100001> m;

void dfs(int nod){
    m[nod] = 1;
    for(const int & cop : v[nod]){
        if(!m[cop]) dfs(cop);
    }
}

signed main(){
    ios_base::sync_with_stdio(false);
    in.tie(NULL);

    int n, nn; in >> n >> nn;
    for(int i = 0; i < nn; i++){
        int a, b; in >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }

    int cnt = 0;
    for(int i = 1; i <= n; i++){
        if(!m[i]){
            cnt++;
            dfs(i);
        }
    }

    out << cnt << '\n';


    return 0;
}