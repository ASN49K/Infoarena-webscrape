//
//  main.cpp
//  DFS comp conexe
//
//  Created by Andrada Minca on 05.02.2026.
//

#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("dfs.in");
ofstream cout("dfs.out");
int i,j,n,x,s,y,l[100005],nr,m;
vector<int> v[100001];
int main()
{
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    int nr=0;
    for(int i=1;i<=n;i++)
    {
        if(l[i]==0)
        {
            nr++;
            l[i]=1;
            queue<int> st;
            st.push(i);
            while(!st.empty())
            {
                int nod=st.back();
                for(int j=0;j<v[nod].size();j++)
                {
                    if(l[v[nod][j]]==0){st.push(v[nod][j]);l[v[nod][j]]=1;}
                }
                st.pop();
            }
        }
    }
    cout<<nr;
    return 0;
}
