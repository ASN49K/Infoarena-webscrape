#include <bits/stdc++.h>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int maxDim = 200000;

vector<int> adList[maxDim];

bool viz[maxDim];
int N, M, ans;

void DFS(int n) {
    viz[n] = 1;
    for (int i = 0; i < adList[n].size(); i++)
        if (viz[adList[n][i]] == 0)
            DFS(adList[n][i]);
}

int main() {
    fin >> N >> M;

    for (int i = 1; i <= M; i++) {
        int x, y;
        fin >> x >> y;
        adList[x].push_back(y);
        adList[y].push_back(x);
    }

    for (int i = 1; i <= N; i++)
        if (viz[i] == 0) {
            DFS(i);
            ans++;
        }

   
    fout << ans;

    return 0;
}
