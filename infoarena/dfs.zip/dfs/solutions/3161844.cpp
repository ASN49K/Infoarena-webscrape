#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int nmax = 100003;
int n, m;
bool viz[nmax];
vector <int> g[nmax];

void dfs(int nod);
void read(void);

int main(){
    int i, cnt = 0;
    read();
    for(i = 1; i <= n; i++){
        if(!viz[i]){
            dfs(i);
            cnt++;
            }
        }
    fout<<cnt;
    }

void read(void){
    int i, j;
    
    fin>>n>>m;

    while(m--){
        fin>>i>>j;
        g[i].push_back(j);
        g[j].push_back(i);
        }
    }

void dfs(int nod){
    int i, vecin;
    
    viz[nod] = true;

    for(i = 0; i < g[nod].size(); i++){
        vecin = g[nod][i];
        if(!viz[vecin])
            dfs(vecin);
        }
    }