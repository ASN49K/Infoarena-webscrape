#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector <int> l[100001];
int viz[100001];

void dfs(int nod, int tata)
{
    viz[nod]=1;
    for(int i=0;i<l[nod].size();i++)
    {
        int vecin=l[nod][i];
        if(viz[vecin]==0&&vecin!=tata)
        {
            dfs(vecin, nod);
        }
    }
}

int main()
{
    int n, m, i, x, y, cnx=0;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        l[x].push_back(y);
        l[y].push_back(x);
    }
    for(i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            dfs(i, 0);
            cnx++;
        }
    }
    fout<<cnx;
    return 0;
}
