#include <fstream>
using namespace std;
ifstream fin ("dfs.in");
ofstream fout ("dfs.out");
int main()
{
    long long n,m,a,b,i;
    fin >> n >> m;
    int g[n+1][m+1];
    for (i=1;i<=m;i++)
    {
        fin >> a >> b;
        g[a][b]=1;
        g[b][a]=1;
    }
    fout << m;
    return 0;
}
