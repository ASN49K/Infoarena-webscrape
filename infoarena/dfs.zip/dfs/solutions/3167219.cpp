#include <bits/stdc++.h>
#define NMAX 1000001
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");


long long int N,M, nod_start,x,y, cnt = 0;


vector<int> G[NMAX];
bool viz[NMAX];
queue<int> q;


void citire()
{
    fin>>N>>M;
    for(int i=1;i<=M;i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
    }
}


void DFS(int nod)
{
    viz[nod] = 1;
    for(auto nbs:G[nod])
    {
        if(!viz[nbs])
        {
            DFS(nbs);
        }
    }
}

void afisare()
{
    int i;
    for(i=1;i<=N;i++)
    {
        if(!viz[i])
        {
            cnt++;
            DFS(i);
        }
    }
    fout<<cnt;
}


int main()
{
    citire();
    afisare();
}
