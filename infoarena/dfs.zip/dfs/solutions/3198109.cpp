#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int nmax= 100000;

bool u[nmax+1];
vector <int> v[nmax+1];

void dfs( int x ) {
    u[x]= 1;
    for ( auto it: v[x] ) {
        if ( u[it]==0 ) {
            dfs(it);
        }
    }
}

int main() {
    int n, m;
    fin>>n>>m;

    for ( int i= 0, x, y; i<m; ++i ) {
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }

    int sol= 0;
    for ( int i= 1; i<=n; ++i ) {
        if ( u[i]==0 ) {
            ++sol;
            dfs(i);
        }
    }

    fout<<sol<<"\n";

    return 0;
}
