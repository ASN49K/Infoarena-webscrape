#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");
const int NMAX = 100001;
int s[NMAX];
bool a[NMAX];
vector<vector<int>>G(NMAX);
void bfs(int nod){
    a[nod]=1;
    for(auto y: G[nod])
        if(a[y]==0){
                bfs(y);
        }
}
int main()
{
    int n,m,pctplc,x,y;
    f>>n>>m;
    for(int i = 1; i <= m; i++)
    {
        f >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    int conn=0;
    for(int i=1;i<=n;i++)
        if(a[i]==0)
    {
        //cout<<i<<' ';
        bfs(i);
        conn++;
    }
    g<<conn;
    return 0;
}
