#include <bits/stdc++.h>
#define pb push_back
//#define int long long
using namespace std;
const int N=1e5+5;
vector<int> g[N];
bool vis[N];
void dfs(int node)
{
    vis[node]=1;
    for(auto x:g[node])
    {
        if(vis[x]) continue;
        dfs(x);
    }
}
signed main()
{
    ifstream cin("dfs.in");ofstream cout("dfs.out");
    int n,m;
    cin>>n>>m;
    for(int _=1;_<=m;++_)
    {
        int u,v;cin>>u>>v;
        g[u].pb(v);g[v].pb(u);
    }
    int cnt=0;
    for(int i=1;i<=n;++i)
    {
        if(vis[i]) continue;
        ++cnt;
        dfs(i);
    }
    cout<<cnt;
}
