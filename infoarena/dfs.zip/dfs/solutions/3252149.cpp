#include <bits/stdc++.h>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int viz[100010],n,m,i,j,x,y,z,p,k=0;
vector <int> v[100010];
void dfs(int x)
{
    viz[x]=1;
    for(auto vecin:v[x])
        if(viz[vecin]==0)
            dfs(vecin);
}
int main()
{
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>y>>z;
        v[z].push_back(y);
        v[y].push_back(z);
    }
    for(i=1; i<=n; i++)
        if(viz[i]==0)
        {
            k++;
            dfs(i);
        }
    fout<<k;
    return 0;
}
