#include <fstream>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int nmax=100005;
bool viz[nmax];
vector<int> l[nmax];
void dfs(int nod)
{

    viz[nod]=1;
    for(int j : l[nod])
    {
        if(!viz[j])
           dfs(j);
    }
}


int main()
{
    int n,m,x,nod;
    fin>>n>>m>>x;

    while(m--)
          {
              fin>>x>>nod;
              l[x].push_back(nod);
              l[nod].push_back(x);
          }
    int nrcomp=0;
    for(int i=1;i<=n;i++)
    {  if(viz[i]==false)
         {
           nrcomp++;
           dfs(i);
         }
    }
    fout<<nrcomp;

    return 0;
}
