#include <bits/stdc++.h>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m;
vector<vector<int> > v;
vector<int> b;
void dfs(int i)
{
    b[i]=1;
    for (int j=0; j<v[i].size(); j++){
        if (!b[v[i][j]])dfs(v[i][j]);
    }
}
int main()
{
    fin>>n>>m;
    v.resize(n+1);
    b.resize(n+1);
    for (int i=0; i<m; i++){
        int x, y;
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    int c=1;
    for (int i=1; i<=n; i++){
        if (!b[i]){dfs(i);++c;}
    }
    fout<<c-1;
    return 0;
}
