#include <fstream>
#include <vector>
using namespace std;
ifstream fin ("dfs.in");
ofstream fout("dfs.out");
int viz[100010],n,m,i,c[100010],nr,x,y;
vector<int> V[100010];
void bfs(int start)
{
    int st,dr,nod,vecin;
    st=dr=1;
    viz[start]=1;
    c[st]=start;
    while(st<=dr)
    {
        nod=c[st];
        for(int j=0;j<V[nod].size();j++)
        {
            vecin=V[nod][j];
            if(!viz[vecin])
            {
                c[++dr]=vecin;
                viz[vecin]++;
            }
        }
        st++;
    }
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        V[x].push_back(y);
        V[y].push_back(x);
    }
    for(i=1;i<=n;i++)
    {
        if(!viz[i])
        {
            bfs(i);
            nr++;
        }
    }
    fout<<nr;
    return 0;
}
