#include <bits/stdc++.h>

using namespace std;

const int NMAX = 100000;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m; 
int x, y;
vector <int> Muchii[NMAX+1];
int vizitat[NMAX+1];

void DFS(int x)
{
    vizitat[x] = 1;
    for(int a : Muchii[x])
        if(!vizitat[a])
            DFS(a);
}

int main()
{
    fin >> n >> m;
    for(int i=1; i<=m; i++)
    {
        fin >> x >> y;
        Muchii[x].push_back(y);
        Muchii[y].push_back(x);
    }
    int nrZone = 0;
    for(int i=1; i<=n; i++)
    {
        if(!vizitat[i])
            DFS(i), nrZone++;
    }
    fout << nrZone;
    return 0;
}