#include <fstream>
#include <vector>
using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");
const int N = 200000;
int vizit[N + 1];
vector <int> v[N + 1];
int n, cnx = 1;
long long m;
void citire_graf(int n, long long m)
{
    int i, x, y;
    for(i = 0; i < m; i++)
    {
        cin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
}

void dfs(int nod)
{
    vizit[nod] = 1;
    //printf("%d ", n);
    for(int i = 0; i <= v[nod].size(); i++)
    {
        if(vizit[i] == 0)
        {
            cnx++;
            dfs(i);
        }
    }
}
int main()
{
    cin >> n >> m;
    citire_graf(n, m);
    dfs(1);
    cout << cnx;
    return 0;
}
