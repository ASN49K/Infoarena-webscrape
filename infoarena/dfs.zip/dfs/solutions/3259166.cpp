#include <bits/stdc++.h>

using namespace std;

ifstream fin ("dfs.in");
ofstream fout ("dfs.out");

vector <int> graph[200005];
bool visited[100005];

void dfs(int node){
    visited[node] = 1;
    for (auto x:graph[node]){
        if (visited[x]) continue;
        dfs(x);
    }
}

int main()
{
    int n,m,ans = 0;
    fin >> n >> m;
    for (int i=1;i<=n;++i){
        int x,y;
        fin >> x >> y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }
    for (int i=1;i<=n;++i){
        if (visited[i]==0){
            ans++;
            dfs(i);
        }
    }
    fout << ans;
    return 0;
}
