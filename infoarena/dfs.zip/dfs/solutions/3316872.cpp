
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

// DFS

vector<int> L[101];
int viz[101];


void DFS(int i, int &nr){
    viz[i] = 1;
    for(int j = 0; j < L[i].size(); j++){
        int vecin = L[i][j];
        if(viz[vecin] == 0){
            DFS(vecin, nr);
        }
    }
}


int main()
{
    ifstream cin("dfs.in");
    ofstream cout("dfs.out");

    int n, m;
    cin>>n>>m;
    int x, y;
    while (cin >> x >> y) {
        L[x].push_back(y);
        L[y].push_back(x);
    }

    for(int i = 1; i <= n; i ++)
    {
        sort(L[i].begin(), L[i].end());
        L[i].erase(unique(L[i].begin(), L[i].end()), L[i].end());
    }

    int nr=0;

    for(int i = 1; i <= n; i ++)
    {
        if(!viz[i])
            DFS(i, ++nr);
    }

    cout<<nr;

    return 0;
}

