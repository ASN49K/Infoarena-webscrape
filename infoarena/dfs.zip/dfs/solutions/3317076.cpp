#include <fstream>
#include <vector>
using namespace std;

ifstream in("dfs.in");
ofstream out("dfs.out");

const int MAXN = 100001;
static vector<int> lista[MAXN];
bool viz[MAXN];
int n, m;

void dfs(int u) {
    viz[u] = true;
    for (int v : lista[u])
        if (!viz[v])
            dfs(v);
}

int main() {
    ios::sync_with_stdio(false);
    in.tie(nullptr);

    in >> n >> m;
    for (int i = 0; i < m; i++) {
        int x, y;
        in >> x >> y;
        lista[x].push_back(y);
        lista[y].push_back(x);
    }

    int comp = 0;
    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            comp++;
            dfs(i);
        }
    }

    out << comp;
    return 0;
}
