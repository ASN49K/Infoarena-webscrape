#include <iostream>
#include <vector>
#include <fstream>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int NMAX = 1e5 + 5;

int vizitat[NMAX];
vector<int> G[NMAX];

int raspuns;

void dfs(int nod)
{
    vizitat[nod] = 1;
    for (int i = 0; i < (int) G[nod].size(); i ++){
        if(!vizitat[G[nod][i]]){
            dfs(G[nod][i]);
        }
    }
}

int main(){
    int N, M;
    fin >> N >> M;
    while(M--){
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    for (int i = 1; i <= N; i ++){
        if(!vizitat[i]){
            dfs(i);
            raspuns++;
        }
    }
    fout << raspuns;
}