#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

//int g[100000][100000] = {0};
int v[100001] = {0};
int n, m, con = 0;

vector<int> g[100001];

void dfs(int k)
{
    v[k] = 1;
    //cout << k;
    for (int i = 0; i < g[k].size(); ++i)
        if (!v[g[k][i]])
            dfs(g[k][i]);
}

int main()
{
    ifstream in("dfs.in");
    ofstream out("dfs.out");
    int x, y;
    in >> n >> m;
    for (int i = 1; i <= m; ++i)
    {
        in >> x >> y;
        g[x].push_back(y);
        g[y].push_back(x);
    }
    for (int i = 1; i <= n; ++i)
    {
        if (v[i] == 0)
        {
            ++con;
            dfs(i);
        }
    }
    out << con;
    in.close();
    out.close();
    return 0;
}