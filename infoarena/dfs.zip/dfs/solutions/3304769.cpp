#include <fstream>
#include <vector>
#define NMAX 100002
using namespace std;
ifstream  fin("bfs.in");
ofstream fout("bfs.out");
int N,M,nrc;
vector<int> viz(NMAX,0),graph[NMAX];

void citire()
{
    fin>>N>>M;

    int x,y;
    for(int i=1; i<=M; i++)
    {
        fin>>x>>y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }
}

void DFS(int nod)
{
    viz[nod]=1;
    for(int i=0; i<graph[nod].size(); i++)
    {
        if(!viz[graph[nod][i]])
        {
            DFS(graph[nod][i]);
        }
    }
}

int main()
{
    citire();

    nrc=0;
    for(int i=1; i<=N; i++)
    {
        if(!viz[i])
        {
            nrc++;
            DFS(i);
        }
    }

    fout<< nrc << "\n";

    return 0;
}
