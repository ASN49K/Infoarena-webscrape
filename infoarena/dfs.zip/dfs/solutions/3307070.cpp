#include <bits/stdc++.h>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
const int NMAX=1e5;
vector<int> mat[NMAX+5];
vector<bool> vizitat(NMAX+5);
void bfs(int nod){
    vizitat[nod]=1;
    for(auto it:mat[nod]){
        if(vizitat[it]==0){
            bfs(it);
        }
    }
}
int main(){
    int n, m;
    fin>>n>>m;
    for(int i=1;i<=m;i++){
        int x, y;
        fin>>x>>y;
        mat[x].push_back(y);
        mat[y].push_back(x);
    }
    int cnt=0;
    for(int i=1;i<=n;i++){
        if(vizitat[i]==0){
            bfs(i);
            cnt++;
        }
    }
    fout<<cnt;
}
