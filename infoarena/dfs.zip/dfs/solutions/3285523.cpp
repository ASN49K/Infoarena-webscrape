#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin ("dfs.in");
ofstream fout ("dfs.out");

vector<int> G[100005];
int n, m, viz[100005], k;

void dfs(int start)
{
    viz[start] = 1;

    for (int i = 0; i < G[start].size(); i++)
        if (!viz[G[start][i]]) dfs(G[start][i]);
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    for (int i = 1; i <= n; i++)
    {
        if (!viz[i])
        {
            k++;
            dfs(i);
        }
    }
    fout << k;
    return 0;
}
