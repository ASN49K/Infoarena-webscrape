#include <iostream>
#include <fstream>
#include <vector>
#define NMAX 100002

using namespace std;

ifstream fin ("dfs.in");
ofstream fout ("dfs.out");
int n, m, nrc;
vector<int> G[NMAX];
int uz[NMAX]; ///uz[i]=x, daca i a fost deja vizitat in componenta conexa x
//int d[NMAX]; ///d[i] este gradul, respectiv gradul exteror al vf
void citire();
void dfs(int x);
void afisare();
int main()
{int i;
    citire();
    for(i=1;i<=n;i++)
        if(uz[i]==0) ///am identificat o noua componenta conexa
        {
            nrc++;
            dfs(i);
        }
    afisare();
    return 0;
}

void citire()
{int x, y, i;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        ///adaug pe x in lista de adiacenta a lui y
        G[y].push_back(x);
        ///adaug pe y in lista de adiacenta a lui x
        G[x].push_back(y);
    }

}

void dfs(int x)
///parcurg DFS incepand din varful x
{int i;
    uz[x]=nrc; ///il marchez pe x ca vizitat
    ///parcurg toti vecinii lui x in ordinea din lista de adiacenta
    for(i=0;i<G[x].size();i++)
        if(!uz[G[x][i]])
            dfs(G[x][i]);
}

void afisare()
{int i, j;
    fout<<nrc<<'\n';

}