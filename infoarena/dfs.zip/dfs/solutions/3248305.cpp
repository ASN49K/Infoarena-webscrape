#include <fstream>
#include <vector>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n,m,f[10001];
vector<int>G[100001];
void dfs(int nod){
    f[nod]=1;
    for(auto x : G[nod])
        if(f[x]==0)
            dfs(x);
}
int main(){
    fin>>n>>m;
    while(m--){
        int i,j; fin>>i>>j;
        G[i].push_back(j);
        G[j].push_back(i);
    }
    int rez = 0;
    for(int i=1;i<=n;i++)
    if(f[i]==0){
        rez++;
        dfs(i);
    }
    fout<<rez;
    return 0;
}
