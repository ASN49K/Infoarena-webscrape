#include <bits/stdc++.h>
using namespace std;
vector<vector<int>>adj(100000);
bool vis[100000];
int ans;
void dfs(int nod){
    vis[nod] = 1;
    for(auto v : adj[nod]) if(!vis[v]) dfs(v);
    
}
int main()
{
   freopen("dfs.in","r",stdin);
  freopen("dfs.out","w",stdout);
    int n,m,s;
    cin >> n >> m >> s;
    
 
    
    for(int i = 0;i<m;i++){
        int a,b;
        cin >> a >> b;
        a--;
        b--;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    
    for(int i =0;i<n;i++){
        if(!vis[i]) {
            ans++;
            dfs(i);
        }
    }
   cout<<ans;
    
    
   

    return 0;
}