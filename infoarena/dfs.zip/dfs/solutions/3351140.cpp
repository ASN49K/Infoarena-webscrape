#include <fstream>
#include <vector>

using namespace std;

const int N = 1e5;
const int M = 2e5;

vector <int> a[N+1];
bool viz[N+1];

void dfs(int x) {
    viz[x] = true;
    for (auto y: a[x]) {
        if (!viz[y]) {
            dfs(y);
        }
    }
}

int main() {
    ifstream in("dfs.in");
    ofstream out("dfs.out");
    int n, m;
    in >> n >> m;
    for (int i = 0; i < m; i++) {
        int x, y;
        in >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    in.close();
    int nrc = 0;
    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            nrc++;
            dfs(i);
        }
    }
    out << nrc << "\n";
    out.close();
    return 0;
}