#include <fstream>
#include <iostream>
#include <stack>
#include <vector>


void citireDate(int &numarNoduri, int &numarMuchii, std::vector<std::vector<int>> &listeAdiacenta) {
    std::ifstream in("dfs.in");

    in >> numarNoduri >> numarMuchii;

    for (int i = 0; i < numarNoduri; i ++) {
        listeAdiacenta.emplace_back();
    }
    for (int j = 0; j < numarMuchii; j ++) {
        int x, y;
        in >> x >> y;
        x --;
        y --;
        listeAdiacenta[x].push_back(y);
        listeAdiacenta[y].push_back(x);
    }

    in.close();
}

void parcurgere_dfs(const int &sursa,
                    const std::vector<std::vector<int>> &listeAdiacenta, std::vector<bool> &eVizitat) {
    std::stack<int> stivaDfs;
    stivaDfs.push(sursa);
    while (!stivaDfs.empty()) {
        int nodCurent = stivaDfs.top();
        stivaDfs.pop();
        eVizitat[nodCurent] = true;
        for (auto vecin: listeAdiacenta[nodCurent]) {
            if (eVizitat[vecin] == false) {
                stivaDfs.push(vecin);
            }
        }
    }
    std::cout << std::endl;
}

void afisareRezultat(const int &numarComponenteConexe) {
    std::ofstream out("dfs.out");
    out << numarComponenteConexe;
    out.close();
}

void dfs_1() {
    int numarNoduri, numarMuchii;
    std::vector<std::vector<int>> listeAdiacenta;
    citireDate(numarNoduri, numarMuchii, listeAdiacenta);

    std::vector<bool> eVizitat(numarNoduri, false);
    int numarComponenteConexe = 0;
    for (int i = 0; i < numarNoduri; i ++) {
        if (eVizitat[i] == true) {
            continue;
        }
        parcurgere_dfs(i, listeAdiacenta, eVizitat);
        numarComponenteConexe ++;
    }

    afisareRezultat(numarComponenteConexe);
}


int main() {
    dfs_1();


    return 0;
}
