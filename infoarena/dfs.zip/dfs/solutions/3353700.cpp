#include <iostream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int M[1001][1001];
int n,m;
queue<int>q;
int cnt=0;
int v[1001];
void bfs(int node)
{
    int i;
    v[node]=1;
    q.push(node);
    while(!q.empty())
    {
        int k=q.front();
        for(i=1; i<=n; i++)
        {
            if(v[i]==0 && M[k][i]==1)
            {
                v[i]=1;
                q.push(i);
            }
        }
        q.pop();
    }
    return;
}
int main()
{

    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int a,b;
        fin>>a>>b;
        M[a][b]=1;
        M[b][a]=1;
    }
    int i,j;
    for(i=1; i<=n; i++)
    {
        if(v[i]==0)
        {
            bfs(i);
            cnt++;
        }
    }
    fout<<cnt;
    /*for(i=1;i<=n;i++,fout<<'\n')
        for(j=1;j<=n;j++)
        fout<<M[i][j]<<" ";
        */
    return 0;
}
