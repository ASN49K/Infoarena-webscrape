#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
#define maxn 100010
ifstream f("dfs.in");
ofstream g("dfs.out");
///DFS simplu - doar algoritmul
int d[maxn+1],viz[maxn+1],tata[maxn+1];
void DFS(int Start, vector<vector<int>> adiacenta){
    viz[Start]=1;
//    cout<<Start<<" ";
    for(auto vecin : adiacenta[Start]){
        if(viz[vecin]==0){
            tata[vecin]=Start;
            d[vecin]=d[Start]+1;
            DFS(vecin,adiacenta);
        }
    }
}
int main() {
    int n,m,cc=0,x,y;
    f>>n>>m;
    vector<vector<int>> Lista(n+1);
    for(int i=1;i<=m;i++){
        f>>x>>y;
        Lista[x].push_back(y);
    }
    for(int i=1;i<=n;i++){
        if(viz[i]==0){
            DFS(i,Lista);
            cc++;
        }
    }
   g<<cc;
    return 0;
}
