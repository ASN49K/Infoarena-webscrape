#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int N,M; // noduri si muchii
const int NLIMIT = 100005;
bool vizitat[NLIMIT];
vector <int> Muchii[NLIMIT];
int insule = 0;
void DFS(int Nod){
    vizitat[Nod] = true;
    for(unsigned int i = 0; i<Muchii[Nod].size();i++){
        int vecin = Muchii[Nod][i];
        if(!vizitat[vecin]){
            DFS(vecin);
        }
    }
}
void citire(){
    fin >> N >> M;
    for(int i=1,x,y;i<=M;i++){
        fin >> x >> y;
        //legatura muchiilor
        Muchii[x].push_back(y);
        Muchii[y].push_back(x);
    }
    for(int i=1;i<=M;i++){
        if(!vizitat[i]){
            insule = insule + 1;
            DFS(i);
        }
    }
    fout << insule << "\n";
}
int main() {
    citire();
    return 0;
}
