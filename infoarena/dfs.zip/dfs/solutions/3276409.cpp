#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");


int a[101][101], n, m, viz[101], b[101][101], k;

void citire(){
    fin>>n>>m;
    int x, y;
    for(int i=1;i<=m;i++){
        fin>>x>>y;
        if(a[x][y]==0 && a[y][0]==0){
            a[x][y] = a[y][x] = 1;

        }
    }
}
void dfs(int x, int k){
    viz[x] = k;
    for(int i=1;i<=n;i++)
    {
        if(a[x][i] && !viz[i])dfs(i,k);
    }
}

void afisare(){
    for(int i=1;i<=n;i++,fout<<"\n")
        for(int j=1;j<=n;j++){
            if(i!=j && b[i][j]==0)fout<<"* ";
                else fout<<b[i][j]<<" ";
        }
}

int main()
{
    citire();
    for(int i=1;i<=n;i++)
        if(!viz[i])dfs(i,++k);
    fout<<k;


    return 0;
}
