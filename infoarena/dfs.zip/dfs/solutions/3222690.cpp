#include <fstream>
#include <vector>
#include <queue>

using namespace std;
#define cin find
#define cout fout

ifstream cin("dfs.in");
ofstream cout("dfs.out");

#define maxn 1005
int a[maxn][maxn], n, m, viz[maxn], c;

void dfs(int nod) {
    viz[nod] = 1;
    for (int i = 1; i <= n; ++i) {
        if (!viz[i] && a[nod][i]){
            dfs(i);
        }
    }
}


int main() {
    cin >> n >> m;

    for (int i = 1; i <= m; ++i) {
        int x ,y;
        cin >> x >> y;
        a[y][x] = a[x][y] = 1;
    }

    for (int i = 1; i <= n; ++i) {
        if ( !viz[i] ) {
            c++;
            dfs(i);
        }
    }

    cout << c;
}