#include <vector>
#include <fstream>
using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

vector<vector<int>> adj;
vector<bool> viz;

void dfs(int nod)
{
    viz[nod] = true;

    for (int vecin : adj[nod])
    {
        if (!viz[vecin])
        {
            dfs(vecin);
        }
    }
}

int main()
{
    int n, m;
    f >> n >> m;

    adj.resize(n + 1);
    viz.assign(n + 1, false);

    int x, y;
    while (m--)
    {
        f >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x); // graf neorientat
    }

    int componente = 0;
    for (int i = 1; i <= n; ++i)
    {
        if (!viz[i])
        {
            dfs(i);
            componente++;
        }
    }

    g << componente;

    return 0;
}
