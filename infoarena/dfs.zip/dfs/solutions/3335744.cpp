#include <bitset>
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<vector<int> > ma(100001);

bitset<100001> visitat;


void dfs(int nod) {
    visitat[nod] = 1;
    for (int i = 0; i < ma[nod].size(); i++) {
        if (visitat[ma[nod][i]] == 0)
        dfs(ma[nod][i]);
    }
}

int main() {
    int n, m, nr_componete = 0;
    fin >> n >> m;
    for (int i = 0; i < m; i++) {
        int a, b;
        fin >> a >> b;
        ma[a].push_back(b);
        ma[b].push_back(a);
    }

    for (int i = 1; i <= n; i++) {
        if (visitat[i] == 0) {
            nr_componete++;
            dfs(i);
        }
    }
    fout<<nr_componete;
    return 0;
}
