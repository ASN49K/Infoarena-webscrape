#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
const int NLIM = 100005;
int N, M, insule;
vector <int> Muchii[NLIM];
bool viz[NLIM];

void DFS(int nod) {
	viz[nod] = true;
	for (unsigned int i = 0; i < Muchii[nod].size(); i++) {
		int vecin = Muchii[nod][i];
		if (!viz[vecin])
			DFS(vecin);
	}
}

void Citire() {
	fin >> N >> M;
	for (int i = 0; i < M; i++)
	{
		int x, y;
		fin >> x >> y;
		Muchii[x].push_back(y);
		Muchii[y].push_back(x);
	}
	for (int i = 0; i < N; i++) {
		if (!viz[i]) {
			insule++;
			DFS(i);
		}
	}
}

int main()
{
	Citire();
	fout << insule<<"\n";
	return 0;
}