#include <bits/stdc++.h>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");

vector <int> v[100001];
int viz[100001], k;

void dfs(int x)
{
    viz[x]=1;
    for(int i=0; i<v[x].size(); i++)
    {
        if(!viz[v[x][i]])
        {
            dfs(v[x][i]);
        }
    }
}

int main()
{
    int n, m;
    f >> n >> m;
    for(int i=1; i<=m; i++)
    {
        int x, y;
        f >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    for(int i=1; i<=n; i++)
    {
        if(!viz[i])
        {
            dfs(i);
            k++;
        }
    }

    g << k;
}
