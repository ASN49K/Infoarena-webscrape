#include <fstream>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

void dfs(int source, vector<int> &visited, vector<vector<int>> adj) {
    visited[source] = 1;

    for (auto node : adj[source])
        if (visited[node] == 0)
            dfs(node, visited, adj);
}

int main() {
    int n, m;
    fin >> n >> m;

    vector<vector<int>> adj(n + 1);
    for (int i = 1; i <= m; i++) {
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    vector<int> visited(n + 1, 0);
    int solution = 0;
    for (int i = 1; i <= n; i++)
        if (visited[i] == 0) {
            solution++;
            dfs(i, visited, adj);
        }

    fout << solution;
}