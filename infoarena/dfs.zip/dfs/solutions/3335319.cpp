#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector < vector<int> > adj;
vector<bool> visited;

void dfs(int v){
    visited[v] = true;
    for(int u: adj[v]){
        if(!visited[u]){
            dfs(u);
        }
    }
}


int main(){
    int N,M;
    fin >> N >> M;
    adj.resize(N + 1);
    visited.resize(N + 1, false);
    for(int i=0; i<M; i++){
        int x,y;
        fin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }   
    int connected_components = 0;
    for (int i=1; i<=N; i++){
        if(!visited[i]){
            dfs(i);
            connected_components++;
        }
    }
    fout << connected_components << "\n";
    return 0;

}