#include <bits/stdc++.h>

using namespace std;
ifstream in("dfs.in");
ofstream out("dfs.out");
const int nmax = 1e6;
bitset <nmax> visited;
vector <int> graph[nmax];
int n, m;
void dfs(int node)
{
    visited[node] = 1;
    for(int i : graph[node])
    {
        if(visited[i] == 0)
            dfs(i);
    }
}
int main()
{
    int x, y;
    in>>n>>m;
    for(int i = 1; i <= m; i++)
    {
        in>>x>>y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }
    int r = 0;
    for(int i = 1; i <= n; i++)
    {
        if(visited[i] == 0)
        {
            dfs(i);
            r++;
        }
    }
    out<<r;
}
