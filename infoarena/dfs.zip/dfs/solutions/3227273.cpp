#include <bits/stdc++.h>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");
int nr,n,m,a[10001][10001],x,y,i,v[10001];
void dfs(int k)
{
  v[k]=1;
  for(int i=1;i<=n;i++)
    if(a[k][i]==1 && v[i]==0)
    {
      nr++;
      dfs(i);
    }
}
int main()
{
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y;
        a[x][y]=a[y][x]=1;
    }
    for(i=1;i<=n;i++)
        dfs(i);
    g<<nr;
    return 0;
}
