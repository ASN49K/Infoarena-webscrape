#include <fstream>
#include <queue>
using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

int n;
bool A[101][101],viz[101];

void citire()
{
    int m,x,y;
    f>>n>>m;
    while(m--)
    {
        f>>x>>y;
        A[x][y]=A[y][x]=1;
    }
}
void DFS(int x)
{
    viz[x]=1;
    for(int j=1;j<=n;j++)
        if(A[x][j]==1 && viz[j]==0)
            DFS(j);
}
int main()
{
    int nrCC=0;
    citire();
    for(int i=1;i<=n;i++){
        if(viz[i]==0){
            nrCC++;
            DFS(i);
        }
    }
    g<<nrCC;
    f.close();
    g.close();
    return 0;
}
