#include <bits/stdc++.h>
#define N 100'005
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n,m,x,y,i,j,t,k;
set<int> v[N];
bool f[N];
queue<int> q;
void parc(int x)
{
    f[x]=1;
    q.push(x);
    while(!q.empty())
    {
        x=q.front();
        q.pop();
        set<int>::iterator it;
        for(it=v[x].begin();it!=v[x].end();++it)
        {
            k=*it;
            if(f[k]) continue;
            f[k]=1;
            q.push(k);
        }
    }
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;++i)
    {
        fin>>x>>y;
        v[x].insert(y);
        v[y].insert(x);
    }
    for(y=1;y<=n;++y)
    {
        if(f[y]) continue;
        ++t;
        parc(y);
    }
    fout<<t;
    return 0;
}
