#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("dfs.in");
ofstream out("dfs.out");

vector<int> G[100001];
int viz[100001];

void DFS(int x)
{
    viz[x]=1;
    for(auto next : G[x])
    {
        if(viz[next]==0)
            DFS(next);
    }
}

int main()
{
    int n, m;
    in>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x, y;
        in>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    int cnt = 0;
    for(int i=1;i<=n;i++)
        if(viz[i]==0)
    {
        cnt++;
        DFS(i);
    }
    out<<cnt;
    return 0;
}
