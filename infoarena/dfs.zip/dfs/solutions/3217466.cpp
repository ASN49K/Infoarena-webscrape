// https://infoarena.ro/problema/dfs

#include <fstream>
#include <vector>

using namespace std;

ifstream fi("dfs.in");
ofstream fo("dfs.out");
vector<int> vecini[100001];
int n, m, ncc; // numarul de componente conexe
bool viz[100001];

void citire() {
    int i, x, y;

    fi >> n >> m;
    for (i = 1; i <= m; i++) {
        fi >> x >> y;
        vecini[x].push_back(y);
        vecini[y].push_back(x);
    }
}

void dfs(int nod) {
    int i;

    viz[nod] = true;
    for (int i : vecini[nod])
        if (not viz[i])
            dfs(i);            
}

int main() {
    int i;

    citire();
    for (i = 1; i <= n; i++)
        if (not viz[i]) {
            ncc++;        
            dfs(i);
        }
    fo << ncc;
    return 0;
}
