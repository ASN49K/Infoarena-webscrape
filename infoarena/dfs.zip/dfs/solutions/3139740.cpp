#include <fstream>

using namespace std;

ifstream cin ("dfs.in");
ofstream cout ("dfs.out");

int v[1001],M[1001][1001],n,m,comp;

int dfs (int x)
{
    v[x]=1;
    for (int i=1; i<=n; ++i)
        if (M[i][x] && !v[i])
            dfs(i);
}

int main()
{
    cin>>n>>m;
    for (int i=1; i<=m; ++i)
    {
        int x,y;
        cin>>x>>y;
        M[x][y]=M[y][x]=1;
    }
    for (int i=1; i<=n; ++i)
        if (!v[i]){
            comp++;
            dfs(i);
        }
    cout<<comp;

    return 0;
}
