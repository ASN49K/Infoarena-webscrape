#include <iostream>
#include <vector>
#include <fstream>

std::ifstream fin("dfs.in");
std::ofstream fout("dfs.out");

int marked[100001];
std::vector<std::vector<int>> vec;

void DFS(int v) {
    marked[v] = 1;
    for ( auto u : vec[v] ) {
        if ( marked[u] == 0 ) {
            DFS(u);
        }
    }
}

int main() {
    int compCon = 0;
    int x, y;
    int N, M;

    fin >> N >> M;
    vec.resize(N + 1);

    for (int i = 0; i < M; ++i) {
        fin >> x >> y;
        vec[x].push_back(y);
        vec[y].push_back(x);
    }

    for(int i = 1; i <= N; i++) {
        if (!marked[i]) {
            compCon++;
            DFS(i);
        }
    }

    fout << compCon << std::endl;
    return 0;
}