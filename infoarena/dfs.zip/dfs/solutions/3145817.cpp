#include <iostream>
#include <vector>
// NUMARUL DE COMPONENTE CONEXE
using namespace std;

const int NMAX = 1e5 + 2;

vector<int> adj[NMAX];

bool viz[NMAX];

void dfs (int nod) {
    viz[nod]=1;
    for (auto& to : adj[NMAX]) {
        if (!viz[to]) {
            dfs(to);
        }
    }
}

int main()
{
    int n, m;//n-nr noduri; m-nr muchii
    cin >> n >> m;
    for (int i=1; i<=m; ++i) {
        int x, y;
        cin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    int nrcomp=0;
    for (int nod=1; nod<=n; nod++) {
        if (!viz[nod]) {
            dfs(nod);
            nrcomp++;
        }
    }
    cout << nrcomp;
    return 0;
}
