#include <fstream>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int vizitat[100001];
vector<vector<int>> conex;
vector <int> linie;

void dfc(int nod)
{
    int x,i,j;
        for(i=0;i<conex[nod].size();i++)
        {
            if(vizitat[conex[nod][i]]==0)
            {
                vizitat[conex[nod][i]]=vizitat[nod];
                dfc(conex[nod][i]);
            }
        }
}

int main()
{
    int n, m, i, j, k, s,x,nr=0;
    fin>>n>>m;

    for(i=0;i<n+2;i++)
        conex.push_back(linie);

    for (i = 0; i < m; i++)
    {
        fin >> j >> k;
        conex[j].push_back(k);
        conex[k].push_back(j);
    }

    for(i=1;i<=n;i++)
        {
            if(vizitat[i]==0)
            {
                nr++;
                vizitat[i]=i;
            }
                dfc(i);
        }

fout<<nr<<'\n';
    fout.flush();
    return 0;
}
