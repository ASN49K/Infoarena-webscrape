#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

void DFSrecursive(int i, vector<int> &p, vector<vector<int>> &adj) {
	for (int j : adj[i]) {
		if (p[j] == 0) {
			p[j] = i;
			DFSrecursive(j, p, adj);
		}
	}
}

int main() {
	ifstream fin("dfs.in");
	ofstream fout("dfs.out");

	int n, m, nr = 0;

	fin >> n >> m;

	vector<vector<int>> adj(n + 1);
	vector<int> p(n + 1, 0);

	for (int i = 1; i <= m; i++) {
		int x, y;
		fin >> x >> y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}

	for (int i = 1; i <= n; i++) {
		if (p[i] == 0) {
			nr++;
			DFSrecursive(i, p, adj);
		}
	}
	fout << nr << endl;

	return 0;
}