#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m, nr_comp_con;
const int dim = 100000;
vector<int> lista[dim + 2];
bool vizitat[dim + 2], finalizat = 0;

void citire()
{
    fin >> n >> m;

    for(int i = 0; i < m; i++)
    {
        int x, y;

        fin >> x >> y;

        lista[x].push_back(y);
        lista[y].push_back(x);
    }
}

void DFS(int start)
{
    vizitat[start] = 1;

    for(int i = 0; i < lista[start].size(); i++)
        if (vizitat[lista[start][i]] == 0)
            DFS(lista[start][i]);
}

int main()
{

    citire();

        for(int i = 1; i <= n; i++)
            if (vizitat[i] == 0)
            {
                DFS(i);
                nr_comp_con++;
            }



    fout<<nr_comp_con;

    fin.close();

    return 0;
}