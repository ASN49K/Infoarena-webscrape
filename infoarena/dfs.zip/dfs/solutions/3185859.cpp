#include <bits/stdc++.h>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n,m,a[10001],x,y,nrc;
vector<int>v[10001];
void dfs(int k,int a[])
{
    a[k]=1;
    for(auto i:v[k])
        if(a[i]==0)
            dfs(i,a);
}
int main()
{   fin>>n>>m;
    for(int i=1;i<=m;i++)
        {   fin>>x>>y;
            v[x].push_back(y);}
    for(int i=1;i<=n;i++)
        if(a[i]==0)
    {nrc++;
    dfs(i,a);
    }
    fout<<nrc;
    return 0;
}
