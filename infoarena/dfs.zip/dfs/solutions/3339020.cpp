#include <fstream>
//Varianta 1
//Liste simplu inlantuite
using namespace std;
const int NMAX = 30001;

struct nod
{
    int vec;
    nod *urm;
};

int n;
nod *L[NMAX];   //L[i] = cap de lista pentru vecinii nodului i
bool viz[NMAX];

ifstream f("dfs.in");
ofstream g("dfs.out");

void add_nod(int x, int y) //La lista vecinilor lui x se adauga y
{
    nod *p = new nod;
    p->vec = y;
    p->urm = L[x];
    L[x] = p;
}

void citire()
{
    int m, x, y;
    f >> n >> m;
    while(m--)
    {
        f >> x >> y;
        add_nod(x, y); //se adauga y la lista vecinilor lui x
        add_nod(y, x); //se adauga x la lista vecinilor lui y
    }
}

void DFS(int i)
{
    viz[i] = 1;
    for(nod *p = L[i]; p != NULL; p = p->urm)
        if(viz[p->vec] == 0)
            DFS(p->vec);
}

int main()
{
    int nrCC = 0;
    citire();
    for(int i = 1; i <= n; i++)
        if(viz[i] == 0) //i nu a fost vizitat
        {
            nrCC++;
            DFS(i);
        }

    g << nrCC;
    f.close();
    g.close();
    return 0;
}

