#include <fstream>
#include<vector>
using namespace std;
ifstream in("dfs.in");
ofstream out("dfs.out");
vector<int> se[100001];
int cnt;
int arr[100001];
void dfs(int sursa)
{
    arr[sursa]=cnt;
    for(auto vec:se[sursa])
    {
        arr[vec]=arr[sursa];
        dfs(vec);
    }
}
int main()
{
    int n,m,a,b;
    in>>n>>m;
    for(int i=1; i<=m; i++)
    {
        in>>a>>b;
        se[a].push_back(b);
    }
    for(int i=1; i<=n; i++)
    {
        if(arr[i]==0)
        {
            cnt++;
            dfs(i);
        }
    }
    out<<cnt;
    return 0;
}
