#include <fstream>
#include <vector>
using namespace std;
ifstream fin ("dfs.in");
ofstream fout ("dfs.out");

vector<int> v[100001];
int N, M, vizitat[100001], cont;

void dfs(int nod)
{
    vizitat[nod] = 1;
    for(int element: v[nod])
        if(!vizitat[element]) dfs(element);
}

int main()
{
    fin >> N >> M;
    for(int i=1; i<=M; i++)
    {
        int x, y;
        fin >> x >> y;
        v[x].push_back(y);
    }
    for(int i=1; i<=N; i++)
    {
        if(vizitat[i]==0)
        {
            cont++;
            dfs(i);
        }
    }
    fout << cont;
    return 0;
}