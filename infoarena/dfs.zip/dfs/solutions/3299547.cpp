#include <bits/stdc++.h>
using namespace std;
const int NMAX = 100004;
int n, m;

vector<int> adj[NMAX];
bool valoare[NMAX];

void fill(int nod)
{
    valoare[nod] = 1;
    for (int i = 0; i < adj[nod].size(); i++)
    {
        if (valoare[adj[nod][i]] == 0)
        {
            fill(adj[nod][i]);
        }
    }
}
int main()
{
    int i;
    freopen("dfs.in", "r", stdin);
    freopen("dfs.out", "w", stdout);

    scanf("%d %d", &n, &m);

    for (i = 0; i < m; i++)
    {
        int x, y;
        scanf("%d %d", &x, &y);
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    int cnt = 0;
    for (i = 1; i <= n; i++)
    {
        if (valoare[i] == 0)
        {
            fill(i);
            cnt++;
        }
    }
    printf("%d", cnt);
    return 0;
}
