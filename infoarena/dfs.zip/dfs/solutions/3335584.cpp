#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n, m;

void dfs(int v, vector<bool>&visited, vector<vector<int>>&adj)
{
    visited[v] = true;
    for(auto a : adj[v])
    {
        if(!visited[a])
            dfs(a, visited, adj);
    }
}
int main()
{
    fin >> n >> m;
    vector<vector<int>>adj(n + 1);

    for(int i = 0; i < m; i++)
    {
        int x, y;
        fin >> x >> y;

        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    int cnt = 0;
    vector<bool>visited(n, false);
    for(int i = 1; i <= n; i++)
    {
        if(!visited[i])
        {
            cnt++;
            dfs(i, visited, adj);
        }
    }

    fout << cnt;

    return 0;
}
