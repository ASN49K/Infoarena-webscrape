
using namespace std;
#include <fstream>
#include <vector>

using namespace std;

ifstream fin ("dfs.in");
ofstream fout ("dfs.out");

int a[1003][1003], viz[1003], n, m;

vector <int> G[100001];

void dfs (int nod)
{
    viz[nod] = 1;
    for(unsigned int i = 0; i < G[nod].size(); i++)
    {
        if(viz[G[nod][i]] == 0)
            dfs(G[nod][i]);
    }
}

int main()
{
    int x, y, cnt = 0;
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    for(int i = 1; i <= n; i++)
    {
        if(viz[i]== 0)
        {
            dfs(i);
            cnt++;
        }
    }
    fout << cnt;
    return 0;
}
