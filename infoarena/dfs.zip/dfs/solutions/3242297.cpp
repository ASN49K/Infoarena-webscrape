#include <iostream>
#include <fstream>
#include <vector>
#include <set>
using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

vector < set <int>> a;
int n, x, y, maxi, nr;
int viz[20000001], vf[20000001];

void dfs(int x)
{
    viz[x] = 1;
    for(auto i=a[x].begin(); i!=a[x].end(); i++)
        if(!viz[*i])
            dfs(*i);
}
int main()
{
    while(f >> x >> y)
    {   maxi = max(maxi, x);
        maxi = max(maxi, y);
        a[x].insert(y);
        a[y].insert(x);
        vf[x] = 1;
        vf[y] = 1;
    }
    for(int i=0; i<=maxi; i++)
        if(!viz[i] && vf[i] == 1)
    {
        dfs(i);
        nr++;
    }
    g << nr;
    return 0;
}
