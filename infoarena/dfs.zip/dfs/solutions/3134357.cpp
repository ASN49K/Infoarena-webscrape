#include <bits/stdc++.h>

using namespace std;
#define NMAX 100005

vector<int> adj[NMAX];
vector<bool> visited(NMAX, false);

void dfs(int node) {
    visited[node] = true;
    for (auto neigh : adj[node]) {
        if (!visited[neigh]) {
            dfs(neigh);
        }
    }
}

int main () {
    ifstream fin("dfs.in");
    ofstream fout("dfs.out");

    int n, m;
    fin >> n >> m;
    for (int i = 1, x, y; i <= m; i++) {
        fin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    int comp = 0;
    for (int i = 1; i <= n; i++) {
        if (!visited[i]) {
            dfs(i);
            comp ++;
        }
    }

    fout << comp << "\n";
    return 0;
}