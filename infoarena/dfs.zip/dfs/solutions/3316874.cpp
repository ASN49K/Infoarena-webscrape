
#include <fstream>
#include <iostream>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.ou");

vector<int> vecini[100001];
int verif[100001];
int nr=0;

int DFS(int node){
    verif[node] = 1;
    for(auto i : vecini[node]){
        if(marked[i] == 0)
        {
            DFS(i);
        }
    }
}

void citire(int &n, int &m){
    fin>>n;
    fin>>m;
    for(int i =1; i<=m; i++){
        int x, y;
        fin>>x>>y;
        vecini[x].push_back(y);
        vecini[y].push_back(x);
    }
}

int main()
{
    
    int n, m;
    citire(n, m);
    int componente =0;
    for(int i = 1; i <= n; i++) {
        if(verif[i]==0){
            componente++;
        }
        DFS(i);
    
    }
    return 0;
}