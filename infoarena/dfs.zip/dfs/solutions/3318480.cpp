#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m, v[100001], nr;
vector <int> ma[100001];

void DFS(int nod)
{
    v[nod] = 1;
    for (int i = 0; i < ma[nod].size(); i++)
        if (v[ma[nod][i]] == 0)
        {
            DFS(ma[nod][i]);
        }
}

int main()
{
    fin >> n >> m;

    for (int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        ma[x].push_back(y);
        ma[y].push_back(x);
    }

    for (int i = 1; i <= n; i++)
    {
        if (v[i] == 0)
        {
            DFS(i);
            nr++;
        }
    }

    fout << nr;

    fin.close();
    fout.close();
    return 0;
}