#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define ll long long
#define NMAX 100005
#define INF 1000000000
#define MOD 666013

vector<int> graf[NMAX];
bool viz[NMAX];

queue<int> q;

void DFS(int nod) {
    q.push(nod);
    viz[nod] = true;
    while (!q.empty()) {
        int nodprim = q.front();
        for (int x: graf[nodprim]) {
            if (!viz[x]) {
                q.push(x);
                viz[x] = true;
            }
        }
        q.pop();
    }
}

int main() {
    ifstream cin("dfs.in");
    ofstream cout("dfs.out");

    ios::sync_with_stdio(false), cin.tie(nullptr);
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int x, y;
        cin >> x >> y;
        graf[x].pb(y);
        graf[y].pb(x);
    }

    int componente = 0;
    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            componente++;
            DFS(i);
        }
    }

    cout << componente;
    return 0;
}