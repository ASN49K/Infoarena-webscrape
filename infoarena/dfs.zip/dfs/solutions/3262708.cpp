#include <fstream>
#include <algorithm>
#include <vector>
#define NMAX 100001

using namespace std;
ifstream fin ("dfs.in");
ofstream fout ("dfs.out");
int n;
bool viz[NMAX];
int nrc;
vector<int> G[NMAX];
void dfs (int x);
void citire()
{
    int i,j,m;
    fin>>n>>m;
    for(int k=0; k<m; k++)
    {
        fin>>i>>j;
        G[i].push_back(j);
        G[j].push_back(i);

    }
    /*for(int i=1; i<=n; i++)
    {
        sort(G[i].begin(), G[i].end());
    }*/
}
int main()
{

    citire();
    for(int i=1; i<=n; i++)
    {
        if(!viz[i])
        {
            nrc++;
            dfs(i);
        }
    }
    fout<<nrc<<'\n';
    return 0;
}
void dfs (int x)
{
    int i;
    //fout<<x<<' ';
    viz[x]=1;
    //parcurg vecinii varfului x
    for( i=0; i<G[x].size(); i++)
    {
        if(!viz[G[x][i]])
            dfs(G[x][i]);
    }
}
