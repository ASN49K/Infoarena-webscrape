#include <bits/stdc++.h>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n, m;
vector<list<int>> a;
int viz[100001];

void DFS(int t)
{
    viz[t] = 1;
    for (auto i : a[t])
        if (!viz[i])
            DFS(i);
}
int main()
{
    int x, y;
    int nrcomp = 0;
    fin >> n >> m;
    a.resize(n + 1);
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    for (int nod = 1; nod <= n; nod++)
        if (viz[nod] == 0)
        {
            nrcomp++;
            DFS(nod);
        }
    fout << nrcomp;
    return 0;
}
