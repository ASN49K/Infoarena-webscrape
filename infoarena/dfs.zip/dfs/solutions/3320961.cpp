#include <fstream>
using namespace std;
const int maxn=1e5+5;
int p[maxn];
int findd(int x){
    if(x==p[x])return x;
    return p[x]=findd(p[x]);
}
void unite(int a,int b){
    a=findd(a);
    b=findd(b);
    if(a==b)return;
    p[a]=b;
}
int main()
{
    ifstream cin("dfs.in");
    ofstream cout("dfs.out");
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++)p[i]=i;
    for(int i=1;i<=m;i++){
        int l,r;
        cin>>l>>r;
        unite(l,r);
    }
    int cnt=0;
    for(int i=1;i<=n;i++){
        if(findd(i)==i)cnt++;
    }
    cout<<cnt;
    return 0;
}