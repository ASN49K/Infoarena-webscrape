#include <bits/stdc++.h>

using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

const int NMAX = 1e5;
vector<int> L[NMAX + 1];
int vis[NMAX + 1];

void dfs(int x) {
    vis[x] = 1;
    for(auto next : L[x]) {
        if(!vis[next]) {
            dfs(next);
        }
    }
}


int main() {
    int n, m;
    f >> n >> m;
    for(int i = 1; i <= m; i++) {
        int x, y;
        f >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    int cc = 0;
    for(int i = 1; i <= n; i++) {
        if(!vis[i]) {
            cc++;
            dfs(i);
        }
    }
    g << cc;
	return 0;
}