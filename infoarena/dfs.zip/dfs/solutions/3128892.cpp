#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
const int Nmax=100005;
bool viz[Nmax];
vector<int> v[Nmax];
queue<int> q;
int main()
{
    int n,m,x,y;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    int cnt=0;
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            cnt++;
            q.push(i);
            while(!q.empty())
            {
                int a=q.front();
                q.pop();
                for(int j=0;j<v[a].size();j++)
                {
                    if(viz[v[a][j]]==0)
                    {
                        q.push(v[a][j]);
                        viz[v[a][j]]=1;
                    }
                }
            }
        }
    }
    fout<<cnt<<'\n';
    return 0;
}
