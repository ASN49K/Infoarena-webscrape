#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int n,m,x,y,viz[100001]={0},nr=0;
vector<int>v[100001];
void DF(int nod)
{
    viz[nod]=1;
    for(int i=0;i<v[nod].size();i++)
    {
    int o=v[nod][i];
    if(viz[o]==0)DF(o);
    }
}
int main()
{
 ifstream f("dfs.in");
 ofstream g("dfs.out");
 f>>n>>m;
 while(f>>x>>y)
 {
     v[x].push_back(y);
     v[y].push_back(x);
 }
 for(int k=1;k<=n;k++)
 if(viz[k]==0)
 {  
 DF(k); 
 nr++;
 }
 g<<nr;
 return 0;   
}