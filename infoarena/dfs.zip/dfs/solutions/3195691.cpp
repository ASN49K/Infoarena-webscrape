/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("dfs.in");
ofstream gout("dfs.out");

 void dfs (int x, vector<vector<int>> &g,int v[]){
   v[x]=1;
   for( int a: g[x]){
     if(v[a]!=1){
       dfs(a,g ,v);
     }
   }
 }
int main() 
{
 int n,m,i,x,y, v[1001]={0},nr=0;
f>>n>>m;
vector<vector<int>> g(n+1);
for(i=1;i<=m;i++){
  f>>x>>y;
 g[x].push_back(y);
 g[y].push_back(x);
}
  for(i=1;i<=n;i++){
    if(v[i]==0){
      dfs(i,g,v);
       nr++;
    }
    
  }
 gout<<nr;
}