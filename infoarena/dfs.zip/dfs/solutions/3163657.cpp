#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int NMAX = 100000;
vector<int> G[NMAX+1];
int vis[NMAX + 1];

void DFS(int x)
{
    vis[x] = 1; // marcam nodul curent ca vizitat
    for (auto next : G[x]) // trecem prin lista de adiacenta a nodului curent
        if (!vis[next]) // la primul nod gasit nevizitat apelam dfs pt acesta
            DFS(next);
}

int main()
{
    int n, m;

    fin >> n >> m;
    for (int i = 1;i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y); // facem liste de adiacenta pentru fiecare nod
        G[y].push_back(x);
    }
    int cc = 0;
    for(int i = 1; i <= n; i ++){
        if(!vis[i]){ // la un nod gasit nevizitat marim comp conexe si apelam dfs pt a gasit toate nodurile care le leaga
            cc++;
            DFS(i);
        }
    }
    fout << cc;

    return 0;
}