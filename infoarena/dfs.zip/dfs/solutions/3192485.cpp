#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n, m, s, viz[100005], nrc;
vector <int> G[100005];
queue <int> q;
void dfs(int nod)
{
    viz[nod]=1;
    for(auto i: G[nod])
        if(viz[i]==0)
            viz[i]=1, dfs(i);
}
int main() {
    fin>>n>>m;
    for(int i=0; i<m; i++)
    {
        int x, y;
        fin>>x>>y;
        G[x].push_back(y);
    }
    for(int i=1; i<=n; i++)
        if(viz[i]==0)
            dfs(i), nrc++;
    fout<<nrc;
    return 0;
}