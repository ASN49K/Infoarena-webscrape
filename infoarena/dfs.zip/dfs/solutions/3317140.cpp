#include <bits/stdc++.h>

using namespace std;

vector<int> G[100005];
bool viz[100005];

void DFS(int v) {
  viz[v] = true;
  for (int n : G[v]) {
    if (!viz[n]) {
      DFS(n);
    }
  }
}

int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  freopen("dfs.in", "r", stdin);
  freopen("dfs.out", "w", stdout);
  int n, m;
  cin >> n >> m;
  for (int i = 1; i <= m; ++i) {
    int x, y;
    cin >> x >> y;
    G[x].push_back(y);
    G[y].push_back(x);
  }
  int ans = 0;
  for (int i = 1; i <= n; ++i) {
    if (!viz[i]) {
      ++ans;
      DFS(i);
    }
  }
  cout << ans;
  return 0;
}