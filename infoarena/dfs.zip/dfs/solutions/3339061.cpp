#include <bits/stdc++.h>
using namespace std;

bitset<100005> viz;
vector<int> adj[100005];

void dfs(int s) {
    viz[s] = true;
    queue<int> st;
    st.push(s);
    while(!st.empty()) {
        int top = st.front();
        st.pop();

        for(auto& i : adj[top]) {
            if(!viz[i]) {
                st.push(i);
                viz[i] = true;
            }
        }
    }
}

signed main() {
    cin.tie(nullptr)->sync_with_stdio(false);
#ifndef LOCAL
    freopen("dfs.in", "r", stdin);
    freopen("dfs.out", "w", stdout);
#endif

    int n, m; cin >> n >> m;
    for(int i = 0; i < m; ++i) {
        int x, y; cin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    int cnt = 0;
    for(int i = 1; i <= n; ++i) {
        if(!viz[i]) {
            dfs(i);
            ++cnt;
        }
    }

    cout << cnt;

    return 0;
}