#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

int n, m, s, x, y, cc[100005];
vector<int> vec[100005];

void dfs(int sursa){
    for(auto vecin:vec[sursa]){
        if(cc[vecin]==0){
            cc[vecin]=cc[sursa];
            dfs(vecin);
        }
    }
}

int main(){
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        vec[x].push_back(y);
        vec[y].push_back(x);
    }
    int ans=0;
    for(int i=1;i<=n;i++){
        if(cc[i]==0){
            cc[i]=++ans;
            dfs(i);
        }
    }
    cout<<ans;
}
