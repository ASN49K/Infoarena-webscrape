#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

void dfs(int nod_curent, vector<int> lista_vecini[], int vizitat[]) {
    vizitat[nod_curent] = 1;
    for (int i = 0; i < lista_vecini[nod_curent].size(); i++) {
        if (vizitat[lista_vecini[nod_curent][i]] == 0)
            dfs(lista_vecini[nod_curent][i], lista_vecini, vizitat);
    }

}

int main() {
    int numar_noduri, numar_muchii;
    fin >> numar_noduri >> numar_muchii;

    int count = 0;

    vector<int> lista_vecini[numar_noduri];
    int vizitat[numar_noduri];

    for (int i = 1; i <= numar_muchii; i++) {
        int nod1, nod2;
        fin >> nod1 >> nod2;
        lista_vecini[nod1].push_back(nod2);
        lista_vecini[nod2].push_back(nod1);
    }

    for (int i = 1; i <= numar_noduri; i++) {
        if (vizitat[i] == 0) {
            dfs(i, lista_vecini, vizitat);
            count++;
        }
    }

    fout << count;

    return 0;
}

