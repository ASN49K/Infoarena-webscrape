#include <bits/stdc++.h>

using namespace std;
ifstream in ("dfs.in");
ofstream out ("dfs.out");
const int NMAX=100005;
int n,m;
vector <int> v[NMAX];
int x,y;
bitset <NMAX> fr;
int cnt;
void dfs(int poz)
{
    for(int i=0; i<v[poz].size(); i++)
    {
        if(!fr[v[poz][i]])
        {
            fr[v[poz][i]]=true;
            dfs(v[poz][i]);
        }
    }
}
int main()
{
    in>>n>>m;
    for(int i=1; i<=m; i++)
    {
        in>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    for(int i=1; i<=n; i++)
    {
        if(!fr[i])
        {
            cnt++;
            fr[i]=true;
            dfs(i);
        }
    }
    out<<cnt;
    return 0;
}
