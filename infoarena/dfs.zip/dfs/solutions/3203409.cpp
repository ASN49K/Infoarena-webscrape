#include <bits/stdc++.h>

using namespace std;

ifstream in("dfs.in");
ofstream out("dfs.out");

int n, m;
vector<int> a[100001];
int viz[100001];

void dfs(int nod) {
    viz[nod] = 1;
    for(int i = 0;i < a[nod].size();i++){
        if(viz[a[nod][i]] == 0){
            viz[a[nod][i]] = 1;
            dfs(a[nod][i]);
        }
    }
}

int main() {
    in >> n >> m;

    for(int i = 0;i < n;i++){
        int x, y;
        in >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }

    int count = 0;

    for(int i = 1;i <= n;i++){
        if(viz[i] == 0){
            dfs(i);
            count++;
        }
    }
    out << count;
    return 0;
}
