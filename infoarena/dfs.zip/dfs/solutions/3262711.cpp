#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#define NMAX 100002

using namespace std;

ifstream fin ("dfs.in");
ofstream fout ("dfs.out");

int n, nrc;
vector <int> G[NMAX];
bool viz[NMAX];
void citire();
void dfs(int x);

int main()
{
    citire();
    for (int i=1; i<=n; i++)
        if (!viz[i])
        {
            nrc++;
            dfs(i);
        }
    fout<<nrc<<'\n';
    return 0;
}
void citire()
{
    int i, j, m;
    fin>>n>>m;
    for (int k=0; k<m; k++)
    {
        fin>>i>>j;
        G[i].push_back(j);
        G[j].push_back(i);
    }
    /*for (int i=1; i<=n; i++)
    {
        sort(G[i].begin(), G[i].end());
    }*/
}
void dfs(int x)
{
    //fout<<x<<' ';
    viz[x]=1;
    for (int i=0; i<G[x].size(); i++)
    {
        if (!viz[G[x][i]])
            dfs(G[x][i]);
    }
}
