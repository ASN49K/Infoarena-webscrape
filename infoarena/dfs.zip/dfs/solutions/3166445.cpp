#include <fstream>
#include <list>

using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

list<int> v[100002];
bool viz[100002];

void dfs(int nod);

int main()
{
    int n, m, ans = 0;
    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        cin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    for(int i = 1; i <= n; i++)
    {
        if(!viz[i])
        {
            ans++;
            dfs(i);
        }
    }
    cout << ans << '\n';
    return 0;
}

void dfs(int nod)
{
    int link;
    for(auto link : v[nod])
        if(!viz[link])
        {
            viz[link] = 1;
            dfs(link);
        }
}
