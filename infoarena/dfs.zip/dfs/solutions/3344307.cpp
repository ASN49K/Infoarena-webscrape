#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int LIM=100001;
vector<int>Muchii[LIM];

bool vizitat[LIM];
int comp;

void DFS(int nod)
{
    vizitat[nod]=true;
    for (unsigned int i=0; i<Muchii[nod].size(); i++)
    {
        int vecin=Muchii[nod][i];
        if(!vizitat[vecin])
            DFS(vecin);
    }
}

void citire (int N, int M)
{
    fin>>N>>M;
    for (int i=0; i<M; i++)
    {
        int X,Y;
        fin>>X>>Y;
        Muchii[X].push_back(Y);
        Muchii[Y].push_back(X);
    }
    for (int i=0; i<N; i++)
    {
        if (!vizitat[i])
        {
            comp=comp+1;
            DFS(i);
        }
    }
}

int main()
{
    int N,M;
    citire (N,M);
    fout<<comp<<"\n";
    return 0;
}
