#include <bits/stdc++.h>
using namespace std;

vector<int> v[100001];
int vis[100001];
int n, m;

void dfs(int node) {
    vis[node] = 1;
    for(auto vec : v[node]) {
        if(!vis[vec]) {
            dfs(vec);
        }
    }
}

int main() {
	ifstream cin("dfs.in");
    ofstream cout("dfs.out");
    cin >> n >> m;
    for(int i = 1; i <= m; i++) {
        int x, y;
        cin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    int cnt = 0;
    for(int i = 1; i <= n; i++) {
        if(!vis[i]) {
            cnt++;
            dfs(i);
        }
    }
    cout << cnt;
}
