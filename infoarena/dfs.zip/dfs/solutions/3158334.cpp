#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;
ifstream in("dfs.in");
ofstream out("dfs.out");
void construire(vector<vector<int>>& ls, int n, int m) {
	for (int i = 0; i < m; i++)
	{
		int x, y;
		in >> x >> y;
		ls[x].push_back(y);
		ls[y].push_back(x);
	}
}

void afisare(vector<vector<int>>ls) {
	for (int i = 1; i < ls.size(); i++)
	{
		cout << i << ": ";
		for (int j = 0; j < ls[i].size(); j++)
		{
			cout << ls[i][j] << " ";
		}
		cout << "\n";
	}
}

int vizitat[100000];
void dfs(vector<vector<int>>ls,int s,int n) {
	
	vizitat[s] = 1;
	for (int i = 0; i < ls[s].size(); i++)
	{
		if (vizitat[ls[s][i]] == 0) {
			vizitat[ls[s][i]] = 1;
			dfs(ls, i, n);
		}
	}
}

int main() {
	int n, m;
	in >> n >> m;
	vector<vector<int>>ls(n + 1);
	construire(ls, n, m);

	
	int contor = 0;
	
	for (int i = 1; i <= n; i++)
	{
		if (vizitat[i] == 0)
		{
			contor++;
			dfs(ls, i, n);
		}
	}
	out << contor;
}