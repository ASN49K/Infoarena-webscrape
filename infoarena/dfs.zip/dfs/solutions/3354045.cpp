#include <fstream>
#include <vector>

using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

const int NMAX = 1e5;
vector<int> adj[NMAX + 5];
bool visited[NMAX + 5];

int dfs(int nod)
{
    visited[nod] = true;
    for(auto it : adj[nod])
    {
        if(visited[it] == false)
        dfs(it);
    }
}
int main()
{
    int n, m, u, v, rp = 0;
    cin >> n >>m;
    for(int i = 1; i <= m; i++)
    {
        cin >> u;
        cin >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    for(int i = 1; i <= n; i++)
    {
        if(visited[i] == false)
            dfs(i), rp++;
    }
    cout << rp;
    return 0;
}
