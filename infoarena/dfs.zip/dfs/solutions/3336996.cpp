#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");


vector<int> adj[100005];
vector<bool> visited(100005, false);

void DFS(int nod){
    visited[nod] = true;
    for(auto vecin : adj[nod]){
        if(!visited[vecin]){
            DFS(vecin);
        }
    }
}

int main(){
    int n, m;
    fin >> n >> m;
    for (int i = 0 ; i < m ; i++){
        int u, v;
        fin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    int nr_comp_conexe = 0;
    for(int i = 1 ; i <=n ; i++){
        if(!visited[i]){
            nr_comp_conexe++;
            DFS(i);
        }
    }

    fout << nr_comp_conexe;
}
