#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int n, m, nr;
vector<int>  L[10000001];
vector<int> viz(n+1, 0);
void DFS(int nod) {
    viz[nod] = 1;
    for (auto vecin : L[nod]) {
        if (viz[vecin] == 0)
            DFS(vecin);
    }
}
int main() {
    ifstream fin("dfs.in");
    fin >> n >> m;
    for (int i = 0; i < m; i++) {
        int x, y;
        fin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
    }

    for (int i = 1 ; i <= n ; i++) {
        if (viz[i] == 0){
            nr++;
            DFS(i);
        }
    }
    ofstream fout("dfs.out");
    fout << nr;
}
