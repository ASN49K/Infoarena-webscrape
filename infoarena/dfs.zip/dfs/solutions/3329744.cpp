#include <bits/stdc++.h>
using namespace std;

#define int long long

const int MAXN = 100000+5;
vector<int> g[MAXN];
bool vis[MAXN];

void dfs(int v){
    vis[v]=true;
    for(auto to:g[v]){
        if(!vis[to]) dfs(to);
    }
}

signed main(){
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    freopen("dfs.in","r",stdin);
    freopen("dfs.out","w",stdout);

    int N,M; cin>>N>>M;
    for(int i=0;i<M;i++){
        int x,y; cin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
    }

    int comp=0;
    for(int i=1;i<=N;i++){
        if(!vis[i]){
            comp++;
            dfs(i);
        }
    }

    cout<<comp<<"\n";
    return 0;
}
