#include <iostream>
#include <iomanip>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m, viz[100001], k;

struct nod {
	int vf;
	nod* urm;
}*v[100001];


void adaugare(int x,nod*& prim)
{
	nod* nou = new nod;
	nou->vf = x;
	nou->urm = prim;
	prim = nou;
}

void citire()
{
	fin >> n >> m;
	for (int i = 1; i <= m; i++)
	{
		int x, y;
		fin >> x >> y;
		adaugare(x, v[y]);
		adaugare(y, v[x]);
	}
}


void dfs(int x)
{
	viz[x] = k;
	for (nod*q=v[x];q;q=q->urm)
	{
		if (!viz[q->vf])
		{
			dfs(q->vf);
		}
	}
}

int main()
{
	citire();
	for (int i = 1; i <= n; i++)
	{
		if (!viz[i])
		{
			k++;
			dfs(i);
		}
	}
	fout << k;
}