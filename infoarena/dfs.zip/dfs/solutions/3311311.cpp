#include <fstream>
#include <vector>
#include <stack>
#include <bitset>

using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

vector<vector<int>> v;
int n, m;
stack<int> st;
bitset<100001> viz;

void dfs(int node) {
    viz[node] = 1;
    st.push(node);
    while (!st.empty()) {
        int current = st.top();
        st.pop();
        for (int neighbor : v[current]) {
            if (!viz[neighbor]) {
                st.push(neighbor);
                viz[neighbor] = 1;
            }
        }
    }
}

int main() {
    cin >> n >> m;
    v.resize(n + 2);
    for (int i = 0 ; i < m ; ++i) {
        int src, dest;
        cin >> src >> dest;
        v[src].push_back(dest);
        v[dest].push_back(src);
    }

    int ans = 0;
    for (int i = 1 ; i <= n ; ++i) {
        if (!viz[i]) {
            dfs(i);
            ans++;
        }
    }

    cout << ans;
    return 0;
}