#include <fstream>
#include <iostream>
#include <algorithm>
using namespace std;

int g[1000][10000] = {0};
int v[1000] = {0};
int n, m, con = 0;

void dfs(int k)
{
    v[k] = 1;
    for (int i = 1; i <= n; ++i)
    {
        if (g[k][i] && !v[i])
        {
            dfs(i);
        }
    }
}

int main()
{
    ifstream in("dfs.in");
    ofstream out("dfs.out");
    int x, y;
    in >> n >> m;
    for (int i = 0; i < m; ++i)
    {
        in >> x >> y;
        g[x][y] = 1;
        g[y][x] = 1;
    }
    for (int i = 1; i <= n; ++i)
        if (!v[i]) {
            dfs(i);
            ++con;
        }
    out << con << '\n';
    in.close();
    out.close();
    return 0;
}