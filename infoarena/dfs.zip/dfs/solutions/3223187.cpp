#include <iostream>
#include <vector>
using namespace std;

vector<vector<int>> g;

int n, m, vis[100001], a, b, cnt;

void DFS(int node){
    vis[node]=true;
    for(int i=0; i<g[node].size(); i++){
        int vec = g[node][i];
        if(vis[vec]==0){
            DFS(vec);
        }
    }
}

int main()
{
    cin>>n>>m;
    g.resize(n+1);
    for(int i=1; i<=m; i++){
        cin>>a>>b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    for(int node=1; node<=n; node++){
        if(!vis[node]){
            cnt++;
            DFS(node);
        }
    }
    cout<<cnt;
    return 0;
}
