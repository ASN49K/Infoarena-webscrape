#include <iostream>
#include <fstream>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");
int n,viz[100001];
struct nod
{
    int val;
    nod*urm;
}*L[100001];
void adnod(int x, int y)
{
    nod *p=new nod;
    p->val=y;
    p->urm=L[x];
    L[x]=p;
}
void citire()
{
    int x,y,m;
    f>>n>>m;
    while(m--)
    {
        f>>x>>y;
        adnod(x,y);
        adnod(y,x);
    }
}
void dfs(int i)
{
    viz[i]=1;
    for(nod *p=L[i];p;p=p->urm)
        if(viz[p->val]==0)
        dfs(p->val);
}
int main()
{
    citire();
    int nrc=0;
    for(int i=1;i<=n;i++)
        if(viz[i]==0)
    {
        dfs(i);
        nrc++;
    }
    g<<nrc;
    return 0;
}
