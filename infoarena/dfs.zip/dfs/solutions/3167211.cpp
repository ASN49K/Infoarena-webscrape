#include <bits/stdc++.h>
#define NMAX 1000001
using namespace std;

ifstream fin("bfs.in");
ofstream fout("bfs.out");


int N,M, nod_start,x,y, cnt = 0;


vector<int> G[NMAX];
bool viz[NMAX];
int dist[NMAX];
queue<int> q;


void citire()
{
    fin>>N>>M;
    for(int i=1;i<=M;i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
    }
}


void DFS(int nod)
{
    viz[nod] = 1;
    for(int nbs:G[nod])
    {
        if(!viz[nbs])
        {
            DFS(nbs);
        }
    }
}

void afisare()
{
    int i;
    for(i=1;i<=N;i++)
    {
        if(!viz[i])
        {
            DFS(i);
            cnt++;
        }
    }
    fout<<cnt;
}


int main()
{
    citire();
    afisare();
}
