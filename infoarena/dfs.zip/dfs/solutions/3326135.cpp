#include<iostream>
#include<fstream> 
#include<vector> 

using namespace std; 

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<int> lista_adiacenta[100001];
bool visited[100001];

void DFS (int node)
{
    visited[node] = 1; 
    
    for(int v : lista_adiacenta[node])
        if(visited[v] == 0)
            DFS(v);
}


int main() 
{
    int n, m, a, b, i, componente = 0;
    fin >> n >> m; 
    for(i = 1; i <= m; i++)
    {
        fin >> a >> b; 
        lista_adiacenta[a].push_back(b);
        lista_adiacenta[b].push_back(a);
    }
    
    for(i = 1; i <= n; i++)
        if(!visited[i])
        {
            componente++; 
            DFS(i);
        }
        
    fout << componente; 
}