#include<fstream>
#include<vector>
#include<bitset>
std::ifstream fin("dfs.in");
std::ofstream fout("dfs.out");
const int NMAX=100005;
std::vector<int>G[NMAX];
std::bitset<NMAX>f;
int n, m;
void read()
{
    fin>>n>>m;
    for(int i=0; i<m; ++i)
    {
        int from, to;
        fin>>from>>to;
        G[from].push_back(to);
    }
}
void dfs(int node)
{
    f[node]=true;
    for(auto it:G[node])
        if(!f[it])
            dfs(it);
}
void solve()
{
    int ans=0;
    for(int i=1; i<=n; ++i)
    {
        if(!f[i])
        {
            dfs(i);
            ++ans;
        }
    }
    fout<<ans;
}
int main()
{
    read();
    solve();
    return 0;
}