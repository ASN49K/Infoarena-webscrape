#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("dfs.in");
ofstream out("dfs.out");

const int nmax = 100;

int n;
bool viz[nmax * nmax + 1];
vector<int>v[nmax + 1];

void dfs(int x){
    viz[x] = 1;
    for(auto y : v[x]){      
        if(!viz[y]){
            dfs(y);
        }
    }
}

int main(){
    int a, b, nrc = 0;
    in >> n;
    while(in >> a >> b){
        v[a].push_back(b);
        v[b].push_back(a);
    }
    for(int i = 1; i <= n; i++){
        if(!viz[i]){
            nrc++;
            dfs(i);
        }
    }
    out << nrc;
    return 0;
}