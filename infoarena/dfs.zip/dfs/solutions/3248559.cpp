#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m, x, y, rez = 1;

vector<int> graph[100000];
int marked[100000];

void dfs(int k){
    int lim = graph[k].size();
    for(int i = 0; i<lim; i++){
        if(marked[ graph[k][i] ] == 0){
            marked[ graph[k][i] ] = 1;
            rez++;
            dfs(i);
        }
    }
}
int main()
{
    fin>>n>>m;
    for(int i = 0; i<n; i++){
        fin>>x>>y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }
    dfs(1);
    fout<<rez;
    return 0;
}
