#include <iostream>
#include <vector>
#include <queue>
using namespace std;

vector<int> lista[100001];
int d[100001];
int tata[100001];

void bfs(int s, int n) {
    for (int i = 1; i <= n; i++) {
        d[i] = -1;
        tata[i] = -1;
    }

    queue<int> q;
    d[s] = 0;
    tata[s] = -1;
    q.push(s);

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : lista[u]) {
            if (d[v] == -1) {
                d[v] = d[u] + 1;
                tata[v] = u;
                q.push(v);
            }
        }
    }
}

int main() {
    int n, m, s;
    cin >> n >> m >> s;

    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        lista[u].push_back(v);
    }

    bfs(s, n);

    for (int i = 1; i <= n; i++) {
        if (i > 1)
            cout << " ";
        cout << d[i];
    }
    cout << "\n";

    int x;
    cin >> x;
    if (d[x] != -1) {
        vector<int> drum;
        int v = x;
        while (v != -1) {
            drum.push_back(v);
            v = tata[v];
        }
        reverse(drum.begin(), drum.end());
        for (int x : drum)
            cout << x << " ";
        cout << endl;
    } else
        cout << "nu se poate ajunge la nodul " << x << endl;

    return 0;
}
