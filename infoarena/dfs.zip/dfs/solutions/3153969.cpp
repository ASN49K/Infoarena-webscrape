#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int LMAX = 100005;
vector<int> L[LMAX];
bool viz[LMAX];

void dfs(int node) {
    viz[node] = true;
    for (int vec : L[node]) {
        if (!viz[vec]) {
            dfs(vec);
        }
    }
}

int main(){

    int n, m, x, y, i, cc;
    fin>>n>>m;
    while (m--) {
        fin>>x>>y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    cc = 0;
    for (i = 1; i <= n; i++) {
        if (!viz[i]) {
            dfs(i);
            cc++;
        }
    }
    fout<<cc;



    fin.close();
    fout.close();
    return 0;
}
