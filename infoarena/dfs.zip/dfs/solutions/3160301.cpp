#include <iostream>
#include <vector>

void dfs(std::vector<std::vector<int>>& adj, std::vector<bool>& visited, int node) {
    visited[node] = true;
    for(auto i: adj[node]) {
        if(!visited[i]) {
            dfs(adj, visited, i);
        }
    }
}

int main() {
    int n, m;
    std::cin >> n >> m;
    std::vector<std::vector<int>> adj(n);
    for(int i = 0; i < m; i++) {
        int u, v;
        std::cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    std::vector<bool> visited(n, false);
    int cnt = 0;
    for(int i = 0; i < n; i++) {
        if(!visited[i]) {
            dfs(adj, visited, i);
            cnt++;
        }
    }
    std::cout << cnt;
}