#include<fstream>
#include<vector>

using namespace std;

vector<bool> vis(100005,false);

void dfs(int x, int n , vector<vector<int>> &adj) {
    vis[x] = true;

    for(auto neighbour : adj[x]) {
        if(!vis[neighbour]) {
            dfs(neighbour, n, adj);
        }
    }
}

int main() {
    ifstream fin("dfs.in");
    ofstream fout("dfs.out");

    int n, m;
    fin >> n >> m;

    vector<vector<int>> v(200005);

    for(int i = 0 ; i < m ; i++) {
        int x, y;
        fin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }

    int cnt = 0;
    for(int i = 1 ; i <=n ; i++) {
        if(!vis[i]) {
            dfs(i,n,v);
            cnt -= -1;
        }
    }

    fout << cnt;
    fin.close();
    fout.close();
    return 0;
}