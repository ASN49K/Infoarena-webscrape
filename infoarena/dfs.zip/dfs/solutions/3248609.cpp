#include <bits/stdc++.h>

using namespace std;
ifstream in("dfs.in");
ofstream out("dfs.out");
int n,x,y,viz[100001],c,m;
vector<int>Graph[100001];
void dfs(int node){
viz[node]=1;
for(auto nb: Graph[node]){
    if(!viz[nb]) dfs(nb);
}
}
int main()
{
    in>>n>>m;
    for(int i=1;i<=m;i++){
        in>>x>>y;
        Graph[x].push_back(y);
        Graph[y].push_back(x);
    }
   for(int i=1;i<=n;i++){
        if(!viz[i]){
            c++;
            dfs(i);
        }
    }
    out<<c;
    return 0;
}
