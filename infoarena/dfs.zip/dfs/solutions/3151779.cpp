#include <fstream>
#include <iostream>
#include <vector>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector <int> v[200000];
int n, m, viz[200000];

void dfs(int nod) {
    for (int x = 0; x < v[nod].size(); x++) {
        int fiu = v[nod][x];
        if (viz[fiu] == 0) {
            viz[fiu] = 1;
            dfs(fiu);  
        }
            
    }
}

int main()
{
    int con = 0;
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int x, y;
        fin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    for (int i = 1; i <= n; i++) {
        if (viz[i] == 0) {
            con++;
            viz[i] = 1;
            dfs(i);
        }
    }
    fout << con;
}
