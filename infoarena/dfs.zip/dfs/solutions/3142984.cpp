#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m, nr;
vector<int> gf[100001];
int viz[100001];

void DFS(int x) {
    viz[x] = 1;
    for (int i : gf[x])
        if (!viz[i])
            DFS(i);
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int x, y;
        fin >> x >> y;
        gf[x].push_back(y);
        gf[y].push_back(x);
    }
    for (int i = 1; i <= n; i++)
        if (!viz[i])
            nr++, DFS(i);
    fout << nr;
    return 0;
}
