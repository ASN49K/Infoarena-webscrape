#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int NMAX = (int)1e5 + 5;

vector<int> adj[NMAX];

void dfs(int node, vector<int>& visited) {
    visited[node] = true;
    for (int u : adj[node]) {
        if (!visited[u])
            dfs(u, visited);
    }
}

int main() {

    ifstream fin("dfs.in");

    int n, m;
    fin >> n >> m;

    vector<int> visited(n + 1);

    for (int i = 0; i < m; i++) {
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y);
    }

    int nr = 0;
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            nr++;
            dfs(i, visited);
        }
    }

    ofstream fout("dfs.out");
    fout << nr;

    return 0;
}