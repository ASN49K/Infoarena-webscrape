#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
vector <vector<int>> graf;

int n,m,cnt;
bool vis[101];
void DFS(int nod)
{
    vis[nod]=true;
    for(int vecin:graf[nod]){
        if(!vis[vecin]){
            cnt++;
            DFS(vecin);
        }
    }
}

int main()
{
    fin>>n>>m;
    graf.resize(n+1);
    for(int i=0;i<m;i++){
        int nod1,nod2;
        fin>>nod1>>nod2;
        graf[nod1].push_back(nod2);
        graf[nod2].push_back(nod1);
    }
    for(int i=1;i<=n;i++){
        DFS(i);
    }

    fout<<cnt;
    return 0;
}
