#include <fstream>
#include <vector>

using namespace std;

const int MAXN = 100005;

vector<int> adj[MAXN];
bool visited[MAXN];
int N, M;

// void dfs(int node) {
//     visited[node] = true;
//     for (int neighbor : adj[node]) {
//         if (!visited[neighbor]) {
//             dfs(neighbor);
//         }
//     }
// }
void dfs(int node) {
    visited[node] = true;
    for(int i = 0; i < adj[node].size(); i++) {
        if(!visited[adj[node][i]]) {
            dfs(adj[node][i]);
        }
    }
}

int main() {
    ifstream fin("dfs.in");
    ofstream fout("dfs.out");

    fin >> N >> M;
    for (int i = 0; i < M; ++i) {
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    int connected_components = 0;
    for (int i = 1; i <= N; ++i) {
        if (!visited[i]) {
            ++connected_components;
            dfs(i);
        }
    }

    fout << connected_components << "\n";

    return 0;
}
