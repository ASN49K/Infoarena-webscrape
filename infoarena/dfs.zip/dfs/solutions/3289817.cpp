#include <fstream>
#include <vector>

using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

int n, m, vizi[100002], cnt;
vector<int> a[100002];

void df(int nod)
{
    vizi[nod] = 1;
    for(auto i : a[nod])
    {
        if(vizi[i] == 0)
            df(i);
    }
}

int main()
{
    cin >> n >>m;
    for(int i=1; i<=m; ++i)
    {
        int x, y;
        cin >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }

    for(int i=1; i<=n; ++i)
    {
        if(vizi[i] == 0)
        {
            cnt++;
            df(i);
        }
    }

    cout << cnt;
    return 0;
}
