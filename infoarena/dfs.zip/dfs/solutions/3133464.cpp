#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int NLIM = 100000;
vector<int> Muchii[NLIM];
int n, m, insule, x, y;
bool vizitat[NLIM];

void dfs(int k)
{
    vizitat[k] = 1;
    for(unsigned int i=0 ; i < Muchii[k].size() ; ++i)
    {
        int vecin = Muchii[k][i];
        if(!vizitat[vecin])
            dfs(vecin);
    }
}
int main()
{
    fin>>n>>m;

    for(int i=1 ; i<=m ; ++i)
    {
        fin>>x>>y;

        Muchii[x].push_back(y);
        Muchii[y].push_back(x);
    }

    for(int i=1 ; i<=n ; ++i)
    {
        if(!vizitat[i])
        {
            insule += 1;
            dfs(i);
        }
    }
    fout<<insule;
    return 0;
}
