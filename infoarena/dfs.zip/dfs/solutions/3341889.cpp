#include <bits/stdc++.h>

using namespace std;

vector<int> graph[100005];
bool visited[100005];

void dfs(int nod) {
    visited[nod] = true;
    for (auto vecin : graph[nod]) {
        if (visited[vecin])
            continue;
        dfs(vecin);
    }
}

int main() {

    freopen("dfs.in", "r", stdin);
    freopen("dfs.out", "w", stdout);

    int n, m;
    cin >> n >> m;
    for (int i = 0; i < m; ++i) {
        int x, y;
        cin >> x >> y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }

    int ans = 0;
    for (int nod = 1; nod <= n; ++nod) {
        if (visited[nod])
            continue;
        dfs(nod);
        ans++;
    }

    cout << ans;
}