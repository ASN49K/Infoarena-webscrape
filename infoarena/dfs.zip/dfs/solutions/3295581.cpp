#include <fstream>
#include <iostream>
#include <vector>
#include <queue>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

void dfs(int node, vector<int> &visited, vector<int> adj[]) {
    visited[node] = 1;

    for (int neigh : adj[node]) {
        if (visited[neigh] == 0)
            dfs(neigh, visited, adj);
    }
}

int main() {
    int n, m, p;
    fin >> n >> m;

    vector<int> adj[n + 2];

    for (int i = 0; i < m; i++) {
        int x, y;
        fin >> x >> y;
        adj[x].push_back(y);
    }

    vector<int> visited(n + 2, 0);
    int number = 0;

    for (int i = 1; i <= n; i++) {
        if (!visited[i]) {
            dfs(i, visited, adj);
            number++;
        }
    }

    fout << number;

}