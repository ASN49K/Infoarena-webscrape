#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void dfs(vector<vector<int>> &adj_list, vector<int> &viz, int n, int node, int nr){
    if(viz[node] > 0){
        return;
    }

    viz[node] = nr;
    for(auto& adn : adj_list[node]){
        if(!viz[adn])
            dfs(adj_list, viz, n, adn, nr);
    }
}

int conex(vector<vector<int>> &adj_list, int n){
    vector<int> viz(n + 1, 0);
    int nrcomp = -1;
    int nr = 1;
    for(int i = 1; i <= n; i++){
        if(!viz[i]){
            dfs(adj_list, viz, n, i, nr);
            nr++;
        }
    }
    for(int i = 1; i <= n; i++){
        nrcomp = max(nrcomp, viz[i]);
    }
    return nrcomp;
}

int main(){
    ifstream fin("dfs.in");
    ofstream fout("dfs.out");

    int n, m;
    int node1, node2;
    vector<vector<int>> adj_list;

    fin >> n >> m;
    adj_list.resize(n + 1);

    for(int i = 1; i <= m; i++){
       fin >> node1 >> node2;
       adj_list[node1].push_back(node2);
       adj_list[node2].push_back(node1);
    }

    //printing
    // for(int i = 1; i <= n; i++){
    //     cout << i << ": ";
    //     for(int j = 0; j < adj_list[i].size(); j++){
    //         cout << adj_list[i][j] << " ";
    //     }
    //     cout << '\n';
    // }

    fout << conex(adj_list, n) << '\n';
}
