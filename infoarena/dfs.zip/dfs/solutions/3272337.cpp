#include <fstream>
#include <algorithm>

using namespace std;
ifstream cin("dfs.in");
ofstream cout("dfs.out");

int k, n, m, s, viz[101101], nr, start[201001], l[2][101101], x, y;

void liste(int i, int j)
{
    k++;
    l[0][k]=j;
    l[1][k]=start[i];
    start[i]=k;
    k++;
    l[0][k]=i;
    l[1][k]=start[j];
    start[j]=k;
}

void dfs(int s)
{
    int man=start[s];
    viz[s]=nr;
    while(man)
    {
        if(viz[l[0][man]]==0) dfs(l[0][man]);
        man=l[1][man];
    }
}

int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>x>>y;
        liste(x, y);
    }
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            nr++;
            dfs(i);
        }
    }
    cout<<nr<<'\n';
    return 0;
}
