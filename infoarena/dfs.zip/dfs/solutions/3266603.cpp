#include <bits/stdc++.h>

using namespace std;
ifstream fin ("dfs.in");
ofstream fout ("dfs.out");
vector <int> v[100005];
queue <int> q;
int n,m,x,y,g[100005],cnt;
void dfs (int nod,int nr)
{
    g[nod]=nr;
    for (int i:v[nod])
        if (g[i]==0)
            dfs(i,nr);
}
int main()
{
    int i;
    fin>>n>>m;
    for (i=1;i<=m;i++)
        {
            fin>>x>>y;
            v[x].push_back(y);
            v[y].push_back(x);
        }
    for (i=1;i<=n;i++)
        {
            if (g[i]==0)
                {
                    cnt++;
                    dfs(i,cnt);
                }
        }
    fout<<cnt;
    return 0;
}
