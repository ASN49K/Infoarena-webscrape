#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
void dfs(vector<vector<int>> adj, vector<int> &viz, int start){
    viz[start] = 1;
    for(int vecin : adj[start]){
        if(!viz[vecin]){
            dfs(adj, viz, vecin);
        }
    }
}
int main(){
    int n,m;
    fin >> n >> m;
    vector<vector<int>> adj(n+1);
    vector<int> viz(n+1, 0);
    while(m--){
        int a,b;
        fin >> a >> b;
        adj[a].push_back(b);
        adj[b].push_back(a);
    }
    int cnt = 0;
    for(int i = 1; i<=n; i++){
        if(viz[i] == 0) {
            dfs(adj, viz, i);
            cnt++;
        }
    }
    fout << cnt;
    return 0;
}