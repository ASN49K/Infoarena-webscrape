            #include <fstream>
            #include <map>

            using namespace std;

            ifstream cin("dfs.in");
            ofstream cout("dfs.out");



            struct per
            {
                int dir[101];

            }v[101];

            bool prez[1001];

            void dfs(int a)
            {
                for(int i=1;i<=v[a].dir[0];i++)
                {
                    if(prez[v[a].dir[i]]==0)
                    {
                       prez[v[a].dir[i]]=1;
                        dfs(v[a].dir[i]);
                    }

                }
            }

    int main()
    {
        int n,m;
        cin>>n>>m;
        for(int i=1;i<=m;i++)
        {
            int x,y;
            cin>>x>>y;
            v[x].dir[0]++;
            v[x].dir[v[x].dir[0]]=y;

            v[y].dir[0]++;
            v[y].dir[v[y].dir[0]]=x;






        }
        int cnt=0;
        for(int i=1;i<=n;i++)
        {
            if(prez[i]==0)
            {
                cnt++;
                 dfs(i);

            }

        }
            cout<<cnt;

        return 0;
    }


