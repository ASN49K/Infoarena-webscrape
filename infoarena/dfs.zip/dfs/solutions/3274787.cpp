#include<fstream>
#include<stack>
#include<vector>
using namespace std;
int v[100001];
stack <int> s;
vector <int> graf[100001];
void fill(int i){
  while(!s.empty()){
    int top=s.top();
    s.pop();
    for(int vecin:graf[top]){
      if(v[vecin]==0){
        v[vecin]=1;
        s.push(vecin);
      }
    }
  }
}
int main(){
  ifstream fin("dfs.in");
  ofstream fout("dfs.out");
  int n, m, x, y, cnt=0;
  fin>>n>>m;
  for(int i=0; i<m; i++){
    fin>>x>>y;
    graf[x].push_back(y);
    graf[y].push_back(x);
  }
  for(int i=1; i<=n; i++)
    if(v[i]==0){
      s.push(i);
      fill(i);
      cnt++;
    }
  fout<<cnt;

  return 0;
}
