#include <iostream>
#include <fstream>
#include <vector>
///#include <queue>
using namespace std;

ifstream fin ("dfs.in");
ofstream fout ("dfs.out");

///queue<int> q;
int vizi[100001];
int nr;
int timp;
vector<vector<int>> mat(100001);

int dfs(int tat)
{
    vizi[tat]=timp;
    for(vector<int>::iterator k=mat[tat].begin();k!=mat[tat].end();k++)
    {
        if(vizi[*k]==0)
        dfs(*k);
    }
}

int main()
{
    cout << "Hello world!" << endl;
    int n,m;
    fin>>n>>m;
    int tat,fiu;
    for(int k=1;k<=m;k++)
    {
        fin>>tat>>fiu;
        mat[tat].push_back(fiu);
        mat[fiu].push_back(tat);
        ///vizi[fiu]=1;
    }
    timp=1;
    for(int k=1;k<=n;k++)
    {
        if(vizi[k]==0)
        {
            dfs(k);
            nr++;
        }
    }
    fout<<nr;
    return 0;
}
