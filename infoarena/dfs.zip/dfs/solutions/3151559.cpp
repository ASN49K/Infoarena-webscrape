#include <fstream>
#include <vector>
using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

vector<int> v[100000];
int viz[100000];
int m, n;

void dfs(int x)
{
    for(int i = 0; i<v[x].size(); i++)
    {
        if(viz[v[x][i]] == 0)
        {
            viz[v[x][i]] = 1;
            dfs(x);
        }
    }
}

int main()
{
    cin >> n >> m;
    for(int i = 0; i<m; i++)
    {
        int a, b;
        cin >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }

    int k = 0;
    for(int i = 1; i<=n; i++)
        if(viz[i] == 0)
        {
            viz[i] = 1;
            dfs(i);
            k++;
        }

    cout << k;
}
