#include <fstream>

using namespace std;
ifstream in("cp.in");
ofstream out("cp.out");
int n,nrc=0,a[101][101],viz[101];
void DF(int x)
{
    viz[x]=nrc;
    for(int i=1;i<=n;i++)
        if(a[x][i]==1 && viz[i]==0)
            DF(i);
}
int main()
{
    int x,y;
    in>>n;
    while(in>>x>>y)
        a[x][y]=a[y][x]=1;
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            nrc++;
            DF(i);
        }
    }
    out<<nrc<<'\n';
    for(int i=1;i<=nrc;i++)
    {
        for(int j=1;j<=n;j++)
            if(viz[j]==i)
                out<<j<<' ';
        out<<'\n';
    }
    return 0;
}
