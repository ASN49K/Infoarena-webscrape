#include <iostream>
#include <fstream>
#include <vector>

void read_input(int &n, int &m, std::vector<std::vector<int>> &adj) {
    std::ifstream fin;
    int x, y;
    fin.open("dfs.in");
    fin >> n >> m;
    adj.resize(n + 1);
    for (int i = 0; i < m; i++) {
        fin >> x >> y;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    fin.close();
}

void write_output(int result) {
    std::ofstream fout;
    fout.open("dfs.out");
    fout << result << "\n";
    fout.close();
}

void dfs_rec(int node, std::vector<std::vector<int>> &adj, std::vector<bool> &visited) {
    visited[node] = true;
    for (int neigh : adj[node]) {
        if (!visited[neigh]) {
            dfs_rec(neigh, adj, visited);
        }
    }
}

void dfs(int n, std::vector<std::vector<int>> adj) {
    std::vector<bool> visited(n + 1, false);
    int conex_components = 0;
    for (int i = 1; i <= n; i++) {
        if (!visited[i]) {
            ++conex_components;
            dfs_rec(i, adj, visited);
        }
    }
    write_output(conex_components);
}


int main() {
    int n, m;
    std::vector<std::vector<int>> adj;
    read_input(n, m, adj);
    dfs(n, adj);
    return 0;
}