//https://www.infoarena.ro/problema/dfs
#include <bits/stdc++.h>
using namespace std;

int n,m,x,y,s, V[200], nrg;

vector<int> G[100100];


void dfs(int s){

    if(V[s]){
        return;
    }

    V[s] = 1;
    for(int i=0; i<G[s].size(); i++){
        dfs(G[s][i]);
    }
}

int main(){
    ifstream cin("dfs.in");
    ofstream cout("dfs.out");
    cin >> n >> m;
    s = 1;
    for(int i=1; i<=m; i++){
        cin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    for(int i=1; i<=n; i++){
        if(V[i] == 0){
            nrg++;
            dfs(i);
        }
    }

    cout << nrg;
}