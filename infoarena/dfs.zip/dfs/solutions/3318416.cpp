#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;

vector<vector<int>> L(100001);
vector<int> viz(100001);

void dfs(int nod) {
    viz[nod] = 1;
    for (int vecin : L[nod]) {
        if (viz[vecin] == 0) {
            dfs(vecin);
        }
    }
}

int main () {
    int cc = 0;
    int n, m;
    if (!(cin >> n >> m)) return 0;
    L.assign(n + 1, vector<int>());
    viz.assign(n + 1, 0);
    int x, y;
    for (int i = 0; i < m; i++) {
        if (!(cin >> x >> y)) break;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    for (int i = 1; i<=n; i++) {
        if (viz[i] == 0) {
            dfs(i);
            cc++;
        }
    }
    cout << cc << "\n";

    return 0;
}