#include <bits/stdc++.h>
using namespace std;
ifstream f("dfs.in"); ofstream g("dfs.out");
vector <int> L[100001];
int n,m,nr,viz[100001];
int dr,st,Q[100001];
void lee(int nod)
{   st=dr=1;
    Q[1]=nod;
    viz[nod]=nr;
    while(st<=dr)
    {   int x=Q[st];
        for(int i=0;i<L[nod].size();i++)
        if(viz[L[nod][i]]==0) {dr++; Q[dr]=L[nod][i];viz[L[nod][i]]=nr;  }
        st++;
    }
}
int main()
{   f>>n>>m;
    while(m--)
    {   int x,y;
        f>>x>>y;
        L[x].push_back(y);
        L[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(viz[i]==0)
        {   nr++;
            lee(i);

        }
    g<<nr;

    return 0;
}
