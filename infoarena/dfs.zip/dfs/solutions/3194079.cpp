#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");


const int NMAX = 100005;
vector <int> G[NMAX];
int n, m;
int vizitat[NMAX];
int conex = 0;

void read()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
}

void dfs(int nod)
{
    vizitat[nod] = 1;
    for(int vecin: G[nod])
    {
        if(!vizitat[vecin])
        {
            dfs(vecin);
        }
    }
}

int main()
{
    read();
    for(int i = 1; i <= n; i++)
    {
        if(!vizitat[i])
        {
            dfs(i);
            conex++;
        }
    }
    fout << conex;
}