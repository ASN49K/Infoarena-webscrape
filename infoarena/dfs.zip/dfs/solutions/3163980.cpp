#include <fstream>
#include <bitset>
#include <vector>
#define Max 100001
using namespace std;

ifstream fin ("dfs.in");
ofstream fout("dfs.out");

bitset <Max> viz;
vector <int> graph[Max];

int n, m, c;

void read()
{
    fin >> n >> m;
    for (int i = 1 ; i <= m ; ++i)
    {
        int x, y;
        fin >> x >> y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }
}

void dfs (int node)
{
    viz[node] = 1;
    for (int i : graph[node])
        if (!viz[i])
            dfs(i);
}

int main()
{
    read();
    for (int i = 1 ; i <= n ; ++i)
        if (!viz[i])
        {
            ++c;
            dfs(i);
        }
    fout << c;

    fin.close(); 
    fout.close();
    return 0;
}