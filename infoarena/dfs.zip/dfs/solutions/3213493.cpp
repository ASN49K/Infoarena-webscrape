#include<iostream>
#include<vector>
#include<fstream>
#include<stack>

std::ifstream fin("dfs.in");
std::ofstream fout("dfs.out");

const int limita = 100005;
int N,M;
int conexe = 0;

bool visited[limita];
std::vector<int> graph[limita];

void DFS(int k){
    visited[k] = true;
    for(unsigned int i =0; i< graph[k].size();i++){
        int vecin = graph[k][i];
        if(!visited[vecin]){
            DFS(vecin);
        }
    }
}



int main(){

    fin>>N>>M;
    for(int i=1; i<=M; i++){
        int x, y;
        fin>>x>>y;
        graph[x].push_back(y);
        graph[y].push_back(x);

    }

    DFS(1);

    for(int i = 0; i<=N; i++){
        if(!visited[i]){
            conexe += 1;
            DFS(i);
        }
    }

    fout<<conexe;
    
    fin.close();
    fout.close();
    return 0;
}