#include <fstream>
#include <iostream>
#include <queue>
#include <vector>
using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");
int m, n, s;
vector<vector<int>> lista;
queue<int> coada;
vector<int> viz;
vector<int> d;
vector<int> tata;

void DFS(int x) {
  // Setăm x ca fiind vizitat (dar gri)
  viz[x] = 1;

  // luam ca fiind y un vecin al lui x
  for (auto &y : lista[x]) {
    if (viz[y] == 0) {
      // reapelăm pentru fiecare vecin
      DFS(y);
    }
  }
}

int main() {
  f >> n >> m >> s;
  int x1, x2;
  lista.resize(n + 1);
  viz.resize(n + 1);
  d.resize(n + 1, 0);
  tata.resize(n + 1, -1);

  for (int i = 1; i <= m; i++) {
    f >> x1 >> x2;
    lista[x1].push_back(x2);
    lista[x2].push_back(x1);
  }

  int nr_componente = 0;
  for (int i = 1; i <= n; i++) {
    if (viz[i] == 0) {
      DFS(i);
      nr_componente++;
    }
  }

  g << nr_componente;

  f.close();
  g.close();

  return 0;
}
