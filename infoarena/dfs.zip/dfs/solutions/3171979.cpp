#include <fstream>
#include <vector>

using namespace std;

ifstream fi("dfs.in");
ofstream fo("dfs.out");
vector<int> vecini[100001];
int n, m, ncc; // numarul de componente conexe
bool viz[100001];

void citire() {
    int i, x, y;

    fi >> n >> m;
    for (i = 1; i <= m; i++) {
        fi >> x >> y;
        vecini[x].push_back(y);
        vecini[y].push_back(x);
    }
}

void df(int nod) {
    int i;

    viz[nod] = true;
    for (auto i : vecini[nod])
       if (not viz[i])
            df(i);
}

int main() {
    int i;

    citire();
    for (i = 1; i <= n; i++)
        if (not viz[i]) {
            ncc++;
            df(i);
        }
    fo << ncc;
    return 0;
}