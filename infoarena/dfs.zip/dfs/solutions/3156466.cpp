//nr componentelor conexe - DFS 
#include<iostream>
#include<vector>
#include<fstream>

using namespace std;

const int NMAX = 10e5;
vector<int>G[NMAX];
int vis[NMAX];

ifstream fin("dfs.in");
ofstream fout("dfs.out");

void DFS(int x)
{
    vis[x] = 1;
    for(auto next : G[x])
    {
        if(!vis[next])
            DFS(next);
    }
}

int main()
{
    int n, m;
    fin >> n >> m;
    for(int i=1; i<=m; i++)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    int cc = 0;
    for(int i=1;i<=n;i++)
    {
        if(!vis[i])
        {
            cc++;
            DFS(i);
        }
    }
    fout<<cc;
}