#include <bits/stdc++.h>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int main() {
    int n, m;
    fin >> n >> m;
    vector<vector<int>> a(n + 1);
    vector<bool> visited(n + 1, false);
    for (int i = 0; i < m; i++) {
        int x, y;
        fin >> x >> y;
        a[x].push_back(y);
        a[y].push_back(x);
    }
    int componente = 0;
    for (int i = 1; i <= n; i++) {
        if (!visited[i]) {
            componente++;
            stack<int> st;
            st.push(i);
            visited[i] = true;
            while (!st.empty()) {
                int u = st.top();
                st.pop();

                for (int v : a[u]) {
                    if (!visited[v]) {
                        visited[v] = true;
                        st.push(v);
                    }
                }
            }
        }
    }
    fout << componente;
    return 0;
}

