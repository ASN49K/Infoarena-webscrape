#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");
const int maxim=100005;
int n, m, nr_componente;
vector<int>v[maxim];
bool vizitat[maxim]={false};

void DFS(int nod){
    int i, e, s, con=0;
    vizitat[nod]=true;

    for(const auto vecin: v[nod]){
        if(vizitat[vecin]==false){
            DFS(vecin);
        }
    }
}

int main(){

    int i, e, s, cont=0, a, b, c;
    f >> n >> m;
    for(i=1; i<=m; ++i){
        f >> a >> b;
        v[a].push_back(b);
        v[b].push_back(a);
    }

    for(i=1; i<=n; ++i)
        if(vizitat[i]==false){
            nr_componente++;
            DFS(i);
        }

    g << nr_componente;


    return 0;
}
