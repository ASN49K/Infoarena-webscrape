#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
vector<int> vecini[100001];
bool vizitat[100001] = {0};
void dfs(int sursa){
    vizitat[sursa] = 1;
    for (int i = 0; i < vecini[sursa].size(); i++){
        int vecin = vecini[sursa][i];
        if (vizitat[vecin] == 0) {
            dfs(vecin);
        }
    }
}
int main(){
    int componente_conexe = 0;
    int noduri, muchii;
    fin >> noduri >> muchii;
    for (int i = 1; i <= muchii; i++){
        int x, y;
        fin >> x >> y;
        vecini[x].push_back(y);
        vecini[y].push_back(x);
    }
    for (int i = 1; i <= noduri; i++){
        if (vizitat[i] == 0){
            componente_conexe++;
            dfs(i);
        }
    }
    fout << componente_conexe;
    return 0;
}