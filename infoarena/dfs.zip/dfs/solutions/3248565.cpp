#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int use[100005],N,M;
const int NMax = 100000;
vector <int> G[NMax + 5];
void DFS(int Nod,int Tata)
{
    use[Nod]=1;
    for(auto Vecini : G[Nod])
        if(use[Vecini]==0)
        DFS(Vecini,Nod);
}
int main()
{
    int x,y,k=0;
    fin>>N>>M;
    for(int i=0;i<M;i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    for(int i=1;i<=N;i++)
    if(use[i]==0)
    {
    DFS(i,0);
    k++;
    }
    fout<<k;
    return 0;
}
