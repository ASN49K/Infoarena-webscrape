#include <fstream>
#include <vector>
using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

vector<vector<int>> adj;
vector<bool> vis;

void dfs(int n)
{

    if (!vis[n])
    {
        vis[n] = true;
        for (const auto &neigh : adj[n])
        {
            if (!vis[neigh])
                dfs(neigh);
        }
    }
}

int main()
{
    int n, m, res = 0;
    cin >> n >> m;

    adj.assign(n + 1, vector<int>());
    vis.assign(n + 1, false);

    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    for (int i = 0; i < n; i++)
    {
        if (!vis[i])
        {
            res++;
            dfs(i);
        }
    }

    cout << res;
    return 0;
}