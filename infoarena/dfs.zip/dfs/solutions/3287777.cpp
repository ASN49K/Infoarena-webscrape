#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int MAXN = 100005;

vector<int> adiacenta[MAXN]; // Liste de adiacenta folosind vectori

void dfs(int nod, bool vizitat[]) {
    vizitat[nod] = true;
    for (int vecin : adiacenta[nod]) {
        if (!vizitat[vecin]) {
            dfs(vecin, vizitat);
        }
    }
}

int main() {
    ifstream fin("dfs.in");
    ofstream fout("dfs.out");

    int n, m;
    fin >> n >> m;

    // Citire muchii
    for (int i = 0; i < m; i++) {
        int u, v;
        fin >> u >> v;
        adiacenta[u].push_back(v);
        adiacenta[v].push_back(u); // Graf neorientat
    }

    // Initializare vector vizitat
    bool vizitat[MAXN];
    for (int i = 1; i <= n; i++) {
        vizitat[i] = false;
    }

    int componenteConexe = 0;
    for (int i = 1; i <= n; i++) {
        if (!vizitat[i]) {
            dfs(i, vizitat);
            componenteConexe++;
        }
    }

    fout << componenteConexe << endl;

    fin.close();
    fout.close();

    return 0;
}
