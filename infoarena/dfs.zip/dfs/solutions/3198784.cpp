#include <fstream>
#include <vector>
using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.in");

const int N = 100005;

vector<vector<int>> graf;
vector<bool> viz;

struct nod{
    int n1, n2;
}e;

void dfs(int nod)
{
    viz[nod] = true;
    for (int i: graf[nod]){
        if(!viz[i])
            dfs(i);
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    graf.resize(N);
    viz.assign(N, false);
    for(int i = 0; i < m; i++){
        cin >> e.n1 >> e.n2;
        graf[e.n1].push_back(e.n2);
        graf[e.n2].push_back(e.n1);
    }
    int nr = 0;
    for(int i = 1; i <= n; i++){
        if(!viz[i]){
            nr++;
            dfs(i);
        }
    }
    cout << nr;
    return 0;
}
