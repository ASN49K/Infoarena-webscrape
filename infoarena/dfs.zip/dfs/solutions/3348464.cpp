#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

const int NMAX = 100001;

long long n, m;
bool vizitat[NMAX];
vector<long long> v[NMAX];

ifstream fin("dfs.in");
ofstream fout("dfs.out");

void parcurgere(long long nod)
{
    vizitat[nod] = true;
    for (auto next : v[nod])
    {
        if (!vizitat[next])
            parcurgere(next);
    }
}

int main()
{
    fin >> n >> m;

    long long x, y;
    for (long long i = 0; i < m; i++)
    {
        fin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
    }

    long long componente = 0;

    for (long long i = 1; i <= n; i++)
    {
        if (!vizitat[i])
        {
            parcurgere(i);
            componente++;
        }
    }

    fout << componente;

    return 0;
}
