#include <iostream>
#include <bits/stdc++.h>
#include <vector>
#include <bitset>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

const int nmax=1e5;

bitset<nmax> viz;

vector<vector<int>> graf;


void dfs(int nod){
    viz[nod]=1;
    for(int i: graf[nod]){
        if(!viz[i]){
           dfs(i);
        }
    }

}


int main()
{
    int n,m,i,x,y,res=0;
    fin>>n>>m;
    graf.assign(n,vector<int>());
    for(i=0;i<m;i++){
        fin>>x>>y;
        x-=1; y-=1;
        graf[y].emplace_back(x);
        graf[x].emplace_back(y);

    }

    for(i=0;i<n;i++){
        if(!viz[i]){
            dfs(i); res++;
        }
    }

    fout<<res;

    graf.clear();
    return 0;


}
