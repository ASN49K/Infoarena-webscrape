#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<vector<int>> A;
int vis[100005];
int n,m;
void DFS(int nod){

    vis[nod]=1;
    for(int i = 0; i < A[nod].size(); i++){
        if(vis[A[nod][i]] == 0){
            DFS(A[nod][i]);
        }
    }

}

int main()
{
    fin>>n>>m;
    A.resize(n+1);
    int a, b, cnt=0;
    for(int i = 1; i <=m; i++){
        fin>>a>>b;
        A[a].push_back(b);
        A[b].push_back(a);
    }
    for(int i = 1; i<=n; i++){
        if(vis[i]==0){
            DFS(i);
            cnt++;
        }
    }
    fout<<cnt;
    return 0;
}
