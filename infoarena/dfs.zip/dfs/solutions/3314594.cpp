#include <iostream>
#include <vector>
#include <fstream>

std::vector<int> L[100001];
bool vis[100001];

void dfs(int nod){
    // std::cout << nod << ' ';
    vis[nod] = 1;
    for ( int i = 0; i < L[nod].size(); i++){
        int vecin = L[nod][i];
        if ( !vis[vecin] ){
            dfs(vecin);
        }
    }
}

int main(){
    std::ifstream fin("dfs.in");
    std::ofstream fout("dfs.out");
    int n,m;
    fin >> n >> m;
    for ( int i = 0; i < m; i++ ){
        int x, y;
        fin >> x >> y;
        L[x].push_back(y);
        L[y].push_back(x);
        
        
    }
    // dfs(1);
    int cc = 0;
    for ( int i = 0; i < n; i++ ){
        if (!vis[i]){
            dfs(i);
            cc++;
        }
    }
    fout << cc;
}