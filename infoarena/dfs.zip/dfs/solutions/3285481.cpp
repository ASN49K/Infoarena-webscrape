#include <fstream>
#include <vector>
using namespace std;
ifstream cin("dfs.in");
ofstream cout("dfs.out");

int n,m,cnt;
vector <int> lista[100001];
int viz[100001];

void dfs(int nod)
{
    viz[nod]=1;
    for(auto x:lista[nod])
    {
        if(viz[x]==0)
            dfs(x);
    }
}

int main()
{
    int i,x,y;
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y;
        lista[x].push_back(y);
        lista[y].push_back(x);
    }
    for(i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            cnt++;
            dfs(i);
        }
    }
    cout<<cnt;
    return 0;
}