// https://infoarena.ro/problema/dfs - Szucs Patrik - Kevin
#include <fstream>
#include <vector>
#include <queue>

void dfs(std::vector<std::vector<int>> &graf, std::vector<bool> &vis, int a)
{
    vis[a] = true;
    for (auto elem : graf[a])
    {
        if (!vis[elem])
        {
            dfs(graf, vis, elem);
        }
    }
    return;
}

int main()
{
    int n, m;

    std::ifstream in("dfs.in");
    in >> n >> m;

    std::vector<std::vector<int>> graf(n);
    while (m--)
    {
        int x, y;
        in >> x >> y;

        x--;
        y--;
        graf[x].push_back(y);
        graf[y].push_back(x);
    }
    in.close();

    int db = 0;
    std::vector<bool> vis(n);
    for (; n > 0; n--)
    {
        if (!vis[n - 1])
        {
            dfs(graf, vis, n - 1);
            db++;
        }
    }

    std::ofstream out("dfs.out");
    out << db;
    out.close();

    return 0;
}