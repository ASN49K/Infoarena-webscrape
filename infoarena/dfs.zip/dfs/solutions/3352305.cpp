#include <fstream>
#include <vector>
using namespace std;

ifstream cin("dfs.in");
ofstream cout("dfs.out");

struct point {
    vector <int> V;
};

point X[100005];
int N[100005];

void dfs(int i, int val) {
    N[i]=val;
    for (int j=1; j<=X[i].V.size(); j++) {
        if (N[X[i].V[j]]==0) dfs(X[i].V[j], val);
    }
}

int main() {
    int n, m;
    cin>>n>>m;
    for (int i=1; i<=m; i++) {
        int x, y;
        cin>>x>>y;
        X[x].V.push_back(y);
        X[y].V.push_back(x);
    }
    int rasp=0;
    for (int i=1; i<=n; i++) {
        if (N[i]==0) {
            rasp++;
            dfs(i, rasp);
        }
    }
    cout<<rasp;
}
