#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m, x, y, viz[100001], cnt;
vector<int> G[100001];

void DFS(int nod)
{
    viz[nod] = 1;
    for(int i = 0; i < G[nod].size(); i++)
    {
        if(viz[G[nod][i]] == 0)
        {
            viz[G[nod][i]] = 1;
            DFS(G[nod][i]);
        }
    }
}

int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        fin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    for(int i = 1; i <= n; i++)
    {
        if(viz[i] == 0)
        {
            cnt++;
            DFS(i);
        }
    }
    fout << cnt;

    return 0;
}
