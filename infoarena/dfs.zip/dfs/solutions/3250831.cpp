#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream f("dfs.in");
ofstream g("dfs.out");

vector<vector<int>> LM(100000);
int n, m;

void CitireDate()
{
    f >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        f >> x >> y;
        LM[x].push_back(y);
    }
}
int viz[100000];
void ParcurgereInAdancime(int x, int numarcompConexa)
{
    viz[x] = numarcompConexa;
    for (int nod = 1; nod <= n; nod++)
        if (viz[nod] == 0 && LM[x][nod] == 1)
            ParcurgereInAdancime(nod, numarcompConexa);
}

int main()
{
    CitireDate();

    int numarComponenteConexe = 0;
    for (int nod = 1; nod <= n; nod++)
    {
        if (viz[nod] == 0)
        {
            numarComponenteConexe++;
            ParcurgereInAdancime(nod, numarComponenteConexe);
        }
    }

    g << numarComponenteConexe;
}
