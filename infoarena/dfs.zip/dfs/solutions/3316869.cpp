#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out"):

int N, M;
vector<int> adj[100005];
bool vizitat[100005]

void dfs(int u) {
    vizitat[u] = true;
    for (int v : adj[u]){
        if(!vizitat[v])
            dfs(v);
    }

}

void solve() {
        fin >> N >> M;
        for (int i = 0; i < M; ++i) {
            int u, v;
            fin >> u >> v;
            adj[u].push_back(v);
            adj[v].push_back(u);
        }
        int nr_cc = 0;
        for(int i = 0; i <= N; ++i){
            if (!vizitat[i]) {
                nr_cc++;
                dfs(i);
            }
        }
        fout << nr_cc << endl;

}
int main()
{
    solve();
    return 0;
}
