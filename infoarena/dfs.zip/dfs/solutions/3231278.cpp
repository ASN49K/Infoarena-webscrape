#include <fstream>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");
struct nod{
    int info;
    nod* urm;
};
void dfs(int x)
{
    viz[x]=1;
    for(nod* p=v[x];p;p=p->urm)
        if(viz[p->info]==0)
            dfs(p->info);
}
nod* v[100001],viz[100001];
int main()
{
   int x,y;
   while(f>>x>>y)
   {
        nod *p=new nod;
        p->info=y;
        p->urm=v[x];
        v[y]=p;
   }
    return 0;
}
