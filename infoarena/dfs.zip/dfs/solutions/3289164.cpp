#include <bits/stdc++.h>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
const int NMAX = 1e5 + 5;
vector<int> vec[NMAX];
bitset<NMAX> vis;
vector<vector<int>> comps;

void dfs(int nod, vector<int>& comp)
{
    vis[nod] = 1;
    comp.push_back(nod);
    for(auto vecin : vec[nod])
        if(!vis[vecin])
            dfs(vecin, comp);
}

signed main()
{
    int n, m;
    fin >> n >> m;
    while(m--)
    {
        int i, j;
        fin >> i >> j;
        vec[i].push_back(j);
        vec[j].push_back(i);
    }
    for(int i = 1; i <= n; i++)
    {
        if(!vis[i])
        {
            vector<int> comp;
            dfs(i, comp);
            comps.push_back(comp);
        }
    }
    fout << comps.size();

    return 0;
}
