﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 16
VisualStudioVersion = 16.0.31729.503
MinimumVisualStudioVersion = 10.0.40219.1
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "Rude", "Rude\Rude.vcxproj", "{3FDCC86F-326C-4639-9A8D-F708E7B99229}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|x64 = Debug|x64
		Debug|x86 = Debug|x86
		Release|x64 = Release|x64
		Release|x86 = Release|x86
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{3FDCC86F-326C-4639-9A8D-F708E7B99229}.Debug|x64.ActiveCfg = Debug|x64
		{3FDCC86F-326C-4639-9A8D-F708E7B99229}.Debug|x64.Build.0 = Debug|x64
		{3FDCC86F-326C-4639-9A8D-F708E7B99229}.Debug|x86.ActiveCfg = Debug|Win32
		{3FDCC86F-326C-4639-9A8D-F708E7B99229}.Debug|x86.Build.0 = Debug|Win32
		{3FDCC86F-326C-4639-9A8D-F708E7B99229}.Release|x64.ActiveCfg = Release|x64
		{3FDCC86F-326C-4639-9A8D-F708E7B99229}.Release|x64.Build.0 = Release|x64
		{3FDCC86F-326C-4639-9A8D-F708E7B99229}.Release|x86.ActiveCfg = Release|Win32
		{3FDCC86F-326C-4639-9A8D-F708E7B99229}.Release|x86.Build.0 = Release|Win32
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
	GlobalSection(ExtensibilityGlobals) = postSolution
		SolutionGuid = {1C237824-D42B-47A7-9904-C9EE10DB22FA}
	EndGlobalSection
EndGlobal
