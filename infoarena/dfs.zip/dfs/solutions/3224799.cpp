#include <bits/stdc++.h>

using namespace std;
ifstream in("dfs.in");
ofstream out("dfs.out");

void dfs(int node, vector<bool> &visited, vector<vector<int>> &adj) { 
    visited[node] = true;

    for (auto neigh : adj[node]) {
        if (!visited[neigh]) {
            dfs(neigh, visited, adj);
        }
    }
}

int main() {
    int n, m, node, x;
    int comp = 0;
    in >> n >> m;

    vector<vector<int>> adj(n + 1);
    vector<bool> visited(n + 1, false);

    for (int i = 0; i < m; i++) {
        in >> node >> x;
        adj[node].push_back(x);
    }

    for (node = 1; node <= n; node++) {
        if (!visited[node]) {
            comp++;
            dfs(node, visited, adj);
        }
    }

    out << comp << '\n';

    in.close();
    out.close();
    
    return 0;
}