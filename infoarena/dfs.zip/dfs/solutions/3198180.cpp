#include <bits/stdc++.h>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n,m;
vector<vector<int> > G;
vector<int> viz;

void dfs(int nod,int nrcomp){
    viz[nod]=nrcomp;
    for(auto t:G[nod]){
        if(viz[t]==0)
            dfs(t,nrcomp);
    }
}

int main()
{
    fin>>n>>m;
    int nrcomp=1;
    G=vector<vector<int> > (min(200000,n*(n+1)/2) +1);
    viz=vector<int> (n+1);
    for(int i=1;i<=m;++i){
        int x,y;
        fin>>x>>y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    for(int i=1;i<=n;++i){
        if(viz[i]==0)
            dfs(i,nrcomp),nrcomp++;
    }
    fout<<nrcomp-1;
    return 0;
}
