#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");
const int NMAX = 100001;
vector<int> adj[NMAX];
int cc[NMAX];

void dfs(int x)
{
    for (auto vec: adj[x])
    {
        if (cc[vec] == 0) //nu l-am vizitat pana acum
        {
            cc[vec] = cc[x];
            dfs(vec);
        }
    }
}

int main()
{
    int n, m;
    f >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int u, v;
        f >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    int nrCompCon = 0;
    for (int i = 1; i <= n; i++)
    {
        if (cc[i] == 0) /// am gasit o noua comp conexa
        {
            nrCompCon++;
            cc[i] = nrCompCon;
            dfs(i);
        }
    }
    g << nrCompCon;
    return 0;

}