#include <bits/stdc++.h>

using namespace std;
ifstream in("componenteconexe.in");
ofstream out("componenteconexe.out");
int a[101][101],nrc=0,viz[101],n,x,y;
void df(int x)
{
    viz[x]=nrc;
    for(int i=1; i<=n; i++)
        if(a[x][i]==1 && viz[i]==0)
            df(i);
}
int main()
{
    in>>n;
    while(in>>x>>y)
    {
        a[x][y]=a[y][x]=1;
    }
    for(int i=1; i<=n; i++)
    {
        if(viz[i]==0)
        {
            nrc++;
            df(i);
        }
    }
    out<<nrc<<'\n';
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
            if(viz[j]==i)
                out<<j<<' ';
        out<<'\n';
    }

    return 0;
}
