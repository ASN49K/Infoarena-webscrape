#include <iostream>
#include <vector>
#include <fstream>
#include <stack>

using namespace std;

const int NMAX = 1e5;
vector <int> G[NMAX+1];
stack <int> stiva;
int V[NMAX+1];

void DFS(int s){
    stiva.push(s);
    for(auto x:G[s])
    {
        if(!V[x]){
            V[x] = 1;
            DFS(x);
        }
    }
    stiva.pop();
}

int main(){
    ifstream f("dfs.in");
    int n, m;
    f>>n>>m;
    for(int i=1; i<=m; i++){
        int x,y;
        f>>x>>y;
        G[x].push_back(y);
    }
    f.close();
    for(int i=1; i<=n; i++)
        V[i] = 0;
    int count=0;
    for(int i=1; i<=n; i++){
        if(!V[i]){
            V[i] = 1;
            DFS(i);
            count++;
        }
    }
    ofstream g("dfs.out");
    g<<count;
    g.close();
}
