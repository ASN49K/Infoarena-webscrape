#include <fstream>
#include <vector>

using namespace std;

vector<int> adj[100001];
int visited[100001];

void dfs(int node, int n)
{	
	visited[node] = 1;
	for (int i = 0; i < adj[node].size(); ++i) {
		if (!visited[adj[node][i]])
			dfs(adj[node][i], n);
	}
}

int main() 
{
	ifstream cin("dfs.in");	
	ofstream cout("dfs.out");
	int n, m;
	cin >> n >> m;
	for (int i = 0; i < m; i++) {
		int x, y;
		cin >> x >> y;
		adj[x].push_back(y);
		adj[y].push_back(x);
	}

	// for (int i = 1; i <= n; i++) {
	// 	cout << "pentru " << i << ": ";
	// 	for (int j = 0; j < adj[i].size(); ++j)
	// 		cout << adj[i][j] << " ";
	// 	cout << endl;
	// }

	int nrc = 0;
	for (int i = 1; i <= n; ++i) {
		if (!visited[i]) {
			nrc++;
			dfs(i, n);
		}
	}
	cout << nrc;

	return 0;
}

