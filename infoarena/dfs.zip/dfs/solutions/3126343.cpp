#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
const int Nmax=100005;
vector<int> v[Nmax];
int f[Nmax];
void comp(int i)
{
    f[i]=1;
    for(int j=0;j<v[i].size();j++)
    {
        if(f[v[i][j]]==0)
        {
            comp(v[i][j]);
        }
    }
    return;
}
int main()
{
    int n,m;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    int cnt=0;
    for(int i=1;i<=n;i++)
    {
        if(f[i]==0)
        {
            cnt++;
            comp(i);
        }
    }
    fout<<cnt<<'\n';
    return 0;
}
