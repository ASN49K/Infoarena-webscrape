#include <bits/stdc++.h>
#define ll long long
#define pb push_back
using namespace std;
vector<vector<int>>adj(100000);
bool vis[100000];
void dfs(int nod){
    vis[nod] = 1;
    for(auto v : adj[nod]){
        if(!vis[v]) dfs(v);
    }
}

int main()
{   
    freopen("dfs.in","r",stdin);
    freopen("dfs.out","w",stdout);
    int n,m;
    cin >> n >> m;
    for(int i =0;i<m;i++){
        int a,b;
        cin >> a >> b;
        adj[a].pb(b);
        adj[b].pb(a);
    }
    int ans = 0;
    for(int i =0;i<n;i++){
        if(!vis[i]){
            ans++;
            dfs(i);
        }
    }
    cout << ans;
  
    
    
    


    return 0;
}
