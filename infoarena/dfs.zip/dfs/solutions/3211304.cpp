﻿#include <bits/stdc++.h>
#include <unordered_map>
#define nmax 100005
#define MOD 666013
#define INF 2012345678
#define ll long long
using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n, m;
vector <int> L[nmax];
bitset <nmax> viz;

void DFS(int k)
{
    stack <int> st;
    st.push(k);
    viz[k] = 1;
    while (!st.empty())
    {
        k = st.top();
        st.pop();
        for (int i : L[k])
            if (viz[i] == 0)
            {
                st.push(i);
                viz[i] = 1;
            }
    }
}

int main()
{
    int i, j, q, cnt;
    fin >> n >> m;
    for (q = 1; q <= m; q++)
    {
        fin >> i >> j;
        L[i].push_back(j);
        L[j].push_back(i);
    }
    cnt = 0;
    for (i = 1; i <= n; i++)
        if (viz[i] == 0)
        {
            ++cnt;
            DFS(i);
        }
    fout << cnt << "\n";
    fin.close();
    fout.close();
    return 0;
}