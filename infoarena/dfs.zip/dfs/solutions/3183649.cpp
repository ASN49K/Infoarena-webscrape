#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <cmath>
using namespace std;

int use[100001], nr=0;
vector<int> v[100001];

void dfs (int nod)
{
    int i;
    use[nod]=1;
    for (i=0; i<v[nod].size(); i++)
        if (!use[v[nod][i]])
        {
            dfs(v[nod][i]);
            nr++;
        }
}
int main()
{
    ifstream fin("dfs.in");
    ofstream fout ("dfs.out");
    int N, M, x, y, i;
    fin>>N>>M;
    for (i=1; i<=M; i++)
    {
        fin>>x>>y;
        v[y].push_back (x);
        v[x].push_back (y);
    }
    dfs(1);
    for (i=1; i<=N; i++)
        dfs(i);
    fout<<N-nr;
    fin.close();
    fout.close();
    return 0;
}
