#include <fstream>

using namespace std;
ifstream fin("dfs.in");
ofstream fout("dfs.out");
int n,m,x,y,M[1001][1001],viz[1001];
void dfs(int node)
{
    viz[node]=1;
    for(int i=1; i<=n; i++)
    {
        if(M[node][i]==1 && viz[i]==0)
            dfs(i);
    }
}
int main()
{
    int cnt=0;
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        fin>>x>>y;
        M[x][y]=M[y][x]=1;
    }
    for(int j=1; j<=n; j++)
    {
        if(viz[j]==0)
        {
            dfs(j);
            cnt++;
        }
    }
    fout<<cnt;
    return 0;
}
