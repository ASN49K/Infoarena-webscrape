#include <bits/stdc++.h>

using namespace std;

ifstream fin("dfs.in");
ofstream fout("dfs.out");

int n,m,viz[100002];
vector <int> Liste[100002];

void Dfs(int x)
{
    viz[x]=1;
    for(int i:Liste[x])
        if(viz[i]==0)
        Dfs(i);
}

int main()
{
    int i,j,nrc=0;
    fin>>n>>m;
    while(m--)
    {
        fin>>i>>j;
        Liste[i].push_back(j);
        Liste[j].push_back(i);
    }
    for(i=1;i<=n;i++)
        if(viz[i]==0)
        {
            nrc++;
            Dfs(i);
        }
    fout<<nrc;
    return 0;
}
