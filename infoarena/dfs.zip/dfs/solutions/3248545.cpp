#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

int N , M ;
vector<bool>visited;
ifstream fin("dfs.in");
ofstream fout("dfs.out");

vector<vector<int>>adjList ;
void citire(int M) {
    for( int i = 1 ; i <= M ; i++ ) {
        int x , y;
        adjList[x].push_back(y);
        adjList[y].push_back(x);}
}
void dfs(int node){
    visited[node]=true;
    for(int x : adjList[node])
        if(!visited[x])
            dfs(x);

}

int main() {
    fin >> M >> N;
    adjList.resize(N+1);
    visited.resize(N+1);
    citire(M);
    int count = 0;
    for(int i = 1 ; i <= N ; i++)
        if(!visited[i])
        {count++;
            dfs(i);

            cout<<count<<endl;
            return 0;
        }
}
