#include <fstream>
#include <cmath>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

int n, k, x[15], ok, nr;

int cont(int k)
{
    for(int i=1; i<k; i++)
        if(x[i] == x[k] || k-i == abs(x[i]-x[k])) return 0;
    return 1;
}

void afis()
{
    if(!ok)
    {   for(int i=1; i<=n; i++) g << x[i] << ' ';
        g << '\n';
        ok = 1;
    }
    nr++;
}

void Back(int k)
{
    for(int i=1; i<=n; i++)
    {
        x[k] = i;
        if(cont(k)) if(k == n) afis();
                        else Back(k+1);
    }
}

int main()
{
    f >> n;
    Back(1);
    g << nr << '\n';
    return 0;
}
