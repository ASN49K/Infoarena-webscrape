#include <iostream>
#include <fstream>

#pragma GCC optimise ("O3");

using namespace std;
ifstream fin ("damesah.in");
ofstream fout ("damesah.out");
const int Nmax=13;

string mat[Nmax];
int lin[Nmax], col[Nmax], d1[2*Nmax], d2[2*Nmax], sol, N, v[Nmax], ind, l, c;

inline void nxt_cell(){
    if (c!=N-1)
        c++;
    else{
        l++;
        c=0;
    }
}
inline void prev_cell(){
    if (c!=0)
        c--;
    else{
        l--;
        c=N-1;
    }
}
inline void bkt(){
    if (ind==N){
        if (sol==0){
            for (int i=0; i<N; i++)
                fout<<v[i]<<' ';
            fout<<'\n';
        }
        sol++;
        return;
    }
    if (l>=N || l==N-1 && c==N)
        return;
    if (lin[l]==0 && col[c]==0 && d1[l-c+N-1]==0 && d2[l+c]==0){
        lin[l]=1;
        v[l]=c+1;
        col[c]=1;
        d1[l-c+N-1]=1; 
        d2[l+c]=1;

        ind++;
        nxt_cell();
        bkt();
        ind--;
        prev_cell();
        lin[l]=0; 
        col[c]=0;
        d1[l-c+N-1]=0; 
        d2[l+c]=0;
    }
    nxt_cell();
    bkt();
    prev_cell();
}

int main(){
    fin>>N;
    bkt();
    fout<<sol;

    return 0;
}