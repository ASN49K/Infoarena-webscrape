#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n, x[14], cnt;
bool ok, p[14];

void afis()
{
    for(int i=1; i<=n; i++)
        fout<<x[i]<<' ';

    fout<<'\n';
    ok=true;
}

bool valid(int k)
{
    for(int i=1; i<k; i++)
        if(k-i==abs(x[k]-x[i]))
        return false;

    return true;
}

void btk(int k)
{
    for(int i=1; i<=n; i++)
        if(!p[i])
    {
        x[k]=i;
        p[i]=1;

        if(valid(k))
        {
            if(k==n)
            {
                if(!ok)
                afis();

                cnt++;
            }
            else btk(k+1);
        }

        p[i]=0;
    }
}

int main()
{
    fin>>n;
    fin.close();

    btk(1);

    fout<<cnt;

    fout.close();
    return 0;
}
