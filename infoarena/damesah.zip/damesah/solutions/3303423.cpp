#include <bits/stdc++.h>
using namespace std;

int nrsol = 0;
int sol[20];

bool valid(int k)
{
    for(int i = 1; i < k; i++)
    {
        if((sol[k] == sol[i]) || (k - i == abs(sol[k] - sol[i])))
            return false;
    }
    return true;
}

void bkt(int n, int k)
{
    if(n < k)
    {
        nrsol++;
        if(nrsol == 1)
        {
            for(int i = 1; i <= n; i++)
            {
                cout << sol[i] << " ";
            }
            cout << "\n";
        }
        return;
    }
    for(int i = 1; i <= n; i++)
    {
        sol[k] = i;
        if(valid(k))
        {
            bkt(n, k + 1);
        }
    }
    sol[k] = 0;
    return;
}

int main()
{
    freopen("damesah.in", "r", stdin);
    freopen("damesah.out", "w", stdout);
    int n;
    cin >> n;
    bkt(n, 1);
    cout << nrsol;
}