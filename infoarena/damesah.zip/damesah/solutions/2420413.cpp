#include <iostream>

FILE * fin= fopen("damesah.in","r");
FILE * fout=fopen("damesah.out","w");

bool d1[17];
bool d2[40];
bool c[17];
int t[17];
int v[17];
int n;
long long found;
int pos;

void write()
{
  for(int i=0;i<n;i++)
    fprintf(fout,"%d ",v[i]+1);
  fprintf(fout,"\n");
}

int main()
{
  fscanf(fin,"%d",&n);
  t[0]=1;
  d1[0]=true;
  d2[n]=true;
  c[0]=true;
  pos++;
  while(true)
  {
    bool ok=false;
    for(int i=t[pos];i<n;i++)
    {
      t[pos]=i+1;
      if(!d1[i+pos]&&!d2[i-pos+n] && !c[i])
      {
        d1[i+pos]=true;
        d2[i-pos+n]=true;
        c[i]=true;
        v[pos]=i;
        pos++;
        ok=true;
        break;
      }
    }
    if(!ok)
    {
      if(pos==0) break;
      t[pos]=0;
      v[pos]=0;
      pos--;
      int i = v[pos];
      d1[i+pos]=false;
      d2[i-pos+n]=false;
      c[i]=false;
    }
    if(ok&&pos==n)
    {
      found++;
      if(found==1)
        write();
    }
  }
  fprintf(fout,"%lld",found);
}
