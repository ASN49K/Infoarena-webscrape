#include <bits/stdc++.h>
using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

int n, m[15][15], l[15], c[15], md1[15][15], md2[15][15], d1[30], d2[30], cnt;
bool e;

void diag();
void fill(int, int, int);
void bck(int);
void prt();

int main()
{
    f >> n;
    diag();
    bck(1);
    g << '\n' << cnt;
    return 0;
}

void diag(){
    for (int i = 1; i <= n; i++) {
        md1[1][i] = md2[1][i] = i;
        md1[i][1] =md2[i][n] = i + n;
    }
    for (int i = 2; i <= n; i++)
        for (int j = 2; j <= n; j++)
            md1[i][j] = md1[i - 1][j - 1];
            
    for (int i = 2; i <= n; i++)
        for (int j = n - 1; j; j--)
            md2[i][j] = md2[i - 1][j + 1];
    
}
void fill(int x, int y, int v){
    l[x] = c[y] = m[x][y] = d1[md1[x][y]] = d2[md2[x][y]] = v;
}
void bck(int x){
    if (x == n + 1) {
        if(!e){
            prt();
            e = true;
        }
        cnt++;
        return;
    }
    
    for (int i = 1; i <= n; i++){
        if(!l[x] && !c[i] && !d1[md1[x][i]] && !d2[md2[x][i]]){
            fill(x, i, 1);
            bck(x + 1);
            fill(x, i, 0);
        }
    }
    
}
void prt(){
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            if(m[i][j]) g << j << ' ';
}

