#include <bits/stdc++.h>
#define MAXN 13
using namespace std;
ofstream fout( "damesah.out" );
int n , ans , v[MAXN + 1] , f[MAXN + 1] , fdp[2 * MAXN + 1] , fds[2 * MAXN + 1];
void afis() {
    int i;
    for( i = 1 ; i <= n ; i++ )
        fout << v[i] << ' ';
    fout << '\n';
}
void gen( int pos ) {
    int i;
    if( pos == n + 1 ) {
        ans++;
        if( ans == 1 )
            afis();
    }
    for( i = 1 ; i <= n ; i++ )
        if( f[i] == 0 && fdp[i + pos] == 0 && fds[n - i + pos] == 0 ) {
            f[i] = fdp[i + pos] = fds[n - i + pos] = 1;
            v[pos] = i;
            gen( pos + 1 );
            f[i] = fdp[i + pos] = fds[n - i + pos] = 0;
        }
}
int main() {
    ifstream fin( "damesah.in" );
    fin >> n;
    gen( 1 );
    fout << ans << '\n';
    return 0;
}
