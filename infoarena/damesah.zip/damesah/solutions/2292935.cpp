#include <iostream>
#include <fstream>
#define MAXN 14
using namespace std;

int N, db=0;
int perm[MAXN];
bool o[MAXN];
bool a1[2*MAXN-1], a2[2*MAXN-1];
bool elso=1;
ofstream g("damesah.out");

void Read()
{
    ifstream f("damesah.in");
    f>>N;
}

void WriteConf()
{
    elso=0;
    for (int i=1;i<=N;i++)
        g<<perm[i]<<' ';
    g<<'\n';
}

void BT(int k)
{
    if (k>N)
    {
        db++;
        if (elso)
            WriteConf();
    }
    else
    {
        for (int i=1;i<=N;i++)
        {
            if (o[i]==0 && a1[i-k+N-1]==0 && a2[i+k-2]==0)
            {
                o[i]=1;
                a1[i-k+N-1]=1;
                a2[i+k-2]=1;
                perm[k]=i;
                BT(k+1);
                o[i]=0;
                a1[i-k+N-1]=0;
                a2[i+k-2]=0;
            }
        }
    }
}

int main()
{
    Read();
    BT(1);
    g<<db<<'\n';
}
