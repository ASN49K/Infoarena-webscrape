#include<fstream>
using namespace std;
ifstream F("damesah.in");
ofstream G("damesah.out");
int n,m,q[14],c[14],a[28],b[28];
void A(int l)
{
    int i;
	if(l==n) {
		if(m<1) {
			for(i=0;i<n;++i)
				G<<(q[i]+1)<<" ";
			G<<"\n";
		}
		++m;
	} else
		for(i=0;i<n;++i)
            if(!c[i]&&!a[i-l+n-1]&&!b[l+i])
                q[l]=i,c[i]=a[i-l+n-1]=b[l+i]=1,A(l+1),c[i]=a[i-l+n-1]=b[l+i]=0;
}
int main()
{
    F>>n,A(0),G<<m;
    return 0;
}
