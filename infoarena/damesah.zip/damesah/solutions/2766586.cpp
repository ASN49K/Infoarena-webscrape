#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n, ans;
int x[15];
bool col[15], diag1[30], diag2[30];
// diag1 - diagonala principala, diag2 - diagonala secundara

void back(int k) {
    if(k == n) {
        if(ans < 1) {
            for(int i = 0; i < n; i++) {
                fout << x[i] + 1 << " ";
            }
            fout << "\n";
        }
        ans++;
    } else {
        for(int i = 0; i < n; i++) {
            if(!col[i] && !diag1[i - k + n - 1] && !diag2[k + i]) {
                x[k] = i;
                col[i] = diag1[i - k + n - 1] = diag2[k + i] = true;
                back(k + 1);
                col[i] = diag1[i - k + n - 1] = diag2[k + i] = false;
            }
        }
    }
}

int main() {
    fin >> n;
    fin.close();
    back(0);
    fout << ans;
    fout.close();
    return 0;
}