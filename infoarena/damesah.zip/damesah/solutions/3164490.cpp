#include<fstream>
using namespace std;
ifstream cin("damesah.in");
ofstream cout("damesah.out");
int n, x[10], nr;
int verif(int k)
{

    int i=1, ok;
    ok=1;
    while(i<=k-1 && ok==1)
    {
        if(x[i]!=x[k] && abs(x[k]-x[i])!=abs(k-i))
            i++;
        else
            ok=0;
    }
    return ok;
}
void back(int k)
{
    int ok;
    int i;
    ok=0;
    if(k==n+1)
    {
        nr++;
        if(nr==1)
        {
            ok=1;
            for(i=1; i<=n; i++)
                cout<<x[i]<<" ";
            cout<<endl;
        }
    }
    else
    {
        x[k]=0;
        while(x[k]<n)
        {
            x[k]++;
            if(verif(k)==1)
                back(k+1);
        }
    }
}
int main()
{
    cin>>n;
    back(1);
    cout<<nr;
}
