#include <bits/stdc++.h>
#pragma GCC optimize("O3")
using namespace std;
bool oriz [ 16 ], d1 [ 30 ], d2 [ 30 ];
int ans [ 16 ], n, total = 0;
bool found = 0;

void back ( int pos = 1 )
{

	if ( pos == n + 1 )
	{
		if ( !found )
		{
			for ( int i = 1 ; i <= n ; ++ i )
			{
				cout << ans [ i ] << ' ';
			}
			cout << '\n';
		}
		found = 1;
		++ total;
	}
	for ( int i = 1 ; i <= n; ++ i )
	{
		if ( !oriz [ i ] && !d1 [ n + pos - i ] && !d2 [ pos + i ] )
		{
			ans [ pos ] = i;
			oriz [ i ] = 1;
			d1 [ n + pos - i ] = 1;
			d2 [ pos + i ] = 1;
			back ( pos + 1 );
			oriz [ i ] = 0;
			d1 [ n + pos - i ] = 0;
			d2 [ pos + i ] = 0;
		}		
	}
}

int main()
{
	( void )! freopen ( "damesah.in" , "r" , stdin );
	( void )! freopen ( "damesah.out" , "w" , stdout );
    ios_base::sync_with_stdio ( false );
    cin.tie ( NULL );
    cin >> n;
    back ();
    cout << total << '\n';
    return 0;
}