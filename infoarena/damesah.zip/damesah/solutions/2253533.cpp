#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int st[25],n;
int viz[25],dp[50],ds[50];
int c;

void Afisare()
{
    c++;
    if(c==1)
    {
        for(int i=1;i<=n;i++)
            fout << st[i] << " ";
        fout << "\n";
    }
}

int Valid(int i, int j)
{
    if(viz[j]==1) return 0;
    if(dp[n-j+i]==1) return 0;
    if(ds[i+j-1]) return 0;
    return 1;
}

void Back(int top)
{
    if(top==n+1) Afisare();
    else for(int j=1;j<=n;j++)
    {
        if(Valid(top, j))
        {
            st[top]=j;
            viz[j]=1;
            dp[n-j+top]=1;
            ds[top+j-1]=1;
            Back(top+1);
            viz[j]=0;
            dp[n-j+top]=0;
            ds[top+j-1]=0;
        }
    }
}

int main()
{
    fin >> n;
    Back(1);
    fout << c;
    fin.close();
    fout.close();
    return 0;
}
