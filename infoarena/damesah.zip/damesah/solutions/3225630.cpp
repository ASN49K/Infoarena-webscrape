#include <bits/stdc++.h>
#define ll long long
using namespace std;

ifstream fin ("damesah.in");
ofstream fout ("damesah.out");
ll st[15], n, cnt=0;
bool valid (int k)
{
    for (int i=1; i<k; i++) {
        if (st[i]==st[k]) return false;
        int ii=i, ij=n-st[i]+1;
        int ki=k, kj=n-st[k]+1;
        if (abs(ii-ki)==abs(ij-kj)) return false;
    }
    return true;
}
void back(int k)
{
    for (int i=1; i<=n; i++) {
        st[k]=i;
        if (valid(k)) {
            if (k==n) {
                if (cnt==0) {
                    for (int j=1; j<=n; j++) {
                        fout<<st[j]<<' ';
                    }
                    fout<<'\n';
                }
                cnt++;
            }
            else {
                back(k+1);
            }
        }
    }
}
int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    fin>>n;
    back(1);
    fout<<cnt;
    return 0;
}