#include <iostream>
#include <fstream>
using namespace std;
long long nrsol;
int n, x[30];
ifstream f("damesah.in");
ofstream g("damesah.out");
void afis (int k)
{
    for (int i=1;i<=k;i++)
        g<<x[i]<<" ";
    g<<endl;
}
int corect (int k)
{
    for(int i=1; i<k; i++)
        if(x[i]==x[k])
            return 0;
    for(int i=1; i<k; i++)
        if(x[i]==(x[k]-(k-i)) || x[i]==(x[k]+(k-i)))
            return 0;
    return 1;
}
void bt (int k)
{
    int i;
    for (i=1;i<=n;i++)
    {
        x[k]=i;
        if (corect(k))
        {
            if (k==n)
            {
                nrsol++;
                if(nrsol==1)
                    afis (k);
            }
            else bt(k+1);
        }
    }
}
int main()
{
    f>>n;
    bt(1);
    g<<nrsol;
    return 0;
}
