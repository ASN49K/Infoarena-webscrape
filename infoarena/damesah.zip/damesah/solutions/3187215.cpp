#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

vector<bool> folosit;
vector<bool> diagonala1;
vector<bool> diagonala2;
vector<int> rasp;
int cont;
bool ok;

void backtracking(int n, int linie, ofstream& f) {
    if (linie == n + 1) {
        if (ok == false) {
            for (int i = 1; i <= n; i++) {
                f << rasp[i] << " ";
            }
            f << endl;
            cont = 1;
            ok = true;
            return;
        } else {
            cont += 1;
            return;
        }
    }
    for (int coloana = 1; coloana <= n; coloana++) {
        if (diagonala1[linie - coloana + n] == true || diagonala2[linie + coloana] == true || folosit[coloana] == true) {
            continue;
        }
        diagonala1[linie - coloana + n] = true;
        diagonala2[linie + coloana] = true;
        folosit[coloana] = true;
        rasp[linie] = coloana;
        backtracking(n, linie + 1, f);
        diagonala1[linie - coloana + n] = false;
        diagonala2[linie + coloana] = false;
        folosit[coloana] = false;
    }
}

int main() {
    ifstream g("damesah.in");
    ofstream f("damesah.out");
    int n;
    g >> n;
    folosit.resize(2 * n + 1, false);
    diagonala1.resize(2 * n + 1, false);
    diagonala2.resize(2 * n + 1, false);
    rasp.resize(n + 1, 0);
    cont = 0;
    ok = false;
    backtracking(n, 1, f);
    f << cont;
    return 0;
}

