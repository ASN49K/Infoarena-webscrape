#include <iostream>
#include <fstream>
using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int n,x[101],nrsol,k;
bool valid()
{
    for(int i=1;i<k;i++)
        if(x[k]==x[i]||k-i==abs(x[k]-x[i]))
        return 0;
    return 1;
}
void afis()
{
    nrsol++;
    if(nrsol==1)
    {for(int i=1;i<=n;i++)
        g<<x[i]<<' ';
    g<<'\n';
    }
}
int succesor()
{
    if(x[k]<n)
    {
        x[k]++;
        return 1;
    }
    return 0;
}

void bt()
{
    k=1;
    x[k]=0;
    while(k>0)
    {
        int as=1,ev=0;
        while(as&&!ev)
        {
            as=succesor();
            if(as) ev=valid();
        }
        if(as)
            if(k==n) afis();
            else {
                    k++;
                    x[k]=0;
                 }
        else
            k--;
    }
}
int main()
{
    f>>n;
    bt();
    g<<nrsol;
    return 0;
}
