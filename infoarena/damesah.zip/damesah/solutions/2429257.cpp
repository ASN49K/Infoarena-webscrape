#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

const int CMAX = 20;
int n , v[CMAX] , rasp = 0 , mat[CMAX][CMAX];
bool ok = 0;

void citire()
{
    fin >> n;
}

bool verificare(int si , int sj)
{
    int sk = 1;
    while(si-sk>=1)
    {
        if(mat[si-sk][sj-sk]==1&&sj-sk>=1)
            return false;
        if(mat[si-sk][sj+sk]==1&&sj+sk<=n)
            return false;
        if(mat[si-sk][sj]==1)
            return false;
        sk++;
    }
    return true;
}

void afisare()
{
    for(int oi=1;oi<=n;oi++)
    {
        for(int oj=1;oj<=n;oj++)
            cout << mat[oi][oj] << " ";
        cout << '\n';
    }
    cout << '\n';
}

void bkt(int k)
{
    for(int i=1;i<=n;i++)
    {
        v[k] = i;
        mat[k][i] = 1;
        if(verificare(k,i)==true)
        {
            if(k==n)
            {
                afisare();
                if(ok==0){
                    for(int j=1;j<=n;j++)
                        fout << v[j] << " ";
                    ok = 1;
                }
                rasp++;
            }
            else bkt(k+1);
        }
        mat[k][i] = 0;
    }
}

int main()
{
    citire();
    bkt(1);
    fout << '\n' << rasp;
    return 0;
}
