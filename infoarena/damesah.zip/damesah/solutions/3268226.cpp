#include <iostream>
#include <fstream>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

const int NMAX = 13;

int n, x[NMAX + 1];
bool C[NMAX + 1],
     dP[2 * NMAX],
     dS[2 * NMAX];

void afis()
{
    int i, k;
    for(i = 1; i <= n; i++)
        g << x[i] << ' ';
}

long long int nrsol;

void backt(int k)
{
    if(k <= n)
    {
        for(int i = 1; i <= n; i++)
            if(C[i] == 0 && dP[n - k + i] == 0 && dS[k + i - 1] == 0) /// valid
            {
                x[k] = i;
                C[i] = dP[n - k + i] = dS[k + i - 1] = 1;
                backt(k + i);
                C[i] = dP[n - k + i] = dS[k + i - 1] = 0;
            }
    }
    else
    {
        if(nrsol == 0)
            afis();
        nrsol++;
    }
}

int main()
{
    f >> n;
    backt(1);
    g << '\n' << nrsol;
    f.close();
    g.close();
    return 0;
}
