#include <bits/stdc++.h>
using namespace std;

ifstream in("damesah.in");
ofstream out("damesah.out");

const int DIM = 15;

bool c[DIM];
bool d1[2 * DIM];
bool d2[2 * DIM];

int st[DIM];

void bt(int n,int k,int &cnt)
{
    if(k == n)
    {
        cnt++;
        if(cnt == 1)
        {for(int i = 1; i <= n; i++)
            out << st[i] <<" ";
         out <<'\n';
        }
    }
    else
    for(int i = 1; i <= n; i++)
    {
        if(c[i] == false && d1[i + k] == false && d2[n - i + 1 + k] == false)
        {
            d1[i + k] = true;
            d2[n - i + 1 + k] = true;
            c[i] = true;
            st[k + 1] = i;
            bt(n,k + 1,cnt);
            d1[i + k] = false;
            d2[n - i + 1 + k] = false;
            c[i] = false;
        }
    }
}

int main()
{
    int n;
    in >> n;

    int cnt = 0;
    bt(n,0,cnt);

    out << cnt;
    return 0;
}
