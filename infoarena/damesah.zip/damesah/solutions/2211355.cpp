#include <bits/stdc++.h>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n,s=0;
bool first=true;
bool C[14],R[14],D1[27],D2[27];
int S[14];

bool diag(int x,int y){
	int d1 = x + y;
	int d2 = x-y+13;
	if (R[y]+C[x]+D1[d1]+D2[d2]){
		return 1;
	} else{ 
		if(first){
			S[y]=x;
		} 
		return 0;
	}
}

void bk(int y){
//	cout<<y<<'\n';
	if(y<=n){
		for(int i=1;i<=n;i++){
			int d1=i+y,d2=i-y+13;
			if(!diag(i,y)){
				R[y]=C[i]=D1[d1]=D2[d2]=1;
				//cout<<y<<' '<<i<<'\n';
				bk(y+1);
				R[y]=C[i]=D1[d1]=D2[d2]=0;
			}
		} 
	}else{
		if(first){
			for (int i=1;i<=n;i++)
				fout<<S[i]<<' ';		
			fout<<'\n';
		first=false;
		}
		s++;
	}
}

int main(){
	fin>>n;
	bk(1);
	fout<<s;
	return 0;
}
