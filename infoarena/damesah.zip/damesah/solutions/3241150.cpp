#include <fstream>
using namespace std;
ifstream   fin("damesah.in");
ofstream  fout("damesah.out");
int n,nr,prima,C[15];
bool col[15],main_diag[30],sec_diag[30];

void afisare()
{
    if(prima)
    {
        for(int i=1; i<=n; i++)
        {
            fout<< C[i] << " ";
        }
        fout<< "\n";
        prima=0;
    }
    nr++;
}

int solutie(int k)
{
    if(k==n)
    {
        return 1;
    }
    return 0;
}

int ok(int i, int k)
{
    if(!col[i] && !main_diag[i-k+n-1] && !sec_diag[k+i])
    {
        return 1;
    }
    return 0;
}

void BACK(int k)
{
    for(int i=1; i<=n; i++)
    {
        C[k]=i;
        if(ok(i,k))
        {
            col[i]=main_diag[i-k+n-1]=sec_diag[k+i]=true;
            if(solutie(k))
            {
                afisare();
            }
            BACK(k+1);
            col[i]=main_diag[i-k+n-1]=sec_diag[k+i]=false;
        }
    }
}

int main()
{
    fin>>n;

    nr=0;
    prima=1;

    BACK(1);

    fout<< nr;

    return 0;
}
