	
#include <fstream>
 
using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int n,nr,v[100],v2[100],v3[100],v4[100];
void bkt(int poz)
{
    if(poz==n+1)
    {
        nr++;
        if(nr==1)
        {
            for(int i=1; i<=n; i++)
            {
                g<<v3[i]<<" ";
            }
            g<<'\n';
        }
        return;
    }
    for(int i=1; i<=n; i++)
    {
        if(v[i]==0 && v2[poz-i+n]==0 && v4[i+poz]==0)
        {
            v3[poz]=i;
            v[i]=1;
            v2[poz-i+n]=1;
            v4[i+poz]=1;
            bkt(poz+1);
            v[i]=0;
            v2[poz-i+n]=0;
            v4[i+poz]=0;
        }
    }
}
int main()
{
    f>>n;
    bkt(1);
    g<<nr;
    return 0;
}