//#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream cin("damesah.in");
ofstream cout("damesah.out");
int n,cnt;
bool ok=1;
struct queen
{
    int r,c;

}v[20];
void func(int row)
{
    if(row==n+1)
    {
        if(ok==1)
        {
            for(int i=1;i<=n;i++)
            {
                cout<<v[i].c<<" ";
            }
            cout<<"\n";
        }
        cnt++;
        ok=0;return;
    }
    for(int i=1;i<=n;i++)
    {
        bool k=1;
        for(int j=1;j<row;j++)
        {
            if(abs(v[j].c-i)==abs(v[j].r-row) or i==v[j].c)
            {
                k=0;
                break;
            }
        }
        if(k==1)
        {
            v[row].c=i;
            v[row].r=row;
            func(row+1);
        }
    }
}
int main()
{
    cin>>n;
    func(1);
    cout<<cnt;
    return 0;
}
