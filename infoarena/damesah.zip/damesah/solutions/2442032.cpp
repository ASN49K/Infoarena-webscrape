#include <fstream>
using namespace std;
int n,m[15][15],solutii,ok=1;
ifstream cin("damesah.in");
ofstream cout("damesah.out");

bool verific(int linie, int coloana){
    for(int i=1; i<=n; i++){
        if(m[linie][i]==1)
            return false;
        if(m[i][coloana]==1)
            return false;
    }
    int i=linie+1, j=coloana+1;
    while(i<=n&&j<=n){
        if(m[i][j]==1)
            return false;
        i++; j++;
    }
    i=linie-1; j=coloana-1;
    while(i>0&&j>0){
        if(m[i][j]==1)
            return false;
        i--; j--;
    }
   i=linie-1; j=coloana+1;
    while(i>0&&j<=n){
        if(m[i][j]==1)
            return false;
        i--; j++;
    }
    i=linie+1; j=coloana-1;
    while(i<=n&&j>0){
        if(m[i][j]==1)
            return false;
        i++; j--;
    }
    return true;
}

void dama(int linie){
    if(linie==n+1){
        solutii++;
        if(ok==1){
            for(int i=1; i<=n; i++)
                for(int j=1; j<=n; j++)
                    if(m[i][j]==1)
                        cout<<j<<' ';
            cout<<'\n';
            ok=0;
        }
        return;
    }
    for(int i=1; i<=n; i++)
        if(verific(linie,i)){
            m[linie][i]=1;
            dama(linie+1);
            m[linie][i]=0;
        }
};


int main()
{
    cin>>n;
    dama(1);
    cout<<solutii;
    return 0;
}
