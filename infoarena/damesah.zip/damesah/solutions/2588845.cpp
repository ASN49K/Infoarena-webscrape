#include <fstream>

using namespace std;

ifstream cin("damesah.in");
ofstream cout("damesah.out");
 
int N;
int a[100][100];
int is_OK(int rand, int coloana) {
	int i;
	for (i = 0; i < rand; i++) {
		if ((a[rand - 1 - i][coloana] == 1) ||
				(a[rand - 1 - i][coloana - 1 - i] == 1 && (coloana - i - 1) >= 0) ||
				(a[rand - 1 - i][coloana + 1 + i] == 1 && (coloana + 1 + i <= N - 1)))
			return 0;
	}

	return 1;
}

int main() {
	int n, rand, coloana, prev, verif, count = 0, i, j;

	cin >> n;
	N = n;
	for (rand = 0; rand < N; rand++) {
		for (prev = 0; prev < N; prev++) {
			verif = 0;
			if (a[rand][prev] == 1) {
				a[rand][prev] = 0;
				verif = 1;
				break;
			}
		}

		if (verif == 0) {
			prev = -1;
		}

		verif = 0;
		for (coloana = prev + 1; coloana < N; coloana++) {
			if (is_OK(rand, coloana)) {
				a[rand][coloana] = 1;
				verif = 1;
				break;
			}
		}

		if (rand == 0 && verif == 0)
			break;
		else if (coloana == N)
			rand = rand - 2;
		else if (rand == N - 1 && verif == 1) {
			count++;

		
			cout << endl;
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					if (a[i][j] == 1) {
						cout << j+1 << " ";
					}
				}
				
			}
			
		}
	}
	
		cout<<endl<<count;
}
