#include <fstream>
using namespace std;
ifstream fin ("damesah.in");
ofstream fout ("damesah.out");
int x[14],ok,n,nrc,f[14];
int vv (int pas)
{
    for (int i=1; i<pas; i++)
    {
        int nr1,nr2;
        nr1=pas-i;
        if (nr1<0)
            nr1=nr1*(-1);
        nr2=x[pas]-x[i];
        if (nr2<0)
            nr2=nr2*(-1);
        if (nr1==nr2)
            return 0;
    }
    return 1;
}
void backtrack (int pas)
{
    if (pas==n+1)
    {
        nrc++;
        if (ok==0)
        {
            ok=1;
            for (int i=1; i<=n; i++)
                fout<<x[i]<<" ";
            fout<<"\n";
        }
    }
    else
    {
        for (int i=1; i<=n; i++)
        {
            if (f[i]==0)
            {
                x[pas]=i;
                f[i]=1;
                if (vv(pas)==1)
                    backtrack (pas+1);
                f[i]=0;
            }
        }
    }
}
int main()
{
    fin>>n;
    backtrack (1);
    fout<<nrc;
    return 0;
}
