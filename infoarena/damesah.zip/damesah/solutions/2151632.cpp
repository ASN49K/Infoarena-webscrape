#include <fstream>
#include <cstdlib>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int v[20],n,ok,cnt;

void afisare(int k)
{
    for (int i=1;i<=k;++i) fout << v[i] << " ";
    fout << "\n";
}

bool valid(int k)
{
    for (int i=1; i<k; ++i)
    {
        if (v[i]==v[k] || abs(v[i]-v[k])==abs(i-k)) return 0;
    }
    return 1;
}

void back(int k)
{
    for (int i=1; i<=n; ++i)
    {
        v[k]=i;
        if (valid(k))
        {
            if (k<n) back(k+1);
            else
            {
                if (ok==0)
                afisare(k),ok=1;
                ++cnt;
            }
        }
    }
}

int main()
{
    fin >> n;
    back(1);
    fout << cnt << "\n";
    return 0;
}
