#include <bits/stdc++.h>
#define INF 2e9

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int sol, n, st[20], viz[20], dp[40], ds[40];

bool Valid(int i, int j)
{
    if (viz[j] == 1) return 0;
    if (dp[i + j - 1] == 1) return 0;
    if (ds[n + i - j] == 1) return 0;
    return 1;
}

void Back(int top)
{
    if (top == n + 1)
    {
        sol++;
        if (sol == 1)
        {
            for (int i = 1; i <= n; i++)
                fout << st[i] << " ";
            fout << "\n";
        }
    }
    else
    {
        for (int i = 1; i <= n; i++)
            if (Valid(top, i))
            {
                viz[i] = 1;
                st[top] = i;
                dp[top + i - 1] = 1;
                ds[n + top - i] = 1;
                Back(top + 1);
                viz[i] = 0;
                dp[top + i - 1] = 0;
                ds[n + top - i] = 0;
            }
    }
}

int main()
{
    fin >> n;
    Back(1);
    fout << sol << "\n";
    return 0;
}