#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

const int NMAX = 14;

int n, sol = 0, a[14];
bool sfq[2 * NMAX + 1], dfq[2 * NMAX + 1], vfq[NMAX + 1];
bool check(int pas)
{
    if (dfq[pas - a[pas] + n] > 0)
        return false;
    if (sfq[pas + a[pas]] > 0)
        return false;
    if (vfq[a[pas]] > 0)
        return false;

    return true;
}

void bkt(int pas)
{
    if (pas == n + 1)
    {
        sol++;
        if (sol == 1)
        {
            for (int i = 1; i <= n; i++)
            {
                fout << a[i] << " ";
            }
            fout << "\n";
        }
        return;
    }
    else
    {
        for (int i = 1; i <= n; i++)
        {
            a[pas] = i;
            if (check(pas))
            {
                sfq[pas + i] = 1;
                dfq[pas - i + n] = 1;
                vfq[i] = 1;
                bkt(pas + 1);
                sfq[pas + i] = 0;
                dfq[pas - i + n] = 0;
                vfq[i] = 0;
            }
        }
    }
}

int main()
{
    fin >> n;
    bkt(1);
    fout << sol;
    return 0;
}