#include<fstream>
#include<cmath>
using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n,x[14],cnt=0;

void Afiseaza()
{
    for(int i=1;i<=n;i++)
        fout<<x[i]<<" ";
    fout<<"\n";
}

int Valid(int k)
{
    for(int i=1;i<k;i++)
        if(x[i]==x[k] || abs(x[i]-x[k])==abs(i-k))
            return 0;
    return 1;
}

void Backtracking(int k)
{
    if(k>n)
    {
        cnt++;
        if(cnt==1)
            Afiseaza();
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            x[k]=i;
            if(Valid(k))
                Backtracking(k+1);
        }
    }
}

int main()
{
    fin>>n;
    Backtracking(1);
    fout<<cnt;
    fin.close();
    fout.close();
}
