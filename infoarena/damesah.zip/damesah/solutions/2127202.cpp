#include <fstream>
#include <cmath>
using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

int n;
int col[14];
bool prima = true;
int contor = 0;

bool valid(int nivel) {
    for(int i = 1; i < nivel; i++ ) {
        if(nivel == i || col[i] == col[nivel])
            return false;
        if((i - col[i]  == nivel - col[nivel]) || (i + col[i] == nivel + col[nivel]) )
            return false;
    }
    return true;
}

void afiseaza() {
    for(int i  = 1; i <= n; i++) {
        g << col[i] << " ";
    }
    g << "\n";
}

void back(int nivel) {

    for(int i = 1; i <= n; i++) {
        if(i == nivel)
            continue;
        col [nivel] = i;
        if(valid(nivel)) {
            if(nivel == n) {
                if(prima == true) {
                    afiseaza();
                    prima = false;
                    contor++;
                }
                else {
                    contor++;
                }
            }
            else
                back(nivel + 1);

        }
        col [nivel] = 0;
    }
}


int main() {
    f >> n;
    
    back(1);
    g << contor;

}
