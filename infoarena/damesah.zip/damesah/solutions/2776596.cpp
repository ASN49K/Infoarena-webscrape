#include <bits/stdc++.h>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int st[14], n, nr_afis, ap_prin[26], ap_sec[26];

void Afisare()
{
    nr_afis++;
    if(nr_afis <= 1)
    {
        for (int i = 1; i <= n; i++)
            fout << st[i] << " ";
        fout << "\n";
    }
}

int Valid(int top)
{
    int k, x, y;
    for(int i = 1;i < top;i++)
        if(st[i] == st[top]) return 0;
    if(st[top] >= top && ap_prin[n - st[top] + 1] == 1) return 0;
    if(st[top] <= top && ap_prin[n + top] == 1) return 0;
    if(st[top] ap_sec[])

    return 1;
}

void Remove(int top)
{
    for (int i = 1; i <= n; i++)
        if (tabla[top][i] == '*')
            tabla[top][i] = '-';
}

void Back()
{
    int top, cand;
    top = 0;
    st[++top] = 0;
    while (top > 0)
    {
        cand = 0;
        while (cand == 0 && st[top] < n)
        {
            st[top]++;
            cand = Valid(top);
        }
        if (cand == 0)
        {
            top--;
            Remove(top);
        }
        else if (top == n) Afisare();
        else st[++top] = 0;
    }
}

int main()
{
    fin >> n;
    Back();
    fout << nr_afis << "\n";
    fin.close();
    fout.close();
}
