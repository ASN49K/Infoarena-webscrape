#include<bits/stdc++.h>
using namespace std;
ifstream fin("damesah.in"); ofstream fout("damesah.out");
int n;
bool t[14][14], d[3][30], o[15], v[15];
bool w;

int dame(int f){
int sol=0;

for(int j=1; j<=n; j++){
int i=f+1;

        if( (d[1][j+i]==false) && (d[2][n+1-j+i]==false) && (o[i]==false) && (v[j]==false) && (t[i][j]==false)   ){

            d[1][j+i]=true; d[2][n+1-j+i]=true; t[i][j]=true; o[i]=true; v[j]=true;

            if( (f+1)==n ){sol+=1; if(!w){w=true; for(int g=1; g<=n; g++){for(int h=1; h<=n; h++){if(t[g][h]==1){fout<<h<<" ";}  } }fout<<"\n";      } }
            else{sol+=dame(f+1);}

            d[1][j+i]=false; d[2][n+1-j+i]=false; t[i][j]=false; o[i]=false; v[j]=false;
        }


}


return sol;
}






int main(){
fin>>n;


fout<<dame(0);




return 0;
}
