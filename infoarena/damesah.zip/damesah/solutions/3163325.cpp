#include <bits/stdc++.h>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");
int n, r, d[15];
bool col[15], d1[15], d2[15], ok;

static inline void afis() {
    if(!ok) {
        ok = true;
        for(int i = 1; i <= n; i++) fout << d[i] << " ";
    }
    r++;
}

static inline void Calc(int c) {
    for(int l = 1; l <= n; l++) {
        if(!col[l] && !d1[l + c] && !d2[l - c + n]) {
            d[c] = l;
            col[l] = true;
            d1[l + c] = true;
            d2[l - c + n] = true;

            if(c < n) Calc(c + 1);
            else afis();

            d[c] = 0;
            col[l] = false;
            d1[l + c] = false;
            d2[l - c + n] = false;
        }
    }
}

int main() {
    fin >> n;
    Calc(1);
    fout << "\n" << r;

    return 0;
}
