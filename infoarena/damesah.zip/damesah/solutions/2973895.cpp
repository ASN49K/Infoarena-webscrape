#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n = 4, cont = 0;
int v[14];

bool verif(int k)
{
    for(int i = 1; i < k; i++)
    {
        if(v[i] == v[k]) return false;
        if(abs(v[i] - v[k]) == abs(k-i))
            return false;
    }
    return true;
}

void backtrack(int k)
{
    for(int i = 1; i <= n; i++)
    {
        v[k] = i;
        if(verif(k))
        {
            if(k == n)
            {
                if(cont == 0)
                {
                    for(int i = 1; i <= n; i++)
                        cout << v[i] << ' ';
                }
                cont++;
            }
            else
                backtrack(k+1);
        }
    }
}

int main()
{
    fin >> n;
    backtrack(1);
    fout  << '\n' << cont;
    return 0;
}
