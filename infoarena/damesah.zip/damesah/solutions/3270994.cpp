#include  <bits/stdc++.h>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int v[15],n,nr,uz[15];
void afisare()
{
    for(int i=1;i<=n;i++)
        fout<<v[i]<<" ";
    fout<<endl;
}
bool valid(int k)
{
    for(int i=1;i<k;i++)
        if( k-i==abs(v[i]-v[k]) )return 0;
    return 1;
}
void bkt(int k)
{
    for(int i=1;i<=n;i++)
    {
        v[k]=i;
        if(uz[i]==0)
        {
            uz[i]=1;
            if(valid(k) )
                if(k==n)
                {
                    nr++;
                    if(nr==1)afisare();
                }
                else bkt(k+1);
            uz[i]=0;
        }
    }
}
int main()
{
    fin>>n;
    bkt(1);
    fout<<nr;
    return 0;
}
