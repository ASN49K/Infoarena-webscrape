#include <bits/stdc++.h>
typedef unsigned long long ul;
typedef long long ll;
using namespace std;

int n, tab[20], sol = 0;

ifstream in("damesah.in");
ofstream out("damesah.out");

void afisare(int k)
{
    for (int i = 1; i <= n; i++)
    {
        out << tab[i] << " ";
    }
    out << "\n";
}

bool solutie(int k)
{
    if (k == n) return 1;
    return 0;
}

bool valid(int k)
{
    for (int i = 1; i < k; i++)
    {
        if (tab[k] == tab[i] || abs(tab[k] - tab[i]) == abs(k - i)) return 0;
    }
    return 1;
}

void dame(int k)
{
    for (int i = 1; i <= n; i++)
    {
        tab[k] = i;
        if (valid(k))
        {
            if (solutie(k)) {
                if (sol == 0) afisare(k);
                sol++;
            }
            else dame(k + 1);
        }
    }
}

int main(){
//ios_base::sync_with_stdio(0); cin.tie(); cout.tie();

in >> n;

dame(1);

out << sol;
return 0;
}
