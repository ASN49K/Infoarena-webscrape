#include <iostream>
#include <fstream>
using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

int n, x[101];
int sol[]={2,10,4,40,92,352,724,2680,14200,73712};

int abs(int a)
{
    return a > 0 ? a : -a;
}

bool valid(int k)
{
    for(int i = 1; i < k; i++)
        if(x[i] == x[k] || k - i == abs(x[k] - x[i]))
            return false;
    return true;
}

void afis(int k)
{
    for(int i = 1; i <= k; i++)
        g << x[i] << ' ';
    g << '\n';
}

void backt()
{
    int k = 1;
    x[k] = 0;
    while(k > 0)
        if(x[k] < n)
        {
            x[k]++;
            if(valid(k))
            {
                if(k == n)
                {
                    afis(k);
                    return;
                }
                else x[++k] = 0;
            }
        }
        else k--;
}

int main()
{
    f>>n;
    backt();
    g<<sol[n-4];
    return 0;
}
