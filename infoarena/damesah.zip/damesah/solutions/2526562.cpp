#include <bits/stdc++.h>
#define ll long long
#define all(a) (a).begin(), (a).end()
//#pragma GCC optimize("O3")
//#pragma GCC optimize("Ofast")
//#pragma GCC target("sse,sse2,sse3,ssse3,sse4,popcnt,abm,mmx,avx,tune=native")
#define sz() size()
#define fr first
#define sc second
#define pb push_back
#define er erase
#define in insert
#define pi pair<int,int>
#define pii pair<pair<int,int>,int>
#define mp make_pair
//#define int long long
#define rc(s) return cout<<s,0
#define rcc(s) cout<<s,exit(0)
using namespace std;

const int mod=1e9+7;
const int modx=998244353;
const int per=666013;

const int inf=1e9;

int n,ans;
pair<int,int>queen[14];
bitset<50>lin,col,diag1,diag2;

void dame(int pos,int indx){
    int x=(pos-1)/n+1;
    int y=pos-(x-1)*n;
    queen[indx].fr=x;
    queen[indx].sc=y;
    lin[x]=1;
    col[y]=1;
    diag1[x+y]=1;
    diag2[x+n-y+1]=1;
    if(indx==n){
        ans++;
        if(ans==1){ for(int i=1;i<=n;i++) cout << queen[i].sc << ' '; cout << '\n'; }
    }
    for(int i=pos+1;i<=n*n;i++){
        int x1=(i-1)/n+1;
        int y1=i-(x1-1)*n;
        if(lin[x1]==0 && col[y1]==0 && diag1[x1+y1]==0 && diag2[x1+n-y1+1]==0) dame(i,indx+1);
    }
    lin[x]=0;
    col[y]=0;
    diag1[x+y]=0;
    diag2[x+n-y+1]=0;
}

int32_t main(){
	ios_base::sync_with_stdio(false);cin.tie(0);cerr.tie(0);cout.tie(0);
    srand(chrono::steady_clock::now().time_since_epoch().count());
    ifstream cin("damesah.in");
    ofstream cout("damesah.out");
    cin >> n;
    for(int i=1;i<=n*n;i++) dame(i,1);
    cout << ans << '\n';
}
