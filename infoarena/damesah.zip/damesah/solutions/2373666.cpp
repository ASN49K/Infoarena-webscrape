#include <bits/stdc++.h>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");


int n,ok=1,nr,sol[51],first_sol[51],fv1[1010],fv2[1010],fv3[1010];


void beck(int k)
{

    int i,dif;
    if(k==n+1)
    {
        nr++;
        if(ok==1)
        {
            for(i=1;i<=n;i++)
                first_sol[i]=sol[i];
            ok=0;
        }
    }
    else
    {
        for(i=1;i<=n;i++)
        {
            sol[k]=i;

            if(k>i)dif=k-i;
            else dif=(i-k)+12;

            fv1[i]++;
            fv2[dif]++;
            fv3[k+i]++;

            if(fv1[i]==1 && fv2[dif]==1 && fv3[k+i]==1)beck(k+1);

            fv1[i]--;
            fv2[dif]--;
            fv3[k+i]--;

        }
    }
}


int i;

int main()
{
    f>>n;
    beck(1);

    for(i=1;i<=n;i++)
        g<<first_sol[i]<<" ";
    g<<'\n';
    g<<nr;

    return 0;
}
