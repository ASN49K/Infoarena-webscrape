#include <bits/stdc++.h>
#include <fstream>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
template<class T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
struct custom_hash {static uint64_t splitmix64(uint64_t x) {x += 0x9e3779b97f4a7c15;x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;x = (x ^ (x >> 27)) * 0x94d049bb133111eb;return x ^ (x >> 31);}size_t operator()(uint64_t x) const {static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();return splitmix64(x + FIXED_RANDOM);}};
string __fname = "damesah"; ifstream in (__fname + ".in"); ofstream out (__fname + ".out"); 
#define cin in 
#define cout out
#define int64 long long
#define uint64 unsigned long long
#define x first
#define y second
#define pb push_back
#define pii pair <int, int> 
#define pii64 pair <int64, int64>
#define db(x) cout << "> " << #x << ": " << (x) << "\n"
#define qr queries()
#define yn(x) if (x) {ctn("Yes");}else {ctn("No");}
void solve(int);
void queries(){int n;cin >> n;for (int i = 1; i <= n; i++) solve(i);}
template<class T>T ceildiv(T a, T b) {return a / b + !!(a % b);}
template<class T>T gcd (T a, T b){return (b ? gcd(b, a % b): a);}
template<class T>T lcm (T a, T b){return a * b / gcd(a, b);}
// // // // // // // // // // // // // // // // // // // // // // 
/*                  TEMPLATE - VANILLA                         */
// // // // // // // // // // // // // // // // // // // // // //
const int ddx[] = {-1, -1, 0, 1, 1, 1, 0, -1};
const int ddy[] = {0, 1, 1, 1, 0, -1, -1, -1};
const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};
const double pi = 3.14159265359;
const double eps = 1e-6;
const int64 hash_inv = 940594066;
const int64 hash_p = 101;
const int64 mod = 1e9 + 7;
const int maxn = 20;
int row [maxn], col[maxn], d1[maxn], d2[maxn];
int rs = 0;
vector <int> a;
vector <pii> sf;
int n;

void solve(int id){
    
    return;
}

void calc (int x, int y, int qn) {
    if (!qn) {
        vector <pii> temp = sf;
        sort(temp.begin(), temp.end());
        vector <int> k;
        for (auto [i, j]: temp) k.push_back(j);
        if (!rs) a = k;
        else a = min(a, k);
        rs++;
        return;
    }
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            if ((i == x && j <= y) || (i < x)) continue;
            if (!row[i] && !col[j] && !d1[n - i + j] && !d2[i + j]) {
                row[i] = col[j] = d1[n - i + j] = d2[i + j] = 1;
                sf.push_back({i, j});
                calc(i, j, qn - 1);
                row[i] = col[j] = d1[n - i + j] = d2[i + j] = 0;
                sf.pop_back();
            }
        }
    }
}



int main(){
    ios_base::sync_with_stdio(0); cin.tie(0); cout << fixed; cout << setprecision(10); 
    cin >> n;
    calc(0, 0, n);
    for (int i: a) {
        cout << i + 1 << " ";
    }
    cout << "\n";
    cout << rs;
    return 0;
}