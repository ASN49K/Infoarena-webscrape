#include<bits/stdc++.h>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

short ma[14][14],n,st[54],sol,rr[54],diag[104],secdiag[104];

bool ok(int k)
{
    for(int i=1;i<k;++i)
        if((k-i==abs(st[i]-st[k])))
        return 0;
    return 1;
}

void bck(int k)
{
    if(k<=n)
    {
        for(int i=1;i<=n;++i)
        {
            if(rr[i]==0 && diag[i-k+n]==0 && secdiag[k+i-1]==0){
            st[k]=i;
            diag[i-k+n]=1;
            secdiag[k+i-1]=1;
            ma[k][i]=1;
            rr[i]=1;

                if(k==n)
                {
                    sol++;
                    if(sol==1)
                    {
                        for(int j=1;j<=n;++j)
                            g<<st[j]<<' ';
                        g<<'\n';

                    }
                }
                else
                    bck(k+1);
            diag[i-k+n]=0;
            secdiag[k+i-1]=0;
            ma[k][i]=0;
            rr[i]=0;
            }
        }
    }
}
int main()
{
    f>>n;
    bck(1);
    g<<sol;
}
