#include <bits/stdc++.h>

using namespace std;
ifstream fcin("damesah.in");
ofstream fcout("damesah.out");
int n;
vector<vector<int>> board;

int sol_cnt = 0;
bool attacks(int i1, int j1, int i2, int j2, vector<pair<int, int>> placed) {
	if(i1 == i2) return true;
	if(j1 == j2) return true;
	return abs(i1 - i2) == abs(j1 - j2);
}

bool can_place(int i, int j, vector<pair<int, int>> placed) {
	bool ans = true;
	for(auto [placed_i, placed_j] : placed) {
		ans &= !attacks(i, j, placed_i, placed_j, placed);
	}
	return ans;
}

void back(vector<pair<int, int>> placed) {
	if(placed.size() == n) {
		sol_cnt++;
		if(sol_cnt == 1) {
			for(auto [queen_i, queen_j]: placed) {
				fcout<<queen_j<<" ";
			}
			fcout<<"\n";
		}
		return;
	}
	for(int i = 0; i < n; i++) {
		for(int j = 0; j < n; j++) {
			if(can_place(i, j, placed)) {
				placed.push_back({i, j});
				back(placed);
				placed.pop_back();
			}
		}
	}
}


int main(void) {
	
	fcin >> n;
	board.assign(n, vector<int> (n, 0));
	vector<pair<int, int>> placed;
	back(placed);
	fcout<<sol_cnt<<"\n";
	return 0;
}