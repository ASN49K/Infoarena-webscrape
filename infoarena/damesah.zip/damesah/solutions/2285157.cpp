#include <fstream>
#include <cstdlib>
using namespace std;
int n, v[14], c[14], ds[14], dp[14], sol;
ifstream fin ("damesah.in");
ofstream fout ("damesah.out");

int tipar (int k)
{
    int i=0;
    for (i=1;i<=k;i++)
        fout<<v[i]<<" ";
    fout<<"\n";
}

void back (int k)
{
    int i=0;
    for (i=1;i<=n;i++) {
        if (c[i]==0 && dp[n-(i-k)]==0 && ds[k+i-1]==0) {
            v[k]=i;
            c[i]=1;
            dp[n-(i-k)]=1;
            ds[k+i-1]=1;
            if (k==n) {
                sol++;
                if (sol==1)
                    tipar(k);
            } else {
                back(k+1);
            }
            c[i]=0;
            dp[n-(i-k)]=0;
            ds[k+i-1]=0;
        }

    }
}

int main () {
    fin>>n;
    back(1);
    fout<<sol;

    return 0;
}
