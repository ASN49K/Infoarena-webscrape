#include <iostream>
#include <fstream>

using namespace std;

ifstream in("damesah.in");
ofstream out("damesah.out");

const int NMAX = 50;

int n,counter=0;
int sol[NMAX];
int col[NMAX],diagon_alley[NMAX],diagonally[NMAX];
bool flag=0;

void solve(int depth)
{

    if(depth>n)
    {
        if(flag==0)
        {
            for(int i=1;i<=n;i++)
            {
               out<<sol[i]<<" ";
            }
            flag=1;
        }
        counter++;
    }
    else
    {

        for(int i=1;i<=n;i++)
        {
            if(col[i]==0 && diagon_alley[depth+i]==0 && diagonally[depth-i+n]==0)
            {
                col[i]=diagon_alley[depth+i]=diagonally[depth-i+n]=1;
                sol[depth]=i;
                solve(depth+1);
                col[i]=diagon_alley[depth+i]=diagonally[depth-i+n]=0;
            }
        }
    }
}

int main()
{
    in>>n;
    solve(1);
    out<<'\n'<<counter;
}
