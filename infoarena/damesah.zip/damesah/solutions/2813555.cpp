#include <bits/stdc++.h>
using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int v[14];
int n;
int ans=0;
int afis=0;

void afisare()
{
    for (int i=1;i<=n;i++)
        fout<<v[i]<<' ';
    fout<<'\n';
}

bool ok(int k)
{
    for (int i=1;i<k;i++)
    {
        if (v[k]==v[i]) return 0;
        if (k-i==abs(v[k]-v[i])) return 0;
    }
    return 1;
}

void bkt(int poz)
{
    for (int i=1;i<=n;i++)
    {
        v[poz]=i;
        if (ok(poz))
        {
            if (poz==n)
            {
                ans++;
                if (afis==0) afisare(),afis=1;
            }
            else bkt(poz+1);
        }
    }
}

int main()
{
    fin>>n;
    bkt(1);
    fout<<ans;
}
