#include <bits/stdc++.h>
#define NMAX 15
using namespace std;

ifstream in("damesah.in");
ofstream out("damesah.out");

int nr_solutii=0;
int v[NMAX];

bitset<NMAX> col; ///salvam daca exista deja o dama pe coloana, diagonala principala si diagonala secundara
bitset<NMAX*2> diag_principal, diag_secundar;

void generare_permutari(int poz, int n)
{
    if(poz>n)
    {
        if(nr_solutii==0)
        {
            for(int i=1; i<=n; i++) out << v[i] << " ";
            out << "\n";
        }
        nr_solutii++;
        return;
    }
    for(int i=1; i<=n; i++)
    {
        if(col[i]==0 && diag_principal[poz-i+n]==0 && diag_secundar[poz+i]==0)
        {
            v[poz]=i;
            col[i]=1; diag_principal[poz-i+n]=1; diag_secundar[poz+i]=1;
            generare_permutari(poz+1, n);
            col[i]=0; diag_principal[poz-i+n]=0; diag_secundar[poz+i]=0;
        }
    }
}

int main()
{
    int n;
    in >> n;
    generare_permutari(1, n);
    out << nr_solutii;

    return 0;
}
