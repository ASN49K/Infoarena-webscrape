#include <fstream>
#include <cstdlib>
using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int n,x[31],et;
bool dp[31],ds[31],viz[15];
void tipar(){
    for(int i=1;i<=n;i++)
            g<<x[i]<<' ';
        g<<'\n';
}
void back(int k){
    for(int i=1;i<=n;i++){

        if(ds[k+i-1]==0 && dp[n-(i-k)]==0 && viz[i]==0){
              x[k]=i;
            viz[i]=1;

            dp[n-(i-k)]=1;
            ds[k+i-1]=1;
            if(k==n){
                if(et==0)
                    tipar();
                et++;
            }
            else
                back(k+1);
            viz[i]=0;
            dp[n-(i-k)]=0;
            ds[k+i-1]=0;
        }
    }
}
int main()
{   f>>n;
    et=0;
    back(1);
    g<<et;
    return 0;
}
