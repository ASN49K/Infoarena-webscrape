#include <fstream>
using namespace std;

int n, r[14], nrSol;
bool run = true;
ifstream fin("damesah.in");
ofstream fout("damesah.out");

void afisare() {
    for (int i = 1; i <= n; ++i) {
        fout << r[i] << ' ';
    }
    fout << '\n';
}

bool ok(int k, int j) {
    for (int i = 1; i <= n; ++i) {
        if (r[i]) {
            if (i == k || r[i] == j)
                return false;
            if (i + r[i] == k + j)
                return false;
            if (r[i] - i == j - k)
                return false;
        }
    }
    return true;
}

void bt(int k) {
    for (int j = 1; j <= n; ++j) {
        if (ok(k, j)) {
            r[k] = j;
            if (k == n) {
                if (run)
                    afisare(), run = false;
                ++nrSol;
            }
            else bt(k+1);
        }
        r[k] = 0;
    }
}

int main() {
    fin >> n;
    bt(1);
    fout << nrSol;
    return 0;
}