#include <fstream>

using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int v[10],f[10],n,sol;
void verif() {
    int i,j;
    if(sol==0)
        for(i=1;i<=n;i++)
            fout<<v[i]<<" ";
    sol++;
}
void backt(int k) {
    int j;
    if(k==n+1)
        verif();
    else {
        for(int i=1;i<=n;i++)
            if(!f[i]) {
                for(j=1;j<i;j++)
                    if(j-k==v[j]-i || j-k==i-v[j])
                        break;
                if(i==j) {
                v[k]=i;
                f[i]=1;
                backt(k+1);
                f[i]=0;
                }
            }
    }
}
int main()
{
    fin>>n;
    backt(1);
    fout<<'\n';
    fout<<sol;
    return 0;
}
