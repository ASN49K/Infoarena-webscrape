#include <bits/stdc++.h>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n,s=0;
bool first=true;
bool A[14][14];

bool diag(int x,int y){
	int d1 = x + y;
	int d2 = abs(x-y);
	for(int i=1;i<=n;i++){
		if ((x>y && A[i][i+d2] && i+d2<=n)||(x<y && A[i+d2][i] && i+d2<=n)||(x==y && A[i][i]) || (d1-i>0 &&A[i][d1-i]) || A[y][i] || A[i][x]||A[x][y]) 	{
			//cout<<x<<' '<<y<<' '<<i<<' '<<i+d2<<' '<<d1-i<<'\n';
			return 1;
		}
	}
}

void bk(int y){
	if(y<=n){
		for(int i=1;i<=n;i++){
			if(!diag(i,y))
			{
				A[y][i]=1;
				bk(y+1);
				A[y][i]=0;
			}
		} 
	}else{
		if(first){
			for (int i=1;i<=n;i++){
			 	for (int j=1;j<=n;j++)
					if(A[i][j])
					fout<<j<<' ';		
			}
			fout<<'\n';
		first=false;
		}
		s++;
	}
}

int main(){
	fin>>n;
	bk(1);
	fout<<s;
	return 0;
}
