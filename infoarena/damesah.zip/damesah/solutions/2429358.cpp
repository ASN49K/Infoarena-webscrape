#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <conio.h>

using namespace std;

int n, x[101], nrsol = 0;

int valid(int k)
{
    for(int i = 1; i < k; i++)
        if(x[k] == x[i] || k - i == abs(x[k] - x[i]))
            return 0;
    return 1;
}

void afis()
{
    int i, k;
    system("cls");
    nrsol++;
    cout <<"Solutia " << nrsol << ": ";
    for(i = 1; i <= n; i++)
        cout << x[i] << ' ';
    cout << endl << endl;
    //
    cout << "   ";
    for(k = 1; k <= n; k++)
        cout << setw(4) << k;
    cout << endl << "    +";
    for(k = 1; k <= n; k++)
        cout << "---+";
    cout << endl;
    for(i = 1; i <= n; i++)
    {
        cout << setw(4) << i << "|";
        for(k = 1; k < x[i]; k++)
            cout << "   |";
        cout << " D |";
        for(k = x[i] + 1; k <= n; k++)
            cout << "   |";
        cout << endl;
        cout << "    +";
        for(k = 1; k <= n; k++)
            cout << "---+";
        cout << endl;
    }
    cout << endl;
    cout<<"\nApasati orice tasta pentru continuare...\n";
    getch();
}

void backt()
{
    int k = 1;
    x[1] = 0;
    while(k > 0)
        if(x[k] < n)
        {
            x[k]++; ///...cautare
            if(valid(k))
            {
                if(k == n)
                {
                    afis();
                    k--; ///se poate forta revenirea
                }
                else
                    x[++k] = 0; ///avansare
            }
        }
        else
            k--; //revenire
}
int main()
{
    cout << " n ? ";
    cin >> n;
    backt();
    cout << "S-au generat " << nrsol << " solutii." << endl;
    return 0;
}
