#include <bits/stdc++.h>


using namespace std;

ifstream fin ("damesah.in");
ofstream fout ("damesah.out");

int n, dig1[50], dig2[50], col[50], ok, ans[20], st[20], sol;

void backt (int k) {
  if (k == n + 1) {
    if (!ok) {
      for (int i = 1; i <= n; i++)
        ans[i] = st[i];
      ok = 1;
    }
    sol++;
    return;
  }
  for (int i = 1; i <= n; i++) {
    if (!col[i] && !dig1[k - i + n] && !dig2[k + i - 1]) {
      col[i] = dig1[k - i + n] = dig2[k + i - 1] = 1;
      st[k] = i;
      backt(k + 1);
      col[i] = dig1[k - i + n] = dig2[k + i - 1] = 0;
    }
  }
  return;
}


int main()
{
  fin >> n;
  backt(1);
  for (int i = 1; i <= n; i++)
    fout << ans[i] << " ";
  fout << "\n";
  fout << sol << "\n";
  return 0;
}
