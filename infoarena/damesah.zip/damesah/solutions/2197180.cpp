#include <bits/stdc++.h>
using namespace std;

int n, a[15], b[15], ans;

void backtr(int q){
	if (q == n){
		ans++;
		if (b[1]) return;
		for (int i=1; i<=n; i++) b[i] = a[i];
	}
	for (int col = 1; col <= n; col++){
		bool flag = 1;
		for (int sol=1; sol <= q; sol++){
			if (col == a[sol] || abs(col-a[sol]) == q + 1 - sol) flag = 0;
		}
		if (flag) a[q+1] = col, backtr(q + 1);
	}
}

int main(){
	ifstream cin ("damesah.in");
	ofstream cout ("damesah.out");
	cin >> n;
	backtr(0);
	for (int i=1; i<=n; i++) cout << b[i] << " ";
	cout << "\n" << ans;
	return 0;
}
