#include <fstream>
using namespace std;
ifstream fin ("damesah.in");
ofstream fout ("damesah.out");
long long n,t,v[55],c[55],d1[55],d2[55];
void Backtr (long long k)
{
    if (k<=n)
    {
        for (int i=1;i<=n;++i)
        {
            if (c[i]==0 and d1[i-k+n]==0 and d2[k+i]==0)
            {
                c[i]=1;
                d1[i-k+n]=1;
                d2[i+k]=1;
                v[k]=i;
                Backtr (k+1);
                c[i]=0;
                d1[i-k+n]=0;
                d2[i+k]=0;
                v[k]=0;
            }
        }
    }
    else
    {
        if (t==0)
        {
            for (int i=1;i<=n;++i)
                fout <<v[i]<<' ';
            fout <<'\n';
        }
        t++;
    }
}
int main()
{
    fin >>n;
    Backtr (1);
    fout <<t;
    fin.close ();
    fout.close ();
    return 0;
}
