#include <iostream>
#include <cmath>
using namespace std;

int n, x[20], nrsol;
int prima[20];
bool ok = 0;

bool valid(int k)
{
    for(int i = 1; i < k; i++)
        if(x[k] == x[i] || k - i == abs(x[k] - x[i]))
            return 0;
    return 1;
}

void afis()
{
    nrsol++;
    if(!ok)
    {
        for(int i = 1; i <= n; i++)
            prima[i] = x[i];
        ok = 1;
    }
}

void bt(int k)
{
    if(k <= n)
        for(int i = 1; i <= n; i++)
        {
            x[k] = i;
            if(valid(k))
                bt(k + 1);
        }
    else
        afis();
}

int main()
{
    cin >> n;
    bt(1);

    for(int i = 1; i <= n; i++)
        cout << prima[i] << ' ';
    cout << '\n' << nrsol;

    return 0;
}
