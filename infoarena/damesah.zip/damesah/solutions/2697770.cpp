#include <fstream>

using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int v[10],f[10],n,sol;
void verif() {
    int i,j;
    for(i=1;i<n;i++)
        for(j=i+1;j<=n;j++)
            if(i-j==v[i]-v[j] || i-j==v[j]-v[i])
                return;
    if(sol==0)
        for(i=1;i<=n;i++)
            fout<<v[i]<<" ";
    sol++;
}
void backt(int k) {
    if(k==n+1)
        verif();
    else {
        for(int i=1;i<=n;i++)
            if(!f[i]) {
                v[k]=i;
                f[i]=1;
                backt(k+1);
                f[i]=0;
            }
    }
}
int main()
{
    fin>>n;
    backt(1);
    fout<<'\n';
    fout<<sol;
    return 0;
}
