#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n, nr_losutii;
int st[20];
bool f[20];

void afisare() {
    if (nr_losutii == 0) {
        ++nr_losutii;
        for (int i = 1; i <= n; ++i) {
            fout << st[i] << " ";
        }
        fout << "\n";
    } else {
        ++nr_losutii;
    }
}

void back(int top) {
    if (top > n) {
        afisare();
        return;
    }

    for (int i = 1; i <= n; ++i) {
        if (top == 1) {
            if (f[i] == 0) {
                f[i] = 1;
                st[top] = i;
                back(top + 1);
                f[i] = 0;
            }
        } else {
            // Prin st[top - 1] + 1 != i ca damele sa nu fie pe aceasi diagolana(principala)
            // Prin st[top - 1] - 1 != i ca damele sa nu fie pe aceasi diagolana(secundara)
            if (f[i] == 0) {
                bool corect = true;
                for (int j = 1; j < top  && corect == true; ++j) {
                    corect = false;
                    if (st[j] + top - j != i && st[j] - top + j != i) {
                        corect = true;
                    }
                }
                if (corect == true) {
                    f[i] = 1;
                    st[top] = i;
                    back(top + 1);
                    f[i] = 0;
                }
            }
        }
    }
}

int main() {
    fin >> n;
    nr_losutii = 0;
    back(1);
    fout << nr_losutii;

    return 0;
}
