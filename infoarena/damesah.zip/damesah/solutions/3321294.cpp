/*#include <fstream>
#include <cstdlib>
using namespace std;
int n, x[20]; bool da=0;
ifstream fin("damesah.in");
ofstream fout("damesah.out");

bool Val(int k)
{
    for(int i=1; i<k; ++i)
    {
        if(x[i]==x[k])return 0;
        if(k-i==abs(x[k]-x[i]))
            return 0;
    }
    return 1;
}

void Afisare(int n)
{
    da=1;for(int i=1; i<=n; ++i)
    {
        for(int j=1; j<=n; ++j)
            if(x[j]==i)fout<<"* ";
            else fout<<"- ";
        fout<<'\n';
    }
}

void Back(int k)
{
    for(int i=1; !da&&i<=n; ++i)
    {
        x[k]=i;
        if(Val(k))
        {
            if(k==n)Afisare(n);
            else Back(k+1);
        }
    }
}

int main()
{
    fin >> n;
    Back(1);
    fin.close();
    fout.close();
    return 0;
}*/
///scusami
#include <iostream>
#include <fstream>
using namespace std;

int n, v[15];
bool col[15], d1[30], d2[30];
long long sol;
bool gasit = false;
ofstream fout("damesah.out");

void scrie() {
    for(int i = 1; i <= n; i++)
        fout << v[i] << (i == n ? '\n' : ' ');
}

void BT(int i) {
    if(i > n) {
        sol++;
        if(!gasit) {
            scrie();
            gasit = true;
        }
        return;
    }
    for(int j = 1; j <= n; j++) {
        if(!col[j] && !d1[i - j + n] && !d2[i + j]) {
            v[i] = j;
            col[j] = d1[i - j + n] = d2[i + j] = true;
            BT(i + 1);
            col[j] = d1[i - j + n] = d2[i + j] = false;
        }
    }
}

int main() {
    ifstream fin("damesah.in");
    fin >> n;
    BT(1);
    fout << sol << endl;
    return 0;
}
