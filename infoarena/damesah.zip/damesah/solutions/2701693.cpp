#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

bool lin[14],  diag[30], dsec[30];


int n;
bool afisat;
unsigned long long sol;
int v[14];

void backt(int j)
{
    if(j == n + 1)
    {
        ++sol;
        if(!afisat)
        {
            for(int i=1;i<=n;i++)
                fout<<v[i]<<' ';
            fout<<'\n';
            afisat = true;
        }
    }
    for(int i=1;i<=n;i++)
        if(!lin[i] && !diag[n+j-i+1] && !dsec[i+j-1])
        {
            v[j] = i;
            lin[i] = true;
            diag[n+j-i+1] = true;
            dsec[i+j-1] = true;
            backt(j + 1);
            lin[i] = false;
            diag[n+j-i+1] = false;
            dsec[i+j-1] = false;
        }

}


int main()
{
    fin>>n;
    backt(1);
    fout<<sol<<'\n';
    fin.close();
    fout.close();
    return 0;
}
