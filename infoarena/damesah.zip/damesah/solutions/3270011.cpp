#include <bits/stdc++.h>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n, cnt=0, sol[20];
bool ok=false;

void afis() {
    for(int i=1; i<=n; i++) {
        fout << sol[i] << " ";
    }
    fout << "\n";
    ok=true;
}

bool verif(int k) {
    for(int i=1; i<k; i++) {
        if(sol[i]==sol[k] || (k-i)==abs(sol[k]-sol[i])) {
            return false;
        }
    }
    return true;
}

void bktr(int k) {
    if(k==n+1) {
        cnt++;
        if(ok==false) {
            afis();
        }
        return;
    }
    for(int i=1; i<=n; i++) {
        sol[k]=i;
        if(verif(k)) {
            bktr(k+1);
        }
        sol[k]=0;
    }
}

int main()
{
    fin >> n;
    bktr(1);
    fout << cnt;
    return 0;
}
