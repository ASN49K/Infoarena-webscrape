#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

#define N 15
bool viz[N], ok;
int x[N], n, cnt;
bool SolPar(int k)
{
    for(int i = 1; i < k; i++)
        if(abs(k - i) == abs(x[k] - x[i]))
            return 0;
    return 1;
}
void Afisare(int k)
{
    for(int i = 1; i <= n; i++)
        fout << x[i] << " ";
    fout << "\n";
}
void Back(int k)
{
    for(int i = 1; i <= n; i++)
        if(!viz[i])
    {
        viz[i] = 1;
        x[k] = i;
        if(SolPar(k))
            if(k == n)
            {
                if(!ok)
                {
                    Afisare(k);
                    ok = 1;
                }
                cnt++;
            }
            else Back(k + 1);
        viz[i] = 0;
    }
}
int main()
{
    fin >> n;
    Back(1);
    fout << cnt;
    return 0;
}
