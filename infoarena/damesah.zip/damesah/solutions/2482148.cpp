#include <iostream>
#include <fstream>
using namespace std;
int n,sol[20],v[20],ans,sel[20];
bool valid (int k){
    if (!k)
        return 1;
    for (int i = k - 1; i > -1; --i)
    if (v[i] - i == v[k] - k || v[i] + i == v[k] + k)
        return 0;
    return 1;
}
void bkt (int k){
    if (k == n){
        ++ans;
        if (ans == 1){
            for (int i = 0; i < n; ++i)
                sol[i] = v[i];
        }
        return;
    }
    for (int i = 0; i < n; ++i)
    if (!sel[i]){
        sel[i] = 1;
        v[k] = i;
        if (valid (k))
            bkt (k + 1);
        v[k] = 0;
        sel[i] = 0;
    }

}
int main()
{
    ifstream fin ("damesah.in");
    ofstream fout ("damesah.out");
    fin >> n;
    bkt (0);
    for (int i = 0; i < n; ++i)
        fout << sol[i] + 1 << " ";
    fout << '\n' << ans;
    return 0;
}
