#include <fstream>
std::ifstream fin("damesah.in");
std::ofstream fout("damesah.out");
int cnt, sol[14], n, mat[14][14];
void print(){
    if(!cnt){
        for(int i = 1; i <= n; i++)
            fout << sol[i] << " ";
        fout << "\n";
    }
    cnt++;
}
void back(int k){
    if(k == n + 1){
        print();
    }
    for(int i = 1; i <= n; i++){
        int ok = 1;
        for(int j = 1; j < k; j++)
            if(sol[j] == i)
                ok = 0;
        for(int j = k - 1, col = i - 1; j >= 1 && col >= 1; j--, col--){
            if(mat[j][col] == 1)
                ok = 0;
        }
        for(int j = k + 1, col = i - 1; j <= n && col >= 1; j++, col--){
            if(mat[j][col] == 1)
                ok = 0;
        }
        for(int j = k - 1, col = i + 1; j >= 1 && col <= n; j--, col++){
            if(mat[j][col] == 1)
                ok = 0;
        }
        for(int j = k + 1, col = i + 1; j <= n && col <= n; j++, col++){
            if(mat[j][col] == 1)
                ok = 0;
        }
        
        if(ok){
            sol[k] = i; mat[k][i] = 1;
            back(k + 1);
            sol[k] = 0, mat[k][i] = 0;
        }
    }
}
int main(){
    fin >> n;
    back(1);
    fout << cnt;
}