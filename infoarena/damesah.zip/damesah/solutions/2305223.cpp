#include <bits/stdc++.h>

using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int n;
bool coloane[20];
vector<int> sol;
int solutii;
void bkt(int poz);
bool ver(int x);
bool ok=true;
int main()
{
    fin>>n;
    bkt(0);
    fout<<solutii<<'\n';
    return 0;
}
bool ver(int x)
{
    bool key=true;
    for(int i=sol.size()-1; i>=0 && key; i--)
    {
        int linie_adauga=sol.size();
        if(abs(linie_adauga-i)+1==abs(x-sol[i])+1) key=false;
    }
    return key;
}
void bkt(int poz)
{
    if(poz==n)
    {
        solutii++;
        if(ok)
        {
            for(int i=0; i<sol.size(); i++) fout<<sol[i]<<' ';
            fout<<'\n';
            ok=false;
        }
        return;
    }
    for(int i=1; i<=n; i++)
    {
        if(coloane[i])  continue;
        else if(ver(i))
        {
            coloane[i]=1;
            sol.push_back(i);
            bkt(poz+1);
            sol.pop_back();
            coloane[i]=0;
        }
    }
}
