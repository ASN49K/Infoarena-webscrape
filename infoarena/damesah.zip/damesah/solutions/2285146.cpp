#include <fstream>
#include <cstdlib>
using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int n,viz[20],x[20],et;
int valid(int k){
    if(viz[x[k]]==1)
        return 0;
    for(int i=1;i<k;i++)
        if(k-i==abs(x[k]-x[i]))
            return 0;
    return 1;
}
void tipar(){
    if(et==0){
    for(int i=1;i<=n;i++)
            g<<x[i]<<' ';
        g<<'\n';
        et=1;
    }
    else
        et++;
}
void back(int k){
    for(int i=1;i<=n;i++){
        x[k]=i;
        if(valid(k)==1){
            viz[i]=1;
            if(k==n){
                tipar();
            }
            else
                back(k+1);
            viz[i]=0;
        }
    }
}
int main()
{   f>>n;
    et=0;
    back(1);
    g<<et;
    return 0;
}
