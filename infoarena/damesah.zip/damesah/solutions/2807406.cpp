#include <bits/stdc++.h>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int n, x[21], nrSol;
bool ok = false;
void afis()
{
    for(int i = 1 ; i <= n ; i++)
        fout << x[i] << " ";
    fout  << '\n';
}
bool verif(int k)
{


    int d1 = abs(x[k]-k);
     int d2 = abs(x[k]+k);
    for(int i = 1 ; i < k ; i++)
    {

         int rez1 = abs(x[i] - i);
         int rez2 = abs(x[i] + i);

        if(x[i] == x[k])
            return false;
            if(d1 == rez1 && ((i <= x[i] && k <= x[k]) || (i > x[i] && k > x[k])))
                return false;
            if(d2 == rez2  )
                return false;
    }
    return true;
}
void back(int k)
{
    if(k > n)
    {
        if(!ok)
        {
            afis();
            ok = true;
        }
        nrSol++;
    }
    else
        for(int i = 1 ; i <= n ; i++)
    {
        x[k] = i;
        if(verif(k))
            back(k+1);
    }
}
int main()
{

    fin >> n;
    back(1);
    fout << nrSol;
    return 0;
}
