def ciuciu():
    global n
    global ans
    global ok
    col = [0 for i in range(n+1)]
    d1 = [0 for i in range(0, 2*n + 2)]
    d2 = [0 for i in range(0, 2*n + 2)]
    sol = [0 for i in range(0, n + 1)]
    ok = 0
    def BKT(k):
        global n
        global ans
        global ok
        if k == n + 1:
            ans += 1
            if ok == 0:
                ok = 1
                for i in range(1, n+1):
                    g.write(str(sol[i]))
                    g.write(" ")
                g.write("\n")
        else:
            for i in range(1, n + 1):
                r1 = k - i + n
                r2 = k - (n + 1 - i) + n
                if d1[r1] == 0 and d2[r2] == 0 and col[i] == 0:
                    d1[r1] = 1
                    d2[r2] = 1
                    col[i] = 1
                    sol [k] = i
                    BKT(k+1)
                    d1[r1] = 0
                    d2[r2] = 0
                    col[i] = 0
    BKT(1)
    g.write(str(ans))

f = open("damesah.in","r")
g = open("damesah.out","w")
try:
    n = int(f.readline())
except:
    n = int(f.readline())
ans = 0
ok = 0
ciuciu()
