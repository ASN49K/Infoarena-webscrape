#include <iostream>
#include <fstream>

using namespace std;
ifstream fin ("damesah.in");
ofstream fout ("damesah.out");
const int Nmax=13;

string mat[Nmax];
int lin[Nmax], col[Nmax], d1[2*Nmax], d2[2*Nmax], sol, N, v[Nmax];

void bkt(int ind, int i){
    if (ind==N){
        if (sol==0){
            for (int i=0; i<N; i++)
                fout<<v[i]<<' ';
            fout<<'\n';
        }
        sol++;
        return;
    }
    if (i==N*N)
        return;
    if (lin[i/N]==0 && col[i%N]==0 && d1[i/N-i%N+N-1]==0 && d2[i/N+i%N]==0){
        lin[i/N]=1;
        v[i/N]=i%N+1;
        col[i%N]=1;
        d1[i/N-i%N+N-1]=1; 
        d2[i/N+i%N]=1;
        bkt(ind+1, i+1);
        lin[i/N]=0; 
        col[i%N]=0;
        d1[i/N-i%N+N-1]=0; 
        d2[i/N+i%N]=0;
    }
    bkt(ind, i+1);
}

int main(){
    fin>>N;
    bkt(0, 0);
    fout<<sol;

    return 0;
}