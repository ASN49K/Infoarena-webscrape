#include <fstream>

using namespace std;
ifstream cin("damesah.in");
ofstream cout("damesah.out");
int n,sol=0;
bool v[15][15];


 void solve ()
 {
     if(sol==1)
     {
         for(int i=1;i<=n;i++)
           for(int j=1;j<=n;j++)
           if(v[i][j]==1)
           cout<< j<<" ";
         cout<<'\n';
     }


 }
 void  submultimi(int pos)
 {
     if(pos==n+1)
     {

        sol++;
        solve();
        return;
     }

     for(int i=1;i<=n;i++)
     {
         int ok=1;
         for(int a=pos,b=i;a>=1 && b>=1;a--,b--)
            if(v[a][b])
            ok=0;
          for(int a=pos,b=i;a>=1 && b<=n;a--,b++)
            if(v[a][b])
            ok=0;
             for(int a=pos,b=i; a>=1;a--)
            if(v[a][b])
            ok=0;
            if(ok==1)
            {
                v[pos][i]=1;
                submultimi(pos+1);
                v[pos][i]=0;


            }
     }
 }
int main()
{
    cin>>n;
    submultimi(1);
    cout<<sol;
    return 0;
}
