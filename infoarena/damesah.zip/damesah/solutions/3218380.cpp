#include <bits/stdc++.h>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

bool col[20];
bool diag1[40];
bool diag2[40];
bool ok;
int v[20];
int n;
int cnt;

void myback(int k)
{
    if(k==n+1)
    {
        if(!ok)
        {
            int i;
            for(i=1;i<=n;++i)
                fout<<v[i]<<' ';
            fout<<'\n';
            ok=1;
        }
        ++cnt;
    }
    else
    {
        int i;
        for(i=1;i<=n;++i)
            if(!col[i] && !diag1[k-i+n] && !diag2[k+i])
            {
                v[k]=i;
                col[i]=1;
                diag1[k-i+n]=1;
                diag2[k+i]=1;
                myback(k+1);
                col[i]=0;
                diag1[k-i+n]=0;
                diag2[k+i]=0;
            }
    }
}

int main()
{
    fin>>n;
    myback(1);
    fout<<cnt;
    return 0;
}
