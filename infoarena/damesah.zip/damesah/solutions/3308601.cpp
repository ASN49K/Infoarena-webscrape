#include <fstream>
#include <bitset>
#include <cmath>

using namespace std;

ifstream cin("damesah.in");
ofstream cout("damesah.out");

int v[15];
int n;
int cnt = 0;

bitset<15> viz; // rezolvam evitarea damelor pe aceeasi coloana

void back(int k) {
    if (k > n) {
        if (cnt == 0) {
            for (int i = 1 ; i <= n ; ++i) {
                cout << v[i] << " ";
            }
        }
        ++cnt;
        return;
    }
    for (int i = 1 ; i <= n ; ++i) {
        if (viz[i] == 0) { // nicio dama pe linia asta
            bool ok = 1;
            for (int j = 1 ; j < k && ok ; ++j) {
                if (abs(v[j] - i) == abs(j - k)) { // coloanele damelor trecute - coloana damei de acuma == liniile damelor trecute - linia de acuma
                    // sunt pe aceeasi diagonala, |x1 - x2| == |y1 - y2|
                    ok = 0;
                }
            }
            if (ok) {
                v[k] = i;
                viz[i] = 1;
                back(k + 1);
                viz[i] = 0;
            }
        }
    }
}

int main() {
    cin >> n;
    back(1);
    cout << "\n" << cnt;
    return 0;
}