#include <iostream>
#pragma GCC optimise("O3, Ofast, unroll-loops")
using namespace std;

const int NMAX = 15;
int solution[NMAX], cnt = 0;
bool occupied_column[NMAX];
bool occupied_principal_diagonal[2 * NMAX];
bool occupied_secondary_diagonal[2 * NMAX];

void print_solution(int n){
    for(int i = 1; i <= n; i++){
        printf("%d ", solution[i]);
    }
    printf("\n");
}

void backtrack(int line, int n){
    if(line == n + 1){
        if(cnt == 0)
            print_solution(n);
        cnt++;
        return;
    }
    for(int column = 1; column <= n; column++){
        if(occupied_column[column]) continue;
        if(occupied_principal_diagonal[line - column + n]) continue;
        if(occupied_secondary_diagonal[line + column]) continue;
        occupied_column[column] = true;
        occupied_principal_diagonal[line - column + n] = true;
        occupied_secondary_diagonal[line + column] = true;
        solution[line] = column;
        backtrack(line + 1, n);
        occupied_column[column] = false;
        occupied_principal_diagonal[line - column + n] = false;
        occupied_secondary_diagonal[line + column] = false;
    }
}

int main(){
    freopen("damesah.in", "r", stdin);
    freopen("damesah.out", "w", stdout);
    int n;
    scanf("%d", &n);

    backtrack(1, n);
    printf("%d", cnt);
    return 0;
}
