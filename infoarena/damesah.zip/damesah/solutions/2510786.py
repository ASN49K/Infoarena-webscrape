f = open("damesah.in","r")

n = int(f.read())

print(n)

f.close()