#include<bits/stdc++.h>
using namespace std;
#define forn(i,a,b) for (int i = a; i <= b; i++)
ifstream in("damesah.in");
ofstream out("damesah.out");
int n, st[100], k, as, ev, i;

void succesor()
{
	if (st[k]<n){
		st[k]++;
		as=1;
	}
	else as=0;
}

void valid()
{
	int i; ev=1;
	forn(i,1,k) if (st[i]==st[k] || abs(i-k)==abs(st[i]-st[k])) ev=0;
}

void back()
{
	k=1; st[k]=0;
	while(k>0)
	{
		do{
			succesor();
			if (as) valid();
		}
		while(as && !ev);
		if (as) if (k==n){
			forn(i,1,n)
				out<<st[i]<<" ";
			cout<<endl;
		}
		        else{
		        	k++;
		        	st[k]=0;
				}  
		else k--;        
	}
}

int main()
{
	in>>n;
	back();
	return 0;
}
