#include <iostream>

#include <fstream>



using namespace std;



ifstream fin("damesah.in");

ofstream fout("damesah.out");



int dame[14], db;

bool col[14], fatlo[30], matlo[30];



void bkt(int n, int k)

{

    if(k==n){

        if(db<1){

            for(int i=0; i<n; i++){

                fout<<dame[i]+1<<" ";

            }

            fout<<endl;

        }

        db++;

    } else{

         for(int i=0; i<n; i++){

            if (!col[i] && !fatlo[i-k+n-1] && !matlo[k+i]){

                dame[k]=i;

                col[i]=fatlo[i-k+n-1]=matlo[k+i]=true;

                bkt(n,k+1);

                col[i]=fatlo[i-k+n-1]=matlo[k+i]=false;

            }

        }

    }

}



int main()

{

    int n;

    fin>>n;

    bkt(n,0);

    fout<<db;

    return 0;

}
