#include <bits/stdc++.h>
using namespace std;
ifstream fin ("damesah.in");
ofstream fout("damesah.out");
int n,st[15],sol,viz[15];

void afis ()
{
    for (int i=1;i<=n;i++)
        fout<<st[i]<<' ';
    fout<<'\n';
}

bool valid (int p)
{
    if (p==1)
        return 1;
    for (int i=1;i<p;i++)
        if (abs (st[i]-st[p])==p-i)
        return 0;
    return 1;
}


void bk (int p)
{
    for (int i=1;i<=n;i++)
    if (viz[i]==0)
    {
        st[p]=i;
        viz[i]=1;
        if (valid(p))
        {
            if (p==n)
            {
                sol++;
                if (sol==1)
                    afis();
            }
            else    bk(p+1);
        }
        viz[i]=0;
    }
}

int main()
{
    fin>>n;
    bk(1);
    fout<<sol<<'\n';
}
