#include <bits/stdc++.h>

using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int n, sol = 0, st[20], v[20], dp[20], ds[20];
bool valid(int i, int j)
{
    if (v[j] == 1) return 0;
    if (dp[i + j - 1] == 1) return 0;
    if (ds[n + i - j] == 1) return 0;
    return 1;
}
void Back(int top)
{
    if (top == n + 1)
    {
        sol++;
        if (sol == 1)
        {
            for (int i = 1; i <= n; i++)
                fout << st[i] << " ";
            fout << "\n";
        }
    }
    else
    {
        for (int i = 1; i <= n; i++)
        if (valid(top, i))
        {
            v[i] = 1;
            st[top] = i;
            dp[top + i - 1] = 1;
            ds[n + top - i] = 1;
            Back(top + 1);
            dp[top + i - 1] = 0;
            ds[n + top - i] = 0;
            v[i] = 0;
        }
    }
}
int main()
{
    fin >> n;
    Back(1);
    fout << sol << "\n";
    return 0;
}
