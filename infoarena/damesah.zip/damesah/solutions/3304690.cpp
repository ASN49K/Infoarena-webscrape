#include <bits/stdc++.h>
using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

constexpr int NMAX = 13;
int a[NMAX + 1], main_diag[NMAX * 2 + 1], sec_diag[NMAX * 2 + 1];

int main() {
    int n;
    fin >> n;

    for (int i = 1; i <= n; i++) {
        a[i] = i;
    }

    long long ans = 0;
    bool first = true;
    do {
        bool ok = true;

        for (int i = 1; i <= n; i++) {
            if (!main_diag[a[i] - i + n] && !sec_diag[i + a[i]]) {
                main_diag[a[i] - i + n] = sec_diag[i + a[i]] = 1;
            } else {
                ok = false;
                break;
            }
        }

        for (int i = 1; i <= n; i++) {
            main_diag[a[i] - i + n] = sec_diag[i + a[i]] = 0;
        }

        ans += ok;

        if (ok && first) {
            first = false;
            for (int i = 1; i <= n; i++) {
                fout << a[i] << ' ';
            }
            fout << '\n';
        }
    } while (next_permutation(a + 1, a + n + 1));

    fout << ans;

}