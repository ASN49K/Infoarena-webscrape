#include<fstream>
using namespace std;
int sol[100], nr;
int fol[100];
int n;

ifstream f("damesah.in");
ofstream g("damesah.out");

void back(int k)
{
	if (k == n + 1)
	{
		nr++;
		if (nr == 1)
		{
			for (int i = 1; i <= n; i++)
				g << sol[i] << ' ';
			g << '\n';
		}
	}
	else
		for (int i = 1; i <= n; i++)
			if (fol[i] == 0)
			{
				int ok = 1;
				for (int j = 1; j < k; j++)
					if (abs(sol[j] - i) == k - j)
					{
						ok = 0;
						break;
					}
				if (ok)
				{
					sol[k] = i;
					fol[i] = 1;
					back(k + 1);
					fol[i] = 0;

				}
			}
}

int main()
{
	ios_base::sync_with_stdio(false);
	f.tie(0);
	g.tie(0);
	f >> n;
	back(1);
	g << nr;
}