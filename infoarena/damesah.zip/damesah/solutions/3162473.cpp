#include<bits/stdc++.h>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int n, s[14], l[14], d1[28], d2[28], cnt=0;

void afis(){
    if(!cnt){
        for(int i=1; i<=n; i++) fout<<s[i]<<" ";
        fout<<"\n";
    }
    cnt++;
}

void bkt(int k){
    for(int i=1; i<=n; i++){
        //cout<<k<<" "<<i<<" "<<n-i+k<<" "<<k+i-1<<" ";
        if(!l[i] && !d1[n+(i-k)] && !d2[(k+i)-1]){
            //cout<<"true!\n";
            s[k] = i;
            l[i] = 1;
            d1[n+(i-k)] = 1;
            d2[(k+i)-1] = 1;
            if(k<n) bkt(k+1);
            else afis();
            d2[(k+i)-1] = 0;
            d1[n+(i-k)] = 0;
            l[i] = 0;
            s[k] = 0;
        }
        //else cout<<"false.\n";
    }
}

int main(){
    fin>>n;
    bkt(1);
    fout<<cnt;
}
