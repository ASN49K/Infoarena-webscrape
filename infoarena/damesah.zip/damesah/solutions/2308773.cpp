#include <fstream>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
short n;
int rez;
bool M[15][15],afisare;
bool Linie[15],Coloana[15];
void Add(short,short,short),Afis();
bool Posibil(short,short);
void afisare1(){
    int i,j;
    for(i=0;i<n;++i){
        for(j=0;j<n;++j)fout<<M[i][j]<<' ';
        fout<<endl;
    }
    fout<<endl;
}
int main(){
    int i,j;
    fin>>n;
    Add(n,0,0);
    fout<<rez<<'\n';
    return 0;
}
void Add(short x,short a,short b){
    if(!x){
        if(!afisare){
            afisare=1;
            Afis();
        }
        ++rez;
    }
    //afisare1();
    if(a>=1&&x==n)return;
    int i,j;
    for(i=a;i<n;++i){
        while(i<n&&Linie[i])++i;
        if(i==n)break;
        if(i!=a)b=0;//resetam b pentru urmatorul for
        if(i>=1&&x==n) return;
        for(j=b;j<n;++j){
            while(j<n&&Coloana[j])++j;
            if(j==n)break;
            if(Posibil(i,j)){
                M[i][j]=1;
                Linie[i]=1;
                Coloana[j]=1;
                Add(x-1,i,j);
                M[i][j]=0;
                Linie[i]=0;
                Coloana[j]=0;
            }

        }
    }
}
bool Posibil(short a,short b){
    if(M[a][b])return 0;
    short ca=a,cb=b;
    ++a;--b;
    while(a<n&&b>=0){
        if(M[a][b])return 0;
        ++a;--b;
    }a=ca;b=cb;
    ++a;++b;
    while(a<n&&b<n){
        if(M[a][b])return 0;
        ++a;++b;
    }a=ca;b=cb;
    --a;--b;
    while(a>=0&&b>=0){
        if(M[a][b])return 0;
        --a;--b;
    }a=ca;b=cb;
    --a;++b;
    while(a>=0&&b<n){
        if(M[a][b])return 0;
        --a;++b;
    }
    return 1;
}
void Afis(){
    int i,j;
    for(i=0;i<n;++i){
        for(j=0;j<n;++j){
            if(M[i][j])fout<<j+1<<' ';
        }
    }fout<<'\n';
}
