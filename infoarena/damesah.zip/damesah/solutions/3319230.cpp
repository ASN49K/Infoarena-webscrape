#include <fstream>
#include <cmath>

using namespace std;
ifstream cin("damesah.in");
ofstream cout("damesah.out");
int x[14],n,nr;
bool okay=1;
bool valid(int k)
{
    for(int i=1; i<k; i++)
    {
        if(x[k]==x[i] || k-i==abs(x[k]-x[i])) return 0;
    }
    return 1;
}
void afis()
{
    for(int i=1; i<=n; i++)
        cout<<x[i]<<' ';
}
void bt(int k)
{
    if(k<=n)
    {
        for(int i=1; i<=n; i++)
        {
            x[k]=i;
            if(valid(k)) bt(k+1);
        }
    }
    else
    {
        if(okay==1)
        {
            okay=0;
            afis();
        }
        nr++;
    }
}
int main()
{
    cin>>n;
    bt(1);
    cout<<'\n'<<nr;
    return 0;
}
