#include <bits/stdc++.h>

using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
const int cst=20;
int n;
bool coloane[20];
bool Dp[40], Ss[20];
vector<int> sol;
int solutii;
void bkt(int poz);
bool ver(int x, int &dif, int &suma);
bool ok=true;
int main()
{
    fin>>n;
    bkt(0);
    fout<<solutii<<'\n';
    return 0;
}
bool ver(int x, int &dif, int &suma)
{
    dif=sol.size()-x+cst;
    suma=sol.size()+x;
    if(Dp[dif] || Ss[suma]) return 0;
    Dp[dif]=1;
    Ss[suma]=1;
    return 1;
}
void bkt(int poz)
{
    if(poz==n)
    {
        solutii++;
        if(ok)
        {
            for(int i=0; i<sol.size(); i++) fout<<sol[i]<<' ';
            fout<<'\n';
            ok=false;
        }
        return;
    }
    for(int i=1; i<=n; i++)
    {
        if(coloane[i])  continue;
        int dif, suma;
        if(ver(i, dif, suma))
        {
            coloane[i]=1;
            sol.push_back(i);
            bkt(poz+1);
            sol.pop_back();
            coloane[i]=0;
            Dp[dif]=0;
            Ss[suma]=0;
        }
    }
}
