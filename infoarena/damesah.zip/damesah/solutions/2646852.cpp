#include <fstream>

using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int n,r,v[14];
bool v2[28],v3[28];
bool w[14];
void bkt(int l)
{
    if(l>n)
    {
        r++;
        if(r==1)
        {
            for(int i=1; i<=n; ++i)
            {
                g<<v[i]<<" ";
            }
            g<<'\n';
        }
        return;
    }
    for(int i=1; i<=n; ++i)
    {
        if(w[i]==0 && v2[i-l+n]==0 && v3[i+l]==0)
        {
            w[i]=1;
            v[l]=i;
            v2[i-l+n]=1;
            v3[i+l]=1;
            bkt(l+1);
            w[i]=0;
            v[l]=0;
            v2[i-l+n]=0;
            v3[i+l]=0;
        }
    }

}
int main()
{
    f>>n;
    bkt(1);
    g<<r;

    return 0;
}
