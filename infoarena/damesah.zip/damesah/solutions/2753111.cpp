#include <bits/stdc++.h>
#define dim 100005
#define mod 1000000007
#define int long long
#define INF  2000000000
using namespace std;
ifstream fin ("damesah.in");
ofstream fout("damesah.out");
int n,st[15],sol,viz[15];

void afis ()
{
    for (int i=1;i<=n;i++)
        fout<<st[i]<<' ';
    fout<<'\n';
}


void bk (int p)
{
    for (int i=1;i<=n;i++)
    if (viz[i]==0)
    {
        st[p]=i;
        viz[i]=1;
        if ((p==1)|| (st[p-1]!=i-1 && st[p-1]!=i+1))
        {
            if (p==n)
            {
                sol++;
                if (sol==1)
                    afis();
            }
            else    bk(p+1);
        }
        viz[i]=0;
    }
}

int32_t main()
{
    fin>>n;
    bk(1);
    fout<<sol<<'\n';
}
