#include <iostream>

using namespace std;

int n,i,j;
int sol[12];
int psol[12];
int solutii;
void print()
{
    if(solutii==1)
    {
        for(int i=1;i<=n;i++)
            cout<<sol[i]<<" ";
        cout<<'\n';
    }
}
bool eOk(int k)
{
    for(int i=1;i<k;i++)
    {
        if(sol[k]==sol[i])
            return 0;
        if(k-i==abs(sol[k]-sol[i]))
            return 0;
    }
    return 1;
}
void backtrack(int k)
{
    if(k==n+1)
    {
        solutii++;
        print();
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            sol[k]=i;
            if(eOk(k))
                backtrack(k+1);
        }
    }
}
int main()
{
    cin>>n;
    backtrack(1);
    cout<<solutii;
    return 0;
}
