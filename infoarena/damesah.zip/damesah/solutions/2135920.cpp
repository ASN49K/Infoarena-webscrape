#include <fstream>
#include <cmath>
using namespace std;
ifstream fin ("damesah.in");
ofstream fout("damesah.out");
const int NMAX=13;
int st[NMAX+5];
bool viz[NMAX+5];
int n;
int nr=0;
void print()
{
    int i;
    for(i=1;i<=n;i++)
        fout<<st[i]<<" ";
    fout<<"\n";

}
void backt(int x)
{
    bool ok=1;
    int i, j;
    if(x==n+1)
    {
        nr=nr+1;
        if(nr==1)
          print();
    }
    else
    {
        for(i=1;i<=n;i++)
        {
            st[x]=i;
            if(!viz[st[x]])
            {
                ok=1;
                for(j=1;j<x;j++)
                {
                    if((abs(st[x]-st[j])==abs(x-j))or(st[x]==st[j]))
                   {
                    ok=0;
                    break;
                    }
                }
                if(ok==1)
                {
                viz[st[x]]=1;
                backt(x+1);
                viz[st[x]]=0;
                }
            }
        }
    }
}

int main()
{
    fin>>n;
    backt(1);
    fout<<nr<<"\n";

    return 0;
}
