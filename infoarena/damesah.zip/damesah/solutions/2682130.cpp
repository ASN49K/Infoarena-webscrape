#include <iostream>
#include <fstream>

using namespace std;

ifstream in("damesah.in");
ofstream out("damesah.out");

int n, ans;
int v[15];

void print()
{
    for(int i = 1; i <= n; i++)
        out << v[i] << ' ';
    out << '\n';
}

bool check(int index)
{
    for(int i = 1; i < index; i++)
        if(v[index] == v[i] || v[index] == v[i] + (index - i) || v[index] == v[i] - (index - i))
            return false;

    return true;
}

void sah(int index)
{
    for(v[index] = 1; v[index] <= n; v[index]++)
    {
        if(index == n + 1)
        {
            if(ans == 0)
                print();
            ans++;
            return;
        }
        else if(check(index))
            sah(index + 1);
    }
}

int main()
{
    in >> n;

    sah(1);

    out << ans << '\n';

    return  0;
}
