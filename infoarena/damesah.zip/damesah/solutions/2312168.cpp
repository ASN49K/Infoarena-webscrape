#include <fstream>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
short n;
int rez;
short M[15][15],afisare;
bool Coloana[15];
void Bkt(short),Afis();
void Fill(short,short,bool);
void AfisareM(){
    int i,j;
    for(i=0;i<n;++i){
        for(j=0;j<n;++j)fout<<M[i][j]<<' ';
        fout<<'\n';
    }
}
int main(){
    fin>>n;
    Bkt(0);
    fout<<rez<<'\n';
    return 0;
}
void Bkt(short x){
    short i;
    if(x==n){
        --x;
        if(!afisare){
            afisare=1;
            Afis();
        }++rez;
        return;
    }
//    AfisareM();fout<<'\n';
    for(i=0;i<n;++i){
        while(i<n&&Coloana[i])++i;
        if(i==n)break;
        if(M[x][i]==0){
            Coloana[i]=1;
            Fill(x,i,1);
            M[x][i]=2;
            Bkt(x+1);
            Fill(x,i,0);
            Coloana[i]=0;
            M[x][i]=0;
        }
    }
}
void Fill(short a,short b,bool x){
    short ca=a,cb=b;
    while(a<n&&b>=0){
        M[a][b]=x;
        ++a,--b;
    }a=ca,b=cb;
    while(a<n&&b<n){
        M[a][b]=x;
        ++a,++b;
    }
}
void Afis(){
    int i,j;
    for(i=0;i<n;++i){
        for(j=0;j<n;++j){
            if(M[i][j]==2){
                fout<<j+1<<' ';
                break;
            }
        }
    }fout<<'\n';
}
