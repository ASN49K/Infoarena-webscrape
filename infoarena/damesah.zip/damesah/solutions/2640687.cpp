#include <bits/stdc++.h>
using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

stack<int> s;
vector<bool> c, dp, ds;

bool check(int i, int j, int n)
{
    if(i==3&&j==2)
    {

        cout<<"";


    }
    if(c[j] || dp[j-i+n] || ds[i+j-1])
        return 0;
    c[j]=dp[j-i+n]=ds[i+j-1]=1;
    return 1;
}

void print_stack(stack<int> x)
{
    if(x.size()==1)
    {
        g<<x.top()<<' ';
        return;
    }
    int aux=x.top();
    x.pop();
    print_stack(x);
    x.push(aux);
    g<<aux<<' ';
}

void solve(int n)
{
    int sol=0;
    bool found=0;
    c.resize(n+1, 0);
    dp.resize(2*n, 0);
    ds.resize(2*n, 0);
    s.push(0);
    while(s.size())
    {
        if(s.top())
            c[s.top()]=dp[s.top()-s.size()+n]=ds[s.size()+s.top()-1]=0;
        int j=s.top()+1;
        while(j<=n && !check(s.size(), j, n))
            j++;
        if(j<=n)
        {
            s.pop();
            s.push(j);
            if(s.size()<n)
                s.push(0);
            else
            {
                if(!found)
                {
                    found=1;
                    print_stack(s);
                    g<<'\n';
                }
                sol++;
            }
        }
        else
            s.pop();
    }
    g<<sol;
}

int main()
{
    int n;
    f>>n;
    solve(n);
    f.close();
    g.close();
    return 0;
}
