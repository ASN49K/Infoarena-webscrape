#include<fstream>
using namespace std;
ifstream F("damesah.in");
ofstream G("damesah.out");
int m;
short d[13],n;
bool a[13],b[25],c[25];
void A(int k)
{
    int i;
    if(k==n) {
        if(m<1) {
            for(i=0;i<n;G<<1+d[i++]<<' ');
            G<<'\n';
        }
        ++m;
    } else
        for(i=0;i<n;++i)
            if(a[i]+b[i+k]+c[n-1+i-k]==0)
                d[k]=i,a[i]=b[i+k]=c[n-1+i-k]=1,A(k+1),a[i]=b[i+k]=c[n-1+i-k]=0;
}
int main()
{
    return F>>n,A(0),G<<m,0;
}
