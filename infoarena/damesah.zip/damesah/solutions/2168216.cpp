#include <fstream>
#include <cmath>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int v[16];
int fr[17];
int d1[100];
int d2[100];

int con=0,n,a1;

void bkt(int a1)
{
    if(a1==n+1)
    {
        con++;
        if(con==1)
        {
            for(int i=1;i<=n;i++)
            {
                 fout<<v[i]<<" ";
            }
            fout<<endl;
        }
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            if(fr[i]==0&&d1[i+a1]==0&&d2[i-a1+n-1]==0)
            {
                v[a1]=i;
                fr[i]=d1[i+a1]=d2[i-a1+n-1]=1;
                bkt(a1+1);
                fr[i]=d1[i+a1]=d2[i-a1+n-1]=0;
            }
        }
    }
}

int main()
{
    fin>>n;
    bkt(1);
    fout<<con;
    return 0;
}
