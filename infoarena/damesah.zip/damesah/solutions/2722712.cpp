#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

int v[15];

int n, sol;

void afisare()
{
    for(int i=1; i<=n; i++)
    {
        cout<<v[i]<<' ';
    }
    cout<<'\n';
}

bool valid(int x)
{
    for(int i=1; i<x; i++)
    {
        if((abs(v[x] - v[i]) == x - i) || (v[x] == v[i]))
            return 0;
    }
    return 1;
}

int backtr(int x)
{
    for(int i=1; i<=n; i++)
    {
        v[x] = i;
        if(valid(x))
        {
            if(x == n)
            {
                if(!sol)
                    afisare();
                sol++;
            }
            else
            {
                backtr(x+1);
            }
        }
    }
}

int main()
{
    fin>>n;
    backtr(1);
    fout<<sol;
    fin.close();
    fout.close();
    return 0;
}
