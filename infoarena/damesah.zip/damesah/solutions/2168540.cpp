#include <iostream>
#include <fstream>

using namespace std;

struct graf
{
    int kezd, veg;
};


int n, m;
graf x[100001];
bool nod[50001];
int er[50001];
int k = 0;

void dfs(int node)
{

    for(int i = 0 ; i < m; ++i)
    {
        if(x[i].kezd == node)
        {
            if(nod[x[i].veg] == 0)
            {
                dfs(x[i].veg);
            }
        }
    }
    //cout << node << endl;
    nod[node] = 1;
    er[k++] = node;
}

void topologicalsort()
{
    for(int i = 1 ; i <= n; ++i)
    {
        if(nod[i] == 0)
            dfs(i);
    }
}

int main()
{
    ifstream fin("sortaret.in");
    ofstream fout("sortaret.out");
    fin >> n >> m;
    for(int i = 0; i < m; ++i)
    {
        fin >> x[i].kezd >> x[i].veg;
    }

    topologicalsort();

    for(int i = k-1 ; i >= 0; --i)
    {
        fout << er[i] << " ";
    }
    return 0;
}
