#include <bits/stdc++.h>
using namespace std;

ifstream fin ("damesah.in");
ofstream fout("damesah.out");

const int dim=15;

int n,sol[dim],ok,cnt;
bool st[dim],dr[dim], fv[dim];

void afisare(){
    cnt++;
    if(!ok){
        for(int i=1;i<=n;i++){
            fout<<sol[i]<<' ';
        }
            fout<<'\n';
        ok=1;
    }
}

void backtracking(int pas){
    for(int i=1;i<=n;i++){
        if(!fv[i]&&!st[i-pas+n]&&!dr[pas+i]){
            fv[i]=st[i-pas+n-1]=dr[pas+i]=1;
            sol[pas]=i;
            if(pas==n){
                afisare();
            }
            else{
                backtracking(pas+1);
            }
            fv[i]=st[i-pas+n-1]=dr[pas+i]=0;
        }
    }
}

signed main(){
    fin>>n;
    backtracking(1);
    fout<<cnt;
}
