#include<fstream>
using namespace std;
int sol[100], nr;
int viz[100];
int n;

ifstream f("damesah.in");
ofstream g("damesah.out");

void back(int k)
{
	for (int i = 1; i <= n; i++)
	{
		if (!viz[i])
		{
			
			int ok = 1;
			for (int i = 1; i < k; i++)
				if (abs(k - i) == abs(sol[k] - sol[i]))
				{
					ok = 0;
					break;
				}
			if (ok)
			{
				sol[k] = i;
				viz[i] = 1;
				if (k == n)
				{
					nr++;
					if (nr == 1)
					{
						for (int i = 1; i <= n; i++)
							g << sol[i] << ' ';
						g << '\n';
					}
				}
				else
					back(k + 1);
				viz[i] = 0;

			}
		}
	}
}

int main()
{
	ios_base::sync_with_stdio(false);
	f.tie(0);
	g.tie(0);
	f >> n;
	back(1);
	g << nr;
}