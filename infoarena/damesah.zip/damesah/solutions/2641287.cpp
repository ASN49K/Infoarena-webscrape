#include <fstream>

using namespace std;

ifstream fin ("damesah.in");
ofstream fout ("damesah.out");

int n, c[14], nd;
bool col[14], diagp[14], diags[14];

void afisol () {
  for (int i = 1; i <= n; i++)
    fout << c[i] << ' ';
  fout << '\n';
}

void bkt (int l) {
  if (l == n + 1) {
    nd++;
    if (nd == 1)
      afisol ();
  }
  for (int i = 1; i <= n; i++)
    if (not col[i] and not diagp[i - l + n] and not diags[l + i]) {
      c[l] = i;
      col[i] = diagp[i - l + n] = diags[l + i] = true;
      bkt (l + 1);
      col[i] = diagp[i - l + n] = diags[l + i] = false;
    }
}

int main()
{
  fin >> n;
  bkt (1);
  fout << nd;
  return 0;
}
