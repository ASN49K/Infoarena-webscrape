#include <fstream>

using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");

bool frec[100] = {0}, sem = false;

bool valid(int st[], int k)
{
    if(frec[st[k]])
        return false;
    for(int i = 1; i < k; i++)
        if(((k - i) == (st[k] - st[i])) || ((k - i) == (st[i] - st[k])))
            return false;
    return true;
}

void print(int st[], int n)
{
    for(int i = 1; i <= n; i++)
        fout << st[i] << ' ';
    fout << '\n';
}

int permutari(int st[], int n)
{
    int k = 1, ct = 0;
    st[k] = 0;
    while(k > 0)
        if(st[k] < n)
        {
            st[k]++;
            if(valid(st, k))
            {
                frec[st[k]] = 1;
                if(k == n)
                {
                    frec[st[k]] = 0;
                    if(ct == 0)
                        print(st, n);
                    ct++;
                    sem = true;
                }
                else
                    st[++k] = 0;
            }
        }
        else
        {
            k--;
            frec[st[k]] = 0;
        }
    return ct;
}

int main()
{
    int stiva[100] = {0}, n;
    fin >> n;
    fout << permutari(stiva, n);
    return 0;
}
