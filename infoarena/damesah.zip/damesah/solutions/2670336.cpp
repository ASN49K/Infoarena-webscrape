#include <fstream>

using namespace std;
const int NMAX = 13;

int N, x[NMAX + 1], nrSol;
bool C[NMAX + 1], dP[2 * NMAX], dS[2 * NMAX];

ifstream f("damesah.in");
ofstream g("damesah.out");

void afis()
{
    for(int i = 1; i <= N; i++)
        g << x[i] << ' ';
    g << '\n';
}



void backt()
{
    int k=1;
    while(k>0)
        if(x[k]<N)
        {
            x[k]++;
            if(C[x[k]]==0&&dP[N-k+x[k]]==0&&dS[k+x[k]-1]==0)
            {
                C[x[k]]=dP[N-k+x[k]]=dS[k+x[k]-1]=1;
                if(k==N)
                {
                    if(nrSol==0)afis();
                    nrSol++;
                    C[x[k]]=dP[N-k+x[k]]=dS[k+x[k]-1]=0;
                    k--;
                    C[x[k]]=dP[N-k+x[k]]=dS[k+x[k]-1]=0;
                }
                else
                    x[++k]=0;
            }
        }
        else
        {
            k--;
            C[x[k]]=dP[N-k+x[k]]=dS[k+x[k]-1]=0;
        }
}

int main()
{
    f >> N;
    backt();
    g << nrSol;
    return 0;
}
