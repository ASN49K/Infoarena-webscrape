#include <bits/stdc++.h>

using namespace std;

ifstream fin ("damesah.in");
ofstream fout ("damesah.out");

void usain_bolt()
{
    ios::sync_with_stdio(false);
    fin.tie(0);
}

int ans[25], sols, n;
bool f[25];

bool check(int n)
{
    if(f[ans[n]] == true) {
        return false;
    }
    for(int i = 1; i < n; ++i) {
        if(n - i == abs(ans[n] - ans[i])) {
            return false;
        }
    }
    return true;
}

void solve(int k)
{
    for(int i = 1; i <= n; ++i) {
        ans[k] = i;
        if(check(k) == true) {
            f[i] = true;
            if(k < n) {
                solve(k + 1);
            }
            else {
                ++sols;
                if(sols == 1) {
                    for(int j = 1; j <= n; ++j) {
                        fout << ans[j] << " ";
                    }
                    fout << "\n";
                }
            }
            f[i] = false;
        }
    }
}
int main()
{
    usain_bolt();

    fin >> n;
    solve(1);
    fout << sols << "\n";
    return 0;
}
