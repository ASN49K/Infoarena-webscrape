#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n, sol;
int tabla[15];
bool c[15], pd[30], sd[30];

void afisare() {
    for (int i = 1; i <= n; ++i) fout << tabla[i] << " ";
    fout << "\n";
}

void generare(int i) {
    if (i == n + 1) {
        sol++;
        if (sol == 1) afisare();
        return;
    }

    for (int j = 1; j <= n; ++j) {
        int pdiag = (i - j + n);
        int sdiag = (n - i + 1) - j + n;
        if (!c[j] && !pd[pdiag] && !sd[sdiag]) {
            c[j] = pd[pdiag] = sd[sdiag] = true;
            tabla[i] = j;
            generare(i + 1);
            c[j] = pd[pdiag] = sd[sdiag] = false;
        }
    }
}

int main()
{
    fin >> n;
    generare(1);
    fout << sol;

    return 0;
}
