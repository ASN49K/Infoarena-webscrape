#include <bits/stdc++.h>
using namespace std;

string file = "damesah";
ifstream fin(file + ".in");
ofstream fout(file + ".out");

int v[40], n;
bool col[40], *d1, *d2;
bool afis = false;

int back(int k) {

    if (n + 1 == k) {

        if (!afis) {

            afis = true;
            for (int i = 1; i <= n; i++)
                fout << v[i] << ' ';
            fout << '\n';
        }

        return 1;
    }

    int ret = 0;

    for (int i = 1; i <= n; i++) {

        if (col[i] || d1[k - i] || d2[i + k])
            continue;

        v[k] = i;
        col[i] = d1[k - i] = d2[i + k] = true;
        ret += back(k + 1);
        col[i] = d1[k - i] = d2[i + k] = false;
    }

    return ret;
}

int main() {

    fin >> n;
    d1 = new bool[80];
    d1 += 40;
    d2 = new bool[40];
    d2 += 40;

    int res = back(1);
    fout << res;

    return 0;
}
