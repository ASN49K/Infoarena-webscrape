#include <bits/stdc++.h>

using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int n, st[15], viz[15], top, sol[15], nr;
int check(int top, int i)
{
    if(viz[i])
        return false;
    for(int j = 1; j < top; ++j)
        if(abs(j - top) == abs(st[j] - i))
            return false;
    return true;
}
void Back(int top)
{
    int i;
    if(top == n + 1)
    {
        if(!nr)
        {
            for(i = 1; i < top; ++i)
                sol[i] = st[i];
            nr++;
        }
        else
            nr++;
    }
    else
        for(i = 1; i <= n; ++i)
            if(check(top, i))
            {
                viz[i] = 1;
                st[top] = i;
                Back(top + 1);
                viz[i] = 0;
            }
}
int main()
{
    fin >> n;
    Back(1);
    for(int i = 1; i <= n; ++i)
        fout << sol[i] << " ";
    fout << "\n" << nr;
    return 0;
}
