#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

ifstream in("damesah.in");
ofstream out("damesah.out");

int x[11], n;
bool show=1;
int c;

bool ok(int k)
{
    for(int i=1; i<k; i++)
        if(x[i]==x[k] || x[i]+k-i==x[k] || x[i]-k+i==x[k]) return 0;
    return 1;
}

bool sol(int k)
{
    if(k==n) return 1;
    return 0;
}

void afisare(int k)
{
    ++c;
    if(!show) return;
    for(int i=1; i<=k; i++) out<<x[i]<<' ';
    show=0;
}

void Back(int k)
{
    for(int i=1; i<=n; i++)
    {
        x[k]=i;
        if(ok(k))
        {
            if(sol(k)) afisare(k);
            else Back(k+1);
        }
    }
}

int main()
{
    in>>n;
    if(n<=10) Back(1);
    out<<'\n'<<c;
    return 0;
}
