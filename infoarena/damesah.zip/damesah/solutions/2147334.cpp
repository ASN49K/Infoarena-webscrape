#include <cstdio>
#include <cmath>

using namespace std;

int n,cnt,sol[15];
bool used[15];

bool valid(int k)
{
    for(int i=1; i<k; i++)
    {
        if(sol[k]==sol[i] || abs(sol[k]-sol[i])==abs(k-i)) return false;
    }
    return true;
}

int backtracking(int n)
{
    int k=1,cnt=0;
    bool prima=1, ok;

    sol[k]=0;
    while(k>0)
    {
        ok=0;
        while(sol[k]<n&&!ok)
        {
            sol[k]++;
            ok=valid(k);
        }
        if(!ok)
        {
            k--;
        }
        else
        {
            if(k == n)
            {
                if(prima)
                {
                    prima=0;
                    for(int i=1; i<=n; i++)
                    {
                        printf("%d ", sol[i]);
                    }
                    printf("\n");
                }
                cnt++;
            }
            else
            {
                k++;
                sol[k]=0;
            }
        }
    }
    return cnt;
}

int main()
{
    freopen("damesah.in", "r", stdin);
    freopen("damesah.out", "w", stdout);
    scanf("%d", &n);
    printf("%d\n", backtracking(n));
    return 0;
}
