#include <bits/stdc++.h>

using namespace std;

ifstream fin ("dame.in");
ofstream fout ("dame.out");


int a[20] , n, cnt;

void Print(int top)
{
    cnt++;
    if(cnt == 1)
    {
        for(int i = 1; i <= n ; i++, fout<<"\n")
            fout<<i<<" "<<a[i];
    }
}

int Check(int top)
{
    for(int i = 1; i < top; i++)
    {
        if(a[i] == a[top]) return 0;
        if(abs(i-top) == abs(a[i]- a[top])) return 0;
    }
    return 1;
}

void Back()
{
    int cand, top;
    top = 1;
    a[top] = 0;
    while(top > 0)
    {
        cand = 0;
        while(cand == 0 && a[top] < n)
        {
            a[top]++;
            cand = Check(top);
        }
        if(cand == 0) top--;
        else if(top == n) {Print(top); return;}
            else a[++top] = 0;

    }
}

int main()
{
    fin>>n;
    Back();
    fout<<cnt;
    return 0;
}
