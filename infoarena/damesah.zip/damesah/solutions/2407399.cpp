#include <iostream>

#include<fstream>
using namespace std;
ifstream in("damesah.in");
ofstream out("damesah.out");
bool mat[13][13];
bool lines[13];
bool diagonala1[200],diagonala2[200];
int n;
void read()
{
    in>>n;
    n=13;
}
bool is_inside(int x,int y)
{
    return x>=0 && x<n && y>=0 &&y<n;
}
int get_diagonala1(int line,int column)
{
    return line-column+n-1;

}
int get_diagonala2(int line,int column)
{
    return line+column+1;

}
bool is_ok(int line,int column)
{
    int x1=column,y=line;
    int diagonala1x=get_diagonala1(line,column);
    int diagonala2x=get_diagonala2(line,column);
    if(diagonala1[diagonala1x] || diagonala2[diagonala2x]||lines[line])
        return false;
    return true;
}
int dame[14];
int i=0;
bool already_found=false;
void backtrack(int column)

{
    if(column==n)
    {
        i++;
        if(!already_found)
        {
            for(int i=0; i<column; i++)

                out<<dame[i]+1<<" ";
            already_found=true;
        }
        return;
    }
    bool found=false;
    for(int i=0; i<n; i++)
    {
        if(is_ok(i,column))
        {
            found=true;
            mat[i][column]=1;
            lines[i]=1;
            dame[column]=i;
            diagonala1[get_diagonala1(i,column)]=1;
            diagonala2[get_diagonala2(i,column)]=1;
            backtrack(column+1);
            mat[i][column]=0;
            diagonala1[get_diagonala1(i,column)]=0;
            diagonala2[get_diagonala2(i,column)]=0;
            lines[i]=0;
        }
    }
    if(!found)

        return;
}

int main()

{

    read();
    backtrack(0);
    out<<endl<<i;
    return 0;

}
