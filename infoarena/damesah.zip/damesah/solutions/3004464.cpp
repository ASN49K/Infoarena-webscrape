#include <fstream>
#include <cmath>
using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int x[20],n,i,p;
bool gasit=0;
int OK(int k)
{
    int i;
    for(i=1;i<k;i++)
        if(x[k]==x[i]||k-i==abs(x[i]-x[k]))
            return 0;
    return 1;
}
void afis()
{
   for(i=1;i<=n;i++)
           g<<x[i]<<" ";

}
void back(int k)
{
    if(gasit>=0)
    {
    int i;
    for(i=1;i<=n;i++)
    {
        x[k]=i;
        if(OK(k))
            if(k==n)
            {p++;
            if(p==1)
                afis();

                gasit=1;
            }
            else
                back(k+1);
    }
    }
}
int main()
{
    f>>n;
    back(1);
    g<<'\n';
    g<<p;
    return 0;
}
