///de continuat
#include<fstream>
using namespace std;
int x[50],m[20][20],n,i,j;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
void zero(int n){
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
        m[i][j]=0;
}
void marcare(int i, int j)
{
    int ci,cj;
    ci=i;
    cj=j;
    while(ci!=0 && cj!=0){
        m[ci][cj]=1;
        ci--;
        cj--;
    }
    ci=i;
    cj=j;
    while(ci!=0 && cj<=n){
        m[ci][cj]=1;
        ci--;
        cj++;
    }
    ci=i;
    cj=j;
    while(ci<n && cj!=0){
        m[ci][cj]=1;
        ci++;
        cj--;
    }
    ci=i;
    cj=j;
    while(ci<=n && cj<=n){
        m[ci][cj]=1;
        ci++;
        cj++;
    }
}

void back(int k){
    if(k==n+1){
            zero(n);
        for(int i=1;i<=n;i++){
            fout<<x[i]<<" ";
        }
        fout<<"\n";
    }
    else{
        for(int i=x[k-1]+1;i<=n;i++){
                if(m[k][i]==0){
                    x[k] = i;
                    marcare(k,i);
                    back(k+1);
                }
        }
    }
}
int main(){
fin>>n;
/*marcare(5,3);
for(i=1;i<=n;i++){
    for(j=1;j<=n;j++)
        fout<<m[i][j];
fout<<"\n";
} */
back(1);
return 0;
}

