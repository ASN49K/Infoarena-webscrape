#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

long long n,k,af[15],a[15][15];
bool ok,l[15];

void diag(int i, int j, int v)
{
    int di[]={-1,-1,1,1};
    int dj[]={-1,1,-1,1};
    for (int d=0;d<4;d++)
    {
        int x=i+di[d];
        int y=j+dj[d];
        while (x>=1 && x<=n && y>=1 && y<=n)
        {
            a[x][y]+=v;
            x=x+di[d];
            y=y+dj[d];
        }
    }
}

void backt(int c)
{
    if (c==n+1)
    {
        k++;
        if (ok==0)
        {
            ok=1;
            for (int i=1;i<=n;i++) fout << af[i] << " ";
            fout << "\n";
        }
    }
    else
    {
        for (int i=1;i<=n;i++) if (a[i][c]==0 && l[i]==0)
        {
            af[c]=i;
            int v=(i-1)*n+c;
            diag(i,c,v);
            l[i]=1;
            backt(c+1);
            v*=-1;
            diag(i,c,v);
            l[i]=0;
        }
    }
}

int main()
{
    fin >> n;
    backt(1);
    fout << k;

    return 0;
}
