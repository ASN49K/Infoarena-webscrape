#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

int n,x[14],nrsol;

ifstream f("damesah.in");
ofstream g("damesah.out");

bool valid(int k)
{
    for(int i=1; i<k; i++)
        if(x[i]==x[k]||k-i==abs(x[k]-x[i]))
            return 0;
    return 1;
}

void afis()
{
    nrsol++;
    if(nrsol==1)
    {
        for(int i=1; i<=n; i++)
            g<<x[i]<<' ';
        g<<'\n';
    }
}

void bt()
{
    int k=1;
    x[1]=0;
    while(k>0)
        if(x[k]<n)
        {
            x[k]++;
            if(valid(k))
                if(k==n)
                    afis();
                else
                    x[++k]=0;
        }
        else
            k--;
}



int main()
{
    f>>n;
    bt();
    g<<nrsol;
    return 0;
}
