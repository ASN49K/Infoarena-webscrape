#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;
ifstream in("damesah.in");
ofstream out("damesah.out");
void solve(int n, int &nr, int y, vector<int> aleg, vector<int> amvazut){
    if (y == n){
        nr += 1;
        if (nr == 1){
            for (int i = 0; i < n; i++)
                    out<< aleg[i] << " ";
            out<< "\n";
        }
    }
    else{
        for (int i = 1; i <= n; i++){
            bool ok = 0;

            aleg[y] = i;
            amvazut[aleg[y]]++;
            if (amvazut[aleg[y]] <= 1){
                    for (int j = 0; j < y; j ++){
                        int s1 = j + 1 + aleg[j], s2 = y + 1 + aleg[y];
                        int dif1 = abs(j + 1 - aleg[j]), dif2 = abs(y + 1 - aleg[y]);
                        if (s1 == s2)
                            ok = 1;
                        else
                            if (dif1 == dif2){
                                if ((j + 1 >= aleg[j] && y + 1 >= aleg[y]) || (j + 1 < aleg[j] && y + 1 < aleg[y]))
                                    ok = 1;
                            }
                    }
                    if (ok == 0)
                        solve(n, nr, y + 1, aleg, amvazut);
            }
            amvazut[aleg[y]] -= 1;
        }
    }
}
int main()
{
    int n, y = 0, nr = 0;

    in>> n;
    vector<int> amvazut(n + 1, 0), aleg(n, 0);

    solve(n, nr, y, aleg, amvazut);
    out<< nr;
    return 0;
}
