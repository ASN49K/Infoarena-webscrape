#include <fstream>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int n,a[15],b[15],v[15],sol,ok;
int modul(int x){
    if(x<0)return -x;
    return x;
}
int verif(int k){
    for(int i=1;i<k;i++)
        if(k-i==modul(a[k]-a[i]))return 0;
    return 1;
}
void bk(int k){
    if(k==n+1){
        sol++;
        if(!ok){
            for(int i=1;i<=n;i++)
                v[i]=a[i];
            ok=1;
        }
        return;
    }
    for(int i=1;i<=n;i++)
        if(!b[i]){
            b[i]=1;
            a[k]=i;
            if(verif(k))
               bk(k+1);
            b[i]=0;
        }
}
int main(){
    fin>>n;
    bk(1);
    for(int i=1;i<=n;i++)
        fout<<v[i]<<" ";
    fout<<"\n"<<sol;
    return 0;
}
