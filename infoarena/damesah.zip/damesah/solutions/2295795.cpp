#include <fstream>
//#include <iostream>
#define LMAX 15

using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");


int n;
int sol[LMAX];
int col[LMAX];
bool dpr[2*LMAX], dsc[2*LMAX]; //diagonalele principale/secundare
int diagp[LMAX][LMAX], diags[LMAX][LMAX]; //lene sa calculez formule
int af;
bool flag;

void bkt(int k)
{
    if (k-1==n)
    {
        af++;
        if (!flag)
        {
            flag = true;
            for (int i=1;i<=n;i++)
            {
                fout<<sol[i]<<' ';
            }
            fout<<'\n';
        }
        return;
    }
    for (int i=1;i<=n;i++)
    {
        if (!col[i])
        {
            // vad daca pe diagonala se va intersecta cu vreo dama
            int dpract = diagp[k][i], dscact = diags[k][i];
            if (dpr[dpract] || dsc[dscact])
            {
                continue;
            }
            col[i] = true;
            dpr[dpract] = true;
            dsc[dscact] = true;
            sol[k] = i;
            bkt(k+1);
            dpr[dpract] = false;
            dsc[dscact] = false;
            col[i] = false;
        }
    }
}

void precalc()
{
    int nr = 0;
    for (int i = 1;i<=n;i++)
    {
        nr++;
        for (int j = 1, k = i; k<=n; ++k, ++j)
        {
            diagp[j][k] = nr;
            diags[j][n-k+1] = nr;
        }
    }
    for (int i=2;i<=n;i++)
    {
        nr++;
        for (int j=i, k=1; j<=n;++k, ++j)
        {
            diagp[j][k] = nr;
            diags[j][n-k+1] = nr;
        }
    }
    /*for (int i=1;i<=n;i++)
    {
        for (int j=1;j<=n;j++)
        {
            cout<<diagp[i][j]<<' ';
        }
        cout<<'\n';
    }
    cout<<'\n';
    for (int i=1;i<=n;i++)
    {
        for (int j=1;j<=n;j++)
        {
            cout<<diags[i][j]<<' ';
        }
        cout<<'\n';
    }*/
}

int main()
{
    fin>>n;
    precalc();
    bkt(1);
    fout<<af<<'\n';
    return 0;
}
