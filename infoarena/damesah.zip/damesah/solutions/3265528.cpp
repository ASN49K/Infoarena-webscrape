#include <fstream>
using namespace std;

ifstream cin("damesah.in");
ofstream cout("damesah.out");

int v[13],rasp[13];

bool vf(int a){
    int i;
	for(i=1;i<a;i++)
		if((a-i==abs(v[a]-v[i])) || (v[a]==v[i])){
			return 0;
	}
	return 1;
}


int main()
{
    int n,poz=1,cntsol=0,stg=1,i;
    cin>>n;
    while(poz){
        do{
            v[poz]++;
        }while(v[poz]<n && !vf(poz));
        if(v[poz]>n ||!vf(poz)){
            poz--;
        }else{
            if(poz==n){
                if(stg){
                    stg=0;
                    for(i=1;i<=n;i++) {
                        rasp[i]=v[i];
                    }
                }
                cntsol++;
            }else{
                poz++;
                v[poz]=0;
            }
        }
    }
    for(i=1;i<=n;i++) cout<<rasp[i]<<" ";
    cout<<"\n"<<cntsol;
    return 0;
}
