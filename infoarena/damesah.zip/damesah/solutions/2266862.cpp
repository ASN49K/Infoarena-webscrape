#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n;
bitset < 40 > col, md, sd;
int rez[20];
int cer;

void bkt(int x) {
    if(x == n + 1) {
        if(cer == 0) {
            for(int i = 1; i <= n; i++) {
                fout << rez[i] << " ";
            }
            fout << '\n';
        }
        cer++;
    } else {
        for(int i = 1; i <= n; i++) {
            if(!col[i] && !md[n + i - x] && !sd[n - x - i + 1]) {
                rez[x] = i;
                col[i] = md[n + i - x] = sd[n - x - i + 1] = true;
                bkt(x + 1);
                col[i] = md[n + i - x] = sd[n - x - i + 1] = false;
            }
        }
    }
}

int main() {
    fin >> n;
    bkt(1);
    fout << cer;
}
