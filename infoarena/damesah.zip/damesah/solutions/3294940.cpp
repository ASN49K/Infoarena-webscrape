#include <iostream>
#include <cmath>
#include <fstream>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

int n,x[50], nrsol;
bool ok=0;

bool valid(int k)
{
    for(int i=1 ; i<k ; i++)
        if(x[k] == x[i]  || abs(x[k]-x[i]) == k-i)
            return 0;
    return 1;

}

void afis()
{
    nrsol++;
    if (!ok)
    {
        for (int i = 1; i <= n; i++)
            g << x[i] << ' ';
        g << '\n';
        ok = 1;
    }
}

void backt(int k)
{
    if(k <= n)
        for(int v=1 ; v<=n ; v++)
        {
            x[k]=v;
            if(valid(k))
                backt(k+1);
        }
    else
        afis();
}

int main()
{
    f>>n;
    backt(1);
    g<<'\n'<<nrsol;

    f.close();
    g.close();
    return 0;
}
