#include <fstream>
using namespace std;
ifstream fin ("damesah.in");
ofstream fout ("damesah.out");
#define NMAX 20

int v[NMAX], n, total, sol[NMAX];
bool u[NMAX];

int modul(int a) {
    if(a < 0)
        return (-1) * a;
    return a;
}

void Back(int k) {
    int i;
    bool verif;
    for(i=1; i<=n; i++) {
        if(!u[i]) {
            verif = true;
            for(int j=1; j<k; j++)
                if(modul(i - v[j]) == modul(k - j))
                    { verif = false; break; }
            if(verif) {
                u[i] = true;
                v[k] = i;

                if(k == n) {
                    if(!total)
                        for(int j=1; j<=n; j++)
                            sol[j] = v[j];

                    total++;
                } else Back(k + 1);

                u[i] = false;
            }
        }
    }
}

int main()
{
    fin >> n;

    Back(1);

    if(total) {
        for(int i=1; i<=n; i++)
            fout << sol[i] << " ";
        fout << endl << total;
    }

    return 0;
}
