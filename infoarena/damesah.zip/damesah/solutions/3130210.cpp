#include<bits/stdc++.h>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int n,st[12],sol,fv[12];

void afis()
{
    sol++;
    if(sol==1)
    {
        int i;
        for(i=1;i<=n;i++)
            fout<<st[i]<<" ";
        fout<<'\n';
    }
}

bool solutie(int p)
{
    if(p==n)
        return 1;
    return 0;
}

int modul(int x)
{
    if(x<0)
        return 0-x;
    return x;
}

bool valid(int p)
{
    int i;
    for(i=1;i<=p-1;i++)
    if(modul(i-p)==modul(st[i]-st[p]))//i si p se ataca pe diagonala
        return 0;
    return 1;
}

void bk(int p)
{
    int i;
    for(i=1;i<=n;i++)
    if(fv[i]==0)//daca coloana i nu este ocupata
    {
        st[p]=i;
        fv[i]=1;
        if(valid(p))
        {
            if(solutie(p))
                afis();
            else
                bk(p+1);
        }
        fv[i]=0;
    }
}

int main()
{
    fin>>n;
    bk(1);
    fout<<sol;
    return 0;
}
