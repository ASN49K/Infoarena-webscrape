#include <bits/stdc++.h>
using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n, sol[15], rs;
bool col[15], diag1[30], diag2[30]; // diag1: i-j+n; diag2: i+j-1

void back(int k) {
    if(k == n + 1) {
        rs++;
        if(rs == 1) {
            for(int i = 1; i <= n; i++)
                fout << sol[i] << ' ';
            fout << '\n';
        }
        return;
    }

    for(int j = 1; j <= n; j++) {
        if(!col[j] && !diag1[k - j + n] && !diag2[k + j - 1]) {
            sol[k] = j;
            col[j] = diag1[k - j + n] = diag2[k + j - 1] = true;
            back(k + 1);
            col[j] = diag1[k - j + n] = diag2[k + j - 1] = false;
        }
    }
}

int main() {
    fin >> n;
    back(1);
    fout << rs << '\n';
    return 0;
}
