#include <bits/stdc++.h>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n;
int nrsol=0;
int v[15][15];
int lin[15];
int col[15];
int diag1[31];
int diag2[31];
int sol[15];

void bkt(int l)
{
    if(l==n+1)
    {
        if(nrsol<1)
        {
            for(int i=1; i<=n; i++)
            {
                fout<<sol[i]<<" ";
            }
            fout<<"\n";
        }
        nrsol++;
        return;
    }
    else
    {
        for(int c=1; c<=n; c++)
        {
            if(col[c]==0 && diag1[n-c+l]==0 && diag2[c+l]==0){
                sol[l]=c;
                col[c]=diag1[n-c+l]=diag2[l+c]=1;
                bkt(l+1);
                col[c]=diag1[n-c+l]=diag2[c+l]=0;
            }
        }
    }
}

int main()
{
    fin>>n;
    bkt(1);
    fout<<nrsol;
    return 0;
}
