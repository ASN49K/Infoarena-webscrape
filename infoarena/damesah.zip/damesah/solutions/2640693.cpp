#include <bits/stdc++.h>
using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

vector<int> v;
vector<bool> c, dp, ds;

inline bool check(int i, int j, int n)
{
    if(c[j] || dp[j-i+n] || ds[i+j-1])
        return 0;
    c[j]=dp[j-i+n]=ds[i+j-1]=1;
    return 1;
}

inline void solve(int n)
{
    int sol=0, i=1;
    bool found=0;
    v.resize(n+1);
    c.resize(n+1, 0);
    dp.resize(2*n, 0);
    ds.resize(2*n, 0);
    v[i]=0;
    while(i)
    {
        int j=v[i];
        if(j)
            c[j]=dp[j-i+n]=ds[i+j-1]=0;
        j++;
        while(j<=n && !check(i, j, n))
            j++;
        if(j<=n)
        {
            v[i]=j;
            if(i<n)
                v[++i]=0;
            else
            {
                if(!found)
                {
                    found=1;
                    for(int p=1; p<v.size(); p++)
                        g<<v[p]<<' ';
                    g<<'\n';
                }
                sol++;
            }
        }
        else
            i--;
    }
    g<<sol;
}

int main()
{
    int n;
    f>>n;
    solve(n);
    f.close();
    g.close();
    return 0;
}
