#include <fstream>
#include <bitset>
#define DIM 40
using namespace std;
int x[DIM/2];
bitset<DIM> f,p,s;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int n,sol;
void bt(int k) {
    if (k>n) {
        sol++;
        if (sol==1) {
			for (int i=1;i<=n;i++)
				fout<<x[i]<<" ";
			fout<<"\n";
        }
        return;
    }
    for (int i=1;i<=n;i++) {
        x[k]=i;
        if (p[n+i-k]==0&&s[i+k]==0&&f[i]==0) {
			f[i]=1, p[n+i-k]=1, s[i+k]=1;
			bt(k+1);
			f[i]=0, p[n+i-k]=0, s[i+k]=0;
        }
    }
}
int main() {
    fin>>n;
    bt(1);
    fout<<sol;
    return 0;
}
