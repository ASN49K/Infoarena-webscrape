#include<iostream>
#include<cmath>
#include<cstdio>
FILE * f=fopen("damesah.in","r");
FILE * g=fopen("damesah.out","w");
#define nmax 14
using namespace std;
int n,nrsol,c[nmax];
void afisare();
void regina(int k);
int main()
{
    int i,j;
     fscanf(f,"%d",&n);
    regina(1);
    fprintf(g,"\n");
    fprintf(g,"%d",nrsol);
    return 0;
}


void afisare()
{
    int i,j;
    cout<<"soulutia"<<" "<<++nrsol<<endl;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            if(c[i]==j)
                cout<<"*";
            else
                cout<<"o";
        }
        cout<<endl;
    }
    cout<<endl;
    if(nrsol==1)
    {
        for(i=1;i<=n;i++)
            fprintf(g,"%d ",c[i]);
    }
}
void regina(int k)
{ int i,j,ok;
    if(k==n+1)
        afisare();
    else
        for(i=1;i<=n;i++)
    {
        for(ok=1,j=1;j<k;j++)
            if(c[j]==i || abs(c[j]-i)==k-j)
            ok=0;
            if(ok)
            {
                c[k]=i;
                regina(k+1);

            }
    }



}
