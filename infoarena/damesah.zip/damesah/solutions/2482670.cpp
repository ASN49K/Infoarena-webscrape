#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;
int v[100],k,n,i,nr;

ifstream f("damesah.in");
ofstream g("damesah.out");
int valid(int k)
{   if(k==1)
    return 1;
    for(i=1; i<k; i++)
    {
        if(v[i]==v[k])
            return 0;
        if((abs(v[k]-v[i]))==k-i)
            return 0;


    }
     return 1;
}
int solutie(int k)
{
    if(k==n)
    return 1;

    return 0;
}
void afisare()
{

if(nr==0)
     {for(i=1; i<=k; i++)
        g<<v[i]<<" ";
        g<<endl;
     }
nr++;
    }
int main()
{
    k=1;
    f>>n;
   while(k>0)
   {

    do

        v[k]++;
    while((valid(k)==0));



    if(v[k]<=n)
    {
        if (solutie(k))
            afisare();
        else
        {k++;
        v[k]=0;
        }

    }
    else
    {
        k--;
    }
   }


g<<nr;

    return 0;
}
