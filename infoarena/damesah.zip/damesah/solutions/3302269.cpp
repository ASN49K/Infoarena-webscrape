#include <bits/stdc++.h>
#define cin fin
#define cout fout
using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n, d[14];
bool col[14], diag1[30], diag2[30];
int ans = 0;

void gen(int i) {
    if (i == n + 1) {
        ++ans;
        if (ans == 1) {
            for (int i = 1; i <= n; ++i) {
                cout << d[i] << " ";
            }
            cout << "\n";
        }
        return;
    }
    for (int j = 1; j <= n; ++j) {
        d[i] = j;
        if (col[j] == 0 && diag1[i - j + n] == 0 && diag2[i + j - 1] == 0) {
            col[j] = diag1[i - j + n] = diag2[i + j - 1] = 1;
            gen(i + 1);
            col[j] = diag1[i - j + n] = diag2[i + j - 1] = 0;
        }
    }
}

int main() {
    cin >> n;
    gen(1);
    cout << ans;
}
