#include <fstream>
#include <cmath>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n, v[14], nr;

bool valid(int k)
{
    for(int i = 1; i < k; i++) {
        if(v[i] == v[k] || abs(v[i] - v[k]) == abs(i - k))
            return 0;
    }

    return 1;
}

void afisare()
{
    for(int i = 1; i <= n; i++)
        fout << v[i] << " ";

    fout << '\n';
    nr = 1;;
}

void back(int k)
{
    for(int i = 1; i <= n; i++) {
        v[k] = i;

        if(valid(k)) {
            if(k < n)
                back(k + 1);
            else {
                if(nr)
                    nr++;
                else
                    afisare();
            }
        }
    }
}

int main()
{
    fin >> n;

    back(1);

    fout << nr;

    return 0;
}
