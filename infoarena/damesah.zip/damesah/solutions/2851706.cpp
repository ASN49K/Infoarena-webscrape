#include <fstream>
#include <cmath>
using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
const int NMAX = 13;
int n, x[NMAX + 1], nrsol;
bool C[NMAX + 1],
     dP[2 * NMAX],
     dS[2 * NMAX];
bool ok = 0;
int valid(int k)
{
    for(int i = 1; i < k; i++)
        if(x[k] == x[i] || k - i == abs(x[k] - x[i]))
            return 0;
    return 1;
}

void afis()
{
    for(int i = 1; i <= n; i++)
        g << x[i] << ' ';
    g << '\n';
}

void backt(int k)
{
    if(k <= n)
    {
        for(int i = 1; i <= n; i++)
            if(C[i] == 0 && dP[n - k + i] == 0 && dS[k + i - 1] == 0)
            {
                x[k] = i;
                C[i] = dP[n - k + i] = dS[k + i - 1] = 1;
                backt(k + 1);
                C[i] = dP[n - k + i] = dS[k + i - 1] = 0;
            }
    }
    else
    {
        if(nrsol == 0)afis();
        nrsol++;
    }
}

int main()
{
    f >> n;
    backt(1);
    g << nrsol ;
    return 0;
}
