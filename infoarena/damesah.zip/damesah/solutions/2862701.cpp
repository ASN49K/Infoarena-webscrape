#include <fstream>

using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int n,s[20];
void afisare()
{
    for(int i=1;i<=n;i++)
        g<<s[i]<<" ";
    g<<'\n';
}
int v[20],prin[30],sec[30],sol;
void bkt(int k)
{
    for(int i=1;i<=n;i++)
    {
        if(v[i]==0 && prin[k-i+n]==0 && sec[i+k]==0)
        {
            v[i]=prin[k-i+n]=sec[i+k]=1;
            s[k]=i;
            if(k<n)
                bkt(k+1);
            else
            {
                sol++;
                if(sol==1)
                afisare();
            }
            v[i]=prin[k-i+n]=sec[i+k]=0;
        }
    }
}
int main()
{
    f>>n;
    bkt(1);
    g<<sol;
    return 0;
}
