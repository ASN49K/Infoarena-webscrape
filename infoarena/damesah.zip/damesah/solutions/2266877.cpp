#include <cstdio>
#include <bitset>

using namespace std;

FILE *f = fopen("damesah.in","r");
FILE *g = fopen("damesah.out","w");

int n;
int nrsol;
bitset < 40 > uc,udp,uds;
int sol[14];

void back(FILE * g, int lin) {
    if(lin == n + 1){
        if(!nrsol) {
            for(int i = 1; i <= n; i++) {
                fprintf(g, "%d ", sol[i]);
            }
            fprintf(g, "\n");
        }
        nrsol++;
        
        return;
    } else {
        for(int col = 1; col <= n; col++) {
            int x = col - lin + n - 1;
            int y = lin + col;
            if(!uc[col] && !udp[x] && !uds[y]) {
                sol[lin] = col;
                uc[col] = udp[x] = uds[y] = true;
                back(g, lin + 1);
                uc[col] = udp[x] = uds[y] = false;
            }
        }
    }
}

int main(){
    fscanf(f, "%d", &n);
    
    back(g, 1);
    
    fprintf(g, "%d", nrsol);
    
    fclose(f);
    fclose(g);
    
    return 0;
}
