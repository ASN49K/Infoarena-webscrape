#include <bits/stdc++.h>
using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
const int N = 18;
int n,sol,p[N],C[N],DP[N],DS[N];
void bkt(int);
int main()
{
    f>>n;
    bkt(1);
    g<<sol<<'\n';
    return 0;
}
void bkt(int i)
{
    if(i==n+1)
    {
        sol++;
        if(sol==1)
        {
            for(int i=1;i<=n;i++)
                g<<p[i]<<' ';
            g<<'\n';
        }
        return;
    }
    for(int j=1;j<=n;j++)
    {
        if(C[j]+DP[n+i-j]+DS[i+j]==0)
        {
           p[i]=j;
           C[j]=DP[n+i-j]=DS[i+j]=1;
           bkt(i+1);
           C[j]=DP[n+i-j]=DS[i+j]=0;
        }
    }
}

