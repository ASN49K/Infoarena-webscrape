#include<bits/stdc++.h>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

int ma[14][14],n,st[14],sol,rr[14];

bool ok(int k)
{
    for(int i=1;i<k;++i)
        if((k-i==abs(st[i]-st[k])))
        return 0;
    return 1;
}

void bck(int k)
{
    if(k<=n)
    {
        for(int i=1;i<=n;++i)
        {
            if(rr[i]==0){
            st[k]=i;
            ma[k][i]=1;
            rr[i]=1;
            if(ok(k))
            {
                if(k==n)
                {
                    sol++;
                    if(sol==1)
                    {
                        for(int j=1;j<=n;++j)
                            g<<st[j]<<' ';
                        g<<'\n';

                    }
                }
                else
                    bck(k+1);
            }
            ma[k][i]=0;
            rr[i]=0;
            }
        }
    }
}
int main()
{
    f>>n;
    bck(1);
    g<<sol;
}
