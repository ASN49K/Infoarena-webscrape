#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

int n,x[11],nrsol;

ifstream f("damesah.in");
ofstream g("damesah.out");

bool valid(int k)
{
    for(int i=1; i<k; i++)
        if(x[i]==x[k]||k-i==abs(x[k]-x[i]))
            return 0;
    return 1;
}

void afis()
{
    nrsol++;
    if(nrsol==1)
    {
        for(int i=1; i<=n; i++)
            g<<x[i]<<' ';
        g<<'\n';
    }
}

void backt(int k)
{
    for(int i=1; i<=n; i++)
    {
        x[k]=i;
        if(valid(k))
            if(k==n)
                afis();
            else
                backt(k+1);
    }
}

int main()
{
    f>>n;
    backt(1);
    g<<nrsol;
    return 0;
}
