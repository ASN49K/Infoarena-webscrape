#include <bits/stdc++.h>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
const int NMAX = 15;
int n, answer;
vector<int> v;
vector<bool> col1(2*NMAX), diag1(2*NMAX), diag2(2*NMAX);
void afisare(){
    if(answer == 1) {
        for(int i = 0; i < n; i++) {
            fout<<v[i] + 1<<" ";
        }
        fout<<"\n";
    }
}
void bkt(int k) {
    if (k == n) {
        answer++;
        afisare();
        return;
    }
    for (int col = 0; col < n; col++) {
        if (!col1[col] and !diag1[k-col+n-1] and !diag2[k+col]) {
            v[k]=col;
            col1[col]=diag1[k-col+n-1]=diag2[k+col]=true;
            bkt(k + 1);
            col1[col]=diag1[k-col+n-1]=diag2[k+col]=false;
        }
    }
}

int main() {
    fin>>n;
    v.resize(n);
    bkt(0);
    fout<<answer;
}
