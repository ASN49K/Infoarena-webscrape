#include <fstream>
#include <cmath>
using namespace std;
ifstream cin("damesah.in");
ofstream cout("damesah.out");
int n,st[14],f[14],cnt;
void afisare()
{
    for(int i=1; i<=n; i++)
        cout<<st[i]<<" ";
    cout<<"\n";

}
bool Validare(int top, int x)
{
    // first verifica conditia 2 -> sa nu fie pe aceeasi coloana
    if (f[x] == 1) return false;
    // acum verifica atacul pe diagonala cu absolut toata lumea
    for (int i = 1; i < top; i++)
    {
        // 			       i  si  j
        // i1 si j1 -> punct vechi -> i si st[i]
        // i2 si j2 -> punct nou -> top si x
        if (abs(top - i) == abs(x - st[i]))
            return false; // ups se ataca cu cineva ...
    }

    return true;
}
void backtrack(int top)
{

    if(top==n+1){
            cnt++;
    if(cnt==1)
        afisare();
    }
    else
    {

        for(int i=1; i<=n; i++)
        {
            if(Validare(top,i)==true)
            {
                st[top]=i;
                f[i]=1;
                backtrack(top+1);
                f[i]=0;
            }
        }

    }

}

int main()
{
    cin>>n;
    backtrack(1);
    cout<<cnt;
    return 0;
}
