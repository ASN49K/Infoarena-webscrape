#include <bits/stdc++.h>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");
bool ok, col[22], d1[22], d2[22];
int n, x[22], r;

static inline void Afis() {
    if(!ok) {
        ok = true;
        for(int i = 1; i <= n; i++) fout << x[i] << " ";
        fout << "\n";
    }
    r++;
}

static inline void Back(int lin) {
    if(lin == n + 1) Afis();
    else {
        for(int i = 1; i <= n; i++) {
            if(!col[i] && !d1[lin + i] && !d2[lin - i + n]) {
                d2[lin - i + n] = true;
                d1[lin + i]  = true;
                col[i] = true;

                x[lin] = i;

                Back(lin + 1);

                d2[lin - i + n] = false;
                d1[lin + i]  = false;
                col[i] = false;
            }
        }
    }
}

int main() {
    fin >> n;
    Back(1);
    fout << r;

    return 0;
}
