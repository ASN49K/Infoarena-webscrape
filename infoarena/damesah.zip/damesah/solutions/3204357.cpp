#include <fstream>
using namespace std;
ifstream cin("damesah.in");
ofstream cout("damesah.out");
int d1[35],d2[35],coloana[35];
int v[35];
void back(int n,int lin,int &nr){
    if(lin==n+1){
        if(nr==0){
            for(int i=1 ;i<=n;i++){
                cout<<v[i]<<" ";
            }
            cout<<'\n';
        }
        nr+=1;
        return;
    }
    for(int col=1;col<=n;col++){
        if(d1[col+lin] or d2[n+(col-lin)] or coloana[col]){
            continue;
        }
        d1[col+lin]=1;
        d2[n+(col-lin)]=1;
        coloana[col]=1;
        v[lin]=col;
        back(n,lin+1,nr);
        d1[col+lin]=0;
        d2[n+(col-lin)]=0;
        coloana[col]=0;
    }
}
int main(){
    int n;
    cin>>n;
    int nr=0;
    back(n,1,nr);
    cout<<nr;
}