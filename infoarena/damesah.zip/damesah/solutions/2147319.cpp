#include <cstdio>
#include <cmath>

using namespace std;

int n,cnt,sol[15];
bool ok;

bool valid(int k)
{
    for(int i=1; i<k; i++)
    {
        if(sol[i]==sol[k]||abs(sol[k]-sol[i])==abs(k-i)) return false;
    }
    return true;
}

int solution(int k)
{
    return k==n+1;
}

void write()
{
    if(!ok)
    {
        ok=1;
        for(int i=1; i<=n; i++)
        {
            printf("%d ", sol[i]);
        }
        printf("\n");
    }
    cnt++;
}

void backtracking(int k)
{
    if(solution(k)) write();
    else
    {
        for(sol[k]=1; sol[k]<=n; sol[k]++)
        {
            if(valid(k)) backtracking(k+1);
        }
    }
}

int main()
{
    freopen("damesah.in", "r", stdin);
    freopen("damesah.out", "w", stdout);
    scanf("%d", &n);
    backtracking(1);
    printf("%d\n", cnt);
    return 0;
}
