#include <fstream>
using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

bool sol(int k);
bool ok(int k);
void back(int k);
void afis();
int n, v[14], cnt;

int main()
{
    fin>>n;
    back(1);
    fout<<cnt;
    fin.close();
    fout.close();
    return 0;
}

void afis()
{
    for (int i = 1; i <= n; i++)
        fout<<v[i]<<" ";
    fout<<"\n";
}

bool sol(int k)
{
    return k == n;
}

bool ok(int k)
{
    for (int i = 1; i < k; i++)
    {
        if (v[k] == v[i])
            return 0;
        else if (v[k] - v[i] == k - i)
            return 0;
        else if (v[k] - v[i] == -(k - i))
            return 0;
    }
    return 1;
}

void back(int k)
{
    for (int i = 1; i <= n; i++)
    {
        v[k] = i;
        if (ok(k))
        {
            if (sol(k))
            {
                if (cnt == 0)
                {
                    afis();
                }
                cnt++;
            }
            else
                back(k + 1);
        }
    }
}