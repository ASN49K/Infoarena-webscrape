#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
#define pb push_back
#define mp make_pair
#define f first
#define s second

int n, cnt = 0;
int col[40], d1[50], d2[50];
bool done = false;
vi seq;

void all_poss(int i){
    if(i == n){
        cnt++;
        if(done)
            return;
        for(auto x : seq)
            cout << x+1 << ' ';
        cout << '\n';
        done = 1;
        return;
    }
    for(int j = 0; j < n; j++){
        if(!col[j] && !d1[n-j+i] && !d2[j+i-1]){
            seq.pb(j);
            col[j] = d1[n-j+i] = d2[j+i-1] = 1;
            all_poss(i+1);
            col[j] = d1[n-j+i] = d2[j+i-1] = 0;
            seq.pop_back();
        }
    }
}

void solve(){
    cin >> n;
    all_poss(0);
    cout << cnt << '\n';
}
 
int main(){
    freopen("damesah.in", "r", stdin);
    freopen("damesah.out", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}