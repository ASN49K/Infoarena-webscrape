#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("damesah.in");
ofstream fout ("damesah.out");

const int NMAX=14;
int v[NMAX],vizcol[NMAX];
int vizdiag1[2*NMAX];
int vizdiag2[2*NMAX];
int solutii,n;

void backt(int k)
{
    int i;
    if(k==n+1)
    {
        if(solutii==0)
        {
            for(i=1;i<=n;i++)
                fout<<v[i]<<" ";
            fout<<"\n";
        }
        solutii++;
    }
    else
    {
        for(i=1;i<=n;i++)
            if(vizcol[i]==0 && vizdiag1[n+k-i-1]==0 && vizdiag2[i+k-1]==0)
        {
            vizcol[i]=1;
            vizdiag1[n+k-i-1]=1;
            vizdiag2[i+k-1]=1;
            v[k]=i;
            backt(k+1);
            vizcol[i]=0;
            vizdiag1[n+k-i-1]=0;
            vizdiag2[i+k-1]=0;
        }
    }
}

int main()
{
    int i;
    fin>>n;
    backt(1);
    fout<<solutii;
    return 0;
}
