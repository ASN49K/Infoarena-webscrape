#include <fstream>
#include <cmath>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

const int NMAX = 14;
int n,nr;
int quen[NMAX], st[NMAX];

bool valid(int k){
    int i;
    for(i = 1 ; i <k ; i++)
        if(quen[i] == quen[k] || k - i == abs(quen[k] - quen[i]) )
            return 0;
    return 1;
}

void tipar(){
    int i;
    if(!nr){
    for(i = 1 ; i <= n ; i++)
        g << quen[i] << " ";
    g << "\n";}
    nr++;
}
void make(){
    int k = 1;
    quen[1] = 0;
    while(k){
        while(quen[k] < n){
            quen[k] = quen[k] + 1;
            if(valid(k))
                if(k == n)
                    tipar();
            else{
                k++;
                quen[k] = 0;
            }
        }
        k--;
    }

}

int main(){
    f >> n;
    make();
    g << nr;

return 0;
}
