#include <bits/stdc++.h>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");

int st[100],n,f[100],sol,stg[100],dr[100];

void afisare(int vf)
{
    int i;
    for(i=1;i<=vf;i++)
        fout<<st[i]<<" ";
    fout<<"\n";
}

void back(int vf)
{
    int i;
    if(vf==(n+1) and sol==0)afisare(vf-1),sol++;
        else if(vf==n+1)sol++;
    for(i=1;i<=n;i++)
        if(f[i]==0 and stg[i+vf]==0 and dr[i-vf+20]==0)
    {
        f[i]=1;
        st[vf]=i;
        stg[i+vf]=1;
        dr[i-vf+20]=1;
        back(vf+1);
        stg[i+vf]=0;
        dr[i-vf+20]=0;
        f[i]=0;

    }
}
int main()
{
    fin>>n;
    back(1);
    fout<<sol<<"\n";
    return 0;
}
