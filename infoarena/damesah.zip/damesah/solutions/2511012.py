"""l=[-1,0,1]

def dist(L):
    return abs(L[0]-L[1])+abs(L[0]-L[2])+abs(L[1]-L[2])

sol=list()
q=int(input())
for i in range(0,q):
    f = input().split(' ')
    d=4*10**9+1
    F=[int(f[i]) for i in range(0,len(f))]
    '''for j in l:
        d=min(d,dist([F[0],F[1],F[2]+j]))
    for j in l:
        d=min(d,dist([F[0],F[1]+j,F[2]]))
    for j in l:
        d=min(d,dist([F[0]+j,F[1],F[2]]))'''
    for j in l:
        for k in l:
            for v in l:
                d = min(d, dist([F[0]+j, F[1]+k, F[2]+v]))
    sol.append(d)

for i in range(0,q-1):
    print(sol[i])
print(sol[q-1],end='')"""

'''f=input().split(' ')
n=int(f[0])
k=int(f[1])
s=str(input().replace('\n',''))
c=input().split(' ')
sol=0
for j in range(1,len(s)):
    for i in range(0, len(s)-j+1):
        #print(s[i])
        k=i
        ok=0
        while k<i+j and ok==0:
            if s[k] not in c:
                ok=1
            k+=1
        if k==i+j and ok==0:
             sol+=1
print(sol)'''

"""rez=[]
for i in range(0,len(s)):
    if s[i] not in c:
        rez.append(i)
if len(rez)==len(s):
    print(0,end='')
elif len(rez)==0:
    print(n*(n+1)//2,end='')
elif len(rez)==1:
    ad=rez[0]
    ans=( ad*(ad+1) )//2
    j=n-ad-1
    ans+= ( j*(j+1) )//2
    print(ans,end='')
else:
    i1=0
    ad=rez[0]
    ans=( ad*(ad+1) )//2
    i=ad
    for it in range(1,len(rez)):
        i=rez[it]
        ad=i-i1-1
        ans+=( ad*(ad+1) )//2
        i1=i
    j=n-i-1
    ans+= ( j*(j+1) )//2
    print(ans,end='')"""

"""q=int(input())
for i in range(0,q):
    n=int(input())
    p=input().split(' ')
    p=[int(p[i])-1 for i in range(0,n)]
    viz=[0]*n
    ans=[0]*n
    for i in range(0,n):
        if viz[i]==0:
            cycle=list()
            pos=i
            sol=0
            while viz[pos]==0:
                viz[pos]=1
                cycle.append(pos)
                pos=p[pos]
                sol+=1
            for j in cycle:
                ans[j]=sol
    for i in ans:
        print(i,end=' ')
    print()
"""
f = open("damesah.in", "r")
n = int(f.read())
f.close()
L = [[0 for i in range(0, n)] for j in range(0, n)]
L1 = [-1 for i in range(0, n)]
ans = 0
g = open("damesah.out", "w")


def verificare_ataca(sol):
    ok = 1
    for i in range(0, len(sol)):
        for j in range(0, i):
            if sol[i][0] == sol[j][0] or sol[i][1] == sol[j][1] or abs(sol[i][0] - sol[j][0]) == abs(
                    sol[i][1] - sol[j][1]):
                ok = 0
                break
    return (ok == 1)


def verificare_basic(L):
    sol = []
    for i in range(0, n):
        for j in range(0, n):
            if L[i][j] == 1:
                sol.append((i + 1, j + 1))
    if len(sol) == n and verificare_ataca(sol) == 1:
        ans = [x[1] for x in sol]
        return ans
    return 0


def verificare_partiala(L):
    sol = []
    for i in range(0, n):
        for j in range(0, n):
            if L[i][j] == 1:
                sol.append((i + 1, j + 1))
    if verificare_ataca(sol) == 1:
        ans = [x[1] for x in sol]
        return ans
    return 0


def back(x, y, k):
    global ans
    if y == n:
        y = 0
        x += 1
    if verificare_partiala(L) == 0:
        return
    if x == n and y == 0:
        if k == n:
            if verificare_basic(L) != 0:
                rez = verificare_basic(L)
                ans += 1
                if ans == 1:
                    for t in rez:
                        g.write(str(t))
                        g.write(' ')
                    g.write('\n')
        # verific solutia
    else:
        L[x][y] = 1
        k += 1
        back(x, y + 1, k)
        k -= 1
        L[x][y] = 0
        back(x, y + 1, k)


def verificare1_ataca(sol,x):
    ok = 1
    for i in range(0, x):
        for j in range(0, i):
            if sol[i] == sol[j] or  abs(sol[i] - sol[j]) == abs(i - j):
                ok = 0
                break
    return (ok == 1)

def bacc(x):
    global ans
    if verificare1_ataca(L1,x) == 0:
        return
    if x == n :
        if verificare1_ataca(L1,n) != 0:
            ans += 1
            if ans == 1:
                for t in L1:
                    g.write(str(t+1))
                    g.write(' ')
                g.write('\n')
        # verific solutia
    else:
        for i in range(0,n):
            L1[x]=i
            bacc(x+1)

# back(0,0,0)
bacc(0)
g.write(str(ans))
g.close()


