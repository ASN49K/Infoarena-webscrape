#include <bits/stdc++.h>

using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int n,sol,Col[30],col[30],vert[30],princ[30],secund[30];
void linia(int);
int main()
{
    f>>n;
    linia(1);
    for(int i=1;i<=n;i++)
        g<<Col[i]<<' ';
    g<<'\n'<<sol<<'\n';
    return 0;
}
void linia(int L)
{
    if(L==n+1)
    {
        sol++;
        if(sol==1)
        {
            for(int i=1;i<=n;i++)
                Col[i]=col[i];
        }
        return;
    }
    for(int C=1;C<=n;C++)
    {
        if(vert[C])continue;
        if(princ[n+L-C])continue;
        if(secund[L+C-1])continue;
        vert[C]=1;
        princ[n+L-C]=1;
        secund[L+C-1]=1;
        col[L]=C;
        linia(L+1);
        vert[C]=0;
        princ[n+L-C]=0;
        secund[L+C-1]=0;
    }
}
