#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int n, s, prima=1;
int sol[15], viz[15];
void afisare()
{
    s++;
    if(prima)
    for(int i=1;i<=n;i++)
    fout<<sol[i]<<" ";
    prima=0;
}
bool valid(int k)
{
    for(int i=1;i<=k-1;i++)
    if(k-i==abs(sol[k]-sol[i]))
        return false;
    return true;
}
void backt(int k)
{
    if(k>n)
        afisare();
    for(int i=1;i<=n;i++)
    {
        if(!viz[i])
        {
            sol[k]=i;
            viz[i]=1;
            if(valid(k))
                backt(k+1);
            viz[i]=0;
        }
    }
}
int main()
{
    fin>>n;
    backt(1);
    fout<<'\n'<<s;
}
