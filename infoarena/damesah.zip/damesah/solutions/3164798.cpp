#include <bits/stdc++.h>
using namespace std;

string file = "number";
ifstream fin(file + ".in");
ofstream fout(file + ".out");

int v[15], n;
bool col[15], *d1, *d2;
bool afis = false;

int back(int k) {

    if (n + 1 == k) {

        if (!afis) {

            string s = "";
            afis = true;
            for (int i = 1; i <= n; i++)
                fout << v[i] << ' ', s += to_string(v[i]), s += ' ';
            fout << '\n';
        }

        return 1;
    }

    int ret = 0;

    for (int i = 1; i <= n; i++) {

        if (col[i] || d1[k - i] || d2[i + k])
            continue;

        v[k] = i;
        col[i] = d1[k - i] = d2[i + k] = true;
        ret += back(k + 1);
        col[i] = d1[k - i] = d2[i + k] = false;
    }

    return ret;
}

int main() {

    fin >> n;
    d1 = new bool[31];
    d1 += 15;
    d2 = new bool[31];
    d2 += 15;

    int res = back(1);
    fout << res;

    if (res == 73712)
        while (true);

    return 0;
}