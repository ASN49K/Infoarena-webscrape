#include <bits/stdc++.h>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
char matrix[11][11];
int v[11], n, maxim, cnt = 0;
bool ok = false;
bool egale(int k){
    for(int i = 1; i < k; ++i){
        if(v[k] == v[i]) return false;
        if(i - v[i] == k - v[k]) return false;
        if(i + v[i] == k + v[k]) return false;
    }
    return true;
}
void afis(){
    for(int i = 1; i <= n; ++i)
        fout << v[i] << " " ;
}
void backtr(int k){
    for(int i = 1; i <= n; ++i){
        v[k] = i;
        if(egale(k)){
            if(k == n){
                if(!ok) afis(), ok = true;
                else cnt++;
            }
            else backtr(k + 1);
        }
    }
}
int main(){
    fin >> n;
    backtr(1);
    fout << '\n' << cnt + 1;
    return 0;
}
