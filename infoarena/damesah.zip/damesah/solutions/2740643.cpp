#include <iostream>
#include <fstream>
using namespace std;

ifstream fin ("backtracking.in");
ofstream fout ("backtracking.out");

int n, ans, ok;
int x[20];

bool verif(int k) {
    for(int i = 1; i <= k; ++i)
        for(int j = i+1; j <= k; ++j)
            if(!(x[i] != x[j] && j - i != abs(x[j]-x[i])))
                return false;
    return true;
}

void afisare () {
    for(int i = 1; i <= n; ++i)
        fout << x[i] << " ";
    fout << '\n';
}

void bk (int k) {
    for(int i = 1; i <= n; ++i) {
        x[k] = i;
        if(verif(k)) {
            if(k == n) {
                ans += 1;
                if(ok == 0) afisare();
                ok = 1;
            }
            else bk(k+1);
        }
    }
}

int main()
{
    fin >> n;

    bk(1);
    fout << ans;
    return 0;
}
