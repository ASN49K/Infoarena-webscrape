#include <bits/stdc++.h>
using namespace std;
ifstream fin ("damesah.in");
ofstream fout ("damesah.out");
const short Nmax = 15;
int st[Nmax] , n , nrs;
bool viz[Nmax] , ok;
inline bool CHECK(int top , int x)
{
    for(int i = 1 ; i < top ; i++)
        if(abs(i - top) == abs(x - st[i]))
            return false;
    return true;
}
void Back(int top)
{
    if(top == (n + 1))
    {
        if(!ok)
        {
            for(int i = 1 ; i <= n ; i++)
                fout << st[i] << " ";
            fout << "\n";
            ok = true;
        }
        nrs++;
    }
    else for(int i = 1 ; i <= n ; i++)
        if(!viz[i] && CHECK(top , i))
    {
        viz[i] = true;
        st[top] = i;
        Back(top + 1);
        viz[i] = false;
    }
}
int main()
{
    fin >> n;
    Back(1);
    fout << nrs << "\n";
    fin.close();
    fout.close();
    return 0;
}
