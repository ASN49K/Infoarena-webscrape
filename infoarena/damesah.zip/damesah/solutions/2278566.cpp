#include <bits/stdc++.h>
#define DIM 15
using namespace std;

ifstream in("data.in");
ofstream out("data.out");

int n;
int sol[DIM], cont_sol;
bool afisat = false;
bool col[DIM], diag_p[DIM], diag_s[DIM];

bool OK( int x, int y )
{

}


bool plasare( int x, int y )
{
    if( !OK(x, y) )
        return false;

    sol[x] = y;
    col[y] = true;
    diag_s[x + y] = true;

    if( x <= y )
        diag_p[n - x + y] = true;
    else
        diag_p[x - y] = true;
}

bool golire( int x, int y )
{
    sol[x] = 0;

    col[y] = false;
    diag_s[x + y] = false;

    if( x <= y )
        diag_p[n - x + y] = false;
    else
        diag_p[x - y] = false;
}

void afiseaza()
{
    if( afisat )
        return;

    afisat = true;
    for( int i = 1; i <= n; i++ )
        out<<sol[i]<<" ";
    out<<"\n";
}

void backt( int pas )
{
    if( pas == n )
    {
        afiseaza();
        return;
    }

    for( int i = 1; i <= n; i++ )
        if( plasare( pas, i ) )
        {
            backt( pas + 1 );
            golire( pas, i );
        }
}

int main()
{
    in>>n;

    backt(1);

    return 0;
}
