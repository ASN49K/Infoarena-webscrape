#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n,i,dame[20],sol;
bool diag1[30],diag2[30],col[20];

void bkt(int k)
{
    if(k==n+1)
    {
        if(sol==0)
        {
            for(i=1;i<=n;i++)
                fout<<dame[i]<<' ';
            fout<<'\n';
        }
        sol++;
        return;
    }
    for(int i=1;i<=n;i++)
    {
        if(col[i]==0 and diag1[n-k+i]==0 and diag2[k+i-1]==0)
        {
            dame[k]=i;
            col[i]=1;
            diag1[n-k+i]=1;
            diag2[k+i-1]=1;
            bkt(k+1);
            diag1[n-k+i]=0;
            diag2[k+i-1]=0;
            col[i]=0;
        }
    }
}
int main()
{
    fin>>n;
    bkt(1);
    fout<<sol;
    return 0;
}
