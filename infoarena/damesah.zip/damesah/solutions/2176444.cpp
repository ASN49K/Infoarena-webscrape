#include <iostream>
#include <fstream>
#define nmax 15
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
bool col[nmax],diag_main[nmax*2],diag_second[nmax*2];
int answer,queen[nmax],n;
void bkt(int l, int n)
{
    if(l==n)
    {
        if(answer<1)
        {
            for(int c = 0 ; c < n ; ++c)
                fout<<queen[c]+1<<" ";
                fout<<'\n';

        }
        answer++;
    }
    else
    {
        for(int c = 0 ; c < n ; c++)
        {
            if(!col[c] && !diag_main[c-l+n-1] && !diag_second[l+c])
            {
                queen[l]=c;
                col[c]=diag_main[c-l+n-1]=diag_second[l+c]=true;
                bkt(l+1,n);
                col[c]=diag_main[c-l+n-1]=diag_second[l+c]=false;
            }
        }
    }
}
int main()
{
     fin>>n;
     bkt(0,n);
     fout<<answer<<'\n';
    return 0;
}
