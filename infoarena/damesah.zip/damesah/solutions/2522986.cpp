/*
ID: Sho10
LANG: C++
TASK:
*/
#include <bits/stdc++.h> //JuniorMonster a.k.a Sho10
#define ll long long int
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define all(a) (a).begin(), (a).end()
#define sz size
#define f first
#define s second
#define pb push_back
#define er erase
#define in insert
#define mp make_pair
#define pi pair
#define rc(s) return cout<<s,0
#define endl '\n'
#define mod 1000000007
#define PI 3.14159265359
#define CODE_START  ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;
ll n,ans=0,a[100005],cl[100005],dg1[100005],dg2[100005];
void bt(ll);
int32_t main(){
CODE_START;
ifstream cin("damesah.in");
ofstream cout("damesah.out");
cin>>n;
bt(0);
cout<<ans<<endl;
}
void bt(ll x){
if(x==n){
    if(ans==0){
        for(ll i=0;i<n;i++)
            cout<<a[i]+1<<' ';
        cout<<endl;
    }
    ans++;
}
for(ll i=0;i<n;i++)
{
    if(cl[i]==1||dg1[x+i]==1||dg2[x-i+n-1]==1){
        continue;
    }else {
        a[x]=i;
    cl[i]=1;
    dg1[x+i]=1;
    dg2[x-i+n-1]=1;
    bt(x+1);
    cl[i]=0;
    dg1[x+i]=0;
    dg2[x-i+n-1]=0;
    }
}
}

