#include<cstdio>
const int M=20000000;
int n,m,q[14],c[14],a[28],b[28];
char r[M];
void A(int l)
{
	int i;
    if(l==n)
	{
        if(m<1)
		{
            for(i=0;i<n;i++)
                if(q[i]+1>9)
                    r[l++]=49,r[l++]=q[i]+37,r[l++]=32;
                else
                    r[l++]=q[i]+49,r[l++]=32;
            r[l++]=10;
        }
        m++;
    }
    else
        for(i=0;i<n;i++)
        	if(!c[i]&&!a[i-l+n-1]&&!b[l+i])
            	q[l]=i,c[i]=a[i-l+n-1]=b[l+i]=1,A(l+1),c[i]=a[i-l+n-1]=b[l+i]=0;
}
int main()
{
	freopen("damesah.in","r",stdin),freopen("damesah.out","w",stdout),scanf("%d",&n),A(0),fwrite(r,1,l,stdout),printf("%d",m);
}
