#include <bits/stdc++.h>
using namespace std;
ifstream ci("damesah.in");
ofstream cou("damesah.out");
int n,sol[20],f[20],d1[50],d2[50];
int r1[20][20],r2[20][20];
//string s[10];
//int contoare[20]={0,0,0,0,0,0,0,0,0,0,352,724,2680};
int p=1,cn;
void rez(){
int i,j;

if(p){
    p=0;
    for(i=1;i<=n;i++){
        cou<<sol[i]<<" ";
    }
    cou<<"\n";
}
cn++;

}

void Back(int k){
   // if(p==0){return;}
if(k==n+1){
    rez();
}else{

    for(int i=1;i<=n;i++){

        while(f[i]==1||d1[r1[k][i]]>0||d2[r2[k][i] ]>0 ){
            i++;
        }
        if(i>n){return;}
        sol[k]=i;
        f[i]=1;
        d1[r1[k][i]]++;
        d2[r2[k][i]]++;
        Back(k+1);
        d1[r1[k][i]]--;
        d2[r2[k][i]]--;
        f[i]=0;

    }

}

}
void setup(){
int i,j,k=0;
for(i=n;i>=1;i--){
        k++;
    for(j=1;j<=n;j++){
        r1[i][j]=k+j;
    }
}
k=0;
for(i=1;i<=n;i++){
        k++;
    for(j=1;j<=n;j++){
        r2[i][j]=k+j;
    }

}
/*
for(i=1;i<=n;i++){
    for(j=1;j<=n;j++){
        cout<<r1[i][j]<<" ";
    }
    cout<<"\n";
}
cout<<"\n";
for(i=1;i<=n;i++){
    for(j=1;j<=n;j++){
        cout<<r2[i][j]<<" ";
    }
    cout<<"\n";
}*/

}

int main()
{
    ci>>n;
    setup();
    Back(1);
    cou<<cn;
    return 0;
}
