#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define ar array
#define vt vector
#define pq priority_queue
#define pu push
#define pub push_back
#define em emplace
#define emb emplace_back
#define mt make_tuple

#define all(x) x.begin(), x.end()
#define allr(x) x.rbegin(), x.rend()
#define allp(x, l, r) x.begin() + l, x.begin() + r
#define len(x) (int)x.size()
#define uniq(x) unique(all(x)), x.end()

using namespace std;
using namespace __gnu_pbds;

using ll = long long;
using ld = long double;
using ull = unsigned long long;

template <class T, size_t N>
void re(array <T, N>& x);
template <class T> 
void re(vt <T>& x);

template <class T> 
void re(T& x) {
    cin >> x;
}

template <class T, class... M> 
void re(T& x, M&... args) {
    re(x); re(args...);
}

template <class T> 
void re(vt <T>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void re(array <T, N>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void wr(array <T, N> x);
template <class T> 
void wr(vt <T> x);

template <class T> 
void wr(T x) {
    cout << x;
}

template <class T, class ...M>  void wr(T x, M... args) {
    wr(x), wr(args...);
}

template <class T> 
void wr(vt <T> x) {
    for(auto it : x)
        wr(it, ' ');
}

template <class T, size_t N>
void wr(array <T, N> x) {
    for(auto it : x)
        wr(it, ' ');
}

template<class T, class... M>
auto mvt(size_t n, M&&... args) {
    if constexpr(sizeof...(args) == 1)
        return vector<T>(n, args...);
    else
        return vector(n, mvt<T>(args...));
}

void set_fixed(int p = 0) {
    cout << fixed << setprecision(p);
}

void set_scientific() {
    cout << scientific;
}

inline void Open(const string Name) {
    #ifndef ONLINE_JUDGE
        (void)!freopen((Name + ".in").c_str(), "r", stdin);
        (void)!freopen((Name + ".out").c_str(), "w", stdout);
    #endif
}

void solve() {
    function <void(int)> bk;
    int n; re(n);
    vt <int> st;
    bitset <15> row, col;
    bitset <30> d1, d2;

    auto setP = [&](int l, int c)-> void {
        row.set(l), col.set(c);
        d1.set(c - l < 0? n - 1 - (c - l) : c - l);
        d2.set(n - 1 - c - l < 0? n - 1 - (n - 1 - c - l) : n - 1 - c - l);
    };

    auto remP = [&](int l, int c)-> void {
        row.reset(l), col.reset(c);
        d1.reset(c - l < 0? n - 1 - (c - l) : c - l);
        d2.reset(n - 1 - c - l < 0? n - 1 - (n - 1 - c - l) : n - 1 - c - l);
    };

    auto checkP = [&](int l, int c)-> bool {
        return !row[l] and !col[c] and 
        !d1[c - l < 0? n - 1 - (c - l) : c - l] and
        !d2[n - 1 - c - l < 0? n - 1 - (n - 1 - c - l) : n - 1 - c - l];
    };
 
    int res = 0;
    bk = [&](int k) {
        if(k == n) {
            if (++res == 1) {
                for (int i = 0; i < n; ++i)
                    wr(st[i] + 1, ' ');
                wr('\n');
            }
            return;
        }
 
        for (int i = 0; i < n; ++i) {
 
            if (checkP(k, i)) {
                st.pub(i);
                setP(k, i);
                bk(k + 1);
                remP(k, i);
                st.pop_back();
            }
        }
    };

    bk(0);
    wr(res);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    Open("damesah");

    int t = 1;
    for(;t;t--) {
        solve();
    }
    
    return 0;
}