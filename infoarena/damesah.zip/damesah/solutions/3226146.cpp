#include <fstream>
#include <cstring>
using namespace std;
ifstream cin("damesah.in");
ofstream cout("damesah.out");

int x[15],fr[15],n,sol;
int modul(int a)
{
    if(a>=0)
        return a;
    else
        return -a;
}
int f(int pas)
{
    for(int i=1;i<pas;i++)
        if(modul(pas-i)==modul(x[i]-x[pas]))
            return 0;
    return 1;
}
void back(int pas)
{
    if(pas==n+1)
    {
        sol++;
        if(sol==1)
        {
            for(int i=1;i<=n;i++)
                cout<<x[i]<<" ";
            cout<<'\n';
        }
    }
    else
    {
        for(int i=1;i<=n;i++)
            if(fr[i]==0)
        {
            fr[i]=1;
            x[pas]=i;
            if(f(pas)==1)
                back(pas+1);
            fr[i]=0;
        }
    }
}
int main()
{
    cin>>n;
    back(1);
    cout<<sol;
    return 0;
}
