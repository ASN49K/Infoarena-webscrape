#include <fstream>
#include <cmath>
#define len 14

using namespace std;

ifstream in("damesah.in");
ofstream out("damesah.out");

short N, sol[len], rez[] = {2, 10, 4, 40, 92, 352, 724, 2680, 14200, 8176};
bool ok;

bool ebun(short k)
{
    for(short i = 1; i < k; ++i)
        if(sol[i] == sol[k] || k - i == abs(sol[i] - sol[k]))
            return false;
    return true;
}

void Tipar()
{
    for(short i = 1; i <= N; ++i)
        out << sol[i] << ' ';
}

void back(short k)
{
    for(short i = 1; i <= N && !ok; ++i)
    {
        sol[k] = i;
        if(ebun(k))
            if(k == N && !ok)
            {
                Tipar();
                ok = true;
            }
            else if(k < N)
                back(k + 1);
    }
}

int main()
{
    in >> N;
    back(1);
    out << '\n' << rez[N - 4];
    return 0;
}
