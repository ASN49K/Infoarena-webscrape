#include <bits/stdc++.h>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

int n,ok,nr,sol[20],sol_fin[20],fv1[40],fv2[40],fv3[40];
void beck(int k)
{
    int i;

    if(k==n+1)
    {
        nr++;
        if(ok==0)
        {
            for(i=1;i<k;i++)
                sol_fin[i]=sol[i];
            ok=1;
        }
    }
    else
    {
        for(i=1;i<=n;i++)
        {
            sol[k]=i;

            int dif=k-i;
            if(dif<0)dif=abs(dif)+13;

            fv1[i]++;
            fv2[i+k]++;
            fv3[dif]++;

            if(fv1[i]==1 && fv2[i+k]==1 && fv3[dif]==1)beck(k+1);

            fv1[i]--;
            fv2[i+k]--;
            fv3[dif]--;
        }
    }
}

int main()
{
    f>>n;
    beck(1);

    for(int i=1;i<=n;i++)g<<sol_fin[i]<<" ";
    g<<'\n'<<nr;
    return 0;
}
