#include <fstream>
using namespace std;

ifstream in("damesah.in");
ofstream out("damesah.out");

int n, a[14], t, m;
bool f[14], d1[28], d2[28];

void afis()
{
	if(t == 1)
	{
		for(int i = 1; i <= n; ++i)
			out << a[i] << ' ';
		out << '\n';
	}
}

void sol(int k)
{
	if(k > n) t++, afis();
	else
	{
		for(int i = 1; i <= n; ++i)
			if(!(f[i] || d1[n+k-i-1] || d2[i+k]))
			{
				a[++m] = i, f[i] = d1[n+k-i-1] = d2[i+k] = 1; 
				sol(k+1);
				m--, f[i] = d1[n+k-i-1] = d2[i+k] = 0;
			}
	}
}

int main()
{
	in >> n;
	sol(1);
	out << t;
	return 0;
}