#include <bits/stdc++.h>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

int n, column[15], principal[200], secundar[200], nr, sol[15];

void back(int linie) {
    if (linie > n) {
        if (nr < 1) {
            for (int c = 1; c <= n; c++)
                g<< sol[c] << " ";
            g<< "\n";
        }
        ++nr;
    } else {
        for (int coloana = 1; coloana <= n; coloana++) {
            if ((column[coloana] == 0) && (principal[linie - coloana + n] == 0) && (secundar[linie + coloana] == 0)) {
                sol[linie] = coloana;
                column[coloana] = coloana;
                principal[linie - coloana + n] = 1;
                secundar[linie + coloana] = 1;
                back(linie + 1);
                column[coloana] = 0;
                principal[linie - coloana + n] = 0;
                secundar[linie + coloana] = 0;
            }
        }
    }
}
int main() {
    f >> n;
    back(1);
    /*for ( int i = 1; i<= n ; i++)
        g << sol[i]<< " ";
    g << "\n";*/
    g << nr;
    return 0;
}