#include<bits/stdc++.h>

#define all(s) s.begin(),s.end()
#define rc(x) return cout<<x<<endl,0
#define forn(i,n) for(int i=0;i<int(n);i++)
#define pb push_back
#define mp make_pair
#define fr first
#define sc second

typedef long long ll;
typedef long double ld;

const int nmax=1025;
const int mod=998244353;
const ll inf=0x3f3f3f3f3f3f3f3f;

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n,t[20][20],sol,ok;

void baga()
{
    if(!ok)
    {
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
                if(t[i][j]) fout<<j<<" ";
        }
        fout<<"\n";
        ok=1;
    }
    sol++;
}

bool noatack(int a,int b)
{
    for(int i=1;i<a;i++)
    {
        if(a>i && t[a-i][b]) return 0;
        if(b>i && t[a][b-i]) return 0;
        if(a>i && b>i && t[a-i][b-i]) return 0;
        if(a>i && b+i<n+1 && t[a-i][b+i]) return 0;
    }
    return 1;
}

void back(int k)
{
    if(k==n+1) baga(); else
    {
        for(int i=1;i<=n;i++)
            if(noatack(k,i))
        {
            t[k][i]=1;
            back(k+1);
            t[k][i]=0;
        }
    }
}

int main()
{
  ios_base::sync_with_stdio(0); cin.tie(0);
  //freopen("damesah.in","r",stdin);
  //freopen("damesah.out","w",stdout);
  fin>>n;
  back(1);
  fout<<sol;
}
