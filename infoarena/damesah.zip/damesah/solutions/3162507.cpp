#include <fstream>
#include <deque>
using namespace std;
ifstream cin("damesah.in");
ofstream cout("damesah.out");
int n,fr[13],x[13],nr;
int modul(int a)
{
    if(a>=0)
        return a;
    else
        return -a;
}
int diag(int pas)
{
    for(int i=1;i<=pas-1;i++)
        if(modul(pas-i)==modul(x[pas]-x[i]))
        return 0;
    return 1;
}
void back(int pas)
{
    if(pas==n+1)
    {
        nr++;
        if(nr==1)
            for(int i=1;i<=n;i++)
            cout<<x[i]<<" ";
    }
    else
    {
        for(int i=1;i<=n;i++)
            if(fr[i]==0)
        {
            fr[i]=1;
            x[pas]=i;
            if(diag(pas))
                back(pas+1);
            fr[i]=0;

        }
    }
}
int main()
{
   cin>>n;
   back(1);
   cout<<'\n'<<nr;
    return 0;
}
