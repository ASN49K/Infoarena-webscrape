#include <bits/stdc++.h>
using namespace std ;
const int NR = 100002 ;
ifstream in ("damesah.in") ;
ofstream out ("damesah.out") ;

bool d [ 14 ][ 14 ] , sw ;
int n , cnt ;

void print()
{
    int i , j ;
    for (  i = 1 ; i <= n ; ++ i )
    for (  j = 1 ; j <= n ; ++ j )
    if ( d [ i ][ j ] ) cout << j << " " ;
    cout << "\n" ;
}

bool clearz ( int i , int j )
{
    int a , b , k ;
    for ( k = 1 ; k <= i ; ++ k )   if ( d [ k ][ j ] ) return false ;
    a = i , b = j ;
    for ( ; a && b <= n ; a -- , b ++ )
    {
        if ( d [ a ][ b ] ) return false ;
    }
    a = i , b = j ;
    for ( ; b && a ; a -- , b -- )
    {
        if ( d [ a ][ b ] ) return false ;
    }
    return true ;
}
int bt ( int level )
{
    if ( level == n + 1 )
    {
        if ( !sw ) print() , sw = true ;
        return ++ cnt , 0 ;
    }

    int j ;
    for ( j = 1 ; j <= n ; j ++ )
    {
        if ( clearz ( level , j ) )
        {
         d [ level ][ j ] = true ;
         bt ( level + 1 ) ;
         d [ level ][ j ] = false ;
        }
    }
    return 0 ;
}



int main ()
{
    cin >> n ;
    bt( 1 ) ;
    cout << cnt ;
}
