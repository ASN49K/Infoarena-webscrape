#include <fstream>
#include <cmath>
#include <stdlib.h>

using namespace std;

ifstream cin("damesah.in");
ofstream cout("damesah.out");

int x[15], uz[15], n, nrsol;

void gen(int k);

int valid(int k, int j);

int main()
{
    cin >> n;

    for(int i = 1; i <= n; i++)
    {
        x[1] = i;
        uz[i] = 1;
        gen(2);
        uz[i] = 0;
    }

    cout << nrsol;

    return 0;
}

int valid(int k, int j)
{
    if(uz[j] == 1)
        return 0;

    for(int i = 1; i < k; i++)
        if(abs(k - i) == abs(j - x[i]))
            return 0;

    return 1;
}

void gen(int k)
{
    if(k == n + 1)
    {
        if(nrsol == 0)
        {
            for(int i = 1; i <= n; i++)
                cout << x[i] << " ";

            cout << '\n';
            nrsol++;
        }
        else
            nrsol++;
    }

    else
        for(int j = 1; j <= n; j++)
            if(valid(k, j))
            {
                x[k] = j;
                uz[j] = 1;
                gen(k + 1);
                uz[j] = 0;
            }
}
