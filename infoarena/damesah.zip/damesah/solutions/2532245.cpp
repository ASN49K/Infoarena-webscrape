#include <fstream>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

int n;
int l[11], c[11], d1[11], d2[11];
int nr;

bool ok(int k)
{
    for (int i=1;i<k;i++)
        if (l[i]==l[k] || c[i]==c[k] || d1[i]==d1[k] || d2[i]==d2[k])
            return 0;
    return 1;
}

void bkt(int k)
{
    for (int j=1;j<=n;j++)
    {
        l[k]=l[k-1]+1, c[k]=j;
        d1[k]=l[k]+j-1, d2[k]=l[k]+n-j;
        if (ok(k))
        {
            if (k==n)
            {
                if (!nr)
                {
                    for (int x=1;x<=n;x++)
                        g<<c[x]<<" ";
                    g<<"\n";
                }
                nr++;
            }
            else
                bkt(k+1);
        }
    }
}

int main()
{
    f>>n;
    bkt(1);
    g<<nr;
    return 0;
}
