#include <bits/stdc++.h>

using namespace std;

ifstream fin ("damesah.in");
ofstream fout ("damesah.out");

const int NMAX = 40;
int st[NMAX], col[NMAX], diag1[NMAX], diag2[NMAX], n, rez;

void afisare() {
    rez++;
    if (rez == 1) {
        for (int i = 1; i <= n; i++)
            fout << st[i] << " ";
        fout << "\n";
    }
}

int f1(int i, int j) {
    return i + j - 1;
}

int f2(int i, int j) {
    return i + n - j;
}

void bkt(int k) {
    if (k == n + 1)
        afisare();
    else
        for (int i = 1; i <= n; i++) {
            if (col[i] == 0&& diag1[f1(k, i)] == 0 && diag2[f2(k, i)] == 0) {
                st[k] = i;
                col[i] = diag1[f1(k, i)] = diag2[f2(k, i)] = 1;
                bkt(k + 1);
                col[i] = diag1[f1(k, i)] = diag2[f2(k, i)] = 0;
            }
        }
}

int main() {

    fin >> n;
    bkt(1);
    fout << rez;

    return 0;
}
