#include <fstream>
#define sz 13
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n;

int c[sz + 2];
int d1[sz*2+2];
int d2[sz*2+2];
int q[sz+ 2];

bool ok = false;

int sol;

void backt(int pas)
{
    if(pas==n+1)
    {
        sol++;
        if(!ok)
        {
            ok = true;
            for(int i=1; i<=n; i++)
                fout<<q[i]<<' ';
            fout<<'\n';
        }
        return;
    }
    for(int i=1; i<=n; i++)
    {
        if(c[i]==0)
        {
            if(d1[i-pas + n])
                continue;
            if(d2[i+pas])
                continue;
            c[i] = pas;
            q[pas] = i;
            d1[i-pas+n]=true;
            d2[i+pas]=true;
            backt(pas+1);
            c[i] = 0;
            d1[i-pas+n]=false;
            d2[i+pas]=false;
            q[pas] = 0;
        }
    }


}

int main()
{
    fin>>n;
    backt(1);
    fout<<sol;
}
