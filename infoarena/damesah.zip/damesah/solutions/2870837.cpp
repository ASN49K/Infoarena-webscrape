#include <bits/stdc++.h>
#pragma GCC optimize ("Ofast")

using namespace std;

ifstream fin  ("damesah.in");
ofstream fout ("damesah.out");

const int MAX_N = 30;
int f[MAX_N], p[MAX_N], sol[MAX_N];
int n, config, found, check;

int _abs(int k){
    return (k < 0 ? -k : k);
}

void dame(int k){
    if(k > n){
        if(!found){
            found = 1;
            for(int i=1; i<=n; i++)
                sol[i] = p[i];
        }
        config++;
        return;
    }

    for(int i=1; i<=n; i++){

        check = true;
        for(int j=k-1; j>=1; j--)
            if(_abs(i - p[j]) == k - j){
                check = false;
                break;
            }

        if(check && !f[i]){
            f[i] = 1;
            p[k] = i;
            dame(k+1);
            f[i] = 0;
        }
    }
}

int main (){
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin>>n;
    dame(1);

    for(int i=1; i<=n; i++)
        fout<<sol[i]<<" ";
    fout<<"\n"<<config;
    return 0;
}
