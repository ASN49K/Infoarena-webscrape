#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n, sol, amAfisat;
int permutare[30];

bool seAtaca(int lin1, int col1, int lin2, int col2) {
    // lin1 < lin2
    if(lin2 - lin1 == col2 - col1 || lin2 - lin1 == col1 - col2) {
        return true;
    }
    return false;
}

void backtrack(int poz) {
    if(poz == n + 1) {
        if(!amAfisat) {
            for(int i = 1; i <= n; i++) {
                fout << permutare[i] << " ";
            }
            fout << "\n";
            amAfisat = 1;
        }
        sol++;
    }
    else {
        for(int val = 1; val <= n; val++) {
            bool isValid = true;
            for(int i = 1; i < poz; i++) {
                if(permutare[i] == val || seAtaca(i, permutare[i], poz, val)) {
                    isValid = false;
                }
            }
            if(isValid) {
                permutare[poz] = val;
                backtrack(poz + 1);
            }
        }
    }
}

int main() {
    
    fin >> n;
    backtrack(1);
    fout << sol << "\n";
    return 0;
}