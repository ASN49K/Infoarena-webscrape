#include <fstream>

using namespace std;
ifstream cin("damesah.in");
ofstream cout("damesah.out");
int n,sol=0;
bool v[15][15];
int dss[34];
int dsj[34];
int s[20];


 void solve ()
 {
     if(sol==1)
     {
         for(int i=1;i<=n;i++)
           for(int j=1;j<=n;j++)
           if(v[i][j]==1)
           cout<< j<<" ";
         cout<<'\n';
     }


 }
 void  submultimi(int pos)
 {
     if(pos==n+1)
     {

        sol++;
        solve();
        return;
     }

     for(int i=1;i<=n;i++)
     {


            if(!dss[pos-i+n] && !dsj[pos+i] && !s[i])
            {

                v[pos][i]=1;
                dss[pos-i+n]=1;
                dsj[pos+i]=1;
                s[i]=1;

                submultimi(pos+1);
                 dss[pos-i+n]=0;
                dsj[pos+i]=0;
                s[i]=0;
                v[pos][i]=0;


            }
     }
 }
int main()
{
    cin>>n;
    submultimi(1);
    cout<<sol;
    return 0;
}
