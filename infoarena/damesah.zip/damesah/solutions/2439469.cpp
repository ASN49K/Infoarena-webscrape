#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

int n, x[14], nrsol, v[14];

bool valid(int k)
{
    for(int i = 1; i < k; i++)
        if(x[k] == x[i] || k - i == abs(x[k] - x[i]))
            return 0;
    return 1;
}

void afis(int n)
{
    for(int i = 1; i <= n; i++)
        v[i] = x[i];
}

void backt()
{
    int k = 1;
    x[1] = 0;
    int ok = 1;
    while(k > 0)
        if(x[k] < n) ///mai avem elemente
        {
            x[k]++;///...cautare
            if(valid(k))///se verifica conditiile de continuare(v.c.c.)
            {
                if(k == n) ///este solutie
                {
                    if(ok)
                    {
                        afis(n);
                        ok = 0;
                    }
                    nrsol++;
                    ///k--;///se poate forta revenirea(doar la dame, iterativ)
                }
                else
                    x[++k] = 0; ///avansare+initializare
            }
        }
        else
            k--;///revenire
}
int main()
{
    f >> n;
    backt();
    for(int i = 1; i <= n; i++)
        g << v[i] << ' ';
    g << '\n';
    g << nrsol;
    return 0;
}
