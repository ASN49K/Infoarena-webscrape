#include <fstream>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
const int NMAX=15;
int st[NMAX+5];
bool viz[NMAX+5],dp[NMAX+50], ds[NMAX+50];
bool ok=0;
int n, s=0;
// Formula pentru diagonala secundara
//x+i-1
//Formula pentru diagonala principala
//x-i+n
void backt(int x)
{
    int i;
    if(x==n+1)
    {
        if(ok==0)
        {
          s=1;
          ok=1;
          for(i=1;i<=n;i++)
          {
             fout<<st[i]<<" ";
          }
           fout<<"\n";
        }
        else
            s++;
    }
    else
    {
        for(i=1;i<=n;i++)
        {
            if(ds[x+i-1]==0 and dp[x-i+n]==0 and viz[i]==0)
            {
                st[x]=i;
                viz[i] = ds[x+i-1] = dp[x-i+n] = 1;
               backt(x+1);
                 viz[i] = ds[x+i-1] = dp[x-i+n] = 0;
            }
        }
    }
}
int main()
{
    fin>>n;
    backt(1);
    fout<<s<<"\n";

    return 0;
}
