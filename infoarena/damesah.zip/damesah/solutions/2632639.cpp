#include <cstdio>

#define MAX_N 14

int queen[MAX_N];
bool col[MAX_N], main_diag[MAX_N * 2], sec_diag[MAX_N * 2];
int ans;

void bkt(FILE* fout, int l, int n) {
    if (l == n) {
        if (ans < 1) {
            for (int c = 0; c < n; c++)
                fprintf(fout, "%d ", queen[c] + 1);
            fprintf(fout, "\n");
        }
        ++ans;
    }
    else {
        for (int c = 0; c < n; c++) {
            if (!col[c] && !main_diag[c - l + n - 1] && !sec_diag[l + c]) {
                queen[l] = c;

                col[c] = main_diag[c - l + n - 1] = sec_diag[l + c] = true;
                bkt(fout, l + 1, n);
                col[c] = main_diag[c - l + n - 1] = sec_diag[l + c] = false;
            }
        }
    }
}

int main() {
    FILE* fin, * fout;

    fin = fopen("damesah.in", "r");
    int n;
    fscanf(fin, "%d", &n);
    fclose(fin);

    fout = fopen("damesah.out", "w");
    bkt(fout, 0, n);
    fprintf(fout, "%d\n", ans);
    fclose(fout);
}