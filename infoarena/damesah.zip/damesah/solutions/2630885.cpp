#include <iostream>
#include<math.h>
#include<fstream>
 using namespace std;
int n,s[20], k, sol;
ifstream f ("damesah.in");
ofstream g("damesah.out");
void citeste(){//cout<<"n=";
    f>>n; }
void afiseaza(){
   sol++;if(sol==1)
    {for (int i=1;i<=n;i++) g<<s[i]<<" ";//g<<"\n";
     }}
int valid (int k )

{for (int i=1; i<k; i++)
if((s[i]==s[k]) || (fabs(s[k]-s[i])== k-i))return 0;return 1; }
 void bkt (int k)
{ if(k==n+1) afiseaza();
else   for(int i=1;i<=n;i++)
    { s[k]=i;if (valid(k)) bkt (k+1); } }
 int main(){citeste(); bkt(1);  g<<sol;   return 0;}

