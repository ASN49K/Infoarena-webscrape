#include <iostream>
#include <fstream>
#include <string.h>
using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");


int k, as, ev, n, st[100], m, bri=0;

void init()
{
    st[k] = 0;
}

int abs(int a)
{
    if(a<0) return -a;
    return a;
}

int succesor()
{
    if(st[k]<n)
    {
        st[k] = st[k] + 1;
        return 1;
    }
    else return 0;
}

int valid()
{
    for(int i=1; i<k; i++)
        {if(st[k]==st[i]) return 0;
        if(abs(st[k]-st[i])==k-i) return 0;}
    return 1;
}

int solutie()
{
    return k==n;
}

void tipar()
{bri++;
    if(bri==1)
    {for(int i=1; i<=n; i++)
        g << st[i] << " ";
    g << '\n';}
}

void back()
{
    k=1;
    init();
    while(k>0)
    {
        as = 1; ev = 0;
        while(as && !ev)
        {
            as = succesor();
            if(as) ev = valid();
        }
        if(as)
            if(solutie()) tipar();
            else {k++; init();}
        else k--;
    }
}

int main()
{
    f >> n;
    back();
    g<<bri;
}
