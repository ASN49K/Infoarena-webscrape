#include <bits/stdc++.h>
#define pb push_back
#define optimize ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0)
#define ll long long
#define FILEIN "damesah.in"
#define FILEOUT "damesah.out"
using namespace std;
ifstream fin(FILEIN);
ofstream fout(FILEOUT);
void citire();
bool col[15];
int ans,n,s[15];
void rez();
int modul(int x)
{
	if(x<0)
		return -x;
	else
		return x;
}
bool valid(int k)
{
	for(int i=1;i<k;i++)
		if(modul(s[k]-s[i])==modul(k-i))
			return false;
	return true;

}
void bkt(int);
void afis();
int main()
{
	fin>>n;
	bkt(1);		
	fout<<ans;
}
void bkt(int k)
{
	if(k==n+1)
		{
			ans++;
			if(ans==1)
				afis();
		}
	else
		for(int i=1;i<=n;i++)
		{
			if(col[i]!=false)
				continue; 
			s[k]=i;
			col[i]=true;
			if(valid(k))
				bkt(k+1);
			col[i]=false;
		}
}
void afis()
{
	for(int i=1;i<=n;i++)
		fout<<s[i]<<" ";
	fout<<'\n';
}