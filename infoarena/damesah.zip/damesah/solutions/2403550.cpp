#include <bits/stdc++.h>

using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int n,cnt,C[30],P[30],S[30],sol[30];
void bkt(int);
int main()
{
    f>>n;
    bkt(1);
    g<<cnt<<'\n';
    return 0;
}
void bkt(int i)
{
    if(i==n+1)
    {
        cnt++;
        if(cnt==1)
        {
            for(int j=1;j<=n;j++)
                g<<sol[j]<<' ';
            g<<'\n';
        }
        return;
    }
    for(int j=1;j<=n;j++)
        if(C[j]+P[n+i-j]+S[i+j]==0)
        {
            C[j]=P[n+i-j]=S[i+j]=1;
            sol[i]=j;
            bkt(i+1);
            C[j]=P[n+i-j]=S[i+j]=0;
        }
}
