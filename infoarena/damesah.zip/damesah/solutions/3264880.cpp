#include <bits/stdc++.h>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
int n,v[15],fr[15],cnt;

bool ok(int x){
    for(int i=1;i<x;i++){
        if(v[i]-v[x] == x-i || v[x]-v[i] == x-i)
            return 0;
    }
    return 1;
}

void backtrack(int x){
    if(x <= n){
        for(int k=1;k<=n;k++){
            if(!fr[k]){
                fr[k]++;
                v[x] = k;
                if(ok(x))
                    backtrack(x+1);
                fr[k]--;
            }

        }
    }else{
        if(!cnt){
            for(int i=1;i<=n;i++){
                fout<<v[i]<<' ';
            }
            fout<<'\n';
        }
        cnt++;
    }
}
int main()
{
    fin>>n;
    backtrack(1);
    fout<<cnt;
    return 0;
}
