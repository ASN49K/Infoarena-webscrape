#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int n, nr;
vector <int> v;
int validare(int k)
{
	for (int i = 1; i <= k - 1; i++)
		if (v[i] == v[k] || abs(v[k] - v[i]) == abs(k - i))
			return 0;
	return 1;
}
void afisare(int k)
{
	for (int i = 1; i <= k; i++)
		g << v[i] << ' ';
	g <<"\n";
}
void bktr(int k)
{
	for (int i = 1; i <= n; i++)
	{
		v[k] = i;
		if (validare(k))
			if (n == k)
			{
				nr++;
				if(nr==1)
					afisare(k);
			}
			else bktr(k + 1);
	}

}
int main()
{
	f >> n;
	v.resize(n + 2);
	bktr(1);
	g << nr;
	f.close();
	g.close();
}
