#include <fstream>
#include <map>

using namespace std;

ifstream fin ("damesah.in");
ofstream fout("damesah.out");

const int DIM = 15;

int n, solCnt;
int sol[DIM];
bool isUsed[DIM], isPrinted;
map<int, bool> mainDiag, secDiag;

void backtrack(int step) {
    if (step == n + 1) {
        solCnt++;
        if (!isPrinted) {
            isPrinted = true;
            for (int i = 1; i <= n; i++)
                fout << sol[i] << ' ';
            fout << '\n';
        }
    } else {
        for (int i = 1; i <= n; i++) {
            if (!isUsed[i] && !mainDiag[step - i] && !secDiag[step + i]) {
                sol[step] = i;
                isUsed[i] = mainDiag[step - i] = secDiag[step + i] = true;
                backtrack(step + 1);
                isUsed[i] = mainDiag[step - i] = secDiag[step + i] = false;
            }
        }
    }
}

int main() {
    fin >> n;

    solCnt = 0;
    isPrinted = false;
    backtrack(1);
    fout << solCnt;

    return 0;
}