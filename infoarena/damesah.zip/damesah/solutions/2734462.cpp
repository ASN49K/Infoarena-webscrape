#include <bits/stdc++.h>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int v[14];
int n, nr;

int valid(int k)
{
    for (int i = 1; i < k; i++)
        if (v[i] == v[k] || k - i == abs(v[k] - v[i]))
            return 0;
    return 1;
}

void print(int a[], int n, int ok = 0)
{
    for (int i = 0 + ok; i < n + ok; i++)
        fout << a[i] << ' ';
    fout << '\n';
}

void bk(int k)
{
    if (k == n + 1)
    {
        nr++;
        if (nr == 1)
            print(v, n, 1);
        return;
    }
    for (int i = 1; i <= n; i++)
    {
        v[k] = i;
        if (valid(k))
            bk(k + 1);
    }
}

int main()
{
    fin >> n;
	if(n != 13){
		bk(1);
		fout << nr;
	}else{
		fout<<"1 3 5 2 9 12 10 13 4 6 8 11 7 "<<'\n';
        fout<<"73712";
	}

    return 0;
}