#include <fstream>
#include <cmath>
using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int n,k,nrsol,ok=1,x[14];
bool valid(int k)
{
    for (int i=1;i<k;i++)
        if (x[k]==x[i] || k-i==abs(x[k]-x[i])) return 0;
    return 1;
}
void afis()
{
    ok=0;
    for (int i=1;i<=n;i++)
        g<<x[i]<<' ';
    g<<'\n';
}
void backt(int k)
{
    for(int i=1; i<=n; i++)
    {
        x[k]=i;
        if(valid(k))
        {
            if(k==n)
            {
                nrsol++;
                if(ok) afis();
            }
            else
                backt(k+1);
        }
    }
}
int main()
{
    f>>n;
    backt(1);
    g<<nrsol;
    return 0;
}
