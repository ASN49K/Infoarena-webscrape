#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

int n;
int nrsol;
int uc[14],udp[40],uds[40];
int sol[14];

void back(int lin) {
    if(lin == n + 1){
        nrsol++;
        
        if(!nrsol) {
            for(int i = 1; i <= n; i++) {
                fout << sol[i] << " ";
            }
            fout << '\n';
        }
        
        return;
    } else {
        for(int col = 1; col <= n; col++) {
            if(!uc[col] && !udp[col - lin + n - 1] && !uds[lin + col]) {
                sol[lin] = col;
                uc[col] = udp[col - lin + n - 1] = uds[lin + col] = 1;
                back(lin + 1);
                uc[col] = udp[col - lin + n - 1] = uds[lin + col] = 0;
            }
            
        }
    }
}

int main(){
    fin >> n;
    
    back(1);
    
    fout << nrsol;
}
