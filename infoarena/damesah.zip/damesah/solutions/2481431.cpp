#include<fstream>
using namespace std;

ifstream fin("dame.in");
ofstream fout("dame.out");

int contor = 0;
bool write = 1;

int perm[20];
int col[20];
int diag1[20];
int diag2[20];

void back(int poz, int n)
{
	if(poz == n+1)
	{
		contor++;
		if(write == 1)
		{
			write = 0;
			for(int i = 1; i <= n; i++)
			{
				fout << perm[i] << " ";
			}
		}
		return;
	}

	for(int i = 1; i <= n; i++)
	{
		if(!col[i] && !diag1[i-poz+n] && !diag2[i+poz-1])
		{
			col[i] = 1;
			diag1[i-poz+n] = 1;
			diag2[i+poz-1] = 1;
			perm[poz] = i;
			back(poz+1, n);
			diag2[i+poz-1] = 0;
			diag1[i-poz+n] = 0;
			col[i] = 0;
		}
	}
}

int main()
{
	int n;
	fin >> n;
	fin.close();
	fout << "\n" << contor;
	fout.close();
}