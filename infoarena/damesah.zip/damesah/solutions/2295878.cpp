#include <bits/stdc++.h>

using namespace std;
int ok=0, z=0;
int diag(int k, int v[])
{int i;
    for(i=1;i<k;i++)
        if(abs(v[k]-v[i])==(k-i))
            return 0;
    return 1;
}
void afisare(int n, int v[], int viz[])
{int i,j;
    for(i=1;i<=n;i++)
        {for(j=1;j<=n;j++)
            {if(v[i]==j) cout<<v[i]<<" ";
             }
        }
}
void bkt(int k, int v[], int n, int viz[])
{int i;
 if(k==n+1) {if(ok==0) afisare(n,v,viz); ok=1; z++;}
    for(i=1;i<=n;i++)
    {
        v[k]=i;
        if(viz[i]==0 && diag(k,v))
        {
            viz[i]=1;
            bkt(k+1,v,n,viz);
            viz[i]=0;
        }
    }
}
int main()
{int viz[15]={0},n,v[15];
cin>>n;
bkt(1,v,n,viz);
cout<<"\n"<<z;
    return 0;
}
