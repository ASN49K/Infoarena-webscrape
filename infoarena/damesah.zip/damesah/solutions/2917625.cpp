#include <fstream>
#include <iostream>
#include <vector>
#define MAX 10000
using namespace std;

int n;
vector<vector<int>> ans;
vector<int> vis(20);
vector<int> diag1(40);
vector<int> diag2(40);
vector<int> partial;
int printed;
int count;

ifstream fin;
ofstream fout;

void queens(int length){
	if(length == n){
		++count;
		if(printed)
			return;
		for(auto elm: partial)
			fout << elm << " ";
		fout << "\n";
		printed = 1;
		return;
	}

	for(int i = 1; i <= n; ++i){
		if(!vis[i] && !diag1[i + length] && !diag2[i - length + n]){
			vis[i] = 1;
			diag1[i + length] = 1;
			diag2[i - length + n] = 1;
			partial.push_back(i);
			queens(length + 1);
			partial.pop_back();
			vis[i] = 0;
			diag1[i + length] = 0;
			diag2[i - length + n] = 0;
		}
	}

}

int main(){
	fin.open("damesah.in");
	fout.open("damesah.out"); 
	int m, q, a, b;

	fin >> n;
	n = 14;
	queens(0);
	fout << count << endl;

}