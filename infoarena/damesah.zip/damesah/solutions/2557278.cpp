#include <bits/stdc++.h>

using namespace std;
ifstream f("damesah.in");
ofstream g("damesah.out");
int nr,n,mat[100][100],col[15],diag1[100],diag2[100];
bool ok(int x,int y)
{
    if(col[y]==1)return 0;
    if(diag1[x+y]==1)return 0;
   int  dif=x-y;
    if(dif>0 and diag2[dif]==1)return 0;
    else if(diag2[30-dif]==1)return 0;
    return 1;
}
void dame(int i)
{
    int j;
    if(i<=n)
        for(j=1; j<=n; j++)
        {
            if(ok(i,j))
            {
                col[j]=1;
                diag1[i+j]=1;
               int  dif=i-j;
                if(dif>0)diag2[dif]=1;
                else diag2[30-dif]=1;
                mat[i][j]=1;
                dame(i+1);
                mat[i][j]=0;
                col[j]=0;
                diag1[i+j]=0;
                dif=i-j;
                if(dif>0)diag2[dif]=0;
                else diag2[30-dif]=0;
            }
        }
    else
    {
        nr++;
        if(nr==1)
        {
            for(int e=1; e<=n; e++)
                for(int l=1; l<=n; l++)if(mat[e][l]==1)g<<l<<" ";
            g<<'\n';
        }
    }
}

int main()
{
    f>>n;
    dame(1);
    g<<nr;
}
