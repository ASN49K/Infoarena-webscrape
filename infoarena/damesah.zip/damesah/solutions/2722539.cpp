/**
*/
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
vector <int> q;
int n,cont=0;
bool c[14],l[14],dp[100],ds[100];
void afisare()
{
    for(int i=0; i<q.size(); i++)
        fout<<q[i]<<" ";
    fout<<endl;
}
int valid(int linie,int col)
{
    if(c[col]!=0)
        return 0;
    if(l[linie]!=0)
        return 0;
    if(dp[n+col-linie]!=0)
        return 0;
    if(ds[col+linie-1]!=0)
        return 0;
    return 1;
}
void back(int linie)
{
    if(linie==n+1)
    {
        cont++;
        if(cont==1)
            afisare();
    }
    else
    {
        for(int j=1; j<=n; j++)
        {

            if(valid(linie,j)==1)
            {
                q.push_back(j);
                c[j]=1;
                l[linie]=1;
                dp[n+j-linie]=1;
                ds[j+linie-1]=1;
                back(linie+1);
                q.pop_back();
                c[j]=0;
                l[linie]=0;
                dp[n+j-linie]=0;
                ds[j+linie-1]=0;
            }


        }
    }

}
int main()
{
    fin>>n;
    back(1);
    fout<<cont;
    return 0;
}
