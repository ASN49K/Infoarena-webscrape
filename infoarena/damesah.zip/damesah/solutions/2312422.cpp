#include <fstream>

using namespace std;

ifstream fin("damesah.in");
ofstream fout("damesah.out");

static const int NMAX = 15;

int n;
int ct;
int v[NMAX];

bool used[NMAX];

void PrintSolution()
{
    for(int i =1; i<= n; ++i)
        fout << v[i] << " ";
    fout << endl;
    return;
}

bool Check(int k)
{
    if(k == 1)
        return true;
    if(v[k-1] == v[k]-1)
        return false;
    if(v[k-1] == v[k] + 1)
        return false;
    return true;
}

void Backtrack(int k)
{
    for(int i = 1; i<= n; ++i)
    {
        v[k] = i;
        if(!used[v[k]] && Check(k))
        {
            used[v[k]] = true;
            if(k == n)
            {
                ct++;
                if(ct == 1)
                    PrintSolution();
            }
            else
                Backtrack(k+1);
            used[v[k]] = false;
        }

    }
}

int main()
{
    fin >> n;
    Backtrack(1);
    fout << ct;
    return 0;
}
