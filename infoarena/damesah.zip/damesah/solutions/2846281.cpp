#include <bits/stdc++.h>
using namespace std;
bool f[15];
int n,a[15];
int ct=0;
ifstream fin("damesah.in");
ofstream fout("damesah.out");
bool Sol(int k)
{
    if(k!=n) return 0;
    return 1;
}
void Afisare()
{
    for(int i=1;i<=n;i++)
        fout<<a[i]<<" ";
    fout<<"\n";
}
bool ok(int i, int k)
{
    if(f[i]) return 0;
    if(i==a[k-1]+1||i==a[k-1]-1) return 0;
    int i1,k1;
    for(i1=i-1 ,k1=k-1;i1&&k1;i1--,k1--)
        if(a[k1]==i1) return 0;
    for(i1=i+1,k1=k-1;i1<=n&&k1;i1++,k1--)
        if(a[k1]==i1) return 0;
    return 1;
}
void Back(int k)
{
    if(k<=n)
    {
    for(int i=1;i<=n;i++)
    if(ok(i,k))
        {
            f[i]=1;
            a[k]=i;
            if(Sol(k))
            {
                if(!ct) Afisare();
                ct++;
            }
            else Back(k+1);
            f[i]=0;
        }
    }
}
int main ()
{
    fin>>n;
    Back(1);
    fout<<ct;
    return 0;
}
