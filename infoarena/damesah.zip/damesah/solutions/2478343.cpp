#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream f("damesah.in");
ofstream g("damesah.out");

int n, NumberOfSolutions;

vector <int> sol(14), viz(14);

void ShowSolution()
{
    for (int i = 1; i <= n; i++)
        g << sol[i] << " ";
    g << "\n";
}

void back_dame(int k)
{
    if (k == n + 1)
    {
        ++NumberOfSolutions;
        if (NumberOfSolutions == 1)
            ShowSolution();
        return;
    }

    for (int i = 1; i <= n; i++)
    {
        if (viz[i] == 0)
        {
            viz[i] = 1;
            sol[k] = i;
            int ok = 1;
            for (int j = 1; j < k; j++)
            {
                int v1 = sol[k] - sol[j];
                int v2 = sol[j] - sol[k];

                if (v1 >= 0 && v1 == k - j)
                    ok = 0;
                if (v1 < 0 && v2 == k - j)
                    ok = 0;

            }
            if (ok == 1)
                    back_dame(k + 1);
            viz[i] = 0;
        }
    }
}

int main()
{
    f >> n;

    back_dame(1);

    g << NumberOfSolutions;

    return 0;
}
