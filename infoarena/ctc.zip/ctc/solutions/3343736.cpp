#include <fstream>
#include <vector>
#define NMAX 100001
#define MMAX 200001
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n,m,nrctc;
vector<int> G[NMAX];
vector<int> Gt[NMAX];
vector<int> CTC[NMAX];
bool viz[NMAX];
int v[NMAX],nrv;

void dfs1(int x);
void dfs2(int x);
int main()
{
    int i,j,x,y;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
        Gt[y].push_back(x);
    }
    for(i=1;i<=n;i++)
        if(!viz[i]) dfs1(i);
    for(i=n;i>=1;i--)
        if(viz[v[i]])
        {
            nrctc++;
            dfs2(v[i]);
        }
    fout<<nrctc<<'\n';
    for(i=1;i<=nrctc;i++)
    {
        for(j=0;j<CTC[i].size();j++) fout<<CTC[i][j]<<' ';
        fout<<'\n';
    }

    return 0;
}
void dfs1(int x)
{
    int i;
    viz[x]=1;
    for(i=0;i<G[x].size();i++)
        if(!viz[G[x][i]])
        {
            viz[G[x][i]]=1;
            dfs1(G[x][i]);
        }
    v[++nrv]=x;
}
void dfs2(int x)
{
    int i;
    viz[x]=0;
    CTC[nrctc].push_back(x);
    for(i=0;i<Gt[x].size();i++)
        if(viz[Gt[x][i]])
        {
            viz[Gt[x][i]]=0;
            dfs2(Gt[x][i]);
        }
}
