#include <bits/stdc++.h>
#define NMAX 100010
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n,m,low[NMAX],i,k,viz[NMAX],x,y,onstack[NMAX],cc,ans[NMAX];
vector<int>v[NMAX],c[NMAX];
stack<int>s;
void tarjan(int node,int parent=0)
{
    viz[node]=low[parent]+1;
    s.push(node);
    onstack[node]=1;
    low[node]=low[parent]+1;
    for(auto it:v[node])
    {
            if(viz[it]==0)
                tarjan(it,node);
            if(onstack[it])
                low[node]=min(low[node],low[it]);
    }
    if(low[node]==viz[node])
    {
        cc++;
        while(s.top()!=node)
        {
            onstack[s.top()]=0;
            ans[s.top()]=cc;
            low[s.top()]=low[node];
            s.pop();
        }
        onstack[s.top()]=0;
        ans[s.top()]=cc;
        s.pop();
    }
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
    }
    for(i=1;i<=n;i++)
        if(viz[i]==0)
            tarjan(i);
    for(i=1;i<=n;i++)
        c[ans[i]].push_back(i);
    fout<<cc<<'\n';
    for(i=1;i<=cc;i++)
    {
        for(auto it:c[i])
            fout<<it<<" ";
        fout<<'\n';
    }
    return 0;
}
