#include <bits/stdc++.h>

using namespace std;

ifstream f("ctc.in");
ofstream g("ctc.out");

int n,m,k,x,y,r,viz[100200],low[100200],hi[100200];
vector <int> w[100200],edges[100200];
stack <int> st;

void tarjan(int x)
{
    st.push(x);
    viz[x]=1, low[x]=hi[x]=++k;
    for(auto y:edges[x])
        if(viz[y]==0)
            tarjan(y), low[x]=min(low[x],low[y]);
        else if(viz[y]==1)
            low[x]=min(low[x],hi[y]);
    if(low[x]==hi[x])
    {
        r++;
        while(!st.empty() and st.top()!=x)
            viz[st.top()]=2, w[r].push_back(st.top()), st.pop();
        viz[x]=2, w[r].push_back(x), st.pop();
    }
}

int32_t main()
{
    f>>n>>m;
    for(int i=1; i<=m; i++)
        f>>x>>y, edges[x].push_back(y);
    for(int i=1; i<=n; i++)
        if(viz[i]==0)
            tarjan(i);
    g<<r<<'\n';
    for(int i=1; i<=r; i++, g<<'\n')
        if(w[i].size())
            for(auto it:w[i])
                g<<it<<' ';
    return 0;
}
