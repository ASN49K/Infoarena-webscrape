#include <iostream>
#include <mutex>
#include <queue>
#include <string>
#include <vector>
#include <fstream>
#include <stack>
using namespace std;

void MatriceDeAdiacenta() {
    vector<vector<int> > matrice;
    int n, m;
    cin >> n >> m;
    matrice.resize(n + 1, vector<int>(n + 1, 0));
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        matrice[u][v] = matrice[v][u] = 1;
    }

    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++)
            cout << matrice[i][j] << ' ';
        cout << '\n';
    }
}

void ListaDeAdiacenta() {
    vector<vector<int> > lista_muchii;
    int n, u, v;

    cin >> n;
    lista_muchii.resize(n + 1);

    while (cin >> u >> v) {
        lista_muchii[u].push_back(v);
        lista_muchii[v].push_back(u);
    }

    for (int i = 1; i <= n; i++) {
        cout << "Vecinii nodului " << i << ": ";
        for (auto vecin : lista_muchii[i])
            cout << vecin << ' ';
        cout << '\n';
    }
}

void BFS_NEORIENTAT(int s) {
    vector<vector<int>> lista_noduri;
    int n, m, u, v;
    cin >> n >> m ;
    lista_noduri.resize(n+1);

    for (int i=1; i<= m; i++){
        cin >> u >> v;
        lista_noduri[u].push_back(v);
        lista_noduri[v].push_back(u);
    }

    vector<int> viz(n+1, 0), tata(n+1, 0), d(n+1, 2e9);
    priority_queue<int> q;

    q.push(s);
    viz[s] = 1;
    d[s] = 0;

    while (!q.empty()) {
        int nod = q.top();
        q.pop();
        for (auto vec:lista_noduri[nod]) {
            if (!viz[vec]) {
                q.push(vec);
                tata[vec] = nod;
                viz[vec] = 1;
                d[vec] = d[nod] + 1;
            }
        }
    }
}


void bfs_infoarena() {
    ifstream cin("bfs.in");
    ofstream cout("bfs.out");

    int n,m,s;
    cin>>n>>m>>s;
    vector<vector<int>> lista_adiacenta(n+1);
    vector<int> viz(n+1), tata(n+1), d(n+1, -1);
    queue<int> coada;

    for (int i = 1; i<=m; i++) {
        int u, v;
        cin >> u >> v;
        lista_adiacenta[u].push_back(v);
    }

    viz[s] = 1;
    d[s] = 0;
    coada.push(s);
    while (!coada.empty()) {
        int nod = coada.front();
        coada.pop();
        for (auto vec:lista_adiacenta[nod]) {
            if (!viz[vec]) {
                coada.push(vec);
                viz[vec] = 1;
                tata[vec] = nod;
                d[vec] = d[nod] + 1;
            }
        }
    }

    for (int i = 1; i<=n; i++) {
        cout << d[i]<<' ';
    }
}

void sortare_topologica() {
    ifstream cin("sortaret.in");
    ofstream cout("sortaret.out");
    int n, m;
    cin >> n >> m;
    vector<vector<int>> lista_adicaenta(n+1);
    vector<int> dg_in(n+1, 0), sortare;
    queue<int> coada;

    for (int i = 1; i<=m; i++) {
        int u,v;
        cin>>u>>v;
        lista_adicaenta[u].push_back(v);
        dg_in[v]++;
    }

    for (int nod = 1; nod<=n; nod++) {
        if (!dg_in[nod]) {
            coada.push(nod);
            sortare.push_back(nod);
        }
    }

    if (coada.empty()) {
        cout<<"nu exista o sortare topologica";
        return;
    }

    while (!coada.empty()) {
        int nod = coada.front();
        coada.pop();
        for (auto vec : lista_adicaenta[nod]) {
            dg_in[vec]--;
            if (!dg_in[vec]) {
                sortare.push_back(vec);
                coada.push(vec);
            }
        }
    }

    for (auto nod:sortare) {
        cout << nod <<' ';
    }
}

void dfs(int nod, vector<vector<int>>& lista_adiacenta, vector<bool>& viz, vector<int>& tata) {
    viz[nod] = true;
    for (auto vec:lista_adiacenta[nod]) {
        if (!viz[vec]) {
            tata[vec] = nod;
            dfs(vec, lista_adiacenta, viz, tata);
        }
    }
}

void dfs_componente_conexe() {
    ifstream cin("dfs.in");
    ofstream cout("dfs.out");
    int n , m;
    cin >> n >> m;

    vector<vector<int>> lista_adiacenta(n+1);
    vector<int> tata(n+1, 0);
    vector<bool> viz(n+1, false);

    for (int i = 1; i <= m; i++) {
        int u, v;
        cin>>u>>v;
        lista_adiacenta[u].push_back(v);
        lista_adiacenta[v].push_back(u);

    }

    int nr_componente_conexe = 0;
    for (int i = 1; i<=n; i++) {
        if (!viz[i]) {
            dfs(i, lista_adiacenta, viz, tata);
            nr_componente_conexe++;
        }
    }

    cout<<nr_componente_conexe;
}
void dfs_muchie_critica(int nod, vector<vector<int>> & lista_adiacenta, vector<bool> &viz, vector<int> &nvl_min, vector<int> & nvl_cur) {
    viz[nod] = true;
    nvl_min[nod] = nvl_cur[nod];
    for (auto vec: lista_adiacenta[nod]) {
        if (!viz[vec]) {
            nvl_cur[vec] = nvl_cur[nod] + 1;
            dfs_muchie_critica(vec, lista_adiacenta, viz, nvl_min, nvl_cur);

            nvl_min[nod] = min(nvl_cur[nod], nvl_min[vec]);

            if (nvl_min[vec] > nvl_cur[nod])
                cout<<nod << ' '<<vec << "este muchie critica";
        } else {
            if (nvl_cur[vec] < nvl_cur[nod]-1 )
                nvl_min[nod] = min(nvl_cur[nod], nvl_min[vec]);
        }
    }
}

void detectare_muchie_critica() {

}
void kosaraju_dfs(int nod, vector<vector<int>> & lista_adiacenta, vector<bool> &viz, stack<int> & stiva) {
    viz[nod] = true;
    for (auto vec: lista_adiacenta[nod]) {
        if (!viz[vec]) {
            kosaraju_dfs(vec, lista_adiacenta, viz, stiva);
        }
    }
    stiva.push(nod);
}

void kosaraju_dfs_gt(int nod, vector<vector<int>>& lista_adiacenta, vector<bool> &viz, vector<int>& comp, stack<int> &stiva ) {
    viz[nod] = true;
    for (auto vec: lista_adiacenta[nod]) {
        if (!viz[vec]) {
            kosaraju_dfs_gt(vec, lista_adiacenta, viz, comp, stiva);
        }
    }
    comp.push_back(nod);
    stiva.pop();
}
void kosaraju() {
    ifstream cin("ctc.in");
    ofstream cout("ctc.out");
    int n, m;
    cin>>n>>m;

    vector<vector<int>> g_lista_adiacenta(n+1), gt_lista_adiacenta(n+1);
    vector<bool> viz(n+1), viz2(n+1);
    vector<int> tata(n+1);
    stack<int> stiva;

    for (int i=1; i<=m; i++) {
        int u, v;
        cin>>u>>v;
        g_lista_adiacenta[u].push_back(v);
        gt_lista_adiacenta[v].push_back(u);
    }

    for (int i=1; i<=n; i++) {
        if (!viz[i]) {
            kosaraju_dfs(i, g_lista_adiacenta, viz, stiva);
        }
    }

    vector<vector<int>> comp_ctc;
    while (!stiva.empty()) {
        vector<int> comp;
        kosaraju_dfs_gt(stiva.top(), gt_lista_adiacenta, viz2, comp, stiva);
        comp_ctc.push_back(comp);
    }
    cout<<comp_ctc.size()<<'\n';
    for (auto comp: comp_ctc) {
        for (auto nod:comp) {
            cout<<nod<<' ';
        }
        cout<<'\n';
    }

}
int main() {
    kosaraju();
}
