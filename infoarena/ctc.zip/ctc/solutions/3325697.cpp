#include <fstream>
#include <vector>
using namespace std;
ifstream fin ("ctc.in");
ofstream fout ("ctc.out");
const int DIM = 100000;
vector <int> v[DIM + 1], vt[DIM + 1], l;
vector <vector <int>> sol;
bool vis[DIM + 1];
int n, m, k, s[DIM + 1];
void read ()
{
    int x, y;
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y;
        v[x].push_back (y);
        vt[y].push_back (x);
    }
}
void dfs1 (int nod)
{
    vis[nod] = 1;
    for (int i = 0; i < (int) v[nod].size (); i++)
    {
        int vecin = v[nod][i];
        if (!vis[vecin])
            dfs1 (vecin);
    }
    s[++k] = nod;
}
void dfs2 (int nod)
{
    vis[nod] = 1;
    l.push_back (nod);
    for (int i = 0; i < (int) vt[nod].size (); i++)
    {
        int vecin = vt[nod][i];
        if (!vis[vecin])
            dfs2 (vecin);
    }
}
void solve ()
{
    for (int i = 1; i <= n; i++)
    {
        if (!vis[i])
            dfs1 (i);
    }
    for (int i = 1; i <= n; i++)
        vis[i] = 0;
    for (int i = n; i > 0; i--)
    {
        if (!vis[s[i]])
        {
            l.clear ();
            dfs2 (s[i]);
            sol.push_back (l);
        }
    }
}
void print ()
{
    fout << sol.size () << "\n";
    for (int i = 0; i < (int) sol.size (); i++)
    {
        for (int j = 0; j < (int) sol[i].size (); j++)
            fout << sol[i][j] << " ";
        fout << "\n";
    }
}
int main ()
{
    read ();
    solve ();
    print ();
    return 0;
}
