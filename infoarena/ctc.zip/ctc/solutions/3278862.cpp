#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

const int nmax = 100005;
vector<int> a[nmax], at[nmax], rez[nmax];
int pos[nmax], viz[nmax], nr, nrc,n,m;

void dfs(int x) {
    viz[x] = 1;
    for (int i = 0; i < a[x].size(); ++i) {
        if (!viz[a[x][i]]) {
            dfs(a[x][i]);
        }
    }
    pos[++nr] = x;
}

void dfst(int x) {
    viz[x] = 0;
    rez[nrc].push_back(x);
    for (int i = 0; i < at[x].size(); ++i) {
        if (viz[at[x][i]]) {
            dfst(at[x][i]);
        }
    }
}

int main() {
    ifstream be("ctc.in");
    ofstream ki("ctc.out");

    be >> n >> m;


    for (int i = 1; i <= m; ++i) {
        int x, y;
        be >> x >> y;
        a[x].push_back(y);
        at[y].push_back(x);
    }

    for (int i = 1; i <= n; ++i) {
        if (!viz[i]) {
            dfs(i);
        }
    }


    for (int i = n; i >= 1; --i) {
        if (viz[pos[i]]) {
            ++nrc;
            rez[nrc].clear();
            dfst(pos[i]);
        }
    }


    ki << nrc << '\n';

    for (int i = 1; i <= nrc; ++i) {
        for (int j = 0; j < rez[i].size(); ++j) {
            ki << rez[i][j] << ' ';
        }
        ki << '\n';
    }


    return 0;
}