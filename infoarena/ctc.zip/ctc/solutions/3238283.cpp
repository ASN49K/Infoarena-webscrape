#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n, m;
int x, y;
int ans; /// nr de componente tari conexe (ctc)
vector<int> ctc [100005]; ///matrice care retine pe fiecare linie, nodurile unei componente tari conexe
vector<vector<int>> gr, grtrans;
vector<bool> vizitat;
stack<int> st;
void DFS(int nod){
    vizitat[nod]=true;
    for (int i : gr[nod]){
        if (vizitat[i]==false){
            DFS(i);
        }
    }
    st.push(nod);
}
void DFStrans(int nod){
    ctc[ans].push_back(nod);
    vizitat[nod]=true;
    for(int i : grtrans[nod]){
        if (vizitat[i]==false){
            DFStrans(i);
        }
    }
}
int main()
{
    fin >> n >> m;
    gr.resize(n+1);
    grtrans.resize(n+1);
    vizitat.resize(n+1, false);
    for(int i=1; i<=m; ++i){
        fin >> x >> y;
        gr[x].push_back(y);
        grtrans[y].push_back(x); ///graful transpus (muchii opuse)
    }
    for(int i=1; i<=n; ++i){
        if (vizitat[i]==false){
            DFS(i); ///umplu stacku
        }
    }
    vizitat.clear();
    vizitat.resize(n+1,false);
    int nod;
    while(!st.empty()){
        nod=st.top();
        if (vizitat[nod]==false){
            DFStrans(nod);
            ans++;
        }
        st.pop();
    }
    fout << ans << '\n';
    for (int i=0; i<ans; ++i){
        for (int j=0; j<ctc[i].size(); ++j){
            fout << ctc[i][j] << ' ';
        }
        fout << '\n';
    }
    return 0;
}
