#include <bits/stdc++.h>
#include <cstring>
#include <cstdio>
#pragma GCC optimize ("O3")
#define din cin
#define dout out
#define pi 3.14159265359
#define sw(x,y) x^=y,y^=x,x^=y
#define bmin(a,b)((a<b)?(a):(b))
#define bmax(a,b)((a>b)?(a):(b))
#define bminify(a,b)a=bmin(a,b)
#define bmaxify(a,b)a=bmax(a,b)
#define forq(i,ii,n)for(i=ii;i<n;i++)
#define f first
#define s second
#define mod 1000000007ll
#define nmax 200002
#define lim 351
using namespace std;
typedef long long ll;
ifstream in("ctc.in");
ofstream out("ctc.out");
//FILE *fin=fopen("infasuratoare.in","r");
//FILE *fout=fopen("infasuratoare.out","w");
int n,m,i,j,k,l,c[nmax],f[nmax],p[nmax],q[nmax],z,r,b[nmax];vector<int>g[nmax],o[nmax];
void tr(int v){
    //cout<<v<<'v';
    p[v]=q[v]=++z,c[l++]=v,b[v]=1;
    for(auto i:g[v])
        if(p[i]==0)
            tr(i),bminify(q[v],q[i]);
            else if(b[i]) bminify(q[v],p[i]);
    if(q[v]==p[v]){
        ++r;
        do{
            o[v].emplace_back(c[--l]),b[c[l]]=0;
        }while(c[l]!=v);
    }
}
int main()
{
in>>n>>m;
for(k=0;k<m;k++)in>>i>>j,g[i].emplace_back(j);
tr(1);
out<<r;
for(i=1;i<=n;i++)
    if(p[i]==q[i]){
        out<<'\n';
        for(auto j:o[i])out<<j<<' ';
}
}
