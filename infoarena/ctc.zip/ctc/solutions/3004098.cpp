#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <stack>

///Through The Fire And Flames...

using namespace std;

ifstream fin ("ctc.in");
ofstream fout ("ctc.out");

const int NMAX=1e5+5;

vector<int>v[NMAX];
vector<int>comp[NMAX];
vector<int>rev[NMAX];

int color[NMAX];
stack<int>stiva;

bool viz[NMAX];
int kon;

void dfs(int p)
{
    viz[p]=true;
    for(auto i:v[p])
    {
        if(!viz[i])
            dfs(i);
    }
    stiva.push(p);
}

void dfsc(int p)
{
    viz[p]=true;
    color[p]=kon;
    comp[kon].push_back(p);
    for(auto i:rev[p])
    {
        if(!viz[i])
            dfsc(i);
    }
}

int main()
{
    int n,m,i,j;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        rev[y].push_back(x);
    }
    for(i=1;i<=n;i++)
        if(!viz[i])
            dfs(i);
    for(i=1;i<=n;i++)
        viz[i]=false;
    while(!stiva.empty())
    {
        int p=stiva.top();
        if(!viz[p])
        {
            kon++;
            dfsc(p);
        }
        stiva.pop();
    }
    fout<<kon<<"\n";
    for(i=1;i<=kon;i++)
    {
        for(auto j:comp[i])
            fout<<j<<" ";
        fout<<"\n";
    }
    return 0;
}
