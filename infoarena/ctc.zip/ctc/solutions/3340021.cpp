//https://infoarena.ro/problema/ctc

//#pragma GCC optimize("O3")   
//#pragma GCC optimize("Ofast") 
//#pragma GCC optimize("fast-math") 
//#pragma GCC optimize("unroll-loops") 
//#pragma GCC optimize("inline")  
//#define _USE_MATH_DEFINES
//#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <fstream>
#include <vector>
//#include <cstring>
//#include <cmath>
//#include <bitset>
//#include <queue>
//#include <stack>
//#include <utility>
//#include <algorithm>
//#include <string>
//#include <map>
//#include <unordered_map>
//#include <set>
//#include <unordered_set>
//#include <cstdint>
//#include <climits>
//#include <iomanip>
//#include <cstdio>
//#include <tuple>

using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

const int NMAX = 100000;
const int MMAX = 200000;

vector<int> gr[NMAX + 1];
vector<int> igr[NMAX + 1];
vector<int> rez[NMAX + 1];
vector<int> st;
bool b[NMAX + 1];

void dfs(int x, const vector<int> g[], vector<int>& r)
{
	b[x] = true;
	for (const auto& it : g[x])
	{
		if (!b[it])
		{
			dfs(it, g, r);
		}
	}
	r.push_back(x);
}

int main()
{
	//ios_base::sync_with_stdio(false);
	//cin.tie(nullptr);
	//cout.tie(nullptr);

	int n, m, x, y, i, k = 0;

	fin >> n >> m;

	for (i = 1; i <= m; ++i)
	{
		fin >> x >> y;
		gr[x].push_back(y);
		igr[y].push_back(x);
	}
	
	for (i = 1; i <= n; ++i)
	{
		if (!b[i])
			dfs(i, gr, st);
	}
	
	memset(b, false, sizeof b);
	
	for (i = n - 1; i >= 0; --i)
	{
		//cout << st[i] << " ";
		if (!b[st[i]])
			dfs(st[i], igr, rez[k++]);
	}

	fout << k << "\n";

	for (i = 0; i < k; ++i)
	{
		for (const auto& it : rez[i])
			fout << it << " ";

		fout << "\n";
	}

	return 0;
}