#include <bits/stdc++.h>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
vector<int> ord;
vector<int> viz;
vector<vector<int>> ctc;
vector<vector<int>> graph;
vector<vector<int>> graphRev;
void dfs1(int node)
{
    viz[node] = 1;
    for(auto it = graph[node].begin(); it != graph[node].end(); it++)
    {
        if(!viz[(*it)])
            dfs1((*it));
    }
    ord.push_back(node);
}
void dfs2(int node, int cnt)
{
    ctc[cnt].push_back(node);
    viz[node] = 1;
    for(auto it = graphRev[node].begin(); it != graphRev[node].end(); it++)
    {
        if(!viz[(*it)])
            dfs2((*it), cnt);
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    int n, m;
    cin >> n >> m;
    graph.resize(n + 5);
    graphRev.resize(n + 5);
    viz.resize(n + 1);
    for(int i = 0; i < m; i++)
    {
        int x, y;
        cin >> x >> y;
        graph[x].push_back(y);
        graphRev[y].push_back(x);
    }
    for(int i = 1; i <= n; i++)
    {
        if(!viz[i])
            dfs1(i);
    }
    // for(auto it = ord.begin(); it != ord.end(); it++)
    // {
    //     cout << (*it) << " ";
    // }
    // cout << "\n";
    viz.clear(); viz.resize(n + 1);
    int cnt = 0;
    for(auto it = ord.rbegin(); it != ord.rend(); it++)
    {
        if(!viz[(*it)])
        {
            ctc.push_back(vector<int>());
            dfs2((*it), cnt);
            cnt++;
        }
    }
    cout << cnt << "";
    for(int i = 0; i < cnt; i++)
    {
        cout << "\n";
        sort(ctc[i].begin(), ctc[i].end());
        for(auto it = ctc[i].begin(); it != ctc[i].end(); it++)
        {
            cout << (*it) << " ";
        }
    }
}
