#include <bits/stdc++.h>
#define MOD 666013
using namespace std;
///aproapeperm
ifstream fin("ctc.in");
ofstream fout("ctc.out");

int n, m, nrC;
stack<int> st;
bitset<100005> viz;
vector<int> L[100005], T[100005], sol[100005];

void DFS(int k)
{
    viz[k] = 1;
    for (int i : L[k])
        if (viz[i] == 0)
            DFS(i);
    st.push(k);
}
void DFST(int k)
{
    viz[k] = 1;
    sol[nrC].push_back(k);
    for (int i : T[k])
        if (viz[i] == 0)
            DFST(i);
}

int main()
{
    int i, j;
    fin >> n >> m;
    while (m--)
    {
        fin >> i >> j;
        L[i].push_back(j);
        T[j].push_back(i);
    }
    for (i = 1; i <= n; i++)
        if (viz[i] == 0)
            DFS(i);
    viz.reset();
    while (!st.empty())
    {
        i = st.top();
        st.pop();
        if (viz[i] == 0)
        {
            nrC++;
            DFST(i);
        }
    }
    fout << nrC << "\n";
    for (i = 1; i <= nrC; i++)
    {
        for (int w : sol[i])
            fout << w << " ";
        fout << "\n";
    }
    return 0;
}
