#include <bits/stdc++.h>

using namespace std;
#define int long long int
#define pb push_back
const int N = 1e5 + 5;

vector<int> g[N], gt[N], ct[N];

int n, m, ctc, used[N];
stack<int> stk;

void dfs(int node) {
    used[node] = 1;
    for (auto it : g[node]) {
        if (!used[it]) {
            dfs(it);
        }
    }
    stk.push(node);
}

void dfs_2(int node) {
    ct[ctc].push_back(node);
    used[node] = 1;
    for (auto it : gt[node]) {
        if (!used[it]) {
            dfs_2(it);
        }
    }
}

signed main() {
    cin.tie(nullptr)->sync_with_stdio(false);
    freopen("ctc.in", "r", stdin);
    freopen("ctc.out", "w", stdout);
    cin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int u, v;
        cin >> u >> v;
        g[u].pb(v);
        gt[v].pb(u);
    }
    for (int i = 1; i <= n; i++) {
        if (!used[i]) {
            dfs(i);
        }
    }
    for (int i = 1; i <= n; i++) {
        used[i] = 0;
    }
    while (!stk.empty()) {
        int node = stk.top();
        stk.pop();
        if (!used[node]) {
            ++ctc;
            dfs_2(node);
        }
    }
    cout << ctc << '\n';
    for (int i = 1; i <= ctc; i++) {
        for (auto it : ct[i]) {
            cout << it << ' ';
        }
        cout << '\n';
    }
}
