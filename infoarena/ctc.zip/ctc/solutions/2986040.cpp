#include<bits/stdc++.h>
using namespace std;
const int dim=100002;
ifstream f("ctc.in");
ofstream g("ctc.out");
int n,m,k=0;
int nr=0;
vector <int> ctc[dim];
vector <int> v[dim];
vector <int> w[dim];
int viz[dim];

int st[dim];

void DFS(int nod)
{
    viz[nod] = 1;
    for(int i = 0; i < v[nod].size(); i++)
    {
        int vecin = v[nod][i];
        if(!viz[vecin])
        {
            DFS(vecin);
        }
    }
    st[k--]=nod;
}

void DFS2(int nod)
{
    viz[nod] = 2;
    ctc[nr].push_back(nod);
    for(int i = 0; i < w[nod].size(); i++)
    {
        int vecin = w[nod][i];
        if(viz[vecin] == 1)
        {
            DFS2(vecin);
        }
    }
}

int main()
{
    int i;
    f>> n >> m;
    k=n;
    for(i = 1; i <= m; i++)
    {
        int x,y;
        f >> x >> y;

        v[x].push_back(y);
        w[y].push_back(x);
    }

    for(i = 1; i<= n; i++)
    {
        if(!viz[i])
        {
            DFS(i);
        }
    }

    k=1;
    while(k<=n)
    {
        int nod = st[k];

        if(viz[nod] == 1)
            nr++,DFS2(nod);

        k++;
    }

    g <<nr << "\n";
    for(i = 1; i <= nr; i++)
    {
        for(int j = 0; j < ctc[i].size(); j++)
        {
            g << ctc[i][j] << " ";
        }
        g << "\n";
    }

    return 0;
}
