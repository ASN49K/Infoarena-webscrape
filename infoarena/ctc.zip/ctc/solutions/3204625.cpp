#include <fstream>
#include <vector>
#define NMAX 100009
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
bool uz[NMAX];
int postordine[NMAX],lg,nrc;
vector <int> g[NMAX];
vector <int> gt[NMAX];
vector <int> comp[NMAX];
int n,m;
void DFS1(int x);
void DFS2(int x);
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        g[x].push_back(y);
        gt[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(!uz[i])
        {
            DFS1(i);
        }

    for(int i=n;i>=1;i--)
        if(uz[postordine[i]])
        {
            nrc++;
            DFS2(postordine[i]);
        }
    fout<<nrc<<'\n';
    for(int i=1;i<=nrc;i++)
    {
        for(int j=0;j<comp[i].size();j++)
            fout<<comp[i][j]<<' ';
        fout<<'\n';
    }
    return 0;
}
void DFS1(int x)
{
    uz[x]=1;
    for(int i=0;i<g[x].size();i++)
        if(!uz[g[x][i]])
        {
            uz[g[x][i]]=1;
            DFS1(g[x][i]);
        }
    postordine[++lg]=x;

}
void DFS2(int x)
{
    uz[x]=0;
    for(int i=0;i<gt[x].size();i++)
        if(uz[gt[x][i]])
        {
            uz[gt[x][i]]=0;
            DFS2(gt[x][i]);
        }
    comp[nrc].push_back(x);

}
