#include <fstream>
#define pb push_back
#include <vector>
#include <set>
using namespace std;
ifstream cin ("ctc.in");
ofstream cout ("ctc.out");
int n,m;
vector <int> g[100005],gt[100005];
int q[100005];
int vf;
int nrc;
vector<int> componente[100005];
bool u[100005];
int nrcomp;
void dfs (int x)
{
    u[x] = true;
    for (auto vf:g[x])
    {
        if (u[vf]==true)
            continue;
        dfs(vf);
    }
    q[++vf] = x;
}
void dfs1 (int x)
{
    u[x] = true;
    for (auto vf:gt[x])
    {
        if (u[vf]==true)
            continue;
        dfs1(vf);
    }
    componente[nrcomp].pb(x);
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    int i,j;
    for (i=1;i<=m;i++)
    {
        int x,y;
        cin >> x >> y;
        g[x].pb(y);
        gt[y].pb(x);
    }
    for (i=1;i<=n;i++)
        if (!u[i])
            dfs(i);
    for (i=1;i<=n;i++)
        u[i] = false;
    for (i=vf;i>=1;i--)
        if (!u[q[i]])
        {
            nrcomp++;
            vf = q[i];
            dfs1(vf);
        }
    cout << nrcomp << '\n';
    for (i=1;i<=nrcomp;i++)
    {
        for (auto e:componente[i])
            cout << e << ' ';
        cout << '\n';
    }
    return 0;
}
