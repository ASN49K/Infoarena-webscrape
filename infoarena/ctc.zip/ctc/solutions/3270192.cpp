#include <fstream>
#include <vector>
#define NMAX 100003
using namespace std;
ifstream fin ("ctc.in");
ofstream fout ("ctc.out");
int n, m;
///graful initial reprezentat prin liste de adiacenta
vector <int> G[NMAX];
///graful transpus reprezentat prin liste de adiacenta
vector <int> Gt[NMAX];
vector <int> ctc[NMAX]; ///ctc[i] contine vf din componenta tare-conexa i
int post[NMAX], nr, nrc;
bool viz[NMAX];
void citire()
{
    int m, i, x, y;
    fin>>n>>m;
    for(i=0; i<m; i++)
    {
        fin>>x>>y;
        ///exista arc de la x la y in G
        G[x].push_back(y);
        ///exista arc de la y la x in Gt
        Gt[y].push_back(x);
    }
}
void DFS(int x)
{
    int i;
   viz[x]=1;
   ///parcurg lista de adiacenta a lui x
   for(i=0; i<G[x].size(); i++)
    if(!viz[G[x][i]]) DFS(G[x][i]);
   post[++nr]=x;
}
void DFST(int x)
{
    int i;
    viz[x]=0;
    ctc[nrc].push_back(x);
    for(i=0; i<Gt[x].size(); i++)
    if(viz[Gt[x][i]]) DFST(Gt[x][i]);
}
void afisare()
{
    int i, j;
    fout<<nrc<<'\n';
    for(i=1; i<=nrc; i++)
        ///afisez vf din ctc i
    {
        for(j=0; j<ctc[i].size(); j++)
            fout<<ctc[i][j]<<' ';
        fout<<'\n';
    }
}
int main()
{
    int i;
    citire();
    ///parcurgem DFS pe G si construiesc vectorul post
    for(i=1; i<=n; i++)
        if(!viz[i]) DFS(i);
    ///parcurg vectorul post de la dreapta la stanga si fac DFS in vectorul transpus
    for(i=n; i>0; i--)
        if(viz[post[i]]) ///post[i] este nevizitat in graful transpus
    {
        ///am identificat o noua componenta tare-conexa
        nrc++;
        DFST(post[i]);
    }
    ///afisare
    afisare();
    return 0;
}
