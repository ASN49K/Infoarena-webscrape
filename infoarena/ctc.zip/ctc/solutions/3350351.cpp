#include <bits/stdc++.h>

const int NMAX = 1005;

bool onStack[NMAX];
int low[NMAX], disc[NMAX];
std::vector<int> graph[NMAX];
std::stack<int> st;
std::vector<std::vector<int>> sccs;

void compute_sccs(int from) {
    static int time = 0;
    low[from] = disc[from] = ++time;
    onStack[from] = true;
    st.push(from);

    for(int to : graph[from]) {
        if(!onStack[to]) {
            compute_sccs(to);

            low[from] = std::min(low[from], low[to]);
        }
        else {
            low[from] = std::min(low[from], low[to]);
        }
    }

    if(low[from] == disc[from]) {
        int top;
        std::vector<int> scc;

        do {
            top = st.top();
            st.pop();
            scc.push_back(top);
        } while(top != from);

        sccs.push_back(scc);
    }
}

int main() {
    int n, m;
    std::cin >> n >> m;

    for(int i = 0; i < m; ++i) {
        int x, y;
        std::cin >> x >> y;
        graph[x].push_back(y);
    }

    for(int i = 1; i <= n; ++i) {
        if(!low[i]) {
            compute_sccs(i);
        }
    }

    std::cout << sccs.size() << '\n';

    for(std::vector<int> scc : sccs) {
        for(int c : scc) {
            std::cout << c << ' ';
        }std::cout << '\n';
    }

    return 0;
}
