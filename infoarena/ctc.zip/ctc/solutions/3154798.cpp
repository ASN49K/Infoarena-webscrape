#include <bits/stdc++.h>
#define VI vector<int>
#define VVI vector<VI>
#define PI pair <int, int>
#define F first
#define S second
using namespace std;
const int N = 1e5 + 9;

int n, m, a, b;
VVI G;

int lvl[N], low[N], comp[N], idx, cnt;
bool instk[N];
stack<int> stk;
void Dfs(int x)
{
    stk.push(x);
    instk[x] = true;
    lvl[x] = low[x] = ++idx;

    for(auto y : G[x])
        if(!lvl[y]){
            Dfs(y);

            low[x] = min(low[x], low[y]);
        }
        else if(instk[y])low[x] = min(low[x], lvl[y]);

    if(low[x] == lvl[x])
    {
        ++cnt;
        while(true)
        {
            int a = stk.top();
            stk.pop();
            instk[a] = false;
            comp[a] = cnt;
            if(a == x)break;
        }
    }
}
void Tarjan()
{
    for(int i = 1; i <= n; ++i)
        if(!lvl[i])
            Dfs(i);
}

int main()
{
    freopen("ctc.in", "r", stdin);
    freopen("ctc.out", "w", stdout);

    cin >> n >> m;
    G = VVI(n + 1);
    while(m --)
    {
        cin >> a >> b;
        G[a].push_back(b);
    }

    Tarjan();

    VVI CTC = VVI(cnt + 1);
    for(int i = 1; i <= n; ++i)
        CTC[comp[i]].push_back(i);

    cout << cnt << '\n';
    for(int i = 1; i <= cnt; ++i, cout << '\n')
        for(auto j : CTC[i])
            cout << j << ' ';
    return 0;
}
