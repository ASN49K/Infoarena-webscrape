#include <fstream>
#include <vector>

using namespace std;

/// Algoritmul lui Tarjan in n

const int NMAX = 1e5;

vector<int> graf[1 + NMAX];

vector<vector<int>> ctc;

vector<int> stiva;

bool peStiva[1 + NMAX];

int indexNod[1 + NMAX];
int indexIntoarcereNod[1 + NMAX];

int index = 0;

void dfs(int nod)
{
    stiva.emplace_back(nod);
    peStiva[nod] = true;

    for (int i = 0; i < graf[nod].size(); ++i)
    {
        if (indexNod[graf[nod][i]] == -1)
        {
            ++index;
            indexNod[graf[nod][i]] = index;
            indexIntoarcereNod[graf[nod][i]] = index;
            dfs(graf[nod][i]);
            indexIntoarcereNod[nod] = min(indexIntoarcereNod[nod], indexIntoarcereNod[graf[nod][i]]);
        }
        else if (peStiva[graf[nod][i]])
        {
            indexIntoarcereNod[nod] = min(indexIntoarcereNod[nod], indexNod[graf[nod][i]]);
        }
    }

    if (indexNod[nod] == indexIntoarcereNod[nod])
    {
        ctc.emplace_back();
        while (stiva.back() != nod)
        {
            ctc.back().emplace_back(stiva.back());
            peStiva[stiva.back()] = false;
            stiva.pop_back();
        }
        ctc.back().emplace_back(stiva.back());
        peStiva[stiva.back()] = false;
        stiva.pop_back();
    }
    /// altfel nimic
}

int main()
{
    ifstream in("ctc.in");
    ofstream out("ctc.out");

    ios_base::sync_with_stdio(false);
    in.tie(nullptr);

    int n, m;
    in >> n >> m;

    for (int i = 1; i <= m; ++i)
    {
        int a, b;
        in >> a >> b;

        graf[a].emplace_back(b);
    }

    for (int i = 1; i <= n; ++i)
    {
        indexNod[i] = -1;
        indexIntoarcereNod[i] = -1;
    }

    for (int i = 1; i <= n; ++i)
    {
        if (indexNod[i] == -1)
        {
            ++index;
            indexNod[i] = index;
            indexIntoarcereNod[i] = index;

            dfs(i);
        }
    }

    out << ctc.size() << '\n';
    for (int i = 0; i < ctc.size(); ++i)
    {
        for (int j = 0; j < ctc[i].size(); ++j)
            out << ctc[i][j] << ' ';
        out << '\n';
    }

    in.close();
    out.close();

    return 0;
}
