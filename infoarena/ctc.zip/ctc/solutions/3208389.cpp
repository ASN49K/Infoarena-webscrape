#include <fstream>
#include <vector>
#include <algorithm>

#define NMAX 100

using namespace std;

int stiva[NMAX + 1], k, globalTime;

struct type_node{
  int d, l;
  vector<int>edge;
}graf[NMAX + 1];

vector<int>comp[NMAX + 1];
int nrComp;

ifstream cin("ctc.in");
ofstream cout("ctc.out");

void dfs(int nod) {
  globalTime++;
  graf[nod].d = graf[nod].l = globalTime;
  k++;
  stiva[k] = nod;
  for(auto copil : graf[nod].edge) {
    if(graf[copil].d == 0) {
      dfs(copil);
    }
    graf[nod].l = min(graf[nod].l, graf[copil].l);
  }
  if(graf[nod].l == graf[nod].d) {
    nrComp++;
    while(stiva[k] != nod) {
      comp[nrComp].push_back(stiva[k]);
      k--;
    }
    comp[nrComp].push_back(stiva[k]);
    k--;
  }
}

signed main() {
  int n, m, i;
  cin>>n>>m;
  while(m--) {
    int a, b;
    cin>>a>>b;
    graf[a].edge.push_back(b);
  }
  for(i = 1; i <= n; i++) {
    if(graf[i].d == 0) {
      dfs(i);
    }
  }
  cout<<nrComp<<"\n";
  for(i = 1; i <= nrComp; i++) {
    for(int j = 0; j < comp[i].size(); j++) {
      cout<<comp[i][j]<<" ";
    }
    cout<<"\n";
  }
  return 0;
}