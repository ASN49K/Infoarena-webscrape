#include <iostream>

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
#include <bits/stdc++.h>
using namespace std;
int ct, viz[200001], viz2[200001], n, m, x, y;
vector <int> v[200001], v2[200001], qq[200001];
void dfs(int k)
{
    viz[k] = ct;
    for(int i = 0; i < v[k].size(); i ++)
      if(!viz[v[k][i]]) dfs(v[k][i]);
}
void dfs2(int k)
{
    viz2[k] = ct;
    for(int i = 0; i < v2[k].size(); i ++)
      if(!viz2[v2[k][i]]) dfs2(v2[k][i]);
}
void stergere()
{
    for(int i = 1; i <= n; i ++)
      if((viz[i] == 0 && viz2[i] != 0) || (viz[i] != 0 && viz2[i] == 0)) viz[i] = viz2[i] = 0;
}
int main()
{
    cin >> n >> m;
    while(m --)
    {
        cin >> x >> y;
        v[x].push_back(y);
        v2[y].push_back(x);
    }
    ct = 1;
    dfs(1);
    dfs2(1);
    stergere();
    for(int i = 1; i <= n; i ++)
        if(viz[i] == 0) ct ++, dfs(i), dfs2(i), stergere();
    for(int i = 1; i <= n; i ++)
      for(int j = 0; j < v[i].size(); j ++)
        if(viz[i] != viz2[v[i][j]]) qq[viz[i]].push_back(viz[v[i][j]]);
    for(int i = 1; i <= ct; i ++)
    {
        for(int j = 0; j < qq[i].size(); j ++)
          cout << qq[i][j] << " ";
        if(qq[i].size() == 0) cout << 0;
        cout << "\n";
    }
    return 0;
}
