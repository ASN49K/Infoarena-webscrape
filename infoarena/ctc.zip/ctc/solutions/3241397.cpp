#include<fstream>//Tarjan's
#include<vector>
#include<bitset>
#include<stack>
#include<set>
std::ifstream fin("ctc.in");
std::ofstream fout("ctc.out");
const int NMAX=100005;
std::set<int>G[NMAX];
int n, m;
int disc[NMAX], low[NMAX];
std::stack<int>st;
std::bitset<NMAX>stack_member;
std::vector<std::vector<int>>ans;
void read()
{
    fin>>n>>m;
    for(int i=0; i<m; ++i)
    {
        int from, to;
        fin>>from>>to;
        G[from].insert(to);
    }
}
void dfs(int node, int time)
{
    stack_member[node]=true;
    disc[node]=low[node]=++time;
    st.push(node);
    for(auto it:G[node])
    {
        if(!disc[it])
        {
            dfs(it, time);
            low[node]=std::min(low[node], low[it]);
        }
        else if(stack_member[it])
            low[node]=std::min(low[node], disc[it]);
    }

    if(disc[node]==low[node])
    {
        std::vector<int>local;
        while(st.top()!=node)
        {
            local.push_back(st.top());
            st.pop();
        }
        local.push_back(node);
        st.pop();
        ans.push_back(local);
    }
}
void displayAns()
{
    fout<<ans.size()<<'\n';
    for(auto const& it:ans)
    {
        for(auto i:it)
            fout<<i<<' ';
        fout<<'\n';
    }
}
int main()
{
    read();
    for(int i=1; i<=n; ++i)
        if(!disc[i])
            dfs(i, 0);

    displayAns();
    return 0;
}