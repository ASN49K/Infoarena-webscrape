#include <fstream>
#include <bits/stdc++.h>
using namespace std;
vector <int> V[100005];
int discovery[100005],low[100005],initlow[100005],discoveryTime=0;
stack <int> St;
bool inStack[100005];
typedef set<int> ctc;
vector<ctc> CompTariConexe;
void dfs(int k)
{
    discovery[k]=low[k]=++discoveryTime;
    St.push(k);
    inStack[k]=1;
    for(auto x:V[k])
    {
        if(discovery[x]==0)
            dfs(x);
        if(inStack[x]==1)
        {
            low[k]=min(low[k],low[x]);
        }
    }
    if(discovery[k]==low[k])
    {
        ctc new_ctc={};
        int x=-1;
        while(x!=k)
        {
            x=St.top();
            St.pop();
            low[x]=discovery[k];
            new_ctc.insert(x);
        }
        new_ctc.insert(k);
        CompTariConexe.push_back(new_ctc);
    }
}
int main()
{
    ifstream fin("ctc.in");
    ofstream fout("ctc.out");
    int n,m,a,b;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>a>>b;
        V[a].push_back(b);
    }
    for(int i=1;i<=n;i++)
        if(!discovery[i])
        {
            dfs(i);
        }
    fout<<CompTariConexe.size()<<'\n';
    for(auto x:CompTariConexe)
    {
        for(auto y:x)
            fout<<y<<" ";
        fout<<'\n';
    }
    return 0;
}
