#include <fstream>
#include <vector>
#include <bitset>
#include <stack>
#define DIM 100001
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n,m,x,y,nr,ctc,lvl[DIM],low[DIM];
vector<int> l[DIM],c[DIM];
bitset<DIM> viz;
stack<int> st;

void dfs(int nod) {
    nr++;
    lvl[nod]=nr;
    low[nod]=nr;
    st.push(nod);
    viz[nod]=1;
    for (int i=0;i<l[nod].size();i++) {
        int vec=l[nod][i];
        if (lvl[vec]==0) {
            dfs(vec);
            low[nod]=min(low[nod],low[vec]);
        }
        else
            if (viz[vec]==1)
                low[nod]=min(low[nod],low[vec]);
    }
    if (lvl[nod]==low[nod]) {
        ctc++;
        int x;
        do {
            x=st.top();
            st.pop();
            c[ctc].push_back(x);
            viz[x]=0;
        } while (x!=nod);
    }
}

int main() {
    fin>>n>>m;
    while (m--) {
        fin>>x>>y;
        l[x].push_back(y);
    }
    for (int i=1;i<=n;i++)
        if (lvl[i]==0)
            dfs(i);
    fout<<ctc<<"\n";
    for (int i=1;i<=ctc;i++) {
        for (int j=0;j<c[i].size();j++)
            fout<<c[i][j]<<" ";
        fout<<"\n";
    }
    return 0;
}
