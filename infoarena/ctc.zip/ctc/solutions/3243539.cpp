#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>

using namespace std;

void dfs1(int v, const vector<vector<int>>& G, vector<bool>& visited, stack<int>& Stack) {
    visited[v] = true;
    for (int u : G[v]) {
        if (!visited[u]) {
            dfs1(u, G, visited, Stack);
        }
    }
    Stack.push(v);
}

void dfs2(int v, const vector<vector<int>>& GT, vector<bool>& visited, vector<int>& component) {
    visited[v] = true;
    component.push_back(v);
    for (int u : GT[v]) {
        if (!visited[u]) {
            dfs2(u, GT, visited, component);
        }
    }
}

int main() {
    ifstream fin("ctc.in");
    ofstream fout("ctc.out");

    int N, M;
    cin >> N >> M;

    vector<vector<int>> G(N), GT(N);
    for (int i = 0; i < M; ++i) {
        int x, y;
        cin >> x >> y;
        --x; --y; //folosim indexare de la 0 
        G[x].push_back(y);
        GT[y].push_back(x); //construim grafu
    }

    // primul DFS
    vector<bool> visited(N, false);
    stack<int> Stack;

    for (int i = 0; i < N; ++i) {
        if (!visited[i]) {
            dfs1(i, G, visited, Stack);
        }
    }

    // al doilea DFS
    visited.assign(N, false);
    vector<vector<int>> sccs;

    while (!Stack.empty()) {
        int v = Stack.top();
        Stack.pop();
        if (!visited[v]) {
            vector<int> component;
            dfs2(v, GT, visited, component);
            sccs.push_back(component);
        }
    }


    cout <<  sccs.size() << endl;
    for (const vector<int>& scc : sccs) {
        for (int v : scc) {
            cout << v + 1 << " "; // afisam +1 pentru ca indexam de la 0
        }
        cout << endl;
    }


    return 0;
}

