#include <bits/stdc++.h>

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
typedef pair<int,int> pii;
vector<vector<int>> sol;
int n,m;
bool use[100005];
vector<int> st;
vector<pii> g;
vector<int> muchii[100005],nodes;
void dfs1(int nod)
{
	use[nod]=1;
	for(int i:muchii[nod])
		if(!use[i])
			dfs1(i);
	st.push_back(nod);
}
void dfs2(int nod)
{
	nodes.push_back(nod);
	use[nod]=1;
	for(int i:muchii[nod])
		if(!use[i])
			dfs2(i);
}
int main()
{
	ios_base::sync_with_stdio(false);
	fin.tie(0);
	fin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int a,b;
		fin>>a>>b;
		muchii[a].push_back(b);
		g.push_back({a,b});
	}
	for(int i=1;i<=n;i++)
		if(!use[i])
			dfs1(i);
	reverse(st.begin(),st.end());
	for(int i=1;i<=n;i++)
	{
		use[i]=0;
		muchii[i].clear();
	}
	for(pii p:g)
		muchii[p.second].push_back(p.first);
	for(int i:st)
		if(!use[i])
		{
			nodes.clear();
			dfs2(i);
			sol.push_back(nodes);
		}
	fout<<sol.size()<<'\n';
	for(auto i:sol)
	{
		for(int j:i)
			fout<<j<<' ';
		fout<<'\n';
	}
	return 0;
}
