#include <iostream>
#include <fstream>
#include <bits/stdc++.h>
#define inf INT_MAX
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");

vector <int> g[100001], gt[100001];
stack <int> St;
int cc[100001], n, m, x, y, nrc;
bool viz[100001];
void dfs(int nod)
{
    viz[nod]=1;
    for(auto &x:g[nod])
    {
        if(viz[x]==0)
        {
            dfs(x);
        }
    }
    St.push(nod);
}
void dfst(int nod)
{
    cc[nod]=nrc;
    for(auto &x:gt[nod])
    {
        if(cc[x]==0)
        {
            dfst(x);
        }
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        fin>>x>>y;
        g[x].push_back(y);
        gt[y].push_back(x);
    }
    for(int i=1; i<=n; i++)
    {
        if(viz[i]==0)
        {
            dfs(i);
        }
    }
    int i;
    while(!St.empty())
    {
        i=St.top();
        St.pop();
        if(cc[i]==0)
        {
            nrc++;
            dfst(i);
        }
    }
    fout<<nrc<<"\n";
    for(int i=1; i<=nrc; i++)
    {
        for(int j=1; j<=n; j++)
        {
            if(cc[j]==i)
            {
                fout<<j<<" ";
            }
        }
        fout<<"\n";
    }
    return 0;
}
