
#include <fstream>
#include <vector>
#include <set>
#include <stack>
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
int n,m,x,y,nrc,indi;
vector<set<int>> G;
vector<bool> fr,frs;
vector<int> minime,ind;
stack<int> S;
vector<vector<int>> ans;
void dfs(int nod)
{
   ind[nod]=indi;
   minime[nod]=indi;
   indi++;
   S.push(nod);
   frs[nod]=1;
   for(auto j=G[nod].begin();j!=G[nod].end();j++)
   {
       int vecin=*j;
       if(!fr[vecin])
       {
           fr[vecin]=1;
           dfs(vecin);
           minime[nod]=min(minime[nod],minime[vecin]);
       }
       if(frs[vecin])
          minime[nod]=min(minime[nod],minime[vecin]);
   }
   if(ind[nod]==minime[nod])
   {
       ans.resize(ans.size()+1);
       while(S.top()!=nod)
       {
         ans[nrc].push_back(S.top());
         frs[S.top()]=0;
         minime[S.top()]=ind[nod];
         S.pop();
       }
        ans[nrc].push_back(S.top());
        frs[nod]=0;
        S.pop();
        nrc++;
   }
}
int main()
{
    cin>>n>>m;
    G.resize(n+1);
    fr.resize(n+1);
    minime.resize(n+1);
    ind.resize(n+1);
    frs.resize(n+1);
    for(int i=0;i<m;i++)
    {
        cin>>x>>y;
        G[x].insert(y);
    }
    for(int i=1;i<=n;i++)
      if(!fr[i])
      {
          fr[i]=1;
          dfs(i);
      }
    cout<<nrc;
    cout<<'\n';
    for(int i=0;i<ans.size();i++)
    {
        for(int j=0;j<ans[i].size();j++)
          cout<<ans[i][j]<<" ";
        cout<<'\n';
    }
    return 0;
}
