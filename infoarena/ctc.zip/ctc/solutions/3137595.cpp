#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <climits>
#include <set>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
const int Nmax=100005;
int st[Nmax],poz[Nmax],minnxt[Nmax],viz[Nmax];
bool compc[Nmax];
int indst=0;
vector<int> v[Nmax];
vector<set<int>> sol;
set<int> cursol;
void dfs(int nod)
{
    indst++;
    st[indst]=nod;
    poz[nod]=indst;
    viz[nod]=1;
    int minpoz=INT_MAX;
    for(int i=0;i<v[nod].size();i++)
    {
        if(compc[v[nod][i]]==0)
        {
            if(viz[v[nod][i]]==0)
            {
                dfs(v[nod][i]);
                minpoz=min(minpoz,minnxt[v[nod][i]]);
            }
            else
            {
                minpoz=min(minpoz,poz[v[nod][i]]);
            }
        }
    }
    minnxt[nod]=min(poz[nod],minpoz);
    if(poz[nod]==minnxt[nod])
    {
        cursol.clear();
        for(int i=poz[nod];i<=indst;i++)
        {
            cursol.insert(st[i]);
            compc[st[i]]=1;
        }
        sol.push_back(cursol);
        indst=poz[nod]-1;
    }
    return;
}
int main()
{
    int n,m,x,y;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
    {
        if(viz[i]==0)
        {
            dfs(i);
        }
    }
    fout<<sol.size()<<'\n';
    for(int i=0;i<sol.size();i++)
    {
        for(auto it=sol[i].begin();it!=sol[i].end();it++)
        {
            fout<<(*it)<<' ';
        }
        fout<<'\n';
    }
    return 0;
}
