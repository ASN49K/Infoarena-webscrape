#include <fstream>
#include <stack>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
long long n ,m;
vector<int> adj [ 150001 ];
vector<int> transposed[ 150001 ];

bool used [ 150001 ];
stack<int> st ;
void dfs1 ( long long nod )
{
    used [ nod ] = true ;

    for (int i = 0 ; i < adj [ nod ] .size() ;  i++  )
    {
        if ( used [ adj [ nod ] [ i ]] == false )
            dfs1 ( adj [ nod ] [ i ] );
    }

    st.push(nod);
}

vector<int> marcat[ 150001 ];

int color = 0 ;

long long dolor [ 150001 ];

void dfs2( long long nod )
{
    used [ nod ] = true ;

    dolor [nod ] = color ;
    marcat[ color ] [ 0 ] ++ ;
    marcat[ color ].push_back(nod);
    for ( int i = 0 ; i < transposed[ nod] .size() ; i ++ )
    {
        if ( used[ transposed[ nod ] [ i] ] == false )
        {
            dfs2( transposed [ nod ] [ i ] );
        }
    }
}

bool culss[ 150001 ];
int main()
{
    cin >> n >> m ;

    for ( int i = 1 ; i <= m ; i ++ )
    {
        long long a , b ;
        cin >> a >> b;
        adj [a ] .push_back(b);
        transposed[ b ] .push_back(a);

    }



    for( int i = 1; i <= n ; i ++ )
    {
        if ( used [i ] == 0 )
            dfs1(i);
    }


    for ( int i = 1; i <= n ; i ++ )
    {
        used[ i ] = 0 ;
    }




    while ( !st.empty() )
    {
        if ( used [ st.top() ] == true )
            st.pop();
        else
        {

            color ++ ;
            marcat[color].push_back(0);
            dfs2(st.top() );
            st.pop();
        }


    }
    cout << color << '\n';

    for ( int i = 1; i <= color ; i ++ )
    {
        sort ( marcat[ i ] .begin() + 1 , marcat[ i ] .end() );


    }

    for ( int i = 1; i <= n ; i ++ )
    {
        if ( culss [ dolor [ i ] ] == 0 )
        {
            for ( int j = 1 ; j < marcat[ dolor [ i ] ].size() ; j ++  )
                cout << marcat[ dolor [ i ] ] [ j ] << " ";

            cout << '\n';
            culss[ dolor [ i ] ] = 1;
        }
    }



    return 0;
}
