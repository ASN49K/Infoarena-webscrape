#include <bits/stdc++.h>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");

const int NMAX = 1e5 + 5;
vector < vector <int> > v(NMAX), w(NMAX), r(NMAX);
vector <int> viz(NMAX), t(NMAX);
int cnt;
void topologic(int nod){
    viz[nod] = 1;
    for(auto& new_nod: v[nod])
    {
        if(!viz[new_nod])
            topologic(new_nod);
    }
    t[cnt--] = nod;
}

void dfs(int nod)
{
    viz[nod] = 1;
    r[cnt].push_back(nod);
    for(auto& new_nod: w[nod])
    {
        if(!viz[new_nod])
            dfs(new_nod);
    }
}
int main()
{
    int n, m, x, y, c;
    fin >> n >> m;
    
    for(int i = 1; i <= m; ++i)
    {
        fin >> x >> y;
        v[x].push_back(y);
        w[y].push_back(x);
    }
    cnt = n;
    for(int i = 1; i <= n; ++i)
        if(!viz[i])
            topologic(i);

    
    fill(viz.begin(),viz.end(),0);
    
    cnt = 0;
    for(int i = 1; i <= n; ++i)
    {
        if(!viz[i])
        {
            cnt++;
            dfs(t[i]);
        }
    }
    fout << cnt << "\n";
    for(int i = 1; i <= cnt; ++i)
    {
        for(auto& c: r[i])
            fout << c << " ";
        fout << "\n";
    }
    return 0;
}