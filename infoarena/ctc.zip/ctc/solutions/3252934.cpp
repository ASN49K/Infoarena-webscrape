/*
                    __
                   /\ \
 _ __   ___     ___\ \ \/'\     ___      __      ___     ___      __
/\`'__\/ __`\  /'___\ \ , <    / __`\  /'__`\  /' _ `\ /' _ `\  /'__`\
\ \ \//\ \L\ \/\ \__/\ \ \\`\ /\ \L\ \/\ \L\.\_/\ \/\ \/\ \/\ \/\ \L\.\_
 \ \_\\ \____/\ \____\\ \_\ \_\ \____/\ \__/.\_\ \_\ \_\ \_\ \_\ \__/.\_\
  \/_/ \/___/  \/____/ \/_/\/_/\/___/  \/__/\/_/\/_/\/_/\/_/\/_/\/__/\/_/


*/

#include <bits/stdc++.h>
using namespace std;

#define endl '\n'
using i64 = int64_t;

int n, m;
vector<int> ts;
vector<vector<int>> ctc;
bool vis[100001];

void dfs(int crt, vector<vector<int>>& v, vector<int>& add_to) {
  vis[crt] = true;
  for (auto& e : v[crt]) {
    if (!vis[e]) dfs(e, v, add_to);
  }

  add_to.push_back(crt);
}

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  // #ifdef LOCAL
  ifstream cin{"ctc.in"};
  ofstream cout{"ctc.out"};
  // #endif

  cin >> n >> m;

  vector<vector<int>> v1, v2;
  v1.assign(n + 1, {}), v2.assign(n + 1, {});

  int a, b;
  for (int i = 0; i < m; i++) {
    cin >> a >> b;
    v1[a].push_back(b);
    v2[b].push_back(a);
  }

  int idx = -1;
  for (int i = 1; i <= n; i++) {
    if (!vis[i]) {
      dfs(i, v1, ts);
    }
  }

  for (int i = 0; i <= n; i++) {
    vis[i] = false;
  }

  idx = 0;
  ctc.reserve(n);
  for (int i = n - 1; i >= 0; i--) {
    if (!vis[ts[i]]) {
      ctc.push_back({});
      dfs(ts[i], v2, ctc[idx]);
      sort(ctc[idx].begin(), ctc[idx].end());
      idx++;
    }
  }

  cout << ctc.size() << endl;
  for (auto& e : ctc) {
    for (auto& x : e) {
      cout << x << " ";
    }
    cout << endl;
  }

  return 0;
}
