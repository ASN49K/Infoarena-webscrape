#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream cin ("ctc.in");
ofstream cout ("ctc.out");
vector< vector<int> > componente;
vector<int> componenta;
vector<int> g[100005];
vector<int> gt[100005];
vector<int> ordine;
bool u[100005];
int n,m;
void dfs1(int nod)
{
    u[nod] = true;
    for(auto urm:g[nod])
    {
        if(u[urm])
            continue;
        dfs1(urm);
    }
    ordine.push_back(nod);
}
void dfs2(int nod)
{
    componenta.push_back(nod);
    u[nod] = true;
    for(auto urm:gt[nod])
    {
        if(u[urm])
            continue;
        dfs2(urm);
    }
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        cin >> x >> y;
        g[x].push_back(y);
        gt[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
    {
        if(u[i])
            continue;
        dfs1(i);
    }
    for(int i=1;i<=n;i++)
        u[i] = false;
    reverse(ordine.begin(),ordine.end());
    for(auto x:ordine)
    {
        if(u[x])
            continue;
        componenta.clear();
        dfs2(x);
        componente.push_back(componenta);
    }
    cout << componente.size() << '\n';
    for(auto x:componente)
    {
        for(auto y:x)
            cout << y << ' ';
        cout << '\n';
    }
    return 0;
}
