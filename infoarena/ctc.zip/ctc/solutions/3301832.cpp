// Source: https://usaco.guide/general/io

#include <bits/stdc++.h>
#include <fstream>
using namespace std;
ifstream f("ctc.in");
ofstream g("ctc.out");
vector <int> v1[100005],v2[100005],ctc[100005];
int vis1[100005],vis2[100005];
int n,m,x,y,k,v[100005],cnt;
void dfs1(int x)
{
    vis1[x]=1;
    for(int i=0;i<v1[x].size();i++)
    if(vis1[v1[x][i]]==0)
    dfs1(v1[x][i]);
    k++;
    v[k]=x;
}
void dfs2(int x)
{   
    ctc[cnt].push_back(x);
    vis2[x]=1;
    for(int i=0;i<v2[x].size();i++)
    if(vis2[v2[x][i]]==0)
    dfs2(v2[x][i]);
    
}
int main() {
	f>>n>>m;
    for(int i=1;i<=m;i++)
    {
        f>>x>>y;
        v1[x].push_back(y);
        v2[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
    if(vis1[i]==0)
    dfs1(i);
//for(int i=1;i<=k;i++)
//g<<v[i]<<' ';
    for(int i=k;i>=1;i--)
    {
        if(vis2[v[i]]==0)
        {
            cnt++;
            dfs2(v[i]);
            
        }
    }
    g<<cnt<<'\n';
    for(int i=1;i<=cnt;i++,g<<'\n')
    for(int j=0;j<ctc[i].size();j++)
    g<<ctc[i][j]<<' ';


}
