#include <bits/stdc++.h>

using namespace std;
#define N 100007
int n,k,m,timp=1;
vector<int>a[N],ciclu[N];
vector<int>disc(N,0),llink(N,0);
stack<int>st;
bitset<N>instack;
//ifstream fin("ctc.in");ofstream fout("ctc.out");
//#define cin fin
//#define cout fout
void DFS(int x)
{
//    cout << x << "\n";
    disc[x]= timp++;
    llink[x]=disc[x];
    instack[x]=1;
    st.push(x);
    for(auto y:a[x])
    {
        if( !disc[y] )
        {
            DFS( y );
            llink[x]=min(llink[x],llink[y]);
        }
                                                                                    else if( instack[y] )
            llink[x]=min(llink[x],llink[y]);
    }
    if( disc[x]==llink[x] )
    {
//cout << x << " :  ";
        k++;
        while( st.top()!=x )
        {
//cout << st.top() << " ";
            ciclu[k].push_back( st.top() );
            instack[st.top()]=0;
            st.pop();
        }
        instack[st.top()]=0;
        ciclu[k].push_back( st.top() );
//cout << st.top() << " ";cout << "\n";
        st.pop();
    }
}

int main()
{
    int n,m;
    cin >> n >> m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        cin >> x >> y;
        a[x].push_back(y);
//        a[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
    {
        if( !disc[i] )
            DFS(i);
//    cout << i << " :   " << disc[i] << " " << llink[i]  << "\n";
    }
    cout << k << "\n";
//    for(int i=1;i<=k;i+=1)
//    {
//        for(auto x:ciclu[i])cout << x << " ";
//        cout << "\n";
//    }

    return 0;
}
