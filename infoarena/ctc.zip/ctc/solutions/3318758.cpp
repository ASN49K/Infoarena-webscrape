#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;

vector<vector<int>> L;
vector<vector<int>> Lrev;
vector<int> viz;
vector<int> componenta;
vector<int> finish;
vector<vector<int>> all_components;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

void dfs1(int nod) {
    viz[nod] = 1;
    for (int vecin : L[nod]) {
        if (viz[vecin] == 0) {
            dfs1(vecin);
        }
    }
    finish.push_back(nod);
}

void dfs2(int nod) {
    viz[nod] = 1;
    componenta.push_back(nod);
    for (int vecin : Lrev[nod]) {
        if (viz[vecin] == 0) {
            dfs2(vecin);
        }
    }
}

int main () {
    int cc = 0;
    int n, m;
    fin >> n >> m;
    L.resize(n + 1);
    Lrev.resize(n + 1);
    viz.resize(n + 1);

    int x, y;
    for (int i = 0; i < m; i++) {
        fin >> x >> y;
        L[x].push_back(y);
        Lrev[y].push_back(x);
    }
    for (int i = 1; i <= n; i++) {
        if (viz[i] == 0) {
            dfs1(i);
        }
    }
    fill(viz.begin(), viz.end(), 0);
    reverse(finish.begin(), finish.end());
    for(int nod : finish) {
        if (viz[nod] == 0) {
            componenta.clear();
            dfs2(nod);
            all_components.push_back(componenta); 
            cc++;
        }
    }
    fout << cc << "\n";
        for (const auto& comp : all_components) {
        for (int node : comp) {
            fout << node << " ";
        }
        fout << "\n";
    }

    return 0;
}