#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream in("ctc.in");
ofstream out("ctc.out");
int n, m, ans;
int id;
vector<int> v[100005];
int viz[100005];
int low[100005];
stack<int> s;
int onstack[100005];
vector<int> sol[100005];

void dfs(int nod)
{
    //out<<nod<<'\n';
    onstack[nod] = 1;
    s.push(nod);

    id++;
    viz[nod] = low[nod] = id;

    for(auto it: v[nod])
    {
        if(viz[it] == 0)
        {
            dfs(it);
        }

        if(onstack[it])
        {
            low[nod] = min(low[nod], low[it]);
        }
    }

    if(low[nod] == viz[nod])
    {
        //out<<"gata "<<nod<<'\n';
        ans++;
        while(!s.empty())
        {
            onstack[s.top()] = 0;
            low[s.top()] = viz[nod];
            sol[ans].push_back(s.top());

            if(s.top() == nod)
            {
                s.pop();
                break;
            }
            else
            {
                s.pop();
            }
        }
    }
}

int main()
{
    in>>n>>m;

    int x, y;
    for(int i = 1; i<=m; i++)
    {
        in>>x>>y;

        v[x].push_back(y);
    }

    for(int i = 1; i<=n; i++)
    {
        if(viz[i] == 0)
        {
            dfs(i);
        }
    }

    out<<ans<<'\n';
    for(int i = 1; i<=ans; i++)
    {
        for(auto it: sol[i])
        {
            out<<it<<" ";
        }
        out<<'\n';
    }

    return 0;
}
