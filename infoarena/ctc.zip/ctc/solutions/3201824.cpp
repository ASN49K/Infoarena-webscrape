#include <fstream>
#include <cmath>
#include <vector>
#include <stack>
#include <algorithm>
#define f first
#define s second
const int NMAX=1055;

using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");

void dfs1(int);
void dfs2(int);

vector <int> v[NMAX], vt[NMAX], c[NMAX];
int n, m, ct[NMAX], df[NMAX], ctc, dfs;
stack <int> st;

int main()
{
    int i, a, b;
    cin>>n>>m;
    for(i=1; i<=m; i++)
    {
        cin>>a>>b;
        v[a].push_back(b);
        vt[b].push_back(a);
    }
    for(i=1; i<=n; i++)
    {
        if(!ct[i])
        {
            ++dfs;
            dfs1(i);
            while(!st.empty())
            {
                if(!ct[st.top()])
                {
                    ++ctc;
                    dfs2(st.top());
                }
                st.pop();
            }
        }
    }
    cout<<ctc<<'\n';
    for(i=1; i<=ctc; i++)
    {
        sort(c[i].begin(), c[i].end());
        for(auto j:c[i]) cout<<j<<' ';
        cout<<'\n';
    }
}

void dfs1(int nod)
{
    df[nod]=dfs;
    for(auto i:v[nod])
    {
        if(!ct[i] && df[i]!=dfs)
        {
            dfs1(i);
        }
    }
    st.push(nod);
}

void dfs2(int nod)
{
    c[ctc].push_back(nod);
    ct[nod]=ctc;
    for(auto i:vt[nod])
    {
        if(!ct[i] && df[i]==dfs)
        {
            dfs2(i);
        }
    }
}
