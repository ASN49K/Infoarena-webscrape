#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_set>

std::vector<std::vector<int>> graph;
std::vector<std::vector<int>> transpose;
std::vector<int> stack;
std::vector<bool> visited;
std::vector<int> roots;

void dfs1(int node) {
    visited[node] = true;
    for (const auto &x: graph[node]) {
        if (!visited[x]) {
            dfs1(x);
        }
    }
    stack.push_back(node);
}

void dfs2(int node, int root) {
    roots[node] = root;
    for (const auto &x: transpose[node]) {
        if (roots[x] == 0) {
            dfs2(x, root);
        }
    }
}

int main() {
    std::ifstream input("ctc.in");
    std::ofstream output("ctc.out");

    int n, m;
    input >> n >> m;

    graph.resize(n + 1);
    transpose.resize(n + 1);
    visited.resize(n + 1, false);
    roots.resize(n + 1, 0);
    while (m--) {
        int x, y;
        input >> x >> y;
        graph[x].push_back(y);
        transpose[y].push_back(x);
    }

    for (int i = 1; i <= n; ++i) {
        if (!visited[i]) {
            dfs1(i);
        }
    }

    int root = 1;
    while (!stack.empty()) {
        int node = stack.back();
        stack.pop_back();
        if (roots[node] == 0) {
            dfs2(node, root);
            root++;
        }
    }

    std::unordered_set<int> set(roots.begin() + 1, roots.end());

    std::vector<std::vector<int>> components(n + 1);
    for (int i = 1; i <= n; ++i) {
        components[roots[i]].push_back(i);
    }
    output << set.size() << '\n';
    for (int i = 1; i <= n; ++i) {
        if (!components[i].empty()) {
            for (const auto &x: components[i]) output << x << " ";
            output << '\n';
        }
    }

    return 0;
}