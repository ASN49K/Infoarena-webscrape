#include <bits/stdc++.h>

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
bitset<100001>ver;
vector<int>v[100001];
vector<int>p[100001];
vector<int>sol[100001];
vector<int>Q;
int nrn[100001],conexe=0;
void topo(int x)
{
    ver[x]=true;
    for(auto y:v[x])
    {
        if(ver[y]==false)topo(y);
    }
    Q.push_back(x);
}
void dfs(int x)
{
    ver[x]=true;
    sol[conexe].push_back(x);
    for(auto y:p[x])
    {
        if(ver[y]==false)
        {
            dfs(y);
        }
    }
}
int main()
{
    int i,n,m,x1,x2;
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x1>>x2;
        v[x1].push_back(x2);
        p[x2].push_back(x1);
    }
    for(i=1;i<=n;i++)
    {
        if(ver[i]==false)
            {
                topo(i);
            }
    }
    ver.reset();
    reverse(Q.begin(),Q.end());
    for(auto y:Q)
    {
        if(ver[y]==false)
        {
            conexe++;
            dfs(y);
        }
    }
    fout<<conexe<<'\n';
    for(i=1;i<=conexe;i++)
    {
        for(auto y:sol[i])fout<<y<< ' ';
        fout<<'\n';
    }
}
