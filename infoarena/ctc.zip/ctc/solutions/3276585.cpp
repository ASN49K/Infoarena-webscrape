#include <fstream>
#include <cstring>
#include <vector>
#define nmax (int)(1e5+1)
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
int n,m,k,x,y,tops[nmax];
vector<int>v[nmax],vt[nmax],aux;
vector<vector<int>>sol;
bool viz[nmax];
void dfs(int nod){
    viz[nod]=1;
    for(auto i:v[nod])
        if(!viz[i])
            dfs(i);
    tops[++k]=nod;
}
void dfs_t(int nod){
    viz[nod]=1;
    for(auto i:vt[nod])
        if(!viz[i])
            dfs_t(i);
    aux.push_back(nod);
}
signed main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back(y);
        vt[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(!viz[i])
            dfs(i);
    memset(viz,0,sizeof(viz));
    for(int i=n;i>0;i--)
        if(!viz[tops[i]]){
            aux.clear();
            dfs_t(tops[i]);
            sol.push_back(aux);
        }
    cout<<sol.size()<<'\n';
    for(auto i:sol){
        for(auto j:i)
            cout<<j<<" ";
        cout<<'\n';
    }
    return 0;
}
/// kosaraju
