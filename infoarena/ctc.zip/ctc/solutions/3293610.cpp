#include <fstream>
#include <cstring>
#include <vector>
#define nmax (int)(1e5+1)
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
int n,m,tops[nmax],k,x,y;
bool viz[nmax];
vector<int>v[nmax],vr[nmax],aux;
vector<vector<int>>sol;
void dfs(int nod){
    viz[nod]=1;
    for(auto i:v[nod])
        if(!viz[i])
            dfs(i);
    tops[++k]=nod;
}
void dfsr(int nod){
    aux.push_back(nod);
    viz[nod]=1;
    for(auto i:vr[nod])
        if(!viz[i])
            dfsr(i);
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back(y);
        vr[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(!viz[i])
            dfs(i);
    memset(viz,0,sizeof(viz));
    for(int i=n;i>0;i--)
        if(!viz[tops[i]]){
            aux.clear();
            dfsr(tops[i]);
            sol.push_back(aux);
        }
    cout<<sol.size()<<'\n';
    for(auto i:sol){
        for(auto j:i)
            cout<<j<<" ";
        cout<<'\n';
    }
    return 0;
}
