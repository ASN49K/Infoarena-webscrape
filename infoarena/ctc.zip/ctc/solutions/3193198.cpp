#include <bits/stdc++.h>
//#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("ctc.in" , "r" , stdin) , freopen("ctc.out" , "w" , stdout)
#define ll long long
#define ull unsigned long long
#define ld long double
#define eb emplace_back
#define pb push_back
#define qwerty1 first
#define qwerty2 second
#define qwerty3 -> first
#define qwerty4 -> second
#define umap unordered_map
#define uset unordered_set
#define pii pair < ll , ll >
#define pq priority_queue
#define dbg(x) cerr << #x << ": " << x << '\n'

namespace FastRead
{
    char __buff[5000];ll __lg = 0 , __p = 0;
    char nc()
    {
        if(__lg == __p){__lg = fread(__buff , 1 , 5000 , stdin);__p = 0;if(!__lg) return EOF;}
        return __buff[__p++];
    }
    template<class T>void read(T&__x)
    {
        T __sgn = 1; char __c;while(!isdigit(__c = nc()))if(__c == '-')__sgn = -1;
        __x = __c - '0';while(isdigit(__c = nc()))__x = __x * 10 + __c - '0';__x *= __sgn;
    }
}

using namespace FastRead;
using namespace std;

const ll N = 1e5 + 10;
const ll M = 1e9 + 7;
const ld PI = acos(-1);
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int n , m;
int dt[N] , low[N];
bool in[N];

vector < int > G[N] , ctc[N];
stack < int > st;

int cnt = 0;

int Time = 0;

void dfs(int node)
{
    dt[node] = low[node] = ++Time;
    st.push(node);
    in[node] = 1;

    for(auto to : G[node])
        if(!dt[to])
        {
            dfs(to);
            low[node] = min(low[node] , low[to]);
        }
        else if(in[to])
            low[node] = min(low[node] , low[to]);


    if(low[node] == dt[node])
    {
        ++cnt;
        while(st.top() != node)
        {
            ctc[cnt].pb(st.top());
            in[st.top()] = 0;
            st.pop();
        }

        st.pop();
        ctc[cnt].pb(node);
        in[node] = 0;
    }
}

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif


    int i;

    cin >> n >> m;

    while(m--)
    {
        int x , y;
        cin >> x >> y;
        G[x].pb(y);
    }

    dfs(1);

    cout << cnt << '\n';

    for(int i = 1 ; i <= cnt ; i++ , cout << '\n')
    {
        sort(ctc[i].begin() , ctc[i].end());
        for(auto j : ctc[i]) cout << j << ' ';
    }

    return 0;
}

