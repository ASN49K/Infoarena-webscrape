﻿#include <bits/stdc++.h>
#include <random>
#include <chrono>
using namespace std;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
const char nl = '\n';
const char sp = ' ';
const int inf = 0x3f3f3f3f;
const int mod = 1e9 + 7;
const char out[2][4]{ "NO", "YES" };
#define all(x) x.begin(), x.end()
using ll = long long;
ifstream fin("ctc.in");
ofstream fout("ctc.out");

#define variableName(var) #var
#define __debug(var) cout << #var << " = " << var << ' '

const int nmax = 1e5;
int n, m;
vector<int> g[nmax + 1];
vector<int> rg[nmax + 1];
bool vis[nmax + 1]{ 0 };
vector<int> order;
vector<vector<int>> components;

void dfs1(int u) {
    vis[u] = 1;
    for (auto& v : g[u]) {
        if (vis[v]) {
            continue;
        }
        dfs1(v);
    }
    order.push_back(u);
}

void dfs2(int u) {
    vis[u] = 1;
    for (auto& v : rg[u]) {
        if (vis[v]) {
            continue;
        }
        dfs2(v);
    }
    components.back().push_back(u);
}

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    fin >> n >> m;
    for (int i = 1; i <= m; ++i) {
        int u, v;
        fin >> u >> v;
        g[u].push_back(v);
        rg[v].push_back(u);
    }
    for (int i = 1; i <= m; ++i) {
        if (!vis[i]) {
            dfs1(i);
        }
    }
    reverse(all(order));
    fill(vis + 1, vis + n + 1, 0);
    for (auto& i : order) {
        if (!vis[i]) {
            components.push_back({});
            dfs2(i);
        }
    }
    fout << components.size() << nl;
    for (auto& component : components) {
        for (auto& x : component) {
            fout << x << sp;
        }
        fout << nl;
    }
}