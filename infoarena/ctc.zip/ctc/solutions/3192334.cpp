#include <bits/stdc++.h>



using namespace std;

int n,m,comp=0,f[100001],f2[100001];
vector<int>G[100001],GT[100001];
vector<int>S;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
set<int>lista[100001];
void dfs(int nod){
    f[nod]=1;
    for(auto x : G[nod])
        if(f[x]==0)
            dfs(x);
    S.push_back(nod);
}
void dfs2(int nod){
    f2[nod]=1;
    lista[comp].insert(nod);
    for(auto x: GT[nod])
        if(f2[x]==0)
            dfs2(x);

}
int main(){
    fin>>n>>m;
    while(m--){
        int x,y; fin>>x>>y;
        G[x].push_back(y);
        GT[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(!f[i])
            dfs(i);
    for(vector<int> :: reverse_iterator it = S.rbegin();it!=S.rend();it++){
        if(!f2[*it]){
            comp++;
            dfs2(*it);
        }


    }
    fout<<comp<<'\n';
    for(int i=1;i<=comp;i++){
        for(auto x : lista[i])
            fout<<x<<" ";
        fout<<'\n';}
    return 0;
}
