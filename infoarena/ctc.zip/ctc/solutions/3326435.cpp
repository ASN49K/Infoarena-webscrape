#include <bits/stdc++.h>

using namespace std;
bool viz[100005];
vector<int>v;
vector<int>gf[100005];
vector<int>gfinv[100005];
vector<int>ans[100005];
int componente=0;
void dfs(int x)
{
    viz[x]=1;
    for(auto var:gf[x])
    {
        if(viz[var]==0)
            dfs(var);
    }
    v.push_back(x);
}
void dfs2(int x)
{
    viz[x]=0;
    ans[componente].push_back(x);
    for(auto var:gfinv[x])
    {
        if(viz[var]==1)
            dfs2(var);
    }

}
int main()
{
    ifstream cin("ctc.in");
    ofstream cout("ctc.out");
  int n,m,x,y;
  cin>>n>>m;
  for(int i=0;i<m;i++)
  {
      cin>>x>>y;
      gf[x].push_back(y);
      gfinv[y].push_back(x);
  }
  for(int i=1;i<=n;i++)
  {
      if(viz[i]==0)
        dfs(i);
  }
  for (int i=n-1;i>=0;i--)
  {
      if(viz[v[i]]==1)
      {
          componente++;
          dfs2(v[i]);
      }

  }
  cout<<componente<<'\n';
  for(int i=1;i<=componente;i++)
  {
      for(auto var:ans[i])
        cout<<var<<" ";
      cout<<'\n';
  }
    return 0;
}
