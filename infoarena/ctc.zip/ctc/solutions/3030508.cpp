#include <fstream>
#include <vector>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n, m, i, j, x, y, nctc;
vector <int> viz, ord, c;
vector <vector <int> > v, vt, ctc;
void dfs (int x)
{
    viz[x] = 1;
    for (auto it : v[x])
    {
        if (viz[it] == 0)
            dfs(it);
    }
    ord.push_back(x);
}
void rdfs (int x)
{
    c[x] = nctc;
    for (auto it : vt[x])
    {
        if (c[it] == 0)
        {
            rdfs(it);
        }
    }
}
int main()
{
    fin >> n >> m; v.resize(n+1); vt.resize(n+1); viz.resize(n+1); c.resize(n+1);
    for (i = 1; i <= m; i++)
    {
        fin >> x >> y;
        v[x].push_back(y);
        vt[y].push_back(x);
    }
    for (i = 1; i <= n; i++)
    {
        if (viz[i] == 0)
            dfs(i);
    }
    for (i = n-1; i >= 0; i--)
    {
        if (c[ord[i]] == 0)
        {
            nctc++;
            rdfs(ord[i]);
        }
    }
    ctc.resize(nctc+1);
    for (i = 1; i <= n; i++)
    {
        ctc[c[i]].push_back(i);
    }
    fout << nctc << '\n';
    for (i = 1; i <= nctc; i++, fout << '\n')
        for (auto it : ctc[i])
            fout << it << ' ';
    return 0;
}
