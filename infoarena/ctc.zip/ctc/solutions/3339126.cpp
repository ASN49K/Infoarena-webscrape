#include <fstream>
#include <stack>
#include <vector>
#define NMAX 100002

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");

int n,m;
int nrc;
vector<int> G[NMAX];
vector<int> tG[NMAX];

void kosaraju();
stack<int> s;
vector<int> ctc[NMAX];
void dfs1(int x);
void dfs2(int x);
int viz[NMAX];

int main()
{
    int i,x,y,j;
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
        tG[y].push_back(x);
    }
    kosaraju();
    fout<<nrc<<'\n';
    for(i=1; i<=nrc; i++)
        {
         for(j=0; j<ctc[i].size(); j++)
            fout<<ctc[i][j]<<' ';
         fout<<'\n';
        }
    return 0;
}

void dfs1(int x)
{
    int i;
    viz[x]=1;
    for(i=0; i<G[x].size(); i++)
        if(!viz[G[x][i]])
            dfs1(G[x][i]);
    s.push(x);
}

void dfs2(int x)
{
    int i;
    ctc[nrc].push_back(x);
    viz[x]=1;
    for(i=0; i<tG[x].size(); i++)
        if(!viz[tG[x][i]])
            dfs2(tG[x][i]);
}

void kosaraju()
{
    int i,j,x;
    //primul dfs
    for(i=1; i<=n; i++)
        if(!viz[i])
            dfs1(i);
    //al doilea dfs
    for(i=1; i<=n; i++)
        viz[i]=0;
    while(!s.empty())
        {
         x=s.top(); s.pop();
         for(i=1; i<=n; i++)
            if(!viz[i])
                {
                 nrc++;
                 dfs2(i);
                }
        }
}
