#include <bits/stdc++.h>
using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

vector<int> g[100001];
vector<int> gt[100001];
bitset<100001> viz;
int sol[100001], len, n, m;
int nrctc;
vector<int> ctc[100001];

void Citire()
{
    int i, j, p;
    fin >> n >> m;
    for (p = 1; p <= m; p++)
    {
        fin >> i >> j;
        g[i].push_back(j);
        gt[j].push_back(i);
    }
}

void DFS(int k)
{
    viz[k] = 1;
    ctc[nrctc].push_back(k);
    for (int i : gt[k])
        if (viz[i] == 0) DFS(i);
}

void Kosaraju()
{
    for (int i = n; i >= 1; i--)
        if (viz[sol[i]] == 0)
        {
            nrctc++;
            DFS(sol[i]);
        }
}

void DFSt(int k)
{
    viz[k] = 1;
    for (int i : g[k])
        if (viz[i] == 0) DFSt(i);
    sol[++len] = k;
}

void SortTop()
{
    for (int i = 1; i <= n; i++)
        if (viz[i] == 0)
            DFSt(i);
}

void Afis()
{
    fout << nrctc << "\n";
    for (int i = 1; i <= nrctc; i++)
    {
        for (int e : ctc[i])
            fout << e << " ";
        fout << "\n";
    }
}

int main()
{
    Citire();
    SortTop();
    viz.reset();
    Kosaraju();
    Afis();
    return 0;
}
