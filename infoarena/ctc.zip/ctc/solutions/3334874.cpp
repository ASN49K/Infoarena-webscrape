#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

vector<int> viz;
stack<int> st;
vector<vector<int>> grInit, grTr;

void dfsInit(int x) {
    viz[x] = 1;
    for (auto& y : grInit[x]) {
        if (viz[y] == 0) {
            dfsInit(y);
        }
    }

    st.push(x);
}


vector<vector<int>> compConexe;
int idx_comp = 0;
void dfsTr(int x) {
    viz[x] = 1;
    compConexe[idx_comp].push_back(x);
    for (auto& y : grTr[x]) {
        if (viz[y] == 0) {
            dfsTr(y);
        }
    }
}

int main() {
    int N, M;
    fin >> N >> M;
    grInit.resize(N + 1);
    grTr.resize(N + 1);

    for (int i = 0; i < M; i++) {
        int x, y;
        fin >> x >> y;

        grInit[x].push_back(y);
        grTr[y].push_back(x);
    }

    viz.assign(N + 1, 0);
    for (int i = 1; i <= N; i++) {
        if (viz[i] == 0) {
            dfsInit(i);
        }
    }

    compConexe.resize(N + 1);
    viz.assign(N + 1, 0);
    while(!st.empty()) {
        int crt = st.top();
        st.pop();

        if (viz[crt] == 0) {
            dfsTr(crt);
            idx_comp++;
        }
    }


    fout << idx_comp << endl;
    for (int i = 0; i < idx_comp; i++) {
        for (int& u : compConexe[i]) {
            fout << u << ' ';
        }
        fout << endl;
    }
    return 0;
}