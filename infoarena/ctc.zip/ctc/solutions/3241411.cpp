#include<fstream>//Tarjan's
#include<vector>
#include<bitset>
#include<stack>
std::ifstream fin("ctc.in");
std::ofstream fout("ctc.out");
const int NMAX=100005;
std::vector<int>G[NMAX];
int n, m;
int t=0;
std::vector<int> disc(NMAX, -1), low(NMAX, -1);
std::stack<int>st;
std::bitset<NMAX>stack_member;
std::vector<std::vector<int>>ans;
void read()
{
    fin>>n>>m;
    for(int i=0; i<m; ++i)
    {
        int from, to;
        fin>>from>>to;
        G[from].push_back(to);
    }
}

void dfs(int node)
{
    stack_member[node]=true;
    disc[node]=low[node]=t;
    ++t;
    st.push(node);
    for(auto it:G[node])
    {
        if(disc[it]==-1)
        {
            dfs(it);
            low[node]=std::min(low[node], low[it]);
        }
        else if(stack_member[it])
            low[node]=std::min(low[node], low[it]);
    }

    if(disc[node]==low[node])
    {
        std::vector<int>local;
        while(st.top()!=node)
        {
            local.push_back(st.top());
            stack_member[st.top()]=false;
            st.pop();
        }
        local.push_back(node);
        st.pop();
        stack_member[node]=false;
        ans.push_back(local);
    }
}
void displayAns()
{
    fout<<ans.size()<<'\n';
    for(auto const& it:ans)
    {
        for(auto i:it)
            fout<<i<<' ';
        fout<<'\n';
    }
}
int main()
{

    read();
    for(int i=1; i<=n; ++i)
        if(disc[i]==-1)
            dfs(i);

    displayAns();
    return 0;
}