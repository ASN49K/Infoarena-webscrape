#include <fstream>
#include <queue>
#include <vector>
#include <iostream>
using namespace std;
ifstream f("ctc.in");
ofstream g("ctc.out");
vector <int> v[100001];
vector <int> vc[100001];
int fi[100001],viz[100001],viz2[100001];
int c;
vector <int> compc[100001];
void dfs1(int x)
{
    viz[x]=1;
    for(auto i:v[x])
        if(!viz[i])
            dfs1(i);
    fi[--c]=x;
}
void dfs2(int x, int k)
{
    compc[k].push_back(x);
    viz2[x]=1;
    for(auto i:vc[x])
        if(!viz2[i])
            dfs2(i,k);
}
int main()
{
    int n,m;
    f>>n>>m;
    c=n+1;
    for(int j=1;j<=m;j++)
    {
        int x,y;
        f>>x>>y;
        v[x].push_back(y);
        vc[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(!viz[i])
            dfs1(i);
    int cnt=0;
    for(int i=1;i<=n;i++)
        if(!viz2[fi[i]])
            {cnt++; dfs2(fi[i],cnt);}
    g<<cnt<<'\n';
    for(int i=1;i<=cnt;i++){
        for(auto j:compc[i])
            g<<j<<" "; g<<'\n';}
    return 0;
}