#include <bits/stdc++.h>
using namespace std;
const int nmax = 1e5 + 5;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

int n, m, x, y, viz[nmax], culoare[nmax], cnt_culoare;
vector < int > adj[nmax], rev_adj[nmax], aproximare;
vector < int > ciclu[nmax];

void dfs1(int node){
    
    viz[node] = 1;
    
    for(auto elem : adj[node]){
        if(viz[elem] == 0){
            dfs1(elem);
        }
    }
    
    aproximare.push_back(node);
    
}

void dfs2(int node){
    
    viz[node] = 2;
    
    culoare[node] = cnt_culoare;
    ciclu[cnt_culoare].push_back(node);
    
    for(auto elem : rev_adj[node]){
        if(viz[elem] == 1){
            dfs2(elem);
        }
    }
    
}

int main()
{
    
    fin>>n>>m;
    for(int i=1;i<=m;i++){
        fin>>x>>y;
        adj[x].push_back(y);
        rev_adj[y].push_back(x);
    }
    
    for(int i=1;i<=n;i++){
        if(viz[i] == 0){
            dfs1(i);
        }
    }

    reverse(aproximare.begin() , aproximare.end());
    
    for(auto elem : aproximare){
        if(viz[elem] == 1){
            cnt_culoare ++;
            dfs2(elem);
        }
    }
    
    fout<<cnt_culoare<<"\n";
    for(int i=1;i<=cnt_culoare;i++){
        for(auto elem : ciclu[i]){
            fout<<elem<<" ";
        }
        fout<<"\n";
    }
    
    
}


