#include <bits/stdc++.h>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
#define cin fin
#define cout fout

vector<int>g[100005];
vector<int>gt[100005];
stack<int>st;
vector<int>cicluri[100005];
int visited[100005];
int n,m;
void dfs(int nod){
    visited[nod]=1;
    for(auto i:g[nod])
        if(!visited[i])dfs(i);
    st.push(nod);
}

void dfs2(int nod,int ceva){
    visited[nod]=1;
    cicluri[ceva].push_back(nod);
    for(auto i:gt[nod])
        if(!visited[i])dfs2(i,ceva);

}

int main(){
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        int n1,n2;
        cin>>n1>>n2;
        g[n1].push_back(n2);
        gt[n2].push_back(n1);
    }

    memset(visited,0,sizeof(visited));
    for(int i=1;i<=n;i++){
        if(!visited[i]){
            dfs(i);
        }
    }
    memset(visited,0,sizeof(visited));
    int cnt=0;
    while(!st.empty()){
        int nod=st.top();
        st.pop();
        if(!visited[nod]){
            cnt++;
            dfs2(nod,cnt);

        }

    }
    cout<<cnt<<'\n';
    for(int i=1;i<=cnt;i++){
        for(auto j:cicluri[i])cout<<j<<' ';
        cout<<'\n';


    }

}
