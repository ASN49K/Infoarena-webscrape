#include <fstream>
#include <vector>
#include <set>
#include <stack>

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
vector <int> de[100001],di[100001];
set <int> ctc[100001];
stack <int> st;
int n,m,x,y,nr;
bool viz[100001];
void DFS1(int k)
{
    viz[k]=1;
    for(auto it : de[k])
        if(!viz[it])
            DFS1(it);
    st.push(k);
}
void DFS2(int k)
{
    viz[k]=1;
    ctc[nr].insert(k);
    for(auto it : di[k])
        if(!viz[it])
            DFS2(it);
}
int main()
{
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        fin>>x>>y;
        de[x].push_back(y);
        di[y].push_back(x);
    }
    for(int i=1; i<=n; i++)
        if(!viz[i])
            DFS1(i);
    for(int i=1; i<=n; i++)
        viz[i]=0;
    while(!st.empty())
    {
        if(!viz[st.top()])
        {
            nr++;
            DFS2(st.top());
        }
        st.pop();
    }
    fout<<nr<<'\n';
    for(int i=1; i<=nr; i++, fout<<'\n')
        for(auto it : ctc[i])
            fout<<it<<' ';
    return 0;
}
