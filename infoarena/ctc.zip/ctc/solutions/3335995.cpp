#include  <fstream>
#include <vector>
#include <algorithm>
#include <iostream>
#include <queue>
#include <stack>
using namespace std;
const int NMAX = 1e5;
// bool havelHakimi(int deg[NMAX+1], int m) {
//
//     int sum=0;
//     for (int i=0; i<m; i++) {
//         sum+=deg[i];
//         if (deg[i]>=m) return false;
//         if (deg[i]<0) return false;
//     }
//     if ( sum%2 ==1 ) return false;
//     sort(deg, deg+m, greater<int>());
//     for (int i=0; i<m; i++) {
//         int t=deg[i];
//         if (t > m-i-1) return false;
//         for (int j=i+1; j<i+t+1; j++) {
//             deg[j]--;
//             if (deg[j]<0) return false;
//         }
//         deg[i]=0;
//         if (deg[i]>0 ) return false;
//         sort(deg, deg+m, greater<int>());
//     }
//     return true;
// }

vector<vector<int>> g;
vector<vector<int>> gT;
vector<int> viz;
stack<int> st;

void dfs(int vf){
    viz[vf]=1;
    for (int x: g[vf]) {
        if (!viz[x])
            dfs(x);

    }
    st.push(vf);
}

void dfsT(int vf, vector<int> &v) {
    viz[vf]=1;
    v.push_back(vf);
    for ( int x : gT[vf]) {
        if (!viz[x])
            dfsT(x,v);
    }
}

ifstream in ("bfs.in");
ofstream out ("bfs.out");

int main () {

    // HAVEL HAKIMI -
    // int n, m;
    // in>>n;
    // for (int i=0; i<n; i++) {
    //     in>>m;
    //     int deg[100001];
    //     for (int j=0; j<m; j++) {
    //         in>>deg[j];
    //     }
    //     int ok=havelHakimi(deg, m);
    //
    //     if (ok==1) out<<"POSSIBLE"<<endl;
    //     else out<<"IMPOSSIBLE"<<endl;
    // }


    //BFS - distanta de la un nod S la restul nodurilor
    // int n,m,a,b,s;
    // in>>n>>m>>s;
    // vector<vector<int> > adj(n+1);
    //
    // for (int i=0; i<m; i++) {
    //     in>>a>>b;
    //     adj[a].push_back(b);
    // }
    // vector<int> dist(n+1, -1);
    // queue<int> q;
    // dist[s]=0;
    // q.push(s);
    //
    // while(!q.empty()) {
    //     int u=q.front();
    //     q.pop();
    //     for ( auto i : adj[u]) {
    //         if (dist[i]==-1) {
    //             dist[i]=dist[u]+1;
    //             q.push(i);
    //         }
    //     }
    // }
    //
    // for ( int i=1; i<=n; i++ ) {
    //     out<<dist[i]<<" ";
    // }

    //DFS - cate componente conexe are un graf
    // int n,m;
    // in>>n>>m;
    // vector<vector<int>> lista(1000000);
    // for ( int i=1;i<=m;i++) {
    //     int x,y;
    //     in>>x>>y;
    //     lista[x].push_back(y);
    //     lista[y].push_back(x);
    // }
    //
    // vector< int> vis(n+1, 0);
    // vector<int> stack;
    // int comp=0;
    //
    // for (int i=1;i<=n;i++) {
    //     if (!vis[i]) {
    //         comp++;
    //         stack.clear();
    //         stack.push_back(i);
    //         vis[i]=1;
    //     }
    //     else continue;
    //     while (!stack.empty()) {
    //         int u=stack.back();
    //         stack.pop_back();
    //         for ( auto v : lista[u]) {
    //             if ( !vis[v] ) {
    //                 vis[v]=1;
    //                 stack.push_back(v);
    //             }
    //         }
    //     }
    // }
    //
    // out << comp << endl;

    //BFS - berarie2 muchii inversate
    // int n,m,p;
    // in>>n>>m>>p;
    // vector<vector<int> > adj (n+1);
    // for ( int i = 1; i <= m; i++ ) {
    //     int x,y;
    //     in>>x>>y;
    //     adj[y].push_back(x);
    // }
    // queue<int> q;
    // vector<int> vis (n+1,0);
    //
    // for (int i = 1; i <= p; i++ ) {
    //     int z;
    //     in>>z;
    //     if (!vis[z]) {
    //         vis[z] = 1;
    //         q.push(z);
    //     }
    // }
    //
    // while ( !q.empty() ) {
    //     int x = q.front();
    //     q.pop();
    //     for ( auto v: adj[x] ) {
    //         if ( !vis[v] ) {
    //             vis[v] = 1;
    //             q.push(v);
    //         }
    //     }
    // }
    // vector<int> ans;
    // for ( int i = 1; i <= n; i++ ) {
    //     if ( !vis[i] ) {
    //         ans.push_back(i);
    //     }
    // }
    // out<<ans.size()<<endl;
    // for ( int i = 0; i < ans.size(); i++ ) {
    //     out<<ans[i]<<"\n";
    // }


    // KOSARAJU - determina ctc dintr-un graf

    int n,m;
    in>>n>>m;
    g.resize(n+1);
    gT.resize(n+1);
    viz.assign(n+1, 0);
    for( int i=1;i<=m;i++) {
        int x,y;
        in>>x>>y;
        g[x].push_back(y);
        gT[y].push_back(x);
    }

    for ( int i=1;i<=n;i++) {
        if (!viz[i])
            dfs(i);
    }
    viz.assign(n+1,0);
    vector<vector<int>> comp;

    while (!st.empty()) {
        int vf = st.top();
        st.pop();
        if ( !viz[vf]) {
            vector<int> vv;
            dfsT(vf,vv);
            comp.push_back(vv);
        }
    }

    out<<comp.size()<<endl;
    for (vector<int> v : comp) {
        for (int x: v) {
            out<< x<< " ";
        }
        out<< endl;
    }

    return 0;
}

