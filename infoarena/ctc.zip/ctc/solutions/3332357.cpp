#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream f("ctc.in");
ofstream g("ctc.out");


int n,m,x,y,k;
vector<int> graf[5005];
vector<int> grafT[5005];
vector<int> visited(5005,0);
vector<vector<int>> comp;
stack<int> st;

void dfs(int nod){
    visited[nod] = 1;
    for(auto& neigh: graf[nod]){
        if(visited[neigh] == 0){
            dfs(neigh);
        }
    }
    st.push(nod);
}

void dfsT(int nod){
    visited[nod] = 2;
    comp[k].push_back(nod);
    for(auto& neigh: grafT[nod]){
        if(visited[neigh] == 1){
            dfsT(neigh);
        }
    }
}

int main(){
    f >> n >> m;
    visited.resize(n+1, 0);
    for(int i=1; i<=m; i++){
        f >> x >> y;
        graf[x].push_back(y);
        grafT[y].push_back(x);
    }
    for(int i=1; i<=n; i++){
        if(visited[i] == 0){
            dfs(i);
        }
    }
    k = 0;
    while(!st.empty()){
        int nod = st.top();
        st.pop();

        if(visited[nod] == 1){
            comp.push_back(vector<int>());
            dfsT(nod);
            k++;
        }
    }
    g << k << '\n';
    for(int i=0; i<k; i++){
        for(int j=0; j< comp[i].size(); j++){
            g << comp[i][j] << " ";
        }
        g<<'\n';
    }
}