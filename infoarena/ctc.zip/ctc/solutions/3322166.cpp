#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int N, M;
    if (!(cin >> N >> M)) return 0;
    vector<vector<int>> g(N+1), gt(N+1);
    for (int i = 0; i < M; ++i) {
        int x, y; cin >> x >> y;
        g[x].push_back(y);
        gt[y].push_back(x);
    }

    vector<char> vis(N+1, 0);
    vector<int> order;
    order.reserve(N);

    // Iterative DFS to build finishing order
    vector<pair<int,int>> stk; // {node, next_index}
    for (int s = 1; s <= N; ++s) {
        if (vis[s]) continue;
        stk.clear();
        stk.emplace_back(s, 0);
        while (!stk.empty()) {
            auto &top = stk.back();
            int v = top.first;
            int &idx = top.second;
            if (!vis[v]) {
                vis[v] = 1;
            }
            if (idx < (int)g[v].size()) {
                int to = g[v][idx++];
                if (!vis[to]) {
                    stk.emplace_back(to, 0);
                }
            } else {
                // finished v
                order.push_back(v);
                stk.pop_back();
            }
        }
    }

    // Second pass on transposed graph: collect components
    fill(vis.begin(), vis.end(), 0);
    vector<vector<int>> comps;
    comps.reserve(N);

    for (int i = (int)order.size()-1; i >= 0; --i) {
        int s = order[i];
        if (vis[s]) continue;
        vector<int> comp;
        // iterative stack for second DFS
        vector<int> st;
        st.push_back(s);
        vis[s] = 1;
        while (!st.empty()) {
            int v = st.back(); st.pop_back();
            comp.push_back(v);
            for (int to : gt[v]) if (!vis[to]) {
                vis[to] = 1;
                st.push_back(to);
            }
        }
        comps.push_back(move(comp));
    }

    // Output
    cout << comps.size() << '\n';
    for (auto &c : comps) {
        for (size_t j = 0; j < c.size(); ++j) {
            if (j) cout << ' ';
            cout << c[j];
        }
        cout << '\n';
    }
    return 0;
}
