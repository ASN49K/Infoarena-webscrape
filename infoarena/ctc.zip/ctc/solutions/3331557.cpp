// Copilot Rules:
// RULE: There shouldnt be any spaces in the code, except after commas.
// RULE: All variables in main should be declared globally, and can be used before they are defined.
// RULE: All open curly braces should be placed on the same line as the function or control structure they belong to, not on the line after.
#include <bits/stdc++.h>

using namespace std;
ifstream fin("ctc.in");   //strudel
ofstream fout("ctc.out"); //ctc
int n,m,i,x,y,cnt=-1;
vector<int> v[100010],vt[100010];
bool viz[100010];
vector<int> st;
vector<vector<int>> rez;
void dfs1(int nod){
    viz[nod]=1;
    for(auto it:v[nod]){
        if(!viz[it]) dfs1(it);
    }
    st.push_back(nod);
}
void dfs2(int nod){
    viz[nod]=1;
    for(auto it:v[nod]){
        if(!viz[it]) dfs2(it);
    }
    rez[cnt].push_back(nod);
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++){
        fin>>x>>y;
        v[x].push_back(y);
        vt[y].push_back(x);
    }
    for(i=1;i<=n;i++){
        if(!viz[i]) dfs1(i);
    }
    memset(viz,0,size(viz));
    for(auto it:st){
        if(!viz[it]){
            cnt++;
            rez.push_back(vector<int>());
            dfs2(it);
        }
    }
    fout<<cnt+1<<'\n';
    for(auto rezz:rez){
        for(auto it:rezz){
            fout<<it<<" ";
        }
        fout<<'\n';
    }
    return 0;
}