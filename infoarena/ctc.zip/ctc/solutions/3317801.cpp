#include <fstream>
#include <vector>
#include <algorithm>
#include <cstring>
#define nmax (int)(1e5+1)
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
int n,m,x,y;
bool viz[nmax];
vector<int>v[nmax],vr[nmax],tsort,aux;
vector<vector<int>>c;
void dfs(int nod){
    viz[nod]=1;
    for(auto i:v[nod])
        if(!viz[i])
            dfs(i);
    tsort.push_back(nod);
}
void dfsr(int nod){
    viz[nod]=1;
    for(auto i:vr[nod])
        if(!viz[i])
            dfsr(i);
    aux.push_back(nod);
}
signed main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back(y);
        vr[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(!viz[i])
            dfs(i);
    memset(viz,0,sizeof(viz));
    reverse(tsort.begin(),tsort.end());
    for(auto i:tsort)
        if(!viz[i]){
            aux.clear();
            dfsr(i);
            c.push_back(aux);
        }
    cout<<c.size()<<'\n';
    for(auto i:c){
        for(auto j:i)
            cout<<j<<" ";
        cout<<'\n';
    }
    return 0;
}
