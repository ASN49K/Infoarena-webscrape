#include <bits/stdc++.h>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
vector <vector <int> >G(100005),GT(100005);
stack <int> f;
int n,m,k,nctc,nrk,v[100005];
void dfsG(int k)
{
    v[k]=1;
    for(int i=0;i<G[k].size();i++)
        if(!v[G[k][i]])
        dfsG(G[k][i]);
    f.push(k);
}
void dfsGT(int k,int nrc)
{
    v[k]=nrc;
    for(int i=0;i<GT[k].size();i++)
        if(!v[GT[k][i]])
        dfsGT(GT[k][i],nrc);
}
void kosaraju()
{
    for(int i=1;i<=n;i++)
        if(!v[i])
        dfsG(i);

    for(int i=1;i<=n;i++)
        v[i]=0;

    while(!f.empty())
    {
        if(!v[f.top()])
        {
            nctc++;
            dfsGT(f.top(),nctc);
        }
        f.pop();
    }
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        G[x].push_back(y);
        GT[y].push_back(x);
    }
    kosaraju();
    fout<<nctc<<'\n';
    for(int i=1;i<=nctc;i++)
    {

     for(int j=1;j<=n;j++)
        if(v[j]==i)
        fout<<j<<" ";

    fout<<'\n';
    }

    return 0;
}
