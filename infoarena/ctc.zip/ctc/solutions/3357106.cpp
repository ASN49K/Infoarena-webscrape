#include <fstream>
#include <vector>

using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

const int N = 1e5;

int n, m;

vector<vector<int>> g;

void getPostOrder(int node, vector<vector<int>> &g, vector<int> &postOrder,
				  vector<bool> &visited) {
	if (visited[node])
		return;
	visited[node] = true;
	for (auto v : g[node]) {
		if (!visited[v]) {
			getPostOrder(v, g, postOrder, visited);
		}
	}
	postOrder.push_back(node);
}

vector<int> getPostOrder(vector<vector<int>> &g) {
	vector<bool> visited(n);
	vector<int> postOrder;
	for (int i{}; i < n; i++) {
		getPostOrder(i, g, postOrder, visited);
	}
	return postOrder;
}

void sccDfs(int node, vector<vector<int>> &gt, vector<bool> &visited,
			vector<int> &component) {
	if (visited[node])
		return;
	visited[node] = true;
	component.push_back(node);
	for (auto v : gt[node]) {
		if (!visited[v]) {
			sccDfs(v, gt, visited, component);
		}
	}
}

vector<vector<int>> getSCC(vector<vector<int>> &g) {
	vector<int> postOrder = getPostOrder(g);
	vector<vector<int>> gt(g.size());

	for (size_t i{}; i < g.size(); i++) {
		for (auto v : g[i]) {
			gt[v].push_back(i);
		}
	}

	vector<vector<int>> ret;
	vector<bool> visited(g.size());

	for (auto v : gt) {
		for (auto x : v) {
		}
	}
	for (size_t i{postOrder.size()}; i--;) {
		vector<int> component;
		sccDfs(postOrder[i], gt, visited, component);
		if (!component.empty()) {
			ret.push_back(component);
		}
	}
	return ret;
}

int main() {
	fin >> n >> m;

	g.resize(n);

	for (int i{m}; i--;) {
		int a, b;
		fin >> a >> b;
		a--, b--;
		g[a].push_back(b);
	}

	vector<vector<int>> ans = getSCC(g);
	fout << ans.size() << '\n';
	for (auto comp : ans) {
		for (auto x : comp) {
			fout << x + 1 << ' ';
		}
		fout << '\n';
	}
	return 0;
}
