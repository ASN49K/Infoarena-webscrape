#include <fstream>
#include <vector>
#include <cstring>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n,m,nr,nrc;
vector<int>v[100001],vt[100001],cc[100001];
bool viz[100001];
int stop[100001];
void dfs(int k){
    viz[k]=1;
    for(auto i:v[k])
    if(viz[i]==0){
        dfs(i);
    }
    stop[++nr]=k;
}
void dfs2(int k){
    viz[k]=1;
    cc[nrc].push_back(k);
    for(auto i:vt[k])
    if(viz[i]==0){
        dfs2(i);
    }
}
int main()
{
    fin>>n>>m;
    int x,y;
    for(int i=1;i<=m;i++){
        fin>>x>>y;
        v[x].push_back(y);
        vt[y].push_back(x);
    }
    for(int i=1;i<=n;i++){
        if(viz[i]==0){
            dfs(i);
        }
    }
    memset(viz,0,sizeof(viz));
    for(int i=n;i>=1;i--){
        if(viz[stop[i]]==0){
            nrc++;
            dfs2(stop[i]);
        }
    }
    fout<<nrc<<'\n';
    for(int i=1;i<=nrc;i++){
        for(auto j:cc[i])
            fout<<j<<" ";
        fout<<'\n';
    }
    return 0;
}
