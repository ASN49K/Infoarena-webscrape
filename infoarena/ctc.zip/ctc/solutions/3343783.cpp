#include <fstream>
#include <stack>
#include <vector>
#define nmax (int)(1e5+1)
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
int n,m,x,y,k,minlv[nmax],niv[nmax];
bool viz[nmax],in[nmax];
vector<int>v[nmax],aux;
vector<vector<int>>ctc;
stack<int>s;
void dfs(int nod){
    niv[nod]=minlv[nod]=++k;
    viz[nod]=in[nod]=1;
    s.push(nod);
    for(auto i:v[nod])
        if(!viz[i]){
            dfs(i);
            if(in[i])
                minlv[nod]=min(minlv[nod],minlv[i]);
        }else if(in[i])
            minlv[nod]=min(minlv[nod],niv[i]);
    if(minlv[nod]==niv[nod]&&in[nod]){
        aux.clear();
        while(!s.empty()&&s.top()!=nod){
            in[s.top()]=0;
            aux.push_back(s.top());
            s.pop();
        }
        in[nod]=0;
        aux.push_back(nod);
        s.pop();
        ctc.push_back(aux);
    }
}
signed main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
        if(!viz[i])
            dfs(i);
    cout<<ctc.size()<<'\n';
    for(auto i:ctc){
        for(auto j:i)
            cout<<j<<" ";
        cout<<'\n';
    }
    return 0;
}
