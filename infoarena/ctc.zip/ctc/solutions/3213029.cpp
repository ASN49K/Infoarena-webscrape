#include <bits/stdc++.h>

using namespace std;

ifstream fin("ctc.in");ofstream fout("ctc.out");

const int N=1001;
int n,m;
vector<int>g[N];
int disc[N],llink[N],t;
bool deschis[N];
stack<int> st_noduri;
vector<int>comp[N];
int ncomp;



//vector<int> disc(N,0);
//vector<int> llink(N,0);
//bitset<N>instack;
//stack<int> st;


void Citire()
{
    fin >> n >> m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin >> x >> y;
        g[x].push_back(y);
    }
}

void DFS(int x)
{
    disc[x]=llink[x]=++t;
    deschis[x]=1;
    st_noduri.push(x);

    for(auto y:g[x])
    {
        if( !disc[y] )
        {
            DFS(y);
            llink[x]=min(llink[x],llink[y]);
        }
        else if( deschis[y] )
            llink[x]=min(llink[x],llink[y]);
    }
    if( disc[x]==llink[x] )
    {
        ++ncomp;
        while( st_noduri.top()!=x )
        {
            comp[ncomp].push_back( st_noduri.top() );
            deschis[ st_noduri.top() ]=0;
            st_noduri.pop();
        }
        comp[ncomp].push_back( st_noduri.top() );
        deschis[ st_noduri.top() ]=0;
        st_noduri.pop();
    }
}

void Afisare()
{
    fout << ncomp ;
    for(int i=1;i<=ncomp;i++)
    {
        fout << "\n";
        for(auto x:comp[i])
            fout << x << " ";
    }
}

int main()
{
    Citire();
    for(int i=1;i<=n;i++)
        if( !disc[i] )
            DFS(i);
    Afisare();
    return 0;
}
