#include <bits/stdc++.h>
using namespace std;

class Task {
public:
    void solve() {
        read_input();
        print_output(get_result());
    }

private:
    // numarul maxim de noduri
    static constexpr int NMAX = (int)1e5 + 5; // 10^5 + 5 = 100.005

    // n = numar de noduri, m = numar de muchii/arce
    int n, m;

    // adj[node] = lista de adiacenta a nodului node
    // exemplu: daca adj[node] = {..., neigh, ...} => exista arcul (node, neigh)
    vector<int> adj[NMAX];
    vector<int> adj_transp[NMAX];
    void read_input() {
        ifstream fin("ctc.in");
        fin >> n >> m;
        for (int i = 1, x, y; i <= m; i++) {
            fin >> x >> y;
            adj[x].push_back(y); // arc (x, y)
            adj_transp[y].push_back(x);
        }
        fin.close();
    }

    vector<vector<int>> get_result() {
        //
        // TODO: Găsiți componentele tare conexe  (CTC / SCC) ale grafului orientat cu n noduri, stocat în adj.
        //
        // Rezultatul se va returna sub forma unui vector, fiecare element fiind un SCC (adică tot un vector).
        // * nodurile dintr-un SCC pot fi găsite în orice ordine
        // * SCC-urile din graf pot fi găsite în orice ordine
        //
        // Indicație: Folosiți algoritmul lui Tarjan pentru SCC.
        //
        vector<int> p(n + 1, -1);
        vector<int> ended;
        vector<vector<int>> all_sccs;
        for (int i = 1; i <= n; i++) {
            if (p[i] == -1) {
                p[i] = 0;
                dfs(i, p, ended);
            }
        }
        // ended.push_back(0);
        // ended.reserve(ended.size());
        // for (int i = 1; i <= n; i++) {
            // for (auto aux : adj_transp[i])
                // cout << i << "| " << aux << ' ';
            // cout << endl;
        // }
        for (int i = 1; i <= n; i++)
            p[i] = -1;
        reverse(ended.begin(), ended.end());
        for (auto aux : ended) {
            if (p[aux] == -1) {
                cout << "new ctc : " << aux << endl;
                p[aux] = 0;
                vector<int> new_ctc;
                new_ctc.push_back(aux);
                dfs2(aux, p, new_ctc);

                all_sccs.push_back(new_ctc);
            }
        }
        return all_sccs;
    }
    void dfs(int current, vector<int> &p, vector<int> &ended) {
        for (auto neigh : adj[current]) {
            if (p[neigh] == -1) {
                p[neigh] = current;
                dfs(neigh, p, ended);
            }
        }
        ended.push_back(current);
    }
    void dfs2(int current, vector<int> &p, vector<int> &new_ctc) {
        for (auto neigh : adj_transp[current]) {
            if (p[neigh] == -1) {
                p[neigh] = current;
                cout << "added " << neigh << endl;
                new_ctc.push_back(neigh);
                dfs2(neigh, p, new_ctc);
            }
        }
    }



    void print_output(const vector<vector<int>>& all_sccs) {
        ofstream fout("ctc.out");
        fout << all_sccs.size() << '\n';
        for (const auto& scc : all_sccs) {
            for (auto node : scc) {
                fout << node << ' ';
            }
            fout << '\n';
        }
        fout.close();
    }
};

// [ATENTIE] NU modifica functia main!
int main() {
    // * se aloca un obiect Task pe heap
    // (se presupune ca e prea mare pentru a fi alocat pe stiva)
    // * se apeleaza metoda solve()
    // (citire, rezolvare, printare)
    // * se distruge obiectul si se elibereaza memoria
    auto* task = new (nothrow) Task(); // hint: cppreference/nothrow
    if (!task) {
        cerr << "new failed: WTF are you doing? Throw your PC!\n";
        return -1;
    }
    task->solve();
    delete task;
    return 0;
}
