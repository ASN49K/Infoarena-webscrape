/*#include <fstream>
#include <vector>

using namespace std;

ifstream f("ctc.in");
ofstream g("ctc.out");

struct nod
{
    vector <int> vec;
};

struct nod_ref
{
    int val, ind;
};


nod v1[100005];
nod v2[100005];
int n, m;
int viz[100005];
nod_ref aux[100005];
int timp;
nod rez[100005];
int ans;

void dfs(int k)
{
    viz[k] = 1;

    for(int i = 0; i<v1[k].vec.size(); i++)
    {
        if(viz[v1[k].vec[i]] == 0)
        {
            dfs(v1[k].vec[i]);
            timp++;
        }
    }

}

void qs(int st, int dr)
{
    if(st < dr)
    {
        int m = (st + dr) / 2;
        swap(aux[st], aux[m]);

        int i = st;
        int j = dr;
        int d = 0;

        while(i < j)
        {
            if(aux[i].val > aux[j].val)
            {
                swap(aux[i], aux[j]);
                d = 1 - d;
            }
            i += d;
            j -= 1 - d;
        }

        qs(st, i-1);
        qs(i+1, dr);
    }

}

void dfs2(int k)
{
    viz[k] = 1;
    rez[ans].vec.push_back(k);

    for(int i = 0; i<v2[k].vec.size(); i++)
    {
        if(viz[v2[k].vec[i]] == 0)
        {
            dfs2(v2[k].vec[i]);
        }
    }
}

int main()
{
    f>>n>>m;
    int st, dr;
    for(int i = 1; i<=m; i++)
    {
        f>>st>>dr;
        v1[st].vec.push_back(dr);
        v2[dr].vec.push_back(st);
    }

    for(int i = 1; i<=n; i++)
    {
        timp = 0;
        dfs(i);
        aux[i].val = timp;
        aux[i].ind = i;

        for(int j = 1; j<=n; j++)
        {
            viz[j] = 0;
        }
    }

    qs(1, n);


    for(int i = n; i>=1; i--)
    {
        if(viz[aux[i].ind] == 0)
        {
            ans++;
            dfs2(aux[i].ind);
        }
    }

    g<<ans<<'\n';
    for(int i = 1; i<=ans; i++)
    {
        for(int j = 0; j<rez[i].vec.size(); j++)
        {
            g<<rez[i].vec[j]<<" ";
        }
        g<<'\n';
    }


    return 0;
}*/

#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream in("ctc.in");
ofstream out("ctc.out");

const int N = 1e5 +2, M= 2e5+2;
int n, m, v2[N];
bool v[N];
vector <int> pred[N];
vector <int> urm[N];
vector <int> r[N];
stack <int> stiv;

void dfs1(int nd){
    v[nd] = 1;
    for( auto i: urm[nd] ){
        if( v[i] == 0){
            dfs1(i);
        }
    }
    stiv.push(nd);
}

void dfs2(int nd, int secret){
    v2[nd] = secret;
    for(auto i: pred[nd] ){
        if(v2[i] == 0){
            dfs2(i, secret);
        }
    }
}

int main()
{
    in >> n >> m;
    for(int i=1; i<=m; i++){
        int x, y;
        in >> x >> y;
        urm[x].push_back(y);
        pred[y].push_back(x);
    }

    for(int i=1; i<=n; i++){
        if(v[i] == 0){
            dfs1(i);
        }
    }

    int cnt=0;
    while ( !stiv.empty() ){
        int nd =  stiv.top();
        stiv.pop();
        if(v2[nd] == 0){
            cnt++;
            dfs2(nd, cnt);
        }
    }

    for(int i=1;  i<=n; i++){
        r[v2[i]].push_back(i);
    }

    out << cnt << "\n";
    for(int i=1; i<=cnt; i++){
        for(auto j: r[i] ){
            out << j << " ";
        }
        out << "\n";
    }


    return 0;
}
