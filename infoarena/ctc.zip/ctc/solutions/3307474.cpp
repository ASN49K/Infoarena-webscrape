#include <fstream>
#include <algorithm>
#include <vector>
#include <stack>
using namespace std;

ifstream cin("ctc.in");
ofstream cout("ctc.out");

int n, m, ans;
vector<int> adj[100005], rev_adj[100005];
vector<int> comp[100005];
stack<int> st;
bool viz[100005];

void dfs_1(int nod){
    viz[nod]=1;
    for(auto vec:adj[nod]){
        if(!viz[vec]){
            dfs_1(vec);
        }
    }
    st.push(nod);
}

void dfs_2(int nod){
    viz[nod]=1;
    comp[ans].push_back(nod);
    for(auto vec:rev_adj[nod]){
        if(!viz[vec]){
            dfs_2(vec);
        }
    }
}

int main(){
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        int x, y;
        cin>>x>>y;
        adj[x].push_back(y);
        rev_adj[y].push_back(x);
    }
    for(int i=1;i<=n;i++){
        if(!viz[i]){
            dfs_1(i);
        }
    }
    for(int i=1;i<=n;i++){
        viz[i]=0;
    }
    while(!st.empty()){
        int nod=st.top();
        st.pop();
        if(!viz[nod]){
            ans++;
            dfs_2(nod);
        }
    }
    cout<<ans<<'\n';
    for(int i=1;i<=ans;i++){
        sort(comp[i].begin(), comp[i].end());
        for(auto it:comp[i]){
            cout<<it<<" ";
        }
        cout<<'\n';
    }
}
