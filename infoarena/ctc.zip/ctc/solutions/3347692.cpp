#include <bits/stdc++.h>

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n,m;
vector<vector<int>> nodes, T;
stack <int> st;
vector<vector<int>>sol;
int viz[100010];
void dfs(int node)
{
    if(!viz[node])
    {
        viz[node] = 1;
        for(auto v : nodes[node])
            dfs(v);
        st.push(node);


    }
}
int cnt;
void dfs2(int node)
{
    if(viz[node])
    {
        viz[node] = 0;
        sol[cnt].push_back(node);
        for(auto v : T[node])
            dfs2(v);
    }
}
int main()
{
    ios::sync_with_stdio(false);
    fin.tie(nullptr);
    fin >> n >> m;
    nodes.resize(n + 1);
    T.resize(n + 1);
    for(int i = 1; i <= m; i++)
    {
        int u,v;
        fin >> u >> v;
        nodes[u].push_back(v);
        T[v].push_back(u);
    }
    for(int i =1 ; i <= n; i++)
        if(!viz[i])
            dfs(i);
    cnt = 0;
    sol.resize(n + 1);
    while(!st.empty())
    {
        int u = st.top();
        st.pop();
        if(viz[u])
        {
            cnt++;
            dfs2(u);

        }
    }
    fout << cnt << '\n';
    for(int i = 1; i <= cnt; i++, fout << '\n')
        for(auto u : sol[i])
            fout << u << ' ';
    return 0;
}
