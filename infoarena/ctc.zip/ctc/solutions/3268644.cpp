#include <iostream>
#include <fstream>
#include <vector>

#include <stack>
using namespace std;
ifstream in("ctc.in");
ofstream out("ctc.out");
vector <int> v[200005];
vector <int> v2[200005];
vector <int> vs[200005];
stack <int> s;
int n,m,x,y,cnt;
bool f[200005];
void dfs(int nod)
{
    s.push(nod);
    f[nod]=1;
    for(int i:v[nod])
        if(!f[i])
    {
        f[i]=1;
        dfs(i);
    }
}
void dfs2(int nod)
{
    f[nod]=0;
    for(int it:v2[nod])
    {
        if(f[it])
        {
            vs[cnt].push_back(it);
            //out<<it<<" ";
            f[it]=0;
            dfs2(it);
        }
    }
}
int main()
{
    in>>n>>m;
    for(int i=1;i<=m;i++)
        {in>>x>>y;
        v[x].push_back(y);
        v2[y].push_back(x);
        }
    for(int i=1;i<=n;i++)
    {
        if(!f[i]) dfs(i);
    }
    while(!s.empty())
    {
        if(f[s.top()])
        {   cnt++;
            vs[cnt].push_back(s.top());
            //out<<s.top()<<" ";
            dfs2(s.top());
        //out<<'\n';
        }
        s.pop();
    }
    out<<cnt<<'\n';
    for(int i=1;i<=cnt;i++)
    {
        for(int it:vs[i])
            out<<it<<" ";
        out<<'\n';
    }
    return 0;
}
