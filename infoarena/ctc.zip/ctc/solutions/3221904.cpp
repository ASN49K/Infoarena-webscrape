#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
#include <stack>
using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

vector <int> L[100005], Lt[100005], a;
vector < vector<int> > comp;
stack <int> st;
bitset <100005> v;
int n, m;

void DFS(int k)
{
    v[k] = 1;
    for (int i : L[k])
        if (!v[i])
            DFS(i);
    st.push(k);
}

void DFS1(int k)
{
    v[k] = 1;
    a.push_back(k);
    for (int i : Lt[k])
        if (!v[i])
            DFS1(i);
}

int main()
{
    int i, x, y;
    fin >> n >> m;
    for (i = 1; i <= m; i++)
    {
        fin >> x >> y;
        L[x].push_back(y);
        Lt[y].push_back(x);
    }

    for (i = 1; i <= n; i++)
        if (!v[i])
            DFS(i);
    v.reset();
    while (!st.empty())
    {
        x = st.top();
        st.pop();
        if (v[x]) continue;
        DFS1(x);
        comp.push_back(a);
        a.clear();
    }

    fout << comp.size() << "\n";
    for (vector <int> a : comp)
    {
        for (int i : a)
            fout << i << " ";
        fout << "\n";
    }
    return 0;
}
