#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
using namespace std;
ifstream f("ctc.in");
ofstream g("ctc.out");
vector <vector<int>> ListaAdiacenta, ListaTranspusa, solutie;
vector <int> vizitat;
stack <int> stiva;
int nr_comp_conexe = 0;


void DFS(int x)
{
    vizitat[x]++;
    for(int i : ListaAdiacenta[x])
    {
        if(vizitat[i]==0)
            DFS(i);
    }
    stiva.push(x);
}

void DFST(int x)
{
    vizitat[x]++;
    solutie[nr_comp_conexe].push_back(x);
    for(int i : ListaTranspusa[x])
    {
        if(vizitat[i]==1)
            DFST(i);
    }

}
int main()
{
    int N, M, x, y;
    f>>N>>M;
    ListaAdiacenta.resize(N+1);
    ListaTranspusa.resize(N+1);
    solutie.resize(N+1);
    vizitat.resize(N+1, 0);

    for(int i=0; i<N; i++)
    {
        f>>x>>y;
        ListaAdiacenta[x].push_back(y);
        ListaTranspusa[y].push_back(x);
    }

    for(int i=1; i<=N;i++)
        if(vizitat[i]==0)
            DFS(i);

    while(stiva.size()!=0)
    {
        x = stiva.top();
        stiva.pop();
        if(vizitat[x]==1)
        {
            nr_comp_conexe++;
            DFST(x);
        }
    }

    g<<nr_comp_conexe;
    for(int i=1; i<=nr_comp_conexe; i++)
    {
        for(auto x: solutie[i])
            g<<x<<' ';
        g<<'\n';
    }


    return 0;
}
