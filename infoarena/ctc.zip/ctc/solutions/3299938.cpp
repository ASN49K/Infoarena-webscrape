#include <bits/stdc++.h>
#define cin ci
#define cout co
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
int n, m, x, y, ctc;
vector<vector<int>> graf, graft;
vector<int> viz, ord, comp;
void dfs(int node)
{
    viz[node] = 1;
    for(auto next:graf[node])
        if(!viz[next])
            dfs(next);
    ord.push_back(node);
}
void dfst(int node)
{
    viz[node] = 1;
    comp[node] = ctc;
    for(auto next:graft[node])
        if(!viz[next])
            dfst(next);
}
int main()
{
    cin >> n >> m;
    graf.assign(n+1, vector<int>());
    graft.assign(n+1, vector<int>());
    viz.resize(n+1);
    comp.resize(n+1);
    for(int i=1; i<=m; i++)
    {
        cin >> x >> y;
        graf[x].push_back(y);
        graft[y].push_back(x);
    }
    for(int i=1; i<=n; i++)
        if(!viz[i])
            dfs(i);
    reverse(ord.begin(), ord.end());
    fill(viz.begin(), viz.end(), 0);
    for(auto i:ord)
        if(!viz[i])
        {
            ctc++;
            dfst(i);
        }
    vector<vector<int>> ans;
    ans.resize(ctc+1, vector<int>());
    for(int i=1; i<=n; i++)
        ans[comp[i]].push_back(i);
    cout << ctc << '\n';
    for(int i=1; i<=ctc; i++, cout << '\n')
        for(auto j:ans[i])
            cout << j << " ";
    return 0;
}
