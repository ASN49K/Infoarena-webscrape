#include <fstream>
#include <vector>

using namespace std;

const int NMAX = 100001;

int N, M, nrc;
vector<int> G[NMAX], GT[NMAX];
vector<int> CTC[NMAX]; // CTC[i] = lista nodurilor din a i-a c.t.c.
vector<int> Post;      // Lista nodurilor lui G in ordinea finalizarii
                       // acestora in parcurgerea DFS

bool viz[NMAX];

ifstream f("ctc.in");
ofstream g("ctc.out");

void citire()
{
    int x, y;
    f >> N >> M;
    while (M--)
    {
        f >> x >> y;
        G[x].push_back(y);
        GT[y].push_back(x);
    }
}

void dfs(int vf)
{
    viz[vf] = 1;
    for(int x : G[vf])
        if(viz[x] == 0)
            dfs(x);
    Post.push_back(vf); // s-a finalizat parcurgerea din vf
}

void dfsGT(int vf)
{
    viz[vf] = 0;
    CTC[nrc].push_back(vf);
    for(int x : GT[vf])
        if(viz[x] == 1)
            dfsGT(x);
}

void componente() // Algoritmul Kosaraju-Sharir (1978)
{
    int i;
    for(i = 1; i <= N; ++i)
        if(viz[i] == 0)
            dfs(i);

    for(i = Post.size() - 1; i >= 0; --i)
        if(viz[Post[i]] == 1)
        {
            nrc++;
            dfsGT(Post[i]);
        }
}

void afisare()
{
    g << nrc << '\n';
    for(int i = 1; i <= nrc; ++i)
    {
        for(int x : CTC[i])
            g << x << ' ';
        g << '\n';
    }
}

int main()
{
    citire();
    componente();
    afisare();
    f.close();
    g.close();
    return 0;
}
