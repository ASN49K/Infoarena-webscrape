#include <bits/stdc++.h>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");

int n, m, viz[100001], k, a[100001], cnt;
vector <int> G[100001], GT[100001], CTC[100001];

void DFS(int nod)
{
    viz[nod] = 1;
    for (auto next : G[nod])
        if (viz[next] == 0)
            DFS(next);
    a[++k] = nod;
}

void DFS_GT(int nod)
{
    viz[nod] = 1;
    CTC[cnt].push_back(nod);
    for (auto next : GT[nod])
        if (viz[next] == 0)
            DFS_GT(next);
}

int main()
{
    int i, x, y;
    fin >> n >> m;
    for (i = 1 ; i <= m ; i++)
    {
        fin >> x >> y;
        G[x].push_back(y);
        GT[y].push_back(x);
    }
    for (i = 1 ; i <= n ; i++)
        if (viz[i] == 0)
            DFS(i);
    for (i = 1 ; i <= n ; i++)
        viz[i] = 0;
    for (i = k ; i >= 1 ; i--)
        if (viz[a[i]] == 0)
    {
        ++cnt;
        DFS_GT(a[i]);
    }
    fout << cnt << "\n";
    for (i = 1 ; i <= cnt ; i++)
    {
        for (auto next : CTC[i])
            fout << next << " ";
        fout << "\n";
    }
    return 0;
}
