//
// Created by Cristian Constantin on 20.05.2024.
//
#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
#include <algorithm>

using namespace std;

const int MAXN = 100001;

vector<int> adj[MAXN], adjRev[MAXN];
vector<vector<int>> scc;
bitset<MAXN> visited;
vector<int> order;

void dfs(int node) {
    visited[node] = true;
    for (int neighbor : adj[node]) {
        if (!visited[neighbor]) {
            dfs(neighbor);
        }
    }
    order.push_back(node);
}

void dfsReverse(int node) {
    visited[node] = true;
    scc.back().push_back(node);
    for (int neighbor : adjRev[node]) {
        if (!visited[neighbor]) {
            dfsReverse(neighbor);
        }
    }
}

int main() {
    ifstream fin("ctc.in");
    ofstream fout("ctc.out");

    int n, m;
    fin >> n >> m;

    for (int i = 0; i < m; ++i) {
        int u, v;
        fin >> u >> v;
        adj[u].push_back(v);
        adjRev[v].push_back(u);
    }

    for (int i = 1; i <= n; ++i) {
        if (!visited[i]) {
            dfs(i);
        }
    }

    visited.reset();
    reverse(order.begin(), order.end());

    for (int node : order) {
        if (!visited[node]) {
            scc.emplace_back();
            dfsReverse(node);
        }
    }

    fout << scc.size() << "\n";
    for (const auto& component : scc) {
        for (int node : component) {
            fout << node << " ";
        }
        fout << "\n";
    }

    return 0;
}
