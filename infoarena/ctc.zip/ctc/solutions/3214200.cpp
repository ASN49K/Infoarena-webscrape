#include <fstream>
#include <vector>
#include <algorithm>
#include <cstring>
#define nmax 11005
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");

vector<int> ctc[nmax];
vector<int> g[nmax];
vector<int> gt[nmax];
vector<int> v;
int n, m, nr, x, y;
bool viz[nmax];

void dfs1(int nod)
{
    viz[nod]=1;
    for(auto x : g[nod])
        if(!viz[x])
            dfs1(x);
    v.push_back(nod);
}


void dfs2(int nod)
{
    viz[nod]=1;
    for(auto y : gt[nod])
        if(!viz[y])
            dfs2(y);
    ctc[nr].push_back(nod);
}

int main()
{
    cin>>n>>m;
    while(m--)
    {
        cin>>x>>y;
        g[x].push_back(y);
        gt[y].push_back(x);
    }

    // sortare topologica pe primul dfs
    for(int i=1; i<=n; i++)
        if(!viz[i])
            dfs1(i);

    memset(viz,0,sizeof(viz));
    while(!v.empty())
    {
        int curr=v.back();
        v.pop_back();
        if(!viz[curr])
        {
            nr++;
            dfs2(curr);
        }
    }
    cout<<nr<<'\n';
    for(int i=1; i<=nr; i++)
    {
        for(auto sol : ctc[i])
            cout<<sol<<' ';
        cout<<'\n';
    }
    return 0;
}
