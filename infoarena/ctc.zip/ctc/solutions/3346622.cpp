#include <bits/stdc++.h>

using namespace std;
ifstream in("ctc.in");
ofstream out("ctc.out");
int n,m,i,j,x,y,nrc;
bool viz[200001];
stack<int>st;
set<int>v[200000];
set<int>vt[200000];
set<int>sol[200000];
void dfs1(int x){
     viz[x]=1;
     for(auto y:v[x]){
        if(viz[y]==0) dfs1(y);
     }
     st.push(x);
}
void dfs2(int x){
     sol[nrc].insert(x);
     viz[x]=1;
     for(auto y:vt[x]) if(viz[y]==0) dfs2(y);
}
int main()
{
    in>>n>>m;
    for(i=1;i<=m;i++){
        in>>x>>y;
        v[x].insert(y);
        vt[y].insert(x);
    }
    for(i=1;i<=n;i++){
        if(viz[i]==0) dfs1(i);
    }
    for(i=1;i<=n;i++) viz[i]=0;
    while(!st.empty()){
         x=st.top();
         st.pop();
         if(viz[x]==0){
            nrc++;
            dfs2(x);
         }
    }
    out<<nrc<<"\n";
    for(i=1;i<=nrc;i++){
        for(auto k:sol[i]){
            out<<k<<" ";
        }
        out<<"\n";
    }
    return 0;
}
