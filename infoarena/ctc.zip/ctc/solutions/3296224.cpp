#include <fstream>
#include <vector>
#include <queue>

using namespace std;

int n, m;
const int nbutconst = 100005;
vector<int> adiacente[nbutconst], adiacenteinvers[nbutconst];
bool viz[nbutconst];
int postordine[nbutconst], pol = 0;
vector<int> ctc[nbutconst]; int ctcl = 0;

void dfs1(int pos)
{
    viz[pos] = 1;
    for (auto it:adiacente[pos])
    {
        if (!viz[it])
        {
            dfs1(it);
        }
    }
    postordine[pol++] = pos;
}

void dfs2(int pos)
{
    viz[pos] = 0;
    for (auto it:adiacenteinvers[pos])
    {
        if (viz[it])
        {
            dfs2(it);
        }
    }
    ctc[ctcl].push_back(pos);
}

int main()
{
    ifstream cin("ctc.in");
    ofstream cout("ctc.out");
    cin >> n >> m;
    for (int i = 0; i < m; i++)
    {
        int x, y;
        cin >> x >> y;
        adiacente[x].push_back(y);
        adiacenteinvers[y].push_back(x);
    }
    dfs1(1);
    for (int i = n; i >= 1; i--)
    {
        if (viz[postordine[i]])
        {
            ctcl++;
            dfs2(postordine[i]);
        }
    }
    cout << ctcl << "\n";
    for (int i = 1; i <= ctcl; i++)
    {
        for (auto it:ctc[i])
        {
            cout << it << " ";
        }
        cout << "\n";
    }
    return 0;
}
