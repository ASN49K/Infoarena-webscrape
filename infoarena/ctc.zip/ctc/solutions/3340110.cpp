#include <fstream>
#include <vector>
#define NMAX 100002
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n,nr,m,poz;
vector<int> G[NMAX];
vector<int> GT[NMAX];
int nrct;
vector<int> CTC [NMAX];
bool viz[NMAX];
int postordine[NMAX];
void citire();
void afisare();
void dfs(int x);
void dfst(int x);

int main()
{
    int i;
    citire();
    for (i=1; i<=n; i++)
         if (viz[i]==0) dfs(i);
    for (i=n; i>=1; i--)
         if (viz[postordine[i]]==1)
            {
              nrct++;
              dfst(postordine[i]);
            }
    afisare();
    return 0;
}
void citire()
{
    int i,x,y;
    fin>>n>>m;
    for (i=0; i<m; i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
        GT[y].push_back(x);
    }
}
void afisare()
{
    int i,j;
    fout<<nrct<<'\n';
    for (i=1; i<=nrct; i++)
         { for (j=0; j<CTC[i].size(); j++)
             fout<<CTC[i][j]<<' ';
            fout<<'\n';
         }

}
void dfs(int x)
{
    int i;
    //parcurg LAD a lui x
    viz[x]=1;
    for (i=0; i<G[x].size(); i++)
         if (viz[G[x][i]]==0)
             dfs(G[x][i]);
    postordine[++poz]=x;
}
void dfst(int x)
{
    int i;
    viz[x]=0;
    CTC[nrct].push_back(x);
    for (i=0; i<GT[x].size(); i++)
         if (viz[GT[x][i]]==1)
             dfst(GT[x][i]);
}
