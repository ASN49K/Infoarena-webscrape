#include <bits/stdc++.h>
using namespace std;
ifstream fin("sortaret.in");
ofstream fout("sortaret.out");
const int nmax=3e5;
vector <int> graf[nmax+5], tgraf[nmax+5], topo, afisare[nmax+5];
int Use[nmax+5];
void DFS(int nod)
{
    Use[nod]=1;
    for(auto vecin : graf[nod])
    {
        if(Use[vecin]==0)
            DFS(vecin);
    }
    topo.push_back(nod);
}
void DFSM(int nod, int grupa)
{
    Use[nod]=grupa;
    for(auto vecin : tgraf[nod])
    {
        if(Use[vecin]==0)
            DFSM(vecin, grupa);
    }
    afisare[Use[nod]].push_back(nod);
}
void reUse()
{
    for(int i=0; i<nmax+5; i++)
        Use[i]=0;
}
int main()
{
    int x,y,n,m;
    fin>>n>>m;
    for(int i=0; i<m; i++)
    {
        fin>>x>>y;
        graf[x].push_back(y);
        tgraf[y].push_back(x);
    }
    for(int i=1; i<=n; i++)
        if(!Use[i])
        {
            DFS(i);
        }
    int counter=0;
    reUse();
    for(int i=topo.size()-1; i>=0; i--)
    {
        if(Use[topo[i]]==0)
        {
            counter++;
            DFSM(topo[i], counter);
        }
    }
    fout<<counter<<'\n';
    for(int i=1; i<=counter; i++)
    {
        for(auto j : afisare[i])
        {
            fout<<j<<" ";
        }
        fout<<"\n";
    }
    return 0;
}
