#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
#include <stack>
#include <algorithm>

using namespace std;

ifstream fin ("ctc.in");
ofstream fout ("ctc.out");

vector <int> L[100005], T[100005];
bitset<100001> viz;
stack <int> st;

int n, m;

void Read()
{
    fin >> n >> m;
    while (m--) {
        int x, y;
        fin >> x >> y;
        L[x].push_back(y);
        T[y].push_back(x);
    }
}

void DFS1(int nod)
{
    viz[nod] = 1;
    for (auto next : L[nod])
        if (!viz[next])
            DFS1(next);
    st.push(nod);
}

void DFS2(int nod, vector <int> & temp)
{
    viz[nod] = 1;
    temp.push_back(nod);
    for (auto next : T[nod])
        if (!viz[next])
            DFS2(next, temp);
}

void Kosaraju()
{
    for (int i = 1; i <= n; i++)
        if (!viz[i])
            DFS1(i);
    viz.reset();
    vector<vector<int> > ctc;
    while (!st.empty())
    {
        int nod = st.top();
        st.pop();
        if (!viz[nod])
        {
            vector <int> temp;
            DFS2(nod, temp);
            ctc.push_back(temp);
        }
    }
    fout << ctc.size() << "\n";
    for (auto& it : ctc)
    {
        sort(it.begin(), it.end());
        for (auto j : it)
            fout << j << " ";
        fout << "\n";
    }
}

int main(){
    Read();
    Kosaraju();
    return 0;
}
