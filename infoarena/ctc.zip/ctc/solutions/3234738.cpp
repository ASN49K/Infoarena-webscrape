#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
#include <bitset>
#include <stack>
using namespace std;

ifstream fin("test.in");
ofstream fout("test.out");

int n, m, Grad[100005], k;
vector<int> G[100005], GT[100005], ctc[100005];
stack<int> st;
bitset<100005> viz;

void DFS(int x)
{
	viz[x] = true;
	for (auto w : G[x])
		if (!viz[w]) DFS(w);
	st.push(x);
}

void dfsGT(int x)
{
	viz[x] = true;
	ctc[k].push_back(x);
	for (auto w : GT[x])
		if (!viz[w]) dfsGT(w);
}

int main()
{
	int i, j, x;
	fin >> n >> m;
	while (m--)
	{
		fin >> i >> j;
		G[i].push_back(j);
		GT[j].push_back(i);
	}
	for (i = 1; i <= n; i++)
		if (!viz[i]) DFS(i);
	viz.reset();
	k = 0;
	while (!st.empty())
	{
		x = st.top();
		st.pop();
		if (!viz[x])
		{
			dfsGT(x);
			k++;
		}
	}
	fout << k << "\n";
	for (auto j : ctc)
	{
		if (j.size() == 0) break;
		for (auto f : j)
			fout << f << " ";
		fout << "\n";
	}
	return 0;
}