#include <fstream>
#include <bits/stdc++.h>

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n, m, i, j, x, y, nrc;
vector <int> v[100005], vt[100005];
set <int> comp[100005];
stack <int> st;
bool viz[100005];
void dfs1(int nod)
{
    viz[nod]=1;
    for(auto i: v[nod])
        if(viz[i]==0)
            dfs1(i);
    st.push(nod);
}
void dfs2(int nod)
{
    viz[nod]=1;
    comp[nrc].insert(nod);
    for(auto i: vt[nod])
        if(viz[i]==0)
            dfs2(i);
}
int main()
{
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
        vt[y].push_back(x);
    }
    for(i=1; i<=n; i++)
        if(viz[i]==0)
            dfs1(i);
    for(i=1; i<=n; i++)
        viz[i]=0;
    while(!st.empty())
    {
        int x=st.top();
        st.pop();
        if(viz[x]==0)
        {
            nrc++;
            dfs2(x);
        }
    }
    fout<<nrc<<'\n';
    for(i=1; i<=nrc; i++)
    {
        for(auto j: comp[i])
            fout<<j<<" ";
        fout<<'\n';
    }

    return 0;
}
