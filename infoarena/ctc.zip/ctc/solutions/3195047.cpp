#include <bits/stdc++.h>

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");

vector <int> G[100002];
vector <int> GT[100002];
vector <int> out;
vector <int> sol[100002];
bitset <100002> viz;
void dfs(int nod){
    viz[nod] = 1;
    for(auto x : G[nod]){
        if(!viz[x]) dfs(x);
    }
    out.push_back(nod);
}
void dfs2(int nod, vector <int> &v){
    viz[nod] = 1;
    v.push_back(nod);
    for(auto x : GT[nod]){
        if(!viz[x]) dfs2(x,v);
    }
}
int main()
{
    int n,m,i,u,v,k = 0;
    fin >> n >> m;
    for(i = 1; i <= m; i++){
        fin >> u >> v;
        G[u].push_back(v);
        GT[v].push_back(u);
    }
    for(i = 1; i <= n; i++) if(!viz[i]) dfs(i);
    viz.reset();
    reverse(out.begin(), out.end());
    for(i = 1; i <= n; i++)
        if(!viz[i]) dfs2(i, sol[++k]);
    fout << k << "\n";
    for(i = 1; i <= k; i++){
        for(auto x : sol[i]) fout << x << " ";
        fout << "\n";
    }
    return 0;
}
