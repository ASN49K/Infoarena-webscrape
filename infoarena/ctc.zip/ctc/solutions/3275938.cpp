#include <iostream>
#include <fstream>
#include <queue>
#include <bitset>
#include <vector>
#include <stack>
#include <algorithm>

#define maxSize 100001

using namespace std;

vector<vector<int>> readAdjacencyList(ifstream &fin, int nodes, int edges, bool isDirected = false) {
    vector<vector<int>> adjList(nodes + 1);
    for (int i = 0; i < edges; i++) {
        int x, y;
        fin >> x >> y;
        adjList[x].push_back(y);
        if (!isDirected) {
            adjList[y].push_back(x);
        }
    }
    return adjList;
}

vector<vector<int>> transposeGraph(const vector<vector<int>>& adjList) {
    int nodes = adjList.size();
    vector<vector<int>> transposed(nodes);

    for (int i = 1; i < nodes; i++) {
        for (const auto& neighbor : adjList[i]) {
            transposed[neighbor].push_back(i);
        }
    }

    return transposed;
}

void depthFirstSearch(const vector<vector<int>>& adjList, int node, bitset<maxSize>& marked, stack<int>& topOrd) {
    marked[node] = true;

    for (auto neighbor : adjList[node]) {
        if (!marked[neighbor]) {
            depthFirstSearch(adjList, neighbor, marked, topOrd);
        }
    }
    topOrd.push(node);
}

void dsfComponent(const vector<vector<int>>& transposed, int node, bitset<maxSize>& marked, vector<int>& component) {
    marked[node] = true;
    component.push_back(node);

    for (const auto& neighbor : transposed[node]) {
        if (!marked[neighbor]) {
            dsfComponent(transposed, neighbor, marked, component);
        }
    }
}

vector<vector<int>> kosarajuAlgorithm(const vector<vector<int>>& adjList) {
    bitset<maxSize> marked;
    stack<int> topOrd;

    for (int i = 1; i < adjList.size(); i++) {
        if(!marked[i]) {
            depthFirstSearch(adjList, i, marked, topOrd);
        }
    }

    vector<vector<int>> transposed = transposeGraph(adjList);

    marked.reset();
    vector<vector<int>> stronglyConnectedComponents;

    while (!topOrd.empty()) {
        int node = topOrd.top();
        topOrd.pop();

        if (!marked[node]) {
            vector<int> component;
            dsfComponent(transposed, node, marked, component);
            stronglyConnectedComponents.push_back(component);
        }
    }

    return stronglyConnectedComponents;
}

int main() {
    ifstream fin("ctc.in");
    ofstream fout("ctc.out");

    int nodes, edges;
    fin >> nodes >> edges;

    auto adjList = readAdjacencyList(fin, nodes, edges, true);
    auto stronglyConnectedComponents = kosarajuAlgorithm(adjList);

    for (const auto& component : stronglyConnectedComponents) {
        for (const auto& node : component) {
            fout << node << " ";
        }
        fout << endl;
    }

    fin.close();
    fout.close();

    return 0;
}
