#include <bits/stdc++.h>

using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

const int NMAX = 1e5;

int n, m, x, y, cnt;
vector <int> v[NMAX+1];
vector <int> t[NMAX+1];
vector <int> ans[NMAX+1];
vector <int> inv;
vector <bool> trecut;

void dfs1(int nod)
{
    trecut[nod] = true;
    for(auto a : v[nod])
        if(!trecut[a])
            dfs1(a);
    inv.push_back(nod);
}

void dfs2(int nod)
{
    trecut[nod] = true;
    for(auto a : t[nod])    
        if(!trecut[a])
            dfs2(a);
    ans[cnt].push_back(nod);
}

int main()
{
    fin >> n >> m;
    for(int i=1; i<=m; i++)
    {
        fin >> x >> y;
        v[x].push_back(y);
        t[y].push_back(x);
    }
    trecut = vector<bool>(n+1,0);
    for(int i=1; i<=n; i++)
        if(!trecut[i])
            dfs1(i);
    trecut = vector<bool>(n+1,0);   
    cnt = 0;
    while(!inv.empty())
    {
        if(!trecut[inv.back()])
        {
            cnt++;
            dfs2(inv.back());
        }
        inv.pop_back();
    }
    fout << cnt << '\n';
    for(int i=1; i<=cnt; i++, fout << '\n')
        for(auto a : ans[i])
            fout << a << ' ';
    return 0;
}