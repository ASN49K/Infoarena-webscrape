#include <bits/stdc++.h>

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
typedef pair<int,int> pii;
vector<pii> g;
vector<int> muchii[100005],nodes,st;
bool use[100005];
vector<vector<int>> sol;
int n,m;
void dfs1(int nod)
{
    use[nod]=1;
    for(int i:muchii[nod])
        if(!use[i])
            dfs1(i);
    st.push_back(nod);
}
void dfs2(int nod)
{
    nodes.push_back(nod);
    use[nod]=1;
    for(int i:muchii[nod])
        if(!use[i])
            dfs2(i);
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        muchii[a].push_back(b);
        g.push_back({a,b});
    }
    for(int i=1;i<=n;i++)
        if(!use[i])
            dfs1(i);
    reverse(st.begin(),st.end());
    for(int i=1;i<=n;i++)
    {
        muchii[i].clear();
        use[i]=0;
    }
    for(pii i:g)
        muchii[i.second].push_back(i.first);
    for(int i:st)
        if(!use[i])
        {
            nodes.clear();
            dfs2(i);
            sol.push_back(nodes);
        }
    fout<<sol.size()<<'\n';
    for(auto i:sol)
    {
        for(int j:i)
            fout<<j<<' ';
        fout<<'\n';
    }
    return 0;
}
