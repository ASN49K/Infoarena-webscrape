#include <bits/stdc++.h>

using namespace std;

const int NMAX=1e5;
int n, m;
vector<int> g[NMAX+1], rev[NMAX+1], order;
bool viz[NMAX+1];
vector<vector<int>> comp;

void dfs(int nod, vector<int> &ans)
{
    viz[nod]=true;
    for(auto &copil:g[nod])
        if(!viz[copil])
            dfs(copil, ans);
    ans.push_back(nod);
}

void dfs_rev(int nod, vector<int> &ans)
{
    viz[nod]=true;
    for(auto &copil:rev[nod])
        if(!viz[copil])
            dfs_rev(copil, ans);
    ans.push_back(nod);
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    freopen("ctc.in", "r", stdin);
    freopen("ctc.out", "w", stdout);
    cin>>n>>m;
    for(int i=1, x, y; i<=m; i++)
    {
        cin>>x>>y;
        g[x].push_back(y);
        rev[y].push_back(x);
    }
    for(int i=1; i<=n; i++)
        if(!viz[i])
            dfs(i, order);
    reverse(order.begin(), order.end());
    for(int i=1; i<=n; i++)
        viz[i]=false;

    for(auto &nod:order)
    {
        if(!viz[nod])
        {
            vector<int> this_component;
            dfs_rev(nod, this_component);
            comp.push_back(this_component);
        }
    }
    cout<<comp.size()<<'\n';
    for(auto &x:comp)
    {
        for(auto &y:x)
            cout<<y<<' ';
        cout<<'\n';
    }

    return 0;
}
