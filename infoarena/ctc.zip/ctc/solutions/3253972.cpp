#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
int n, m, x, y, ctc;
vector<vector<int>> graf, graft;
vector<int> component, ord, viz;
void dfs(int node)
{
    viz[node] = 1;
    for(auto next:graf[node])
        if(!viz[next])
            dfs(next);
    ord.push_back(node);
}
void dfst(int node)
{
    viz[node] = 1;
    component[node] = ctc;
    for(auto next:graft[node])
        if(!viz[next])
            dfst(next);

}
vector<vector<int>> ans;
int main()
{
    cin >> n >> m;
    viz.resize(n+1);
    component.resize(n+1);
    graf.assign(n+1, vector<int>());
    graft.assign(n+1, vector<int>());
    ans.resize(n+1, vector<int>());
    for(int i=1; i<=m; i++)
    {
        cin >> x >> y;
        graf[x].push_back(y);
        graft[y].push_back(x);
    }
    for(int i=1; i<=n; i++)
        if(!viz[i])
            dfs(i);
    reverse(ord.begin(), ord.end());
    fill(viz.begin(), viz.end(), 0);

    for(auto i:ord)
        if(!viz[i])
        {
            ctc++;
            dfst(i);
        }
    cout << ctc << '\n';

    for(int i=1; i<=n; i++)
        ans[component[i]].push_back(i);
    for(auto i:ans)
    {
        for(auto node:i)
            cout << node << " ";
        if(i.size())
            cout << '\n';
    }


    return 0;
}
