#include <fstream>
#include <vector>
#include <stack>
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
long long n, i, j, k, nr[500005],low[500005],X,g,ctc,m,x,y,s[500005];
vector <long long> v[500005],sol[500005];
bool in[500005];
void dfs(int x)
{
    s[++k]=x;
    in[x]=1;
    g++;
    low[x]=g;
    nr[x]=g;
    for(int i=0;i<v[x].size();i++)
        if(nr[v[x][i]]==0)
        {
            dfs(v[x][i]);
            low[x]=min(low[x],low[v[x][i]]);
        }
        else
            if(in[v[x][i]])
        {
            low[x]=min(low[x],low[v[x][i]]);
        }
    if(low[x]==nr[x])
    {
        ctc++;
        do
        {
           X=s[k];
           k--;
           sol[ctc].push_back(X);
           in[X]=0;
        }while(X!=x);
    }
}
int main ()
{
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y;
        v[x].push_back(y);
    }
    for(i=1;i<=n;i++)
        if(nr[i]==0)
            dfs(i);
    cout<<ctc<<"\n";
    for(i=1;i<=ctc;i++,cout<<"\n")
        for(j=0;j<sol[i].size();j++)
            cout<<sol[i][j]<<" ";
    return 0;
}
