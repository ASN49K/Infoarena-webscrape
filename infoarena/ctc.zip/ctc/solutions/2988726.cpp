#include <bits/stdc++.h>
using namespace std;

class tarjan {

  const vector<vector<int>>& adj;
  vector<int> id, low;
  vector<bool> onStack;
  stack<int> st;
  int cid = 0;

  void dfs(int u) {
    
    id[u] = low[u] = cid++;
    onStack[u] = true;
    st.push(u);

    for (int v : adj[u]) {
      if (id[v] == -1) dfs(v);
      if (onStack[v]) low[u] = min(low[u], low[v]);
    }

    if (low[u] == id[u]) {
      while (onStack[u]) {
        int v = st.top();
        st.pop();
        onStack[v] = false;
        low[v] = id[u];
      }
    }
    
  }


  public:


  vector<int> scc() const {
    return low;
  }


  tarjan(int n, const vector<vector<int>>& graph) : adj(graph) {
    
    id.resize(n + 1, -1);
    low.resize(n + 1, -1);
    onStack.resize(n + 1, false);

    for (int i = 0; i <= n; i++) {
      if (id[i] == -1) {
        dfs(i);
      }
    }
    
  }
};

void solve() {
  
  int n, m;
  cin >> n >> m;

  vector<vector<int>> adj(n + 1);
  for (int i = 0; i < m; i++) {
    int u, v;
    cin >> u >> v;
    adj[u].push_back(v);
  }

  vector<int> scc = tarjan(n, adj).scc();

  adj.clear();
  adj.resize(n + 1);
  for (int i = 1; i <= n; i++) adj[scc[i]].push_back(i);

  int cnt = 0;
  for (int i = 1; i <= n; i++) {
    cnt += !adj[i].empty();
  }
  
  cout << cnt << '\n';
  for (const vector<int>& v : adj) {
    if (v.empty()) continue;
    for (int u : v) {
      cout << u << ' ';
    }
    cout << '\n';
  }

}

int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("ctc.in", "r", stdin);
  freopen("ctc.out", "w", stdout);
  #endif

  ios_base::sync_with_stdio(false), cin.tie(NULL);

  solve();
}
