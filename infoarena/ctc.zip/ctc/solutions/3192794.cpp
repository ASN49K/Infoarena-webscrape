#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>
const int NMAX=200005;

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");

void dfs(int, int);

vector <int> v[NMAX], ct[NMAX];
int n, m, low[NMAX], in[NMAX], ctc, lvl;
stack <int> st;
bool inst[NMAX];

int main()
{
    int a, b, i;
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>a>>b;
        v[a].push_back(b);
    }
    for(i=1; i<=n; i++)
    {
        if(!low[i]) dfs(i, 1);
    }
    fout<<ctc<<'\n';
    for(i=1; i<=n; i++)
    {
        sort(ct[i].begin(), ct[i].end());
        for(auto i:ct[i]) fout<<i<<' ';
        fout<<'\n';
    }
    return 0;
}

void dfs(int nod, int lvl)
{
    low[nod]=lvl;
    st.push(nod); inst[nod]=true;
    for(auto i:v[nod])
    {
        if(!low[i])
        {
            dfs(i, lvl+1);
            low[nod]=min(low[nod], low[i]);
        }
        else if(inst[i]) low[nod]=min(low[nod], low[i]);
    }
    if(lvl==low[nod])
    {
        ctc++;
        int newnod;
        do
        {
            newnod=st.top();
            ct[ctc].push_back(newnod);
            st.pop(); inst[newnod]=false;
        }while(nod!=newnod);
    }
}
