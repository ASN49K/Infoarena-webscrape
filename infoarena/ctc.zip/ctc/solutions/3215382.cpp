#include <fstream>
#include <vector>
using namespace std;
ifstream cin("ciclueuler.in");
ofstream cout("ciclueuler.out");
using pii = pair<int,int>;
const int nmax = 1e5 + 1;
vector <int> ciclu;
vector <pii> g[nmax];
int n , m , a , b , gr[nmax] , cnt;
bool used[nmax] , viz[nmax];
void count_edges(int x)
{
    viz[x] = 1;
    cnt += g[x].size();
    for(auto it : g[x])
    {
        if(!viz[it.first]) count_edges(it.first);
    }
}
void eulerc(int x)
{
    for(auto it : g[x])
    {
        if(!used[it.second])
        {
            used[it.second] = 1;
            eulerc(it.first);
        }
    }
    ciclu.push_back(x);
}
signed main()
{
    cin >> n >> m;
    int asta = -1;
    for(int i = 1 ; i <= m ; ++i)
    {
        cin >> a >> b;
        g[a].push_back({b,i});
        g[b].push_back({a,i});
        gr[a]++;
        gr[b]++;
        asta = a;
    }
    for(int i = 1 ; i <= n ; ++i) if(gr[i]%2){ cout << -1; return 0;}
    count_edges(asta);
    if(m*2 != cnt)
    {
        cout << -1;
        return 0;
    }
    eulerc(1);
    for(auto it : ciclu) cout << it << ' ';
    cout << '\n';
    return 0;
}

