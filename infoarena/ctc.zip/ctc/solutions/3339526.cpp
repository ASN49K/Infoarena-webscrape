#include <fstream>
#include <algorithm>
#include <queue>
#include <vector>
using namespace std;

ifstream cin("ctc.in");
ofstream cout("ctc.out");

int n, m, indeg[100005], ctc[100005], cnt;
vector<int> adj[100005], adj2[100005], st;
bool viz[100005];

void dfs1(int nod){
    viz[nod]=1;
    for(auto it:adj[nod]){
        if(!viz[it]){
            dfs1(it);
        }
    }
    st.push_back(nod);
}

void dfs2(int nod){
    ctc[nod]=cnt;
    for(auto it:adj2[nod]){
        if(ctc[it]==0){
            dfs2(it);
        }
    }
}

int main(){
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        int x, y;
        cin>>x>>y;
        adj[x].push_back(y);
        adj2[y].push_back(x);
    }
    for(int i=1;i<=n;i++){
        if(!viz[i])dfs1(i);
    }
    reverse(st.begin(), st.end());
    for(auto it:st){
        if(!ctc[it])cnt++,dfs2(it);
    }
    cout<<cnt<<'\n';
    for(int i=1;i<=cnt;i++){
        for(int j=1;j<=n;j++){
            if(ctc[j]==i){
                cout<<j<<" ";
            }
        }
        cout<<'\n';
    }
}
