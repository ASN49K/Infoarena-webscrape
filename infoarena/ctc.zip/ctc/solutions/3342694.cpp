#include <bits/stdc++.h>
#define cin ci
#define cout co
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
int n, m;
vector<vector<int>> graf, gt;
vector<int> sorttop, viz;
void dfs(int node)
{
    viz[node] = 1;
    for(auto next : graf[node])
        if(!viz[next])
            dfs(next);

    sorttop.push_back(node);
}
int ctc = 0;
vector<int> comp;
void dfst(int node)
{
    comp[node] = ctc;
    for(auto next : gt[node])
        if(!comp[next])
            dfst(next);
}
int main()
{
    cin.tie(0);
    ios_base::sync_with_stdio(0);
    cin >> n >> m;
    graf.assign(n + 5, vector<int>());
    gt.assign(n + 5, vector<int>());
    viz.assign(n + 5, 0);

    for(int i = 1; i <= m; i ++)
    {
        int x, y;
        cin >> x >> y;
        graf[x].push_back(y);

        gt[y].push_back(x);
    }
    for(int i = 1; i <= n; i ++)
        if(!viz[i])
            dfs(i);
    reverse(sorttop.begin(), sorttop.end());
    comp.assign(n + 5, 0);
    for(int i = 1; i <= n; i ++)
        if(!comp[i])
        {
            ctc ++;
            dfst(i);
        }
    vector<vector<int>> ans(ctc + 5, vector<int>());

    for(int i = 1; i <= n; i ++)
        ans[comp[i]].push_back(i);

    cout << ctc << '\n';
    for(int i = 1; i <= ctc; i ++, cout << '\n')
        for(auto j : ans[i])
            cout << j << " ";
    return 0;
}
