#include<iostream>
#include<fstream>
#include<vector>
#include<algorithm>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
const int NMAX=1e5+5;
vector<int>v[NMAX],rev[NMAX];
int n,m,viz[NMAX],idx;
vector<int>topo,comp[NMAX];
void dfs(int nod){
    viz[nod]=1;
    for(auto f:v[nod]){
        if(viz[f]==0)dfs(f);
    }
    topo.push_back(nod);
}
void dfs1(int nod){
    viz[nod]=0;
    for(auto f:rev[nod]){
        if(viz[f]==1)dfs1(f);
    }
    comp[idx].push_back(nod);
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++){
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        rev[y].push_back(x);
    }
    for(int i=1;i<=n;i++)if(!viz[i])dfs(i);
    topo.push_back(0);
    reverse(topo.begin(),topo.end());
    for(int i=1;i<=n;i++){
        int acm=topo[i];
        if(viz[acm]==1){
        idx++;
        dfs1(acm);
        }
    }
    fout<<idx<<'\n';
    for(int i=1;i<=idx;i++){
        for(auto f:comp[i])fout<<f<<' ';
        fout<<'\n';
    }
    return 0;
}
