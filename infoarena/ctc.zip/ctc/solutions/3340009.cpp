#include <bits/stdc++.h>

using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

const int lim=3e5+10;
int i,n,m,comp;
bool viz[lim];
vector <int> v[lim],g[lim];
vector <int> a;
set <int> s[lim];
void dfs_scc(int k)
{
    viz[k]=1;
    for(auto x:v[k])
    {
        if(viz[x]==0)
            dfs_scc(x);
    }
    a.push_back(k);
}

void clear_viz(int n)
{
    int i;
    for(i=1;i<=n;i++)
        viz[i]=0;
}

void components(int k)
{
    viz[k]=1;
    s[comp].insert(k);
    for(auto x:g[k])
    {
        if(viz[x]==0)
            components(x);
    }
}
int main()
{
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        v[x].push_back(y);
        g[y].push_back(x);
    }
    dfs_scc(1);
    clear_viz(n);
    reverse(a.begin(),a.end());
    for(auto x:a)
    {
        if(viz[x]==0)
            {
                comp++;
                components(x);
            }
    }
    fout<<comp<<'\n';
    for(i=1;i<=comp;i++)
    {
        for(auto x:s[i])
            fout<<x<<" ";
        fout<<'\n';
    }
    return 0;
}
