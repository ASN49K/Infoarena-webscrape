#include <bits/stdc++.h>

#define DIM 100000

using namespace std;

ifstream f("ctc.in");
ofstream g("ctc.out");

int n,m;
int x,y;

int k;
int sortTop[DIM+5];

vector<int>  L[DIM+5];
vector<int> Lt[DIM+5];

int compk = 0;
vector<int> comp[DIM+5];

bool viz1[DIM+5];
void dfs1(int nod){

    viz1[nod] = 1;
    for(auto vec:L[nod]){
        if(!viz1[vec]){
            dfs1(vec);
        }
    }

    sortTop[++k] = nod;
}

bool viz2[DIM+5];
void dfs2(int nod){

    comp[compk].push_back(nod);

    viz2[nod] = 1;
    for(auto vec:Lt[nod]){
        if(!viz2[vec]){
            dfs2(vec);
        }
    }
}

int main()
{
    f>>n>>m;
    for(int i=1;i<=m;i++){
        f>>x>>y;
        L[x].push_back(y);
        Lt[y].push_back(x);
    }

    for(int i=1;i<=n;i++){
        if(!viz1[i]){
            dfs1(i);
        }
    }

    for(int j=n;j>=1;j--){
        int i = sortTop[j];
        if(!viz2[i]){
            compk++;
            dfs2(i);
        }
    }

    g<<compk<<'\n';
    for(int i=1;i<=compk;i++){
        for(auto j:comp[i]){
            g<<j<<" ";
        }
        g<<'\n';
    }


    return 0;
}
