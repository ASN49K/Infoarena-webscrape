#include <iostream>
#include <vector>
#include <queue>
using namespace std;

vector <int> L[100001];
int in[100001];
int lvl[10001];
int main()
{
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        cin >> x >> y;
        L[x].push_back(y);
        in[y]++;
    }
    queue<int> q;
    for (int i = 1; i <= n; i++)
        if (!in[i])
            q.push(i),lvl[i]=0;
    while (!q.empty())
    {
        int curr = q.front();
        q.pop();
        for (auto it : L[curr])
        {
            lvl[it] = max(lvl[it], lvl[curr] + 1);
            in[it]--;
            if (in[it] == 0)
                q.push(it);
        }
    }
    int maxx = 0;
    for (int i = 1; i <= n; i++)
        maxx = max(maxx, lvl[i]);
    cout << maxx;
    return 0;
}