#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>

using namespace std;

ifstream f("ctc.in");
ofstream g("ctc.out");

const int N_MAX = 100001;
int n, m, nrCTC; /// nr comp. tare conexe

vector<int> vecini[N_MAX], veciniTr[N_MAX];
vector<vector<int> > CTC;
vector<bool> viz;

stack<int> S;

void DFS(int nod){
    viz[nod] = true;
    for(const int& vecin : vecini[nod])
        if(not viz[vecin])
            DFS(vecin);

    S.push(nod);
}

void DFSTr(int nod){
    viz[nod] = true;
    CTC[nrCTC].push_back(nod);

    for(const int& vecin : veciniTr[nod])
        if(not viz[vecin])
            DFSTr(vecin);
}

int main()
{
    f >> n >> m;

    for(int i = 0, n1, n2; i < m; ++i){
        f >> n1 >> n2;
        vecini[n1].push_back(n2);
        veciniTr[n2].push_back(n1);
    }

    viz.resize(n + 1, false);
    for(int i = 1; i <= n; ++i)
        if(not viz[i])
            DFS(i);

    viz.assign(n + 1, false);
    CTC.push_back({0}); /// nu folosesc CTC[0]

    while(not S.empty()){
        int nod = S.top();
        S.pop();

        if(not viz[nod]){
            nrCTC++;
            CTC.push_back({});
            DFSTr(nod);
        }
    }

    g << nrCTC << '\n';

    int sz = CTC.size();
    for(int i = 0; i < sz; ++i)
        sort(CTC[i].begin(), CTC[i].end());

    sort(CTC.begin(), CTC.end(),
         [](const vector<int>& a, const vector<int>& b){
            return a[0] < b[0];
    });

    for(int i = 1; i < sz; ++i){
        for(const int& x : CTC[i])
            g << x << ' ';
        g << '\n';
    }

    return 0;
}
