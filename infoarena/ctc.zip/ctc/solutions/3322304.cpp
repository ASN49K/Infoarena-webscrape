#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>
using namespace std;

ifstream fin ("ctc.in");
ofstream fout("ctc.out");

vector<vector<int>> graf;
vector<vector<int>> graft;
vector<int> viz;
vector<int> cc;
stack<int> st;

void dfs(int x)
{
    viz[x] = 1;
    for(auto& i: graf[x])
    {
        if(viz[i] == 0)
            dfs(i);
    }
    st.push(x);
}

void dfst(int x)
{
    viz[x] = 1;
    int top = st.top();
    cc.push_back(top);
    st.pop();
    for(auto& i : graft[x])
        if(viz[i] == 0)
            dfst(i);
}

/*
void bfs(int x)
{
    viz[x] = 1;
    noduri_vizitate++;
    while(!coada.empty())
    {
        for(auto &i : graft[x])
        {
            if(viz[i] == 0)
            {
                viz[i] = 1;
                // niv[i] = niv[x] + 1;
                noduri_vizitate++;
                coada.push(i);
            }
        }
        coada.pop();
        if(!coada.empty())
            x = coada.front();
    }
}*/

int main()
{
    int N, M;
    fin>>N>>M;
    graf.resize(N+1);
    graft.resize(N+1);
    viz.assign(N+1, 0);
    //cc.resize(N+1);

    for(int i=1; i<=M; i++)
    {
        int x, y;
        fin>>x>>y;
        graf[x].push_back(y);
        graft[y].push_back(x);
    }

    for(int i=1; i<=N; i++)
    {
        if(viz[i] == 0)
            dfs(i);
    }

    for(int i=1; i<=N; i++)
        viz[i] = 0;

    int nr = 0;
    int top;
    while(!st.empty())
    {
        top = st.top();
        if(viz[top] == 0)
        {
            nr++;
            dfst(top);
            cc.push_back(-1);
        }
    }

    fout<<nr<<'\n';
    for(auto& i : cc)
        if(i != -1)
            fout<<i<<' ';
        else
            fout<<'\n';



    return 0;
}
