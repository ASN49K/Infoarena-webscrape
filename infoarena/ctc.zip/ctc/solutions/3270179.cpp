#include <fstream>
#include <vector>
#define NMAX 100001

using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

int n, nrc, nr;
//gf initial repr prin liste de adiac
vector<int> G[NMAX];
//gf transpus
vector<int> GT[NMAX];
vector<int>ctc[NMAX]; //ctc[i]contine vf din comp tare conexa i
int post[NMAX];
bool viz[NMAX];

void citire();
void afisare();
void DFS(int x);
void DFST(int x);

int main()
{
    int i;
    citire();
    //parcurgem DFS pe G si constr vect post
    for(i=1; i<=n; i++)
        if(!viz[i]) DFS(i);
    //parcurg vect post de la dr la st si DFS in Gt
    for(i=n; i>0; i--)
        if(viz[post[i]]) //post de i este neviz in Gt
    {
        //am identificat o noua comp tare conexa
        nrc++;
        DFST(post[i]);
    }
    afisare();
    return 0;
}

void citire()
{
    int m, x, y, i;
    fin >> n >> m;
    for(i=0; i<m; i++)
    {
        fin >> x >> y;
        //exista arc de la x la y in G
        G[x].push_back(y);
        //exista arc de la y la x in Gt
        GT[y].push_back(x);
    }
}

void DFS(int x)
{
    int i;
    viz[x]=1;
    //parcurg lista de adiac
    for(i=0; i<G[x].size(); i++)
        if(!viz[G[x][i]])
            DFS(G[x][i]);
    post[++nr]=x;
}

void DFST(int x)
{
    int i;
    viz[x]=0; //inainte vect era plin cu 1
    ctc[nrc].push_back(x);
    for(i=0; i<GT[x].size(); i++)
        if(viz[GT[x][i]])
            DFST(GT[x][i]);

}

void afisare()
{
    int i, j;
    fout << nrc << '\n';
    for(i=1; i<=nrc; i++)
        //afisez nodurile din ctc i
    {
        for(j=0; j<ctc[i].size(); j++)
            fout << ctc[i][j] << " ";
        fout << '\n';
    }
}
