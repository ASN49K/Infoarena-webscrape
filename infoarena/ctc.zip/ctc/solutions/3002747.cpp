#include <bits/stdc++.h>

using namespace std;

ifstream fin("rmq.in");
ofstream fout("rmq.out");

int n, m, rmq[20][100005], e[100005];

int main()
{
    int i, j, x, y;
    fin >> n >> m;
    for (i = 1; i <= n; i++)
        fin >> rmq[0][i];

    e[1] = 0;
    for (i = 2; i <= n; i++)
        e[i] = e[i / 2] + 1;

    for (i = 1; i <= e[n]; i++)
        for (j = 1; j <= n - (1 << i) + 1; j++)
        rmq[i][j] = min(rmq[i - 1][j], rmq[i - 1][j + (1 << (i - 1))]);

    while (m--)
    {
        fin >> x >> y;
        i = e[y - x + 1];
        fout << min(rmq[i][x], rmq[i][y - (1 << i) + 1]) << "\n";
    }

    return 0;
}
