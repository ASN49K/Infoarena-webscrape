#include <bits/stdc++.h>

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");


int n,m;
array<vector<int>,101> adj;
vector<vector<int>> ans;

unordered_map<int,bool> vis,comp;
/*
 * nrc - numarul de componente conexe
 * cnt - variabila care tine minte o eticheta
 * inf -
 * low[x] = eticheta rootului  nodului x
 * num[x] = eticheta lui x
 * stk - o stiva care memoreaza nodurile parcurse in ordine
 */
const int inf = -1;
const int nmax = 100001;
int nrc,cnt;
vector<int> low(nmax),num(nmax,inf),stk;
void solve(int x) {
    stk.push_back(x); // adaugam nodul
    comp[x] = vis[x] = true; // notam nodul ca fiind vizitat si componenta

    low[x] = num[x] = ++cnt; // marcam nodul cu o eticheta unica, devenind un root al sau provizoriu


    if (x == 8) {
        cout << low[x] << ' ' << num[x] << endl;
    }
    for (const int y : adj[x]) {
        if (num[y] == inf) { // daca nodul nu
            solve(y); // parcurgem dfs
            low[x] = min(low[x],low[y]); // radacina lui x devine nodul marcat minim
            if (x == 8) {
                cout << low[x] << ' ' << low[y] << endl;
            }
        } else if (comp[y]) {
            low[x] = min(low[x],num[y]); // radacina lui x devine
            if (x == 8) {
                cout << low[x] << ' ' << num[y] << endl;
            }
        }
    }

    if (num[x] == low[x]) { // daca ajungem la un root, obtinem inseamna ca am obtinut componenta
        nrc++;
        vector<int> t;
        while (true) {
            const int temp = stk.back();
            stk.pop_back();
            t.push_back(temp);
            comp[temp] = false;
            if (temp == x) {
                break;
            }
        }
        ans.push_back(t);
    }
}


int main() {
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int a,b;
        fin >> a >> b;
        adj[a].push_back(b);
    }

    for (int i = 1; i <= n; i++) {
        if (num[i] == inf) {
            cout << i << endl;
            //stk.clear();
            solve(i);
        }
    }
    fout << ans.size() << '\n';
    for (const auto v : ans) {
        for (const int i : v) {
            fout << i << ' ';
        }
        fout << '\n';
    }
    return 0;
}