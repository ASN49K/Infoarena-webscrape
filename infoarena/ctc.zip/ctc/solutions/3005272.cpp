#include <fstream>
#include <cstring>
#include <vector>
#define DIM 100001
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n,m,x,y,k,nr,v[DIM];
bool viz[DIM];
vector<int> gd[DIM],gt[DIM],ctc[DIM];

void dfs1(int nod) {
    viz[nod]=1;
    for (int i=0;i<gd[nod].size();i++) {
        int vec=gd[nod][i];
        if (viz[vec]==0)
            dfs1(vec);
    }
    v[++k]=nod;
}

void dfs2(int nod) {
    viz[nod]=1;
    ctc[nr].push_back(nod);
    for (int i=0;i<gt[nod].size();i++) {
        int vec=gt[nod][i];
        if (viz[vec]==0)
            dfs2(vec);
    }
}

int main() {
    fin>>n>>m;
    while (m--) {
        fin>>x>>y;
        gd[x].push_back(y);
        gt[y].push_back(x);
    }
    for (int i=1;i<=n;i++)
        if (viz[i]==0)
            dfs1(i);
    memset(viz,0,sizeof(viz));
    for (int i=n;i>=1;i--)
        if (viz[v[i]]==0) {
            nr++;
            dfs2(v[i]);
        }
    fout<<nr<<"\n";
    for (int i=1;i<=nr;i++) {
        for (int j=0;j<ctc[i].size();j++)
            fout<<ctc[i][j]<<" ";
        fout<<"\n";
    }
    return 0;
}
