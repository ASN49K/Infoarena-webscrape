#include <iostream>
#include <fstream> 
#include <vector>
#include <stack>

using namespace std;

vector<vector<int>> grInitial;
vector<vector<int>> grTranspus;
vector<vector<int>> rez;
vector<int> viz;
stack<int> st;

int nrCompCon = 0;

void dfsInitial(int nod) {
    viz[nod] = 1;

    for (auto vecin : grInitial[nod]) {
        if (viz[vecin] == 0) {
            dfsInitial(vecin);
        }
    }

    st.push(nod);
}

void dfsTranspus(int nod) {
    viz[nod] = 1;
    rez[nrCompCon].push_back(nod);
    for (auto vecin : grTranspus[nod]) {
        if (viz[vecin] == 0) {
            dfsTranspus(vecin);
        }
    }

}
int main() {

    ifstream fin("ctc.in");
    ofstream fout("ctc.out");

    int N, M;
    fin >> N >> M;

    viz.assign(N+1, 0);
    grInitial.resize(N+1);
    grTranspus.resize(N+1);
    rez.resize(N+1);

    for (int i = 0; i < M; i++) {
        int x, y;
        fin >> x >> y;
        grInitial[x].push_back(y);
        grTranspus[y].push_back(x);
    }

    for (int i = 1; i <= N; i++) {
        if (viz[i] == 0) {
            dfsInitial(i);
        }
    }

    viz.assign(N+1, 0);

    while(!st.empty()) {
        int crt = st.top();
        st.pop();
        if (viz[crt] == 0){
            nrCompCon++;
            dfsTranspus(crt);
        }    
    }

    fout << nrCompCon << endl;
    for (int i = 1; i <= nrCompCon; i++) {
        for (auto elem : rez[i])
            fout << elem << " ";
        fout << endl;
    }
    fin.close();
    fout.close();
    return 0;
}