#include <fstream>
#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

int n, m, i, j, x, y, rmq[31][200001], lg[200001];

ifstream f("rmq.in");
ofstream g("rmq.out");

int main()
{
    f >> n >> m;
    lg[1] = 0;
    for(i = 2; i <= n; i ++) lg[i] = lg[i >> 1] + 1;

    for(i = 1; i <= n; i ++) f >> rmq[0][i];

    for(i = 1; (1 << i) <= n; i ++)
    {
        for(j = 1; j <= n - (1 << i) + 1; j ++)
        {
            rmq[i][j] = min(rmq[i - 1][j], rmq[i - 1][j + (1 << (i - 1))]);
        }
    }

    for(i = 1; i <= m; i ++)
    {
        f >> x >> y;
        if(x > y) swap(x, y);
        int k = lg[y - x + 1];
        g << min(rmq[k][x], rmq[k][y - (1 << k) + 1]) << '\n';
    }
}
