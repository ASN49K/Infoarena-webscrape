#include <bits/stdc++.h>

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
typedef long long ll;
vector <int> in[100005],out[100005];
int viz[100005];
int n,m;
vector <vector <int>> ctc;
vector <int> comp;
vector <int> st;
void dfs1(int nod)
{
    viz[nod]=1;
    for(auto x:out[nod])
        if(!viz[x])
        dfs1(x);
    st.push_back(nod);
}
void dfs2(int nod)
{
    viz[nod]=1;
    comp.push_back(nod);
    for(auto x:in[nod])
        if(!viz[x])
        dfs2(x);
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        in[y].push_back(x);
        out[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
        if(viz[i]==0)
        dfs1(i);
    reverse(st.begin(),st.end());
    for(int i=1;i<=n;i++)
        viz[i]=0;
    for(int i=1;i<=n;i++)
        if(!viz[i])
    {
        comp.clear();
        dfs2(i);
        ctc.push_back(comp);
    }
    fout<<ctc.size()<<'\n';
    for(auto cmp:ctc)
    {
        for(auto nod:cmp)
        fout<<nod<<' ';
        fout<<'\n';
    }
    return 0;
}
