#include <fstream>
#include <stack>
#include <vector>

using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");
const int NMAX = 100005;
int n, m, v[NMAX], v2[NMAX];
vector<int> g[NMAX], g1[NMAX];
vector<vector<int>> sol;
stack<int> s;

void dfs(int k){
    v[k] = 1;
    s.push(k);
    for(int i : g[k]) if(!v[i]) dfs(i);
}

void dfs2(int k, vector<int> &c){
    v2[k] = 1;
    c.push_back(k);
    for(int i : g1[k]) if(!v2[i]) dfs2(i, c);
}

int main(){
    fin >> n >> m;
    for(int i = 1; i <= m; i++){
        int x, y;
        fin >> x >> y;
        g[x].push_back(y);
        g1[y].push_back(x);
    }
    for(int i = 1; i <= n; i++) if(!v[i]) dfs(i);
    while (!s.empty())
    {
        vector<int> c;
        if(!v2[s.top()]) dfs2(s.top(), c), sol.push_back(c);
        s.pop();
    }
    fout << sol.size() << '\n';
    for(auto &s : sol){
        for(auto i : s) fout << i << ' ';
        fout << '\n';
    }
    return 0;
}