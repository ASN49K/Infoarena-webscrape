#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>
const int NMAX=200005;

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");

void dfs(int);

vector <int> v[NMAX], ct[NMAX];
int n, m, low[NMAX], in[NMAX], ctc, lvl;
stack <int> st;
bool inst[NMAX];

int main()
{
    int a, b, i;
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>a>>b;
        v[a].push_back(b);
    }
    for(i=1; i<=n; i++)
    {
        if(!low[i]) dfs(i);
    }
    fout<<ctc<<'\n';
    for(i=1; i<=n; i++)
    {
        sort(ct[i].begin(), ct[i].end());
        for(auto i:ct[i]) fout<<i<<' ';
        fout<<'\n';
    }
    return 0;
}

void dfs(int nod)
{
    in[nod]=low[nod]=++lvl;
    st.push(nod); inst[nod]=true;
    for(auto i:v[nod])
    {
        if(!low[i])
        {
            dfs(i);
            low[nod]=min(low[nod], low[i]);
        }
        else low[nod]=min(low[nod], low[i]);
    }
    if(in[nod]==low[nod])
    {
        ctc++;
        int newnod;
        do
        {
            newnod=st.top();
            ct[ctc].push_back(newnod);
            st.pop(); inst[newnod]=false;
        }while(nod!=newnod);
    }
}
