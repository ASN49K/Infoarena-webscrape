// https://infoarena.ro/problema/ctc - Szücs Patrik - Kevin
#include <fstream>
#include <vector>
#include <stack>

#define vec std::vector
#define stck std::stack

std::ofstream out("ctc.out");

void tarjan(int &i, vec<vec<int>> &adj, vec<int> &indx, vec<int> &lowlink, vec<bool> &onS, stck<int> &s, int &v, int &cnt, vec<vec<int>> &res)
{
    indx[v] = i;
    lowlink[v] = i++;
    s.push(v);
    onS[v] = true;

    for (auto u : adj[v])
        if (!indx[u])
        {
            tarjan(i, adj, indx, lowlink, onS, s, u, cnt, res);
            lowlink[v] = std::min(lowlink[v], lowlink[u]);
        }
        else if (onS[u])
            lowlink[v] = std::min(lowlink[v], indx[u]);

    int w;
    if (lowlink[v] == indx[v])
    {
        do
        {
            w = s.top();
            onS[w] = false;
            s.pop();

            res[cnt].push_back(w + 1);
        } while (w != v);
        cnt++;
    }
}

int main()
{
    int n, m;

    std::ifstream in("ctc.in");
    in >> n >> m;

    vec<vec<int>> adj(n);
    while (m--)
    {
        int x, y;
        in >> x >> y;
        adj[--x].push_back(--y);
    }
    in.close();

    // Tarjan
    int i = 1, cnt = 0;
    stck<int> s;
    vec<int> indx(n), lowlink(n);
    vec<vec<int>> res(n);
    vec<bool> onS(n);

    for (int j = 0; j < n; j++)
    {
        if (!indx[j])
            tarjan(i, adj, indx, lowlink, onS, s, j, cnt, res);
    }

    // Output
    out << cnt << '\n';
    for (int k = 0; k < cnt; k++)
    {
        for (auto it = res[k].begin(); it != res[k].end(); it++)
            out << *it << ' ';
        out << '\n';
    }

    return 0;
}