#include <bits/stdc++.h>
using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

const int nmax = 1e5+5;
vector<int> g[nmax],rg[nmax];
int vizitat[nmax],color[nmax];
int n,m,color_cnt;

vector<int> aux;

void dfs_1(int i)
{
    if(vizitat[i] == 1) return;
    vizitat[i] = 1;

    for(auto pi: g[i])
    {
        dfs_1(pi);
    }
    aux.push_back(i);
}

void dfs_2(int i, int clr)
{
    if(vizitat[i] == 2) return;
    vizitat[i] = 2;
    color[i] = clr;
    for(auto pi : rg[i])
    {
        dfs_2(pi,clr);
    }
}

int main()
{
    fin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int a,b; fin>>a>>b;
        g[a].push_back(b);
        rg[b].push_back(a);
    }
    for(int i=1; i<=n; i++)
    {
        dfs_1(i);
    }
    reverse(aux.begin(),aux.end());
    for(auto i: aux)
    {
        if(vizitat[i] != 2)
        {
            color_cnt++;
            dfs_2(i,color_cnt);
        }
    }
    vector<vector<int> > ctc(color_cnt + 1);
    for(int i=1; i<=n; i++)
    {
        ctc[color[i]].push_back(i);
    }
    fout<<color_cnt;
    for(auto c: ctc)
    {
        for(auto i: c) fout<<i<<" ";
        fout<<"\n";
    }
    return 0;
}
