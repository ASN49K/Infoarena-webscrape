﻿#include <bits/stdc++.h>
#include <unordered_map>
using namespace std;
#define ll long long 
#define ull unsigned long long 
#define nmax 100006
#define MOD 9901 
#define INF 2123456789
//#define fin cin 
//#define fout cout 

ifstream fin("ctc.in");
ofstream fout("ctc.out");

int n, m, cnt;
vector <int> L[nmax], T[nmax];
int viz[nmax];
int sol[nmax], len;

void DFSLexic(int k)
{
	viz[k] = 1;
	for (int i : L[k])
		if (!viz[i])
			DFSLexic(i);
	sol[++len] = k;
}

void SortTop()
{
	for (int i = 1; i <= n; i++)
		if (!viz[i])
			DFSLexic(i);
}

void DFS(int k)
{
	viz[k] = cnt;
	for (int i : T[k])
		if (!viz[i])
			DFS(i);
}

void Kosaraju()
{
	int k;
	for (int i = 1; i <= n; i++)
		viz[i] = 0;
	for (int i = n; i >= 1; i--)
	{
		k = sol[i];
		if (!viz[k])
		{
			++cnt;
			DFS(k);
		}
	}
}

int main()
{
	int i, j;
	fin >> n >> m;
	while (m--)
	{
		fin >> i >> j;
		L[i].push_back(j);
		T[j].push_back(i);
	}
	SortTop();
	Kosaraju();
	fout << cnt << "\n";
	for (i = 1; i <= cnt; i++, fout << "\n")
		for (int j = 1; j <= n; j++)
			if (viz[j] == i)
				fout << j << " ";
	fin.close();
	fout.close();
	return 0;
}