#include <bits/stdc++.h>
#define N 100007

using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

int n,m,t,ncomp;
vector<int> g[N];
vector<int> comp[N];
vector<int> disc(N,0);
vector<int> llink(N,0);
bitset<N>instack;
stack<int> st;


void DFS_T(int x)
{
    disc[x]=++t;
    llink[x]=t;
    instack[x]=1;
    st.push(x);
    for( auto y: g[x] )
        if( !disc[y] )
        {
            DFS_T(y);
            llink[x]=min( llink[x],llink[y] );
        }
        else if( instack[y] )
        {
            llink[x]=min( llink[x],llink[y] );
        }
    if( llink[x]==disc[x] )
    {
        ncomp++;
        while( st.top()!=x )
        {
            comp[ncomp].push_back( st.top() );
            instack[ st.top() ]=0;
            st.pop();
        }
        comp[ncomp].push_back( st.top() );
        instack[ st.top() ]=0;
        st.pop();
    }
}



int main()
{
    fin >> n >> m;
    for(int i=1; i<=m; i++)
    {
        int x,y;
        fin >> x >> y;
        g[x].push_back(y);
    }
    for(int i=1; i<=n; i++)
        if( !disc[i] )
            DFS_T(i);
    fout << ncomp <<"\n";
    for(int i=1; i<=ncomp; i++)
    {
//        sort( comp[i].begin(),comp[i].end() );
        for(int x:comp[i])
            fout << x << " ";
        fout<< "\n";
    }
    fout.close();
    return 0;
}
