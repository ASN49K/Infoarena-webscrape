#include <bits/stdc++.h>
#define t 2e9
using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n, m, cnt;
bitset<100001>viz;
vector<int>L[100001];
vector<int>T[100001];
stack<int>st;
set<int>sol[100001];
void Dfs(int k)
{
    viz[k] = 1;
    for(int i : L[k])
        if(!viz[i])Dfs(i);
    st.push(k);
}
void Dfs1(int k)
{
    viz[k] = 1;
    for(int i : T[k])
        if(!viz[i])Dfs1(i);
    sol[cnt].insert(k);
}
int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int i, x, y, c, k;
    fin >> n >> m;
    for(i = 1; i <= m; i++)
    {
        fin >> x >> y;
        L[x].push_back(y);
        T[y].push_back(x);
    }
    for(i = 1; i <= n; i++)
        if(!viz[i])Dfs(i);
    viz.reset();
    while(!st.empty())
    {
        k = st.top();
        st.pop();
        if(!viz[k])
        {
            cnt++;
            Dfs1(k);
        }
    }
    fout << cnt << "\n";
    for(i = 1; i <= cnt; i++)
    {
        for(int j : sol[i])
            fout << j << " ";
        fout << "\n";
    }
    return 0;
}
