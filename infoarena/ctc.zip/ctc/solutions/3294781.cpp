///n**2: calcul toate ciclurile simple + DFS pe graf neorientat.
#include <bits/stdc++.h>
#define aaa system("read -r -p \"Press enter to continue...\" key");
#define dbg(x) std::cerr<<(#x)<<": "<<(x)<<'\n',aaa
#define dbga(x,n) std::cerr<<(#x)<<"[]: ";for(int _=0;_<n;_++)std::cerr<<x[_]<<' ';std::cerr<<'\n',aaa
#define dbgs(x) std::cerr<<(#x)<<"[stl]: ";for(auto _:x)std::cerr<<_<<' ';std::cerr<<'\n',aaa
#define dbgp(x) std::cerr<<(#x)<<": "<<x.first<<' '<<x.second<<'\n',aaa
#define dbgsp(x) std::cerr<<(#x)<<"[stl pair]:\n";for(auto _:x)std::cerr<<_.first<<' '<<_.second<<'\n';aaa

const int maxn = 100'000;

std::vector<int> g[maxn+1], g_orient[maxn+1];
std::vector<std::vector<int>> ctcs;
bool viz[maxn+1], inchain[maxn+1];
std::vector<int> chain;

void dfs(int nod) {
    viz[nod] = true;
    inchain[nod] = true;
    chain.push_back(nod);

    for (int nn: g[nod]) {
        if (!viz[nn]) dfs(nn);
        else if (nn != nod && inchain[nn]) { ///unesc tot ce am pe lantul simplu.
            int z = (int)chain.size() - 2;
            while (z > 0 && chain[z] != nn) {
                g_orient[chain[z]].push_back(chain[z+1]);
                g_orient[chain[z+1]].push_back(chain[z]);
                // dbgp(std::make_pair(chain[z], chain[z+1]))
                z--;
            }

            g_orient[chain[z]].push_back(chain[z+1]);
            g_orient[chain[z+1]].push_back(chain[z]);
            // dbgp(std::make_pair(chain[z], chain[z+1]))
        }
    }

    inchain[nod] = false;
    chain.pop_back();
}

void dfs_neorient(int nod) {
    viz[nod] = true;
    ctcs.back().push_back(nod);
    for (int nn: g_orient[nod]) if (!viz[nn]) dfs_neorient(nn);
}

int main() {
    std::ifstream fin("ctc.in");
    std::ofstream fout("ctc.out");

    int n, m; fin >> n >> m;

    for (int i = 0; i < m; i++) {
        int a, b; fin >> a >> b;
        g[a].push_back(b);
    }

    for (int i = 1; i <= n; i++) {
        dfs(i);
        std::fill(std::begin(viz), std::end(viz), false);
    }

    for (int i = 1; i <= n; i++) {
        if (!viz[i]) {
            // dbg(i)
            ctcs.push_back(std::vector<int>());
            dfs_neorient(i);
        }
    }

    fout << ctcs.size() << '\n';
    for (const auto &ctc: ctcs) {
        for (int z: ctc) fout << z << ' ';
        fout << '\n';
    }

    return 0;
}
