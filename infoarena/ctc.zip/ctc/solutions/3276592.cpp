#include <fstream>
#include <cstring>
#include <stack>
#include <vector>
#define nmax (int)(1e5+1)
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
int n,m,k,x,y,minlv[nmax],niv[nmax];
vector<int>v[nmax],aux;
vector<vector<int>>sol;
stack<int>s;
bool viz[nmax],in[nmax];
void dfs(int nod){
    s.push(nod);
    in[nod]=1;
    viz[nod]=1;
    niv[nod]=minlv[nod]=++k;
    for(auto i:v[nod])
        if(!viz[i]){
            dfs(i);
            if(in[i])
                minlv[nod]=min(minlv[i],minlv[nod]);
        }else if(in[i])
            minlv[nod]=min(minlv[nod],niv[i]);
    if(niv[nod]==minlv[nod]&&in[nod]){
        aux.clear();
        while(!s.empty()&&s.top()!=nod){
            aux.push_back(s.top());
            in[s.top()]=0;
            s.pop();
        }
        in[nod]=0;
        aux.push_back(nod);
        s.pop();
        sol.push_back(aux);
    }
}
signed main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back(y);
    }
    for(int i=1;i<=n;i++)
        if(!viz[i])
            dfs(i);
    cout<<sol.size()<<'\n';
    for(auto i:sol){
        for(auto j:i)
            cout<<j<<" ";
        cout<<'\n';
    }
    return 0;
}
/// tarjan
