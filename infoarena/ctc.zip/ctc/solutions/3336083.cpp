#include <bits/stdc++.h>

using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n,m,x,y,nr;
vector<int> g[100005],gt[100005],S,rasp[100005];
bool viz[100005];

void dfs(int k)
{
    viz[k]=true;
    for(auto x : g[k])
        if(!viz[x])dfs(x);

    S.push_back(k);
}

void dfsGt(int k)
{
    viz[k]=false;
    for(auto x : gt[k])
        if(viz[x])dfsGt(x);

    rasp[nr].push_back(k);
}

int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        g[x].push_back(y);
        gt[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(!viz[i])
            dfs(i);

    for(int i=n-1;i>=0;i--)
    {
        if(viz[ S[i] ] )
        {
            nr++;
            dfsGt( S[i] );
        }
    }
    fout<<nr<<'\n';

    for(int i=1;i<=nr;i++)
    {
        for(int j=0;j<rasp[i].size();j++)
            fout<<rasp[i][j]<<' ';
        fout<<'\n';
    }
    return 0;
}
