#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

int n, m;
vector <int> G[100005];
vector <int> GT[100005];
stack <int> S;
vector <int> CTC[100005];
int viz[100005], k;

void citire()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        GT[y].push_back(x);
    }
}

void dfs(int nod)
{
    viz[nod] = 1;
    int l = G[nod].size();
    for(int i = 0; i < l; i++)
        if(!viz[G[nod][i]])
            dfs(G[nod][i]);
    S.push(nod);
}

void dfs_ctc(int nod)
{
    viz[nod] = 2;
    CTC[k].push_back(nod);
    int l = GT[nod].size();
    for(int i = 0; i < l; i++)
        if(viz[GT[nod][i]] == 1)
            dfs_ctc(GT[nod][i]);
}

void solve()
{
    for(int i = 1; i <= n; i++)
        if(!viz[i])
            dfs(i);
    while(!S.empty())
    {
        int nod = S.top();
        if(viz[nod] == 1)
        {
            dfs_ctc(nod);
            k++;
        }
        S.pop();
    }
}

void afisare()
{
    fout << k << '\n';
    for(int i = 0; i < k; i++)
    {
        int l = CTC[i].size();
        for(int j = 0; j < l; j++)
            fout << CTC[i][j] << ' ';
        fout << '\n';
    }
}

int main()
{
    citire();
    solve();
    afisare();
    return 0;
}
