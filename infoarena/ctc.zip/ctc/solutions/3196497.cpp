#include <bits/stdc++.h>
#define NMAX 200010
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n,m,low[NMAX],i,k,viz[NMAX],x,y,onstack[NMAX],cc,ans[NMAX],timp;
vector<int>v[NMAX],c[NMAX];
stack<int>s;
void tarjan(int node)
{
    viz[node]=++timp;
    s.push(node);
    onstack[node]=1;
    low[node]=timp;
    for(auto it:v[node])
    {
        if(viz[it]==0)
        {
            tarjan(it);
            low[node]=min(low[node],low[it]);
        }
        if(onstack[it])
            low[node]=min(low[node],viz[it]);
    }
    if(low[node]==viz[node])
    {
        cc++;
        while(s.top()!=node)
        {
            onstack[s.top()]=0;
            ans[s.top()]=cc;
            low[s.top()]=low[node];
            s.pop();
        }
        onstack[s.top()]=0;
        ans[s.top()]=cc;
        s.pop();
    }
}
int main()
{
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y;
        v[x].push_back(y);
    }
    for(i=1; i<=n; i++)
        if(viz[i]==0)
            tarjan(i);
    for(i=1; i<=n; i++)
        c[ans[i]].push_back(i);
    int contor=0;
    for(i=1; i<=cc; i++)
        if(c[i].size())
            contor++;
    fout<<contor<<'\n';
    for(i=1; i<=cc; i++)
    {
        if(c[i].size()==0)
            continue;
        for(auto it:c[i])
            fout<<it<<" ";
        fout<<'\n';
    }
    return 0;
}
