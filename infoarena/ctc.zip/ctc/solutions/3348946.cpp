#include <fstream>
#include <cstring>
#include <algorithm>
#include <vector>
#define nmax 100001
using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");
int n,m,x,y;
bool viz[nmax];
vector<int>v[nmax],vr[nmax],tops,aux;
vector<vector<int>>ctc;
void dfs(int nod,int tip){
    viz[nod]=1;
    if(tip){
        for(auto i:vr[nod])
            if(!viz[i])
                dfs(i,tip);
    }else{
        for(auto i:v[nod])
            if(!viz[i])
                dfs(i,tip);
    }
    if(tip)
        aux.push_back(nod);
    else
        tops.push_back(nod);
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y;
        v[x].push_back(y);
        vr[y].push_back(x);
    }
    for(int i=1;i<=n;i++)
        if(!viz[i])
            dfs(i,0);
    memset(viz,0,sizeof(viz));
    reverse(tops.begin(),tops.end());
    for(auto i:tops)
        if(!viz[i]){
            aux.clear();
            dfs(i,1);
            ctc.push_back(aux);
        }
    cout<<ctc.size()<<'\n';
    for(auto i:ctc){
        for(auto j:i)
            cout<<j<<" ";
        cout<<'\n';
    }
    return 0;
}
