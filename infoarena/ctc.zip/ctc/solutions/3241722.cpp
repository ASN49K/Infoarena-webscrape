#include <fstream>
#include <vector>

using namespace std;

const int NMAX = 1e5;

struct nod
{
    int x;
    nod *next;
};

ifstream fin("ctc.in");
ofstream fout("ctc.out");

int n, m, nrc, nr, Post[NMAX + 1];
nod *G[NMAX + 1], *GT[NMAX + 1], *CTC[NMAX + 1];
bool viz[NMAX + 1];

inline void add(nod *&cap, int y)
{
    nod *p = new nod;
    p->x = y;
    p->next = cap;
    cap = p;
}

void citire()
{
    int x, y;
    fin >> n >> m;
    while(m--)
    {
        fin >> x >> y;
        add(G[x], y);
        add(GT[y], x);
    }
}

void dfs(int i)
{
    viz[i] = 1;
    for(nod *p = G[i]; p != NULL; p = p->next)
        if(!viz[p->x])
            dfs(p->x);
    Post[++nr] = i;
}

void dfsGT(int i)
{
    viz[i] = 0;
    add(CTC[nrc], i);
    for(nod *p = GT[i]; p != NULL; p = p->next)
        if(viz[p->x])
            dfsGT(p->x);
}

void componente()
{
    for(int i = 1; i <= n; ++i)
        if(!viz[i])
            dfs(i);
    for(int i = n; i >= 1; --i)
        if(viz[Post[i]])
        {
            ++nrc;
            dfsGT(Post[i]);
        }
}

void afisare()
{
    fout << nrc << '\n';
    for(int i = 1; i <= nrc; ++i)
    {
        for(nod *p = CTC[i]; p != NULL; p = p->next)
            fout << p->x << ' ';
        fout << '\n';
    }
}

int main()
{
    citire();
    componente();
    afisare();
    return 0;
}
