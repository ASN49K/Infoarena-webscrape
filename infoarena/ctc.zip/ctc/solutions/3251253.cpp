#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("graf.in");
ofstream cout("graf.out");

int dx[7505], dy[7505], fx[14005], fy[14005], sol[7505];

vector <int> l[7505];

queue <int> q;

void bfs(int start, int a[7505], int f[7505])
{
    while(!q.empty())
        q.pop();
        

    
    q.push(start);
    a[start]=1;
    while(!q.empty())
    {
        int curr=q.front();
        q.pop();
        for(int i=0;i<l[curr].size();i++)
            if(a[l[curr][i]]==0)
            {
                a[l[curr][i]]=a[curr]+1;
                f[a[l[curr][i]]]++;
                q.push(l[curr][i]);
            }
    }
}

int main()
{
    int n,m;
    int x,y;
    cin>>n>>m;
    cin>>x>>y;
    for(int i=1;i<=m;i++)
    {
        int z,t;
        cin>>z>>t;
        l[z].push_back(t);
        l[t].push_back(z);
    }

    dx[x]=1;
    bfs(x, dx, fx);
    dy[y]=1;
    bfs(y, dy, fy);

    int dist=min(dx[y], dy[x])-1;
    int nrsol=0;
    for(int i=1;i<=n;i++)
    {
        if(dx[i]+dy[i]-2==dist && fx[dx[i]]==1 && fy[dy[i]]==1)
        {
            nrsol++;
            sol[nrsol]=i;
        }
        else if(x==i || y==i)
        {
            nrsol++;
            sol[nrsol]=i;
        }
        //cout<<i<<" "<<fx[dx[i]]<<" "<<fy[dy[i]]<<'\n';
    }
    cout<<nrsol<<'\n';
    for(int i=1;i<=nrsol;i++)
        cout<<sol[i]<<" ";
    return 0;
}