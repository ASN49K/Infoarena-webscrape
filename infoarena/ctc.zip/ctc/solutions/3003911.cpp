#include <fstream>
#include <vector>
#include <cstring>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");

int a[100001], ct[100001];
int k, nr;
vector <int> l[100001], t[100001];

void kosaraju(int nod)
{
    ct[nod]=1;
    for(int i=0;i<l[nod].size();i++)
    {
        int vecin=l[nod][i];
        if(ct[vecin]==0)
        {
            kosaraju(vecin);
        }
    }
    a[++k]=nod;
}

void dfs(int nod)
{
    ct[nod]=nr;
    for(int i=0;i<t[nod].size();i++)
    {
        int vecin=t[nod][i];
        if(ct[vecin]==0)
        {
            dfs(vecin);
        }
    }
}

int main()
{
    int n, m, x, y, i;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        l[x].push_back(y);
        t[y].push_back(x);
    }
    for(i=1;i<=n;i++)
    {
        if(ct[i]==0)
        {
            kosaraju(i);
        }
    }
    memset(ct, 0, sizeof(ct));
    for(i=n;i>=1;i--)
    {
        if(ct[a[i]]==0)
        {
            nr++;
            dfs(a[i]);
        }
    }
    fout<<nr<<"\n";
    for(i=1;i<=nr;i++)
    {
        for(int j=1;j<=n;j++)
        {
            if(ct[j]==i)
            {
                fout<<j<<" ";
            }
        }
        fout<<"\n";
    }
    return 0;
}
