#include <fstream>
#include <vector>
#define NMAX 100001
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n,nr,nrc;
vector<int> G[NMAX];
vector<int> GT[NMAX];

int post[NMAX];
bool viz[NMAX];
vector<int> ctc[NMAX];
void citire();
void DFS(int x);
void DFST(int x);
void afisare();
int main()
{
    int i;
    citire();
    //parcugem dfs pe G si construiesc vectorul post
    for(i=1;i<=n;i++)
        if(!viz[i]) DFS(i);
    //parcurg vectorul post de la dreapta la stanga si fac dfs
    for(i=n;i>0;i--)
        if(viz[post[i]]) //post
          {
           nrc++;
           DFST(post[i]);
          }
    afisare();
    return 0;
}
void citire()
        {
         int m,i,x,y;
         fin>>n>>m;
         for(i=0;i<m;i++)
            {
             fin>>x>>y;
             //exista arx de la x la y in g
               G[x].push_back(y);
               GT[y].push_back(x);
           }
        }
void DFS(int x)
         {
          int i;
          viz[x]=1;
          for(i=0;i<G[x].size();i++)
              if(!viz[G[x][i]])
                DFS(G[x][i]);
          post[++nr]=x;
         }
void DFST(int x)
          {
           int i;
           viz[x]=0;
           ctc[nrc].push_back(x);
           for(i=0;i<GT[x].size();i++)
              if(viz[GT[x][i]])
                DFST(GT[x][i]);
          }
void afisare()
         {
          int i,j;
          fout<<nrc<<'\n';
          for(i=1;i<=nrc;i++)
              //afisez
          {
              for(j=0;j<ctc[i].size();j++)
                  fout<<ctc[i][j]<<' ';
              fout<<'\n';
          }
         }
