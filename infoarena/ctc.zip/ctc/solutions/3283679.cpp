#include <fstream>
#include <vector>

using namespace std;

ifstream cin("ctc.in");
ofstream cout("ctc.out");

int n, m;
vector<vector<int>> graph;
vector<int> disc, low;
vector<vector<int>> ctc;

void read() {
    cin >> n >> m;
    graph.resize(n + 1);
    for (int i = 1; i <= m; i++) {
        int a, b;
        cin >> a >> b;
        graph[a].emplace_back(b);
    }
}

void dfs(int node, int &time, vector<bool> &stk, vector<int> &curr_stk) {
    curr_stk.emplace_back(node);
    stk[node] = true;
    time ++;
    disc[node] = time;
    low[node] = time;

    for (auto it : graph[node]) {
        if (disc[it] == -1) {
            dfs(it, time, stk, curr_stk);
            low[node] = min(low[node], low[it]);
        }
        else if (stk[it]) {
            low[node] = min(low[node], low[it]);
        }
    }

    if (low[node] == disc[node]) {
        vector<int> temp;
        while (!curr_stk.empty() && curr_stk.back() != node) {
            temp.emplace_back(curr_stk.back());
            stk[curr_stk.back()] = false;
            curr_stk.pop_back();
        }
        temp.emplace_back(node);
        curr_stk.pop_back();
        stk[node] = false;
        ctc.emplace_back(temp);
    }
}

void solve() {

    disc.resize(n + 1, -1);
    low.resize(n + 1, -1);

    vector<bool> temp1(n + 1);
    vector<int> temp2;
    int time = 0;
    for (int i = 1; i <= n; i++) {
        if (disc[i] != -1) {
            continue;
        }
        dfs(i, time, temp1, temp2);
    }

    cout << ctc.size() << "\n";
    for (auto it1 : ctc) {
        for (auto it2 : it1) {
            cout << it2 << " ";
        }
        cout << "\n";
    }
}

int main()
{

    read();
    solve();
    return 0;
}
