#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n,m;
int contor;
vector <vector<int>> G;
vector <vector<int>> T;
vector<int> viz;
stack <int> S;
vector <vector<int>> ans;
void citire()
{
    fin>>n>>m;
    int x,y;
    G.resize(n+1);
    T.resize(n+1);
    for(int i=0;i<m;i++)
    {
        fin>>x>>y;
        G[x].push_back(y);
        T[y].push_back(x);
    }
}
void dfs(int nod)
{
    viz[nod]=1;
    for(int i=0;i<G[nod].size();i++)
    {
        int vecin=G[nod][i];
        if(viz[vecin]==0)
            dfs(vecin);
    }
    S.push(nod);
}
void dfst(int nod)
{
    viz[nod]=2;
    ans[contor].push_back(nod);
    for(int i=0;i<T[nod].size();i++)
    {
        int vecin=T[nod][i];
        if(viz[vecin]==1)
        {
           dfst(vecin);
        }
    }
}
void rezolvare()
{
    citire();
    viz.resize(n+1);
    for(int i=1;i<=n;i++)
    {
        if(!viz[i])
        {
            dfs(i);
        }
    }
    while(!S.empty())
    {
        int nod=S.top();
        S.pop();
        if(viz[nod]==1)
        {
            contor++;
            dfst(nod);
        }
    }
    fout<<contor<<'\n';
    for(int i=1;i<=contor;i++)
    {
        for(int j=0;j<ans[i].size();j++)
        {
            fout<<ans[i][j]<<" ";
        }
    }
}
int main()
{
    fout<<"sula";
    rezolvare();
    return 0;
}
