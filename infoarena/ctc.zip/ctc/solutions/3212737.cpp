#include <bits/stdc++.h>

using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

int n, m;
vector<int> L[100005], T[100005];
int viz[100005], nrc;
vector<int> Comp[100005];
stack<int> st;

void Citire()
{
    int i, j;
    fin >> n >> m;
    while (m--)
    {
        fin >> i >> j;
        L[i].push_back(j);
        T[j].push_back(i);
    }
}

void DFS(int k)
{
    viz[k] = 1;
    for (int i : L[k])
        if (!viz[i]) DFS(i);
    st.push(k);
}

void SortTop()
{
    for (int k = 1; k <= n; k++)
        if (!viz[k]) DFS(k);
}

void ReInit()
{
    for (int i = 1; i <= n; i++)
        viz[i] = 0;
}

void DFS2(int k)
{
    Comp[nrc].push_back(k);
    viz[k] = nrc;
    for (int i : T[k])
        if (!viz[i]) DFS2(i);
}

void Kosaraju()
{
    int k;
    while (!st.empty())
    {
        k = st.top();
        st.pop();
        if (!viz[k])
        {
            nrc++;
            DFS2(k);
        }
    }
    fout << nrc << "\n";
    for(int i  = 1; i <= nrc; i++)
    {
        for(auto e : Comp[i])
            fout << e << " ";
        fout << "\n";
    }
}

int main()
{
    Citire();
    SortTop();
    ReInit();
    Kosaraju();
    return 0;
}
