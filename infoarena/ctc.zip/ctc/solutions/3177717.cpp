#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream fin ("ctc.in");
ofstream fout ("ctc.out");

const int NMAX = 100002;
int n, m, comp_conexe, viz[NMAX];
vector<int> G[NMAX], GT[NMAX], rez[NMAX];
stack<int> s;

void dfs(int nod)
{
    viz[nod] = 1;

    for (int i = 0; i < G[nod].size(); i++)
    {
        if (!viz[G[nod][i]])
            dfs(G[nod][i]);
    }
    s.push(nod);
}

void dfs_t(int nod)
{
    viz[nod] = 2;
    rez[comp_conexe].push_back(nod);

    for (int i = 0; i < GT[nod].size(); i++)
    {
        if (viz[GT[nod][i]] == 1)
            dfs_t(GT[nod][i]);
    }
}
int main()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        fin >> x >> y;
        G[x].push_back(y);
        GT[y].push_back(x);
    }
    for (int i = 1; i <= n; i++)
        if (!viz[i]) dfs(i);

    while (!s.empty())
    {
        if (viz[s.top()] == 1)
        {
            comp_conexe++;
            dfs_t(s.top());
        }
        s.pop();
    }

    fout << comp_conexe << "\n";
    for (int i = 1; i <= comp_conexe; i++)
    {
        for (int j = 0; j < rez[i].size(); j++)
            fout << rez[i][j] << " ";
        fout << "\n";
    }

    return 0;
}
