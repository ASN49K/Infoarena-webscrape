#include <fstream>
#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>
#include <stack>
#include <queue>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
vector<int> L[100005],T[100005];
int viz[100005];
stack<int> st;
void dfs(int nod) {
    viz[nod]=1;
    for (auto it:L[nod])
        if (!viz[it])
            dfs(it);
    st.push(nod);
}
vector<vector<int>> ctc;
void dfs1(int nod) {
    viz[nod]=1;
    ctc[ctc.size()-1].push_back(nod);
    for (auto it:T[nod])
        if (!viz[it])
            dfs1(it);
}
int main() {
    int n,m;
    fin>>n>>m;
    for (int i=1; i<=m; i++) {
        int x,y;
        fin>>x>>y;
        L[x].push_back(y);
        T[y].push_back(x);
    }
    for (int i=1; i<=n; i++)
        if (!viz[i])
            dfs(i);
    for (int i=1; i<=n; i++)
        viz[i]=0;
    while (!st.empty()) {
        int curr=st.top();
        st.pop();
        for (int i=1; i<=n; i++)
            if (!viz[i]) {
                ctc.push_back({ });
                dfs1(i);
            }
    }
    fout<<ctc.size()<<"\n";
    for (auto it:ctc) {
        for (auto ind:it)
            fout<<ind<<" ";
        fout<<"\n";
    }
    return 0;
}
// 2 0 3 -1 7 -4
