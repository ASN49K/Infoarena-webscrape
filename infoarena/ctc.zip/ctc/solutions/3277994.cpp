#include <fstream>

using namespace std;
ifstream cin("ctc.in");
ofstream cout("ctc.out");

int n, m, x, y, t[2][200100], start[200100], k, c[100100], v[100100], dr, tt[2][200100], startt[200100], kt, vt[100100], nr, af[100100], p;

void liste(int i,int j)
{
    k++;
    t[0][k]=j;
    t[1][k]=start[i];
    start[i]=k;
}

void listet(int i,int j)
{
    kt++;
    tt[0][k]=i;
    tt[1][k]=startt[j];
    startt[j]=kt;
}

int dfs(int s)
{
    int man=start[s];
    v[s]=1;
    while(man)
    {
        if(v[t[0][man]]==0) dfs(t[0][man]);
        man=t[1][man];
    }
    c[++dr]=s;
}

int dfst(int s)
{
    int man=startt[s];
    vt[s]=1;
    af[++p]=s;
    while(man)
    {
        if(vt[tt[0][man]]==0) dfst(tt[0][man]);
        man=tt[1][man];
    }
}

int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>x>>y;
        liste(x,y);
        listet(x,y);
    }
    for(int i=1;i<=n;i++) if(v[i]==0) dfs(i);
    for(int i=dr;i>=1;i--)
    {
        if(vt[c[i]]==0)
        {
            nr++;
            dfst(c[i]);
            af[++p]=-1;
        }
    }
    cout<<nr<<'\n';
    for(int i=1;i<=p;i++)
    {
        if(af[i]!=-1) cout<<af[i]<<' ';
        else cout<<'\n';
    }
    return 0;
}
