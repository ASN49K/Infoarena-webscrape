#include <fstream>
#include <vector>
#define NMAX 100001
using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n;
vector<int> g[NMAX];
vector<int> gt[NMAX];
int post[NMAX];
vector <int> ctc[NMAX];
int viz[NMAX], nr, nrc;
void citire();
void DFS(int x);
void DFST(int x);
void afisare();
int main()
{int i;
    citire();
    for(i=1;i<=n;i++)
    {
        if(!viz[i]) DFS(i);
    }
    for(i=n;i>0;i--){
        if(viz[post[i]])
        {
            nrc++;
            DFST(post[i]);
        }
    }
    afisare();
    return 0;
}

void citire(){
    int m, x, i, y;
    fin>>n>>m;
    for(i=0;i<m;i++)
    {
        fin>>x>>y;
        g[x].push_back(y);
        gt[y].push_back(x);
    }

}

void DFS(int x)
{int i;
    viz[x]=1;
    for(i=0;i<g[x].size();i++){
        if(!viz[g[x][i]]) DFS(g[x][i]);
    }
    post[++nr]=x;
}

void DFST(int x)
{int i;
    viz[x]=0;
    ctc[nrc].push_back(x);
    for(i=0;i<gt[x].size();i++){
        if(viz[gt[x][i]]) DFST(gt[x][i]);
    }
    post[++nr]=x;
}

void afisare()
{int i, j;
    fout<<nrc<<'\n';
    for(i=1;i<=nrc;i++){
        for(j=0;j<ctc[i].size();j++)

            fout<<ctc[i][j]<<' ';
        fout<<'\n';

    }

}
