#include<bits/stdc++.h>
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
const int N = 1e5;
vector <int> e[N];
bool vis[N];
vector <int> ord;
int id[N],low[N],cnt = 0;
int necromantic[N],cnt2 = 0;
int onstack[N];
vector <int> ans[N];
int anscnt = 0;
void dfs(int node){
    vis[node] = 1;
    low[node] = cnt;
    id[node] = cnt;
    necromantic[cnt2++] = node;
    onstack[node] = 1;
    cnt++;
    for(auto i:e[node]){
        if(!vis[i]){
            dfs(i);
            low[node] = min(low[node],low[i]);
        }else if(onstack[i]){
            ///point to already found one
            low[node] = min(low[node],id[i]);
        }
    }
    cout<<node<<' '<<id[node]<<' '<<low[node]<<'\n';
    if(low[node] == id[node]){
        int u;
        do{
            u = necromantic[cnt2 - 1];
            onstack[u] = 0;
            cnt2--;
            ans[anscnt].push_back(u);
        }while(u != node);
        anscnt++;
    }
}
int main(){
    int n,m;
    fin>>n>>m;
    for(int i = 0;i < m;i++){
        int u,w;
        fin>>u>>w;
        u--;w--;
        e[u].push_back(w);
    }
    for(int i = 0;i < n;i++){
        if(!vis[i]){
            dfs(i);
        }
    }
    fout<<anscnt<<'\n';
    for(int i = 0;i < anscnt;i++){
        for(auto j:ans[i]){
            fout<<j + 1<<' ';
        }
        fout<<'\n';
    }
    return 0;
}
