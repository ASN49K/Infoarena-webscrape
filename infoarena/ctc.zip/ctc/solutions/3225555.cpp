#include <bits/stdc++.h>
#include <iostream>
using namespace std;

class Solutuion {
 private:
    size_t N;
    size_t M;
    vector<vector<size_t>> adj;
    vector<size_t> start;
    vector<bool> done;
    vector<set<size_t>> ctc = vector<set<size_t>>();
    size_t time = 0;

    size_t dfs(vector<size_t> &s, size_t idx) {
        bool pop = true;
        size_t min_node = 0;

        size_t node = s[idx];

        start[node] = ++time;
        
        for (auto neigh : adj[node]) {
            if (done[neigh])
                continue;
            if (start[neigh] == 0) {
                s.push_back(neigh);
                size_t rez = dfs(s, s.size() - 1);

                if (rez == 0 || rez == node)
                    continue;
                
                if (start[node] > start[rez]) {
                    pop = false;

                    if (min_node == 0) {
                        min_node = rez;
                        continue;
                    }

                    if (start[min_node] > start[rez])
                        min_node = rez;
                }
                
            } else if (start[node] > start[neigh]) {
                pop = false;

                if (min_node == 0) {
                    min_node = neigh;
                    continue;
                }

                if (start[min_node] > start[neigh])
                    min_node = neigh;
            }
        }

        if (pop) {
            ctc.push_back(set<size_t>());

            size_t len = s.size() - idx;
            for (int i = 0; i < len; ++i) {
                ctc.back().insert(s.back());
                done[s.back()] = true;
                s.pop_back();
            }
        }

        return min_node;
    }

 public:
    explicit Solutuion(ifstream &in) {
        in >> N >> M;
        adj.resize(N + 1);
        start.resize(N + 1, 0);
        done.resize(N + 1, false);

        size_t node1, node2;
        for (size_t i = 1; i <= M; i++) {
            in >> node1 >> node2;

            adj[node1].push_back(node2);
        }
    }

    vector<set<size_t>> solve() {
        bool done = false;
        size_t source;

        while (!done) {
            done = true;
            for (size_t node = 1; node <= N; node++)
                if (start[node] == 0) {
                    source = node;
                    done = false;

                    vector<size_t> s = vector<size_t>();
                    s.push_back(source);

                    dfs(s, 0);
                    break;
                }
        }

        return ctc;
    }
};

int main() {
    ifstream in("ctc.in");
    ofstream out("ctc.out");
    
    vector<set<size_t>> solution = Solutuion(in).solve();

    out << solution.size() << endl;
    for (auto sol : solution) {
        copy(sol.begin(), sol.end(), ostream_iterator<size_t>(out, " "));
        out << endl;
    }
    
    in.close();
    out.close();
    return 0;
}
