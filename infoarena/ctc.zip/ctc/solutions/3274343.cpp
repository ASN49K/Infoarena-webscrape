#include <iostream>
#include<vector>
#include<stack>

using namespace std;

const int N_MAX = 20000;
vector<int>g[N_MAX];vector<int>gt[N_MAX];
vector<vector<int>> ctc;
int ver[N_MAX];

int n,m,x,y;
stack<int> s;
void dfs(int node) {
    if(ver[node]) return;
    ver[node]=1;
    for(int i=0;i<g[node].size();i++) {
        dfs(g[node][i]);
    }
    s.push(node);
}
void dfs2(int node, vector<int>& v) {
    if(ver[node]) return;
    ver[node]=1;
    v.push_back(node);
    for(int i=0;i<gt[node].size();i++) {
        dfs2(gt[node][i],v);
    }
}
int main(){
    cin>>n>>m;
    for(int i=0;i<m;i++) {
        cin>>x>>y;
        g[x].push_back(y);
        gt[y].push_back(x);
    }
    for(int i=1;i<=n;i++) {
        dfs(i);
    }
    for(int i=1;i<=n;i++)
        ver[i] = 0;
    while(!s.empty() ) {
        int node = s.top();
        s.pop();
        if(!ver[node]) {
            vector<int> h;
            dfs2(node,h);
            ctc.push_back(h);
        }
    }
    cout<<ctc.size()<<'\n';
    for(int i=0;i<ctc.size();i++) {
        for(int j=0;j<ctc[i].size();j++)
            cout<<ctc[i][j]<<' ';
        cout<<endl;
    }
}