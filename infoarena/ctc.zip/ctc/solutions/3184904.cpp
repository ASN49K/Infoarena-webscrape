#include <bits/stdc++.h>
using namespace std;
void debug_out() { cerr << endl; }
template<class T> ostream& prnt(ostream& out, T v) { out << v.size() << '\n'; for(auto e : v) out << e << ' '; return out;}
template<class T> ostream& operator<<(ostream& out, vector <T> v) { return prnt(out, v); }
template<class T> ostream& operator<<(ostream& out, set <T> v) { return prnt(out, v); }
template<class T1, class T2> ostream& operator<<(ostream& out, map <T1, T2> v) { return prnt(out, v); }
template<class T1, class T2> ostream& operator<<(ostream& out, pair<T1, T2> p) { return out << '(' << p.first << ' ' << p.second << ')'; }
template <typename Head, typename... Tail> void debug_out(Head H, Tail... T) { cerr << " " << H; debug_out(T...);}
#define dbg(...) cerr << #__VA_ARGS__ << " ->", debug_out(__VA_ARGS__)
#define dbg_v(x, n) do{cerr<<#x"[]: ";for(int _=0;_<n;++_)cerr<<x[_]<<" ";cerr<<'\n';}while(0)
#define dbg_ok cerr<<"OK!\n"
#define ll long long
#define ld long double
#define ull unsigned long long
#define pii pair<int,int>
#define MOD 1000000007
#define zeros(x) x&(x-1)^x
#define fi first
#define se second
#define NMAX 500005
const long double PI = acos(-1);

int n, m, viz[NMAX];
vector<int> s;
vector<int> v[NMAX], vp[NMAX];
vector<vector<int>> ans;

void dfs(int nod) {
  viz[nod] = 1;
  for (auto it : v[nod]) {
    if (viz[it]) continue;
    dfs(it);
  }
  s.push_back(nod);
}

void dfs2(int nod, vector<int> &c) {
  viz[nod] = 1;
  c.push_back(nod);
  for (auto it : vp[nod]) {
    if (viz[it]) continue;
    dfs2(it, c);
  }
}

int main(){
  ios::sync_with_stdio(false);
  freopen("ctc.in","r",stdin);
  freopen("ctc.out","w",stdout);
  cin >> n >> m;

  for (int i=1;i<=m;i++) {
    int x, y;
    cin >> x >> y;
    v[x].push_back(y);
    vp[y].push_back(x);
  }

  for (int i=1;i<=n;i++) {
    if (viz[i]) continue;
    dfs(i);
  }

  memset(viz, 0, sizeof(viz));

  while (!s.empty()) {
    if (viz[s.back()]){
      s.pop_back();
      continue;
    }
    vector<int> c;
    dfs2(s.back(), c);
    ans.push_back(c);
  }

  cout << ans.size() << '\n';
  for (auto &comp : ans) {
    for (auto &nod : comp) {
      cout << nod << ' ';
    }
    cout << '\n';
  }

  return 0;
}