#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

// i have to force stl vector in main

void dfs(int node, vector<bool> &b, vector<vector<int>> &a, vector<int> &ans) {
    b[node] = true;
    for(auto i : a[node]) {
        if(b[i])
            continue;
        dfs(i, b, a, ans);
    }
    ans.push_back(node);
}

int main() {
    // freopen("ctc.in", "r", stdin);
    // freopen("ctc.out", "w", stdout);

    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    
    int n, m; cin >> n >> m;

    vector<vector<int>> a(n + 1), ra(n + 1);
    vector<bool> b(n + 1);

    for(int i = 1; i <= m; i ++) {
        int x, y; cin >> x >> y;
        a[x].push_back(y);
        ra[y].push_back(x);
    }
    
    vector<int> topo;

    for(int i = 1; i <= n; i ++) {
        if(b[i])
            continue;
        dfs(i, b, a, topo);
    }

    reverse(topo.begin(), topo.end());

    b = vector<bool>(n + 1);

    vector<vector<int>> ans;

    for(int i = 1; i <= n; i ++) {
        if(b[i])
            continue;
        ans.push_back({});
        dfs(i, b, ra, ans.back());
    }

    cout << ans.size() << '\n';
    for(auto i : ans) {
        sort(i.begin(), i.end());
        for(auto j : i) {
            cout << j << ' ';
        }
        cout << '\n';
    }
}