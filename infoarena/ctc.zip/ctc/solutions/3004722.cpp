#include<fstream>
#include<vector>
#include<stack>

using namespace std;

ifstream cin("ctc.in");
ofstream cout("ctc.out");
int n,m,P[100001],nrcc;
stack<int>S;
vector<vector<int>>G(200001),GT(200001),CTC(200001);

void DFS(int nod)
{
    P[nod]=1;
    for(auto x:G[nod])
        if(!P[x])
            DFS(x);

    S.push(nod);
}

void DFS2(int nod,int id_cc)
{
    P[nod]=1;
    CTC[id_cc].push_back(nod);
    for(auto x:GT[nod])
        if(!P[x])
            DFS2(x,id_cc);

}

int main()
{
    cin>>n>>m;
    for(int i=1,x,y;i<=m;++i)
    {
        cin>>x>>y;
        G[x].push_back(y);
        GT[y].push_back(x);
    }
    for(int i=1;i<=n;++i)
        if(!P[i])
            DFS(i);

    for(int i=1;i<=n;++i)
        P[i]=0;
    while(!S.empty())
    {
        int nod=S.top();
            if(!P[nod])
                DFS2(nod,++nrcc);

        S.pop();
    }
    cout<<nrcc<<'\n';
    for(int i=1;i<=nrcc;++i,cout<<'\n')
        for(auto x:CTC[i])
            cout<<x<<" ";
}