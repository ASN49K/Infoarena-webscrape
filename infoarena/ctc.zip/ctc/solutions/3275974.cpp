#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <bitset>
using namespace std;

ifstream fin("ctc.in");
ofstream fout("ctc.out");

int n, m;

vector<int> graph[100001];
vector<int> stronglyConnectedComp[100001];
vector<int> ans[100001];

bitset<100001> isSelected;

bool existPath(int currentNode, int endNode, bitset<100001> isVisited) {
    if (currentNode == endNode) {
        return 1;
    }
    bool pathFound = 0;
    for (vector<int>::iterator it = graph[currentNode].begin(); it != graph[currentNode].end(); ++it) {
        if (isVisited[*it] == 0) {
            isVisited[*it] = 1;
            bitset<100001> nextIsVisited = isVisited;
            pathFound = existPath(*it, endNode, nextIsVisited) || pathFound;
        }
    }
    return pathFound;
}

int main() {
    fin >> n >> m;
    for (int i = 1; i <= m; ++i) {
        int node1, node2;
        fin >> node1 >> node2;
        graph[node1].push_back(node2);
    }
    for (int i = 1; i < n; ++i) {
        for (int j = i + 1; j <= n; ++j) {
            bitset<100001> isVisitedI = {0};
            bitset<100001> isVisitedJ = {0};
            isVisitedI[i] = isVisitedJ[j] = 1;
            if (existPath(i, j, isVisitedI) && existPath(j, i, isVisitedJ)) {
                stronglyConnectedComp[i].push_back(j);
                stronglyConnectedComp[j].push_back(i);
            }
        }
    }
    int noStronglyConnectedComp = 0;
    for (int i = 1; i <= n; ++i) {
        if (isSelected[i] == 0) {
            ans[++noStronglyConnectedComp].push_back(i);
            isSelected[i] = 1;
            for (int j = 0; j < stronglyConnectedComp[i].size(); ++j) {
                ans[noStronglyConnectedComp].push_back(stronglyConnectedComp[i][j]);
                isSelected[stronglyConnectedComp[i][j]] = 1;
            }
        }
    }
    fout << noStronglyConnectedComp << '\n';
    for (int i = 1; i <= noStronglyConnectedComp; ++i) {
        for (int j = 0; j < ans[i].size(); ++j) {
            fout << ans[i][j] << ' ';
        }
        fout << '\n';
    }
    return 0;
}
/*

 
 
 */
