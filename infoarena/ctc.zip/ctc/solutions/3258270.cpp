#include <fstream>
#include <vector>
#define NMAX 100002
using namespace std;
ifstream fin("ctc.in");
ofstream fout("ctc.out");
int n, nrc, poz=1;
vector<int> G[NMAX];
vector<int> GT[NMAX];
int postordine[NMAX];
vector<int> CTC[NMAX]; //CTC[i]= contine varfurile din componenta tare-conexa i
bool viz[NMAX];

void citire();
void afisare();
void DFS(int x);
void DFST(int x);

int main()
{int i;
 citire();
 for (i=1; i<=n; i++)
     if (!viz[i]) DFS(i);
 for (i=n; i>=1; i--)
     if (viz[postordine[i]]==1) //adica acest vf este nevizitat in graful transpus
         {nrc++; DFST(postordine[i]);}
 afisare();
 return 0;
}

void citire()
{int i, m, x, y;
 fin>>n>>m;
 for (i=0; i<m; i++)
     {fin>>x>>y;
      G[x].push_back(y);
      GT[y].push_back(x);
     }
}

void afisare()
{int i, j;
 fout<<nrc<<'\n';
 for (i=1; i<=nrc; i++)
     {for (j=0; j<CTC[i].size(); j++)
          fout<<CTC[i][j]<<' ';
      fout<<'\n';
     }
}

void DFS(int x)
{int i;
 viz[x]=1;
 //parcurg lista de adiacenta a lui x
 for (i=0; i<G[x].size(); i++)
     if (!viz[G[x][i]])
        DFS(G[x][i]);
 postordine[poz++]=x;
}

void DFST(int x)
{ int i;
  viz[x]=0; CTC[nrc].push_back(x);
  for (i=0; i<GT[x].size(); i++)
     if (viz[GT[x][i]])
        DFST(GT[x][i]);
}
