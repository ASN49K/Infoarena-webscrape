#include <bits/stdc++.h>

using namespace std;
ifstream f("ctc.in");
ofstream g("ctc.out");

struct petrisor {
    int nod;
    int t;
}a[100003];

bool cond(petrisor x, petrisor y) {
    return (x.t > y.t);
}

vector <int> v[100003];
vector <int> rev[100003];
vector <int> rez[100003];

bool viz[100003];

int timp, cnt;

void DFS1(int nod) {
    int i, urm;

    viz[nod] = 1; timp++;

    for (i = 0; i < v[nod].size(); i++) {
        urm = v[nod][i];

        if (viz[urm] == 0)
            DFS1(urm);
    }

    timp++;

    a[nod].nod = nod;
    a[nod].t = timp;
}

void DFS2(int nod) {
    int i, urm;

    viz[nod] = 1;
    rez[cnt].push_back(nod);

    for (i = 0; i < rev[nod].size(); i++) {
        urm = rev[nod][i];

        if (viz[urm] == 0)
            DFS2(urm);
    }
}

int main()
{
    int n, m, i, j, x, y;

    f >> n >> m;

    for (i = 1; i <= m; i++) {
        f >> x >> y;

        v[x].push_back(y);
        rev[y].push_back(x);
    }

    for (i = 1; i <= n; i++) {
        if (viz[i] == 0)
            DFS1(i);
    }

    sort(a + 1, a + n + 1, cond);

    for (i = 1; i <= n; i++) {
        viz[i] = 0;
    }

    for (i = 1; i <= n; i++) {
        x = a[i].nod;

        if (viz[x] == 0) {
            cnt++;
            DFS2(x);
        }
    }

    g << cnt << '\n';

    for (i = 1; i <= cnt; i++) {
        for (j = 0; j < rez[i].size(); j++) {
            g << rez[i][j] << " ";
        }
        g << '\n';
    }

    return 0;
}
