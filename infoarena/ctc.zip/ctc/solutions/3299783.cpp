#include <bits/stdc++.h>

using namespace std;

ifstream in("sortaret.in");
ofstream out("sortaret.out");

const int N = 5e4 + 5;
int n, m, cnt, topsort[N];
bool viz[N];
vector <int> v[N];

void dfs(int nod){
    viz[nod] = true;
    for(auto vecin : v[nod]){
        if(!viz[vecin])
            dfs(vecin);
    }
    topsort[++cnt] = nod;
}

int main(){
    in >> n >> m;
    for(int i = 1; i <= m; i++){
        int x, y;
        in >> x >> y;
        v[x].push_back(y);
    }

    for(int i = 1; i <= n; i++){
        if(!viz[i])
            dfs(i);
    }

    for(int i = cnt; i >= 1; i--)
        out << topsort[i] << " ";
    return 0;
}
