#include <bits/stdc++.h>
#define nmax 200000
using namespace std;
#define cin fin
#define cout fout
ifstream cin("ctc.in");
ofstream cout("ctc.out");


int n, m, x, y, k, viz[nmax];
vector<int> g[nmax];
vector<int> gt[nmax];
vector<int> v;
set<int> ctc[nmax];


void dfs1(int nod)
{
    viz[nod]=1;
    for(auto nnod : g[nod])
        if(!viz[nnod])
            dfs1(nnod);
    v.push_back(nod);
}

void dfs2(int nod, int index)
{
    viz[nod]=1;
    ctc[index].insert(nod);
    for(auto nnod : gt[nod])
        if(!viz[nnod])
            dfs2(nnod,index);
}

int main()
{
    cin>>n>>m;
    while(m--)
    {
        cin>>x>>y;
        g[x].push_back(y);
        gt[y].push_back(x);
    }
    for(int i=1; i<=n; i++)
    {
        if(!viz[i])
            dfs1(i);
    }
    reverse(v.begin(),v.end());
    for(int i=1; i<=n; i++)
        viz[i]=0;
    for(auto i : v)
    {
        if(!viz[i])
        {
            k++;
            dfs2(i,k);
        }
    }
    cout<<k<<'\n';
    for(int i=1; i<=k; i++,cout<<'\n')
        for(auto i : ctc[i])
            cout<<i<<' ';
}
