#include <fstream>
#include <vector>
#include <bitset>

#define DIM 100005

using namespace std;

ifstream f("ctc.in");
ofstream g("ctc.out");

int n, m, nrctc;
vector<int> edges[DIM], edges1[DIM];
vector<int> ctc[DIM];
bitset<DIM> v;
stack<int> s;

void dfs(int node) {
    v[node] = 1;
    for (auto child: edges[node]) {
        if (!v[child]) {
            dfs(child);
        }
    }
    s.push(node);
}

void dfs1(int node) {
    v[node] = 1;
    ctc[nrctc].push_back(node);
    for (auto child: edges1[node]) {
        if (!v[child]) {
            dfs1(child);
        }
    }
}

int main() {

    f >> n >> m;
    for (int i = 1; i <= m; i++) {
        int x, y;
        f >> x >> y;
        edges[x].push_back(y);
        edges1[y].push_back(x);
    }

    for (int i = 1; i <= n; i++) {
        if (!v[i]) {
            dfs(i);
        }
    }

    v.reset();

    while (!s.empty()) {
        if (!v[s.top()]) {
            nrctc++;
            dfs1(s.top());
        }
        s.pop();
    }

    g << nrctc << "\n";
    for (int i = 1; i <= nrctc; i++, g << "\n") {
        for (auto node: ctc[i]) {
            g << node << " ";
        }
    }

    return 0;
}