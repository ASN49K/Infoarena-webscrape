#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <cstring>
#include <sstream>
using namespace std;

#define FIN  "ctc.in"
#define FOUT "ctc.out"
#define FOK  "ctc.ok"

int n, m, answer, tanswer, where[100005];

char buffer[1 << 20];

void error(char msg[], int p)
{
	fprintf(stderr, msg);
	printf("%d", p);
	exit(0);
}

int main(void)
{
    int x, y;
    FILE *f;

    f = fopen(FIN, "r");
    if (!f) error("Fisier de intrare lipsa!", 0);
    if (fscanf(f, "%d %d", &n, &m) != 2)
        error("Eroare in fisierul de intrare", 0);
    for (int i = 0; i < m; ++ i)
    {
        if (fscanf(f, "%d %d", &x, &y) != 2)
            error("Eroare in fisierul de intrare!", 0);
        if (x < 1 || x > n || y < 1 || y > n)
            error("Eroare in fisierul de intrare!", 0);
    }

    f = fopen(FOK, "r");
    if (!f) error("Fisier de verificare lipsa!", 0);
    if (fscanf(f, "%d\n", &answer) != 1)
        error("Eroare in fisierul ok", 0);
    memset(where, -1, sizeof(where));
    for (int i = 0; i < answer; ++ i)
    {
        if (fgets(buffer, 1 << 20, f) == NULL)
            error("Eroare in fisierul ok", 0);

        string str(buffer);

        istringstream iss(str);
        while (iss >> x) {
            if (x < 1 || x > n)
                error("Eroare in fisierul ok: nod inexistent", 0);
            if (where[x] != -1)
                error("Eroare in fisierul ok: nod duplicat", 0);
            where[x] = i;
        }
    }
    for (int i = 1; i <= n; ++ i) if (where[i] == -1)
        error("Eroare in fisierul ok: noduri lipsa", 0);

    f = fopen(FOUT, "r");
    if (!f) error("Fisier de iesire lipsa!", 0);
    if (fscanf(f, "%d\n", &tanswer) != 1)
        error("Fisier de iesire incomplet", 0);
    if (answer != tanswer)
        error("Numar de componente gresit", 0);
    for (int i = 0; i < tanswer; ++ i)
    {
        if (fgets(buffer, 1 << 20, f) == NULL)
            error("Componente tare conexe: gresit", 4);

        string str(buffer);

        istringstream iss(str);
        int idxc = -1;
        while (iss >> x) {
            if (x < 1 || x > n)
                error("Componente tare conexe: nod inexistent", 4);
            if (where[x] == -1)
                error("Componente tare conexe: nod duplicat", 4);
            if (idxc == -1)
                idxc = where[x];
            else {
                if (idxc != where[x])
                    error("Componenta tare conexa gresita", 4);
            }
            where[x] = -1;
        }
    }
    for (int i = 1; i <= n; ++ i) if (where[i] != -1)
        error("Componente tare conexe: gresit", 4);

    error("Corect", 10);

    return 0;
}


