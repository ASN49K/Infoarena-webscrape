#include <iostream>
#include <fstream>
#include <cstdio>
using namespace std;

int euclid(int a, int b){
    if(b == 0)
        return a;
    return euclid(b, a%b);
}
int main()
{
    freopen("euclid2.in", "r", stdin);
    freopen("euclid2.out", "w", stdout);
    int t, a, b;
    scanf("%d", &t);
    for(int i = 1; i <= t; i++) {
        scanf("%d %d", &a, &b);
        cout<<euclid(a, b)<< '\n';
    }
    return 0;
}
