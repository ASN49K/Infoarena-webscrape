var a,b,i,n,c:integer;
    f,g:text;
function cmmdc(a,b:integer):integer;
begin
     while b<>0 do begin
           c:=a mod b;
           a:=b;b:=c;
           end;
     writeln(g,a);
end;
begin
assign(f,'euclid2.in');
reset(f);
read(f,n);
assign(g,'euclid2.out');
rewrite(g);
for i:=1 to n do begin
    readln(f,a,b);
    if (a<>0)and(b<>0) then
       cmmdc(a,b)
    else if b=0 then writeln(f,a)
         else write(f,b);
    end;
close(f);
close(g);
end.