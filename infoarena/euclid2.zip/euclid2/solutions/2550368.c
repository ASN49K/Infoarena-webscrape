﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 16
VisualStudioVersion = 16.0.29709.97
MinimumVisualStudioVersion = 10.0.40219.1
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "Alg. lui Euclid", "Alg. lui Euclid.vcxproj", "{D738EBFC-6B6D-432C-9A27-8FFE126C9BE1}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|x64 = Debug|x64
		Debug|x86 = Debug|x86
		Release|x64 = Release|x64
		Release|x86 = Release|x86
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{D738EBFC-6B6D-432C-9A27-8FFE126C9BE1}.Debug|x64.ActiveCfg = Debug|x64
		{D738EBFC-6B6D-432C-9A27-8FFE126C9BE1}.Debug|x64.Build.0 = Debug|x64
		{D738EBFC-6B6D-432C-9A27-8FFE126C9BE1}.Debug|x86.ActiveCfg = Debug|Win32
		{D738EBFC-6B6D-432C-9A27-8FFE126C9BE1}.Debug|x86.Build.0 = Debug|Win32
		{D738EBFC-6B6D-432C-9A27-8FFE126C9BE1}.Release|x64.ActiveCfg = Release|x64
		{D738EBFC-6B6D-432C-9A27-8FFE126C9BE1}.Release|x64.Build.0 = Release|x64
		{D738EBFC-6B6D-432C-9A27-8FFE126C9BE1}.Release|x86.ActiveCfg = Release|Win32
		{D738EBFC-6B6D-432C-9A27-8FFE126C9BE1}.Release|x86.Build.0 = Release|Win32
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
	GlobalSection(ExtensibilityGlobals) = postSolution
		SolutionGuid = {0829AF5A-3419-4165-9E2D-22DB49D51B20}
	EndGlobalSection
EndGlobal
