#include <stdio.h>

#define NMax 1024

int M, N, A[NMax], B[NMax], D[NMax][NMax], sir[NMax], bst;

int main(void)
{
    int i, j;

    freopen("cmlsc.in", "r", stdin);
    freopen("cmlsc.out", "w", stdout);

    scanf("%d %d", &M, &N);
    for(i=1;i<=M;++i)
        scanf("%d",&A[i]);

    for(i=1;i<=N;++i)
        scanf("%d",&B[i]);

    for(i=1;i<=M;++i)
        for(j=1;j<=N;++j)
            if(A[i]==B[j])
                D[i][j]=1+D[i-1][j-1];
            else{
                if(D[i-1][j]>D[i][j-1])
                    D[i][j]=D[i-1][j];
                else
                    D[i][j]=D[i][j-1];
            }

   i=M;
   j=N;
   while(j>0 && i>0)
        if(A[i]==B[j])
            sir[++bst]=A[i],i--,j--;
        else if(D[i-1][j]<D[i][j-1])
                j--;
            else i--;


    printf("%d\n", bst);
    for (i = bst; i; --i)
        printf("%d ", sir[i]);

    return 0;
}
