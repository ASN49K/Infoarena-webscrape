#include <iostream>
#include <fstream>

using namespace std;
ifstream f ("cmlsc.in");
ofstream g ("cmlsc.out");
int v[1024], u[1024], a[1024][1024], sol[1024], vizv[1024], vizu[1024];
int main()
{
    int n, m, i, j, k;
    f>>n;
    f>>m;
    for(i=1; i<=n; i++)
        f>>v[i];
    for(i=1; i<=m; i++)
        f>>u[i];
    for(i=0; i<=m; i++)
        for(j=0; j<=n; j++)
    {
        if(i==0 || j==0)
            a[i][j]=0;
    }
    k=1;
    for(i=1; i<=m; i++)
        for(j=1; j<=n; j++)
    {
        if((v[j]==u[i]) && (vizv[j]==0) && (vizu[i]==0))
        {
            a[i][j]=1+a[i-1][j-1];
            vizv[j]=1; vizu[i]=1;
        }
        else
        {if(a[i-1][j]>a[i][j-1])
        a[i][j]=a[i-1][j];
        else a[i][j]=a[i][j-1];}
    }
    i=m;
    j=n;
    while (i>=0 && j>=0)
    {
        if(a[i][j-1]!=a[i][j] && a[i-1][j]!=a[i][j])
        {
            sol[k]=v[i];
            i--; j--; k++;
        }
        else
        {
            if(a[i][j-1]==a[i][j])
                j--;
            else
                i--;
        }

    }
    g<<k-1<<"\n";
    for(i=k-1; i>=1; i--)
        g<<sol[i]<<" ";

    return 0;
}
