#include <iostream>
#include <stdio.h>
#include <fstream>
#define NMAX 1001
#define maxim(a, b) ((a > b) ? a : b)

using namespace std;

ifstream fin("cmlsc.in");
ofstream fout("cmlsc.out");
int A[NMAX],B[NMAX],i,j,N,M;

void Citire()
{   fin>>N>>M;
    for(i=1;i<=N;++i)
        fin>>A[i];
    for(i=1;i<=M;++i)
        fin>>B[i];
}
int dist[NMAX][NMAX];

void ConstruireMatrice()
{
    for(i=1;i<=N;++i)
      for(j=1;j<=M;++j)
        if(A[i]==B[j])
            dist[i][j]=dist[i-1][j-1]+1;
        else
            dist[i][j]=maxim(dist[i][j-1],dist[i-1][j]);

}

void AfisareSol()
{   int k=0,sol[101];
    i=N,j=M;
    while(i>=0 && j>=0)
       {
           if(A[i]==B[j])
               sol[++k]=A[i],--i,--j;
           else
              if(dist[i-1][j]<dist[i][j-1])
                     --j;
              else
                     --i;
       }
     fout<<k<<"\n";
     for(i=k;i>=1;i--)
        fout<<sol[i];
}

int main()
{
   Citire();
   ConstruireMatrice();
   AfisareSol();
   return 0;
}
