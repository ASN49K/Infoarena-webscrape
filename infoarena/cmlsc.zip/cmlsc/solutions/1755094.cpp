#include <fstream>
#include <algorithm>
using namespace std;
ifstream in("cmlsc.in");
ofstream out("cmlsc.out");

int d[1025][1025];

int n, m, a[1025], b[1025], v[1025], k=0, maxim;

int main ()
{
     in>>n>>m;
     for (int i=1; i<=n; i++)
        in>>a[i];

    for (int i=1; i<=m; i++)
        in>>b[i];

    for (int i=1; i<=n; i++)
    {
        for (int j=1; j<=m; j++)
        {
            if (a[i]==b[j])
                d[i][j]=d[i-1][j-1]+1;
            else
                d[i][j]=max(d[i-1][j], d[i][j-1]);
        }
    }

/*for (int i=1; i<=n; i++)
{
    for (int j=1; j<=m; j++)
    {
        out<<d[i][j]<<' ';
    }
    out<<'\n';
}
return 0; */
    maxim = d[n][m];

    int x = n;
    int y = m;

    while (maxim)
    {
        if (a[x] == b[y])
        {
            v[maxim] = a[x];
            maxim--;
            x--;
            y--;
        }
        else
            {
                if (d[x-1][y]>d[x][y-1])
                    x--;
                else
                    y--;
            }
    }

    out<<d[n][m]<<'\n';
    for (int i=1; i<=d[n][m]; i++) out<<v[i]<<' ';
    return 0;
}
