#include <iostream>
#include <fstream>

std::ifstream fin("submultimi.in");
std::ofstream fout("submultimi.out");

void print_solution(int x[], int position)
{
	for (int i = 1; i <= position; i++)
	{
		fout << x[i] << " ";
	}

	fout << std::endl;
}

bool check_valid_solution(int x[], int position)
{
	for (int i = 1; i < position; i++)
	{
		if (x[i] == x[position])
			return false;
	}

	if (x[position - 1] >= x[position])
		return false;

	return true;
}

void submultimi(int x[], int n, int position)
{
	for (int i = 1; i <= n; i++)
	{
		x[position] = i;

		if (check_valid_solution(x, position))
		{
			print_solution(x, position);
			submultimi(x, n, position + 1);
		}
	}
}

int main() {
	int n{0};
	int x[20]{ 0 };

	fin >> n;

	submultimi(x, n, 1);

	return 0;
}