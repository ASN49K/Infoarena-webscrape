#include <stdio.h>

int main()
{
    freopen("submultimi.in", "r", stdin);
    freopen("submultimi.out", "w", stdout);

    int N; //char buffer[1000000];

    scanf("%d", &N);

    for(int i = 1 << N; --i;)
    {
        for(int j = i, d = 1; j; j >>= 1, d++)
        {
            if(j & 1) printf("%d ", d);
        }

        puts("");
    }

    return 0;
}
