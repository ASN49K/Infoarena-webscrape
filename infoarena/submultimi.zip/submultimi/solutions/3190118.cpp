#include <iostream>

#define NMAX 17

using namespace std;

int n, i, v[NMAX];

int main()
{
    cin >> n;
    for(int j = 1; j <= 17; j++)
        v[j] = 0;
    while(!v[0])
    {
        i = n;
        while(v[i])
        {
            v[i] = 0;
            i--;
        }

        v[i] = 1;

        if(i == 0)
            break;
        for(int j = 1; j <= n; j++)
            if(v[j])
                cout << j << " ";
        cout << "\n";
    }
    return 0;
}
