#include <bits/stdc++.h>

using namespace std;

ifstream in ("submultimi.in");
ofstream out ("submultimi.out");

int n;

int x;

int main()
{
    ios_base :: sync_with_stdio(false);
    in.tie(NULL);

    in >> n;

    for(int i = 1; i < (1 << n); i ++)
    {
        x = i;
        for(int j = 1; j <= n; j ++)
        {
            if(x % 2)
            {
                cout << j << " ";
            }
            x /= 2;
        }
        cout << '\n';
    }

    return 0;
}

