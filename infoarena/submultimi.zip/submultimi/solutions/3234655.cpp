#include <bits/stdc++.h>
using namespace std;
ifstream f("inumaki.in");
ofstream g("inumaki.out");

int main()
{
    int n;
    cin >> n;
    for(int i=1; i<=n; i++)
    {
        for(int j=i; j<=n; j++)
        {
            for(int k =i; k<=j; k++)
                cout<<k<<" ";
            cout<<endl;
        }
    }
}
