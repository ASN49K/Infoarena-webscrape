#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main()
{
    int n;
    fin >> n;
    for(int msk = 0; msk <= (1 << n) - 1; msk++)
    {
       for(int bit = 0; bit < n; bit++)
        if((msk & (1 << bit)) > 0)
            fout << bit + 1 << ' ';
        if(msk != 0)
            fout << '\n';
   }
}
