#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int sbm[22], n;

void gen_sbm(int lg) {
    if (lg > 1) {
        for(int i = 1; i < lg; ++i)
            fout << sbm[i] << " ";
        fout << "\n";
    }
    for(int i = sbm[lg - 1] + 1; i <= n && lg <= n; ++i) {
        sbm[lg] = i;
        gen_sbm(lg + 1);
    }
}
int main() {
    fin >> n;
    gen_sbm(1);
}
