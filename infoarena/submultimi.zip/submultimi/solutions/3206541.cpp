#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, i,v[21];
int main()
{
    fin >> n;
    for (i = 0; i <= n; ++i)
        v[0] = 0;
    while (!v[0])
    {
        i = n;
        while (v[i] == 1)
        {
            v[i] = 0;
            i--;
        }
        v[i] = 1;
        if (i == 0)
            break;
        for (i=1; i<=n; i++)
            if (v[i] == 1)
                fout << i << " ";
        fout << "\n";
    }
    return 0;
}
