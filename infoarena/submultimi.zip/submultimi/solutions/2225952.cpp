
#include<iostream>
#include<fstream>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int N,*a;
void afisare(int n)
{
    for(int i =1; i<=n;i++)
            g<<a[i]<<" ";
    g<<endl;
}
bool valid(int k)
{
    if(a[k-1] >= a[k] && k>1)
        return false;

    return true;
}
void backtracking(int k)
{
    int i;
    for(i=1;i<=N;i++)
    {
        a[k] = i;
        if(valid(k))
        {
            afisare(k);
            if(k<N)
                backtracking(k+1);
        }
    }
}
int main()
{
    f>>N;
    a = new int[N+1];
    //for(int i=1;i<=N;i++)
      //  a[i]=0;

    backtracking(1);
    f.close();
    g.close();
    return 0;
}
