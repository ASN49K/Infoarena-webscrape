#include <bits/stdc++.h>
using namespace std;

ifstream fin ("submultimi.in");
ofstream fout("submultimi.out");

const int dim=20;

int n,sol[dim];

void afis(int pas){
    for(int i=1;i<=pas;i++){
        fout<<sol[i]<<' ';
    }
        fout<<'\n';
}

void backtracking(int pas){
    for(int i=sol[pas-1]+1;i<=n;i++){
        sol[pas]=i;
        afis(pas);
        if(pas<n){
            backtracking(pas+1);
        }
    }
}

signed main(){
        fin>>n;
    backtracking(1);
}
