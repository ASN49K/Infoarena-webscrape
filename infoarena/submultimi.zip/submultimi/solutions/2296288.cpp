#include <fstream>

using namespace std;
int n,x[20],viz[20],kk;
ifstream fin("combinari.in");
ofstream fout("combinari.out");
void Afisare()
{
    for(int i=1;i<=kk;i++)
        fout<<x[i]<<" ";
    fout<<"\n";
}
void Back(int k)
{
    for(int i=x[k-1]+1;i<=n;i++)
    {

            x[k]=i;
            viz[i]=1;
            if(k==kk) Afisare();
            else Back(k+1);
            viz[i]=0;

    }
}
int main()
{
    fin>>n>>kk;
    Back(1);
    return 0;
}
