#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_set>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");


void back(int index, int stop,int start, vector<int>& domain, vector<int>& solution) {
	if(index == stop){
		for(int i : solution) {
			fout<<i<<" ";
		}
		fout<<endl;
	}
	for(int i=start;i<domain.size();i++) {
		solution[index] = domain[i];
		back(index+1, stop, i+1, domain, solution);
	}
}

int main() {

	int n;
	fin>>n;
	vector<int> domain(n);
	for(int i=0;i<n;i++) {
		domain[i] = i + 1;
	}
	for(int i=1;i<=n;i++){ 
		vector<int> solution(i);
		back(0, i, 1, domain, solution);
	}
	return 0;
}