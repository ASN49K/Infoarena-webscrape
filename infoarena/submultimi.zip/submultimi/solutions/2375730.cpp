#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int a[20];
int n;

void afisare( int z )
{
    for( int i = 1 ; i <= z ; ++i )
        fout << a[i] << " ";
    fout << '\n';
}

void bac( int z )
{
    for( int i = a[z-1] + 1 ; i <= n ; ++i )
    {
        a[z] = i;
        afisare(z);
        bac(z+1);
    }

}

int main()
{
    fin >> n;
    bac(1);
}
