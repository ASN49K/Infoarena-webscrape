#include <fstream>
using namespace std;
ifstream fin("sume.in");
ofstream fout("sume.out");
int s, i,b,e,m,n;
long long a[100001];
int main() {
    fin >> n;
    for(i=1;i<=n;i++) {
        fin >> s;
        a[i]= a[i-1]+ a[i];
    }
    fin >> m;
     for(i=1;i<=m;i++) {
        fin >> b >> e;
        fout << a[e] - a[b-i] << endl;
     }
}
