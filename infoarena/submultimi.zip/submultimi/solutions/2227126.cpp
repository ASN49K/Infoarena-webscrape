#include <stdio.h>

int main() {

freopen("submultimi.in", "r", stdin);
freopen("submultimi.out", "w", stdout);

int N, i, j, m, two_n;

scanf("%d", &N);
two_n = 1 << N;

for(i=1; i<two_n; i++){
    m = 1;
    for(j=1; j<=N; j++){
        if(i & m){
            printf("%d ", j);
        }
        m <<= 1;
    }printf("\n");
}
return 0;
}
