#include <iostream>
#include <fstream>

using namespace std;

ifstream f ("submultimi.in");
ofstream g ("submultimi.out");

int n, sol[17];

bool ok (int poz)
{
    int i;
     for (i=1; i<poz; i++)
       if (sol[i] >= sol[poz])
          return false;
     return true;
}

void afisare (int poz)
{
    for (int i=1; i<=poz; i++)
        g << sol[i] << " ";
    g << '\n';
}

void bkt (int k)
{
    for (int i=1; i<=n; i++)
    {
        sol[k] = i;
         if (ok(k))
         {
             afisare(k);
             bkt(k+1);
         }
    }
}

int main()
{
 f >> n;
 bkt(1);
    return 0;
}
