#include <bits/stdc++.h>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n, x[20];
void afis()
{
    for(int i = 1 ; i <= n ; i++)
        if(x[i] == 1)
        fout << i << " " ;
    fout << '\n';
}
void back(int k)
{
    if(k > n )
        afis();
    else
        for(int i = 1 ; i >= 0 ; i--)
    {
        x[k] = i;
        back(k+1);
    }
}

int main()
{
    fin >> n;
    back(1);
    return 0;
}
