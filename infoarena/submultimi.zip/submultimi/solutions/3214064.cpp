#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;

int main(){
    fin >> n;
    for(int i = 1; i <= (1 << n) - 1; i++, fout << '\n')
        for(int j = 0; j < n; j++) if((1 << j) & i) fout << j + 1 << ' ';
    return 0;
}