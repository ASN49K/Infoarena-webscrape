
// problema submultimi

#include <iostream>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <string>
#include <cstring>
#include <vector>
#include <stack>
#include <queue>
#include <deque>

#define NMax 16

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, vmax;

void input() {
    fin >> n;
}

void solve() {
    vmax = 1 << n;
    for (int i = 1; i < vmax; ++i) {
        for (int j = 0; j < n; ++j) {
            if (i & (1 << j)) fout << j + 1 << ' ';
        }
        fout << '\n';
    }
}

int main() {
    input();
    solve();
}
