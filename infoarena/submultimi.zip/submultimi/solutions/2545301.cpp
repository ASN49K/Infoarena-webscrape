#include <bits/stdc++.h>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int a[20],n;
void Afisare()
{
    for (int i=1; i<=n; i++)
        if (a[i]==0) fout << i << " ";
    fout << "\n";
}
void Back(int top)
{
    if (top==n+1) Afisare();
    else for (int i=0; i<=1; i++)
    {
        a[top]=i;
        Back(top+1);
    }
}
int main()
{
    fin >> n;
    Back(1);


    return 0;
}
