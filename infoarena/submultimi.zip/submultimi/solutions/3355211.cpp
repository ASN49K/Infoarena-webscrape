#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <queue>
#include <stack>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
vector<int> sol;
vector<int> visited;
int n, nr;
void back(int u) {
    for(int i = 1; i <= n; i++) {
        if(visited[i] == 1) {
            fout<<sol[i]<<" ";
        }
    }
    if(nr != 0)
        fout<<"\n";
     
    for(int i = sol[u - 1] + 1; i <= n; i++) {
        if(visited[i] == 0) {
            nr++;
            sol[u] = i;
            visited[i] = 1;
            back(u + 1);
            visited[i] = 0;
            nr--;
        }
    }
}

int main() {
    fin>>n;
    nr = 0;
    sol.assign(n + 1, 0);
    visited.assign(n + 1, 0);
    back(1);
    return 0;
}