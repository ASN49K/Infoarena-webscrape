#include <bits/stdc++.h>

using namespace std;
ifstream f("submultimi.in");ofstream g("submultimi.out");constexpr int NMAX = 17;int n, a[NMAX];void Afisare(int k){	for (int i = 1; i <= k; i++)		g << a[i] << ' ';	g << '\n';}void bkt(int k){	for (int i = a[k-1] + 1; i <= n; i++)	{		a[k] = i;		Afisare(k);		bkt(k+1);	}}
int main()
{	ios_base::sync_with_stdio(false);	f.tie(nullptr); g.tie(nullptr);	f >> n;	f.close();	bkt(1);	g.close();
    return 0;
}
