/*#include <fstream>
using namespace std;
ifstream f("Andrei.in");///Andrei.in
ofstream g("Andrei.out");

int n,m,a[26][26];

void citire()
{   f>>n>>m;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=m;++j) f>>a[i][j];
}

int main()
{   citire();



g.close();
return 0;
}*/
#include <fstream>
using namespace std;
ifstream f("submultimi.in");///submultimi.in
ofstream g("submultimi.out");

unsigned n,x[26],k;

void afis()
{   for(int i=1;i<=k;++i) g<<x[i]<<' ';
    g<<'\n';
}

int cond(int k)
{   if( k >= 2 )
        if( x[k-1] >= x[k] ) return 0;
    return 1;
}

void backtracking()
{   k=1; x[k]=0;
    do
    {   while( x[k] < n )
        {   x[k]++;

            if( cond(k) )
            {   if( k < n ) afis();

                if( k == n ) afis();
                else x[++k]=0;
            }
        }
        k--;
    }
    while(k);
}

int main()
{   f>>n;

    backtracking();

g.close();
return 0;
}
