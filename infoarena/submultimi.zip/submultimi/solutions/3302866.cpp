#include <algorithm>
#include <fstream>
#include <vector>

using namespace std;

ifstream cin("submultimi.in");
ofstream cout("submultimi.out");

vector<int>v;

void f(int n)
{
    if(v.size())
    {
        for(int i=0;i<v.size();i++)
            cout<<v[i]<<' ';
        cout<<'\n';
    }
    for(int i=1;i<=n;i++)
    {
        if(find(v.begin(),v.end(),i)==v.end())
        {
            if(!v.size())
            {
                v.push_back(i);
                f(n);
                v.pop_back();
            }
            else if(v[v.size()-1]<i)
            {
                v.push_back(i);
                f(n);
                v.pop_back();
            }
        }
    }
}

int main()
{
    int n;
    cin>>n;
    f(n);
    return 0;
}
