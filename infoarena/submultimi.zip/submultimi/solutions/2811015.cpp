#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

void gen(int element, int submLength, int elementsNumber, int subm[16]) {
  if (element > elementsNumber) {
    for (int i = 0; i < submLength; ++i) {
        fout << subm[i] << ' ';
    }
    fout << '\n';
    return;
  }
  subm[submLength] = element;
  gen(element + 1, submLength + 1, elementsNumber, subm);
  gen(element + 1, submLength, elementsNumber, subm);
}

int main() {
    int n, v[16];
    fin >> n;
    gen(1, 0, n, v);
    return 0;
}
