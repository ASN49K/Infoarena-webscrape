#include <fstream>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n, l;
int main()
{
    fin >> n;
    fin >> l;
    for (int i = (1<<n) - 1; i >= 1; i--)
    {
        int x = 0;
        for (int j = 0; (1 << j) <= i; j++)
        {
            if (i & (1 << j))
            {
                fout << n - j << ' ';
            }
        }
        fout << endl;
    }
    return 0;
}
