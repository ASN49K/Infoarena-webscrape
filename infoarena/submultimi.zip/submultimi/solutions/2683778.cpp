#include <bits/stdc++.h>
using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int n,i,x,a[10001];
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
    {
        a[i]=i;
    }
    for(x=1;x<=(1<<n);x++)
    {
        for(i=0;i<n;i++)
        {
            if(x&(1<<i))g<<a[i+1]<<" ";
        }
        g<<'\n';
    }
    return 0;
}



