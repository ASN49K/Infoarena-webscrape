#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int stiva[17],n;
void tipar(int k){for(int i=1;i<=k;i++)fout<<stiva[i]<<" ";fout<<'\n';}
int valid(int k)
{
    for(int i=1;i<k;i++) if(stiva[i]==stiva[k]) return 0;
    return 1;
}
void bt(int k)
{
    for(int i=stiva[k-1]+1;i<=n;i++)
    {
        stiva[k]=i;
        if(valid(k)==1)
            {if(k<=n) tipar(k);
            if(k<n) bt(k+1);}
    }
}
int main()
{
    fin>>n; bt(1);
    return 0;
}
