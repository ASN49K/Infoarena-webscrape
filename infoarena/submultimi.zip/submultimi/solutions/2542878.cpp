#include <fstream>

using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");

int x[17],n;

void bkt(int n)
{
    int k=1;
    while(k)
    {
        if(x[k]<n && k<=n)
        {
            ++x[k];
            for(int i=1;i<=k;++i)
                g<<x[i]<<' ';
            g<<'\n';
            ++k;
            x[k]=x[k-1];
        }
        else
        {
            --k;
        }
    }
}
int main()
{
    f>>n;
    bkt(n);
    return 0;
}
