#include <fstream>
using namespace std;

ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");

void afisare(int n, int v[]) {
    for (int i = 1; i < n; i++)
        fout << v[i] << " ";
    fout << "\n";
}

void submultimi(int n, int v[], int dim) {
    if (dim > 1)
        afisare(dim, v);

    for (int i = v[dim - 1] + 1; i <= n && dim <= n; i++) {
        v[dim] = i;
        submultimi(n, v, dim + 1);
    }
}

int main() {
    int n;
    fin >> n;

    int v[17] = {0};
    submultimi(n, v, 1);

    return 0;
}
