#include <fstream>

using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
int v[15],l=0,n;
void backtracking(int val)
{
    if(val>n)
    {
        if(l==0)
            return ;
        for(int i=1; i<=l; i++)
            cout<<v[i]<<" ";
        cout<<'\n';
    }
    else
    {
backtracking(val+1);
        v[++l]=val;
        backtracking(val+1);
        l--;

    }
}
int main()
{
    cin>>n;
    backtracking(1);
    return 0;
}
