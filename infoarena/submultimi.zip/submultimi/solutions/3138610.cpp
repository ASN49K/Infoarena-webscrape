#include<fstream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int x[20],n,m;

void afis(int p)
{
    int i;
    for(i=1; i<=p; i++)
        fout<<x[i]<<" ";
    fout<<'\n';
}

void bk(int p)
{
    int i;
    for(i=x[p-1]+1; i<=n; i++)
    {
        x[p]=i;
            afis(p);
            bk(p+1);
    }
}
int main()
{
    fin>>n;
    bk(1);
    fin.close();
    fout.close();
    return 0;
}
