#include <fstream>

using namespace std;
ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");
int main ()
{
	int n,i,ii;
	fin>>n;
	for(i=1;i<(1<<n);++i)
	{
		for(ii=0;ii<n;++ii)
			if((i & (1<<ii))==(1<<ii))
				fout<<ii+1<<" ";
		fout<<"\n";
	}
	return 0;
}
