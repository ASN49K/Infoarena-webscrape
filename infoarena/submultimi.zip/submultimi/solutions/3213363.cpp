#include <bits/stdc++.h>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

#define pii pair<int, int>
#define pb push_back
#define fi first
#define se second

const int NMAX = 20;
const int INF = 0x3f3f3f3f;

int n, v[NMAX];
vector<int> p;

void read()
{
    in >> n;
}

void back(int k)
{
    for (int i=1; i<=n; i++)
    {
        if (!v[i] && (p.empty() || *(p.end()-1) < i))
        {
            v[i] = 1;
            p.pb(i);
            for (auto e : p) out<<e<<' ';
            out<<'\n';

            if (k<n)
                back(k+1);

            v[i] = 0;
            p.pop_back();
        }
    }
}

void solve()
{
    back(1);
}

int main()
{
    cin.tie(0);
    cout.tie(0);
    ios::sync_with_stdio(false);

    read();
    solve();

    return 0;
}