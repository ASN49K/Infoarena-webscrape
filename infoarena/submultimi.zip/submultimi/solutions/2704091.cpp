#include <iostream>
#include <fstream>
#include <vector>
#include <math.h>
#include <algorithm>
using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n;
int sol[17];

void print_sol(int k) {
  for (int i = 1; i <= n; i++) {
    if (sol[i]) {
      g << sol[i] << " ";
    }
  }
  g << "\n";
}

void gen_submultimi(int idx, int k) {
  if (k > n) {
    return;
  }
  sol[idx] = k;
  print_sol(k);
  gen_submultimi(idx + 1, k + 1);
  sol[idx] = 0;
  gen_submultimi(idx, k + 1);
}

int main() {
  f >> n;
  gen_submultimi(1, 1);
}
