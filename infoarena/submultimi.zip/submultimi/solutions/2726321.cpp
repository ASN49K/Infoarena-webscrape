#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
vector <int> stk;


void backTracking(int step)
{
    if (step > n )
    {
        for (auto i : stk)
        {
            fout << i << ' ';
        }
        if (!stk.empty())
            fout << '\n';
        return;
    }

    backTracking(step + 1);

    stk.push_back(step);
    backTracking(step + 1);

    stk.pop_back();
}


int main()
{

    fin >> n;
    backTracking(1);
    return 0;
}
