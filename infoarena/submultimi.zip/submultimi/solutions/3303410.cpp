#include <bits/stdc++.h>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

int n,v[17];
void back(int k,int d)
{
    v[d]=k;
    if(d)
    {
        for(int i=1;i<=d;i++)
            out<<v[i]<<" ";
        out<<'\n';
    }
    for(int i=k+1;i<=n;i++)
        back(i,d+1);
}
int main()
{
    in>>n;
    back(0,0);
    return 0;
}