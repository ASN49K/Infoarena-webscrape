#include <stdio.h>
#include <stdlib.h>

int main()
{
    freopen("submultimi.in", "r", stdin);
    freopen("submultimi.out", "w", stdout);
    int n;
    scanf("%d", &n);
    int p, b;

    for(p = 0; p < (1 << n); p++)
    {
        for(b = 1; b <= n; b++)
            if(p & (1 << (b-1)))
                printf("%d ", b);

        printf("\n");
    }

    scanf("%u",&n);

}
