#include<iostream>
#include<fstream>
using namespace std;
int n,v[100],k;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
void init(){v[k]=-1;}
//nu avem conditie
int solutie(){return (k==n);}

void afisare()
{   for(int i=1;i<=k;i++)
      {if(v[i]==1)g<<i<<" ";}
      g<<'\n';}

void bt()
{
   k=1;
   init();
   while(k>0)
     {  while(v[k]<1)
	 {
           v[k]++;
            if(solutie())afisare();
              else{k++;init();}               //acest else este de la ultimul if(de la solutie)
         }

        k--;
     }
}

int main()
{
	f>>n;
 	bt();
	return 0;
}
