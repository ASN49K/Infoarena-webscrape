#include <fstream>
using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n, x[17];

void afisare(int k)
{
    for (int i = 1; i <= k; i++)
        g << x[i] << " ";
    g << '\n';
}

void backt(int k)
{
    for (int i = x[k - 1] + 1; i <= n; i++)
    {
        x[k] = i;
        afisare(k);
        backt(k + 1);
    }
}

int main()
{
    f >> n;
    x[0] = 0; 
    backt(1);
    f.close();
    g.close();
    return 0;
}
