#include <fstream>
int n,m,sol[20];
using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
void scrie(){
	for(int i=1;i<=m;++i)
		g<<sol[i]<<" ";
    g<<'\n';
}
void back(int k){
	if(k==m+1){
		scrie();
		return;
	}
	for(int i=1+sol[k-1];i<=n-m+k;++i){
		sol[k]=i;
		back(k+1);
	}
}
int main(){
	f>>n;
	for(m=1;m<=n;++m)
		back(1);
	return 0;
}
