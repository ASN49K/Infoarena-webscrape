#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n,nr,k,c,limita;
int main()
{
  fin>>n;
limita=(1<<(n+1))-1;
for(int i=1;i<=n;i++){
    for(int j=0;j<n;j++){
        if((i>>j)&1==1)
            fout<<j+1<<" ";
    }

fout<<"\n";
}
}
