#include <fstream>
#include <iostream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, x[18], used[18];
void bkt(int p) {
    if(p>n)return;
    for(int i=x[p-1]+1;i<=n;i++)
    {
        x[p]=i;
        if(p<=n)
        {
            for(int i=1;i<=p;i++)
                fout<<x[i]<<" ";
            fout<<'\n';
        }
        bkt(p+1);
    }
}

int main() {
    fin >> n;
    cout<<n;
    bkt(1);
    return 0;
}