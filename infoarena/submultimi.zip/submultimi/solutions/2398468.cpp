#include <fstream>

using namespace std;

ifstream cin("submultimi.in");
ofstream cout("submultimi.out");

int n, k, sol[10], viz[10];

void bkt(int poz);

int main()
{
    cin >> n;

    bkt(1);

    return 0;
}

void bkt(int poz)
{
    if(poz > n + 1)
        return ;

    for(int i = 1; i < poz; i++)
        cout << sol[i] << " ";

    if(poz > 1)
        cout << '\n';

    for(int i = sol[poz - 1] + 1; i <= n; i++)
    {
        sol[poz] = i;

        bkt(poz + 1);

        sol[poz] = 0;
    }
}
