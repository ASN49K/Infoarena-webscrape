#include <bits/stdc++.h>
using namespace std;
int n;
string __fname = "submultimi"; ifstream in (__fname + ".in"); ofstream out (__fname + ".out"); 
#define cin in 
#define cout out
vector <int> a(20);

void back (int step) {
  if (step == n + 1) {
    for (int i = 1; i <= n; i++) {
      if (a[i]) cout << i << " ";
    }
    cout << "\n";
    return;
  }
  a[step] = 1;
  back(step + 1);
  a[step] = 0;
  back(step + 1);
}

int main() {
  cin >> n;
  back(1);
  return 0;
}