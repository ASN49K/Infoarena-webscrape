#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, lg, sir[22];

void bkt(int lg) {
    if (lg == n + 1)
        return;
    for (int i = sir[lg - 1] + 1; i <= n; i++) {
        sir[lg] = i;
        for (int i = 1; i <= lg; i++)
            fout << sir[i] << ' ';
        fout << '\n';
        bkt(lg + 1);
    }
}

int main()
{
    fin >> n;
    bkt(1);
    return 0;
}
