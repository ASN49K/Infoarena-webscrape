#include <fstream>

using namespace std;

ifstream fin  ("submultimi.in");
ofstream fout ("submultimi.out");

int n, x[20];

inline void print (int k){
    int i;
    for (i=1; i<=k; i++){
        fout << x[i] << " ";
    }
    fout << "\n";
}

inline void bkt (int k){
    int i;
    for (i=x[k-1]+1; i<=n; i++){
        x[k] = i;
        print (k);
        bkt (k+1);
    }
}

int main(){
    fin >> n;
    bkt(1);
    return 0;
}
//recapitulare
