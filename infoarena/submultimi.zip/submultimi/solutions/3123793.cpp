#include <fstream>

using namespace std;

ifstream cin("submultimi.in");
ofstream cout("submultimi.out");

int main()
{
    int n;
    cin >> n;

    int lim = (1 << (n + 1)) - 1;
    for(int i = 1; i <= lim / 2; i++)
    {
        for(int j = 1; j <= n; j++)
            if((1 << (j - 1)) & i)    
                cout << j << ' ';
        cout << '\n';
    }

    return 0;
}