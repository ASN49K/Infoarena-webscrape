#include <bits/stdc++.h>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, total;

int main()
{

    fin >> n;
    total = (1 << n);

    for(int i = 1; i < total; ++i){
        int j = i;
        for(int k = 1; j; ++k){
            if(j & 1) fout << k << " ";
            j >>= 1;
        }

        fout << "\n";
    }

    return 0;
}
