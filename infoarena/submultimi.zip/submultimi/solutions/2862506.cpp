#include <fstream>

using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int s[20];
void afisare(int k)
{
    for(int i=1;i<=k;i++)
        g<<s[i]<<" ";
    g<<'\n';
}
int n;
void bkt(int k,int p)
{
    for(int i=p;i<=n;i++)
    {
        s[k]=i;
        afisare(k);
        bkt(k+1,i+1);
    }
}
int main()
{
    f>>n;
    bkt(1,1);
    return 0;
}
