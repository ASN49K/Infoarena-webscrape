#include <iostream>
#include <fstream>
using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");
void print_solutie(int sol[17], int k)
{
    for(int i =1; i<=k; i++)
    {
        out<<sol[i]<<" ";
    }
    out<<"\n";
}

void bkt (int p, int k,int n, int sol[17])
{
    if(p==k+1 && k!=0)
    { 
        print_solutie(sol,k);
        return;
    }
    for(int i=1+sol[p-1]; i<=n; i++)
    {
        sol[p]=i;
        bkt(p+1,k,n,sol);
            
    }

}

int main()
{
     int n,k;
     int sol[17]={0};
     in>> n;
    for( k=0; k<=n;k++)
     bkt(1,k,n,sol);

return 0;
}
