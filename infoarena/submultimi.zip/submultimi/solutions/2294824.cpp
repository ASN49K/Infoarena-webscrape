#include <bits/stdc++.h>
 
using namespace std;
 
ifstream in("submultimi.in");
ofstream out("submultimi.out");

const int Nmax = 20;

int n, v[Nmax];

void afisare() {
    vector< int > sol;
    for(int j = 1; j <= n; ++j) {
        if(v[j]) {
            sol.push_back(j);
        }
    }

    if((int)sol.size() > 0) {
        for(auto it: sol) {
            out << it << " ";
        }
        out << "\n";
    }
}

void bkt(int k) {
    for(int i = 0; i <= 1; ++i) {
        v[k] = i;
        if(k == n) {
            afisare();
        } else {
            bkt(k + 1);
        }
    }
}
 
int main() {
    ios::sync_with_stdio(false); in.tie(0); out.tie(0);
    
    in >> n;

    bkt(1);
 
    in.close(); out.close();
 
    return 0;
}