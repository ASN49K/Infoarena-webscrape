#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

short n;
const short NMAX = 16;
bool taken[NMAX+5];

void backtracking(const short &k)
{
    if (k == n+1) {
        bool ok = false;

        for (short i = 1; i <= n; i++)
            if (taken[i])
                ok = true, fout<<i<<' ';
            
        if (ok) fout<<'\n';
    }
    else taken[k] = false, backtracking(k+1), taken[k] = true, backtracking(k+1); 
}

int main()
{
    fin>>n;
    backtracking(1);
    return 0;
}