#include <stdio.h>
#include <stdlib.h>

FILE *fin , *fout;

int n;

int v[17];
int f[17];

void bkt(int pos) {
    if(pos>0 && pos<=n) {
        for(int i=1;i<=pos;i++) {
            fprintf(fout,"%d ",v[i]);
        }
        fprintf(fout,"\n");
    }

    for(int i=1;i<=n;i++) {
        if(f[i]==0 && i>v[pos]) {
            f[i]=1;
            v[pos+1]=i;
            bkt(pos+1);
            f[i]=0;
        }
    }
}

int main() {
    fin=fopen("submultimi.in","r");
    fout=fopen("submultimi.out","w");

    fscanf(fin,"%d",&n);

    bkt(0);

    fclose(fin);
    fclose(fout);
    return 0;
}
