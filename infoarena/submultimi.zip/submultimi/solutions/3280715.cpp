// 100 Puncte (cu operatii pe biti)
#include <bits/stdc++.h>

using namespace std;

ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    int n; fin>>n;
    for (int i=1; i<(1<<n); i++) {
        for (int j=1; j<=n; j++) {
            if (i&(1<<(j-1))) {
                fout<<j<<' ';
            }
        }
        fout<<'\n';
    }
    return 0;
}