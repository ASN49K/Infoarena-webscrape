#include <fstream>
using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
int n,x[20];
bool fr[20];
void afisare(int m){
    for(int i=1;i<=m;i++)
        cout<<x[i]<<" ";
    cout<<'\n';
}
void back(int k){
    for(int i=x[k-1]+1;i<=n;i++)
        if(!fr[i]){
            fr[i]=1;
            x[k]=i;
            afisare(k);
            if(k<n)
                back(k+1);
            fr[i]=0;
        }
}
int main()
{
    cin>>n;
    back(1);
    return 0;
}
