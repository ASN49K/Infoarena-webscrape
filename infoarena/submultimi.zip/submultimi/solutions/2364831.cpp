<?xml version="1.0" encoding="UTF-8" standalone="yes" ?>
<CodeBlocks_layout_file>
	<ActiveTarget name="Debug" />
	<File name="main.cpp" open="1" top="1" tabpos="0">
		<Cursor position="441" topLine="14" />
	</File>
</CodeBlocks_layout_file>
