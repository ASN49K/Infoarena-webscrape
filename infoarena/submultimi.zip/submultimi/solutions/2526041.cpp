#include <bits/stdc++.h>
using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int N;


int main()
{
    f>>N;

    for(int i=1;i<=(1<<N)-1;i++)
    {
        for(int j=0;j<=log2(i)+1;j++)
        if( ( i & ( 1<<j ) ) > 0 ) g<<j+1<<' ';
        g<<'\n';
    }


    return 0;
}
