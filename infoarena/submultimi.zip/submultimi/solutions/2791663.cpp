#include <bits/stdc++.h>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int a[20] , n;

void Afisare(int x)
{
    for(int i =  1; i <= x ; i++)
        fout << a[i] << " ";
    fout << "\n";
}

int Back(int k)
{
    for(int i = a[k - 1] + 1 ; i <= n ; i++)
    {
        a[k] = i;
        Afisare(k);
        if (a[k] < n)
            Back(k + 1);
    }
}

int main()
{
    fin >> n;
    Back(1);
    return 0;
}
