#include <fstream>

using namespace std;
int n,i,v[100],r;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
void bkt(int poz)
{
	if(poz==n+1)
	{
		r=0;
		for(i=1;i<=n;i++)
		{
			if(v[i]==1)
			{
				r=1;
				g<<i<<" ";
			}
		}
		if(r==1)g<<'\n';
		return;
	}
	v[poz]=1;
	bkt(poz+1);
	v[poz]=0;
	bkt(poz+1);
}

int main(int argc, char *argv[]) {
	f>>n;
	bkt(1);
}
