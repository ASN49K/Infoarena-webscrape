#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int stack[1001], n, level;
void init()//initializeaza val. pe primul nivel
{
    stack[level]=-1;
}
int succesor()
{
    if(stack[level]<1)
    {
        stack[level]++;
        return 1;
    }
    return 0;
}
int valid()
{
    return 1;
}
int solutie()
{
    return n==level;
}
void print()
{
    for(int i=1; i<=n; i++)
    {
        if(stack[i]==1)
        {
            fout<<i<< " ";
        }
    }
        fout<<endl;
}
int solve()
{
    level=1;
    init();
    while(level>0)
    {
        int h,v;
        h=1;
        v=0;
        while(h && !v)
        {
            h=succesor();
            if(h==1)
            {
                v=valid();
            }
        }
        if(h)
        {
            if(solutie())
            {
                print();
            }
            else
            {
                level++;
                init();
            }
        }
        else
        {
            level--;
        }
    }
}
int main()
{
    n=4;
    solve();
}
