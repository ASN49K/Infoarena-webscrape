#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n, i, j;
int main()
{
    fin >> n;
    for (i = 1; i < (1 << n); i++)
    {
        for (j = n; j > 0; j--)
        {
            if ((i >> (j-1)) & 1)
                fout << j << ' ';
        }
        fout << '\n';
    }
    return 0;
}
