/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <fstream>
#define Max 2147483647

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, x[20]={0};

void afisare()
{
    for(int i=1;i<=n;i++)
    {
        if(x[i]==1)
            fout<<i<<" ";
    }
    fout<<"\n";
}
void backtrack(int k)
{
    for(x[k]=1;x[k]>=0;x[k]--)
    {
        if(k<=n)
        {
        if(k==n)
        {
            afisare();
        }
        backtrack(k+1);
        }
    }
}
int main()
{

    fin>>n;
    backtrack(1);
    return 0;
}
