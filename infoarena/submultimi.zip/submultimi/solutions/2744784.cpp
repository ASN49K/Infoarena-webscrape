#include <iostream> 
#include <fstream>
#include <iomanip>
#include <cmath>
#include <algorithm> 
#include <cstring>

using namespace std;

string NumeFisier = "submultimi";

ifstream fin(NumeFisier + ".in");
ofstream fout(NumeFisier + ".out");

typedef unsigned long long int ull;

int n, sol[18];

void print(int k)
{
	for (int i = 1; i <= k; i++)
		fout << sol[i] << " ";
	fout << '\n';
}

bool check(int k)
{
	if (k == 1)
		return 1;
	if (sol[k - 1] >= sol[k])
		return 0;
	return 1;
}

void back(int k)
{
	if (k <= n)
	for (int i = 1; i <= n; i++)
	{
		sol[k] = i;
		if (check(k)) 
		{
			print(k);
			back(k + 1);
		}
	}
}

int main()
{
	fin >> n;
	back(1);
}