#include<stdio.h>
int n;
int main()
{
	freopen("submultimi.in","r",stdin);
	freopen("submultimi.out","w",stdout);
	scanf("%d",&n);
	int i,j,lim=1<<n;
	for(i=1;i<lim;i++)
	{
		for(j=1;j<=n;j++)
			if(i&(1<<(j-1)))
				printf("%d ",j);
		printf("\n");
	}
	return 0;
}
