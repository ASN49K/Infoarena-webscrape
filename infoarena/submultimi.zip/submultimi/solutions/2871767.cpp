#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, v[17],i;

int main()
{

   fin >> n;
   while(v[0]==0){
       for(int i=n; v[i]==1; --i) v[i]--;
          v[i]=1;
       for(int i=1;i<=n; ++i)
           if(v[i]==1) fout << i << " ";

       fout << '\n';
   }

    return 0;
}

