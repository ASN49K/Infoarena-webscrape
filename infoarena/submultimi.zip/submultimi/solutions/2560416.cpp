#include <iostream>

int main()
{
    int n;
    std::cin>>n;

    for(int i=1; i<=(1<<n); i++)
    {
        for(int j=0; j<n; j++)
            if(i & (1<<j))
                std::cout<<j + 1<<' ';
        std::cout<<'\n';
    }
    return 0;
}
