#include <bits/stdc++.h>
 
using namespace std;
 
ifstream f("submultimi.in");
ofstream g("submultimi.out");

int x[17];
int n;

void afis(int n){
	for(int i = 1;i <= n;i++)
		g << x[i] << " ";
	g << "\n";
}

void bk(int k){
	for(int i = x[k - 1] + 1;i <= n;i++){
		x[k] = i;
		afis(k);
		if(k < n)  bk(k + 1);
	}
}

int main(){
	f >> n;
	bk(1);
}