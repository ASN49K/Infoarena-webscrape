#include "bits/stdc++.h"
using namespace std;
void binare( string &s){
    for(int i = s.size()-1; i>=0;i--){
        if (s[i] == '0'){
            s[i] = '1';
            break;
        } else {
            s[i] = '0';
        }
    }
}
int main() {
    ifstream cin("submultimi.in");
    ofstream cout("submultimi.out");
    int n;
    string p="";
    cin >> n;
    for(int e = 0; e < n ; e++){
        p+="0";
    }
    for(int i = 0; i < pow(2,p.size())-1; i++){
        binare(p);
        for(int a = 0 ; a < p.size(); a++){
            if(p[a]=='1'){
                cout << a + 1 << " ";
            }
        }
        cout << endl;
    }
    
    return 0;
}
