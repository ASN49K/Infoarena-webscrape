#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int N;
int v[17];

void afiseaza(int p)
{
    for(int i=1;i<=p;i++)
    {
        fout<<v[i]<<" ";
    }
    fout<<'\n';
}

int main()
{
    fin>>N;
    int p=1;
    v[p]=0;
    while(p>0)
    {
        if(v[p]<N)
        {
            v[p]++;
            afiseaza(p);
            if(p<N)
            {
                p++;
                v[p]=v[p-1];
            }
        }
        else
        {
            p--;
        }
    }
    return 0;
}
