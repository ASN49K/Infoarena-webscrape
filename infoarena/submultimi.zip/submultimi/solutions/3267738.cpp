⁠ #include <iostream>
#include <fstream>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

int v[20], n, i, j, cnt;

int main()
{
    in >> n;

    while (!v[0])
    {
        i = n;
        while (v[i] == 1)
        {
            v[i] = 0;
            i--;
        }

        v[i] = 1;

        if (i == 0)
            break;

        for (i = 1; i <= n; i++)
            if(v[i] == 1)
            out << i << "  ";
        out << '\n';
    }

    return 0;
}
