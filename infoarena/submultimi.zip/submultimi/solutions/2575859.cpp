#include <fstream>

using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int n,limita,i,j;
int main()
{
f>>n;
limita=1<<n;
for(i=1;i<limita;i++)
{
for(j=1;j<=n;j++)
if(i&(1<<j-1)) g<<j<<" ";

g<<'\n';
}

    return 0;
}
