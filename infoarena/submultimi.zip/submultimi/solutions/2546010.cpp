#include <bits/stdc++.h>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

const int nmax = 18;
int n, v[nmax], m;

void Back(int top)
{
    if(top == m + 1)
    {
        for(int i = 1; i <= m; ++i)
            fout << v[i] << " ";
        fout << "\n";
        return;
    }
    for(int i = 1 + v[top - 1]; i <= n - m + top; ++i)
    {
        v[top] = i;
        Back(top + 1);
    }
}
int main()
{
    fin >> n;
    for(m = 1; m <= n; ++m)
        Back(1);
    return 0;
}
