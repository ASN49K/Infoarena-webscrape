#include <stdio.h>
#include <stdlib.h>

int main() {
	FILE *in, *out;
	if (((in = fopen("submultimi.in", "rt")) == NULL)) {
		printf("Nu am putut deschide fisierul de input!");
		return -1;
	}
	if (((out = fopen("submultimi.out", "wt")) == NULL)) {
		printf("Nu am putut deschide fisierul de output!");
		return -2;
	}
	int i, j, n, k;
	fscanf(in, "%d", &n);
	for (i = 1 ; i <= n ; ++i) {
		for (j = 1 ; j <= n ; ++j) {
			for (k = i ; k <= j ; ++k) {
				fprintf(out, "%d ", k);
				if (k == j) {
					fprintf(out, "\n");
				}
			}
			
		}
	}
	// Freeing the memory
	fclose(in);
	fclose(out);
	return 0;
}
