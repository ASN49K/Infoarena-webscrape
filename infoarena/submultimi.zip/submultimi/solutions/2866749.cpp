#include <bits/stdc++.h>

using namespace std;

ifstream fin("hashuri.in");
ofstream fout("hashuri.out");
int n;
bitset <20> b;
int main()
{
    int i;
    fin >> n;
    while (b[0] == 0)
    {
        for (i = n; i >= 1 and b[i] == 1; i--)
            b[i] = 0;
        b[i] = 1;

        for (i = 1; i <= n; i++)
            if (b[i] == 1)
                fout << i << " ";
        fout << "\n";
    }


    return 0;
}