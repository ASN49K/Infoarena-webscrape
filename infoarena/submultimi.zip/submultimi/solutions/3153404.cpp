#include <bits/stdc++.h>

using namespace std;
ifstream fin( "submultimi.in" );
ofstream fout( "submultimi.out" );
int main()
{
    int n, i, j;
    fin >> n;
    for( i = 1; i < (1 << n); i++ ){
        for( j = 0; j < n; j++ ){
            if( i & (1 << j) )
                fout << j + 1 << ' ';
        }
        fout << '\n';
    }
    return 0;
}
