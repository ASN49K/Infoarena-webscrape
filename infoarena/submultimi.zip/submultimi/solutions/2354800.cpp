#import<fstream>
using namespace std;ifstream c("submultimi.in");ofstream t("submultimi.out");int l,i,j,n;int main(){c>>n,l=(1<<n);for(i=0;i<l;++i,t<<'\n')for(j=0;j<n;++j)if(i&(1<<j))t<<j+1<<' ';}
