#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int lenght;
int nums[17];

void name(int num){
    nums[nums[0] + 1] = num;
    ++nums[0];
    if(num == lenght){
        for(int i = 1; i <= nums[0]; ++i){
            fout << nums[i] << ' ';
        }
        fout << '\n';
        return;
    }
    for(int i = 1; i <= nums[0]; ++i){
        fout << nums[i] << ' ';
    }
    fout << '\n';
    for(int i = num + 1; i <= lenght; ++i){
        name(i);
        nums[nums[0]] = 0;
        --nums[0];
    }
    return;
}


int main(){
    fin >> lenght;
    for(int i = 1; i <= lenght; ++i){
        name(i);
        nums[nums[0]] = 0;
        --nums[0];
    }
}
