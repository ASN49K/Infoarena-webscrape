#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main() {
	int n;
	fin >> n;

	for(int mask = 0; mask < (1 << n); mask++) { // parcurg toate mastile posibile
		for(int i = 0; i < n; i++) { // parcurg bitii unei masti fixate
			if(mask & (1 << i)) { // daca bitul i este setat in masca
				fout << i + 1 << " "; // afisez i + 1 (bitii sunt indexati de la 0)
			}
		}
		fout << '\n';
	}
	return 0;
}