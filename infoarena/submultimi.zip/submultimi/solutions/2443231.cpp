#include <iostream>
#include <fstream>

using namespace std;

ifstream fi("submultimi.in");
ofstream fo("submultimi.out");

int n;
int a[17],v[17];
int ok;

int valid(int k)
{
    if(k<=n)
        return 1;

    return 0;
}

int sol(int k)
{
    return k==n;
}

void afis(int k)
{
    if(ok)
    {for(int i=1;i<=n;i++)
        if(v[i])
            fo<<a[i]<<" ";
        fo<<'\n';}
}

void bkt()
{
    int k=1;

    v[k]=-1;

    while(k>0)
        if(v[k]<1)
    {
        v[k]++;
        if(sol(k))
            {afis(k);
            ok=1;}
        else
        {
            k++;
            v[k]=-1;
        }
    }
        else
        k--;
}

int main()
{
    fi>>n;

    for(int i=1;i<=n;i++)
        a[i]=i;

    bkt();

    return 0;
}
