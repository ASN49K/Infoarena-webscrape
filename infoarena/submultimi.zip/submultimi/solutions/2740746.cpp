﻿#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <cstring>
using namespace std;
ifstream f("submultimi.in"); //bac1.txt
ofstream o("submultimi.out");
int n;
int sol[20];
int frec[20];


void bkt(int k, int poz)
{
	if (poz > 1)
	{
		for (size_t i = 1; i < poz; i++)
		{
			g << sol[i] << " \n"[i == poz - 1];
		}

	}
	for (size_t i = k; i <= n; i++)
	{
		if (frec[i] == 0)
		{
			frec[i] = 1;
			sol[poz] = i;
			bkt(k + 1, poz + 1);
			frec[i] = 0;
		}
	}

}

int main()
{
	f >> n;
	bkt(1, 1);

}


