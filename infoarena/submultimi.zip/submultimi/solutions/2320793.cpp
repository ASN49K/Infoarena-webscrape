#include <bits/stdc++.h>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n;
bitset<20> a;
void CitiRez()
{
    int i ;
    fin >> n;
    a[n] = 1;
    while(a[0] == 0)
    {
       for(i = 1; i <= n; i++)
         if(a[i] == 1) fout << i << " ";
                fout << "\n";
       for(i = n; a[i] == 1; i--)
             a[i] = 0;
       a[i] = 1;
    }
}
int main()
{
    CitiRez();
    return 0;
}
