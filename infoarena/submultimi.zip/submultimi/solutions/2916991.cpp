#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, subm[17];

void gen(int lgSubm, int element) {
    if (element == n + 1) {
        for (int i = 0; i < lgSubm; ++i) {
            fout << subm[i] << " ";
        }
        fout << "\n";
        return;
    }
    subm[lgSubm] = element;
    gen(lgSubm + 1, element + 1);
    gen(lgSubm, element + 1);
}

int main() {
    fin >> n;
    gen(0, 1);
    return 0;
}
