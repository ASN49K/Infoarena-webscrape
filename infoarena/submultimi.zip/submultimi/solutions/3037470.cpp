#include <bits/stdc++.h>
using namespace std;
int n;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main()
{
    fin >> n;
    for(int i = 1; i < (1<<n); i++){
        for(int j = 0; j < n; j++){
            if(i&(1<<j)){
                fout << j+1 << " ";
            }
        }
        fout << "\n";
    }
    return 0;
}
