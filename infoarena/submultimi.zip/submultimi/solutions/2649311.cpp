#include <bits/stdc++.h>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");


int v[30],n;

void backt(int k,int i)
{
	if(k==i+1)
	{
		for(int j=1;j<=i;j++)
			out<<v[j]<<" ";
		out<<"\n";
		return;
	}
	for(int j=1+v[k-1];j<=n-i+k;j++)
	{
		v[k]=j;
		backt(k+1,i);
	}
}


int main()
{
	in>>n;
	for(int i=1;i<=n;i++)
		backt(1,i);
}
