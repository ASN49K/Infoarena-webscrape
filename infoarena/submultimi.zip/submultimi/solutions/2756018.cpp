#include <fstream>

using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out")
int st[16],n;
void afisare(int n){

for(int i=1;i<=n;i++)
cout<<st[i]<<" ";
cout<<"\n";


}
void backtrack(int top){
afisare(top-1);
if(top<=n+1)

{


    for(int i=st[top-1]+1;i<=n;i++)
    {
        st[top]=i;
        backtrack(top+1);
    }
}


}
int main()
{

    cin>>n;
    backtrack(1);
    return 0;
}
