#include <fstream>
#include <queue>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
int subset[20], len;

void backtrack(int nr) {
    // am terminat de generat o submultime
    if (nr == n + 1) {
        if (len > 0) {
            for (int i = 1; i <= len; i++) {
                fout << subset[i] << " ";
            }
            fout << "\n";
        }
        return;
    }
    backtrack(nr + 1);
}

int main() {
    fin >> n;
    backtrack(1);
}

