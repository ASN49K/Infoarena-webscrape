#include <fstream>

using namespace std;

ifstream cin ("submultimi.in") ;
ofstream cout ("submultimi.out") ;

int n, x[21] ;

bool valid (int k)
{

    for (int i = 1 ; i < k ; i ++)
        if (x[i] == x[k] || x[i] > x[k])
            return 0 ;

    return 1 ;

}

void afisare(int k)
{

    for (int i = 1 ; i <= k ; i ++)
        cout << x[i] << ' ' ;

}

void backtracking (int k)
{

    for (int i = 1 ; i <= n ; i ++)
    {

        x[k] = i ;

        if (valid (k))
        {

            afisare(k) ;
            cout << '\n' ;
            backtracking(k + 1) ;

        }

    }

}

int main()
{

    cin >> n ;

    backtracking(1) ;

    return 0;
}
