#include <iostream>
using namespace std;
int main()
{
	int n, estePrim = 1;
	cin >> n;
	if (n <= 1)
		estePrim = 0;
	else
	{
		for (int i = 2; i * i <= n; i++)
		{
			if (n % i == 0)
			{
				estePrim = 0;
				break;
			}
		}
	}
	if (estePrim == 1)
		cout << "DA";
	else
		cout << "NU";
    return 0;
}
