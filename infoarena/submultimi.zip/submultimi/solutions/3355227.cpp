#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

void printSol(vector<int>& sol) {
	for (int i = 0; i < sol.size(); i++)
		fout << sol[i] << " ";
	fout << '\n';
}

void bt(int start, int n, vector<int>& sol) {
	if (sol.size() != 0) {
		printSol(sol);
	}

	for (int i = start + 1; i <= n; i++) {
		sol.push_back(i);
		bt(i, n, sol);
		sol.pop_back();
	}
}

int main() {
	int n;
	fin >> n;
	vector<int> sol;
	bt(0, n, sol);
}