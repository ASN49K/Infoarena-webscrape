#include <fstream>
using namespace std;
ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");
int n,x[11],m;
void comb(int k)
{
    int i;
    if(k==m+1)
    {
        for(i=1;i<=m;i++)
            fout<<x[i]<<' ';
        fout<<'\n';
    }
    else
        for(i=x[k-1]+1;i<=n-m+k;i++)
        {
            x[k]=i;
            comb(k+1);
        }
}
int main()
{
    fin>>n;
    for(m=1;m<=n;m++)
        comb(1);
    return 0;
}
