#include    <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

#define ARRAY_MAX 100005

int N;
int arr[ARRAY_MAX];
bool check[ARRAY_MAX];

void backTrack(int start, int N, int K) {
    if (start - 1 == K) {
        for (int i = 1; i <= K; i++)
            fout << arr[i] << " ";

        fout << "\n";
    }

    else {
        for (int i = 1; i <= N; i++) {
            if (!check[i] && arr[start - 1] < i) {
                arr[start] = i;

                check[i] = true;

                backTrack(start + 1, N, K);

                check[i] = false;
            }
        }
    }
}

int main() {
    fin >> N;

    for (int K = 1; K <= N; K++)
        backTrack(1, N, K);
}
