#include <fstream>
const std::string programName = "submultimi";
std::ifstream f(programName + ".in");
std::ofstream g(programName + ".out");
int main() {
    int N;
    f >> N;
    for(int i = 1; i < (1 << N); ++i) {
        for (int j = 1; j <= N; ++j)
            if ((i & (1 << (j - 1))) > 0)
                g << j << ' ';
        g << "\n";
    }
    return 0x0;
}
