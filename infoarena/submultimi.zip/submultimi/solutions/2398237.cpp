#include<iostream>
#include<fstream>
using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");
bool used[20];
int result[20];
void subarrays(int a,int index)
{
    if(index)
    {
        for(int i=0; i<index; i++)
        {
            out<<result[i]<<" ";
        }
        out<<endl;


    }
    for(int i=1; i<=a; i++)
    {
        if(!used[i])
        {
            used[i]=true;
            result[index]=i;
            if(index==0 || result[index-1]<i)
                subarrays(a,index+1);
            used[i]=false;
        }
    }
}
int main()
{

    int n;
    in>>n;
    subarrays(n,0);





}
