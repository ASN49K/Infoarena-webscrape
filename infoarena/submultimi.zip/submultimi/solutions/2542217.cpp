using namespace std;



#define fisier "submultimi"

#ifdef fisier
    #include <fstream>
    ifstream in(fisier ".in");
    ofstream out(fisier ".out");
#else
    #include <iostream>
    #define in cin
    #define out cout
#endif



bool x[16];
int pas, n, luate;



void print() {for (int i = 0; i < n; i++) if (x[i]) out << i + 1 << ' '; out << '\n';}



void backtrack() {

    pas++;

    if (pas == n) {

        print();

    } else {

        x[pas] = true;

        luate++;

        backtrack();

        luate--;

        x[pas] = false;

        if (pas != n - 1 || luate) {

            backtrack();

        }

    }

    pas--;

}



int main() {

    in >> n;

    pas = -1;

    backtrack();

}











//
