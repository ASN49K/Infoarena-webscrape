#include<iostream>
#include<fstream>
using namespace std;
ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");
int n,a[20];
bool verificare( int k)
 {
   for( int j=1;j<k;j++)
     if( a[j]==a[j+1])
        return false ;
     else if( a[j]>a[j+1])
        return false;
   return true;
 }
void afisare ( int l)
{
  for( int i=1;i<=l;i++)
    fout<<a[i]<<" ";
  fout<<endl;
}
void combinari(int k)
{
    for (int i=k ;i<=n;i++)
     {
          a[k]=i;
         if( verificare(k))
         afisare(k);

       combinari(k+1);
     }
}
int main()
{
  fin>>n;
  combinari(1);
}
