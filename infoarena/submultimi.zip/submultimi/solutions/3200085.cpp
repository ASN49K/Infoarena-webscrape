#include<iostream>
#include<vector>
#include<fstream>
#define FIN "submultimi.in"
#define FOUT "submultimi.out"
using namespace std;

vector<int> stiva;

int main()
{
	freopen(FIN, "r", stdin);
	freopen(FOUT, "w", stdout);
	int n ;
	cin>>n;
	//cout<<"Generare submultimi: \n";
	stiva.push_back(1);
	while( !stiva.empty() ) {
	
		for(unsigned int i = 0; i<stiva.size(); ++i)
			cout<<stiva[i]<<" ";
		cout<<"\n";
		if( stiva.back() < n ) 
			stiva.push_back( stiva.back() + 1 );
		else {
			stiva.pop_back();
			if( !stiva.empty() )
				stiva.back()++;
		}
//		display();
	}
}