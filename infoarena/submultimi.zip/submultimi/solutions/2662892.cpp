#include <fstream>
using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");
int n,r[20];
bool v[20];
void bck(int p,int poz)
{
    if(poz>1)
    {
        for(int i=1;i<poz;++i)
            out<<r[i]<<' ';
        out<<'\n';
    }
    for(int i=p;i<=n;++i)
    {
        if(v[i]==false)
        {
            v[i]=true;
            r[poz]=i;
            bck(i+1,poz+1);
            v[i]=false;
        }
    }
    return;
}
int main()
{
    in>>n;
    bck(1,1);
    return 0;
}
