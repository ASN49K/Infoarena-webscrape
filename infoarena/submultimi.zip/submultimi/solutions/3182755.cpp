#include <fstream>
#include <vector>
using namespace std;
vector<int> vector_bkt;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
void bkt(int pas, int n){
    if (pas > n){
        if (vector_bkt.size() > 0) {
            for (int i: vector_bkt)
                fout << i << " ";
            fout << '\n';
        }
        return;
    }
    bkt(pas + 1, n);
    vector_bkt.push_back(pas);
    bkt(pas + 1, n);
    vector_bkt.pop_back();
}
int main(){
    int n;
    fin >> n;
    bkt(1, n);
    return 0;
}