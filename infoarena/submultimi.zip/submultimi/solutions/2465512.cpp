#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

const int NMAX = 16;
int N, st[NMAX + 5];

void GetSol(int p)
{
    for(int i = 1; i <= p; i++)
        fout << st[i] << ' ';
    fout << '\n';
}

void bk(int level, int from)
{
    for(int i = from; i <= N; i++)
    {
        st[level] = i;
        GetSol(level);

        if(level != N)
            bk(level + 1, i + 1);
    }
}

int main()
{
    fin >> N;

    bk(1, 1);

    return 0;
}
