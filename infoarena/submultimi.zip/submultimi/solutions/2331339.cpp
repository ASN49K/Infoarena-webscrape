#include <fstream>
#include <cmath>

using namespace std;
ifstream f("sprim.in");
ofstream g("sprim.out");
int n,v[100001],stop[100001],dif,nr;
int coprim(int x,int y)
{
    while(x!=y)
    {
        if(x>y)
            x-=y;
        else y-=x;
    }
    if(x==1) return 1;
    return 0;
}
int main()
{   int i,j;
    f>>n;
    for(i=1;i<=n;i++)
        f>>v[i];
    for(i=1;i<n;i++)
        for(j=i+1;j<=n;j++)
            {
                if(!coprim(v[i],v[j]))
                    {
                        stop[i]=j;
                        break;
                    }
                stop[i]=n+1;
            }
    for(i=1;i<n;i++)
        for(j=i+1;j<stop[i]&&j<n;j++)
            if(stop[j]<stop[i]) stop[i]=stop[j];
    for(i=1;i<n;i++)
        if(stop[i]!=0)
            {dif=stop[i]-i;
            if(dif>1)
                {
                    nr+=(dif-1);
                }
            }
    g<<nr;
    return 0;
}
