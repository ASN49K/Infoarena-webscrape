#include<fstream>
std::ifstream fin("submultimi.in");
std::ofstream fout("submultimi.out");
int sol[20];
bool f[20];
int n;
void display(int cnt)
{
    for(int i=0; i<=cnt; ++i)
        fout<<sol[i]<<' ';
    fout<<'\n';
}
void back(int k)
{
    if(k==n)
        return;
    for(int i=(k==0)?1:sol[k-1]+1; i<=n; ++i)
        if(!f[i])
        {
            f[i]=true;
            sol[k]=i;
            display(k);
            back(k+1);
            f[i]=false;
        }
}
int main()
{
    fin>>n;
    back(0);
    return 0;
}