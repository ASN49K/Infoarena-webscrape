#include <iostream>
#include <fstream>
using namespace std;
 ifstream in("submultimi.in");
 ofstream out("submultimi.out");

int main(){
    long long int  a, b = 2, i, c = 0, variabila, numar = 1, x;
    long long int v[100000];
    in>>a;
    for(i = 1; i <= a; i++)
        v[i] = i;
    for(i = 2; i <= a; i++)
        b *= 2;
    for(i = 1; i < b; i++){
        variabila = i;
        while(numar <= a){
            if(variabila % 2 == 0)
               c = 3 + 10 * c;
            else
                c = 1 + 10 * c;
            variabila /= 2;
            numar++;
        }
        x = a;
        while(x >= 1){
            if(c % 10 == 1)
                out<<v[x]<<" ";
            x--;
            c /= 10;
        }
        out<<'\n';
        numar = 1;
        c = 0;
    }
    return 0;
}
