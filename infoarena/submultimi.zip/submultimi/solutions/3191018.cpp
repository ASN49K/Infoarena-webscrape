#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

vector<int> V;

void afisare(){

    for(int i = 0; i < V.size(); i++){
        fout<<V[i]<<" ";
    }
    fout<<"\n";

}

void bkt(int pas, int n){

    if(pas > n){
        afisare();
        return;
    }

    bkt(pas + 1, n);

    V.push_back(pas);

    bkt(pas + 1, n);
    V.pop_back();

}

int main()
{
    int n;
    fin>>n;

    bkt(1, n);

    return 0;
}
