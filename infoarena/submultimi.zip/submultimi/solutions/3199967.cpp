#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");
int sol[25], n;
void afisare()
{
    bool displayed=false;
    for (int i=1; i<=n; i++) {
        if (sol[i]==1) {
            fout<<i<<' ';
            displayed=true;
        }
    }
    if (displayed) fout<<'\n';
}
void backtrack (int k, bool state)
{
    sol[k]=state;
    if (n==k) {
        afisare();
    }
    else {
        backtrack(k+1, 0);
        backtrack(k+1, 1);
    }
}
int main()
{
    fin>>n;
    backtrack(1, 1);
    backtrack(1, 0);
    return 0;
}
