#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int sol[20], n, i;

void backt(int poz)
{
    if(poz>i)
    {
        for(int j=1;j<=i;j++)
            fout<<sol[j]<<" ";
        fout<<"\n";
        return;
    }
    for(int j=sol[poz-1]+1;j<=n;j++)
        {
            sol[poz]=j;
            backt(poz+1);
        }

}

int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        backt(1);
    return 0;
}
