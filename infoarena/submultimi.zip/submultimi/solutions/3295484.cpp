#include<fstream>
using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
int main()
{
    int n;
    cin>>n;
    for(int i=(1<<n)-1;i;cout<<'\n',--i)
        for(int j=0;j<n;++j)
            if((i>>j)&1)
                cout<<j+1<<' ';
    return 0;
}
