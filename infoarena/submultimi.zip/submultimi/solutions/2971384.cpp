#include <fstream>
#include <iostream>
#include <vector>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int main()
{
    vector<int> v;
    int n;
    for (int i = 1; i <= n; ++i) {
        v.push_back(i);
    }
    fin >> n;
    for (int i = 1; i <= (1 << n); ++i) {
        for (int j = 0; j < n; ++j) {
            if (i & (1 << j)) {
                fout << v[j] << " ";
            }
        }
        f
        fout << "\n";
    }
    return 0;
}
