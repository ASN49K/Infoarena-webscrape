#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main()
{
    int n,var=0,bit;
    fin>>n;
    for(var=0;var<=(1<<n);var++)
    {
        for(bit=1;bit<=n;bit++)
            if(var & (1<<(bit-1)))
                fout<<bit<<" ";
        fout<<'\n';
    }

    return 0;
}
