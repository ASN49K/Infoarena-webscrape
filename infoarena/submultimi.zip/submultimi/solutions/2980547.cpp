#include <bits/stdc++.h>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int a[25],n;
/**
n=7
{1, 2, 3, 4, 5, 6, 7}
 0  0  1  0  1  1  0

   0 1 2 3 4 5 6 7
a= 0 0 0 0 0 0 0 0
   0 0 0 0 0 0 0 1
   0 0 0 0 0 0 1 0
   0 0 0 0 0 0 1 1
   0 0 0 0 0 1 0 0
 ...
   0 1 1 1 1 1 1 1
   1 0 0 0 0 0 0 0
*/
int main()
{
    int i,s=0;
    fin>>n;
    a[n]=1;
    while(a[0]==0)
    {
        ///afisam submultimea:
        for(i=1; i<=n; i++)
            if(a[i]==1) fout<<i<<" ";
        fout<<"\n";
        ///generez urmatorul sir binar:
        for(i=n; a[i]==1; i--)
            a[i]=0;
        a[i]++;
    }
    fout.close();
    return 0;
}
