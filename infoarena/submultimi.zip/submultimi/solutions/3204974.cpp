#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");


int main()
{
    int n;
    int el;
    cin>>n;
    int po=(1<<n)-1;
    for(el=1;el<=po;el++)
    {
        int k=0;
        while(1<<k<=el)
        {
            if((el&(1<<k))!=0)
                cout<<k+1<<" ";
            k++;
        }
        cout<<'\n';
    }
    return 0;
}
