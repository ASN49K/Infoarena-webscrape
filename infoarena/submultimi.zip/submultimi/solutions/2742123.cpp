#include <fstream>
using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int n,x[17];
void afis()
{   int s=0;
    for(int i=1;i<=n;i++) s+=x[i];
    if(s)
    {   for(int i=1;i<=n;i++)
            if(x[i]==1) g<<i<<' ';
        g<<'\n';
    }
}
void back()
{   int k=1;
    x[k]=-1;
    do
    {   while(x[k]<1)
        {   x[k]++;
            if(k==n) afis();
                else {k++; x[k]=-1;}
        }
        k--;
    }
    while(k);
}
int main()
{   f>>n;
    back();
    return 0;
}
