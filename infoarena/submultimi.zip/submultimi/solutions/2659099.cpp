#include <fstream>
#include <iostream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int sol[20];
int n;

void afisare(int limita)
{
    for(int i = 0; i < limita; i++)
        fout << sol[i] << ' ';
    fout << '\n';
}

int valid(int k)
{
    for(int i = 0 ; i <= k - 1; i++)
        if(sol[i] >= sol[k])
            return 0;
    return 1;
}

void backtracking(int k, int limita)
{
    for(int i = 0 ; i < n; i++)
    {
        sol[k] = i+1;
        if(valid(k))
        {
            if(k == limita - 1)
            {
                afisare(limita);
            }
            else backtracking(k+1, limita);
        }
    }
}

int main()
{
    fin >> n;
    for(int i = 1 ; i <= n; i++)
        backtracking(0,i);
    return 0;
}
