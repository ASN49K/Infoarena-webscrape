#include <iostream>

FILE * fin= fopen("submultimi.in","r");
FILE * fout=fopen("submultimi.out","w");

int n;
int v[20];
int pos=1;

void write()
{
  for(int i=0;i<pos;i++)
    fprintf(fout,"%d ",v[i]);
  fprintf(fout,"\n");
}

int main()
{
  fscanf(fin,"%d",&n);
  v[0]=1;
  write();
  while(v[0]!=n)
  {
    while(pos!=n)
    {
      if(v[pos-1]+1>n)break;
      v[pos]=v[pos-1]+1;
      pos++;
      write();
    }
    while(pos-1>=0 && v[pos-1]+1>n)
      pos--;
    if(pos-1<0) break;
    v[pos-1]++;
    write();
  }
}
