#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

void back(int n, vector<int> &v, int k) {
	for(int i=0; i<=1; i++) {
		v[k]=i;
		if(k==n) {
			for(int j=1; j<=n; j++) {
				if(v[j]==1) {
					fout << j << ' ';
				}
			}
			fout << '\n';
		}
		else {
			back(n, v, k+1);
		}
	}
}

int main() {
 	int n;
 	fin >> n;
 	vector<int> v(n+1);
   back(n, v, 1);
	return 0;
}