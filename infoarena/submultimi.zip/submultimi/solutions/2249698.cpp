#include <fstream>
using namespace std;
short int n, i, j;

int main () {
    ifstream fin ("submultimi.in");
    ofstream fout ("submultimi.out");
    fin>>n;
    for (i=1;i<=(1<<n)-1;i++) {
        for (j=0;j<=15;j++) {
            if (((i>>j)&1)==1)
                fout<<j+1<<" ";
        }
        fout<<"\n";
    }



    return 0;
}
