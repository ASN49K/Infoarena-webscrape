#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

const int NMAX = 20;

void print(int st[NMAX], int k)
{
    for(int i = 1; i <= k; i++)
        fout << st[i] << ' ';
    fout << '\n';
}

void combinari(int n, int p)
{
    int stiva[NMAX] = {0};
    int k = 1;
    stiva[k] = 0;
    while(k)
        if(stiva[k] < n)
        {
            stiva[k]++;
            if(k == p)
                print(stiva, k);
            else
            {
                k++;
                stiva[k] = stiva[k - 1];
            }
        }
        else
            k--;
}

void submultimi(int nr)
{
    for(int i = 1; i <= nr; i++)
        combinari(nr, i);
}

int main()
{
    int nr; fin >> nr;
    submultimi(nr);
    return 0;
}
