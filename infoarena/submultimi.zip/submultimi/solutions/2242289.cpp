#include <bits/stdc++.h>
#define Hack cin.sync_with_stdio(0); cin.tie(NULL); cout.tie(NULL)
#define pb push_back
#define mp make_pair
#define fi first
#define se second

using namespace std;

typedef long long ll;
typedef pair <int, int> pii;
typedef pair <ll, ll> pll;
typedef vector <int> vi;
typedef vector <pii> vii;
typedef vector <ll> vl;
typedef vector <pll> vll;
typedef queue <int> qi;
typedef queue <pii> qii;
typedef queue <ll> ql;
typedef queue <pll> qll;

const int INF = 0x3f3f3f3f;
const int MOD = 666013;
const int NMAX = 20 + 5;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
int v[NMAX];

bool ok(int poz)
{
    return 1;
}

void write(int poz)
{
    for (int i = 1; i <= poz; ++i)
        fout << v[i] << ' ';
    fout << '\n';
}

void backtr(int poz, int last)
{
    for (int i = last + 1; i <= n; ++i)
    {
        v[poz] = i;
        if (ok(poz))
        {
            write(poz);
            if (poz < n) backtr(poz + 1, i);
        }
    }
}

int main()
{
    Hack;
    fin >> n;
    backtr(1, 0);

    return 0;
}
