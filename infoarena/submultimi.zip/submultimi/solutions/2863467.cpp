#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair
#define dbg(x) cout << #x <<": " << x << "\n";
using ll = long long;

const string myf = "submultimi";
ifstream fin(myf + ".in");
ofstream fout(myf + ".out");

int n;

int main() {

	int mx;
	fin >> n;
	mx = (1 << n);

	for (int i = 1; i <= mx; ++i) {
		for (int j = 1; j <= n; ++j)
			if ((i >> (j - 1)) & 1)
				fout << j << " ";
		fout << '\n';
	}



	fin.close();
	fout.close();
	return 0;
}