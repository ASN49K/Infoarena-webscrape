#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

vector<int>subm;

void afis_subm(){
    for(int i=0;i<subm.size();i++){
        fout<<subm[i]<<" ";
    }
    fout<<'\n';
}

void bkt(int nr_crnt, int n){
    if(nr_crnt>n){
        afis_subm();
        return;
    }
    subm.push_back(nr_crnt);
    bkt(nr_crnt+1,n);
    subm.pop_back();// scoate nr_crnt
    bkt(nr_crnt+1,n);
}

int main()
{
    int n;
    fin>>n;
    bkt(1,n);

    return 0;
}
