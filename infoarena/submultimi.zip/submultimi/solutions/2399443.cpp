#include <iostream>
#include <fstream>

using namespace std;

int n, k, v[30];

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

void gback(int nivel)
{
    int i;
    for(i=v[nivel-1]+1;i<=n;i++)
    {
        v[nivel]=i;
        for(int j=1;j<=nivel;j++)
            cout<<v[j]<<" ";
        cout<<"\n";
        if(nivel<n)
            gback(nivel+1);
    }
}

int main()
{
    cin>>n;
    gback(1);
    return 0;
}
