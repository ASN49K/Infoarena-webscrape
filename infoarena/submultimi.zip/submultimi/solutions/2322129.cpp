#include <bits/stdc++.h>
using namespace std;
ifstream f("arbint.in");
ofstream g("arbint.out");
int v[400005], maxx, n, m, i, c, a, b;
void read(int nod, int st, int dr)
{
    if(st == dr)f >> v[nod];
    else
    {
        int mij = (st + dr) / 2;
        read(2 * nod, st, mij);
        read(2 * nod + 1, mij + 1, dr);
        v[nod] = max(v[2 * nod], v[2 * nod + 1]);
    }
}
void query(int nod, int st, int dr, int a, int b)
{
    if(a <= st && dr <= b)maxx = max(maxx, v[nod]);
    else
    {
        int mij = (st + dr) / 2;
        if(a <= mij)query(2 * nod, st, mij, a, b);
        if(mij + 1 <= b)query(2 * nod + 1, mij + 1, dr, a, b);
    }
}
void update(int nod, int st, int dr, int a, int b)
{
    if(st == dr)v[nod] = b;
    else
    {
        int mij = (st + dr) / 2;
        if(st <= a && a <= mij)update(2 * nod, st, mij, a, b);
        if(mij + 1 <= a && a <= dr)update(2 * nod + 1, mij + 1, dr, a, b);
        v[nod] = max(v[2 * nod], v[2 * nod + 1]);
    }
}
int main()
{
    f >> n >> m;
    read(1, 1, n);
    for(i = 1; i <= m; i ++)
    {
        f >> c >> a >> b;
        if(c == 0)
        {
            maxx = 0;
            query(1, 1, n, a, b);
            g << maxx << "\n";
        }
        else update(1, 1, n, a, b);
    }
    return 0;
}
