#include <bits/stdc++.h>

using namespace std;
ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");
int n,v[20];

void afis(int k){
    int ok=1;
    for(int i=1;i<=k;i++) if(v[i]) ok=0;
    if(!ok)
    {
        for(int i=1 ; i <= k ; ++i)
        if(v[i] == 1)
            fout << i << " ";
    fout << endl;
    }

}

void backk(int k){
    for(int i = 0; i <= 1 ; ++i)
    {
        v[k]=i;
        if(k == n)
            afis(k);
        else
            backk(k+1);
    }
}

int main()
{
    fin>>n;
    backk(1);
    return 0;
}
