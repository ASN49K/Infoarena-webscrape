#include<fstream>
using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
int n,x;
int main()
{
    cin>>n;
    int x=1<<n;
    for(int i=1; i<=x; i++)
    {
        for(int j=0; j<n; j++)
            if(i&(1<<j))
                cout<<j+1<<' ';
        cout<<'\n';
    }
}
