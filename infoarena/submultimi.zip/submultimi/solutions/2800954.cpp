#include <bits/stdc++.h>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int v[17], n, top=0;

bool Valid(int nr)
{
  if(nr==1) return true;
  return v[nr]>v[nr-1];
}

void Afisare(int nr)
{
  for(int i=1;i<=nr;i++) fout<<v[i]<<' ';
  cout<<'\n';
}

void Back(int nr)
{
  for(int i=1;i<=n;i++)
  {
    v[nr]=i;
    if(Valid(nr))
    {
      Afisare(nr);
      Back(nr+1);
    }
  }
}

int main()
{
  fin>>n;
  Back(1);
  return 0;
}
