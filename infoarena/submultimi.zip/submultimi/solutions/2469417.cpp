#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n,nr,poz,x;
int main()
{
    fin>>n;
    nr=(1<<n)-1;
    for(int i=1;i<=nr;i++)
    {
        x=i;
        poz=0;
        while(x!=0)
        {
            poz++;
            if((x&1)==1)
            {
                fout<<poz<<" ";
            }
            x=(x>>1);
        }
        fout<<'\n';
    }
    return 0;
}
