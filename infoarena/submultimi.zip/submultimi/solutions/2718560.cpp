#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

const int NMax = 16;

int n;
int st[NMax + 5];

void Read(){
    fin >> n;
}

void Print(int length){
    for (int i = 1; i <= length; i++)
        fout << st[i] << ' ';
    fout << '\n';
}

void Backtracking(int level){
    for (int i = st[level - 1] + 1; i <= n; i++){
        st[level] = i;
        Print(level);
        Backtracking(level + 1);
    }
}

int main(){
    Read();
    Backtracking(1);
    return 0;
}
