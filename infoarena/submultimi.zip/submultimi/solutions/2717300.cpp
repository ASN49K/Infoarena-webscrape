#include <iostream>
#include <fstream>
using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n, v[18];

void afisare(int lg) {
    for(int i = 1; i <= lg; ++i)
        g << v[i] << " ";
    g << "\n";
}

void bkt(int lg) {
    for(int i = v[lg - 1] + 1; i <= n; ++i) {
        v[lg] = i;
        afisare(lg);
        if(lg < n)
            bkt(lg + 1);
    }
}


int main()
{
    f >> n;
    bkt(1);
}
