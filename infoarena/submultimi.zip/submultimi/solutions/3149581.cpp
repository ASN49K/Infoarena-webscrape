#include <fstream>
using namespace std;
int v[20], n, i;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
int main()
{   cin >> n;
    for(i = 0; i <= n; ++i) v[i] = 0;
    while(!v[0]){
    i = n;
    while(v[i] == 1){
    v[i] = 0;
    --i;
                    }
    v[i] = 1;
    if(i == 0) break;
    for(i = 1; i <= n; ++i)
            if(v[i]) cout << i << " ";
    cout << '\n';
                }
    return 0;
}
