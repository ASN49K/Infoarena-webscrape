#include <iostream>
#include <fstream>

using namespace std;

bool este_in_sub(int numar,int poz){
if( (numar>>(poz-1))&1 )return true;
  return false;
}


int main()
{
ifstream in("submultimi.in");
ofstream out("submultimi.out");
int nr;
in>>nr;
for(int i=1;i<(1<<nr);i++){

    for(int i2=1;i2<=nr;i2++){
        if(este_in_sub(i,i2))out<<i2<<' ';

    }
    out<<'\n';

}


in.close();
out.close();
    return 0;
}
