#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
constexpr int NX {17};
int a[NX], n;

void afisare(int k)
{
    for(int i=1; i<=k; ++i)
    fout<<a[i]<<" ";
    fout<<"\n";
}
void bec(int k)
{
    for(int i=a[k-1]+1; i<=n; ++i)
    {
        a[k]=i;
        afisare(k);
        bec(k+1);
    }
}
int main()
{
    fin>>n;
    bec(1);
    return 0;
}

