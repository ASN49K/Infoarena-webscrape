#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
void bkt(int n, int pos,vector<int>& current) {
    if (pos > n) {
        if (!current.empty()) {
            for (int x : current) {
                fout << x << " ";
            }
            fout << "\n";
        }
        return;
    }
    bkt(n, pos + 1, current);
    current.push_back(pos);
    bkt(n, pos + 1, current);
    current.pop_back();
}
int main(){
    ifstream fin("submultimi.in");
    int n;
    fin >> n;
    fin.close();

   vector<int> current;
    bkt(n, 1, current);

    fout.close();
    return 0;

}

