#include <bits/stdc++.h>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n, x[20];
bool v[20];

void afis(int k)
{
    for(int i = 1; i <= k; i++)
        g << x[i] << " ";
    g << "\n";
}

void bkt(int k)
{
    for(int i = x[i - 1] + 1; i <= n; i++)
    {
        x[k] = i;
        afis(k);
        if(k < n)
            bkt(k + 1);
    }
}

int main()
{
    f >> n;
    bkt(1);

    return 0;
}
