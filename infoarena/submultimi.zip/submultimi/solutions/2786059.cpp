#include <fstream>
#include <vector>
#include <cmath>
#include <iostream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

void subsets(int n)
{
    for (int mask = 1; mask < (1 << n); ++mask)
    {
        for (int j = 1, exp = 1; j <= mask; j <<= 1, ++exp)
        {
            if (j & mask)
            {
                fout << exp << " ";
            }
        }
        fout << "\n";
    }
}

int n;
int main()
{
    fin >> n;
    subsets(n);
    return 0;
}
