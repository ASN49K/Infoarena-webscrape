#include <iostream>
#include <cstdio>
#include <algorithm>
#include <vector>
#include <map>
#include <bitset>
#define nl '\n'
using namespace std;
int main(){
    int n;
    bitset<16> b;
    freopen("submultimi.in","r",stdin);
    freopen("submultimi.out","w",stdout);
    ios_base::sync_with_stdio(false);
    cin >> n;
    for(int i=0;i<=(1<<n)-1;++i){
        b = i;
        bool ok = 0;
        for(int j=0;j<n;++j){
            if(b[j]) {cout << j+1 << ' ';ok = 1;}
        }
        if(ok) cout << nl;
    }
}