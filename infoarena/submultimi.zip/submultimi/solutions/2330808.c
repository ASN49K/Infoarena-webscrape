#include <stdio.h>
#include <stdlib.h>

int submultimi(int n, int start, int limit, FILE* out) {
	int i;
	if (limit > n) {
		return 0;
	}
	for (i = start ; i <= limit ; ++i) {
		fprintf(out, "%d ", i);
		if (i == limit && start != n) {
			fprintf(out, "\n");
			submultimi(n , start, limit + 1, out);
		}
	}
	return 0;
}

int execute_until (int n, FILE* out) {
	int i;
	for (i = 1 ; i <= n ; ++i) {
		submultimi(n, i, i, out);
	}
	return 0;
}

int main() {
	FILE *in, *out;
	if (((in = fopen("submultimi.in", "rt")) == NULL)) {
		printf("Nu am putut deschide fisierul de input!");
		return -1;
	}
	if (((out = fopen("submultimi.out", "wt")) == NULL)) {
		printf("Nu am putut deschide fisierul de output!");
		return -2;
	}
	int n;
	fscanf(in, "%d", &n);
	execute_until(n, out);
	// Freeing the memory
	fclose(in);
	fclose(out);
	return 0;
}
