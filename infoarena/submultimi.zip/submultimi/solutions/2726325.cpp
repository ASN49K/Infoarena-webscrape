#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
vector <int> stk;


bool bitMaskVer(int bitMask)
{
    for (int i = 0; i <= n - 1; i++)
    {
        if (bitMask & (1 << i))
        {
            fout << i + 1 << ' ';
        }
    }
    fout << '\n';

}


void s()
{
    for (int i = 1; i < (1 << n); i++)
    {
        bitMaskVer(i);
    }
}



/*void backTracking(int step)
{
    if (step > n )
    {
        for (auto i : stk)
        {
            fout << i << ' ';
        }
        if (!stk.empty())
            fout << '\n';
        return;
    }

    backTracking(step + 1);

    stk.push_back(step);
    backTracking(step + 1);

    stk.pop_back();
}*/


int main()
{

    fin >> n;
    //backTracking(1);
    s();
    return 0;
}
