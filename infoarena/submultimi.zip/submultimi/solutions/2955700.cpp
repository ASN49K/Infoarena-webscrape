#include <iostream>

using namespace std;

int n, subm[25], sir[100000], poz = 0;
bool adv = true;

void gen(int element, int lgSubm) {
    if(element > n) {
        return;
    }
    if(poz > lgSubm && sir[lgSubm - 1] == subm[lgSubm - 1]) {
            //cout << "sir[lgSubm - 1] = " << sir[lgSubm - 1] << endl;
          //  cout << "subm[lgSubm - 1] = " << subm[lgSubm - 1] << endl;
        adv = false;
    }
    else if(poz <= lgSubm && sir[lgSubm - 1] != subm[lgSubm - 1]){
          // cout << "sir[lgSubm - 1] = " << sir[lgSubm - 1] << endl;
          //  cout << "subm[lgSubm - 1] = " << subm[lgSubm - 1] << endl;
        adv = true;
    }
    poz = 0;
  //  cout << "adv =  " << adv << endl;
    if(adv == true) {
    for (int i = 0; i < lgSubm; ++i) {
      cout << subm[i] << ' ';
      sir[poz] = subm[i];
      poz++;
    }
    cout << "\n";
    }
  subm[lgSubm] = element;
  gen(element + 1, lgSubm + 1);
  gen(element + 1, lgSubm);
}


int main()
{
    cin >> n;
    n = n + 1;
    gen(1, 0);
    return 0;
}
