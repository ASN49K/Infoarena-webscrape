#include <bits/stdc++.h>

using namespace std;

int main() {

	ifstream in("submultimi.in");
	ofstream out("submultimi.out");

	int n;
	in >> n;

	vector<int> v;
	vector<bool> used(n + 1);
 	function<void(int, int)> bkt = [&](int p, int k) {
		if(p == k + 1) {
			for(auto i : v) { out << i << ' '; }
			out << '\n';
			return;
		}
		for(int i = (v.empty() ? 1 : v.back()); i <= n; i++) {
			if(used[i]) { continue; }
			used[i] = true;
			v.push_back(i);
			bkt(p + 1, k);
			v.pop_back();
			used[i] = false;
		}
	};

	for(int i = 1; i <= n; i++) {
		bkt(1, i);
	}

	return 0;
}