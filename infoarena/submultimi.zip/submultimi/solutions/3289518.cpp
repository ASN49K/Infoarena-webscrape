#pragma GCC optimize("Ofast,no-stack-protector,unroll-loops,fast-math")
#include <bits/stdc++.h>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

#define cin fin
#define cout fout

int n;
vector<vector<int>> a;
signed main(){
    ios_base::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);

    cin >> n;
    a.resize((1 << n));

    for (int i = 1; i <= (1 << n); ++i) {
        int p = 1, cnt = 1;

        while (p <= i) {
            if (i & p) {
                a[i - 1].push_back(cnt);
            }

            p <<= 1;
            cnt++;
        }
    }

    sort(begin(a), end(a));

    for (int i = 1; i < (1 << n); ++i) {
        for (auto &x : a[i - 1]) {
            cout << x << ' ';
        }

        cout << '\n';
    }
}
