#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ofstream out ( "submultimi.out" );

vector <int> sol;
vector <bool> viz(20, 0);
int n;

void afis() {
  for ( auto x : sol )
    out << x << " ";
 out << "\n";
}

void bkt( int k ){
  if ( k == n + 1 )
    return;
  for (int i = k; i <= n; i++ ){
    sol.push_back ( i );
    afis();
    bkt ( i + 1 );
    sol.erase ( sol.end() - sizeof(int) );
  }
}

int main(){

  ifstream in ("submultimi.in");
  in >> n;
  in.close();

  bkt ( 1 );

  out.close();

  return 0;
}
