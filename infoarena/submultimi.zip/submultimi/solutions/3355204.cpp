#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

vector<int> submultimi;
bool vizitat[17] = {false};
FILE *fin = fopen("submultimi.in", "r");
FILE *fout = fopen("submultimi.out", "w");

void bkt(int k, int n) {
    // if(k == n+1) {
    //     for(int i = 0; i < n; i++) {
    //         fprintf(fout, "%d ", submultimi[i]);
    //     }
    //     fprintf(fout, "\n");
    //     return;
    // }

    for(int i = 1; i <= n; i++) {
        if(!vizitat[i]) {
            if(k == 1 || k > 1 && submultimi.back() < i) {
                submultimi.push_back(i);
                vizitat[i] = true;

                for(int j = 0; j < k; j++) {
                    fprintf(fout, "%d ", submultimi[j]);
                }
                fprintf(fout, "\n");

                bkt(k+1, n);

                submultimi.pop_back();
                vizitat[i] = false;
            }
        }
    }
}

int main() {
    int n;
    fscanf(fin, "%d", &n);

    bkt(1, n);
    return 0;
}