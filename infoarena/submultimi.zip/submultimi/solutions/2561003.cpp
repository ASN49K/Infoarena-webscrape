#include <fstream>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int st[20],n;
int valid (int k)
    {
    for (int i=1;i<=k-1;i++)
        if (st[k]==st[i])
            return 0;
    return 1;
    }
void bkt(int k)
    {
    for (int i=st[k-1]+1;i<=n;i++)
        {
        st[k]=i;
        if (valid(k))
            {
            for (int i=1;i<=k;i++)
                fout<<st[i]<<" ";
            fout<<"\n";
            bkt(k+1);
            }
        }
    }
int main()
{
    fin>>n;
    bkt(1);
    return 0;
}
