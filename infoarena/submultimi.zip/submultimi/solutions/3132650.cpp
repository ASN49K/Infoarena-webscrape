#include <bits/stdc++.h>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n;
int main()
{
    fin >> n;
    int limit = 1 << n;
    for(int i = 1; i < limit; ++i)
    {
        for(int j = 1; j <= n; ++j)
        {
            if(i & (1 << (j - 1)))
            {
                fout << j << " ";
            }
        }
        fout << '\n';
    }
    return 0;
}
