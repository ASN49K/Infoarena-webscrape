#include <fstream>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int solutie[20], N, submultimi = 0;

void afisare()
{
    for (int i = 1; i <= N; i++)
        if(solutie[i])
            fout << i << ' ';
    submultimi++;
    if(submultimi > 1)
        fout << '\n';
}

void generare()
{
    int k = 1;
    solutie[k] = -1;
    while (k)
    {
        if (k <= N)
        {
            if (solutie[k] < 1)
            {
                solutie[k]++;
                if (k == N)
                    afisare();
                else
                    solutie[++k] = -1;
            }
            else
                k--;
        }
    }
}

int main()
{
    fin >> N;
    generare();
}