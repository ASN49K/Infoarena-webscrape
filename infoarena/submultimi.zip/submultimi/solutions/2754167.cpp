#include <bits/stdc++.h>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
vector<int> a;
/**
{1,2,3}
a = 1,2,3
a = 2,1,3
132
213
231
312
321

n=5
    0 1 2 3 4
a = 1,2,3,4,5
*/

int main()
{
    int i, n;
    fin >> n;
    for (i = n; i >= 1; i--)
        a.push_back(i);
    do
    {
        for (i = 0; i < n; i++)
            fout << a[i] << " ";
        fout << "\n";
    }
    while(prev_permutation(a.begin(),a.end()));
    fout.close();
    return 0;
}
