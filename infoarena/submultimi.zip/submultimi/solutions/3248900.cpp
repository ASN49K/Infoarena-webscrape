#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main()
{
    int n, v[1001] = {0}, i = 0;
    fin >> n;
    while(v[0] != 1)
    {
        int i = n;
        while(v[i] == 1)
            v[i] = 0, i--;
        v[i] = 1;
        for(int i = 1; i <= n; i++)
            if(v[i])
                fout << i << " ";
        fout << endl;
    }
    return 0;
}
