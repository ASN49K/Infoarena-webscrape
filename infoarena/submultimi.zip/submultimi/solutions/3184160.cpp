#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n;
vector<int> v;
void search(int k)
{
    if(k==n)
    {
        for(auto x:v)
        {
            fout<<x+1<<" ";
        }
        fout<<endl;
        return;
    }
    search(k+1);
    v.push_back(k);
    search(k+1);
    v.pop_back();
}
int main()
{
    fin>>n;
    search(0);
    fin.close();
    fout.close();
    return 0;
}
