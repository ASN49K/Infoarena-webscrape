#include <bits/stdc++.h>
#define int long long
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, start = 1, len = 0;
vector<int> arr;

void backtrack(int start, int len) {
    if (arr.size() == len && len > 0) {
        for (int num : arr) {
            fout << num << " ";
        }
        fout << "\n";
    }
    for (int i = start; i <= n; ++i) {
        arr.push_back(i);
        backtrack(i + 1, len + 1);
        arr.pop_back();
    }
}

signed main() {
    fin >> n;
    backtrack(start, len);
    return 0;
}

