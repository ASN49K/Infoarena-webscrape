#include <bits/stdc++.h>
using namespace std;

vector<int> sl(20, 0);
void bkt(int n, int k)
{
    if(n < k)
    {
        bool vd = true;
        for(int i = n; i >= 1; i--)
        {
            if(sl[i])
            {
                cout << n - i + 1 << " ";
                vd = false;
            }
        }
        if(!vd)
            cout << "\n";
    }
    else
    {
        for(int i = 0; i <= 1; i++)
        {
            sl[k] = i;
            bkt(n, k + 1);
        }
    }
}

int main()
{
    freopen("submultimi.in", "r", stdin);
    freopen("submultimi.out", "w", stdout);
    cin.tie(nullptr)->sync_with_stdio(false);
    int n;
    cin >> n;
    bkt(n, 1);
}