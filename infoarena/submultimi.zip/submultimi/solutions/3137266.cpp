#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");


int n;

void solve(int n){
    long long lim1 = (1LL << n) + 1;
    long long lim2 = (1LL << (n + 1)) - 1;
    for(long long i = lim1 ; i <= lim2 ; i++){
        for(int j = 0 ; j < n ; j++)
            if((i >> j) & 1)
                fout << (j + 1) << " ";
            fout << "\n";
    }
}

int main(){

    ios :: sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);

    fin >> n;

    solve(n);

    fin.close();
    fout.close();
    return 0;
}
