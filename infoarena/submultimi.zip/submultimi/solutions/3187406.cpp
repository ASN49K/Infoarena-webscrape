#include <bits/stdc++.h>
using namespace std;

int n;

int main(){
    ifstream cin("submultimi.in");
    ofstream cout("submultimi.out");

    cin >> n;

    for(int b=1; b<(1<<n); b++){
        for(int i=0; i<n; i++){
            if((1<<i) & b){
                cout << (n-i) << ' ';
            }
        }
        cout << '\n';
    }
}