#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

void show(int len, vector<int> &v) {
  for (int i = 0; i < len; i++) {
    fout << v[i] << ' ';
  }

  fout << '\n';
}

void back(int len, int n, vector<int> &v) {
  if (len  == n) {
    return;
  }
  if (len > 0) {
    show(len, v);
  }

  for (int i = 1; i <= n; i++) {
    if (len == 0) {
      v[len] = i;
    } else if (v[len - 1] < i) {
      v[len] = i;
    } else {
      continue;
    }
    back(len + 1, n, v);
  }
}

int main() {
  int n;
  fin >> n;
  vector<int> v(n);

  back(0, n, v);

  return 0;
}
