#include <fstream>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
long long n,k,putere, s,j;
int folosit[20],cifra,nr,i,cate_elem;
int main()
{
    fin>>n>>k;
    for(j=1;j<=(1LL<<n)-1;j++){
     k=j;
    cate_elem=n;
    i=1;
    for(int t=1;t<=n;t++) folosit[t]=0;
    while(k>0)
   //for(int v=1;v<=3;v++)
    {
        cifra=1;
        s=1LL<<(cate_elem-1);
     //   fout<<s<<endl;
        putere=s;
        while(k>s)
        {   putere=putere/2;
            s=s+putere;

            cifra++;
        }
      //  fout<<cifra<<" ";
        for(nr=0;i<=n and nr<cifra;i++)
            nr=nr+(1-folosit[i]);

       fout<<i-1<<" ";
        folosit[i-1]=1;
        cate_elem=cate_elem-cifra;
        //if(k==s) k=-1;
        //else
        k=k-(s-putere)-1;
     //   fout<<k<<endl;
    }
    fout<<'\n';
    }
    return 0;
}
