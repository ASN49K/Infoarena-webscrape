#include <bits/stdc++.h>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
void afis(int sol[],int nr){
  for(int i=1;i<nr;i++){
    fout<<sol[i]<<' ';
  }
  fout<<'\n';
}
void bkt(int nr,int sol[]){
  if(nr>1 && nr<=n+1){
    afis(sol,nr);
  }
  for(int i=sol[nr-1]+1;i<=n;i++){
    sol[nr]=i;
    bkt(nr+1,sol);
  }
}

int main(int argc, char const *argv[]) {
  fin>>n;
  int sol[n+1];
  sol[0]=0;
  bkt(1,sol);
  return 0;
}
