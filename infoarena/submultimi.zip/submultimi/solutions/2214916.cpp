#include<iostream>
#include<fstream>
using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int N, *v;

int valid(int k) {
	for (int i = 1; i < k; i++)
		if(v[k]==v[i])
			return 0;
	return 1;
}

void afisare(int k) {
	for (int i = 1; i <= k; i++)
		g << v[i];
	g << endl;
}

void backtr(int k) {
	for (int i = 1; i <= 3; i++) {
		v[k] = i;
		if (valid(k)) {
			afisare(k);
			if (k < N) backtr(k + 1);
		}
	}
}

int main() {
	f >> N;
	v = new int[N];
	backtr(1);
	f.close();
	g.close();
	return 0;
}