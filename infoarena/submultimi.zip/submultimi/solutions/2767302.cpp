#include <fstream>
#include <algorithm>

using namespace std;

ifstream cin("submultimi.in");
ofstream cout("submultimi.out");

int main()  {
    int n;
    cin >> n;
    for (int i = 1; i < (1 << n); ++i)  {
        for (int s = i, j = 1; s; s >>= 1, ++j) {
            if (s & 1)
                cout << j << ' ';
        }
        cout << '\n';
    }
    return 0;
}
