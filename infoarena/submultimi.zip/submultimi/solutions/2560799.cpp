#include <fstream>
using namespace std;ifstream f("submultimi.in");ofstream g("submultimi.out");int main(){int n,i=1,j;f>>n;for(;i<=(1<<n);i++,g<<'\n')for(j=0;j<n;j++)if(i&(1<<j))g<<j+1<<' ';}
