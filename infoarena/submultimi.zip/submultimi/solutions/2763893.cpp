#include <fstream>
#include <iostream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, x[18], used[18];
int asc(int *v,int n)
{
    for(int i=1;i<n;i++)
        if(v[i]>=v[i+1])
            return 0;
        return 1;
}
void bkt(int p) {
    if(p>n)return;
    for(int i=1;i<=n;i++)
    {
        x[p]=i;
        if(asc(x,p))
        {
            for(int i=1;i<=p;i++)
                fout<<x[i]<<" ";
            fout<<'\n';
        }
        bkt(p+1);
    }
}

int main() {
    fin >> n;
    cout<<n;
    bkt(1);
    return 0;
}