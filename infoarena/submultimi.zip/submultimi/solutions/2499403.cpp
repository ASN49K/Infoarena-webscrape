#include <cstdio>
#include <vector>
using namespace std;
vector<int> currentSol;
int N;

void consumeSol() {
	for (auto& value :currentSol) {
		printf("%d ", value);
	}
	printf("\n");
}

void back() {
	if (!currentSol.empty()) {
		consumeSol();
	}

	int lastTaken = currentSol.empty() ? 0 : currentSol.back();
	for (int nextElem = lastTaken + 1; nextElem <= N; nextElem++) {
		currentSol.push_back(nextElem);
		back();
		currentSol.pop_back();
	}
}

int main() {
	freopen("submultimi.in", "r", stdin);
	freopen("submultimi.out", "w", stdout);

	scanf("%d", &N);
	currentSol.reserve(N);
	back();
	return 0;
}