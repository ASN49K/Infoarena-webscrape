#import<fstream>
int N;
int main()
{
    std::ifstream("submultimi.in")>>N;
    std::ofstream g("submultimi.out");

    for(int i = 1 << N; --i;)
    {
        for(int d = 0; i >> d; ++d)
        {
            if((i >> d) & 1)
            {
                g<<d+1<<' ';
            }
        }

        g<<'\n';
    }
}
