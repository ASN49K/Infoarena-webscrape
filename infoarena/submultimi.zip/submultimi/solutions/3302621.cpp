#include <bits/stdc++.h>

using namespace std;

int solutie[20];

void bkt(int pos, int n) {
    if (pos > n) {
        int counter = 0;
        for (int i = 1; i <= n; i++) {
            if (solutie[i] == 1) {
                counter++;
            }
        }
        if (counter == 0) return; // nu vreau sa afisez submultimea vida
        for (int i = 1; i <= n; i++) {
            if (solutie[i] == 1) {
                cout << i << " ";
            }
        }
        cout << '\n';
        return;
    }
    for (int val = 1; val <= 2; ++val) {
        solutie[pos] = val;
        bkt(pos + 1, n);
    }
}

int main()
{
    freopen("submultimi.in", "r", stdin);
    freopen("submultimi.out", "w", stdout);
    int n;
    cin >> n;
    bkt(1, n);
    return 0;
}