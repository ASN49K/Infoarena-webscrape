#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, m, x[20];

void prelsol(int l)
{
    for(int i = 1; i <= l; i++)
        fout << x[i] << ' ';
    fout << '\n';
}

void bt(int k)
{
    if(k <= n)
        for(int i = x[k - 1] + 1; i <= n; i++)
        {
            x[k] = i;
            prelsol(k);
            bt(k + 1);
        }
}

int main()
{
    fin >> n;
    bt(1);
    fin.close();
    fout.close();
    return 0;
}