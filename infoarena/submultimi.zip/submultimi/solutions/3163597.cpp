#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");
int stk[11], len;
void afisare ()
{
    for(int i=0;i<len;i++)
        fout<<stk[i]<<" ";
    fout<<'\n';
}
void bkt (int pas, int n)
{
    if(pas>n)
    {
        afisare();
        return;
    }
    stk[len++]=pas;
    bkt(pas+1,n);
    stk[len-1]=0;
    len--;
    bkt(pas+1,n);
}
int main() {
    int n;
    fin>>n;
    bkt(1,n);
    return 0;
}
