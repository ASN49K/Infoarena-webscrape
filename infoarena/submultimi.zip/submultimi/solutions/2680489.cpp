#include <bits/stdc++.h>
#define newline "\n";
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, st[22];
void back() {
	for(int i = 1; i <= st[0]; i++)
		fout << st[i] <<" ";
	if(st[0])
	   fout << newline;
	for(int i = st[st[0]] + 1; i <= n; i++) {
		st[++st[0]] = i;
		back();
		st[st[0]] = 0;
		st[0]--;
	}
}
 
int main() {
	fin >> n;
	back();
	return 0;
}