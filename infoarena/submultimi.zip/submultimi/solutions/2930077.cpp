#include  <iostream>
#include  <fstream>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

int n, x[20], ok, p;

void ScrieSol() {
    for (int i = 1; i <= p; i++)
        out << x[i] << ' ';
    if (ok != 1)
        out << '\n';
}

void Comb(int k) {
    if (k > p)
    {
        ScrieSol();
        return;
    }

    for (int i = x[k - 1] + 1; i <= n - p + k; i++)
    {
        x[k] = i;
        Comb(k + 1);
    }
}

void Subm() {
    for (p = 1; p <= n; p++)
        Comb(1);
}

int main() {
    in >> n;
    Subm();
}