#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, a[17];

void afisare(int k)
{
    for(int i=1; i<=k; i++)
    {
        fout<<a[i]<<" ";
    }
    fout<<endl;
}

bool valid(int k)
{
    return a[k-1]<a[k];
}

void backtracking(int k)
{
    for(int i=1; i<=n; i++)
    {
        a[k]=i;
        if(valid(k))
        {
            afisare(k);
            backtracking(k+1);
        }
    }
}

int main()
{
    fin>>n;
    backtracking(1);
    fin.close();
    fout.close();
    return 0;
}
