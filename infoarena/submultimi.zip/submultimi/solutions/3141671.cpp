#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main() {

    int n;
    fin >> n;

    for (int conf = 1; conf <= (1 << n); conf++) {
        for (int i = 1; i <= n; i++) {
            if ((1 << (i - 1)) & conf)
                fout << i << ' ';
        }
        fout << '\n';
    }

    return 0;
}
