#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n,v[20];

void submultime(int poz,int val);

int main()
{
    fin>>n;
    submultime(0,0);
    return 0;
}

void submultime(int poz,int val)
{
    int i,j;
    poz++;
    for(i=val+1;i<=n;i++)
    {
        v[poz]=i;
        for(j=1;j<=poz;j++)
            fout<<v[j]<<' ';
        fout<<'\n';
        submultime(poz,i);
    }
}
