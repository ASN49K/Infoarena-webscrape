#include <bits/stdc++.h>
using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

#define NMAX 25
int n, x[NMAX], frq[NMAX];

void afis(int k)
{
    for(int i=1;i<=k;++i)
        g << x[i] << ' ';
    g<<'\n';
}

bool valid(int k)
{
    if(k == 1)
        return true;
    if(x[k] > x[k-1])
        return true;
    return false;
}

void backtracking(int k)
{
    for(int i=1;i<=n;++i)
    {
        x[k] = i;
        if(valid(k))
        {
            afis(k);
            backtracking(k+1);
        }
    }
}

int main()
{
    f >> n;
    backtracking(1);
}