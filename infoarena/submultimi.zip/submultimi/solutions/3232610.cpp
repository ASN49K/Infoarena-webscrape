#include<fstream>
using namespace std;
ifstream F("submultimi.in");
ofstream G("submultimi.out");
int n,i,j,k,m;
int main()
{
    for(F>>n,m=1<<n,i=1;i<m;G<<'\n',++i)
        for(k=i,j=1;j<=n;k>>=1,++j)
            if(k&1)
                G<<j<<' ';
    return 0;
}
