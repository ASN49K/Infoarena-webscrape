#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int N, sub[20];
void back(int len)
{
    if(len > 0)
    {
        for(int i = 1; i <= len; i++)
            fout << sub[i] << " ";
        fout << "\n";
    }
    for(int i = sub[len] + 1; i <= N; i++)
    {
        len++;
        sub[len] = i;
        back(len);
        sub[len] = 0;
        len--;
    }
}

int main()
{
    fin >> N;
    back(0);
    return 0;
}
