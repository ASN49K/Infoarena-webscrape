#include <fstream>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n,x[20];

void afis(int k)
{
    for(int i = 1 ; i <= k ; i++)
        g << x[i] << ' ';
    g << '\n';
}

void bt(int k)
{
    for(int i=x[k-1]+1;i<=n;i++)
    {
        x[k]=i;
        afis(k);
        bt(k+1);
    }
}

int main()
{
    f>>n;
    bt(1);
    f.close();
    g.close();
    return 0;
}
