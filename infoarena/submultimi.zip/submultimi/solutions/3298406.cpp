#include <iostream>
#include <fstream>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int v[10], n;

void afisare(int k)
{
    for(int i=1 ; i<=k ; i++)
        g<<v[i]<<' ';
    g<<'\n';
}
void backt(int k)
{
    for(int i=v[k-1]+1 ; i<=n ; i++)
    {
        v[k]=i;
        afisare(k);
        backt(k+1);
    }
}
int main()
{
    f>>n;
    backt(1);

    f.close();
    g.close();
    return 0;
}
