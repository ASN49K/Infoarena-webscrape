#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int x[20],fr[20],n,y;
void tipar(int){
    for(int i=1;i<=y;i++)
        fout<<x[i]<<" ";
    fout<<"\n";
}
void Back(int k){
for(int i=x[k-1]+1;i<=n;i++){
        x[k]=i;
        y=k;
        tipar(y);
    if(k<n)
        Back(k+1);
}
}
int main()
{
    fin>>n;
    Back(1);
    return 0;
}
