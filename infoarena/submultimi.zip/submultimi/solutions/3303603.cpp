#include <bits/stdc++.h>

#include <random>

using namespace std;

signed main()
{
    freopen("submultimi.in", "r", stdin);
    freopen("submultimi.out", "w", stdout);
    int n;
    cin >> n;

    for (int mask = 1; mask < (1 << n); mask++) {
        for (int bit = 0; bit < n; ++bit) {
            if ((mask & (1 << bit)) != 0) {
                cout << bit + 1 << ' ';
            }
        }
        cout << '\n';
    }
    return 0;
}