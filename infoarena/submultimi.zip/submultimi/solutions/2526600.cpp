#include <bits/stdc++.h>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int f[20],v[20],n;
void afis(int poz)
{
    for(int i=1;i<poz;i++)
        fout<<v[i]<<" ";
    fout<<'\n';
}
void bkt(int poz)
{
    if(poz>1)
        afis(poz);
    if(poz>n)
        return;
    for(int i=v[poz-1]+1;i<=n;i++)
        if(f[i]==0)
        {
            f[i]=1;
            v[poz]=i;
            bkt(poz+1);
            f[i]=0;
        }
}
int main()
{
    fin>>n;
    bkt(1);
    return 0;
}
