
#include <iostream>
#include <fstream>
#include <vector>

using std::cin;
using std::cout;

using std::vector;

using std::ifstream;
using std::ofstream;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

vector<int> v;
int n, k;

void comb(int l = 0) {

	for (auto i : vector<int>(v.begin(), v.begin() + l)) {
		out << i << " ";
	}
	out << "\n";

	for (int i = 1; i <= n; i++) {

		int ok = 1;
		for (int j = 0; j < l; j++) {
			if (v[j] >= i) ok = 0;
		}

		if (ok) {
			v[l] = i;
			comb(l + 1);
		}

	}
}

int main() {
	in >> n;
	v.resize(n + 1);
	comb();
}
