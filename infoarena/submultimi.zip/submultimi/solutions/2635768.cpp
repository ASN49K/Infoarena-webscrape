#include <fstream>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
long long n,i,j,nr;
int main()
{
   fin>>n;
   nr=1LL<<n;
   for(i=1;i<nr;i++)
   {
       //generez submultimea corespunzatoarea reprezentarii binare a lui i
       //testez daca elem (j+1) apartine multimii
       for(j=0;j<n;j++)
        if(i&(1LL<<j))
         fout<<j+1<<" ";
        fout<<'\n';
   }
    return 0;
}
