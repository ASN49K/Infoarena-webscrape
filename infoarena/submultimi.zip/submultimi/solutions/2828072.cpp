#include <fstream>
#include <iostream>

using namespace std;

int n, sol[17], comb = 1;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

bool valid(int k){
    for(int i = 1; i < k; ++i){
        if(sol[i] >= sol[k]){
            return false;
        }
    }
    return true;
}

void bkt(int k){
    if(k == n + 1){
        return;
    }
    for(int i = 1; i <= n; ++i){
        sol[k] = i;
        if(valid(k)){
                for(int i = 1; i <= k; ++i){
                    fout << sol[i] << " ";
                }
                fout << "\n";
            bkt(k + 1);
        }
    }
}

int main()
{
    fin >> n;
    bkt(1);

    return 0;
}
