#include <fstream>
#include <vector>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
void backtrack(int start,int n,int k,vector<vector<int>>& result,vector<int>& current){
    if(current.size()==k){
        result.push_back(current);
        return;
    }
    for(int i=start;i<=n;i++){
        current.push_back(i);
        backtrack(i+1,n,k,result,current);
        current.pop_back();
    }
}
void combinations(int n){
    vector<vector<int>> result;
    vector<int> current;  
    for(int k=1;k<=n;k++)
        backtrack(1,n,k,result,current);
    for(int i=0;i<result.size();i++){
        for(int j=0;j<result[i].size();j++)
            fout<<result[i][j]<<" ";
        fout<<endl;
    }
}
int main(){
    int n,k;
    fin>>n>>k;
    combinations(n);
    return 0;
}