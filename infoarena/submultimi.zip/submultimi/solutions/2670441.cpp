#include <fstream>
#include <iostream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

#define lim (1<<n)
int n, mask, aux;

///verficare daca bitul de pe pozitia 5 in reprezentarea nr e 1 sau 0:
/**
    nr = 00100010111
    nr &(00000010000) = (00000010000)
    00000000 = submultimea vida
    2^3 -> 4biti
    2^3-1 -> 3 biti
{1}
    111111...111 = n de 1
    2^n-1
    0..n-1
**/

int main()
{
    fin>>n;
    for(mask = 1; mask < lim; mask++)
    {
        for(aux = 1;  aux <= n; aux++)
            if(mask & (1<<(aux-1)))
                fout<<aux<<' ';
        fout<<'\n';
    }

    return 0;
}
