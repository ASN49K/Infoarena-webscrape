#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main()
{
    long long int n,i,k;
    fin>>n;
    k=(1<<n)-1;

    for(i=1;i<=k;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(i&(1<<j))
                fout<<j+1<<" ";
        }fout<<endl;
    }
    return 0;
}
