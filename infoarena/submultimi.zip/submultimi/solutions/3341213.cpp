#include <bits/stdc++.h>
using namespace std;

int n;
int v[20], m = 0;

void bkt(int i) {
    if (i > n) {
        return;
    }
    // pune-l in multime
    v[++m] = i;
    for (int j = 1; j <= m; ++j) {
        cout << v[j] << " ";
    }
    cout << "\n";
    bkt(i + 1);
    --m;
    // nu il pune in submultie
    bkt(i + 1);
}

int main() {
    freopen("submultimi.in", "r", stdin);
    freopen("submultimi.out", "w", stdout);
    cin >> n;
    for (int mask = 1; mask < (1 << n); ++mask) {
        for (int i = 0; i < n; ++i) {
            if ((mask >> i) & 1) {
                cout << i + 1 << " ";
            }
        }
        cout << "\n";
    }
    // bkt(1);
}