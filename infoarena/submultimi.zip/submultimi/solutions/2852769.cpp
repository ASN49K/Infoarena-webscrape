#include <bits/stdc++.h>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

const int N=17;
int x[N],n;

bool ok(int k)
{
    for(int i=1;i<k;i++)
        if(x[i] == x[k] || x[i]>x[i+1]) return 0;
    return 1;
}

void afis(int k)
{
    for(int i=1;i<=k;i++)
        out<<x[i]<<' ';
    out<<'\n';
}

void backtrack(int k)
{
    for(int i=1;i<=n;i++)
    {
        x[k]=i;
        if(ok(k))
        {
            afis(k);
            if(k<n) backtrack(k+1);
        }
    }
}

int main()
{
    in>>n;
    backtrack(1);
    return 0;
}
