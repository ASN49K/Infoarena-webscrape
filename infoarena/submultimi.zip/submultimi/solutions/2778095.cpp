#include <iostream>
#include <fstream>
using namespace std;

int n, subm[25];
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

void gen(int element, int lgSubm) {
  if (element == n + 1) {
    for (int i = 0; i < lgSubm; ++i)
      fout << subm[i]<<' ';
    fout << "\n";
    return;
  }
  subm[lgSubm] = element;
  gen(element + 1, lgSubm + 1);
  gen(element + 1, lgSubm);
}
int main() {
    fin >> n;
    gen(1, 0);
    return 0;
}
