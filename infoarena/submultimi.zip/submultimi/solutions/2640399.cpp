#include <bits/stdc++.h>
#define ll long long
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, v[17];

void gen(int element, int lg) {
    if(element == n + 1) {
        for(int i = 1; i < lg; i++)
            fout << v[i] << ' ';
        fout << '\n';
        return;
    }

    v[lg] = element;
    gen(element + 1, lg + 1);
    gen(element + 1, lg);
}

int main() {
    fin >> n;
    gen(1, 1);
    return 0;
}
