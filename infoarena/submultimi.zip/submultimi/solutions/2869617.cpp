#include <bits/stdc++.h>
using namespace std;

///-----------------------------------------------FILES
ifstream f("submultimi.in");
ofstream g("submultimi.out");

///-----------------------------------------------GLOBAL VARIABLES
#define NMAX 405
int x[NMAX], frq[NMAX];
int n;

///-----------------------------------------------READING THE INPUT
void ReadInput()
{
    f >> n;
}

bool isgud(int k)
{
    if(k==1)
        return true;
    if(x[k] > x[k-1])
        return true;
    return false;
}

void backtracking(int k)
{
    if(k > 1)
    {
        for(int i=1;i<k;++i)
            g << x[i] << ' ';
        g<<'\n';
    }
    for(int i=1;i<=n;++i)
        if(!frq[i])
        {
            x[k] = i;
            if(isgud(k))
                backtracking(k+1);
        }
}

///-----------------------------------------------SOLUTION
void Solution()
{
    backtracking(1);
}

///-----------------------------------------------MAIN
int main()
{
    ReadInput();
    Solution();
    Output();
}
