
#include<iostream>
#include<fstream>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");
int N,*a,p=1;
void afisare(int n)
{
    for(int i =1; i<=n;i++)
        if(a[i]!=0)
            g<<a[i]<<" ";
    g<<endl;
}
bool valid(int k)
{
    if(a[k-1] >= a[k] && k>1)
        return false;

    return true;
}
void backtracking(int k)
{
    int i;

    for(i=1;i<=N;i++)
    {
        a[k] = i;

        if(valid(k))
        {
            afisare(k);
            backtracking(k+1);
        }
    }
}
int main()
{
    f>>N;
    a = new int[N+3];
    for(int i=1;i<=N;i++)
        a[i]=0;

    backtracking(1);
    return 0;
}
