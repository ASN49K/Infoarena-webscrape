#include <iostream>
#include <fstream>
#include <string>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;

string toprint;

void dfs(int i)
{
    if (i > n) {return;}

    toprint += ' ';
    toprint += i + '0';
    fout << toprint << '\n';
    dfs(i + 1);

    toprint.pop_back();
    toprint.pop_back();

    dfs(i + 1);
}

int main()
{
    fin >> n;

    dfs(1);
}
