#include <iostream>
#include <fstream>

using namespace std;
ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");

int n;
int sol[16];

void rec(int niv, int nxt){
    sol[niv]=nxt;
    for (int i=0; i<=niv; i++)
        fout<<sol[i]<<' ';
    fout<<'\n';
    for (int i=nxt+1; i<=n;  i++)
        rec(niv+1, i);
}
int main()
{
    fin>>n;
    for (int i=1; i<=n; i++)
        rec(0, i);
    return 0;
}
