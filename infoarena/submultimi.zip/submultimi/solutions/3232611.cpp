#include<fstream>
using namespace std;
ifstream F("submultimi.in");
ofstream G("submultimi.out");
int main()
{
    int n,m;
    F>>n,m=1<<n;
    for(int i=1;i<m;G<<'\n',++i)
        for(int j=0;j<n;++j)
            if((i>>j)&1)
                G<<j+1<<' ';
    return 0;
}
