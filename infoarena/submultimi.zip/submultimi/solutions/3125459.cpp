#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int X[20], M;

void Backtracking(int K, int N)
{
       for(int i = X[K - 1] + 1; i <= M; i ++){
        X[K] = i;
        if(K == N)
        {
            for(int j = 1; j <= N; j ++)
                fout << X[j] << " ";
            fout << '\n';
        }
        else
           Backtracking(K + 1, N);
       }
}
int main()
{
    fin >> M;
    for(int i  = 1; i <= M; i ++)
        Backtracking(1, i);
    return 0;
}