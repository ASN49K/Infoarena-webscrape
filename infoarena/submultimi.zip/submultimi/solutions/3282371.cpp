#include <bits/stdc++.h>

using namespace std;

#define TITLE ""

ifstream f (TITLE".in");
ofstream g (TITLE".out");

int n;

void Print(vector<int> answer)
{
    for(int i=1; i<answer.size(); i++)
        g<<answer[i]<<' ';
    g<<'\n';
}

void backtrack(int CurrentPos,vector<int> answer)
{
    answer.push_back(CurrentPos);
    if(CurrentPos!=0)
    Print(answer);
    for(int i=CurrentPos+1; i<=n; i++)
        backtrack(i,answer);
}

int main()
{
    f>>n;
    vector<int> temp;
    backtrack(0,temp);
    return 0;
}
