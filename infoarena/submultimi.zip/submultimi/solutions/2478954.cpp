#include <iostream>
#include<fstream>
using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int n;
int i;
int v[25];
void backTracking(int k, int poz)
{
    int i = poz;
    while(i <= n)
    {
        v[k] = i;
        for(int j = 1; j <= k; j++)
            g << v[j] <<" ";
        g << '\n';
        if(k != n)
            backTracking(k + 1, i + 1);
        i++;
    }
}
int main() {
   f >> n;
   backTracking(1, 1);
}