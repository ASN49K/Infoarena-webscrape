#include <fstream>
using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
int main()
{
    int n,v[31],a[31];
    int i;
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>a[i];
    for(int i=1;i<=n;i++)
        v[i]=0;
    while(1)
    {
        i=n;
        while(i>=1 && v[i]==1)
        {
            v[i]=0;
            i--;
        }
        if(i==0)
            break;
        v[i]=1;
        for(i=1;i<=n;i++)
            if(v[i]==1)
            cout<<a[i]<<" ";
        cout<<endl;
    }

    return 0;
}

