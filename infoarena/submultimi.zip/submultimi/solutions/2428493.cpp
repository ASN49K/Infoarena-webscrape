#include <fstream>
using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
int n,f[17],s[17];
void combinari(int pas)
{
    for (int i=1; i<pas; ++i)
        cout<<s[i]<<" ";
    if (s[1]) cout<<"\n";
    for (int i=s[pas-1]+1; i<=n; ++i)
    {
        if (!f[i])
        {
            s[pas]=i;
            f[i]=1;
            combinari(pas+1);
            f[i]=0;
        }
    }
}
int main()
{
    cin>>n;
    combinari(1);
}

