#include <bits/stdc++.h>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int v[20], n;

void afisare(int lung)
{
    for(int i = 1; i <= lung; i++)
        g<<v[i]<<' ';
    g<<'\n';
}

void bt(int len, int prev)
{
    for(int i = prev; i <= n; i++)
    {
        v[len] = i;
        afisare(len);
        if(len <= n)
            bt(len + 1, i + 1);
    }
}

int main()
{
    f>>n;
    bt(1, 1);
    return 0;
}