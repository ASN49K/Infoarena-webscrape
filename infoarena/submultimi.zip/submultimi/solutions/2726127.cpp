#include    <iostream>
#include    <fstream>
#include    <bitset>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

int n;

int main() {
    in>>n;
    for(int i = 1, c = i; i <= 1 << n; i++, c = i, out<<'\n') 
        for (int j = 1; j <= n; j++, c >>= 1) 
            if (c & 1)
                out<< j <<' ';
}
