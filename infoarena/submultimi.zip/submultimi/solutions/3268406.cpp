#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, p[20], st[20];

void afis(int k)
{
    for(int i = 1; i <= k; ++i)
        fout << st[i] << " ", p[i] = 0;
    fout << "\n";
}

void bkt(int k)
{
    for(int i = st[k - 1] + 1; i <= n; ++i)
        if(!p[i])
        {
            p[i] = 1;
            st[k] = i;
            afis(k);
            if(k != n)
            {
                bkt(k + 1);
                p[i] = 0;
            }
        }
}

int main()
{
    fin >> n;
    bkt(1);
    return 0;
}

