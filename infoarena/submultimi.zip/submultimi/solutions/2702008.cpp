#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int v[20];
void generate_subs(int n, int element, int lg) {
    if (element == n + 1) {
        for (int i = 1; i <= lg - 1; ++i) {
            fout << v[i] << ' ';
        }
        fout << '\n';
        return;
    }
    v[lg] = element;
    generate_subs(n, element + 1, lg + 1);
    generate_subs(n, element + 1, lg);
}

int main() {
    int n;
    fin >> n;
    generate_subs(n, 1, 1);
    return 0;
}
