#include <bits/stdc++.h>
#pragma GCC optimize("Ofast,unroll-loops")
#pragma GCC target("avx,avx2,fma")
using namespace std;
#define fastIO ios_base::sync_with_stdio(NULL);cin.tie(NULL);
#define testCases int tc;cin>>tc;while(tc--);
#define ll long long
#define ld long double
#define sza(x) ((int)x.size())
#define all(a) (a).begin(),(a).end()
#define PI 3.1415926535897932384626433832795l
template<typename T> inline T gcd(T a,T b){return (b?__gcd(a,b):a);}
template<typename T> inline T lcm(T a,T b){return (a*(b/gcd(a,b)));}
const int NMAX = 1e5 + 5;
static inline void solve();

int main(int argc, char** argv)
{

    (void)! freopen ("submultimi.in", "r", stdin);
    (void)! freopen ("submultimi.out", "w", stdout);
    fastIO

    // testCases
    solve();

    return 0;
}

static inline void solve()
{
    int n; cin >> n;
    for (int i = 1; i < (1 << n); ++ i, cout << '\n')
        for (int j = 0; j < n; ++ j)
            if (i & (1 << j)) cout << j + 1 << ' ';
}