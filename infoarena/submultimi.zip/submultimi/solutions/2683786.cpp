#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n,i,a[101],x;

int main()
{
   fin>>n;
   for(i=1;i<=n;i++)
    a[i]=i;
   for(x=1;x<=(1<<n);x++)
   {
       for(i=0;i<n;i++)
        {if(x&(1<<i)) fout<<a[i+1]<<" ";}
       fout<<'\n';
   }

    return 0;
}
