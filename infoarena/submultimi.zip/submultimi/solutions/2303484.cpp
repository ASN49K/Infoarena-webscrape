#include <bits/stdc++.h>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n,m,sol[20];
void scrie()
{
	for(int i=1;i<=m;i++)
		fout<<sol[i]<<' ';
	fout<<'\n';
}
void bkt(int k)
{
	if(k==m+1)
		scrie();
	else
        for(int i=sol[k-1]+1;i<=n-m+k;i++)
        {
            sol[k]=i;
            bkt(k+1);
        }
}
int main()
{
	fin>>n;
	for(m=1;m<=n;m++)
		bkt(1);
	return 0;
}
