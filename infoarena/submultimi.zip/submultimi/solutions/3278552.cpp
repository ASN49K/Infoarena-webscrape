#include <bits/stdc++.h>
using namespace std;
const string file="submultimi";
ifstream f(file+".in");
ofstream g(file+".out");
//#define f cin
//#define g cout
#define mod 666013
int n,x[20],p[20],k;
void afis(int k){
    for(int i=1; i<=k; ++i) g<<x[i]<<' ';
    g<<'\n';
}
void back(int k){
    for(int i=x[k-1]+1; i<=n; ++i){
        x[k]=i;
        if(k<=n){
            afis(k);
            back(k+1);
        }
    }
}
int main(){
    f>>n;
    back(1);
    return 0;
}
