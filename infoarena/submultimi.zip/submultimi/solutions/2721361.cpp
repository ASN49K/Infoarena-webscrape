#include <fstream>

using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
// scrie toate submultimile lui k...n precedate de a[1],...,a[na]
void printsubset(int n,int k,int a[501],int na)
{
    if(n+1==k)
    {
        for(int i = 1; i <= na; i++)
        {
            cout<<a[i]<<" ";
        }
        cout<<"\n";
    }
    else
    {
        a[na+1] = k;
        printsubset(n,k+1,a,na+1);
        printsubset(n,k+1,a,na);
    }
}

int main()
{
    int n;
    int a[501];
    cin >> n;
    printsubset(n,1,a,0);
    return 0;
}
