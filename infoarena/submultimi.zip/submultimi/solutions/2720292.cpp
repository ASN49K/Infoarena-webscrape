#include <bits/stdc++.h>

using namespace std;

const string FILENAME = "submultimi";

ifstream fin(FILENAME + ".in");
ofstream fout(FILENAME + ".out");

int n;
int a[18];

void show()
{
    if(a[0])
    {
        for(int i = 1; i <= a[0]; i++)
            fout << a[i] << " ";
        fout << "\n";
    }
}

void back()
{
    show();
    for(int i = a[a[0]] + 1; i <= n; i++)
    {
        a[++a[0]] = i;
        back();
        a[a[0]] = 0;
        a[0]--;
    }
    
}

int main()
{
    fin >> n;
    back();
    fin.close();
    fout.close();
    return 0;
}