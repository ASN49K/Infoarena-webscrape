#include <iostream>
#include <vector>
#include <fstream>
using namespace std;
ifstream be("submultimi.in");
ofstream ki("submultimi.out");

void general_alg(int k,int j,int n,int a[])
{
    if(j==k ){
        //if(ellenor(a,k)){
            for(int i=0;i<k;++i)
            {
                ki<<a[i]<<" ";

            }
            ki<<'\n';
    }
    else
    {
        for(int i=1;i<=n;i++){
            if(j==0 || i>a[j-1]){
                a[j]=i;
                general_alg(k,j+1,n,a);
            }

        }
    }

}

int main()
{
    int k;
    be>>k;
    int a[k+1];
    for(int i=1;i<=k;++i)
    general_alg(i,0,k,a);
    return 0;
}
