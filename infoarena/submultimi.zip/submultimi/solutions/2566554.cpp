#include <bits/stdc++.h>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n,i,v[20];
int main() {
    fin>>n;
    while (v[0]==0) {
        i=n;
        while (v[i]==1)
            v[i--]=0;
        v[i]=1;
        for (i=1;i<=n;i++)
            if (v[i]==1)
                fout<<i<<" ";
        if (v[0]==0)
            fout<<"\n";
    }
    return 0;
}
