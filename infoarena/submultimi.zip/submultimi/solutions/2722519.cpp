#include <fstream>
#define N 16

using namespace std;

ifstream fin( "submultimi.in" );
ofstream fout( "submultimi.out" );

//int sol[N + 1];
//char f[N + 1];

//bkt
/*void afis( int v[], int n ) {
    fout << sol[1];
    for ( int i = 2; i <= n; i ++ )
        fout << " " << sol[i];
    fout << "\n"; 
}

void subm( int n, int poz ) {
    if ( poz == n ) {
        return;
    }
    for ( int i = 1; i <= n; i ++ ) {
        if ( i > sol[poz] ) {
            sol[poz + 1] = i;
            f[i] = 1;
            afis( sol, poz + 1 );
            subm( n, poz + 1 );
            f[i] = 0;
        }
    }
}*/

//biti
void subm( int n ) {
    int nr, poz;
    for ( int i = 1; i < ( 1 << n ); i ++ ) {
        nr = i;
        poz = 1;
        while ( nr ) {
            if ( nr % 2 == 1 )
                fout << poz << " ";
            nr /= 2;
            poz ++;
        }
        fout << "\n";
    }
}

int main() {
    int n;
    fin >> n;
    //subm( n, 0 );
    subm( n );
    return 0;
}