#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, x[10000];

void afis(int k){
    for(int i=1 ; i<=k ; ++i)
        fout << x[i] << " ";
    fout << endl;
}
bool valid(int k){
    if(k == 1)
        return true;
    if(x[k] > x[k-1])
        return true;
    return false;
}
void back(int k){
    for(int i=1;i<=n;++i)
    {
        x[k]=i;
        if(valid(k))
        {
            afis(k);
            back(k+1);
        }
    }
}
int main()
{
    fin >> n;
    back(1);
    return 0;
}
