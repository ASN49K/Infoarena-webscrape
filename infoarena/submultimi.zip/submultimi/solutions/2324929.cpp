#include <bits/stdc++.h>

using namespace std;

ifstream fi("submultimi.in");
ofstream fo("submultimi.out");

int main()
{
    int n;
    fi>>n;
    for (int i = 1; i <= 1<<n; i++)
    {
        for (int j = 1; j <= n; j++)
            if (1<<j-1 & i)
                fo<<j<<" ";
        fo<<"\n";
    }

    return 0;
}
