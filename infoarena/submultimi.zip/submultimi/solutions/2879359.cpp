#include <bits/stdc++.h>
#define MAXN 16

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main() {
    int n, arr[MAXN];
    unsigned short bitMask = 1;
    fin >> n;
    for (int i = 0; i < n; i++)
        arr[i] = i + 1;
    while (bitMask < (1 << n) - 1) {
        for (int i = 0; i < n; i++)
            if (bitMask & (1 << i))
                fout << arr[i] << ' ';
        fout << '\n';
        bitMask++;
    }
    return 0;
}
