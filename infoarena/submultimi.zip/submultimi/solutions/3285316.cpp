#include <bits/stdc++.h>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, st[20], fr[20];

void Back(int top)
{
    int i;
    if (top > 1)
    {
        for (i = 1 ; i <= top - 1 ; i++)
            fout << st[i] << " ";
        fout << "\n";
    }
    if (top > n) return;
    for (i = st[top - 1] + 1 ; i <= n ; i++)
        if (fr[i] == 0)
    {
        fr[i] = 1;
        st[top] = i;
        Back(top + 1);
        fr[i] = 0;
    }
}

int main()
{
    fin >> n;
    Back(1);
    return 0;
}
