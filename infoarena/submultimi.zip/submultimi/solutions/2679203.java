import java.util.*;
import java.io.*;
 
class Main {
    private static boolean [] globalarray;
    private static int n;
    private static PrintWriter writer;
    
	public static void main(String []args) {
        File inputFile = new File("submultimi.in");
        File outputFile = new File("submultimi.out");
     
        try {
            FileInputStream inputStream = new FileInputStream(inputFile);
            Scanner scanner = new Scanner(inputStream);
            n = scanner.nextInt();
            inputStream.close();
          
    		FileOutputStream outputStream = new FileOutputStream(outputFile);
            writer = new PrintWriter(outputStream);
          
            globalarray = new boolean[n];
            backtracking(0, n);
          
            writer.close();
            outputStream.close();
        } catch(IOException e) {
     
        }
	}
	
	public static void backtracking(int i, int n){
	    if (i == n){
	        printit();
	        return;
	    }
	    globalarray[i] = false;
	    backtracking(i + 1, n);
	    
	    globalarray[i] = true;
	    backtracking(i + 1, n);
	}
	
	public static void printit(){
	    try {
            for (int i = 0; i < n; i++){
                if (globalarray[i])
                    writer.print(i + 1);
            }
            writer.print('\n');
    	} catch(IOException e) {
 
    	}
	}
}
