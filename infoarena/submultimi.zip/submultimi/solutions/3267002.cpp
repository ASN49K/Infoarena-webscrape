#include<fstream>
//#include<iostream>
using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
int s[20],poz[20],n,p;
void afis(int k)
{
    for(int i=1;i<=k;i++)
        cout<<s[i]<<" ";
    cout<<'\n';
}
void bac(int k)
{
    for(int i=1;i<=n;i++){
        if(!poz[i] && s[k-1]<i){
            poz[i]=1;
            s[k]=i;
            afis(k);
            bac(k+1);
            poz[i]=0;
        }
    }
}
int main()
{
    cin>>n;
    bac(1);
    return 0;
}
