#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int solutie[20],n;
void afisare(int k)
{
    for(int i=1;i<=k;++i)
        fout<<solutie[i]<<" ";

    fout<<'\n';
}
void bkt(int k)
{
  for(int i=solutie[k-1]+1;i<=n;i++)
  {
      solutie[k]=i;
              afisare(k);
            bkt(k+1);


  }
}
int main()
{
    fin>>n;
    bkt(1);
    return 0;
}
