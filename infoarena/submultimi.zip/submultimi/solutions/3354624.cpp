#include <bits/stdc++.h>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

vector<vector<int>>sol;

void back(int n, vector<int>v, int last) {
    if (v.size() != 0) {
        sol.push_back(v);
        if (v.size() == n) {
            return;
        }
    }
    for (int i = last; i <= n; i++) {
        v.push_back(i);
        back(n, v, i + 1);
        v.pop_back();
    }

}

int main() {

    int n;
    fin>>n;
    vector<int>v;
    back(n, v, 1);
    for (int i = 0; i < sol.size(); i++) {
        for (int j = 0; j < sol[i].size(); j++) {
            fout<<sol[i][j]<<" ";
        }
        fout<<endl;
    }
    return 0;
}