#include <fstream>
using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");
int main() {
    int n;
    in >> n;
    int p = 2 << (n - 1);
    for (int i = 1; i < p; i ++) {
        int x = i, nr = 1;
        while (x) {
            if (x % 2 == 1) {
                out << nr << " ";
            }
            nr ++;
            x /= 2;
        }
        out << endl;
    }
    return 0;
}