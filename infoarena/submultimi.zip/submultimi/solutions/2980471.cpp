#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, v[20], sol[20];

void Afisare(int pos)
{
    for(int  i = 1; i <= pos ; i++)
        fout << sol[i] << ' ' ;
    fout << '\n';
}
void Bkt(int  pos, int last)
{
    if(pos == n+1)return ;
    for(int  i =last+1 ; i <= n; i++)
    {
        if(v[i] == 1)continue;
        else
            {
                v[i] = 1;
                sol[pos] = i;
                Afisare(pos);
                Bkt(pos+1, i);
                v[i] = 0;
                sol[pos] = 0 ;
            }
    }
}

int main()
{
    fin >> n;
    Bkt(1,0);
    return  0;
}
