#include <bits/stdc++.h>


using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n,v[17];

void afisare(int k)
{
    for(int i=1;i<=k;i++)
     g<<v[i]<<' ';
    g<<'\n';
}

bool ok(int k)
{
    for(int i=1;i<k;i++)
        if(v[i]>=v[k])
            return false;
     return true;
}

void bkt(int k)
{
    for(int i=1;i<=n;i++)
    {
        v[k]=i;
        if(ok(k))
     {

         afisare(k);
            bkt(k+1);
    }
    }
}

int main()
{

    f>>n;
    bkt(1);

    return 0;
}
