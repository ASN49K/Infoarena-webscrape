#include <iostream>
#include <cmath>
using namespace std;

int out[10], n = 3;
void afis(int k){
    for(int i = 1; i <= k; i++) cout << out[i] << " ";
    cout << "\n";
}
void back(int k){
    for(int i = out[k-1] + 1; i <= n; i++){
        out[k] = i;
        afis(k);
        if(k < n) back(k+1);
    }
}
int main()
{
     back(1);
}
