#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    ifstream cin ( "submultimi.in" );
    ofstream cout ( "submultimi.out" );
    int n , p2 , i , j , cifra;
    cin >> n;
    i = n;
    p2 = 1;
    while ( i > 0 ) {
        p2 *= 2;
        i--;
    }
    for ( j = 1 ; j < p2 ; j++ ){
        i = j;
        cifra = 1;
        while ( i > 0 ) {
            if ( i % 2 == 1 )
                cout << cifra << " ";
            i /= 2;
            cifra++;
        }
        cout << '\n';
    }
    return 0;
}
