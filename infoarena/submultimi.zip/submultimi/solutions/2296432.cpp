#include <fstream>
#include <vector>
using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

vector <int> subm;

void afis(int k)
{
    for(int i=1;i<=k;++i)
        g<<subm[i]<<' ';
    g<<'\n';
}

void submultimi(int n)
{
    subm.resize(n+1);
    int niv=1;
    subm[1]=0;
    while(niv>0)
    {
        if(subm[niv]<n)
        {
            subm[niv]++;
            afis(niv);
            if(niv<n)
            {
                niv++;
                subm[niv]=subm[niv-1];
            }
        }
        else
        {
            subm[niv]=subm[niv-1];
            niv--;
        }
    }
}

int main()
{
    int n;
    f>>n;
    submultimi(n);
    return 0;
}
