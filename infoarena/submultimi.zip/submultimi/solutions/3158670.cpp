#include <fstream>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int x[16];
void afisare(int k)
{
    for(int i=1; i <= k; i++)
        fout << x[i] << " ";
    fout << '\n';
}
void backtrack(int k, int n)
{
    for(int i = x[k - 1] + 1 ; i <= n ; i++)
    {
        x[k]=i;
        afisare(k);
        backtrack(k + 1, n);
    }
}
int main()
{
    int n;
    fin >> n;
    backtrack(1, n);
    return 0;
}
