#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, multime[18], v[18], x[18];

void Prelucrare(int subm)
{
    for (int i = 1; i <= n; i++)
    {
        if (subm && (1 << (i - 1)))
        {
            fout << multime[i] << ' ';
        }
    }
}

int main()
{
    //freopen("submultimi.in", "r", stdin);
    //freopen("submultimi.out", "w", stdout);
    //scanf("%i", &n);
    fin >> n;
    for (int i = 1; i <= n; i++)
    {
        multime[i] = i;
    }

    int nrSubm = 1 << n;
    for (int subm = 0; subm < nrSubm; subm++)
    {
        Prelucrare(subm);
        fout << '\n';
    }
    return 0;
}
