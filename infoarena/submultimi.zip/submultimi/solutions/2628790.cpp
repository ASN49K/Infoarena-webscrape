#include <fstream>
#include <vector>
using namespace std;
ifstream cin( "submultimi.in" );
ofstream cout( "submultimi.out" );
vector< int > v;
int n;

void mut( int sub ){
    if( sub > n ){
        for( int i = 0; i < v.size(); i++ )
            cout << v[ i ] << ' ';
        if( v.size() != 0 )
            cout << '\n';
        return;
    }
    mut( sub + 1 );
    v.push_back( sub );
    mut( sub + 1 );
    v.pop_back();
}
int main()
{

    cin >> n;
    mut( 1 );
    return 0;
}
