#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int main()
{
    int n;
    fin>>n;
    for(int i=1;i<(1<<n);i++)
    {
        for(int j=1;j<=n;j++)
        {
            if(i&(1<<(j-1)))
                fout<<j<<' ';
        }
        fout<<'\n';
    }
    return 0;
}
