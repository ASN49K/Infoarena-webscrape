#include <iostream>
#include <fstream>
#include <string>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;

string toprint = "";

string rev(string x)
{
    string r = "";

    while (x.size() > 0)
    {
        r += x.back();
        x.pop_back();
    }

    return r;
}

string str(int x)
{
    string r = "";

    while (x)
    {
        r += x % 10 + '0';
        x /= 10;
    }

    return rev(r);
}

int length(int x)
{
    int l = 0;

    while (x)
    {
        l++;
        x /= 10;
    }

    return l;
}

void dfs(int i)
{
    string r = str(i);
    int l = length(i);

    if (i > n) {return;}

    toprint += ' ';

    toprint += r;

    fout << toprint << '\n';
    dfs(i + 1);

    toprint.pop_back();
    while (l)
    {
        toprint.pop_back();
        l--;
    }

    dfs(i + 1);
}

int main()
{
    fin >> n;

    dfs(1);
}
