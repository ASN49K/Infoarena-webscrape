#include <iostream>
#include<fstream>
#define N 100005
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
int x[20];

void print(int k)
{
    int i;
    for(i=1;i<=k;++i)fout<<x[i]<<" ";
    fout<<"\n";
}

void backt(int k)
{
    int i;
    for(i=x[k-1]+1;i<=n;++i)
    {
        x[k]=i;
        print(k);
        if(k<n)backt(k+1);

    }
}

int main()
{
    fin>>n;
    backt(1);

    return 0;
}
