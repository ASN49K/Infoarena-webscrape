#include <fstream>

using namespace std;

ifstream cin("submultimi.in");
ofstream cout("submultimi.out");

int main() {
    int n; cin >> n;
    int limit = (1 << n); // 2^n
    for (int i = 1 ; i < limit ; ++i) {
        int ci = i;
        for (int j = 1 ; j <= n ; ++j) {
            if (ci & 1) cout << j << " ";
            ci >>= 1;
        }
        cout << "\n";
    }
    return 0;
}