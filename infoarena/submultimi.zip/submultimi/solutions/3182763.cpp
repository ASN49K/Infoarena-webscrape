#include <bits/stdc++.h>

using namespace std;

ifstream f ("submultimi.in");
ofstream g ("submultimi.out");

vector<int> v;

void afisare(){
    for(int c : v)
        g << c << ' ';
    g << "\n";
}

void bkt(int poz, int n){
    
    if(poz > n){
        if(v.size())
            afisare();
        return;
    }
    
    bkt(poz +1, n);
    v.push_back(poz);
    bkt(poz +1, n);
    v.pop_back();
    
}

int main()
{
    int n;
    f >> n;
    
    bkt(1, n);

    return 0;
}
