#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    int n,v[50],ok,i;
    cin>>n;v[1]=1;
    for(i=1; i<=n; i++)
    {
        v[i]=0;
    }
    do
    {
        ok=0;
        v[1]++;
        i=1;
        while(i<=n)
        {
            if(v[i]>1)
            {
                v[i]=0;
                v[i+1]++;
            }
            i++;
        }
        i=1;
        while(i<=n)
        {
            if(v[i]==1)
                cout<<i<<" ";
            else
                ok=1;
            i++;
        }
        cout<<endl;
    }
    while(ok);
    return 0;
}
