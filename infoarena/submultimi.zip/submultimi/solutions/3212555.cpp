#include<bits/stdc++.h>

using namespace std;

vector<int> v;
int n;

void afisare()
{
    for(int i = 1; i < v.size(); i++)
        cout << v[i] << " ";
    cout << "\n";
}

void bkt()
{
    afisare();
    for(int i = v.back() + 1; i <= n; i++)
    {
        v.push_back(i);
        bkt();
        v.pop_back();
    }
}

int main()
{
    freopen("submultimi.in", "r", stdin);
    freopen("submultimi.out", "w", stdout);

    cin >> n;

    v.push_back(0);
    bkt();
}