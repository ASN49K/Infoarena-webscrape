#include <fstream>
using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");
int n,i,j,lim,kk;
int pow2[17]={1,2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384,32768,65536};
int main()
{
    ios_base::sync_with_stdio(false);
    in.tie(0),out.tie(0);
    in>>n;
    lim=pow2[n]-1;
    for(j=1;j<=lim;++j)
    {
        kk=j;
        for(i=1;i<=n and kk;++i)
        {
            if(kk&1)
                out<<i<<" ";
            kk/=2;
        }
        out<<'\n';
    }
    return 0;
}
