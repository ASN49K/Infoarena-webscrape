#include <stdio.h>

inline void print(int n) {
	char snum[65];
	int i = 0;
	do {
		snum[i++] = n % 10 + '0';
		n /= 10;
	} while (n);

	--i;

	while (i >= 0) {
		putchar(snum[i--]);
	}

	putchar(' ');
}

inline int read() {
	int n = 0;
	char c = getchar_unlocked();

	while (!('0' <= c && c <= '9')) {
		c = getchar_unlocked();
	}

	while ('0' <= c && c <= '9') {
		n = (n << 3) + (n << 1) + (c - '0');
		c = getchar_unlocked();
	}

	return n;
}

int main() {
	freopen("submultimi.in", "r", stdin);
	freopen("submultimi.out", "w", stdout);
	int n;

	n = read();
	for (int i = 1 ; i < (1 << n) ; ++i) {
		for (int j = 1 ; j <= n ; ++j) {
			if (i & (1 << (j - 1))) {
				print(j);
			}
		}

		putchar('\n');
	}

	return 0;
}