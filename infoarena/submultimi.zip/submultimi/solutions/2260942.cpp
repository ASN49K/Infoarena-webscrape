#include <iostream>
#include <fstream>
using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");
int n;
bool a[20],ok=0;
void bacK(int k)
{
    for(int i=0;i<=1;i++)
    {
        a[k]=i;
        if(k==n)
        {
            ok=0;
            for(int j=1;j<=k;j++)
            {
                if(a[j]==1)
                    {out<<j<<' ';ok=1;}
            }
            if(ok)
            out<<'\n';
        }
        else
        bacK(k+1);
    }
}
int main()
{
    in>>n;
    bacK(1);
    return 0;
}
