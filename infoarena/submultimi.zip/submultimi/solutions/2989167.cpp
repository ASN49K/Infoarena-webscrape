#include <bits/stdc++.h>
using namespace std;
///=================
#define swap(a,b) a^=b^=a^=b
#define max(a,b) a>b?a:b
#define min(a,b) a<b?a:b
const string file_name = "submultimi";
ifstream fin(file_name + ".in");
ofstream fout(file_name + ".out");

int a[30], v[30], n, fn = 0;

void afisare(){
    for(int i = 1; i <= fn; i++){
        fout << v[i] << " ";
    }
    fout << "\n";
}

void bck(int k){
    for(int i = 1; i <= n; i++){
        if(a[i] == 0 && v[k - 1] < i){
            a[i] = 1;
            v[k] = i;

            fn = k;
            afisare();
            if(k < n)
                bck(k + 1);

            a[i] = 0;
        }

    }
}

int main(){

    fin >> n;

    bck(1);

    return 0;
}
