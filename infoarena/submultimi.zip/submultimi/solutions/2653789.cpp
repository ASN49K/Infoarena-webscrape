#include <fstream>
using namespace std;
int n,x[17];
ifstream f("submultimi.in"); ofstream g("submultimi.out");
inline void afis()
{   int s=0;
    for(int i=1; i<=n; i++)
    {   s+=x[i];
        if(x[i]==1) g<<i<<' ';
    }
    if(s>0) g<<'\n';
}
void back(int k)
{   for(int i=0;i<=1;i++)
    {   x[k]=i;
        if(k==n) afis(); else back(k+1);
    }
}
int main()
{   f>>n;
    back(1);
    g.close(); return 0;
}
