#include <bits/stdc++.h>

using namespace std;
using ll = long long;

ifstream fin( "submultimi.in" );
ofstream fout( "submultimi.out" );

const int DIM = 16;

int main() {
  ios_base::sync_with_stdio(0);
  fin.tie(0);
  int n;

  fin >> n;
  for ( int q = 1; q < (1 << n); ++q ) {
	for ( int b = 0; b < n; ++b ) {
	  if ( q & (1 << b) ) fout << b + 1 << " ";
	}
	fout << "\n";
  }
  return 0;
}

