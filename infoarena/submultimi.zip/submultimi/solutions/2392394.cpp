#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n; vector<int> st;

void bk(int pas){
    if(pas == n) {
        if(!st.empty()){
            for(int i = 0; i < st.size(); i++){
            g << st[i] << " ";
        }
        g << "\n";
        }
        return;
    }
    bk(pas+1);
    st.push_back(pas+1);
    bk(pas+1);
    st.pop_back();
}

int main(){
    f >> n;
    bk(0);
}
