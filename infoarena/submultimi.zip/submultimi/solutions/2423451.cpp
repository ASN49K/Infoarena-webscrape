#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
int st[20];

void Afisare()
{
    int i, nr1=0;

    for(i=1;i<=n;++i)
        nr1+=st[i];
    if(nr1==0)
        return;

    for(i=1;i<=n;++i)
        if(st[i]==1)
            fout<<i<<" ";
    fout<<"\n";
}

void Back(int k)
{
    if(k==n+1)
        Afisare();
    else
    {
        //cout<<"k="<<k<<"\n";
        int i;
        for(i=0;i<=1;i++)
        {
            //daca st[i]==1, inseamna ca i apare in submultimea
            //respective
            st[k] = i;
            Back(k+1);
        }
    }

}

int main()
{

    fin>>n;
    Back(1);

    return 0;
}
