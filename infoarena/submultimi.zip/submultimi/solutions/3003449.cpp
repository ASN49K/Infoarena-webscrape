#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
const int Nmax=20;
int v[Nmax],f[Nmax],ni;
void solve(int n,int lasti)
{
    for(int i=1;i<=n;i++)
    {
        fout<<v[i]<<' ';
        if(i==n) fout<<'\n';
    }
    if(n==ni)
    {
        v[ni]=0;
        f[ni]=0;
        return;
    }
    else
    {
        for(int i=lasti+1;i<=ni;i++)
        {
            if(f[i]==0)
            {
                v[n+1]=i;
                f[i]=1;
                solve(n+1,i);
                f[i]=0;
                v[n+1]=0;
            }
        }
        return;
    }
}
int main()
{
    int n;
    fin>>n;
    ni=n;
    solve(0,0);
    return 0;
}
