﻿#include <bits/stdc++.h>
#include <unordered_map>
using namespace std;
#define ll long long 
#define ull unsigned long long 
#define nmax 3000006
#define MOD 1999999973 
#define INF 2123456789
//#define fin cin 
//#define fout cout 

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
int st[nmax];
int viz[nmax];

void Afis(int lg)
{
	for (int i = 1; i <= lg; i++)
		fout << st[i] << " ";
	fout << "\n";
}

void Back(int top)
{

	for (int i = top; i <= n; i++)
		if (!viz[i])
		{
			st[top] = i;
			viz[i] = 1;
			Afis(top);
			Back(top + 1);
			viz[i] = 0;
		}
}

int main()
{
	int i, j;
	fin >> n;
	Back(1);
	fin.close();
	fout.close();
	return 0;
}