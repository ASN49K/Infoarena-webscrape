#include <iostream>
#include <fstream>
using namespace std;

int N,K,c,v[18],i,nr,ok,p,n;

ifstream f("submultimi.in");
ofstream g("submultimi.out");
int valid(int a)
{   if(a==1)
        return 1;
    for(i=1; i<a; i++)
        if(v[i]>=v[a])
            return 0;
        return 1;
}
int solutie(int a)
{
    if(a==K)
        return 1;
        return 0;
}

void afisare()
{

    for(i=1; i<=K; i++)
       g<<v[i]<<" ";
        g<<"\n";

}


void combinari(int N, int K)
{
        c=1;
while(c>0)
{
    do
        v[c]++;
    while((valid(c)==0)&&(v[c]<N-K+c));

    if(v[c]<=N-K+c)
            {   if(solutie(c))
                afisare();
                    else
                        {c++;
                        v[c]=v[c-1];
                        }
            }
    else
        {   v[c]=0;
            c--;
        }


}
}

int main()
{
    f>>N;
    for(int i=1; i<=N; i++)
 {K=i;
  combinari(N,K);

}

return 0;
}

