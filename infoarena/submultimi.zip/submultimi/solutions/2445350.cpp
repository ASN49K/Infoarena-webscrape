#include <fstream>
using namespace std;

int n, x[17], nrsol = 0;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

void afis(int k)
{
    nrsol++;
    for(int i = 1; i <= k; i++)
        g << x[i] << ' ';
    g << "\n";
}

void backt()
{
    int k = 1;
    x[1] = 0;
    while(k > 0)
    {
        if(x[k] < n)
        {
            x[k]++;
            afis(k);
            k++;
            x[k] = x[k - 1];
        }
        else
            k--;
    }
}

int main()
{
    f >> n;
    x[0] = 0;
    backt();
    return 0;
}
