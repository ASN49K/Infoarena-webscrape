#include<fstream>
#include<algorithm>

using namespace std;

ifstream cin("submultimi.in");
ofstream cout("submultimi.out");

int v[20],n;
int main()  {
    int p=1;
    cin>>n;
    for(int i=n;i>0;i--,p*=2);
    for(int i=p-1;i>0;i--){
        for(int j=1,bit=1;j<=i;j*=2,++bit){
            if(i&j)
                cout<<bit<<' ';
        }
        cout<<'\n';
    }
    return 0;
}
