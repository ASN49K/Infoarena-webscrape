#include<bits/stdc++.h>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

const int NMAX = 21;
int v[NMAX], n, i, j;

int main()
{
    fin>> n;
    int x = (1<<n);
    for(i = 1; i < x; i++)
    {
        for(j = 0; j < n; j++)
        {
            if(x & (1 << j))
                fout<< j+1<<" ";
        }
        fout<<'\n';
    }
    fin.close();
    fout.close();
    return 0;
}
