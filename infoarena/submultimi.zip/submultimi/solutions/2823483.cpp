#include <bits/stdc++.h>
#define DAU ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#define PLEC return 0;

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
#define cin fin
#define cout fout

#define N 500005
int n, v[N];

void afis(int k)
{
    for(int i = 1 ; i <= k ; i++)cout << v[i] << " ";
    cout << '\n';
}
void fa(int k)
{
    for(int i = v[k-1]+1 ; i <= n ; i++)
    {
        v[k] = i;
        afis(k);
        if(k < n)fa(k+1);
    }
}

int main()
{
    DAU
    cin >> n;
    fa(1);
    PLEC
}
