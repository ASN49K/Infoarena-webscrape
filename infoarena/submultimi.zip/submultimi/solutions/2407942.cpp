#include <fstream>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n;
int st[20];
int k;

void tipar(){
    int i;
    for(i = 1 ; i <= k ; i++)
        g << st[i] << " ";
    g << "\n";
}

bool valid(int k){
    int i;
    for(i = 1 ; i < k ; i++)
        if(st[i] == st[k] || st[i] > st[i + 1])
            return 0;

    return 1;
}

void back(){
    k = 1;
    st[k] = 0;
    while(k){
        while(st[k] < n){
            st[k]++;

            if(valid(k)){
                tipar();
                if(k != n){
                    k++;
                    st[k] = 0;
                }
            }
            /*else{
                k++;
                st[k] = 0;
            }*/
        }
        k--;
    }

}

int main(){
    f >> n;
    back();

    return 0;
}
