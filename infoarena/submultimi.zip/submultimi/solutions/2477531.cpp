#include <fstream>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
int x[17];

void afisare(int k)
{
    for(int i=1; i<=k; i++)
        fout<<x[i]<<" ";
    fout<<"\n";
}

void Back(int k)
{
    for(int i=x[k-1]+1; i<=n; i++)
        {
            x[k]=i;
            afisare(k);
            if(x[k]<n) Back(k+1);
        }
}
int main()
{
    fin>>n;
    Back(1);
    return 0;
}
