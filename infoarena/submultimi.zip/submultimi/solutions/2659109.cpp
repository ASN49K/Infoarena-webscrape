#include <fstream>
#include <iostream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int sol[20];
int viz[20];
int n;

void afisare(int limita)
{
    for(int i = 0; i < limita; i++)
        fout << sol[i] << ' ';
    fout << '\n';
}

/*int valid(int k)
{
    for(int i = 0 ; i <= k - 1; i++)
        if(sol[i] >= sol[k])
            return 0;
    return 1;
}*/

void backtracking(int k, int limita)
{
    if(k == limita)
    {
        afisare(limita);
        return;
    }
    for(int i = 0 ; i < n; i++)
    {
        if(viz[i] == 0 && ((k == 0 || limita == 1) || (sol[k-1] < i+1)))
        {
            viz[i] = 1;
            sol[k] = i+1;
            backtracking(k+1, limita);
            viz[i] = 0;
        }
    }
}

int main()
{
    fin >> n;
    for(int i = 1 ; i <= n; i++)
        backtracking(0,i);
    return 0;

}
