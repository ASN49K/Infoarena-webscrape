#include <bits/stdc++.h>

using namespace std;

int N;

int main()
{
    ifstream cin("submultimi.in");
    ofstream cout("submultimi.out");
    cin >> N;
    
    for (int b = 0; b < (1 << N); b++)
    {
        vector<int> subset;
        for (int i = 0; i < N; i++)
        {
            if (b&(1<<i)) subset.push_back(i);
        }
        for (auto val : subset)
            cout << val << " ";
    }
    
    return 0;
}