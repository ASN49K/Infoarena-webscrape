#include <iostream>
using namespace std;
ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n,k,v[20];


void bt(int nivel)
{
    int i;
    for(i = v[nivel-1] + 1;i <= n;i++)
    {
        v[nivel]=i;
        for(int j=1;j<=nivel;j++)
            fout<<v[j]<<" ";
        fout<<'\n';

        if(nivel<n)
            bt(nivel+1);
    }
}

int main()
{
    fin>>n;
    bt(1);
    return 0;

}

