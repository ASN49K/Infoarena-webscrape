#include <bits/stdc++.h>
using namespace std;

ifstream f ("submultimi.in");
ofstream g ("submultimi.out");

int v[1003], n;

void solve(int lvl)
{
    if (lvl == n + 1)
        return;

    for (int i = v[lvl - 1] + 1; i <= n; ++i)
    {
        v[lvl] = i;

        for (int j = 1; j <= lvl; ++j)
            g << v[j] << ' ';
        g << '\n';

        solve(lvl + 1);
    }
}

int main()
{
    f >> n;

    solve(1);

    return 0;
}
