#include <fstream>
using namespace std;
int n, val, i, j;
int main ()
{
    ifstream fin ("submultimi.in");
    ofstream fout ("submultimi.out");
    fin>>n;
    val=(1<<n);
    for (i=1; i<val; i++)
    {
        for (j=0; j<n; j++)
            if ((i & (1<<j))==(1<<j))
                fout<<j+1<<" ";
        fout<<"\n";
    }
}
