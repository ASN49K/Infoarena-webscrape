#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
int n;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

void back(vector<int> &res, int k) {
    if (k >= n) {
        return;
    }

    for (int i = res[k - 1] + 1; i <= n; i++) {
        res[k] = i;

        for (int i = 1; i <= k; i++) {
            cout << res[i] << ' ';
        }
        cout << "\n";

        back(res, k + 1);
    }
}

int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */   
    
    fin >> n;
    
    if (n == 0) {
        fout << -1;
        return 0;
    }

    vector<int> res(n, 0);
    
    back(res, 1);

    fin.close();
    fout.close();
    
    return 0;
}