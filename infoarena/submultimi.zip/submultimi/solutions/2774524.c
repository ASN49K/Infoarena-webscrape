#include<stdio.h>
int n,p,k,i,j,s[17];
int main()
{
	freopen("submultimi.in","r",stdin),freopen("submultimi.out","w",stdout),scanf("%d",&n);
	for(p=1;p<=n;++p)
        for(k=1,s[k]=0;k;) {
            for(++s[k],j=i=1;i<k&&j;++i)
                if(s[i]==s[k])
                    j=0;
            if(j)
                if(s[k]<=n)
                    if(k==p) {
                        for(i=1;i<=k;++i)
                            printf("%d ",s[i]);
                        printf("\n");
                    } else
                        ++k,s[k]=s[k-1];
                else
                    --k;
        }
    return 0;
}
