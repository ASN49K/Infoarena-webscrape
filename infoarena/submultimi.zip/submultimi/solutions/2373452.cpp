#include <iostream>
#include <fstream>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n, v[20];

void backtracking()
{
    for(int i = 1; i <= v[0]; i++)
        g << v[i];
    if(v[0])
        g << "\n";
    for(int i = v[v[0]] + 1; i <= n; i++)
    {
        v[++v[0]]=i;
        backtracking();
        v[v[0]] = 0;
        v[0]--;
    }
}

int main(){
    f >> n;
    backtracking();
    return 0;
}
