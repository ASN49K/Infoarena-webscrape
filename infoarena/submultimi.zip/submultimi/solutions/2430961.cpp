#include <bits/stdc++.h> //JuniorMonster a.k.a Sho10
#define ll long long
#define all(a) (a).begin(), (a).end()
#define sz size
#define f first
#define s second
#define pb push_back
#define er erase
#define in insert
#define mp make_pair
#define pi pair
#define rc(s) return cout<<s,0
#define mod 1000000007
#define PI 3.14159265359
#define CODE_START  ios_base::sync_with_stdio();cin.tie(0);cout.tie(0);
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
ll n,p;
vector<ll>v;
void fffout(){
if(v.size()!=0){
   for(ll i=0;i<v.size();i++)
        fout<<v[i]<<' ';
   fout<<endl;
}
}
void sol(ll k){
if(k==n) fffout();
else {
    sol(k+1);
    v.pb(k+1);
    sol(k+1);
        v.pop_back();
}
}
int main(){
fin>>n;
p=(1<<n);
sol(0);
return 0;}
