#include <fstream>

using namespace std;

ifstream cin("submultimi.in");
ofstream cout("submultimi.out");

int main()
{
    int n;
    cin>>n;
    int pow2=1<<n;
    for(int i=1;i<pow2;i++)
    {
        int nr=1;
        int ci=i;
        while(ci>0)
        {
            if(ci%2==1)
                cout<<nr<<" ";
            nr++;
            ci/=2;
        }
        cout<<"\n";
    }

    return 0;
}
