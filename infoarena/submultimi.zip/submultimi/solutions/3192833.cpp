#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");

vector<int> subm;

void afis ()
{
    for(int i=0; i<subm.size(); ++i)
        out<<subm[i]<<" ";
    out<<'\n';
}
void bkt(int nr_c, int n)
{
    if(nr_c > n)
    {
        afis();
        return;
    }
    subm.push_back(nr_c);
    bkt(nr_c+1, n);
    subm.pop_back();
    bkt(nr_c+1, n);
}

int main()
{
    int n;
    in>>n;
    bkt(1,n);
    return 0;
}
