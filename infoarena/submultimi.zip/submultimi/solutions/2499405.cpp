#include <cstdio>
#include <vector>
using namespace std;
int N;

const int VMAX = (1 << 18);
// could use a map with 18 entries
int whichBit[VMAX];

inline int lsb(int mask) {
	return mask ^ (mask & (mask - 1));
}

void recons(int mask) {
	while (mask) {
		int leastBitValue = lsb(mask);
		printf("%d ", whichBit[leastBitValue]);
		mask ^= leastBitValue;
	}

	printf("\n");
}

int main() {
	freopen("submultimi.in", "r", stdin);
	freopen("submultimi.out", "w", stdout);

	scanf("%d", &N);
	for (int bit = 1; bit <= N; bit++) {
		whichBit[1 << (bit - 1)] = bit;
	}

	for (int mask = 1; mask < (1 << N); mask++) {
		recons(mask);
	}
	return 0;
}