#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;

bool f[30];
int v[30];

void backt(int pas)
{
    for(int i=v[pas-1]+1;i<=n;i++)
    {
        if(!f[i])
        {
            f[i]=true;
            v[pas]=i;
            for(int j=1;j<=pas;j++)
            {
                fout<<v[j]<<' ';
            }
            fout<<'\n';
            backt(pas+1);
            f[i]=false;
        }
    }
}

int main()
{
    fin>>n;
    backt(1);
}
