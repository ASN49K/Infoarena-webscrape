#include <stdio.h>

int main()
{
    freopen("submultimi.in", "r", stdin);
    freopen("submultimi.out", "w", stdout);

    int N, k = -1; char buffer[2000000];

    scanf("%d", &N);

    for(int i = 1 << N; --i;)
    {
        for(int d = 0; i >> d;)
        {
            if(i >> d++ & 1)
            {
                if(d > 9)
                {
                    buffer[++k] = d / 10 + 48;

                    buffer[++k] = d % 10 + 48;
                }
                else
                {
                    buffer[++k] = d + 48;
                }

                buffer[++k] = ' ';
            }
        }

        buffer[++k] = '\n';
    }

    buffer[k] = '\0';

    puts(buffer);

    return 0;
}
