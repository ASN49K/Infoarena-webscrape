#include <fstream>
#include <cmath>

using namespace std;

ifstream cin("pikachu.in");
ofstream cout("pikachu.out");

long long a[20005];
int s[10005], v[10005];

int n;

void initializare(int nod, int st, int dr)
{
    if(st==dr)
    {
        if(st<=n)
            a[nod]=v[st];
        return;
    }
    int med=(st+dr)/2;
    initializare(2*nod, st, med);
    initializare(2*nod+1, med+1, dr);
}

void update(int nod, int st, int dr, int val, int ust, int udr)
{
    if(st==dr && ust<=st && udr>=st)
    {
        if(st<=n)
            a[nod]=abs(v[st]-val);
        return;
    }
    int med=(st+dr)/2;
    if(med>=ust)
        update(2*nod, st, med, val, ust, udr);
    if(med<udr)
        update(2*nod+1, med+1, dr, val, ust, udr);
    a[nod]=a[2*nod]+a[2*nod+1];
}

long long query(int nod, int st, int dr, int qst, int qdr)
{
    if(st>=qst && dr<=qdr)
    {
        return a[nod];
    }
    int med=(st+dr)/2;
    long long sum=0;
    if(med>=qst)
        sum+=query(2*nod, st, med, qst, qdr);
    if(med<qdr)
        sum+=query(2*nod+1, med+1, dr, qst, qdr);
    return sum;
}

int main()
{
    int k;
    cin>>n>>k;
    int m=pow(2, floor(log2(n))+!(log2(n)==floor(log2(n))));
    for(int i=1;i<=n;i++)
    {
        cin>>v[i];
        s[i]=s[i-1]+v[i];
    }
    initializare(1,1,m);

    /*for(int i=1;i<2*m;i++)
            cout<<a[i]<<" ";
        cout<<'\n';*/

    long long minim=1e18;
    for(int i=1;i+k-1<=n;i++)
    {
        long long mij=(s[i+k-1]-s[i-1])/k;
        //cout<<mij<<'\n';
        update(1,1,m,mij,i, i+k-1);
        /*for(int i=1;i<2*m;i++)
            cout<<a[i]<<" ";
        cout<<'\n';*/
        minim=min(minim, query(1,1,m, i, i+k-1));
    }
    cout<<minim<<'\n';
    return 0;
}
