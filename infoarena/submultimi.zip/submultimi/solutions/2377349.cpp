#include <bits/stdc++.h>
using namespace std;
int main(){
    register int16_t n,x[25];
    freopen("submultimi.in","r",stdin);
    freopen("submultimi.out","w",stdout);
    cin>>n;
    register int16_t i,j,l;
    for(i=1;i<=17;i++) x[i]=i;
    for(i=1;i<=(1<<n)-1;i++)
    {
        l=1;
        j=i;
        while(j)
        {
            if(j&1) cout << x[l]<< " ";
            l++;
            j=(j>>1);
        }
        cout<<"\n";
    }
}
