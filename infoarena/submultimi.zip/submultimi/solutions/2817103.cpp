#include <bits/stdc++.h>

using namespace std;

int main()
{
    ifstream fin("submultimi.in");
    ofstream fout("submultimi.out");
    int n,bit,a;
    fin >> n;
    for (int mask = 1;mask < (1 << n);mask++) {
        bit = 0;
        a = mask;
        while (a) {
            if ((a & (1 << bit))) {
                fout << bit + 1 << ' ';
                a ^= (1 << bit);
            }
            bit++;
        }
        fout << '\n';
    }
    return 0;
}
