#include <fstream>
#include <iostream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, m, x[17];

void afis(int n)
{
    for(int i=1 ; i<=n ; ++i)
        fout << x[i] << " ";
    fout << endl;
}

void bt(int k)
{
    for(int i=x[k-1]+1; i<=n; i++)
    {
        x[k]=i;
        afis(k);
        bt(k+1);
    }
}

int main()
{
    fin >> n >> m;
    bt(1);
    return 0;
}
