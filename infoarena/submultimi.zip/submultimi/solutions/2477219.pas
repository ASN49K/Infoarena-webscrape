﻿var folosit:array[1..17] of boolean;
var a,b,i,e,j,k,l,n:longint;
fin,fout:textfile;
procedure backtrack(now:longint);
var i,e,j,l:longint;
begin
if now<=n then begin
  folosit[now]:=true;
  backtrack(now+1);
  folosit[now]:=false;
  backtrack(now+1);
  end
else begin
   for i:=1 to n do if folosit[i]=true then write(fout,i,' ');
  writeln(fout);
  end;
end;

begin
assign(fin,'submultimi.in');
reset(fin);
assign(fout,'submultimi.out');
rewrite(fout);
read(fin,n);
backtrack(1);







close(fin);
close(fout);
end.