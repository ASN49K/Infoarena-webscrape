#include <iostream>

using namespace std;

void help (int cod, int q)
{
    if (cod != 0)
    {
        help(cod/2, q-1);
        if (cod%2==1)
            cout << q << ' ';
    }
    else
        return;
}

int main()
{
    freopen("submultimi.in", "r", stdin);
    freopen("submultimi.out", "w", stdout);
    int n;
    cin >> n;
    int coSub = 1;
    for (int i = 0; i < n; i++)
        coSub *= 2;

    for (int cod = 1; cod < coSub; cod++)
    {
        help(cod, n);
        cout << '\n';
    }
    return 0;
}
