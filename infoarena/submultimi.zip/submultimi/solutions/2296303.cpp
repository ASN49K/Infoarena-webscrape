#include <fstream>

using namespace std;
int n,x[20],viz[20],kk;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
void Afisare()
{
    int afis=0;
    for(int i=1;i<=n;i++)
        if(x[i]==1) {fout<<i<<" ";afis=1;}
    if(afis==1) fout<<"\n";
}
void Back(int k)
{
    for(int i=0;i<=1;i++)
    {

            x[k]=i;
            if(k==n) Afisare();
            else Back(k+1);
    }
}
int main()
{
    fin>>n;
    Back(1);
    return 0;
}


