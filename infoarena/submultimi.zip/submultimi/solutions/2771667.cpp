#include <fstream>
using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int N, K, x[19];

void read()
{
    f >> N;
}

void afis(int k)
{
    for(int i = 1; i <= k; i++)
        g << x[i] << ' ';
    g << '\n';
}

void backt(int k)
{
    for(int i = x[k - 1] + 1; i <= N; i++)
    {
        x[k] = i;
        afis(k);
        if(k<N)
            backt(k + 1);
    }
}

int main()
{
    read();
    backt(1);
    return 0;
}
