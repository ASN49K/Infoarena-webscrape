#include <bits/stdc++.h>
#define NMAX 500
#define MMAX 12
#define ll long long
#define ull unsigned long long

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, st, dr;

int main() {
    fin >> n;
    st = 1, dr = (1 << n) - 1;
    while (st <= dr) {
        for (int i = 0; i < n; i++) {
            if (st & (1 << i)) {
                fout << i + 1 << ' ';
            }
        }
        fout << '\n';
        st++;
    }
    return 0;
}
