/*#include <bits/stdc++.h>
#define MAXN 8

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, sol[MAXN];
bool fr[MAXN + 1];
void afisare() {
    for (int i = 0; i < n; i++)
        fout << sol[i] << ' ';
    fout << '\n';
}

void back(int k = 0) {
    if (k == n) {
        afisare();
    }
    for (int i = 1; i <= n; i++) {
        if (fr[i])
            continue;
        fr[i] = true;
        sol[k] = i;
        back(k + 1);
        fr[i] = false;
    }
}

int main() {
    fin >> n;
    back();
    return 0;
}*/

//implementat si cu stl ca de ce nu
#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int main() {
    int n;
    fin >> n;
    vector<int> arr;
    for (int i = 1; i <= n; i++)
        arr.push_back(i);
    do {
        for (auto &val: arr)
            fout << val << ' ';
        fout << '\n';
    } while (next_permutation(arr.begin(), arr.end()));
    return 0;
}