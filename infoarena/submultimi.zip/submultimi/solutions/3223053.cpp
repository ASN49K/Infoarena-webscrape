#include<fstream>
using namespace std;
ifstream F("submultimi.in");
ofstream G("submultimi.out");
int n,i,j;
int main()
{
    for(F>>n,i=1;i<1<<n;G<<'\n',++i)
        for(j=0;j<n;++j)
            if(i&(1<<j))
                G<<j+1<<' ';
    return 0;
}
