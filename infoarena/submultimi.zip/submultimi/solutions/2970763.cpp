#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
#define pb push_back
#define mp make_pair
#define f first
#define s second

int n;
void all_subarr(int l, vi &a){
    if(l == n+1){
        if(a.size() == 0)
            return;
        for(auto i : a)
            cout << i << ' ';
        cout << '\n';
    } else {
        a.pb(l);
        all_subarr(l+1, a);
        a.erase(a.end()-1);
        all_subarr(l+1, a);
    }
}
 
void solve(){
    cin >> n;
    vi a = {};
    all_subarr(1, a);
}  
 
int main(){
    freopen("submultimi.in", "r", stdin);
    freopen("submultimi.out", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}