#include <bits/stdc++.h>

using namespace std;

int main()
{
    ifstream fin("submultimi.in");
    ofstream fout("submultimi.out");
    int n;
    fin >> n;

    int a[n]{};
    while(a[0] != 1){

        int i = n;

        while(a[i] == 1){
            a[i] = 0;
            i--;
        }

        a[i] = 1;

        for(int i = 1; i <= n; i++){
            if(a[i] == 1)
                fout << i << " ";
        }
        fout << endl;
    }
    return 0;
}