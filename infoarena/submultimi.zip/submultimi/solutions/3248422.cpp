

#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n, v[1001], cnt;
int main()
{     
    fin >> n;
    
    while (v[0] != 1)
    {
        int i= n;
        while (v[i]==1)
        {
            v[i] = 0;
            i--;

        }
        v[i] = 1;
        for (int j = n; j >= 1; j--)
        {
            if (v[j] == 1)
            {
                fout << j<<' ';
            }
        }
        fout << endl;
    }
    return 0;
   
}




