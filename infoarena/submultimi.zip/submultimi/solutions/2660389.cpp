	
#include <bits/stdc++.h>
using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int n,l,m;
int main()
{
    f>>n;
    l= 1<<n;
    for(int i=1;i<l;i++)
    {
        int d=i;
        for(int j=1;j<=n;j++)
        {
            if(d%2)g<<j<<' ';
            d/=2;
        }
        g<<'\n';
    }
    return 0;
}