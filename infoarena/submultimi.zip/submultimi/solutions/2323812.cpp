#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n, k, a[17];


void afis()
{
    for(int i = 1; i <= k; i ++)
        g << a[i] << " ";
    g << endl;
}

bool verif(int nr)
{
    if(a[nr] > a[nr - 1])
        return true;
    return false;
}
void BKT(int nr,int k)
{
    for(int i = 1; i <= n; i ++)
    {
        a[nr] = i;
        if(verif(nr))
        {
            if(nr == k)
                afis();

            else BKT(nr + 1,k);
        }
    }
}
int main()
{
    f >> n;
    for(k=0;k<=n;k++)
    BKT(1,k);
    return 0;
}
