#include <bits/stdc++.h>

using namespace std;

ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");

const int NM = 25;

int x[NM], n;

void solve (int k){
  for (int i = 1; i <= k; i++){
    fout << x[i] << " ";
  }
  fout << '\n';
}

void back (int k){
  for (int i = x[k - 1] + 1; i <= n; i++){
    x[k] = i;
    solve(k);
    back(k + 1);
  }
}

int main(){
  fin >> n;
  back(1);
}
