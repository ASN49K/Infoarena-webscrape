#include <bits/stdc++.h>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n;

int main()
{
    int i,j,N;
    fin>>n;
    N=(1<<n);
    for (i=1; i<N; i++)
    {
        for (j=0; j<n; j++)
            if ((i&(1<<j))!=0) fout<<j+1<<" ";
        fout<<"\n";
    }
    fout.close();
    return 0;
}
