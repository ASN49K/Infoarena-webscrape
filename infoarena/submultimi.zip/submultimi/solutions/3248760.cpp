#include <fstream>
#include <bitset>
#include <vector>
#include <cmath>

std::string file_name = "submultimi";

std::ifstream fin(file_name + ".in");
std::ofstream fout(file_name + ".out");

std::vector<int> A;

int main() {
    int n;
    fin >> n;

    for (int i = 1; i <= n; ++i)
        A.push_back(i);

    for (int i = 1; i <= pow(2, n) - 1; ++i) {
        std::bitset<16> b(i);

        for (int j = 0; j < n; ++j)
            if (b[j] == 1)
                fout << A[j] << ' ';
        fout << '\n';
    }
}