#include <iostream>
#include <fstream>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n;

int main()
{
    f >> n;
    int p=(1<<n);
    for (int i = 1; i < p; i++)
    {
        for (int j = 0; j < n; j++)
            if(i&(1<<j))
                g << j+1 << " ";
        g << '\n';
    }

    return 0;
}
