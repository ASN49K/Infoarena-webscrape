#include <fstream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int subsets[16], n;

void generate_subsets(int element, int pos) {
	if (element == n + 1) {
		for (int i = 0; i < pos; ++i) {
			fout << subsets[i] << ' ';
		}
		fout << '\n';
		return;
	}
	subsets[pos] = element;
	generate_subsets(element + 1, pos);
	generate_subsets(element + 1, pos + 1);
}

int main() {
	fin >> n;
	generate_subsets(1, 0);
	return 0;
}