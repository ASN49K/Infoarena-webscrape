#include <fstream>
using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int st[16];
int len;
void afisare(){
    for(int i=0;i<len;i++)
        g<<st[i]<<' ';
    g<<'\n';
}
void bkt(int pas,int n){
    if(pas>n){
        afisare();
        return;
    }
    bkt(pas+1,n);
    st[len]=pas;
    len++;
    bkt(pas+1,n);
    len--;
    
}
int main(){
    int n,pas=1;
    f>>n;
    bkt(pas,n);
    f.close();
    g.close();
    return 0;
}