#include <fstream>
using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int x[17],n;
void afis(int k)
{
    for(int i=1;i<=k;i++)
        g<<x[i]<<' ';
    g<<endl;
}
bool valid(int k)
{
    if(k==1)
        return 1;
    if(x[k]<=x[k-1])
        return 0;
    return 1;
}
void subm(int k)
{
    for(int i=1;i<=n;i++)
    {
        x[k]=i;
        if(valid(k))
        {
        afis(k);
        if(k<n)
            subm(k+1);
        }
    }
}
int main()
{
    f>>n;
    subm(1);
    f.close();
    g.close();
    return 0;
}
