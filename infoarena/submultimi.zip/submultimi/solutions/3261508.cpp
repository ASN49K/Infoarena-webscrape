#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main()
{
    int n,a[30];
    fin>>n;
    for(int i=1;i<=n;i++)
        a[i]=0;
    while(1)
    {
        int i=n;
        while(i>0 && a[i]==1)

            {
                a[i]=0;
                i--;
            }
        if(i==0)
            break;
        a[i]=1;
        for(int i=1;i<=n;i++)
            if(a[i])
            fout<<i<<" ";
        fout<<"\n";
    }

    return 0;
}
