#include <cstdio>
#include <cstring>
#include <fstream>
using namespace std;
ifstream cin("submultimi.in");
class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 500) {
            fwrite(buff, 1, 500, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[500]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }
    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};





int main()
{
    int n ;
    cin>>n;
    int p = 1<<n;
    OutParser fout("submultimi.out");
    for(int i = 1;i<p;i++)
    {
        int nr = i, poz = 1;
        while(nr)
        {
            if(nr%2==1)
                fout<<poz<<' ';
            poz++;
            nr/=2;
        }
        fout<<'\n';
    }
    return 0;
}
