#!/usr/bin/env python3

import itertools, sys

sys.stdout = open('submultimi.out', 'w')

with open('submultimi.in', 'r') as fin:
    n = int(fin.readline())
    for c in sorted(itertools.chain.from_iterable(itertools.combinations(range(1, n + 1), k) for k in range(1, n + 1))):
        print(' '.join(map(str, c)))
