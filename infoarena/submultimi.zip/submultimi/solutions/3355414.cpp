#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_set>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

vector<vector<int>> res;
unordered_set<int> visited;

void back(int index, int stop, vector<int>& domain, vector<int>& solution) {
	if(index == stop){
		for(int i : solution) {
			fout<<i<<" ";
		}
		fout<<endl;
	}
	for(int i=0;i<domain.size();i++) {
		if(solution.size() != 1 && domain[i] < solution[index-1]) continue;
		if(visited.find(domain[i]) == visited.end()){
			visited.insert(domain[i]);

			solution[index] = domain[i];
			
			back(index+1, stop, domain, solution);

			visited.erase(domain[i]);
		}
	}
}

int main() {

	int n;
	fin>>n;
	vector<int> domain(n);
	for(int i=0;i<n;i++) {
		domain[i] = i + 1;
	}
	for(int i=1;i<=n;i++){ 
		vector<int> solution(i);
		back(0, i, domain, solution);
	}
	return 0;
}