#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int a[100],n;
int afis(int k){
	for(int i=1;i<=k;++i)
		fout<<a[i]<<" ";
	fout<<"\n";
}


int bt(int k){
	for(int i=a[k-1]+1;i<=n;++i){
	
		a[k]=i;
		afis(k);
		bt(k+1);}
}
int main(){
	fin>>n;
	bt(1);
	fin.close();
	fout.close();
	

	
}
