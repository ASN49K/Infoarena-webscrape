#include <fstream>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");
int v[20];
int n;

void afis(int k)
{
    for(int i = 1; i<=k; i++)
    {
        g<<v[i]<<" ";
    }
    g<<'\n';
}

void bk(int k)
{
    for(int i = v[k-1]+1; i<=n; i++)
    {
        v[k] = i;
        afis(k);
        bk(k+1);
    }
}

int main()
{
    f>>n;
    bk(1);
    return 0;
}
