#include <fstream>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submutlimi.out");

int st[16], len=1;

void afisare() {
    int ok=0;
    for (int i=1;i<=len;i++) {
        if (st[i]!=0) {
            ok=1;
            out << st[i] << " ";
        }
    }
    if (ok==1) {
        out << endl;
    }
}

void bkt(int pos, int n) {
    if (pos==n+1) {
        afisare();
        return;
    }
    bkt(pos+1,n);
    st[len]=pos;
    len++;
    bkt(pos+1,n);
    st[len-1]=0;
    len--;
}

int main() {
    int n;
    in >> n;

    bkt(1,n);
}