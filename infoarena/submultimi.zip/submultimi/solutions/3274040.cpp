#include <bits/stdc++.h>
using namespace std;

ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");

int n;

void afis(int nr)
{
    for (int i = 1; i <= n; i++)
        if ((nr & (1 << (i - 1))) != 0)
            fout << i << " ";

    fout << '\n';
}

int main()
{
    fin >> n;
    for (int i = 1; i <= (1 << n); i++)
        afis(i);
    return 0;
}
