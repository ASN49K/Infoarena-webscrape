#include <iostream>
#include <bits/stdc++.h>

using namespace std;
ofstream out("submultimi.out");
ifstream in("submultimi.in");
int n, k;
int perm[20];
int fol[20];

void Back_Permutari(int pas){
    if(pas > k){
        for(int i = 1; i <= k; ++i)
            out << perm[i] << " ";
        out << '\n';
        return;
    }
    for(int i = perm[pas - 1] + 1; i <= n; ++i){
            perm[pas] = i;
            Back_Permutari(pas + 1);
        }
}


int main()
{
    in >> n;
    for(int i = 1; i <= n; ++ i)
    {
        k = i;
        Back_Permutari(1);
    }
    return 0;
}
