#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
#include <deque>
#include <algorithm>
#include <set>
#define Nmax 505
#define INF ((1LL<<62)-1)
#define ll long long
#define MOD 666013
#define fs first
#define sc second

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n;
int p[20];

void afis(int k)
{
    for (int i = 1; i <= k; i++)
        g << p[i] << " ";
    g << '\n';
}

void bkt(int niv, int k)
{
    if (niv-1 == k)
    {
        afis(k);
    }
    else
    {
        for (int i = p[niv-1]+1; i <= n; i++)
        {
            p[niv]=i;
            bkt(niv+1, k);
        }
    }
}

int main()
{
    f >> n;
    for (int i = 1; i <= n; i++)
        bkt(1, i);


    return 0;
}
