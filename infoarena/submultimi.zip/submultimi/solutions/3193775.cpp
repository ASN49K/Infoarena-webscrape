#include <fstream>
#include <cstring>
#include <vector>
using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
vector <int>subm;
void BKT(int nr,int n)
{
    if(nr>n)
    {
        if(subm.size()>0)
        {
             for(int i=0;i<subm.size();i++)
                cout<<subm[i]<<' ';

             cout<<'\n';
        }
        return;
    }
    subm.push_back(nr);
    BKT(nr+1,n);
    subm.pop_back();
    BKT(nr+1,n);
}
int main()
{
    int n;
    cin>>n;
    BKT(1,n);
}
