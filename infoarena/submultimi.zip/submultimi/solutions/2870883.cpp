#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n,st[20];

void afis(int vf)
{
    for(int i=1;i<=vf;i++)
        fout<<st[i]<<' ';
    fout<<'\n';
}
void back(int vf)
{
    for(int x=st[vf-1]+1;x<=n;x++)
    {
        st[vf]=x;
        afis(vf);
        back(vf+1);
    }
}

int main()
{
    fin>>n;
    back(1);
    return 0;
}
