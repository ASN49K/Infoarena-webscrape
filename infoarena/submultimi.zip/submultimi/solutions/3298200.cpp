#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n,v[17];
void back(int k,int depth)
{
    v[depth]=k;
    for(int i=1;i<=depth;i++)
        fout<<v[i]<<" ";
    fout<<'\n';
    for(int i=k+1;i<=n;i++)
        back(i,depth+1);
}
int main()
{
    fin>>n;
    back(1,1);
    return 0;
}
