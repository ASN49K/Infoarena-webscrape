#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n, k, a[20];
int main()
{
    fin >> n;
    a[1] = 1, k = 1;
    while(k > 0){
        for(int i = 1; i <= k; i++){
            fout << a[i] << " ";
        }
        fout << "\n";
        if(a[k] < n){
            k++;
            a[k] = a[k-1]+1;
        }else{
            k--;
            if(k > 0){
                a[k]++;
            }
        }
    }
    return 0;
}