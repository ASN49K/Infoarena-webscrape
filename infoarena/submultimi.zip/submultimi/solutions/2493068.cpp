#include <fstream>
#include <vector>

using namespace std;

ofstream fout("submultimi.out");

int n, viz[17];
vector<int> c;

void comb(int k){
    if(k>1){
        for(auto i : c)
            fout<<i<<' ';
        fout<<'\n';
    }
    for(int i=k;i<=n;i++)
        if(!viz[i]){
            viz[i] = 1;
            c.push_back(i);
            comb(i);
            c.pop_back();
            viz[i] = 0;
        }
}

int main() {
    ifstream fin("submultimi.in");
    fin>>n;
    comb(1);
    return 0;
}