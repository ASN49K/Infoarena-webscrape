#include<iostream>
#include<fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int sol[1000];
int n;
int uz[10000];
void afisare(int n){

    for(int i=1;i<=n;i++)
        fout<<sol[i]<<' ';
    fout<<'\n';

}

void back(int nr){

    if(nr<=n)
    {
        for(int i=1;i<=n;i++){

            if(!uz[i] && i>sol[nr-1]) {
            uz[i]=1;
            sol[nr]=i;
            afisare(nr);
            back(nr+1);
            uz[i]=0;
            }


        }
    }



}


int main(){



fin>>n;
sol[0]=0;
back(1);



 return 0;
}
