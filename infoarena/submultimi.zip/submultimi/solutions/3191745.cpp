#include <fstream>
#include <bitset>
using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
bitset<17>fr;
int n;
int main()
{
    cin>>n;
    while(fr[n]==0){
        int k=0;
        while(fr[k]==1)
            fr[k++]=0;
        fr[k]=1;
        if(k==n)
            break;
        for(int i=1;i<=n;i++)
            if(fr[i-1]==1)
                cout<<i<<" ";
        cout<<'\n';
    }
    return 0;
}
