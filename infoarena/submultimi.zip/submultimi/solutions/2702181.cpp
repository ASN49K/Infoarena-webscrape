#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, c[20];

void submultimi(int element, int lungime) {
    if (element == n + 1) {
        for (int i = 0; i < lungime; ++i) {
            fout << c[i] << " ";
        }
        fout << '\n';
        return ;
    }
    c[lungime] = element;
    submultimi(element + 1, lungime + 1);
    submultimi(element + 1, lungime);
}

int main() {
    fin >> n;
    submultimi(1, 0);
    return 0;
}
