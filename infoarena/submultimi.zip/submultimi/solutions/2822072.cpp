#include <fstream>
#include <vector>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n;
vector <int> v;
void backt(int k)
{
    if(k>n)
    {
        for(int i=0;i<v.size();i++)
        {
            fout<<v[i]<<' ';
        }
        fout<<'\n';
        return;
    }
    backt(k+1);
    v.push_back(k);
    backt(k+1);
    v.pop_back();
}
int main()
{
    fin>>n;
    backt(1);
    return 0;
}
