#include <bits/stdc++.h>

using namespace std;

ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");

int v[10], i, n;

void afis()
{
    for (int i = 1; i <= n; i ++)
        if (v[i]) fout << i << ' ';
    fout << '\n';
}

int main()
{
    fin >> n;

    while (!v[0])
    {
        i = n;
        while (v[i]) v[i] = 0, i --;
        v[i] = 1;
        if (!v[0]) afis();
    }

    return 0;
}
