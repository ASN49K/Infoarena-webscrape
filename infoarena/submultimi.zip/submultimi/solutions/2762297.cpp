#include <fstream>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n,v[17];
void back(int x)
{
    for (int i=v[x-1]+1;i<=n;i++)
    {
        v[x]=i;

            for(int j=1;j<=x;j++)
                g<<v[j]<<" ";
            g<<'\n';
            back(x+1);
    }
}

int main()
{
    f>>n;

        back(1);

   f.close();
   g.close();
}
