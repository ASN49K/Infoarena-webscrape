#include <iostream>
#include<fstream>

using namespace std;
ifstream fin ("submultimi.in");
ofstream fout("submultimi.out");
int i,n,ok,v[100001];
int main()
{
    fin>>n;
    while(1<2)
    {
        ok=0;
        for(i=1; i<=n; i++)
            if(v[i]==0)
            {
                v[i]=1;
                ok=1;
                break;
            }
            else v[i]=0;
        if(ok==1)
        {
            for(i=1; i<=n; i++)
                if(v[i]==1)
                    fout<<i<<" ";
            fout<<endl;

        }
        else
            break;
    }
    return 0;
}
