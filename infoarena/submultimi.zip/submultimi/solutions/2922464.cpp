#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int submult[20];
int n;
void bkt(int len)
{
    if(len == n+1)
    {
        int nr = 0;
        for(int i = 1; i <= n; i++)
        {
            if(submult[i] == 1)
            {
                fout << i << " ";
                nr++;
            }
        }
        if(nr != 0)
            fout << "\n";
        return;
    }
    bkt(len+1);
    submult[len] = 1;
    bkt(len+1);
    submult[len] = 0;
}
int main()
{
    fin >> n;
    bkt(1);
    return 0;
}
