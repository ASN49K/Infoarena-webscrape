#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n,v[17],poz,nr;

void bkt(int poz)
{
    if(poz==n+1)
    {
        for(int i=1; i<=nr; ++i)
        {
            fout<<v[i]<<" " ;
        }
        fout<<"\n";
        return;
    }
    nr++;
    v[nr] = poz;
    bkt(poz + 1);
    nr--;
    bkt(poz + 1);
}

int main()
{
    fin>>n;
    bkt(1);
    return 0;
}
