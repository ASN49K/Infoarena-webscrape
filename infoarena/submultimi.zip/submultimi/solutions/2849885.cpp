#include <fstream>
using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
int n, x[20], i;
void back(int k){
    if(k==n+1){
         for(int i=1;i<=n;i++)
            if(x[i]==1)
                cout<<i<<" ";
        cout<<"\n";
    }
    else
        for(int i=1;i>=0;i--){
            x[k]=i;
            back(k+1);
    }
}
int main(){
    cin>>n;
    back(1);
}
