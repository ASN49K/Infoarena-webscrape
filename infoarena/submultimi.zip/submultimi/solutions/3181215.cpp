#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int stk[16];
int len;
void bkt(int pas,int n){
    if(pas==n+1){
        for(int i=0;i<len;i++){
            fout<<stk[i]<<" ";
        }
        if(len==0){
            return;
        }
        fout<<"\n";
        return;
    }
    bkt(pas+1,n);
    stk[len]=pas;
    len++;
    bkt(pas+1,n);
    stk[len-1]=0;
    len--;
}
int main()
{
    int n;
    fin>>n;
    bkt(1,n);
    return 0;
}
