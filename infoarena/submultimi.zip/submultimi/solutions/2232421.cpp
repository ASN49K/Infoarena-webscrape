#include <fstream>
const std::string programName = "submultimi";
std::ifstream f(programName + ".in");
std::ofstream g(programName + ".out");
void print(int, int[]);
void back(int, int, int, int[]);
int main() {
    int N;
    f >> N;
    int v[20] = {0};
    for (int M = 1; M <= N; ++M)
        back(1, N, M, v);
    return 0x0;
}
void print(int M, int v[]) {
    for (int i = 1; i <= M; ++i)
        g << v[i] << ' ';
    g << "\n";
}
void back(int k, int N, int M, int v[]) {
    if (k == M + 1)
        print(M, v);
    else
        for (v[k] = v[k - 1] + 1; v[k] <= N - M + k; ++v[k])
            back(k + 1, N, M, v);
}
