#include <iostream>
#include <fstream>
using namespace std;
ifstream fi("submultimi.in");
ofstream fo("submultimi.out");

int main()
{
    int N, K = 1;
    fi >> N;
    while(K <= N)
        K <<= 1;
    K <<= 1;

    for(int i = 1; i < K; ++i)
    {
        for(int j = 0; (1 << j) <= i; ++j)
        {
            if((1 << j) & i)
                fo << j + 1 << " ";
        }
        fo << "\n";
    }
}
