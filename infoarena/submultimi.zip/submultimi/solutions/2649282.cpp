#include <bits/stdc++.h>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

int main()
{
	int n;
	in>>n;
	for(int i=1;i<=(1<<n)-1;i++)
	{
		for(int j=1;j<=n;j++)
			if(i&(1<<(j-1)))
				out<<j<<" ";
		out<<"\n";
	}
}
