2#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int submultime[30],len,n;

void backtrack(int val) {
    if (val>n) {
        if (len==0) {
            return;
        }
        for (int i=1; i<=len; ++i) {
            fout<<submultime[i]<<' ';
        }
        fout<<'\n';
    }
    else {
        backtrack(val+1);
        submultime[++len]=val;
        backtrack(val+1);
        len--;
    }
}

int main()
{
    fin>>n;
    backtrack(1);
    return 0;
}
