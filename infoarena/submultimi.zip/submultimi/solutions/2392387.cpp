#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n; vector<int> st;
vector< vector<int> > ans;

void bk(int pas){
    if(pas == n) {
        ans.push_back(st);
        return;
    }
    bk(pas+1);
    st.push_back(pas+1);
    bk(pas+1);
    st.pop_back();
}

int main(){
    f >> n;
    bk(0);
    sort(ans.begin(), ans.end());
    for(int i = 0; i < ans.size(); i++){
        for(int j = 0; j < ans[i].size(); j++){
            g << ans[i][j] << " ";
        }
        g << endl;
    }
}
