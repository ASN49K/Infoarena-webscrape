fi = open("submultimi.in", "r")
fo = open("submultimi.out", "w")

n = int(fi.read())

for i in range(1, (1 << n)):
    #print(i)
    for j in range(0, n):
        if i & (1 << j):
            fo.write(str(j + 1) + " ")
    fo.write("\n")