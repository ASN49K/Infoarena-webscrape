#include <bits/stdc++.h>
using namespace std;
ifstream f ("submultimi.in") ;
ofstream g ("submultimi.out") ;
int N , sol[18];
bool valid(int k)
{
        if (k > N) return false;
        for (int i = 1 ; i <= k - 1 ; ++i)
            if (sol[i] >= sol[k]) return false;

        return true;
}
void afisare( int k )
{
        for (int i = 1 ; i <= k ; ++i)
            g << sol[i] << ' ';
        g << '\n';
}
void Back (int k)
{
    for (int i = 1 ; i <= N ; ++i)
    {
        sol[k] = i;
        if (valid(k))
        {
            afisare(k) ;
            Back(k+1);
        }
    }
}
int main()
{
    f >> N ;
    Back(1) ;
    f.close();
    g.close();
    return 0 ;
}
