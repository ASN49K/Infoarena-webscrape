#include <bits/stdc++.h>
#define N 100001
using namespace std;

/// submultimi
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, s[17];

void backt(int pas){
    for(int i=s[pas-1]+1;i<=n;i++){
        s[pas] = i;
        for(int j=1;j<=pas;j++){
            cout<<s[j]<<" ";
        }
        cout<<'\n';
        if(pas<n)
            backt(pas+1);
    }
}

int main(){
    fin>>n;
    backt(1);
    return 0;
}
