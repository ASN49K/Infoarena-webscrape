#include <bits/stdc++.h>
using namespace std;
ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");
int n, k, sol [20];
void bkt (int poz){
	if (poz == k + 1){
		for (int i = 1; i <= k; i ++)
            fout << sol [i] << " ";
        fout << '\n';
		return ;
	}
	for (int i = sol [poz - 1] + 1; i <= n - k + poz ; i ++)
		sol [poz] = i, bkt (poz + 1);
}
int main (){
	fin >> n;
	for (k = 1; k <= n; k ++)bkt (1);
	return 0;
}
