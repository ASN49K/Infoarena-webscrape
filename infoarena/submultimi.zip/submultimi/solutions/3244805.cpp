#include <bits/stdc++.h>

using namespace std;
ifstream fin("a.in");
ofstream fout("a.out");
int a[20],n,k;
/**
    n=8 1 2 3 4 5 6 7 8
        0 1 0 0 1 1 1 0    {2 5 6 7}
210
000 0
001 1
010 2
011 3
100 4
101 5
110 6
111 7

  6543210
k=1001101 &
  0001000
*/

int main()
{
    int i,k,x,n,N;
    fin>>n;
    N=(1<<n)-1;
    for(k=1; k<=N; k++)
    {
       for(i=0;i<n;i++)
        if(k&(1<<i))fout<<i+1<<" ";
       fout<<'\n';
    }
    return 0;
}

