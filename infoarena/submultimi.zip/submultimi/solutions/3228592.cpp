#include <iostream>
#include <fstream>
using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int x[17], n;
void afis(int k)
{
    for(int i = 1; i <= k; ++ i)
        g << x[i] << " ";
    g << "\n";
}
bool valid(int k)
{
    for(int i = 1; i < k; ++ i)
        if(x[i] >= x[k]) return false;
    return true;
}
void back(int k)
{
    for(int i = 1; i <= n; ++ i)
    {
        x[k] = i;
        if(valid(k))
        {
            afis(k);
            back(k + 1);
        }
    }
}
int main()
{
    f >> n;
    back(1);
    return 0;
}
