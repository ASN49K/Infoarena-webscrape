#include<fstream>
#include<algorithm>
using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");
int main()
{
   int n,i,j;
   in>>n;
   for(i=1;i<=(1<<(n));i++)
   {
        for(j=0;j<n;j++)
           if(i&(1<<j))
              out<<j+1<<" ";
        out<<'\n';
   }
}
