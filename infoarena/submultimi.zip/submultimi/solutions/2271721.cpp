#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int sol[17];
int l = 0;
int n;

void backtracking(int p)
{
    if(p==n+1)
    {
        for(int i=1; i<=l; i++)
            fout<<sol[i]<<' ';
        fout<<'\n';
    }
    else
    {
        l++;
        sol[l] = p;
        backtracking(p+1);
        l--;
        backtracking(p+1);
    }

}

int main()
{
    fin>>n;
    backtracking(1);

    fin.close();
    fout.close();
    return 0;
}
