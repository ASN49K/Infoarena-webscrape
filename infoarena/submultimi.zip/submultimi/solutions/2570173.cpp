#include <bits/stdc++.h>

using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");

int n, v[20];
bool viz[20];

void bkt(int pos)
{
    if(pos > 1)
    {
        for(int i = 1; i < pos; i++)
            out << v[i] << " ";
        out << "\n";
    }

    if(pos > n)
        return ;

    for(int i = v[pos - 1] + 1; i <= n; i++)
        if(!viz[i])
        {
            viz[i] = true;
            v[pos] = i;
            bkt(pos + 1);
            viz[i] = false;
        }

}

int main()
{
    in >> n;
    bkt(1);
}
