#include <iostream>
#include <fstream>
using namespace std;
 ifstream fin("bla.in");
 ofstream fout("bla.out");


int n,v[11];

void afis(int k)
{
  for(int i=1;i<=k;i++)
    fout<<v[i]<<" ";
  fout<<endl;
}

bool valid(int k)
{
   if(v[k]>v[k-1])return true;
   return false;
}

void backtr(int k)
{
  for(int i=1;i<=n;i++)
  {
   v[k]=i;

      if(valid(k)){afis(k);backtr(k+1);}
  }
}

int main()
{
 fin>>n;
  backtr(1);
}
