#include<iostream>
#include<fstream>

using namespace std;

int sol[1000];
int n;
int uz[10000];
void afisare(int n){

    for(int i=1;i<=n;i++)
        cout<<sol[i]<<" ";
    cout<<endl;

}

void back(int nr){

    if(nr<=n)
    {
        for(int i=1;i<=n;i++){

            if(!uz[i] && i>sol[nr-1]) {
            uz[i]=1;
            sol[nr]=i;
            afisare(nr);
            back(nr+1);
            uz[i]=0;
            }


        }
    }



}


int main(){



cin>>n;
sol[0]=0;
back(1);



 return 0;
}
