#include <fstream>

using namespace std;

int n, l;
int v[20], f[20];

ifstream cin ("submultimi.in");
ofstream cout ("submultimi.out");

void backtr(int poz) {
  int i;
  if (poz == l) {
    for (i = 0; i < l; i++)
      cout << v[i] + 1 << " ";
    cout << "\n";
  }
  else {
    for (i = 0; i < n; i++) {
      if ((poz == 0 || i > v[poz - 1]) && f[i] == 0) {
        v[poz] = i;
        f[i]++;
        backtr(poz + 1);
        f[i]--;
      }
    }
  }
}

int main() {
  cin >> n;
  for (l = 1; l <= n; l++)
    backtr(0);
  return 0;
}
