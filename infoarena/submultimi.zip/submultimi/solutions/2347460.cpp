#include <bits/stdc++.h>
#define nmax 100005

using namespace std;

int N, M;

class Solution {
    vector<int>v;

    public:

            Solution() {
            }


        inline void Solve(int cur, int N) {

            for(auto it: v) {
                cout << it <<" ";
            }
            if(v.size() > 0)
            cout << "\n";
            if (cur > N) {
                return;
            }
            for (int i = cur; i <= N; ++i) {
                        v.push_back(i);
                        Solve(i + 1, N);
                        v.pop_back();
            }
        }
};


int main(){
    int i;
    freopen("submultimi.in","r",stdin);
    freopen("submultimi.out","w",stdout);
//    ios::sync_with_stdio(false);
    cin >> N;
    Solution perm;
    perm.Solve(1, N);
    return 0;
}
