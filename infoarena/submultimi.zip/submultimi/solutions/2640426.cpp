#include <bits/stdc++.h>
using namespace std;
const int nmax = 30;
int n;
int v[nmax];

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

void afisare(int k)
{
    for (int i = 1; i <= k; i++)
        fout << v[i] << " ";
    fout << endl;
}

void backtr(int k)
{
    for(int i = v[k - 1] + 1; i <= n; i++)
    {
        v[k] = i;
        afisare(k);
        backtr(k + 1);
    }
}

int main()
{
    fin >> n;
    backtr(1);
}
