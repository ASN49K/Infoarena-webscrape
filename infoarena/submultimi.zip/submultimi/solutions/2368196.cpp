#include<fstream>
using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");
int n,x[17];
void afis(int k){
    for(int i=1 ; i<=k ; ++i)
        out << x[i] << " ";
    out << endl;
}
bool valid(int k){
    if(k == 1)
        return true;
    if(x[k] > x[k-1])
        return true;
    return false;
}
void back(int k){
    for(int i=1;i<=n;++i)
    {
        x[k]=i;
        if(valid(k))
        {
            afis(k);
            back(k+1);
        }
    }
}
int main ()
{
    in>>n;
    back(1);
    return 0;
}
