#include<iostream>
#include<fstream>
using namespace std;
ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");
int n,a[17];

void afisare ( int l)
{
  for( int i=1;i<=l;i++)
    fout<<a[i]<<" ";
  fout<<"\n";
}
void combinari(int k)
{
    for (int i=a[k-1]+1 ;i<=n;i++)
     {
          a[k]=i;
          afisare(k);
          combinari(k+1);
     }
}
int main()
{
  fin>>n;
  combinari(1);
}
