#include <bits/stdc++.h>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int st[20], n;

void Afis(int n)
{
    for (int i = 1; i <= n; i++)
         fout << st[i] << " ";
    fout << "\n";
}

void Back(int top)
{
    if(top>1) Afis(top-1);
    for(int i=st[top-1]+1;i<=n;i++)
    {
        st[top]=i;
        Back(top+1);
    }
}

int main()
{
    fin >> n;
    Back(1);
    return 0;
}
