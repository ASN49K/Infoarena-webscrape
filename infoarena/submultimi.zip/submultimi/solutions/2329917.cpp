#include <fstream>

using namespace std;
ifstream fi("submultimi.in");
ofstream fo("submultimi.out");
const int NMAX=10;
int n,P[NMAX],F[NMAX];
void afisare(int x)
{
	for(int i=1;i<=x;i++)
		fo<<P[i]<<" ";
	fo<<"\n";
}
void bkt(int poz)
{
	if(poz>1 && poz<=n+1)
		afisare(poz-1);
	for(int i=P[poz-1]+1;i<=n;i++)
		if(!F[i])
		{
			P[poz]=i;
			bkt(poz+1);
		}
}
int main()
{
	fi>>n;
	bkt(1);
	fi.close();
	fo.close();
	return 0;
}