#include <bits/stdc++.h>
#define endl '\n'
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main() {
  int n;
  fin>>n;

  for (int i=1; i<(1<<n); ++i) {
    for (int j=0; j<n; ++j) {
      if (i&(1<<j)) fout<<j+1<<" ";
    }
    fout<<endl;
  }
}