#include <bits/stdc++.h>

#define NMAX 17

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, sol[NMAX];

void afisare(int poz) {
    int i;
    if (sol[1]) {
        for (i = 1; i <= poz; i++)
            fout << sol[i] << ' ';
        fout << '\n';
    }
}

void bkt(int poz) {
    int i;
    afisare(poz - 1);
    for (i = sol[poz - 1]+1; i <= n; i++) {
        sol[poz] = i;
        bkt(poz + 1);
        sol[poz] = 0;
    }
}

int main() {
    fin >> n;
    bkt(1);
}