#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int st[20], n;

void Afis(int n)
{
    if (n == 0) return;
    for (int i = 1; i <= n; i++)
        fout << st[i] << " ";
    fout << "\n";
}

void Subm(int top)
{
    Afis(top - 1);
    if (st[top - 1] < n)
    {
        for (int i = st[top - 1] + 1; i <= n; i++)
        {
            st[top] = i;
            Subm(top + 1);
        }
    }
}

int main()
{

    fin >> n;
    Subm(1);
    fin.close();
    fout.close();

    return 0;
}
