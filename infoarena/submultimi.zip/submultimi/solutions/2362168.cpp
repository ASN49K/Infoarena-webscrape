#include <iostream>
#include <fstream>
std::ifstream in("submultimi.in");
std::ofstream out("submultimi.out");

using namespace std;
int N;

int main()
{
    in>>N;
    for(int i = 1 ; i<(1<<N) ;i++)
    {
        for(int j = 0 ; j<16 ; j++)
        {
            if( (1<<j)&i)
            {
                out<<j+1<<" ";
            }
        }
        out<<'\n';
    }
    return 0;
}
