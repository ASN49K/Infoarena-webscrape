#import<fstream>
int i,d;main(){std::ifstream("submultimi.in")>>i;std::ofstream g("submultimi.out");for(i=1<<i;--i;g<<'\n')for(;i>>d;i>>d++&1,g<<d<<' ');}