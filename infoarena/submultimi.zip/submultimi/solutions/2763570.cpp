#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
int main()
{
    fin>>n;
    for(int i=1; i<(1<<n); i++)
    {
        for(int j=1; j<=n; j++)
        {
            int k=((i>>(j-1))&1);
            ///cout<<k<<'\n';
            if(k)
                fout<<j<<' ';
        }
        fout<<'\n';
    }
    return 0;
}
