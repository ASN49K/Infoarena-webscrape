#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n, subm[25];

void gen(int element, int lgSubm) {
  if (element == n + 1) {
    for (int i = 0; i < lgSubm; ++i) {
            if(subm[0] > 0) {
      fout << subm[i] << ' ';
    }}
    if(subm[0] > 0) {
    fout << "\n";}
    return;
  }
  subm[lgSubm] = element;
  gen(element + 1, lgSubm + 1);
  gen(element + 1, lgSubm);
}

int main()
{
    fin >> n;
    int z = 2, copie;
    for(int i = 1; i <= n; ++i) {
        if(z <= n) {
        while(i < z) {
            fout << i << " ";
            i++;
        }
        z++;
        fout << endl;
        i = 0;}
    }
    gen(0, 0);
    return 0;
}
