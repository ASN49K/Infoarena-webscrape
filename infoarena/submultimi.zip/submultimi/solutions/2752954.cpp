#include <fstream>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int N, subm[17];

void gen(int element, int lgSubm) {
    if (element == N + 1) {
        for (int i = 0; i < lgSubm; ++i) {
            fout << subm[i] << " ";
        }
        fout << "\n";
        return;
    }
    subm[lgSubm] = element;
    gen(element + 1, lgSubm + 1);
    gen(element + 1, lgSubm);
}

int main() {
    fin >> N;
    gen(1, 0);
    return 0;
}
