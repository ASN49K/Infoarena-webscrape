#include <iostream>
#include <fstream>

using namespace std;

int n,nr=-1;
int stiva[22];

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

void backt()
{

	for(int i=1 ; i <= stiva[0] ; i++)
		fout<<stiva[i]<<" ";

	if(stiva[0])
		fout<<'\n';

	for(int i = stiva[stiva[0]]+1 ; i <= n ; i++)
	{
		stiva[++stiva[0]]=i;
		backt();
		stiva[stiva[0]]=0;
		stiva[0]--;
	}
}

int main()
{

	fin>>n;
	backt();
	return 0;
}
