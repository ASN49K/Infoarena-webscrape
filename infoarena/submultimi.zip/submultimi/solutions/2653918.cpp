#include <bits/stdc++.h>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int n, m, n2;
int main() {
    fin >> n;
    n2 = (1 << n);
    for (int i=1;i<n2;i++){
        m = i;
        for (int p=1;p<=n;p++){
            if (m%2 == 1)
                fout << p << " ";
            m /= 2;
        }
        fout << '\n';
    }
    return 0;
}