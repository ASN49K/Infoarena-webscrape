#include <bits/stdc++.h>
#define ll long long
#define MOD 1000000007
#define FAST ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#define LONG_MAX 1LL << 63
#define LONG_MIN -1LL << 63
#define INT_MAX 1<<31 -1
#define INT_MIN -1<<31 +1
using namespace std;
string fis="submultimi";
ifstream fin(fis+".in");
ofstream fout(fis+".out");
int n,v[17];
void afisare(int k)
{
    for(int i=1;i<=k;++i)
        fout<<v[i]<<" ";
    fout<<"\n";
}
void bkt(int k)
{
    for(int i=v[k-1]+1;i<=n;++i)
    {
        v[k]=i;
        afisare(k);
        if(v[k]<n)bkt(k+1);
    }
}
int main()
{
    fin>>n;
    bkt(1);
    return 0;
}

