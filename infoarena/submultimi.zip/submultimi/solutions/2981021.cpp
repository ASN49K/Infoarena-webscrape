#include <algorithm>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unordered_map>

using namespace std;

#ifdef LOCAL
ifstream fin("input.txt");
#define fout cout
#else
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
#define endl '\n'
#endif

int n;

int main() {
    fin >> n;
    for (int i = 1; i <= (1 << n); i++) {
        for (int j = 0; j < n; j++) {
            if (i & (1 << j)) {
                fout << j + 1 << ' ';
            }
        }
        fout << endl;
    }
    return 0;
}
