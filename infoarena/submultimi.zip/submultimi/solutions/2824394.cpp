#include <stdio.h>
#include <ctype.h>

#define MAXN 16

class WriteOnSteroids {
  protected:
    static const int BUFSIZE = (128 * 1024);
    FILE *fout;
    char wbuf[BUFSIZE];
    int wbp = 0;
    bool close;

  public:
    WriteOnSteroids( char *fname ){
      fout = fopen( fname, "w" );
      close = true;
    }
    
    WriteOnSteroids( FILE *fp ){
      fout = fp;
      close = false;
    }

    ~WriteOnSteroids(){
      flush();
      if( close )
        fclose( fout );
    }

    inline void putch( char ch ){
      wbuf[wbp] = ch;
      if( (wbp = ((wbp + 1) & (BUFSIZE - 1))) == 0 )
        fwrite( wbuf, sizeof(char), BUFSIZE, fout );
    }
    
    inline void flush(){
      fwrite( wbuf, sizeof(char), wbp, fout );
      wbp = 0;
    }

    template<typename T, const int maxdigit> inline void putnum( T n ){
      char out[maxdigit + 2];
      int i = maxdigit;
      
      if( n < 0 ){
        n = -n;
        putch( '-' );
      }
      
      if( n == 0 )
        out[--i] = '0';
      
      while( n ){
        out[--i] = '0' + (n % 10);
        n /= 10;
      }
      
      while( i < maxdigit )
        putch( out[i++] );
    }
};

WriteOnSteroids fout( (char *)"submultimi.out" );

int out[MAXN];
int sp;

static inline void print(){
  int i;
  
  if( sp == 0 )
    return;
  
  for( i = 0 ; i < sp ; i++ ){
    fout.putnum<int, 2>( out[i] );
    fout.putch( ' ' );
  }
  
  fout.putch( '\n' );
}

void gen( int i, int n ){
  if( i == n )
    return;

  out[sp++] = i + 1;
  print();
  gen( i + 1, n );
  sp--;
  gen( i + 1, n );
}

int main(){
  FILE *fin = fopen( "submultimi.in", "r" );
  
  int n;
  
  fscanf( fin, "%d", &n );
  
  sp = 0;
  gen( 0, n );
  
  fclose( fin );
  return 0;
}