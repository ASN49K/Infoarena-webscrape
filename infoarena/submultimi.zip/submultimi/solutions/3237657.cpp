#include <fstream>
#include <iostream>

using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");

int stiva[17];
int n;
void scrie(int k){
  for(int i = 1; i<=k; i++)
    cout << stiva[i] << " ";
  cout << "\n";  
}

void back(int l, int k){
  if(l == k){
    scrie(k);
    return;
  }
  for(int i = 1; i<=n; i++){
    if(i > stiva[l]){
      stiva[l+1] = i;
      back(l+1, k);
    }
  }
}

int main(){
  in >> n;
  for(int i = 1; i<=n; i++){
    back(0, i);
  }
}
