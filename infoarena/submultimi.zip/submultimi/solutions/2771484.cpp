#include <fstream>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

int n;

int main() {

        in >> n;
        int doi_la_n = (1 << n);
        for(int i = 1; i < doi_la_n; i++) {
                for(int j = 1; j <= n; j++)
                        if(i & (1 << (j - 1)))
                                out << j << ' ';
                out << '\n';
        }

        return 0;
}
