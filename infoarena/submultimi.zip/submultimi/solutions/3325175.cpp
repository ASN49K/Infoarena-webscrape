#include <bits/stdc++.h>
using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int v[20];
int n;
void afis ()
{
    for (int i=1; i<=n; i++)
        if (v[i]) g << i << ' ';
    g << '\n';
}
void add ()
{
    v[1]++;
    int start=1;
    while (v[start]==2)
    {
        v[start+1]++;
        v[start]=0;
        start++;
    }
    if (v[n+1]!=0) exit(0);
}
signed main ()
{
    f >> n;
    v[1]=1;
    while (true)
    {
        afis();
        add();
    }
}
