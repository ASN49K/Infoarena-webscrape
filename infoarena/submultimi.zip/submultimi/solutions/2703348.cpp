#include <fstream>

using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int n,x[20];
void bkt(int nr,int p)
{
    if(nr==n+1)
        return;
    bkt(nr+1,p);
    x[p]=nr;
    for(int i=1;i<=p;i++)
        g<<x[i]<<' ';
    g<<'\n';
    bkt(nr+1,p+1);

}
int main()
{
    f>>n;
    bkt(1,1);
    return 0;
}

