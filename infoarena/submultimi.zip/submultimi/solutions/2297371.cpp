#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int n;
vector <int>v;
void afisare(int k)
{
	for (int i = 1; i <= k; i++)
		g << v[i] << ' ';
	g << "\n";
}
void bktr(int k)
{
	for (int i = v[k - 1] + 1; i <= n; i++)
	{
		v[k] = i;
		afisare(k);
		bktr(k + 1);
	}
}
int main()
{
	f >> n;
	v.resize(n + 2);
	bktr(1);
	g.close();
	f.close();
}
