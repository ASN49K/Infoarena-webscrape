#include <fstream>
#include <bitset>

using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
const int NMAX = 16;
int sol[NMAX+5];
bitset<NMAX+5> viz;
int n;
void print(int k)
{
    int i;
  for(i=1;i<=k;i++)
    fout<<sol[i]<<" ";
  fout<<"\n";
}
void backt(int k)
{
  if(k == n+1)
   return;
 else
 {
     int i;
    for(i=sol[k-1]+1;i<=n;i++)
    {
      sol[k] = i;
      print(k);
      backt(k+1);
    }
 }
}
int main()
{
    fin>>n;
    backt(1);
    return 0;
}
