#include <fstream>

using namespace std;

ifstream cin("submultimi.in");
ofstream cout("submultimi.out");

int main()
{
    short int n;
    cin>>n;
    for (int i=1; i<=(1<<n)-1; i++)
    {
        for (int j=0; j<n; j++)
            if ( ((i>>j)&1))
                cout<<j+1<<" ";
        cout<<"\n";
    }
    return 0;
}
