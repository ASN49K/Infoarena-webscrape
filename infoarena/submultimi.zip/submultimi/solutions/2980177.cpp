#include <bits/stdc++.h>

using namespace std;
ifstream fin ("submultimi.in");
ofstream fout ("submultimi.out");

int main()
{
    int n;
    fin >> n;
    int N = (1 << n);
    for(int i = 1 ; i < N ; ++i , fout << '\n')
        for(int j = 0 ; j < n ; ++j)
            {
                if((1 << j) & i)
                    fout << j + 1 << " ";
            }
}
