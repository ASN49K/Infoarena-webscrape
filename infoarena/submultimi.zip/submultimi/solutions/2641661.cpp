#include "bits/stdc++.h"
using namespace std;

string bin(int n, int k) {
    string s = "";
    for (int i = 0; i < k; i++) {
        if (n / (int)pow(2, i) % 2 == 1) {
            s = "1" + s;
        } else {
            s = "0" + s;
        }
    }
    return s;
}

int main()
{
    ifstream cin("submultimi.in");
    ofstream cout("submultimi.out");
    int k;
    cin >> k;
    for (int i = 0; i < pow(2, k); i++) {
        string s = bin(i, k);
        for (int j = 0; j < s.size(); j++) {
            if (s[j] == '1') {
                cout<< j + 1<< " ";
            }
        }
        cout<<endl;
    }

    return 0;
}
