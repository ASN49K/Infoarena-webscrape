#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n,v[10001],cnt,x;

int main()
{
    fin>>n;
    while(v[0]!=1)
    {
        int i=n;
        while(v[i]==1)
        {
            v[i]=0;
            i--;
        }
        v[i]=1;
        //afișăm submulțimea corespunzătoare
        for(int i=1; i<=n; i++)
        {
            if(v[i]!=0)
            {
                fout<<i<<" ";
            }
        }
        fout<<'\n';
    }

    return 0;
}