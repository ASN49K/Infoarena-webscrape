#include <bits/stdc++.h>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

int n;

int main()
{
    in>>n;
    for(int mask = 1;mask < (1<<n);mask++)
    {
        for(int p = 0; (1<<p) <= mask;p++)
        {
            if((mask & (1<<p)) != 0)
                out<<p+1<<" ";
        }
        out<<"\n";
    }

    return 0;
}
