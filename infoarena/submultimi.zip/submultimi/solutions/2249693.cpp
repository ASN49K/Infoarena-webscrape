#include <fstream>

using namespace std;
ifstream f("submultimi.in");
ofstream g("submultimi.out");
int n,i,j;
int main()
{   f>>n;
    for(i=1;i<=(1<<n)-1;i++){
        for(j=0;j<=15;j++){
            if(((i>>j)&1)==1)
                g<<j+1<<' ';
        }
        g<<'\n';
    }
    return 0;
}
