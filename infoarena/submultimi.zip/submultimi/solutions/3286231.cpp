#include <fstream>

using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");

int n;

int main()
{
    cin>>n;
    for(int i=1;i<=(1<<n);i++)
    {
        for(int j=0;j<n;j++)
            if((i&(1<<j))!=0)
                cout<<j+1<<" ";
        cout<<'\n';
    }
    return 0;
}