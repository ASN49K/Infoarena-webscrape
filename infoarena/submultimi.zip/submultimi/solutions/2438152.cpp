#include <iostream>
#include <fstream>
using namespace std;
ifstream in("submultimi.in");
ofstream out("submultimi.out");
int n,a[18],fr[18];
void bacK(int k)
{
    if(k==n+1)return;
    for(int i=a[k-1]+1;i<=n;i++)
    {
        a[k]=i;
        for(int j=1;j<=k;j++)
        {
            out<<a[j]<<' ';
        }out<<'\n';
        bacK(k+1);
    }
}
int main()
{
    in>>n;
    bacK(1);
    return 0;
}
