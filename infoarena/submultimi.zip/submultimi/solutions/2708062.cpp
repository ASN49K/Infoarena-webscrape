#include <bits/stdc++.h>
#define ll long long
#define nmax 1000005
#define ui unsigned int

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n, x[20];

void afis(int k)
{
    for(int i = 1; i <= k; i++)
        g << x[i] << " ";
    g << endl;
}

int valid(int k)
{
    return x[k] > x[k-1];
}

void bkt(int k)
{
    for(int i = 1; i <= n; i++)
    {
        x[k] = i;
        if(valid(k))
        {
            afis(k);
            bkt(k + 1);
        }
    }
}

int main()
{
    f >> n;

    bkt(1);

    return 0;
}

