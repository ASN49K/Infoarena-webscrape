#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int sol[20], n, l;

int verifica(int poz)
{
    for(int i=0;i<poz;i++)
        if(sol[i]==sol[poz])
            return 0;
    if(sol[poz]<sol[poz-1])
        return 0;
    return 1;
}

void afisare()
{
    for(int i=0;i<l;i++)
        fout<<sol[i]<<" ";
    fout<<"\n";
}

void backt(int poz)
{
    if(poz==l)
        afisare();
    else
        for(int j=1;j<=n;j++)
    {
        sol[poz]=j;
        if(verifica(poz))
            backt(poz+1);
    }
}

int main()
{
    fin>>n;
    for(int i=1;i<=n+1;i++)
    {
        backt(0);
        l=i;
    }
    return 0;
}
