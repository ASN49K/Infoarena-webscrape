#include <iostream>
#include <fstream>
#include <string>
#define MAX 20
using namespace std;
int n,v[MAX],k;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main()
{
    fin >> n;
    while(!v[0]){
        int i = n;
        while (v[i] == 1) {
            v[i] = 0;
            i--;
        }
        v[i] = 1;

        if(i == 0)
            break;

        for(int i = 1; i <= n; i++){
            if(v[i] == 1){
                fout << i << " ";
            }
        }
        fout << "\n";
    }
    return 0;
}
