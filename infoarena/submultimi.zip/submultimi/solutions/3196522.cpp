#include <iostream>
#include <vector>
#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

void back(int n, vector<int> &v, int k) {
	for(int i=v[k-1]+1; i<=n; i++) {
		v[k]=i;
		for(int i=1; i<=k; i++) {
			fout << v[i] << ' ';
		}
		fout << '\n';
		back(n, v, k+1);
	}

}

int main() {
 	int n;
 	fin >> n;
 	vector<int> v(n+1);
 	v[0]=0;
   back(n, v, 1);
	return 0;
}