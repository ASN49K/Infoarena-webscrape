#include <fstream>

using namespace std;

ifstream f("submultimi.in");
ofstream g("submultimi.out");

int n;
int subsets[20];

bool is_partial_solution(int k) {
    return true;
}

bool is_solution(int k) {
    return true;
}

void write_solution(int k) {
    for (int i = 1; i<=k; i++) {
        g<< subsets[i] << " ";
    }

    g<<"\n";
}

void backtracking() {
    int k = 1;
    subsets[1] = 0;

    while (k > 0) {
        if (subsets[k] < n) {
            subsets[k]++;

            write_solution(k);
            
            k++;
            subsets[k] = subsets[k-1];    
        }
        else {
            k--;
        }
    }
}

int main() {
    f>>n;
    backtracking();

}