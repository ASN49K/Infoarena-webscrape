#include <fstream>

using namespace std;
ifstream f("Submultimi.in");
ofstream g("Submultimi.out");





int main()
{
    int n;

    f>>n;

    const int MAX_VAL = 1<<n;
    for(int i=1;i<MAX_VAL;i++)
    {
        for(int j=0;j<n;j++)
        {
            if((i>>j) & 1 )
            {
                g<<j+1<<" ";
            }
        }

        g<<'\n';
    }
}
