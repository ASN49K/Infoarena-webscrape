#include <fstream>
#include <vector>

using namespace std;

ifstream cin("submultimi.in");
ofstream cout("submultimi.out");

vector <int> st;

void afisare()
{
    if(st.size()!=0)
    {
        for(int i=0;i<st.size();i++)
            cout<<st[i]<<" ";
        cout<<'\n';
    }
}

void bkt(int pas, int n)
{
    if(pas>n)
    {
        afisare();
        return;
    }
    bkt(pas+1,n);
    st.push_back(pas);
    bkt(pas+1,n);
    st.pop_back();
}

int main()
{
    int n;
    cin>>n;
    bkt(1,n);
    return 0;
}
