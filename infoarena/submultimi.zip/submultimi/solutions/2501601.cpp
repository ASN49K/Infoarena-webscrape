#include <fstream>
#include <vector>

using namespace std;

vector <int> subset;

ifstream in ("submultimi.in");
ofstream out ("submultimi.out");

int main()
{
    int n;
    in>>n;
    for (int i=1;i<(1<<n);++i)
    {
      subset.clear();
      for (int j=1;j<=n;j++)
            if (i&(1<<(j-1)))
              subset.push_back(j);
      for (int j=0;j<subset.size();++j)
         out<<subset[j]<<" ";
      out<<'\n';
    }
    return 0;
}
