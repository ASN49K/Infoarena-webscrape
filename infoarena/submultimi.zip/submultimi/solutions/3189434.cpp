#include <bits/stdc++.h>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
bool ok[16];

void bkt(int step) {
    if (step == n) {
        bool has = false;
        for (int i = 0; i < n; i++) {
            if (ok[i]) {
                has = true;
                fout << i << ' ';
            }
        }
        if (has) {
            fout << '\n';
        }
    } else {
        bkt(step + 1);
        ok[step] = true;
        bkt(step + 1);
    }
}

int main() {
    fin >> n;
    bkt(0);
    return 0;
}
