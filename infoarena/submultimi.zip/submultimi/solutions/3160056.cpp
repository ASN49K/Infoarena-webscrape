﻿#include <bits/stdc++.h>
#include <unordered_map>
using namespace std;
#define ll long long 
#define ull unsigned long long 
#define nmax 20
#define MOD 1999999973 
#define INF 2123456789
//#define fin cin 
//#define fout cout 

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int n;
int st[nmax];
int viz[nmax];

void Afis(int lg)
{
	for (int i = 1; i <= lg; i++)
		fout << st[i] << " ";
	fout << "\n";
}

void Back(int top, int k)
{

	for (int i = k; i <= n; i++)
		if (!viz[i])
		{
			st[top] = i;
			viz[i] = 1;
			Afis(top);
			Back(top + 1, st[top]);
			viz[i] = 0;
		}
}

int main()
{
	fin >> n;
	Back(1, 1);
	fin.close();
	fout.close();
	return 0;
}