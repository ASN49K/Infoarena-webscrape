#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

int main() {
    int n;
    in >> n;

    for (int i = 1; i < 1 << n; i++) {
        for (int j = 0; 1 << j <= i; j++) {
            if (((1 << j) & i) > 0)
                out << j + 1 << ' '; 
       }
       out << '\n';
    }
    return 0;
}