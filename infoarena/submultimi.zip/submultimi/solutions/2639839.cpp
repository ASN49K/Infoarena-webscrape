#include <bits/stdc++.h>
using namespace std;
ifstream fin ("submultimi.in");
ofstream fout("submultimi.out");
int n,st[18];

void afis (int p)
{
    int i;
    for (i=1;i<=p;i++)
    fout<<st[i]<<" ";
    fout<<'\n';
}

void bk(int p)
{
    int i;
    for (i=st[p-1]+1;i<=n;i++)
    {
    st[p]=i;
    afis(p);
    bk(p+1);
    }
}

int main()
{
    fin>>n;
    bk(1);
    return 0;
}



