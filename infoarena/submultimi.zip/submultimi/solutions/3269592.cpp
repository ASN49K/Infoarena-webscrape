#include <bits/stdc++.h>

using namespace std;

int n;
vector<int> st;
ofstream fout( "submultimi.out" );

void alege ( int k ) {
  int i;
  if ( k == n + 1 ) {
    if ( st.size() != 0 ) {
      for ( i = 0; i < st.size(); ++ i )
      fout << st[i] << " ";
    fout << "\n";
    }
  }
  else {
   alege( k + 1 );
   st.push_back( k );
   alege( k + 1 );
   st.pop_back();
  }
}


int main()
{
    ifstream fin( "submultimi.in" );
    fin >> n;

    alege( 1 );

    fin.close();
    fout.close();
    return 0;
}
