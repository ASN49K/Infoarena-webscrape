
#include<stdio.h>

int n,nr=-1;

int st[22];



void back()

{

    int i;

    for(i=1;i<=st[0];i++)

        printf("%d ",st[i]);

    if(st[0])

        printf("\n");

    for(i=st[st[0]]+1;i<=n;i++)

    {

        st[++st[0]]=i;

        back();

        st[st[0]]=0;

        st[0]--;

    }

}



int main()

{

    freopen("submultimi.in","r",stdin);

    freopen("submultimi.out","w",stdout);

    scanf("%d",&n);

    back();

    return 0;

}