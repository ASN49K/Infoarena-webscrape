#include <fstream>
using namespace std;
ifstream fin("submultimi.in");
ofstream fout("submultimi.out");
int sol[16];
int n;
void print(int k)
{
    int i;
  for(i=1;i<=k;i++)
    fout<<sol[i]<<" ";
  fout<<"\n";
}
void backt(int k)
{
  if(k == n+1)
   return;
 else
 {
     int i;
    for(i=sol[k-1]+1;i<=n;i++)
    {
      sol[k] = i;
      print(k);
      backt(k+1);
    }
 }
}
int main()
{
    fin>>n;
    backt(1);
    return 0;
}
