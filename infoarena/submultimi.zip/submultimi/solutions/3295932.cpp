#include <bits/stdc++.h>
using namespace std;
ifstream cin("submultimi.in");
ofstream cout("submultimi.out");
int n;
vector<int> subset;
void backtrack(int i) {
    if (i > n) {
        if (!subset.empty()) {
            for(int j = 0; j < subset.size(); ++j){
                if(j) cout << " ";
                cout << subset[j];
            }
            cout << "\n";
        }
        return;
    }
    // nu includem i
    backtrack(i+1);
    // includem i
    subset.push_back(i);
    backtrack(i+1);
    subset.pop_back();
}
int main(){
    cin >> n;
    backtrack(1);
    return 0;
}
