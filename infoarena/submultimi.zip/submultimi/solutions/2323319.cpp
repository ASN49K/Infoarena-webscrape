#include <iostream>
#include <fstream>

using namespace std;
int v[100];
int k;
ofstream g("submultimi.out");

int verif(int k)
{
    for(int i=1;i<k;i++)
        if(v[i]>=v[k])
            return 0;
    return 1;
}
int bkt(int n,int k)
{
    for(int i=1;i<=n;i++)
        {
            v[k]=i;
            if(verif(k))
            {
                    for(int j=1;j<=k;j++)
                        g<<v[j]<<" ";
                    g<<endl;
                    if(k==n)
                        return 0;
                    bkt(n,k+1);

            }
        }

}
int main()
{
    ifstream f("submultimi.in");
    int n;
    f>>n;
    bkt(n,1);

    return 0;
}
