#include <fstream>

using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);

    int n,i,j;
    fin >> n;
    for(i = 1; i < (1 << n); i++)
    {
        for(j = 0; j < n; j++)
            if(i & (1 << j))
                fout << j + 1 << " ";
        fout << "\n";
    }
    return 0;
}
