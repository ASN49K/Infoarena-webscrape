#include <bits/stdc++.h>
using namespace std;

ifstream fin("submultimi.in");
ofstream fout("submultimi.out");

int st[20], n ,k;

void Afis(int n)
{
    k++;
    for (int i = 1; i <= n; i++)
        if(st[i]==1) fout << i << " ";
    if(k>1) fout << "\n";
}

void Back(int top)
{
    if (top == n + 1) Afis(n);
    else for (int i = 0; i <= 1; i++)
        {
            st[top] = i;
            Back(top + 1);
        }
}

int main()
{
    fin >> n;
    Back(1);
    return 0;
}
