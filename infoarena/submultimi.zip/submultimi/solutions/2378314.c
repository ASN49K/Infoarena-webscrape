#include <stdlib.h>
#include <stdio.h>

void print(int n, int *submult, FILE **write)
{
	for (int i = 0; i < n; i++)
		if (i == n - 1)
			fprintf(*write, "%d\n", submult[i]);
		else
			fprintf(*write, "%d ", submult[i]);
}

void submultimi(int n,int k,int *submult, FILE **write)
{
	if(k <= n + 1)
	{
		if (k >= 2)
			print(k - 1, submult, write);

		for (int i = 1; i <= n; i++)
		{
			if (k == 1 || submult[k-2] < i)
			{
				submult[k-1] = i;
				submultimi(n, k+1, submult, write);
			}
		}


	}

}

int main(int argc, char const *argv[])
{
	FILE *read = fopen("submultimi.in", "r");
	FILE *write = fopen("submultimi.out", "w");
	
	int number;
	
	fscanf(read, "%d", &number);

	int * submult = (int *)calloc(number + 1, sizeof(int));

	submultimi(number, 1, submult, &write);


	free(submult);
	fclose(read);
	fclose(write);

	return 0;
}