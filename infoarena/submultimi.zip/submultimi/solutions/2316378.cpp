#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("submultimi.in");
ofstream out("submultimi.out");

void print(vector<int> v, int lim) {
    for(int i = 0; i <= lim; ++i){
        out << v[i] << " ";
    }
    out << "\n";
}

bool check(vector<int> v, int j) {
    for(int i = 0; i < j; ++i) {
        if(v[i] >= v[j]) return false;
    }
    return true;
}

void subm(int n, int p = 0) {
    if(p >= n) return;
    static vector<int> v(n, 0);
    for(int i = 0; i < n; ++i){
        v[p] = i + 1;
        if(check(v, p)){
            if(p <= n - 1){
                print(v, p);
                subm(n, p + 1);
            }
        }
    }
}

int main()
{
    int n;
    in >> n;
    subm(n);
    return 0;
}

