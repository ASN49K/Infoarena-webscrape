#include <cstdio>
#include <cstdlib>

using namespace std;

#define MAX_N 16

int n, subsets[1 << MAX_N];

void error(int points, char *msg) {
    fprintf(stderr, "%s", msg);
    printf("%d", points);
    exit(0);
}

int main(void) {
	FILE *fin = fopen("submultimi.in", "rt");
    if (!fin)
        error(0, "Missing input file! Contact author!");

    if (fscanf(fin, "%d", &n) != 1)
    	error(0, "Invalid input file! Contact author!");

    if (n < 1 || n > 16)
    	error(0, "Invalid input file! Contact author!");

    FILE *fout = fopen("submultimi.out", "rt");
    if (!fout)
    	error(0, "Missing output file!");
    for (int i = 1; i < (1 << n); ++ i) {
    	char s[1 << 10];
    	int subset = 0;

    	fgets(s, (1 << 10) - 1, fout);
    	for (int j = 0; s[j] != '\n' && s[j]; ++ j) {
    		if (s[j] == ' ' || s[j] == '\t')
    			continue ;
    		if (s[j] >= '0' && s[j] <= '9') {
    			int number = 0;
	    		for (; s[j] >= '0' && s[j] <= '9'; ++ j)
	    			number = number * 10 + (s[j] - '0');
                if (number < 1 || number > n)
                    error(0, "Wrong answer!");
	    		subset |= 1 << (number - 1);
	    	}
	    	else
	    		error(0, "Wrong answer!");
	    }
	    subsets[subset] = 1;
    }
 	for (int i = 1; i < (1 << n); ++ i) if (subsets[i] == 0)
 		error(0, "Wrong answer!");
 	error(10, "Correct!");

    return 0;
}
