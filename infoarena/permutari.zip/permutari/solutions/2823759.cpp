#include <fstream>
#include <iostream>

using namespace std;

int n, sol[10];
ifstream fin("permutari.in");
ofstream fout("permutari.out");

bool isValid(int k){
    for(int i = 1; i < k; ++i){
        if(sol[i] == sol[k]){
            return 0;
        }
    }

    return 1;
}

void bkt(int k){
    if(k == n + 1){
        for(int i = 1; i <= n; ++i){
            fout << sol[i] << " ";
        }
        fout << "\n";
        return;
    }

    for(int i = 1; i <= n; ++i){
        sol[k] = i;
        if(isValid(k)){
            bkt(k + 1);
        }
    }
}

int main(){

    fin >> n;
    bkt(1);

    return 0;
}