#include <stdio.h>
#include <stdlib.h>

FILE *fin, *fout;

int v[10], f[10];

void permutari(int k, int n){
    int i;
    if (k==0){
        for (i=n; i>0; i--)
            fprintf(fout, "%d ", v[i]);
        fprintf(fout, "\n");
    }else
        for (i=1; i<=n; i++)
            if (f[i]==0){
                f[i]=1;
                v[k]=i;
                permutari(k-1, n);
                f[i]=0;
            }
}

int main()
{
    int n;
    fin=fopen("permutari.in", "r");
    fscanf(fin, "%d", &n);
    fclose(fin);
    fout=fopen("permutari.out", "w");
    permutari(n, n);
    fclose(fout);
    return 0;
}
