#include <iostream>
#include <algorithm>
#include <fstream>
#include <vector>
using namespace std;
 
ifstream in("permutari.in");
ofstream out("permutari.out");

int n;
int v[10];
bool viz[10];

void perm(int k);
void showPerm();

int main(){
  
  in>>n;

  perm(1);

  return 0;
}

void perm(int k){
  if(n < k){
    showPerm();
  } else {

    for(int i = 1; i <= n; i++){
      if(!viz[i]){
        viz[i] = true;
        v[k] = i;
        perm(k + 1);
        viz[i] = false;
      }
    }

  }

}

void showPerm(){
  for(int i = 1; i <= n; i++){
    out<<v[i]<<" ";
  }
  out<<"\n";
}

