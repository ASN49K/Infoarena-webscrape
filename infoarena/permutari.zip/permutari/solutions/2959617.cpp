#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int s[101], p[101], n;

void perm(int k);
void print();

int main(){
	fin >> n;
	perm(1);
	
	return 0;
}

void print(){
	for (auto i = 1; i <= n; ++i)
	     fout << s[i] << ' ';
	fout << '\n';
	    
}

void perm(int k){
	if (k > n){
		print();
		return;
	}
	
	for (int i = 1; i <= n; ++i){
		s[k] = i;
		if (!p[i]){
			p[i] = true;
			perm(k + 1);
			p[i] = false;
		}
	}
}
