#include <fstream>
using namespace std;
ifstream cin("permutari.in");
ofstream cout("permutari.out");
int x[10] ,n;
void afisare()
{
    for( int j=1;j<=n;j++)
        cout<<x[j]<<" ";
    cout<<endl;
}

bool OK(int k){
    for(int i=1;i<k;++i)
        if(x[k]==x[i])
            return false;
    return true;
}



void bck(int k){
    for(int i=1 ; i<=n ; ++i)
    {
        x[k]=i;
        if( OK(k) ){
            if(k==n)
                afisare();
            else
                bck(k+1);
        }
    }
}
int main(){
    cin>>n;
    bck(1);
    return 0;
}
