#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n, k, a[10],i,j;

int valid(int k)
{
    int i;
    for(i = 1; i <= k - 1; i++)
        if (a[k] == a[i])
            return 0;
    return 1;
}

void BKT(int k)
{

    for(i = 1; i <= n; i++)
    {
        a[k] = i;
        if (valid(k))
            if (k == n)
            {
                for(j=1; j<=n; j++)
                    g<<a[j]<<" ";
                g<<endl;
            }
            else
                BKT(k + 1);

    }
}

int main()
{
    f>> n;
    BKT(1);
    return 0;
}
