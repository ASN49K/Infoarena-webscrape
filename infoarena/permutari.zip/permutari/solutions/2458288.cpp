#include <iostream>
#include <fstream>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int n,st[17],v[9];

void Afisare()
{
    int i;
        for (i=1; i<=n; i++)
                out << st[i] << " ";
        out << "\n";
}

void Back(int top)
{
    int i;
    if (top == n+1)
        Afisare();
    else
        for (i=1; i<=n; i++)
        if (v[i] == 0)
    {
        v[i] = 1;
        st[top] = i;
        Back(top+1);
        v[i] = 0;
    }
}

int main()
{
    in >> n;
    Back(1);
    return 0;
}
