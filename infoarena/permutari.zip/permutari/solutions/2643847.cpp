#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int v[100], n; 
int frc[100];

void Bkt(int id) {
    if (id == n + 1) {
        for (int i = 1; i <= n; i++) {
            out << v[i] << " ";
        }
        out << '\n';
        return;
    }
    for (int i = 1; i <= n; i++) {
        if (frc[i] == 0) {
            v[id] = i;
            frc[i]++;
            Bkt(id + 1);
            frc[i]--;
            v[id] = 0;
        }
        
    }
}

int main() {
    in >> n;
    Bkt(1);
    return 0;
}
