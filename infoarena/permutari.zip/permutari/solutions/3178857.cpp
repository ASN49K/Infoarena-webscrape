#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int numar, permutare[9];
bool folosit[9];

void gen_perm(int pas) {
    if (pas == numar) {
        for (int i = 0; i < pas; ++i){
            fout << permutare[i] << ' ';
        }
        fout << '\n';
        return;
    }
    for (int i = 1; i <= numar; ++i) {
        if (!folosit[i]) {
            permutare[pas] = i;
            folosit[i] = true;
            gen_perm(pas + 1);
            folosit[i] = false;
        }
    }
}

int main()
{
    fin >> numar;
    gen_perm(0);
}
