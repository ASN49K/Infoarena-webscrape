#include <iostream>
#include <fstream>

using namespace std;

int st[10], n, k;
ifstream fin("permutari.in");
ofstream fout("permutari.out");

void init() {
    st[k] = 0;
}

int succesor() {
    if(st[k] < n) {
        st[k]++;
        return 1;
    }
    return 0;
}

int valid() {
    for(int i = 1; i < k; i++)
        if(st[k] == st[i])
            return 0;
    return 1;
}

int solutie() {
    if(k==n)
        return 1;
    return 0;
}

void afisare() {
    for(int i = 1; i <= n; i++)
        fout << st[i] << " ";
    fout << '\n';
}

void back() {
    int as, ev;
    k = 1;
    init();
    while(k > 0) {
        do {
            as = succesor();
            if(as)
                ev = valid();
        } while(as && !ev);
        if(as)
            if(solutie())
                afisare();
            else {
                k++;
                init();
            }
        else k--;
    }
}

int main() {
    fin >> n;
    fin.close();
    back;
    return 0;
}
