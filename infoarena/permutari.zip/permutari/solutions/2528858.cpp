#include <fstream>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n;
int v[9];

bool ok(int k)
{
    for (int i=1;i<k;i++)
        if (v[i]==v[k])
            return 0;
    return 1;
}

void bkt(int k)
{
    for (int i=1;i<=n;i++)
    {
        v[k]=i;
        if (ok(k))
        {
            if (k==n)
            {
                for (int j=1;j<=n;j++)
                    g<<v[j]<<" ";
                g<<"\n";
            }
            else
                bkt(k+1);
        }
    }
}

int main()
{
    f>>n;
    bkt(1);
    return 0;
}
