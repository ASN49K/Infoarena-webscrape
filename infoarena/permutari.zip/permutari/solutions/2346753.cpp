#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int k,n;
int ST[10];

void tipar(int k)
{
    int i;
    for (i=1;i<=k;i++)
        fout<<ST[i]<<" ";
}

int valid(int k)
{
    int i;
    for (i=1;i<=k-1;i++)
        if (ST[k]==ST[i])
            return 0;
    return 1;
}
void back(int k)
{
    int i;
    for (i=1;i<=n;i++)
    {
        ST[k]=i;
        if (valid(k))
            if (k==n)
            {
                tipar(k);
                fout<<endl;
            }
        else
            back(k+1);
    }
}
int main()
{
    fin>>n;
    back(1);
    return 0;
}
