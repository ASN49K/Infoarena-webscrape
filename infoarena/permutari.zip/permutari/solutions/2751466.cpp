#include <bits/stdc++.h>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");
int st[12], n, v[12];
/**
v[i]=1 daca i este in st
v[i]=0, daca i nu este inca in st
*/

void Afis(int n)
{
    for (int i = 1; i <= n; i++)
        fout << st[i] << " ";
    fout << "\n";
}

void Perm(int k)
{
    if (k == n + 1) Afis(n);
    else for (int i = 1; i <= n; i++)
        if (v[i] == 0)
        {
            v[i] = 1;
            st[k] = i;
            Perm(k + 1);
            v[i] = 0;
        }
}

int main()
{
    fin >> n;
    Perm(1);
    fout.close();
    return 0;
}