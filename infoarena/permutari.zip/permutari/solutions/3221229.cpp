#include <fstream>
using namespace std;
ifstream  fin("permutari.in");
ofstream fout("permutari.out");
int N,i,j,ok,v[20],l;
int main()
{
    fin>>N;

    for(i=1; i<=N; i++)
    {
        v[i]=i;
    }

    do
    {
        for(i=1; i<=N; i++)
        {
            fout<< v[i] << " ";
        }
        fout<< "\n";

        ok=0;

        for(i=N; i>=2; i--)
        {
            if(v[i-1]<v[i])
            {
                ok=1;
                for(j=N; j>=i; j--)
                {
                    if(v[j]>v[i-1])
                    {
                       swap(v[j],v[i-1]);
                       break;
                    }

                }

                j=i;
                l=N;

                while(j<l)
                {
                    swap(v[j],v[l]);
                    j++;
                    l--;
                }
                break;
            }
        }
    }
    while(ok!=0);

    fout<< 1;

    return 0;
}
