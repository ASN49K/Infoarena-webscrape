#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n;
int sir[10];
bool fv[10];

void gen(int lg)
{
    if(lg == n){
        for(int j = 0; j < n; j++)
            fout << sir[j] << " ";
        fout << "\n";
        return;
    }

    for(int i = 1; i < 1 + n; i++)
        if(fv[i] == 0){
            sir[lg] = i;
            fv[i] = 1;
            gen(lg + 1);
            fv[i] = 0;
        }
}

int main()
{
    fin >> n;
    gen(0);

    return 0;
}
