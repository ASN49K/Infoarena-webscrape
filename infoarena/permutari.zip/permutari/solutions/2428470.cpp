#include <fstream>
using namespace std;
ifstream cin ("permutari.in");
ofstream cout ("permutari.out");
int n,sol[10];
void afisare()
{
    for (int i=1;i<=n;i++)
    {
        cout << sol[i] << " ";
    }
    cout << '\n';
}
bool verif(int poz)
{
    for (int i=1;i<poz;i++)
    {
        if (sol[i]==sol[poz]) return false;
    }
    return true;
}
void bkt(int poz)
{
    if (poz>n) afisare();
    else
    {
        for (int i=1;i<=n;i++)
        {
            sol[poz]=i;
            if (verif(poz)==true) bkt(poz+1);
        }
    }
}
int main()
{
    cin >> n;
    bkt(1);
}
