#include <bits/stdc++.h>

using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
const int N = 10;
int p[N],n;
void bkt(int);
int main()
{
    f >> n;
    bkt(1);

    return 0;
}
void bkt(int i)
{
    if(i == n+1)
    {
        for(int j=1;j<=n;j++)
            g << p[j] << " ";
        g << '\n';
        return;
    }
    for(int j = 1;j<=n;j++)
    {
        bool gasit = false;
        for(int k=1;k<i;k++)
        {
            if(p[k] == j)
                gasit=true;
        }
        if(!gasit)
        {
            p[i]=j;
            bkt(i+1);
        }
    }
}
