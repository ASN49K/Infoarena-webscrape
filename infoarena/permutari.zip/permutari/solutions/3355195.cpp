#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;

vector<int> permutari;
bool vizitat[10] = {false};
FILE *fin = fopen("permutari.in", "r");
FILE *fout = fopen("permutari.out", "w");

void bkt(int k, int n) {
    if(k == n+1) {
        for(int i = 0; i < n; i++) {
            fprintf(fout, "%d ", permutari[i]);
        }
        fprintf(fout, "\n");
        return;
    }

    for(int i = 1; i <= n; i++) {
        if(!vizitat[i]) {
            permutari.push_back(i);
            vizitat[i] = true;

            bkt(k+1, n);

            permutari.pop_back();
            vizitat[i] = false;
        }
    }
}

int main() {
    int n;
    fscanf(fin, "%d", &n);

    bkt(1, n);
    return 0;
}