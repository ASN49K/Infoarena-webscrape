#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");
const int MAX_SIZE = 8;
int n, v[MAX_SIZE + 1];

bool check(int element) {
  for (int i = 1; i < element; ++i) {
    if (v[element] == v[i]) {
      return false;
    }
  }
  return true;
}

void display() {
  for (int i = 1; i <= n; ++i) {
    fout << v[i] << ' ';
  }
  fout << '\n';
}

void generate(int element) {
  if (check(element) && n == element) {
    display();
  }
  for (int i = 1; i <= n; ++i) {
    v[element] = i;
    if (check(element) && n == element) {
      display();
    } else if (check(element) && n != element) {
      generate(element + 1);
    }
  }
}

int main() {
  fin >> n;
  generate(1);
  return 0;
}