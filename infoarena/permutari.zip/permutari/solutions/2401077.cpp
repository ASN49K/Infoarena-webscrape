#include<iostream>

#include<fstream>

#include<algorithm>

using namespace std;

int main()
{



    ifstream fin("permutari.in");

    ofstream fout("permutari.out");



    int n,k,v[13],t[12],c=0;



    fin>>n;

       for(int i=1; i<=n; i++)
    {

        v[i]=i;

    }


    do
    {

        for(int i=1; i<=n; i++)
        {

            fout<<v[i]<<" ";

        }

        fout<<"\n";

    }
    while(next_permutation(v+1,v+n+1));





    return 0;

}
