#include <fstream>
#include <vector>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n;
vector<int> domain;      // valorile disponibile
vector<int> solution;    // soluția parțială
vector<bool> used;       // marchez ce am folosit deja

void back() {
    if (solution.size() == n) {
        for (int x : solution)
            fout << x << " ";
        fout << "\n";
        return;
    }

    for (int i = 0; i < n; ++i) {
        if (!used[i]) {
            solution.push_back(domain[i]);
            used[i] = true;

            back();

            used[i] = false;
            solution.pop_back();
        }
    }
}

int main() {
    fin >> n;
    domain.resize(n);
    used.resize(n, false);

    for (int i = 0; i < n; ++i)
        domain[i] = i + 1;

    back();
    return 0;
}
