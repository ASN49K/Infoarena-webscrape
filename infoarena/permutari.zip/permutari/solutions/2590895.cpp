#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

bitset <100005> v;

int st[105], n;

void afisare()
{
    for(int i = 1; i<= n; i++)
        g << st[i] << " ";
    g << '\n';
}

void perm(int k)
{
    if(k == n + 1)
        afisare();

    for(int i = 1; i <= n; i++)
        if(v[i] == 0)
        {
            st[k] = i;
            v[i] = 1;
            perm(k + 1);
            v[i] = 0;
        }
}

int main()
{
    fin>>n;
    perm(1);
}
