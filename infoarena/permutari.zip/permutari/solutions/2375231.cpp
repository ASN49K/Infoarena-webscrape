#include <bits/stdc++.h>
#define pb push_back

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

typedef unsigned short ushort;

vector<ushort> v;

ushort N;

int main()
{
    in >> N;
    for(ushort k = 1; k <= N;)
        v.pb(k++);
    do{
        for(auto i : v)
            out << i << ' ';
        out << '\n';
    }while(next_permutation(v.begin(), v.end()));
    return 0;
}
