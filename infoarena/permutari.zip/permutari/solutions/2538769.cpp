#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n;
short sol[9];

int Valid(int pos){
	for(int j=1; j<pos; j++){
		if(sol[j]==sol[pos]) return 0;
	}
	return 1;
}

void bkt(int pos){
	
	for(int i=1; i<=n; i++){
		sol[pos] = i;	
		if(Valid(pos)==1){
			if(pos==n){
				for(int i=1; i<=n; i++){
					fout<<sol[i]<<" ";
				}
				fout<<"\n";
			}
			else{
				bkt(pos+1);
			} 
		}
	}
}

int main(int argc, char** argv) {
	fin>>n;
	bkt(1);
	return 0;
}
