#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using ld = long double;
#define all(v) begin(v), end(v)
#define al(v, l, r) begin(v) + l, begin(v) + r + 1
#define sz(v) (int)v.size()
#define pb push_back
#define pob pop_back
#define fs first
#define sd second

constexpr int inf = 2e9;
constexpr ll infll = 4e18;

int n;
int st[10];
bool viz[10];

void bkt(int k) {
    if (k == n + 1) {
        for (int i = 1; i <= n; ++i) {
            cout << st[i] << " \n"[i == n];
        }

        return;
    }

    for (int i = 1; i <= n; ++i) {
        if (viz[i]) {
            continue;
        }

        st[k] = i;
        viz[i] = true;
        bkt(k + 1);
        viz[i] = false;
    }
}

signed main() {
    ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
    freopen("permutari.in", "r", stdin);
    freopen("permutari.out", "w", stdout);

    cin >> n;
    bkt(1);
}