// https://www.pbinfo.ro/probleme/123/permutari
// https://infoarena.ro/problema/permutari
#include <fstream>
using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int n,x[9];

bool verif(int poz)
{
    bool t[10]={};
    for(int i=0;i<=poz;i++)
    {
        if(t[x[i]]==0)
            t[x[i]]=1;
        else return 0;
    }
    return 1;
}

void backtracking(int poz)
{
    if(poz == n)
    {
        for(int i=0;i<n;i++)
            fout<<x[i]<<' ';
        fout<<endl;

    }else{
        for(int i=1;i<=n;i++)
        {
            x[poz] = i;
            if(verif(poz))
                backtracking(poz+1);
        }
    }
}

int main()
{
    fin>>n;

    backtracking(0);

    return 0;
}
