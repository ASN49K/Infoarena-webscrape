#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int N, x[10];
bool used[10];

inline void scrie() {
    for (int i = 0; i < N; i++)
        fout << x[i] << ' ';
    fout << '\n';
}

inline void back(int const &k) {
    if (k == N) {
        scrie();
        return;
    }

    for (int i = 1; i <= N; i++) {
        if (!used[i]) {
            used[i] = 1;
            x[k]= i;
            back(k + 1);
            used[i] = 0;
        }
    }
}

int main() {
    fin >> N;
    back(0);
    fin.close();
    fout.close();
    return 0;
}