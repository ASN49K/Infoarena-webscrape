#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n,x[9];
bool f[9];

void afisare() {
    for (int i=1;i<=n;i++)
        fout<<x[i]<<" ";
    fout<<"\n";
}

void backtrack(int k) {
    for (int i=1;i<=n;i++)
        if (f[i]==0) {
            x[k]=i;
            if (k==n)
                afisare();
            else {
                f[i]=1;
                backtrack(k+1);
                f[i]=0;
            }
        }
}

int main() {
    fin>>n;
    backtrack(1);
    return 0;
}
