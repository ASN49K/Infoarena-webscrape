#include<bits/stdc++.h>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
short int n,i,v[]={1,2,3,4,5,6,7,8};
int main()
{
    f>>n;
    do {
        for(i=0;i<n;++i)
            g<<v[i]<<' ';
        g<<'\n';
    } while(next_permutation(v,v+n));
    return 0;
}
