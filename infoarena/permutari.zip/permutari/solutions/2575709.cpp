#include <fstream>
using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int fol[10], perm[10];
int n;

void permutari(int k)
{
    if(k==n+1)
    {
        for(int i=1; i<=n; i++)
            out<<perm[i]<<" ";
        out<<'\n';
    }

    for(int j=1; j<=n; ++j)
        if(fol[j]==0)
        {
            perm[k]=j;
            fol[j]=1;
            permutari(k+1);
            fol[j]=0;
        }

}

int main()
{
    in>>n;

    permutari(1);

    in.close();
    out.close();
    return 0;
}
