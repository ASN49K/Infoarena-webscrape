#include <fstream>
#include <algorithm>
using namespace std;

int v[8];

int main()
{
	ifstream in ("permutari.in");
	ofstream out ("permutari.out");
	int n, i;
	in >> n;
	for (i = 0; i < n; i++) v[i] = i + 1;
	do {
		for (i = 0; i < n; i++) out << v[i] << " ";
		out << "\n";
	} while (next_permutation(v, v + n));
	return 0;
}
