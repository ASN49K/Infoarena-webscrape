#include <fstream>
using namespace std;

ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

void permutation(int v[], int dim, int n, bool reached[]) {
    if (dim == n) {
        for (int i = 0; i < n; i++)
            fout << v[i] << " ";
        fout << "\n";
        return;
    }

    for (int i = 1; i <= n; i++)
        if (!reached[i]) {
            reached[i] = true;
            v[dim] = i;
            permutation(v, dim + 1, n, reached);
            reached[i] = false;
        }
}

int main() {
    int n;
    fin >> n;

    int v[9], dim = 0;
    bool reached[10] = {0};
    permutation(v, dim, n, reached);

    return 0;
}
