#include <bits/stdc++.h>

using namespace std;

ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

void usain_bolt()
{
    ios::sync_with_stdio(false);
    fin.tie(0);
}

const int N = 10;

int n, f[N], ans[N];

void solve(int k)
{
    for(int i = 1; i <= n; ++i) {
        ans[k] = i;
        if(f[i] == false) {
            f[i] = true;
            if(k == n) {
                for(int j = 1; j <= n; ++j) fout << ans[j] << " ";
                fout << "\n";
            }
            else solve(k + 1);
            f[i] = false;
        }
    }
}

int main()
{
    usain_bolt();

    fin >> n;
    solve(1);
    return 0;
}
