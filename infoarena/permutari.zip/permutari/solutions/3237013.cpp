#include <fstream>
#include <vector>

using namespace std;
ifstream cin("permutari.in");
ofstream cout("permutari.out");
int n;
vector<int>permutare;
bool exista[10];
void backtracking(int val)
{
    if(val>n)
    {
        for(int x:permutare)
            cout<<x<<" ";
        cout<<'\n';
        return;
    }
    else
    {
        for(int i=1; i<=n; i++)
        {
            if(!exista[i])
            {
                exista[i]=1;
                permutare.push_back(i);
                backtracking(val+1);
                exista[i]=0;
                permutare.pop_back();
            }
        }
    }
}
int main()
{

    cin>>n;
    backtracking(1);
    return 0;
}
