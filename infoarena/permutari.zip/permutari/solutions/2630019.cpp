#include<iostream>
#include<fstream>
using namespace std;
#define dimmax 100
int s[dimmax], n, k;

ifstream f("permutari.in");
ofstream g ("permutari.out");

void init( )
{s[k]=0; }

int succesor ( )
{  if (s[k]<n)
 {s[k]++;
   return 1; }

else return 0;}

int valid ()
{for (int i=1; i<k; i++) if(s[i]==s[k])
return 0;
return 1; }

int solutie ( )
{ if (k==n)	return 1;
return 0;}

void afisare ( )
{//g<<"{";
for(int i=1; i<=n; i++) g<<s[i]<<" ";  g<<"\n";}

void generare( )
{ int as, ev;k=1;
 init();while(k>0)
{as=1;ev=0; while(as&&!ev) {as=succesor(); if(as!=0)  ev=valid();}
        if(as!=0) if(solutie())  afisare();
else   {k++;   init(); }
else k--;}
}
int main ( )
{//g<< "n=";
   f>>n;    generare( );    return 0;}
