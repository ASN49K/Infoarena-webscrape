#include <fstream>
#include <vector>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
vector <int> v;
int n,s[11];
void afisare()
{
    for(int i=1;i<=n;i++)
        g<<s[i]<<" ";
    g<<'\n';
}
void bkt(int k)
{
    for(int i=0;i<v.size();i++)
    {
        int aux=v[i];
        s[k]=v[i];
        v.erase(v.begin()+i);
        if(k==n)
            afisare();
        else
            bkt(k+1);
        v.insert(v.begin()+i,aux);
    }
}
int i;
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
        v.push_back(i);
    bkt(1);
    return 0;
}
