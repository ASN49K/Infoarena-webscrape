#include <stdio.h>

#define MAX_N 8

char f[MAX_N], v[MAX_N], n;

FILE *fin, *fout;

void perm( int i ) {
  int j;

  if ( i == 0 ) {
    for ( j = n; j > 0; j-- ) {
      fputc( v[j] + '0', fout );
      fputc( ' ', fout );
    }
    fputc( '\n', fout );
  } else {
    for ( j = 1; j <= n; j++ )
      if ( !f[j] ) {
        f[j] = 1;
        v[i] = j;
        perm( i - 1 );
        f[j] = 0;
      }
  }
}

int main() {
  fin = fopen( "permutari.in", "r" );
  fscanf( fin, "%hhd", &n );
  fclose( fin );

  fout = fopen( "permutari.out", "w" );
  perm( n );
  fclose( fout );

  return 0;
}
