#include <bits/stdc++.h>

using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");
void perm(vector<int>v,int n,int poz,int prev)
{
    v[prev]=1;
    for(int i=1;i<=n;i++)
    {
        if(v[i]==0)
        {
            if(poz+1==n)
            {
                for(int j=1;j<=n;j++)
                {
                    if(v[j]==1)
                    out<<j<<" ";
                }
                out<<i<<'\n';
                continue;
            }
            perm(v,n,poz+1,i);
        }
    }
}
int main()
{
int n;
in>>n;
vector<int>v(n+1);
perm(v,n,0,0);
    return 0;
}
