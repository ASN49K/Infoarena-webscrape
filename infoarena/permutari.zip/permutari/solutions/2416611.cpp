#include <iostream>
#include <fstream>
#include <algorithm>
 
using namespace std;
 
int d[10];
 
int main() {
  ifstream fin ("permutari.in");
  ofstream fout("permutari.out");
 
  int N;
  fin >> N;
  for(int i = 0; i < N; ++i)
    d[i] = i + 1;
 
  do {
    for(int i = 0; i < N; ++i)
      fout << d[i] << (i == N-1 ? '\n' : ' ');
  } while(next_permutation(d, d+N));
 
  return 0;
}
