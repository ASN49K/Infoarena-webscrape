#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int N, perm[10];
bool uz[10];

void back(int p, int N)
{
    if(p - 1 == N)
    {
        for(int i = 1; i <= N; i++)
            fout << perm[i];
        fout << endl;
        return;
    }
    for(int i = 1; i <= N; i++)
    {
        if(!uz[i])
        {
            perm[p] = i;
            uz[i] = 1;
            back(p + 1, N);
            uz[i] = 0;
        }
    }
}

int main()
{
    fin >> N;
    back(1, N);

    return 0;
}
