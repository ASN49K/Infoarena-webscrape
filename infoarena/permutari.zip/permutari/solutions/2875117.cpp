#include <fstream>
#include <vector>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int nrelem;

void afisare(vector <int> & solutie)
{
    for (auto i : solutie)
        fout << i << ' ';
    fout << '\n';
}

bool OK(vector <int> & solutie, int k)
{
    bool verif = 1;
    for (int i = 0; i < k; i++)
        if (solutie[i] == solutie[k])
            verif = 0;
    return verif;
}

void backu(vector <int> & solutie, int k, int nrelem)
{
    for (int i = 1; i <= nrelem; i++)
    {
        solutie[k] = i;
        if (OK(solutie, k))
        {
            if (k == nrelem-1)
                afisare(solutie);
            else
                backu(solutie, k+1, nrelem);
        }
    }
}

int main()
{
    fin >> nrelem;
    vector <int> solutie;
    solutie.assign(nrelem, 0);
    backu(solutie, 0, nrelem);
    return 0;
}
