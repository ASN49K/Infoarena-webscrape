#include <bits/stdc++.h>
using namespace std;
/*void perm(int n)
{
    ofstream g("permutari.in");

    vector<int> v;
    v.resize(n);

    for(unsigned int i=0;i<v.size();i++)
        v[i]=i+1;

    for(auto a:v)
        g<<a<<' ';
    g<<'\n';



    g.close();
}*/
ofstream g("permutari.out");
void perm(vector<int> r, list<int> v)
{
    if(v.empty())
        for(auto a:r)
            g<<a<<' ';
    g<<"\b\n";
    for(list<int>::iterator it=v.begin();it!=v.end();it++)
    {
        r.push_back(*it);
        perm(r, v);
        r.pop_back();
    }
}

int main()
{
    int n;
    ifstream f("permutari.in");
    f>>n;
    f.close();
    vector<int> r;
    list<int> v;
    for(int i=1;i<=n;i++)
        v.push_back(i);
    perm(r, v);
    g.close();
    return 0;
}
