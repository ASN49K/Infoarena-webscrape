#include <fstream>

using namespace std;

const int MAX_SIZE = 8;

void write_perms_to_file(
    int & n, int crnt_perm_pos, int * crnt_perm,
    bool * used, ofstream & fout
) {

    if (crnt_perm_pos == n) {
        for (int i = 0; i < n; i++) {
            fout << crnt_perm[i] << " ";
        }
        fout << endl;
        return;
    }

    for (int value = 1; value <= n; value++) {
        if (!used[value - 1]) {
            crnt_perm[crnt_perm_pos] = value;
            used[value - 1] = true;
            write_perms_to_file(n, crnt_perm_pos + 1, crnt_perm, used, fout);
            used[value - 1] = false;
        }
    }
}

int main() {
    int n;
    ifstream fin("permutari.in");
    fin >> n;
    fin.close();

    int perm[MAX_SIZE];
    bool used[MAX_SIZE];
    ofstream fout("permutari.out");
    write_perms_to_file(n, 0, perm, used, fout);
    fout.close();

    return 0;
}