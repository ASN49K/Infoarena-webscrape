#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");

int x[10], n;

void back(int k) {
    if (k == n + 1)
    {
        for (int j = 1; j <= n; j++)
            fout << x[j] << " ";
        fout << endl;
    }
    else
        for (int i = 1; i <= n; ++i)
        {
            x[k] = i;
            bool ok = true;
            for (int j = 1; j < k; ++j)
            {
                if (x[k] == x[j])
                {
                    ok = false;
                    break;
                }
            }
            if (ok)
                back(k + 1);
        }
}
int main() {
    fin >> n;
    back(1);
    return 0;
}

