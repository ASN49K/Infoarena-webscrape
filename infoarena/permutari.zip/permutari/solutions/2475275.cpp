#include <fstream>
#define MAX 50000

using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int n, per[MAX];
void afisare () {
    for (int i = 1; i <= n; i++)
        fout << per[i] << " ";
    fout << "\n";
}

bool OK(int l) {
    for (int i = 1; i < l; i++)
        if (per[l] == per[i])
        return false;
    return true;
}

void permutare (int l) {
    for (int i = 1; i <= n; i++) {
        per[l] = i;
        if (OK(l)) {
            if (l == n)
            afisare();
        else
            permutare(l+1);
        }
    }
}

int main()
{
    fin >> n;
    permutare (1);
    return 0;
}
