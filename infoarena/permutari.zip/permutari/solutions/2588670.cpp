#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
 
int main () {
	freopen("permutari.in", "r", stdin);
	freopen("permutari.out", "w", stdout);
 
	int N;
	vector<int> v;
 
	cin >> N;
	for (int i = 1; i <= N; ++i)
		v.push_back(i);
	do {
		for (int i = 0; i < N; ++i)
			cout << v[i] << ' ';
		cout << '\n';
	} while (next_permutation(v.begin(), v.end()));
}

