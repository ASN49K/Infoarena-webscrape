#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n,v[9];

int main()
{
    int i;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        v[i]=i;
    }
    do{
        for(i=1;i<=n;i++)
        {
            fout<<v[i]<<" ";
        }
        fout<<"\n";
    }while(next_permutation(v+1,v+n+1));
    return 0;
}
