#include <bits/stdc++.h>

int v[8];

char frq[9];

FILE*fo;

int n;

void afis(){
    for(int i=0;i<n;i++)
        fprintf(fo,"%d ",v[i]);
    fprintf(fo,"\n");
}

void gen(int k){
    if(k==n)
        afis();
    else {
    for(int i=1;i<=n;i++){
        if(frq[i]==0){
            frq[i]=1;
            v[k]=i;
            gen(k+1);
            frq[i]=0;
        }
    }
    }
}

int main()
{
    int i;
    FILE*fi;
    fi=fopen("permutari.in","r");
    fo=fopen("permutari.out","w");
    fscanf(fi,"%d",&n);
    gen(0);
    fclose(fi);
    fclose(fo);
    return 0;
}
