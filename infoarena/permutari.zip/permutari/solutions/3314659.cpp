#include <iostream>
#include <fstream>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int n,x[9],k;
void tipar()
{
    for(int i=1;i<=n;i++)
       g<<x[i]<<' ';
    g<<'\n';
}
bool valid()
{
    for(int i=1;i<k;i++)
        if(x[i]==x[k]) return 0;
    return 1;
}
void bt()
{
    k=1;
    x[1]=0;
    while(k>0)
        if(x[k]<n)
    {
        x[k]++;
        if(valid())
            if(k==n) tipar();
        else x[++k]=0;
    }
    else k--;
}
int main()
{
    f>>n;
    bt();
    return 0;
}
