#include <fstream>
#include <bitset>
using namespace std;

ifstream cin("permutari.in");
ofstream cout("permutari.out");

int n, aux[9];

bitset <9> b;

void genperm(int x){

    if(x==(n+1)){
        for(int i = 1; i <= n ; i++){
            cout << aux[i] << ' ';
        }
        cout << '\n';
    }
    for(int i = 1 ; i <= n ; i++){
        if(!b[i]){
            aux[x] = i;
            b[i] = 1;
            genperm(x+1);
            b[i] = 0;
        }
    }
}

int main()
{
    cin >> n;

    genperm(1);

    return 0;
}
