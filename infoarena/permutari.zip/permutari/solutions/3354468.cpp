#include <bits/stdc++.h>

using namespace std;

int n;

void print(vector<int> &sol) {
    for (auto u : sol) {
        cout << u << ' ';
    }
    cout << '\n';
}

void bk(int step, vector<int> &sol, vector<bool> &vz) {
    if (step == n) {
        print(sol);
        return;
    }
    for (int i = 1; i <= n; i++) {
        if (vz[i]) continue;
        sol[step] = i;
        vz[i] = true;
        bk(step + 1, sol, vz);
        vz[i] = false;
    }
}

int main() {
    cin >> n;
    vector<int> sol(n);
    vector<bool> vz(n + 1, false);
    bk(0, sol, vz);
}