#include <bits/stdc++.h>
#define mp make_pair 
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n;
vector<int> v;
int main()
{
    fin >> n;
    for(int i = 0; i < n; i++)
        v.push_back(i + 1);
    do
    {
        for(auto i : v)
            fout << i << " ";
        fout << '\n';
    } while (next_permutation(v.begin(), v.end()));
    
    fin.close();
    fout.close();
    return 0;
}