#include <fstream>
using namespace std;ifstream f("permutari.in");ofstream g("permutari.out");short n,v[10];bool viz[10];void back(int k){for(int i=1;i<=n;++i){if(!viz[i]){viz[i]=1;v[k]=i;if(k==n){for(int j=1;j<=n;++j) g<<v[j]<<' '; g<<'\n';}else back(k+1);viz[i]=0;}}}int main(){f>>n;back(1);return 0;}
