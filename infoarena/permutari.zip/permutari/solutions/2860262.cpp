#include <bits/stdc++.h>
using namespace std;
#define mod 10007
#define int long long
ifstream in ("permutari.in");
ofstream out ("permutari.out");
int fr[101];
int sol[101];
int n;
void afis (int k)
{
    for (int i = 1;i<=k;++i)
        out << sol[i] << ' ';
    out << '\n';
}
void bt (int poz)
{
    if (poz > n)
    {
        afis(poz - 1);
        return;
    }
    for (int i = 1;i<=n;++i)
    {
        if (!fr[i])
        {
            sol[poz] = i;
            fr[i] = 1;
            bt (poz + 1);
            fr[i] = 0;
        }
    }
}
void solve()
{
    in >> n;
    bt(1);
}
main ()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t = 1;
    // cin >> t;
    while (t--)
        solve();
    return 0;
}
