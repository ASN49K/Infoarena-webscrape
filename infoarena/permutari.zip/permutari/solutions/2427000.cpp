#include <fstream>
#include <string>
#include <vector>

using namespace std;


typedef unsigned char uchar;


string const inFile = "permutari.in";
string const outFile = "permutari.out";

ifstream Read(inFile);
ofstream Write(outFile);


void Print(vector<uchar> &vec) {
    for (uchar i = 0; i < vec.size(); ++i) {
        Write << uchar(vec[i] + '1') << ' ';
    }

    Write << '\n';
}


void Generate(vector<uchar> &vec, uchar const index) {
    static vector<bool> used(vec.size(), false);

    if (index == vec.size()) {
        Print(vec);

        return;
    }

    for (uchar i = 0; i < vec.size(); ++i) {
        if (used[i] == true) {
            continue;
        }

        vec[index] = i;
        used[i] = true;

        Generate(vec, index + 1);

        used[i] = false;
    }
}


void CloseFiles(ifstream &Read, ofstream &Write) {
    Read.close();
    Write.close();
}


int main() {
    unsigned n;
    Read >> n;

    vector<uchar> vec(n);

    Generate(vec, 0);

    CloseFiles(Read, Write);

    return 0;
}
