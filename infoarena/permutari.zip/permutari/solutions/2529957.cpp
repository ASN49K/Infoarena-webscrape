#include <iostream>
#include <fstream>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");

int n, sol[9];

void bkt(int k) {
	sol[k] = 0;
	while (sol[k] < n) {
		sol[k]++;
		int ok = 1;
		for (int i = 1; i < k; i++) {
			if (sol[k] == sol[i]) ok = 0;
		}
		if (ok == 1) if(k == n) {
			for (int i = 1; i <= k; i++)
				g << sol[i] << ' ';
			g << '\n';
		}
		else bkt(k + 1);
	}
}

int main() {
	f >> n;
	bkt(1);
}