//#include <iostream>
#include <fstream>
using namespace std;
int n,a[100],i,sem;

ifstream cin("permutari.in");
ofstream cout("permutari.out");

int valid(int k)
{
    int sem=1;
    for(int j=1;j<k;j++)
    {
        if(a[j]==a[k])
        {
            sem=0;
        }
    }
    return sem;
}

void afis()
{
    for(i=1;i<=n;i++)
        cout<<a[i]<<' ';
    cout<<'\n';
}

void backt (int k)
{
    if(k>n)
    {
        afis();
    }
    else
    {
        for(int j=1; j<=n;j++)
        {
           a[k]=j;
           if(valid(k)==1)
            {
                a[k]=j;
                backt(k+1);
            }

        }
    }

}

int main()
{
    cin>>n;
    backt(1);
    return 0;
}

