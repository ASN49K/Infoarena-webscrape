#include <cstdio>
using namespace std;

const int NMAX = 10;

int f[NMAX], solution[NMAX];

void print_solution(int n){
    for(int i = 1; i <= n; i++){
        printf("%d ", solution[i]);
    }
    printf("\n");
}

void permutari(int position, int n){
    if(position == n + 1){
        print_solution(n);
        return;
    }
    for(int i = 1; i <= n; i++){
        if(f[i]) continue;
        f[i] = true;
        solution[position] = i;
        permutari(position + 1, n);
        f[i] = false;
    }
}

int main(){
    freopen("permutari.in", "r", stdin);
    freopen("permutari.out", "w", stdout);


    int n;
    scanf("%d", &n);
    permutari(1, n);
    return 0;
}
