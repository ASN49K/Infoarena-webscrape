#include <fstream>

void bkt(int n)
{
    std::ofstream g("permutari.out");
    int Sol[n + 1];
    int k = 1;
    Sol[k] = 0;
    while(k)
    {
        if(Sol[k] < n)
        {
            Sol[k]++;
            int i = 1;
            while(i < k)
            {
                if(Sol[i] == Sol[k])
                    break;
                i++;
            }
            if(i != k)
                continue;
            if(k == n)
            {
                for(i = 1; i <= n; i++)
                    g << Sol[i] << ' ';
                g << '\n';
            }
            else
                Sol[++k] = 0;
        }
        else
            k--;
    }
}

int main()
{
    std::ifstream f("permutari.in");
    int N;
    f >> N;
    f.close();
    bkt(N);
    return 0;
}
