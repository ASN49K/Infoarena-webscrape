#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n;
bool ap[10];
int ans[10];

void afis()
{
    int i;
    for(i=1; i<=n; i++)
        fout << ans[i] << ' ';
    fout << '\n';
}

void Back(int k)
{
    int i;
    for(i=1; i<=n; i++)
        if(!ap[i])
        {
            ap[i]=1;
            ans[k]=i;
            if(k==n)
                afis();
            else
                Back(k+1);
            ap[i]=0;
        }
}

int main()
{
    fin >> n;
    Back(1);
    return 0;
}
