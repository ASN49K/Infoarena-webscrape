#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n, i, out[20];
bool check (int val, int a)
{
    for (int i = 1; i < a; i++)
        if (out[i] == val)
            return 0;
    return 1;
}
void backtrack (int a)
{
    for (int i = 1; i <= n; i++)
    {
        if (check(i, a))
        {
            out[a] = i;
            if (a == n)
            {
                for (int j = 1; j <= n; j++)
                    fout << out[j] << ' ';
                fout << '\n';
            }
            else
                backtrack(a+1);
        }
    }
}
int main()
{
    fin >> n;
    backtrack(1);
    return 0;
}
