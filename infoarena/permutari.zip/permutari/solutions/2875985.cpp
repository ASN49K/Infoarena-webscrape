#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
#include <fstream>
#define newline fout << "\n"
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

template<typename it>

bool next_perm(it begin, it end) {
    if (begin == end)
        return false;
    
    it i = begin;
    ++i;
    
    if(i == end)
        return false;
    
    i = end;
    --i;
    
    while (true) {
        it j = i;
        --i;
        
        if (*i < *j) {
            it k = end;
            
            while (!(*i < *--k));
            
            iter_swap(i, k);
            reverse(j, end);
            return true;
        }
        
        if (i == begin) {
            reverse(begin, end);
            return false;
        }
    }
}
int main() {
    
    ios::sync_with_stdio();
    fin.tie();
    
    vector<int> permutation;
    
    int n;
    fin >> n;
        
    for(int i = 1; i <= n; i++)
        permutation.push_back(i);
    
    do {
        
        for(vector<int>::iterator itr = permutation.begin(); itr != permutation.end(); itr++)
            fout << *itr << " ";
        
        newline;
    } while(next_perm(permutation.begin(), permutation.end()));
    
    
    newline;
    
    return 0;
}
