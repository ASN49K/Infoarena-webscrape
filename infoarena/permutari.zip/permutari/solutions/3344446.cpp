#include <fstream>
#include <vector>
#include <queue>
#define INF 1e9
using namespace std;
ifstream cin ("permutari.in");
ofstream cout ("permutari.out");
int n;
int sol[20];
bool ver[20];
void bkt(int k)
{
    if (k-1==n)
    {
        for (int i=1;i<=n;i++)
            cout<<sol[i]<<' ';
            cout<<endl;
    }
    for (int i=1;i<=n;i++)
    {
        if (ver[i]==0)
        {
            sol[k]=i;
            ver[i]=1;
            bkt(k+1);
            ver[i]=0;
        }
    }
}

int main()
{
    cin>>n;
    bkt(1);
    return 0;
}
