#include<iostream>
#include<fstream>
#define FIN "permutari.in"
#define FOUT "permutari.out"

using namespace std;

int n,
    level,
    stack[100];

void init()
{
    stack[ level ] = 0;
}

int succesor()
{
    if(stack[level]<n) {
        stack[level]++;
        return 1;
    }
    return 0;
}

int valid(){
    for(int i = 1; i < level; i++)
    {
        if(stack[level]==stack[i]) return 0;
    }
    return 1;
}
int sol(){

    return level==n;
}

void afisare()
{
    for(int i=1; i<=n; i++)
    {
        cout<<stack[i]<<" ";
    }
    cout<<"\n";
}

void bk(){

     level = 1;
     init();
     
     while(level>0) {
         int h = 1, v = 0;
         while(h && !v) {
           h = succesor();
           if(h) {
             v = valid();
           }
         }
         if(h) {

           if(sol() == 1) {
             afisare();
           }else{
             level++;
             init();
           }
         }else{
           level--;
         }
     }
}
int main()
{
    freopen(FIN,"r",stdin);
    freopen(FOUT,"w",stdout);
    cout<<"n=";
    cin>>n;
    bk();
    return(0);
}