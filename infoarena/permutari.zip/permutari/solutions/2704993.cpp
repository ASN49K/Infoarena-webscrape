#include <iostream>
#include <fstream>
using namespace std;
ifstream be("combinari.in");
ofstream ki("combinari.out");

int a[20],n,k;

void bt(int j)
{
    if(j==k)
    {
        for(int x=1;x<=k;x++){
            ki<<a[x]<<" ";
            }
            ki<<"\n";
    }
    else {
        for(int i=a[j]+1;i<=n;i++)
        {
                a[j+1]=i;
                bt(j+1);
        }
    }
}
int main()
{
    be>>n>>k;
    bt(0);
    return 0;
}
