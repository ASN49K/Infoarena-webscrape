#include <bits/stdc++.h>

using namespace std;
vector<int> v;
int main() {
  ifstream cin("permutari.in");
  ofstream cout("permutari.out");
  int n;
  cin>>n;
  for(int i=1; i<=n; i++)
    v.push_back(i);

  int temp=1;
  for(int i=1; i<=n; i++)
    temp*=i;

  while(temp--) {
      for(int i=0;i<n;i++)
      cout<<v[i]<<" ";
  cout<<'\n';
    next_permutation(v.begin(), v.end());
  }


  return 0;
}
