#include <cstdio>
#include <algorithm>
#include <time.h>
#include <queue>
#include <cmath>
#include <stack>
#include <fstream>
//#include <iostream>
#include <bitset>

using namespace std;
#define nl '\n'
#define all(v) v.begin(),v.end()
#define eb(x) emplace_back(x)
#define ull unsigned long long
#define N 1002
ifstream cin("permutari.in");
ofstream cout("permutari.out");

template<class a, class type>
void print(a v, type t) {
    for_each(all(v), [](type x) { cout << x; });
    cout << nl;
}

double logXBaseY(double X, double Y) {
    return log2(X) / log2(Y);
}

int ver[9], n;
vector<int> ans;

inline void bkt() {
    for (int i = 1; i <= n; ++i) {
        if (!ver[i]) {
            ver[i] = 1;
            ans.eb(i);
            if (ans.size() == n) {
                print(ans, (int) 0);
            } else
                bkt();
            ans.pop_back();
            ver[i] = 0;
        }
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    clock_t tStart = clock();
    cin >> n;
    bkt();
    //    printf("\nTime taken: %.2fs\n", (double) (clock() - tStart) / CLOCKS_PER_SEC);
}
