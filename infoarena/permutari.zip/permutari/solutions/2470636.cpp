#include<iostream>
#include<vector>
#include<map>
#include<algorithm>
#include<fstream>
using namespace std;

ifstream fcin("permutari.in");
ofstream fcout("permutari.out");

int generate_perm(int pos, int n, vector<int> &cur_perm, vector<int> &options) {
  if (pos == n) {
    for (int i = 0; i < n; i++)
      fcout << cur_perm[i] << " ";
    fcout << "\n";
    return 1;
  }
  for (int i = 1; i <= n; i++) {
    if (options[i] == 1) {
      options[i] = 0;
      cur_perm[pos] = i;
      generate_perm(pos + 1, n, cur_perm, options);
      options[i] = 1;
    }
  }
  return 1;
}

int main() {
  int n; fcin >> n;
  vector<int> cur_perm(n);
  vector<int> options(n + 1, 1);
  generate_perm(0, n, cur_perm, options);
  return 0;
}
