#include <fstream>
using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");
bool ver[10];
int a[10],n;
void bck(int nr)
{
    if(nr==n)
    {
        for(int i=1;i<=n;++i)
            out<<a[i]<<' ';
        out<<'\n';
    }
    for(int i=1;i<=n;++i)
    {
        if(ver[i]==false)
        {
            ver[i]=true;
            a[nr+1]=i;
            bck(nr+1);
            ver[i]=false;
        }
    }
    return;
}
int main()
{
    in>>n;
    bck(0);
    return 0;
}
