#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int v[10];
bool used[10];
int n;

void afis(int k) {
    for(int i = 1; i <= k; i++)
        fout << v[i] << ' ';
    fout << '\n';
}

bool valid(int k) {
    return !used[v[k]];
}

bool solutie(int k) {
    return k == n;
}

void backtracking(int k) {
    for(int i = 1; i <= n; i++) {
        v[k] = i;
        if(valid(k)) {
            used[v[k]] = 1;
            if(solutie(k)) afis(k);
            else backtracking(k+1);
            used[v[k]] = 0;
        }
    }
}

int main() {
    fin >> n;
    backtracking(1);
}

