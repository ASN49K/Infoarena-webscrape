#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, i, st[10];

int succesor(int k) {

    if (st[k] < n){

        st[k]++;
        return 1;

    }

    else
        return 0;

}

int valid(int k) {

    int i;

    for (i = 1; i < k; i++)
        if (st[i] == st[k])
            return 0;

    return 1;

}

void backTrack(int k) {

    if (k == n + 1){
        for (i = 1; i <= n; i++)
            fout << st[i] << " ";

        fout << "\n";

    }

    else {

        st[k] = 0;

        while (succesor(k)){
            if (valid(k))
                backTrack(k + 1);

        }
    }
}

int main() {

    fin >> n;
    backTrack(1);
    fin.close();
    fout.close();

    return 0;

}
