#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, sub[20], fr[1005];

void afis() {
    for(int i=1; i<=n; i++) {
        if(sub[i]!=0) {
            fout << sub[i] << " ";
        }
    }
    fout << "\n";
}

void bktr(int k) {
    if(k==n+1) {
        afis();
        return;
    }
    for(int i=1; i<=n; i++) {
        if(fr[i]==0) {
            sub[k]=i;
            fr[i]++;
            bktr(k+1);
            sub[k]=0;
            fr[i]=0;
        }
    }
}

int main()
{
    fin >> n;
    bktr(1);
    return 0;
}
