#include <algorithm>
#include <fstream>
#include <vector>

using namespace std;

ifstream cin("permutari1.in");
ofstream cout("permutari1.out");

vector<int> v;

void f(vector<int> v,int n)
{
    if(v.size()==n)
    {
        for(int i=0;i<n;i++)
            cout<<v[i]<<' ';
        cout<<'\n';
        return;
    }
    for(int i=1;i<=n;i++)
    {
        if(find(v.begin(),v.end(),i)==v.end())
        {
            v.push_back(i);
            f(v,n);
            v.pop_back();
        }
    }
}

int main()
{
    int n;
    cin>>n;
    f(v,n);
    return 0;
}
