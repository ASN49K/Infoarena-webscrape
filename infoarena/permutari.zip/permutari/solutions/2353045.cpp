#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int v[9], n, viz[9];

void sol(){
    for(int i = 1; i <= n; ++i)
        fout << v[i] << " ";
    fout << endl;
}

void back(int k){
    for(int i = 1; i <= n; ++i)
        if(viz[i] == 0){
            viz[i] = 1;
            v[k] = i;
            if(k == n)
                sol();
            else back(k + 1);
        viz[i] = 0;
    }
}

int main(){

    fin >> n;
    back(1);
//    fin.close();
//    fout.close();
    return 0;
}
