#include <bits/stdc++.h>
using namespace std;
define newline "\n"
ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, sir[9], frq[100];
void gen(int pos, int sir[9]) {
	if(pos == n + 1) {
	   for(int i = 1; i <= n; ++i)
	       fout << sir[i] <<" ";
	   fout << newline;
	   return;
	}
	for(int i = 1; i <= n; ++i) {
		if(frq[i] == 0) {
		   sir[pos] = i; 
		   frq[i] = 1;
		   gen(pos + 1, sir);
		   frq[i] = 0;
		}
	}
}
int main() {
	fin >> n;
	gen(1, sir);
	return 0;
}