#include <fstream>
#include <vector>

using namespace std;

ifstream cin("aib.in");
ofstream cout("aib.out");

vector <int> v;
int n, m;
int putere;

void update(int poz, int val){
    for (int i = poz; i <= v.size(); i += (i & -i))
        v[i] += val;
}

int query(int x){
    int sum = 0;
    for (int i = x; i; i -= (i & -i))
        sum += v[i];
    return sum;
}

int caut(int sum){
    int poz = 0, s = 0;
    for(int i = putere; i >= 1; i >>= 1)
        if((poz + i <= n) && (s + v[poz + i] <= sum))
            poz += i, s+= v[poz];
    if(s == sum && poz != 0)
        return poz;
    return -1;
}

int main() {

    cin >> n >> m;
    v.resize(n + 5);
    putere = 1;
    while(putere * 2 <= n)
        putere *= 2;
    for (int i = 1; i <= n; i++) {
        int x;
        cin >> x;
        update(i, x);
    }
    for (int i = 0; i < m; ++i) {
        int cer;
        cin >> cer;
        if(cer == 0){
            int poz, val;
            cin >> poz >> val;
            update(poz, val);
        }
        else if(cer == 1){
            int st, dr;
            cin >> st >> dr;
            cout << query(dr) - query(st - 1) << '\n';
        }
        else{
            int sum;
            cin >> sum;
            cout << caut(sum) << '\n';
        }
    }
    return 0;
}
