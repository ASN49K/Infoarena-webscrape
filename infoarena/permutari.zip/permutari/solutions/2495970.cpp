#include <bits/stdc++.h>
typedef unsigned int ui;
typedef long long ll;
using namespace std;

int N, per[100];

int solutie (int k){
    if (k == N)
        return 1;
    return 0;
}

int valid (int k){
    for (int i = 1; i <= k-1; i++){
        if (per[k] == per[i]){
            return 0;
        }
    }
    return 1;
}

void afisare(int k){
    for (int i = 1; i <= k; i++){
        cout << per[i] << " ";
    }
    cout << "\n";
}
void permutari(int k){
    for (int i = 1; i <= N; i++){
        per[k] = i;
        if (valid(k)){
            if (solutie(k))
                afisare(k);
            else{
            permutari(k+1);
            }
        }

    }

}

int main(){

ifstream cin("permutari.in");
ofstream cout("permutari.out");

cin >> N;
per[0] = 0;
permutari(1);

return 0;
}
