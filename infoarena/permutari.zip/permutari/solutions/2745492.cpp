#include <fstream>

using namespace std;

ifstream fin ("permutari.in");
ofstream fout("permutari.out");

int n;
int x[10];

void afisare(){
    for (int i = 1; i <= n; i++)
        fout << x[i] << ' ';
    fout << '\n';
}

bool ok (int k){
    for (int i = 1; i < k; i++)
        if (x[i] == x[k])
            return false;
    return true;
}

void Back(int k){
    for (int i = 1; i <= n; i++){
        x[k] = i;
        if (ok(k) == true){
            if (k == n)
                afisare();
            else
                Back(k + 1);
        }
    }
}


int main(){
    fin >> n;
    Back(1);
    return 0;
}
