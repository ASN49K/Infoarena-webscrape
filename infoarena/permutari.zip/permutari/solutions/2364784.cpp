#include <iostream>
#include <fstream>

std::ifstream f("permutari.in");
std::ofstream g("permutari.out");

using namespace std;

int n,k, sol[1000];

void afisare()
{
  for(int i = 1; i <= n; i++)
    g<<sol[i]<<" ";

  g<<'\n';
}

bool ebun(int k)
{
    for(int i = 1; i < k; i++)
        if(sol[i] == sol[k])
        return 0;

    return 1;
}

void bk(int p)
{
  for(int i = 1; i <= n; i++)
    {
      sol[p] = i;
      if(ebun(p))
        if(p == n)
             afisare();
        else
                bk(p + 1);
    }
}

int main()
{
    f>>n;
    bk(1);
    return 0;
}
