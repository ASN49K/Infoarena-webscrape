#include <iostream>
#include <fstream>

std::ifstream f("permutari.in");
std::ofstream g("permutari.out");
int x[11], n;
void afisare()
{
    for(int j=1; j<=n; j++)
        g << x[j] << " ";
    g << '\n';
}
bool OK(int k)
{
    for(int i=1; i<k; i++)
        if(x[k] == x[i]) return false;
    return true;
}
bool Solutie(int k)
{
    return k == n;
}
void back(int k)
{
    for(int i=n; i>=1; i--)
    {
        x[k] = i;
        if(OK(k))
            if(Solutie(k)) afisare();
            else back(k+1);
    }
}
int main()
{
    //x[] vectorul solutie
    //elementele sunt intre 1 si n;
    //elementele nu se repeta
    //x[] se construieste pas cu pas, element cu element // el va contine o permutare valida cand va contine n elemente valide
    //x[k] apartine 1,n
    //x[k] diferit de x[1] x[2]...x[k-1] pentru k apartine 2,n
    //k==n(ca sa existe solutia)
    f >> n;
    back(1);
    return 0;
}
