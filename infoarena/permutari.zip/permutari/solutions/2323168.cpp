
#include <iostream>
#include <fstream>
#include <vector>

using std::cin;
using std::cout;

using std::vector;

using std::ifstream;
using std::ofstream;

ifstream in("permutari.in");
ofstream out("permutari.out");

vector<int> v;
int n, k;

void comb(int l = 0) {
	if (l == n) {
		for (auto i : vector<int>(v.begin() + 1, v.end())) {
			out << i << " ";
		}
		out << "\n";
	} else {
		for (int i = 1; i <= n; i++) {

			int ok = 1;
			for (int j = 0; j <= l; j++) {
				if (v[j] == i) ok = 0;
			}

			if (ok) {
				v[l + 1] = i;
				comb(l + 1);
			}

		}
	}
}

int main() {
	in >> n;
	v.resize(n + 1);
	comb();
}
