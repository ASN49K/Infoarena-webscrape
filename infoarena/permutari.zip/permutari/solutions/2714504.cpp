#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int n;
int x[10];

void afisare(int k)
{
    for(int i = 1; i <= k; ++ i)
        out << x[i] << " ";
    out << '\n';
}

bool valid(int k)
{
    for(int i = 1; i < k; ++ i)
        if(x[k] == x[i]) return 0;
    return 1;
}

void backtrack(int k)
{
    for(int i = 1; i <= n; ++ i)
    {
        x[k] = i;

        if(valid(k))

            if(k == n) afisare(n);
            else backtrack(k + 1);
    }
}

int main()
{
    in >> n;
    backtrack(1);
    return 0;
}
