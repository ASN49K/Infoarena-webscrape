#include <bits/stdc++.h>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

const int NMAX = 10;

int F[NMAX], X[NMAX], n;

void afis(){
    for(int i = 1;i<=n;++i)
        fout << X[i] << ' ';
    fout << '\n';
}

void back(int k){
    for(int i = 1;i<=n;++i)
        if(!F[i]){
            F[i] = 1;
            X[k] = i;
            if(k < n)
                back(k + 1);
            else
                afis();
            F[i] = 0;
        }
}

int main(){

    fin >> n;
    back(1);
    return 0;
}