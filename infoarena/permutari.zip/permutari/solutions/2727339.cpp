#include <algorithm>
#include <stdio.h>
#include <bits/stdc++.h>

#define rep(i, n) for(int i = 0; i < (int)(n); i++)

using namespace std;
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
// const int INF = 0x3f3f3f3f;

ifstream fin {"permutari.in"};
ofstream fout {"permutari.out"};

int N;
int d[10];
void write() {
  rep(j, N) { fout << d[j] << ' '; }
  fout << '\n';
}

bool my_next_permutation(int first, int last) {
  if (first == last || first == last - 1)
    return false;
  int i = last-1;
  while(i > first && d[i-1] > d[i]) {
    --i;
  }
  if (i == first) {
    reverse(d+first, d+last);
    return false;
  }
  --i;
  int j = last - 1;
  while(d[j] < d[i]) {
    --j;
  }
  swap(d[i], d[j]);
  reverse(d+i+1, d+last);
  return true;
}

int main(void) {
  // freopen("permutari.in", "r", stdin);
  std::ios_base::sync_with_stdio(false);
  std::cin.tie(NULL);
  iota(d, d+10, 1);
  fin >> N;

  do {
    write();
  } while(my_next_permutation(0, N));

  return 0;
}
