#include<bits/stdc++.h>
using namespace std;
int n;
vector<int> solution(100, 0);

ifstream fcin("permutari.in");
ofstream fcout("permutari.out");


void back(int pos, set<int> domain) {
	if(pos == n) {
		for(int i = 0; i < n; i++) fcout<<solution[i]<<" ";
		fcout << "\n";
		return;
	}
	set<int> dom(domain.begin(), domain.end());
	for(auto i : domain) {
		solution[pos] = i;
		dom.erase(i);
		back(pos + 1, dom);
		dom.emplace(i);
	}
}

int main() {
	std::ios::sync_with_stdio(false);
	fcin>>n;
	set<int> domain;
	for(int i = 1; i <= n; i++) domain.insert(i);
	back(0, domain);
	return 0;
}