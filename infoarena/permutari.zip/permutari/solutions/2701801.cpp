#include <bits/stdc++.h>
#define startt ios_base::sync_with_stdio(false);cin.tie(0);
#pragma GCC target ("avx2")
#pragma GCC optimization ("O3")
#pragma GCC optimization ("unroll-loops")
typedef unsigned long long ull;
typedef long long  ll;
using namespace std;
#define FOR(n) for(int i=0;i<n;i++)
#define vt vector
#define vint vector<int>
#define all(v) v.begin(), v.end()
#define sz(a) (int)a.size()
#define MOD 1000000007
#define MOD2 998244353
#define MX 1000000000
#define nax 100005
#define MXL 1000000000000000000
#define PI 3.14159265
#define pb push_back
#define pf push_front
#define sc second
#define fr first
#define int ll
#define endl '\n'
#define ld long double

vector<int> read(int n) {vector<int> a; for (int i = 0; i < n; i++) { int x; cin >> x; a.pb(x);} return a;}

int lp[2000000]; //INITIALIZE WITH 0

int32_t main(){
	startt;
	freopen("permutari.in", "r", stdin);
	freopen("permutari.out", "w", stdout);
	int n;
	cin >> n;
	vint a;
	for(int i = 1; i <= n; i++)
	{
		a.pb(i);
	}
	do {
		for(auto x : a)
		{
			cout << x << " ";
		}
		cout << endl;
	} while(next_permutation(all(a)));
}

