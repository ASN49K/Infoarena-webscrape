#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, viz[10], a[10];

void afis()
{	for(int i=1; i<=n; i++)
		fout << a[i] << ' ';
	fout << '\n';
}

void bkt(int x)
{	if(x == n + 1)
		afis();
	else
		{	for(int i=1; i<=n; i++)
				if(!viz[i])
					{	viz[i] = 1;
						a[x] = i;
						bkt(x+1);
						viz[i] = 0;
					}
		}
}

int main()
{
	fin >> n;
	bkt(1);
	return 0;
}

