#include<cstdio>
int n,k=1,s[9],i,o;
int main()
{
    freopen("permutari.in","r",stdin),freopen("permutari.out","w",stdout),scanf("%d",&n);
    while(k)
    {
        for(s[k]++,o=i=1;i<k&&o;i++)
            if(s[k]==s[i])
                o=0;
        if(o)
            if(s[k]<=n)
                if(k==n)
                {
                    for(i=1;i<=n;i++)
                        printf("%d ",s[i]);
                    printf("\n");
                }
                else
                    s[++k]=0;
            else
                k--;
    }
}
