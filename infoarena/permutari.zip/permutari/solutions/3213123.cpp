#include <bits/stdc++.h>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

#define pii pair<int, int>
#define pb push_back
#define fi first
#define se second

const int NMAX = 9;
const int INF = 0x3f3f3f3f;

int n;
bool v[NMAX];
vector<int> p;

void read()
{
    in >> n;
}

void permutations(int k)
{
    if (k == n)
    {
        for (auto i : p)
            out << i << ' ';
        out << '\n';
        return;
    }
    for (int i = 1; i <= n; i++)
    {
        if (v[i])
            continue;
        if (!v[i])
            v[i] = 1, p.push_back(i), permutations(k + 1);
        p.pop_back();
        v[i] = 0;
    }
}

void solve()
{
    permutations(0);
}

int main()
{
    cin.tie(0);
    cout.tie(0);
    ios::sync_with_stdio(false);

    read();
    solve();

    return 0;
}