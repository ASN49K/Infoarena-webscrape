#include <fstream>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int stiva[20], N;
int uz[20];

void BKT(int nivel)
{
    if(nivel == N + 1)
    {
        for(int i = 1; i <= N; i++)
        out << stiva[i] << " ";
        out << "\n";
    }
    else
    for(int i = 1; i <= N; i++)
    if(!uz[i])
    {
        uz[i] = 1;
        stiva[nivel] = i;
        BKT(nivel + 1);
        uz[i] = 0;
    }
}

int main()
{
    in >> N;
    BKT(1);
    return 0;
}
