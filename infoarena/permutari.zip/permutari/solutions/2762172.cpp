#include <iostream>
#include <fstream>

using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");
bool volt[10];
void backtrack_perm(int n, int k, int megold[], bool volt[])
{
    if(k==n){
        for(int i=0; i<n; i++)
            out<<megold[i]<<" ";
        out<<endl;
    }
    else{
        for(int i=1; i<=n; i++) {
            if (!volt[i]) {
                megold[k]=i;
                volt[i]=true;
                backtrack_perm(n, k+1, megold, volt);
                volt[i]=false;
            }
        }
    }
}
int main()
{
    int n;
    in>>n;
    int megold[n+1];
    backtrack_perm(n, 0, megold, volt);
    return 0;
}
