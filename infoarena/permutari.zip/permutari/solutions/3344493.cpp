#include <fstream>
#include <iostream>
#include <cmath>
#include <cstring>
#include <algorithm>
#include <vector>
#include <string>
#include <stack>
#include <queue>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int st[10],n,viz[10];
void afis() {
    for (int i=1; i<=n; i++)
        fout<<st[i]<<" ";
    fout<<"\n";
}
void back(int top) {
    for (int i=1; i<=n; i++)
        if (!viz[i]) {
            viz[i]=1;
            st[top]=i;
            if (top==n)
                afis();
            else
                back(top+1);
            viz[i]=0;
        }
}
int main() {
    fin>>n;
    back(1);
    return 0;
}
// 2 0 3 -1 7 -4
