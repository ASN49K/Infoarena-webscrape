
#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int N;
vector<int> st;

int main() {
    ifstream fi("permutari.in");
    ofstream fo("permutari.out");

    fi >> N;
    st = vector<int>(N);

    int x = 1;
    for (int &i : st)
        i = x++;


    do {
        for (int i : st)
            fo << i << " ";
        fo << "\n";
    } while(next_permutation(st.begin(), st.end()));

    fo.close();
    fi.close();
    return 0;
}
