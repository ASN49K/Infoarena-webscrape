#include <iostream>
#include <fstream>
using namespace std;

ifstream fin ("permutari.in");
ofstream fout ("permutari.out");
int n, v[9];

int good(int v[9], int length, int n) {
    for (int i = 1; i < length; ++i){
        if (v[i] == v[length])
            return 0;
    }
    return 1;
}

void bkt(int v[9], int lg, int n) {
    for (int i = 1; i <= n; ++i) {
        v[lg] = i;
        if (good(v, lg, n) == 1){
            if (lg == n) {
                for (int j = 1; j <= n; ++j)
                    fout << v[j] << ' ';
                fout << '\n';
            } else {
                bkt(v, lg + 1, n);
            }
        }
    }
}

int main() {
    fin >> n;
    bkt(v, 1, n);
    return 0;
}
