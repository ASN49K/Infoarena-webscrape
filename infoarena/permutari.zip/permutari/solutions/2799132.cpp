#include <fstream>
#include <climits>
#include <vector>
#include <queue>
#include <set>
#include <stack>
#include <string>
#include<bitset>
#include <map>
#include <cstring>
#include<algorithm>
#define MOD 1234567
using namespace std;

ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int n;
int v[9];
int fr[9];

void perm(int nivel)
{
    if(nivel>n)
    {
        //afisez si ies
        for(int i=1; i<=n; i++)
        {
            fout<<v[i]<<" ";
        }
        fout<<"\n";
        return;
    }
    for(int i=1; i<=n; i++)
    {
        if(fr[i]==0)
        {
            v[nivel]=i;
            fr[i]=1;
            perm(nivel+1);
            fr[i]=0;
        }
    }
}

int main()
{
    fin>>n;
    perm(1);
    return 0;

}
