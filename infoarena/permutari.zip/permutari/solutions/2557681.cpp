#include <bits/stdc++.h>
using namespace std;
ifstream fin("bfs.in");
ofstream fout("bfs.out");
const int MAXN = 1 * 1e5 + 5;
int n, v[MAXN];
void afis(int k){
    for(int i = 1; i <= k; ++i)
        fout << v[i] << " ";
    fout << '\n';
}
bool ok(int k){
    for(int i = 1; i < k; ++i)
        if(v[i] == v[k]) return false;
    return true;
}
void backtr(int k){
    for(int i = 1; i <= n; ++i){
        v[k] = i;
        if(ok(k)){
            if(k == n) afis(k);
            else backtr(k + 1);
        }
    }
}
int main()
{
    fin >> n;
    backtr(1);
    return 0;
}
