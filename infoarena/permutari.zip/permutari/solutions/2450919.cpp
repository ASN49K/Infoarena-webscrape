#include <fstream>

std::ifstream fin("permutari.in");
std::ofstream fout("permutari.out");

unsigned short p[9], N;

bool succesor(unsigned short K)
{
    if(p[K] < N)
    {
        p[K]++;
        return true;
    }

    return false;
}

bool valid(unsigned short K)
{
    for(unsigned short i = 1; i < K; i++)
    {
        if(p[i] == p[K]) return false;
    }

    return true;
}


void afis(void)
{
    for(unsigned short i = 1; i <= N; i++) fout << p[i] << ' ';
    fout << '\n';
}

void permutari(unsigned short K = 1)
{
    p[K] = 0;

    while(succesor(K))
    {
        if(valid(K))
        {
            if(K == N) afis();
            else permutari(K + 1);
        }
    }
}

int main()
{
    fin >> N;

    permutari();
}
