#include <bits/stdc++.h>
using namespace std;

const string FILENAME = "ciur";

ifstream fin(FILENAME + ".in");
ofstream fout(FILENAME + ".out");

int n;
vector<int> sol;

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
        sol.push_back(i);
    do
    {
        for(auto i : sol)
            fout << i << " ";
        fout << "\n";
    }while(next_permutation(sol.begin(), sol.end()));
    fin.close();
    fout.close();
    return 0;
}
