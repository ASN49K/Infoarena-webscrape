// Ionascu George-Razvan, 324CA

#include <iostream>
#include <vector>
using namespace std;

bool find(int number, vector<int> a) {
    for (int i = 0; i <= (int) a.size(); i++) {
        if (number == a[i]) {
            return true;
        }
    }
    return false;
}

void backtracking(int length, int n, vector<int> a) {
    if (length == n) {
        for (int i = 0; i < n; i++) {
            cout << a[i];
        }

        cout << "\n";
        return;
    }

    for (int i = 1; i <= n; i++) {
        bool is_used = find(i, a);

        if (is_used == false) {
            a[length] = i;
            backtracking(length + 1, n, a);
            a[length] = 0;
        }
    }

}

int main() {
    int n, length;
    cin >> n;

    vector<int> a(n, 0);

    backtracking(0, n, a);

    return 0;
}