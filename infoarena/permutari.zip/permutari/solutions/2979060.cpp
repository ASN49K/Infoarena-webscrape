#include <bits/stdc++.h>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n, a[] = {1, 2, 3, 4, 5, 6, 7, 8};

int main()
{
    f >> n;

    do {
        for (int i = 0; i < n; ++i) {
            g << a[i] << ' ';
        }

        g << "\n";
    } while (next_permutation(a, a + n));

    g.close();

    return 0;
}
