#include <bits/stdc++.h>
using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int n, sol[15];

void afis(){
    for(int i = 1; i <= n; i++)
        out<<sol[i]<<" ";
    out<<"\n";
}

bool ok(int k){
    for(int i = 1; i < k; i++)
        if(sol[i] == sol[k])
            return false;
    return true;
}

void bkt(int k){
    for(int i = 1; i <= n; i++){
        sol[k] = i;
        if(ok(k)){
            if(k == n)
            afis();
            else
            bkt(k + 1);
        }
    }
}

int main(){
    in>>n;
    bkt(1);
}
