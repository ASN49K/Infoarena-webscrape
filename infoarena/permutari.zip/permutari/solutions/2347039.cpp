#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n,v[20],viz[20];

void afisare(int k) //afişează conţinutul vectorului v
{int i;
for (i=1;i<=k;i++)
 fout<<v[i]<<" ";
fout<<endl;}

void BK(int k)
{
    if(k==n)
        afisare(k);
    else
    {
        for(int i=1;i<=n;i++)
            if(viz[i]==0)
            {
                viz[i]=1;
                v[k]=i;
                BK(k+1);
                viz[i]=0;
            }
    }
}


int main()
{fin>>n; //se citeşte n
BK(1);
return 0; //apelăm funcţia BK pentru completarea poziţiei 1din vectorul v
}
