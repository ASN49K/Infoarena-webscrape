#include <iostream>
#include <fstream>
using namespace std;
int v[8];

ifstream fin("permutari.in");
ofstream fout("permutari.out");

bool verif(int x,int p){
    for(int i=0;i<p;i++){
        if(x==v[i]) return false;
    }
    return true;
}

void bkt(int n,int k,int p){
    for(int i=1;i<=n;i++){
        v[p]=i;
        if(p>0 && verif(v[p],p)){
            if(p==n-1){
                for(int j=0;j<n;j++) fout<<v[j]<<" ";
                fout<<endl;
            }else{
                bkt(n,k,p+1);
            }
        }else{
            if(p==0) bkt(n,k,p+1);
        }
    }
}

int main()
{
    int n,k;

    fin>>n;
    bkt(n,0,0);
    return 0;
}
