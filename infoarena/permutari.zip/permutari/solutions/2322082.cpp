#include <bits/stdc++.h>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int n, x[25];
void afisare()
{
    for(int i = 1; i <= n; i ++)
        g << x[i] << " ";
    g << "\n";
}
bool valid(int k)
{
    for(int i = 1; i < k; i ++)
        if(x[i] == x[k])return false;
    return true;
}
void backtrack(int k)
{
    for(int i = 1; i <= n; i ++)
    {
        x[k] = i;
        if(valid(k))
        {
            if(k == n)afisare();
            else backtrack(k + 1);
        }
    }
}
int main()
{
    f >> n;
    backtrack(1);
    return 0;
}
