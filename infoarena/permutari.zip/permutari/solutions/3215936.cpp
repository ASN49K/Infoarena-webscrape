#include <fstream>


using namespace std;
int n,x[10],f[10];
ifstream fin("permutari.in");
ofstream fout("permutari.out");
void back(int poz){
    if(poz==n+1)
    {
        for(int i=1;i<=n;i++)
            fout<<x[i]<<" ";
        fout<<'\n';
    }
    else{
        for(int i=1;i<=n;i++)
            if(f[i]==0){
                x[poz]=i;
                f[i]=1;
                back(poz+1);
                f[i]=0;
            }
    }
}

int main(){
    fin>>n;
    back(1);

    return 0;
}
