#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, st[10], f[10];
void Back( int k )
{
    int i;
    if ( k == n + 1 )
    {
        for ( i = 1; i <= n; ++i )
            fout << st[i] << " ";
        fout << '\n';
    }
    else
    {
        for ( i = 1; i <= n; ++i )
        {
            if ( f[i] == 0 )
            {
                st[k] = i;
                f[i] = 1;
                Back(k + 1);
                f[i] = 0;
            }
        }
    }
}
int main()
{
    fin >> n;
    Back(1);
    return 0;
}
