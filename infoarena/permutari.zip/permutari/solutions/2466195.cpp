#include <fstream>
#include <algorithm>
using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");
int n,i,a[11];
int main()
{
    in>>n;
    for (i=0;i<n;++i)
    {
        a[i]=i+1;
        out<<i+1<<" ";
    }
    out<<'\n';
    while (next_permutation(a,a+n))
    {
        for (i=0;i<n;++i)
            out<<a[i]<<" ";
        out<<'\n';
    }
    return 0;
}
