#include <bits/stdc++.h>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

const int MAXN = 6;

int n;
int s[MAXN + 1];

void bck(int k) {
    if (k == n + 1) {
        for (int i = 1; i <= n; ++ i) out << s[i] << ' ';
        out << '\n';
    }
    else {
        for (int i = 1; i <= n; ++ i) {
            bool ok = 1;
            for (int j = 1; j <= k && ok; ++ j) {
                if (s[j] == i) ok = 0;
            }
            if (ok) {
                s[k] = i;
                bck(k + 1);
            }
        }
    }
}

int main() {
    in >> n;
    bck(1);

    return 0;
}
