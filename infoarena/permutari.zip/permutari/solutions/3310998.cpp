#include <fstream>
using namespace std;
ifstream cin("permutari.in");
ofstream cout("permutari.out");
int n,v[10];
bool fr[10];
void bck(int k){
    if(k==n+1){
        for(int i=1;i<=n;i++)
            cout<<v[i]<<" ";
        cout<<'\n';
        return ;
    }
    for(int i=1;i<=n;i++)
        if(!fr[i]){
            fr[i]=1;
            v[k]=i;
            bck(k+1);
            fr[i]=0;
        }
}
int main()
{
    cin>>n;
    bck(1);
    return 0;
}
