#include <cstdio>
#include <iostream>
#include <vector>

using namespace std;

void backtracking(vector<int> &sol, vector<int> &domain, int n) {
  if (n == sol.size()) {
    for (int i = 0; i < n; i++)
      printf("%d ", sol[i]);
    printf("\n");
    return;
  }

  for (int i = 0; i < domain.size(); i++) {
    /* do */
    int value = domain[i];

    sol.push_back(value);
    domain.erase(domain.begin() + i);

    /* recursion */
    backtracking(sol, domain, n);

    /* undo */
    sol.pop_back();
    domain.insert(domain.begin() + i, value);
  }
}

int main(int argc, char *argv[]) {
  int n;
  scanf("%d", &n);
  vector<int> sol;
  vector<int> domain;

  for (int i = 1; i <= n; i++)
    domain.push_back(i);

  backtracking(sol, domain, n);
  return 0;
}
