#include<fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n,x[10];

void Display()
{
    int i;
    for(i=1;i<=n;i++)
        fout<<x[i]<<" ";
    fout<<'\n';
}

int Valid(int k)
{
    int i;
    for(i=1;i<k;i++)
        if(x[i]==x[k])
            return 0;
    return 1;
}

void Backtracking(int k)
{
    if(k>n)
        Display();
    else
    {
        int i;
        for(i=1;i<=n;i++)
        {
            x[k]=i;
            if(Valid(k))
                Backtracking(k+1);
        }
    }
}

int main()
{
    fin>>n;
    Backtracking(1);
    return 0;
}
