#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int main()
{
    int n;
    fin >> n;
    int v[n];
    for(int i=0; i<n; i++) {
        v[i]=i+1;
    }
    do {
        for(int i=0; i<n; i++) {
            fout << v[i] << " ";
        }
        fout << "\n";
    } while(next_permutation(v, v+n));
    return 0;
}
