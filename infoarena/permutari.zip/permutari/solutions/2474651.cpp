#include <fstream>
#define MAX 50000

using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int n, per[MAX];
void afisare () {
    for (int i = 1; i <= n; i++)
        fout << per[i] << " ";
    fout << "\n";
}

void interschimbare (int a, int b) {
    int aux = per[b];
    per[b] = per[a];
    per[a] = aux;
}

void permutare (int l, int r) {
    if (l == r)
        afisare ();
    else {
        for (int i = l; i <= r; i++) {
            interschimbare(i, l);
            permutare(l+1, r);
            interschimbare(i,l);
        }
    }
}

int main()
{
    fin >> n;

    for (int i = 1; i <= n; i++)
        per[i] = i;

    permutare (1, n);
    return 0;
}
