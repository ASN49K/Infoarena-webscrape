#include <iostream>
#include <fstream>

std::ifstream fin("permutari.in");
std::ofstream fout("permutari.out");

void print(int n, int x[]) {
	for (int i = 1; i <= n; i++)
		fout << x[i] << " ";
	fout << std::endl;
}

bool check_duplicates(int n, int x[], int start) {
	for (int i = 1; i < start; i++)
	{
		if (x[i] == x[start])
			return false;
	}

	return true;
}

void generate_permutation(int start, int n, int x[]) {
	for (int i = 1; i <= n; i++)
	{
		x[start] = i;
		if (check_duplicates(n, x, start))
			if (n == start)
			{
				print(n, x);
			}
			else
			{
				generate_permutation(start + 1, n, x);
			}
	}
}

int main() {
	int x[8] = { 0 };
	int n_numbers;

	fin >> n_numbers;

	generate_permutation(1, n_numbers, x);

	return 0;
}