#include <fstream>
using namespace std;
ifstream cin("permutari.in");
ofstream cout("permutari.out");
int st[10],n;
int valid(int k)
{
    for(int i=1;i<k;i++)
        if(st[i]==st[k]) return 0;
    return 1;
}
int solutie(int k)
{
    return k==n;
}
void tipareste(int k)
{
    for(int i=1;i<=k;i++)
        cout<<st[i]<<" ";
    cout<<endl;
}
void backtr(int k)
{
    if(k==n+1) tipareste(k-1);
    else{
        for(int i=1;i<=n;i++)
        {
            st[k]=i;
            if(valid(k))
                backtr(k+1);
        }
    }
}
int main()
{
    cin>>n;
    backtr(1);
    cin.close();
    cout.close();
    return 0;

}