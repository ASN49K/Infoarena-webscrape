#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ofstream out ("permutari.out");

vector <int> sol;
int n;
bool viz[20];


void afis() {
  for( auto x : sol )
    out << x << " ";
  out << "\n";
}

void bkt ( int k ){
    if ( k == n + 1 ){
      afis();
      return;
    }
    for (int i = 1; i <= n; i++ )
      if( !viz[i] ){
        sol.push_back( i );
        viz[i] = 1;
        bkt ( k + 1 );
        sol.pop_back();
        viz[i] = 0;
      }
}


int main(){

  ifstream in( "permutari.in");
  in >> n;
  in.close();

  bkt ( 1 );
  out.close();

  return 0;
}
