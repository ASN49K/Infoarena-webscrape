// Generarea Permutarilor folosing std::next_permutation
#include <stdio.h>
#include <bits/stdc++.h>

#define rep(i, n) for(int i = 0; i < n; i++)
#define REP(i,a,b) for(int i = a; i < b; i++)

using namespace std;
typedef pair<int, int> pii;

int N, d[10];

int main(void) {
  freopen("permutari.in", "r", stdin);
  freopen("permutari.out", "w", stdout);
  cin >> N;
  rep(i, N) { d[i] = i+1; }

  do {
    rep(i, N)
      cout << d[i] << ' ';
    cout << endl;
  } while(next_permutation(d, d+N));

  return 0;
}
