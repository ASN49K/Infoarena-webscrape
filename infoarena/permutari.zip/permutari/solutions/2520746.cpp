#include <fstream>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int x[9], n;
void afis()
{
    for(int i = 1; i <= n; ++ i)
        g << x[i] << " ";
    g << "\n";
}
bool valid(int k)
{
    for(int i = 1; i < k; ++ i)
        if(x[k] == x[i]) return false;
    return true;
}
void back(int k)
{
    for(int i = 1; i <= n; ++ i)
    {
        x[k] = i;
        if(valid(k))
            if(k == n) afis();
         else back(k + 1);
    }
}
int main()
{
    f >> n;
    back(1);
    return 0;
}
