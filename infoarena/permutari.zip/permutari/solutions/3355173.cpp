// Ionascu George-Razvan, 324CA

#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

vector<int> a;
vector<int> visited;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

void bkt(int n, int size) {
    if (size == n) {
        for (int i = 0; i < size; i++) {
            fout << a[i] << " ";
        }
        fout << "\n";
        return;
    }


    for (int i = 1; i <= n; i++) {
        if (visited[i] == 0) {
            visited[i] = 1;
            a[size] = i;

            bkt(n, size + 1);

            a[size] = 0;
            visited[i] = 0;
        }
    }
}

int main() {
    int n;
    cin >> n;

    a.resize(n + 1);
    visited.resize(n + 1, 0);

    bkt(n, 0);

    return 0;
}