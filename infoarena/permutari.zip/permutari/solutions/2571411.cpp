#include <fstream>

using namespace std;
int n,sol[10];
bool sel[10];
ifstream in("permutari.in");
ofstream out("permutari.out");

void bkt(int k)
{
    if(k==n+1)
    {
        for(int i=1;i<=n;i++) out<<sol[i]<<" ";
        out<<'\n';

    }
    else
    {
       for(int i=1;i<=n;i++)
       {
           if(sel[i]==0)
           {
               sel[i]=1;
               sol[k]=i;
               bkt(k+1);
               sel[i]=0;
           }
       }
}
}
int main()
{
    in>>n;
    bkt(1);

    return 0;
}
