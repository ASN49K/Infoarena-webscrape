#include <bits/stdc++.h>

#include <random>

using namespace std;

signed main()
{
    freopen("permutari.in", "r", stdin);
    freopen("permutari.out", "w", stdout);
    vector <int> permutation;
    int n;
    cin >> n;
    int totalPerms = 1;

    for (int i = 1; i <= n; ++i) {
        permutation.push_back(i);
        totalPerms *= i;
    }

    for (int i = 1; i <= totalPerms; ++i) {
        for (auto j : permutation) {
            cout << j << ' ';
        }
        cout << '\n';
        next_permutation(permutation.begin(), permutation.end());
    }
    return 0;
}