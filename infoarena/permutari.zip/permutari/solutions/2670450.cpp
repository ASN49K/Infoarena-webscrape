#include <bits/stdc++.h>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n;
bool viz[10];
int sol[10];

void Afisare()
{
    for(int i=1;i<=n;i++)
    {
        fout<<sol[i]<<" ";
    }
    fout<<"\n";
}

void Back(int x)
{
    if(x==n+1)
    {
        Afisare();
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            if(viz[i]==0)
            {
                sol[x]=i;
                viz[i]=1;
                Back(x+1);
                viz[i]=0;
            }
        }
    }
}

int main()
{
    fin>>n;
    Back(1);
    return 0;
}
