#include <iostream>
#include    <fstream>


using namespace std;
bool used[110];
int perm[110];int N;int i;int lvl;ifstream fin("permutari.in");
ofstream fout("permutari.out");

void back(int lvl)
{
    if(lvl>N)
        {for(i=1;i<=N;i++)
        fout<<perm[i]<<"  ";
        fout<<endl;
    return;}
    for(int i=1;i<=N;i++){
        if(!used[i]){
            perm[lvl]=i;
        used[i]=1;
        back(lvl+1);
        used[i]=0;
    }}
}



int main()
{

    fin>>N;
    if(N<1||N>8)
        return 0;
    else{ for(int j=1;j<=N;j++)
        fin>>perm[j];
    back(1);
}}
