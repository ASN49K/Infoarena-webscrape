#include <iostream>
#include <fstream>
#define N_MAX 2000005
#define MOD 666013
using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");
int n,sol[9],fr[9];
void perm(int x) {
    if (x == n) {
        for (int i = 0; i < n; i++) {
            out << sol[i] << ' ';
        }
        out << '\n';
        return;
    }
    for (int i = 1; i <= n; i++) {
        if (fr[i] == 0) {
            fr[i] = 1;
            sol[x] = i;
            perm(x + 1);
            fr[i] = 0;
        }
    }
}
int main()
{
    in >> n;
    perm(0);
    return 0;
}