#include <fstream>

using namespace std;
ifstream cin("permutari.in");
ofstream cout("permutari.out");
int n,x[9];
bool f[9];
void afis()
{
    for(int i=1; i<=n; i++) cout<<x[i]<<' ';
    cout<<'\n';
}
void bt(int k)
{
    if(k<=n)
    {
        for(int i=1; i<=n; i++)
        {
            if(!f[i])
            {
                x[k]=i;
                f[i]=1;
                bt(k+1);
                f[i]=0;
            }
        }
    }
    else afis();
}
int main()
{
    cin>>n;
    bt(1);
    return 0;
}

