#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n;

int a[16];
int used[17];

void print(int j)
{
    for (int i = 0; i <= j; i++)
    {
        fout << a[i] << ' ';
    }

    fout << '\n';
}

void dfs(int i)
{
    if (i == n) {print(i - 1); return;}

    for (int x = 1; x <= n; x++)
    {
        if (!used[x])
        {
            used[x] = 1;
            a[i] = x;
            //print(i);
            dfs(i + 1);
            used[x] = 0;
        }
    }
}

int main()
{
    fin >> n;

    dfs(0);
}
