#include <bits/stdc++.h>
using namespace std;

int n;
array<int, 10> st;

bool validare_distincte(int nivel) {
    for(int i = 1; i < nivel; ++i) {
        if(st[i] == st[nivel]) {
            return false;
        }
    }
    return true;
}

void back(int nivel) {
    for(int i = 1; i <= n; ++i) {
        st[nivel] = i;
        if(validare_distincte(nivel)) {
            if(nivel == n) {
                for(int j = 1; j <= n; ++j) cout << st[j] << ' ';
                cout << '\n';
            } else back(nivel + 1);
        }
    }
}

signed main() {
    cin.tie(nullptr)->sync_with_stdio(false);
#ifndef LOCAL
    freopen("permutari.in", "r", stdin);
    freopen("permutari.out", "w", stdout);
#endif

    cin >> n;
    back(1);

    return 0;
}