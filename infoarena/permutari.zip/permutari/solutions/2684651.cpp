#include <iostream>
#include <cstdio>
using namespace std;

#define MAXN 8

bool freq[MAXN+1];
int n, v[MAXN];
FILE *fout=fopen("permutari.out", "w");

void perm(int pos){
    if (pos==n+1){
        for (int i=1; i<=n; i++) fprintf(fout, "%d ", v[i]);
        fprintf(fout, "\n");
    }else{
        for (int i=1; i<=n; i++){
            if (!freq[i]){
                freq[i]=true;
                v[pos]=i;
                perm(pos+1);
                freq[i]=false;
            }
        }
    }
}

int main()
{
    FILE *fin=fopen("permutari.in", "r");
    fscanf(fin, "%d", &n);
    perm(1);
    return 0;
}
