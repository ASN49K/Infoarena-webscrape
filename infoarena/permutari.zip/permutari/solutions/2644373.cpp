#include <fstream>
#include    <iostream>
#include <vector>
#include <algorithm>
#define endl '\n'
using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int n, s[9];

void afisare()
{
    for(int i = 1; i <= n; i++)
        out<<s[i]<<' ';
    out<<endl;
}

bool valid(int i, int j)
{
    for(int k = 1; k < j; k++)
        if(i == s[k])
           return false;
    return true;

}

void bkt(int nivel)
{
    if(nivel == n + 1) afisare();
    else
    {
        for(int i = 1; i <= n; i++)
        {
           if(valid(i,nivel)){
             s[nivel] = i;
             bkt(nivel + 1);
           }
        }
    }
}

int main()
{
    in>>n;
    bkt(1);
}
