#include <iostream>
#include <vector>
#include <fstream>

ifstream cin("permutari.in");
ofstream cout("permutari.out");

using namespace std;

void bkt(int pas, int   n, vector<int>& solutie, vector<bool>& vizitat) {
    if (pas == n) {
        for (int x : solutie) {
            cout << x << " ";
        }
        cout << "\n";
        return;
    }

    for (int i = 1; i <= n; i++) {
        if (!vizitat[i]) {
            vizitat[i] = true;
            solutie.push_back(i);

            bkt(pas + 1, n, solutie, vizitat);

            vizitat[i] = false;
            solutie.pop_back();
        }
    }
}

int main() {
    int n;
    cin >> n;

    vector<int> solutie;
    vector<bool> vizitat(n+1, false);

    bkt(0, n, solutie, vizitat);
    return 0;
}