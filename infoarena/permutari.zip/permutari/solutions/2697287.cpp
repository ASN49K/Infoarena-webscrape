#include <fstream>

using namespace std;
ifstream f ("permutari.in");
ofstream g ("permutari.out");
int a[101],n;
void afis(int i)
{
  int j;
  for(j=1;j<=n;j++)
    g<<a[j]<<" ";
    g<<endl;
}
int valid(int i)
{
  int j;
  for(j=1;j<i;j++)
    if(a[i]==a[j])return 0;
  return 1;
}
void back(int i)
{
  int val;
  for(val=1;val<=n;val++)
  {
    a[i]=val;
    if(valid(i))
       if(i==n)afis(i);
        else
         back(i+1);
  }
}
int main()
{
    f>>n;
    back(1);
    return 0;
}
