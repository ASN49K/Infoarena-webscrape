var t:array[1..10] of integer;
    n,p,i,c,k:integer;
begin
assign(input,'permutari.in'); reset(input);
assign(output,'permutari.out'); rewrite(output);
readln(n);
k:=1; t[k]:=0;
while k>0 do
 begin
  repeat
   if t[k]<n then
    begin
     inc(p);
     inc(t[k])
    end
   else p:=0;
   if p>0 then
    begin
     c:=0;
     for i:=1 to k-1 do
      begin
       if t[i]=t[k] then inc(c);
       if c>0 then break
      end
    end
  until ((p>0) and (c=0)) or (p=0);
  if (p>0) and (k=n) then
   begin
    for i:=1 to n do write(t[i],' ');
    writeln
   end else
  if (p>0) and (k<n) then
   begin
    inc(k);
    t[k]:=0
   end else
  if p=0 then dec(k)
 end;
close(input);
close(output)
end.