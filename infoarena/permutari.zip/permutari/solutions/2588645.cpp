#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, fr[10], v[10];

void gen(int lg, int v[]) {
    if (lg == n + 1) {
        for (int i = 1; i <= n; i++)
            fout << v[i] << " ";
        fout << "\n";
    }
    for (int i = 1; i < n + 1; i++)
        if (fr[i - 1] == 0) {
            v[lg] = i;
            fr[i - 1] = 1;
            gen(lg + 1, v);
            fr[i - 1] = 0;
        }
}

int main(int argc, const char * argv[]) {
    fin >> n;
    gen(1, v);
}
