#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, sol[9], viz[9];

void afisare()
{
    for(int i=0; i<n; i++)
        fout << sol[i] << ' ';
    fout << '\n';
}

void gen_permutari(int k)
{
    if(k==n)
    {
        afisare();
        return;
    }

    for(int i=1; i<=n; i++)
    {
        if(viz[i] == 0)
        {
            viz[i] = 1;
            sol[k] = i;
            gen_permutari(k+1);
            viz[i] = 0;
        }
    }
}

int main()
{
    fin >> n;

    gen_permutari(n);

    return 0;
}
