#include <iostream>
#include <fstream>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");
// Opgave
//
// Alle permutatie van de verzameling {1,2,3 ... N}
// Met getalen van N groot zonder herhalingen
//

// N>9 is niet aangeraden want het zou een heel grrot bestand dat je niet meer kunt openen


int n;
int nummer[16];
int a[16];

bool validate(int c){
    bool ok = 1;
    for(int i = 1; i < c; ++i){ // onderzoek of de cijfer nog een keer in de getaal vindt
        if(nummer[i] == nummer[c]){
            ok = 0; // een cijfer befind  zich nog een keer dus dit is niet goede oplosiingen kunnen opleveren
        }
    }
    return ok;
}

void backtracking(int c){

    if(c-1==n){  // aantal cijfers in de getal bereikt
        for(int i = 1; i <= n; ++i){
            out << nummer[i] << " ";
        }
        out << "\n";
        return;
    }

    for(int i = 1; i <=n; i++)  // ga door alle mogelijke toevoegingen{
        if(!a[i]){// onderzoek of we verder kunnen gaan met deze cijfer
            nummer[c] = i; // voeg de nieuwe cijfer toe
            a[i] = 1;
            backtracking(c+1);
            a[i] = 0;

        }
    }




int main(){
    in >> n;
    backtracking(1);
    return 0;
}
