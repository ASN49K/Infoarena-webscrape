#include <iostream>
#include <fstream>
#define dim 25
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
///in cate feluri pot aranja cele n elem ale unei multimji
bool valid(int k,int x[])
{
    ///verif daca exista elem
    if(k==1)return true;
    else for(int i=1; i<=k-1; i++)
            if(x[i]==x[k])return false;
    return true;
}
bool sol(int k,int x[],int n)
{
    ///verifica daca s-a umplut stiva
    return (k==n);
}
void afis(int k,int x[])
{
    ///tip o solutie

    for(int i=1; i<=k; i++)g<<x[i]<<' ';

    g<<'\n';
}

int main()
{
    ///citim date de intrare
    int n,x[dim],k,nr=0,i;
    f>>n;
    k=1;
    x[k]=0;
    while(k>0)
    {
        ///verific daca exsita o val x[k] care indepl conditia
        bool gasit=false;
        while(x[k]<n &&gasit==false)
        {
            x[k]++;
            if(valid(k,x)) gasit=true;
        }
        if(gasit)if(sol(k,x,n)) afis(k,x);
                else
                {
                    k++;
                    x[k]=0;
                }
        else  k--;
    }
    //if(nr==0)cout<<"nu avem solutie";
}
