/// my_life_is_not_life (aka MihneaStoica) a fost aici
/// nu fi slab si nu copia sursa, ca te vanez

//#pragma GCC optimize ("Ofast,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,popcnt,lzcnt,tune=native") // cam multe pragma-uri
#include <bits/stdc++.h> // prea multe biblioteci
#define bruhus {ios_base::sync_with_stdio(false);}
#define momentum {cin.tie(NULL); cout.tie(NULL);}
#define constant(x, y) constexpr auto x = y;

// Daca nu vrei, nu vrei! (pune steluta intre slash-uri)
#define int int_fast64_t
#define uint uint_fast64_t
//*/

using namespace std;

inline void setIO (string in, string out) // Mi-e prea lene sa schimb fisierele manual
{
	if (!in.empty()) freopen (in.c_str(), "r", stdin);

	if (!out.empty()) freopen (out.c_str(), "w", stdout);
}

inline void read (int& a) // getchar este idolul meu!!!
{
	a = 0;
	char c; c = getchar();

	while (!isdigit (c)) c = getchar();

	a = a * 10 + c - 48;
	c = getchar();

	while (isdigit (c))
	{
		a = a * 10 + c - 48;
		c = getchar();
	}
}

inline void read (uint& a)
{
	a = 0;
	char c; c = getchar();

	while (!isdigit (c)) c = getchar();

	a = a * 10 + c - 48;
	c = getchar();

	while (isdigit (c))
	{
		a = a * 10 + c - 48;
		c = getchar();
	}
}

inline void read (string& a)
{
	a.clear();
	char c; c = getchar();

	while (c == '\n' || c == ' ') c = getchar();

	a += c;
	c = getchar();

	while (c != '\n' && c != ' ')
	{
		a += c;
		c = getchar();
	}
}

void solve();
void preinit();

string in = "permutari.in", out = "permutari.out";
constexpr auto multiple_testcases = 0; // Mai mult de un test? 1 - Da 0 - Nu

int32_t main()
{
	bruhus momentum // bruhus momentum
	setIO (in, out);
	int t = 1;

	if (multiple_testcases) read (t);

	preinit();

	while (t --) solve();
}

void preinit()
{
}

void solve()
{
    int n; cin >> n;
    vector<int> v(n + 1);
    for (int i = 1; i <= n; i ++)
    {
        v[i] = i;
    }
    while (!is_sorted(v.begin() + 1, v.end(), greater<int>()))
    {
        for (int i = 1; i <= n; i ++)
        {
            cout << v[i] << " ";
        }
        cout << '\n';
        next_permutation(v.begin() + 1, v.end());
    }
    for (int i = 1; i <= n; i ++)
    {
        cout << v[i] << " ";
    }
    cout << '\n';
}

/**

*/
