#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int N;
int V[10],F[10];
void afisare()
{
    for (int i=1; i<=N; i++)
        fout<<V[i]<<" ";
        fout<<"\n";

}
void bac(int k)
{
    int i;
    if (k==N+1)
        afisare();
    else
    {
        for (i=1; i<=N; i++)
            if (!F[i])
        {
            F[i]=1;
            V[k]=i;
            bac(k+1);
            F[i]=0;
        }
    }
}
int main()
{
    fin>>N;
    bac(1);
}
