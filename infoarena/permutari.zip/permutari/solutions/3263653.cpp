#include <bits/stdc++.h>

using namespace std;

ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int perm[100], visited[15];

void backtracking(int posCurenta, int n) {
    if (posCurenta > n) {
        for (int i = 1; i <= n; ++i) {
            fout << perm[i] << " ";
        }
        fout << '\n';
        return;
    }

    for (int i = 1; i <= n; ++i) {
        if (visited[i] == 1) continue;

        perm[posCurenta] = i;
        visited[i] = 1;

        backtracking(posCurenta + 1, n);

        visited[i] = 0;
        perm[posCurenta] = 0;
    }
}

int main()
{
    int n;
    fin >> n;
    backtracking(1, n);
    return 0;
}
