#include <bits/stdc++.h>
#define pb push_back
//#define int long long
#define cin fin
#define cout fout
using namespace std;
ifstream cin("permutari.in");ofstream cout("permutari.out");
const int N=8+5;
int n;
bool vis[N];
vector<int> path;
void bkt(int step)
{
    if(step==n+1)
    {
        for(auto x:path) cout<<x<<" ";
        cout<<'\n';
        return;
    }
    for(int i=1;i<=n;++i)
    {
        if(vis[i]) continue;
        path.pb(i);
        vis[i]=1;
        bkt(step+1);
        vis[i]=0;
        path.pop_back();
    }
}
signed main()
{
    cin>>n;
    bkt(1);
}
