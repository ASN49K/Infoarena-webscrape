#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int s[9],nsir,n,i,j;
bool verific(int k)
{
    for(int i=1;i<k;i++)
        if(s[k]==s[i])
          return 0;
    return 1;
}
void afisez()
{
    for(int i=1;i<=n;i++)
        fout<<s[i]<<" ";
    fout<<'\n';
}
void permutari(int k)
{
    if(k<=n)
    for(int i=1;i<=n;i++)
    {
        s[k]=i;
        if(verific(k)==true)
            permutari(k+1);
    }
    else
        afisez();
}
int main()
{
    fin>>n;
    permutari(1);

    return 0;
}
