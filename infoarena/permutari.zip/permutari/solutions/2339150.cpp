#include <iostream>
#include <fstream>
using namespace std;
int st[8],n;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int valid(int k){
    for(int i=k-1;i>=1;i--)
    if(st[k]==st[i])
        return 0;
    return 1;
}
void tipar()
{
    for(int i=1;i<=n;i++)
        fout<<st[i]<<" ";
    
    fout<<endl;
}
int solutie(int k)
{return (k==n);}
void back(int k)
{
    for(int i=1;i<=n;i++)
    {
        st[k]=i;
        if(valid(k))
        {
            if(solutie(k))
                tipar();
            else
                back(k+1);
        }}}
int main() {
    fin>>n;
    back(1);
    return 0;
}
