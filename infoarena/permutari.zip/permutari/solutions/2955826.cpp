#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

const uint32_t MAX_N = 8;

uint32_t n, v[MAX_N];
bool fol[MAX_N + 1];

FILE* fout;

void Backtrack(uint32_t pos) {
    if(pos == n) {
        for(uint32_t i = 0; i < n; ++i)
            fprintf(fout, "%u ", v[i]);
        fprintf(fout, "\n");
    } else {
        for(uint32_t i = 1; i <= n; ++i) {
            if(fol[i])
                continue;
            
            v[pos] = i;
            fol[i] = true;

            Backtrack(pos + 1);

            fol[i] = false;
        }
    }
}

int main() {
    FILE* fin = fopen("permutari.in", "r");
    fout = fopen("permutari.out", "w");

    fscanf(fin, "%u", &n);

    Backtrack(0);

    fclose(fin);
    fclose(fout);

    return 0;
}