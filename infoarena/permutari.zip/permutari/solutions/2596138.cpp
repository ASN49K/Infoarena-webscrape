#include<iostream>
#include<fstream>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int n,v[9],ap[9];
void afisare()
{
    for(int i = 1; i <= n; ++i)
        g << v[i] <<  " ";
    g << '\n';
    return;
}
void bkt(int poz)
{
    if(poz == n + 1) // conditia de oprire
    {
        afisare();
        return;
}
for(int i = 1; i <= n; ++i)
    if(ap[i] == 0)
{
    ap[i] = 1;
    v[poz] = i;
    bkt(poz + 1);
    ap[i] = 0;
    v[poz] = 0;
}
}
int main()
{
    f >> n;
    bkt(1);
}
