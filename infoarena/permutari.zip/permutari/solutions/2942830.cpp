#include <iostream>
using namespace std;

const int MAX_LENGTH = 8;

int frequency[MAX_LENGTH + 1];

void generate(int permutationsLength, int numbersLength, int numbers[MAX_LENGTH + 1]) {
    if (numbersLength == permutationsLength + 1) {
        for (int index = 1; index < numbersLength; ++index) {
            cout << numbers[index] << ' ';
        }
        cout << '\n';
    }
    for (int number = 1; number <= permutationsLength; ++number) {
        if (frequency[number] == 0) {
            frequency[number] = 1;
            numbers[numbersLength] = number;
            generate(permutationsLength, numbersLength + 1, numbers);
            frequency[number] = 0;
        }
    }
}

int main() {
    int permutationsLength;
    cin >> permutationsLength;
    int numbers[MAX_LENGTH + 1];
    generate(permutationsLength, 1, numbers);
    return 0;
}
