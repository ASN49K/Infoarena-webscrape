#include <bits/stdc++.h>

using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int a[20], viz[20], n, top;
void afis()
{
    int i;
    for(i = 1; i <=n; i++)
        g << a[i] << " ";
    g << "\n";
}
void Back1(int top)// RECURSIV
{
    int i;
    if(top == n+1) afis();
    else for(i = n; i >= 1;i--)
        if(viz[i] == 0)
            {
                if(viz[i] = 1);
                a[top] =i;
                Back1(top + 1);
                viz[i] = 0;
            }
}
int main()
{
    f >> n;
    /*Back();*/
    Back1(1);

    return 0;
}
