#include<fstream>
using namespace std;

ifstream fi("permutari.in");
ofstream fo("permutari.out");

int N, k, S[100];

void BackTraking(int k)
{
	if(k==N)
	{
		for(int i=1; i<=N; i++) fo << S[i] << " ";
		fo << '\n';
	}
	else
	{
		for(int i=1; i<=N; i++)
		{
			bool b=1;
			for(int j=1; j<=k; j++) 
				if(S[j]==i) b=0, j=k;
			if(b) S[k+1]=i, BackTraking(k+1);
		}
	}
}


int main()
{
	fi >> N;
	BackTraking(0);
}

