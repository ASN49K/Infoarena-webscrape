#include <bits/stdc++.h>
#define NMAX 8

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, st[NMAX + 2];
bool fr[NMAX + 2];

void afisare(int n) {
    for (int i = 1; i <= n; i++) {
        fout << st[i] << ' ';
    }
    fout << '\n';
}

void Back(int vf) {
    for (int i = 1; i <= n; i++) {
        if (!fr[i]) {
            fr[i] = 1;
            st[vf] = i;
            if (vf == n) {
                afisare(n);
            }
            else {
                Back(vf + 1);
            }
            fr[i] = 0;
        }
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    fin.tie(NULL);
    fout.tie(NULL);

    fin >> n;
    Back(1);
    return 0;
}
