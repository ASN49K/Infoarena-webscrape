#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int x[10],n,viz[10];

void Afisare()
{ int i;
  for(i=1;i<=n;i++)
     fout<<x[i]<<" ";
  fout<<"\n";
}

void Back(int k)
{ int i;
  for(i=1;i<=n;i++)
     { if(viz[i]==0)
         { x[k]=i;
           viz[i]=1;
           if(n==k) Afisare();
           else Back(k+1);
           viz[i]=0;
         }
     }
}


int main()
{   fin>>n;
    Back(1);
    return 0;
}
