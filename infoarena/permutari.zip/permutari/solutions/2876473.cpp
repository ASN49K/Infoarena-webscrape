#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f ("permutari.in");
ofstream g ("permutari.out");
long long n,a[1001],x[1001],j,b,i;
void afisare()
{for(j=1;j<=n;j++)
g<<a[j]<<" ";
g<<'\n';
}


void bkp(int k)
{for(int i=1;i<=n;i++)
    {if(x[i]==0)
        {x[i]=1;
            a[k]=i;
            if(k<=n)
            {if(k==n)
            afisare();
            else
                bkp(k+1);
            }
        x[i]=0;
        }
    }
}

int main()
{

f>>n;
bkp(1);
}
