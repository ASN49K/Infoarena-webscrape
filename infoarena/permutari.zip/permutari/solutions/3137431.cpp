#include<bits/stdc++.h>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int x[101];
int n, i;
bool Correct(int pas){
    for(int i=1;i<pas;i++)
        if(x[i] == x[pas])
            return false;
    return true;
}
void Write(int n){
    for(int i=1;i<=n;i++)
            fout << x[i] << " ";
    fout << "\n";
}
void Backtrack(int pas){
    for(int i=1;i<=n;i++){
        x[pas] = i;
        if(Correct(pas)){
            if(pas == n)
                Write(n);
            else Backtrack(pas + 1);
        }
    }
}
int main(){
    fin >> n;
    Backtrack(1);
}
