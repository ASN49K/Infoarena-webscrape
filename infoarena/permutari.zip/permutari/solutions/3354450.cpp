#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;

int sol[10];
int used[10];
int n;
ifstream fin("permutari.in");
ofstream fout("permutari.out");

void back(int pos) {
    if (pos == n + 1) {
        for (int i=1; i<=n; i++)
            fout << sol[i] << ' ';
        fout << '\n';
        return;
    }
    for (int i=1; i<=n; i++) {
        if (!used[i]) {
            used[i] = 1;
            sol[pos] = i;
            back(pos + 1);
            sol[pos] = 0;
            used[i] = 0;
        }
    }
}

int main(void) {
    fin >> n;
    back(1);
    fin.close();
    fout.close();
    return 0;
}