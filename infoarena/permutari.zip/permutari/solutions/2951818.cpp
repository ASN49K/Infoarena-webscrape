#include <bits/stdc++.h>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n,fol[20],sol[20];
void afisare()
{
    for(int i=1;i<=n;i++)
        fout<<sol[i]<<" ";
    fout<<'\n';
}
void bkt(int poz)
{
    if(poz==n+1)
    {
        afisare();
        return;
    }
    for(int i=1;i<=n;i++)
        if(fol[i]==0)
        {
            fol[i]=1;
            sol[poz]=i;
            bkt(poz+1);
            fol[i]=0;
            sol[poz]=0;
        }
        
}
int main()
{

    fin>>n;
    bkt(1);
}