#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int st[20], n, fr[20];

void Afisare(){
    for(int i = 1; i <= n; i++)
        fout << st[i] << " ";
    fout << "\n";
}

void Back(int top){
    int i;
    if(top == n + 1)
        Afisare();
    else {
        for(i = 1; i <= n; i++)
            /// nu avem numarul i in stiva
            if(fr[i] == 0)
            {
                /// il bagam in stiva
                fr[i] = 1;
                st[top] = i;
                /// generam solutiile in care i este pus in stiva
                Back(top + 1);
                /// il scoatem din stiva
                fr[i] = 0;
            }
    }
}

int main()
{
    fin >> n;
    Back(1);
    return 0;
}
