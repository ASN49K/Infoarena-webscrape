#include <bits/stdc++.h>

#define ll long long
#define pb push_back
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n;
int v[20];
int f[20];

void bkt(int k) {
    if (k == n) {
        for (int i = 1; i <= n; i++)
            fout << v[i] << " ";
        fout << '\n';
    } else {
        for (int i = 1; i <= n; i++) {
            if (f[i] == 0) {
                f[i] = 1;
                v[k + 1] = i;
                bkt(k + 1);
                v[k + 1] = 0;
                f[i] = 0;
            }
        }
    }
}

int main() {
    fin >> n;
    bkt(0);
    return 0;
}