﻿//https://infoarena.ro/problema/permutari

//#pragma GCC optimize("O3")   
//#pragma GCC optimize("Ofast") 
//#pragma GCC optimize("fast-math") 
//#pragma GCC optimize("unroll-loops") 
//#pragma GCC optimize("inline")  
//#define _USE_MATH_DEFINES
//#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <fstream>
//#include <vector>
//#include <cstring>
//#include <cmath>
//#include <bitset>
//#include <queue>
//#include <stack>
//#include <utility>
#include <algorithm>
//#include <string>
//#include <map>
//#include <unordered_map>
//#include <set>
//#include <unordered_set>
//#include <cstdint>
//#include <climits>
//#include <iomanip>
//#include <cstdio>
//#include <tuple>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

const int NRMAX = 8;

int v[NRMAX + 1], n;
int b[NRMAX + 1];

void backtraking(int x)
{
	if (x == n + 1)
	{
		for (int i = 1; i <= n; ++i)
			fout << v[i] << " ";
		fout << "\n";
	}
	else
	{
		for (int i = 1; i <= n; ++i)
		{
			if (b[i] == false)
			{
				v[x] = i;
				b[i] = true;
				backtraking(x + 1);
				b[i] = false;
			}
		}
		
	}
}

int main()
{
	//ios_base::sync_with_stdio(false);
	//cin.tie(nullptr);
	//cout.tie(nullptr);

	fin >> n;

	backtraking(1);

	return 0;
}