#include<bits/stdc++.h>
using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");
int n, v [200], f [200];
void bkt (int poz){
    if (poz == n + 1){
        for (int i = 1; i <= n; i ++)
            fout << v [i] << " ";
        fout << '\n';
    }
    for (int i = 1; i <= n; i ++){
        if (!f [i]){
            f [i] = 1; v [poz] = i;
            bkt (poz + 1);
            f [i] = 0;
        }
    }
}
int main (){
	fin >> n;
	bkt (1);
}
