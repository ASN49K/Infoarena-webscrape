#include <bits/stdc++.h>
#include <fstream>
#define cin fin
#define cout fout
using namespace std;
ifstream cin ("permutari.in");
ofstream cout ("permutari.out");
vector<int>v;
int i,n;
int main()
{
    cin>>n;
    for(i=1;i<=n;i++)
    {
        v.push_back(i);
        cout<<i<<" ";
    }
    while(next_permutation(v.begin(),v.end()))
    {
        cout<<'\n';
        for(i=0;i<n;i++)
            cout<<v[i]<<" ";
    }
    return 0;
}
