#include <iostream>
#include <fstream>

using namespace std;

const string filename = "permutari";
ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

int n, sol[10];
bool used[10];

void afis()
{
    for(int i = 1; i <= n; i++)
        fout << sol[i] << ' ';
    fout << '\n';
}

void bkt(int k)
{
    for(int i = 1; i <= n; i++)
    {
        if(used[i])
            continue;
        sol[k] = i;
        used[i] = 1;
        if(k == n)
            afis();
        else
            bkt(k + 1);
        used[i] = 0;
    }
}

int main()
{
    fin >> n;
    bkt(1);
    return 0;
}
