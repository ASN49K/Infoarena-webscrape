#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("ciur.in");
ofstream fout("ciur.out");

int n, permutari[10];
bool uz[10];

void back(int p, int n)
{
    if(p-1 == n)
    {
        for(int i = 1; i <= n; i++)
            fout << permutari[i] << " ";
        fout << "\n";
        return;
    }
    else
    {
        for(int i = 1; i <= n; i++)
        {
            if(!uz[i])
            {
                permutari[p] = i;
                uz[i] = 1;
                back(p + 1, n);
                uz[i] = 0;
            }
        }
    }
}

int main()
{
    fin >> n;
    back(1, n);
    return 0;
}
