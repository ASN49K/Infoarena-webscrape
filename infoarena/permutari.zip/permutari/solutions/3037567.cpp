#include <iostream>
#include <fstream>
#include <vector>
#include <string>
using namespace std;

#define file "permutari"
ifstream f(file + string(".in"));
ofstream g(file + string(".out"));

int x[9], n;

void afis(int k) {
    for (int i = 1; i <= k; i++) g << x[i] << " ";
    g << endl;
}

bool valid(int k) {
    for (int i = 1; i < k; i++)
        if (x[i] == x[k]) return 0;
    return 1;
}

void back(int k) {
    for (int i = 1; i <= n; i++) {
        x[k] = i;
        if (valid(k))
            if (k == n) afis(k);
            else back(k+1);
    }
}

int main() {

    f >> n;
    back(1);

    return 0;
}