#include<bits/stdc++.h>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");

const int NMAX = 12;
int v[NMAX], n;

void afisare()
{
    int i;
    for(i = 1; i <= n; i++)
        fout<< v[i]<<" ";
    fout<<'\n';
}

int good(int m)
{
    int i;
    for(i = 1; i < m; i++)
    {
        if(v[i] == v[m])
            return 0;
    }
    return 1;
}

void bkt(int poz)
{
    int i;
    for(i = 1; i <= n; i++)
    {
        v[poz] = i;
        if(good(poz))
        {
            if(poz == n)
                afisare();
            else
                bkt(poz+1);
        }
    }
}
int main()
{
    fin>> n;
    bkt(1);

    fin.close();
    fout.close();

    return 0;
}
