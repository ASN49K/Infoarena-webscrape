#include<bits/stdc++.h>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n, s[9], v[9];

void afis(){
    for(int i=1; i<=n; i++)
        fout<<s[i]<<" ";
    fout<<"\n";
}

void bkt(int k){
    for(int i=1; i<=n; i++){
        if(!v[i]){
            v[i] = 1;
            s[k] = i;
            if(k<n) bkt(k+1);
            else afis();
            s[k] = 0;
            v[i] = 0;
        }
    }
}

int main(){
    fin>>n;
    bkt(1);
}
