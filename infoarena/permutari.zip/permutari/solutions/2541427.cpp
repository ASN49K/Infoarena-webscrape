#include <bits/stdc++.h>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");
vector<int>a;
int n;
int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
        a.push_back(i);
    do
    {
        for(i = 0; i< n; i++)
            fout << a[i] << " ";
        fout << "\n";
    }while(next_permutation(a.begin(),a.end()));
    fin.close();
    fout.close();
    return 0;
}
