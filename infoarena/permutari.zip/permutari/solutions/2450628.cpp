#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define all(a) (a).begin(), (a).end()
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define forn(i,a,b) for (int i = a; i <= b; i++)
#define fi(i,a,b) for (int i = a; i < b; i++)
#define ff first
#define ss second
#define pb push_back
#define mp make_pair
#define rc(s) return cout<<s,0
#define rcc(s) cout<<s,exit(0)
#define er erase
#define in insert
#define pi pair <int, int>
#define pii pair <pi, pi>
# define sz(x) (int)((x).size())
int ans[10],f[10],n;
void perm(int x){
	if(x==0){
		forn(i,1,n)cout<<ans[i]<<' ';
	//	cout<<'\n';
	}else{
		forn(i,1,n)
			if(f[i]){
				f[i]=0;
				ans[n-x+1]=i;
				perm(x-1);
				f[i]=1;
			}
		
	}
}


int32_t main(){
ios_base::sync_with_stdio(0); cin.tie(0); cerr.tie(0); cout.tie(0);
	ifstream cin("permutari.in");
	ofstream cout("permutari.out");
	cin>>n;
	forn(i,1,n)f[i]=1;
	perm(n);
return 0;
}

