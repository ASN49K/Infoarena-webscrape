#include <bits/stdc++.h>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int n,p[10],viz[10];
void bkt(int poz)
{
    if(poz==n+1)
    {
        for(int i=1; i<=n; i++)
            g<<p[i]<<' ';
        g<<'\n';
    }

    for(int k=1; k<=n; k++)
        if(!viz[k])
        {
            p[poz]=k;
            viz[k]=1;
            bkt(poz+1);
            viz[k]=0;
        }
}
int main()
{
    f>>n;
    for(int i=1;i<=n;i++)
        p[i]=i;
    do
    {
        for(int i=1;i<=n;i++)
            g<<p[i]<<' ';
        g<<'\n';
    }
    while(next_permutation(p+1,p+n+1));
    return 0;
}


//back - > se controleaza pozitia la care s-a ajuns in permutare
//daca s-a ajuns la poz n+1 => conditie de oprire-> afisare
//altfel
//-> se considera toate valorile nefolosite pana la poz
//    -> se aseaza succesiv pe acea pozitie si
//    se apleaza back la pozitia urmatoare
//    -> valorile nefolosite se folosesc in ordine crescatoare
//    => permutarile vor fi generate lexicografic
//    optimizari :
//        -> tinem un vector de marcaj(sau de vizitare) pentru a
//        memora ce valori au fost deja utilizate
//
