#include <fstream>
#include <algorithm>
using namespace std;
ifstream cin("permutari.in");
ofstream cout("permutari.out");

int n,nf=1;
int v[10];
int main()
{
    cin>>n;
    for(int i=1;i<=n;++i){
        v[i]=i;
        nf*=i;
    }
    
    while(nf){
        for(int i=1;i<=n;++i) cout<<v[i]<<" ";
        next_permutation(v+1,v+1+n);
        cout<<'\n';
        --nf;
    }
    
    return 0;
}