#include <fstream>
#define Nmax 10
using namespace std;

ifstream cin("permutari.in");
ofstream cout("permutari.out");

int rez[10], vis[10];
int n;

void afisare()
{
    for(int i = 1; i<=n; i++)
        cout << rez[i] << ' ';

    cout << '\n';
}

void Back(int k)
{
    if(k == n+1)
        afisare();

    else
    {
        for(int i = 1; i<=n; i++)
            if(vis[i] == 0)
            {
                rez[k] = i;
                vis[i] = 1;

                Back(k+1);
                vis[i] = 0;
            }
    }
}

int main()
{
    cin >> n;
    Back(1);
}
