#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int n;
vector<int> v;

void back()
{
    if (v.size()==n)
    {
        for (int i = 0; i < v.size(); i++)
            fout << v[i] << " ";
        fout << "\n";
        return;
    }
    for (int i = 1; i <= n; i++)
    {
        int ok = 1;
        for (int j = 0; j < v.size(); j++)
        {
            if (i ==  v[j])
            {
                ok = 0;
                break;
            }
        }
        if (ok == 0) continue;

        v.push_back(i);
        back();
        v.pop_back();
    }
}

int main()
{
    fin >> n;
    back();
    return 0;
}
