#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int n;
vector<int> sol;
vector<bool> viz;
ofstream fout("permutari.out");

void bkt(int step) {
    if (step == n) {
        for (int i = 0; i < n; ++i) {
            fout << sol[i] << (i == n - 1 ? "" : " ");
        }
        fout << "\n";
        return;
    }

    for (int i = 1; i <= n; ++i) {
        if (!viz[i]) {
            viz[i] = true;
            sol[step] = i;
            bkt(step + 1);
            viz[i] = false;
        }
    }
}

int main() {
    ifstream fin("permutari.in");
    
    fin >> n;

    sol.resize(n);
    viz.assign(n + 1, false);

    bkt(0);

    fin.close();
    fout.close();

    return 0;
}