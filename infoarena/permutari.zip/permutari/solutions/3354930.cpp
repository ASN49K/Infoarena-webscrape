#include <iostream>
#include <vector>
#include <set>
#include <fstream>
using namespace std;

set<int> used;
ofstream out("permutari.out");

void bkt(int n, vector<int>& path) {
    if (path.size() == n) {
        for (int x : path) {
            out << x << " ";
        }
        out << "\n";
        return;
    }

    for (int i = 1; i <= n; i++) {
        if (!used.count(i)) {
            path.push_back(i);
            used.insert(i);

            bkt(n, path);

            path.pop_back();
            used.erase(i);
        }
    }
}

int main() {
    ifstream f("permutari.in");

    int n;
    f >> n;

    vector<int> path;
    bkt(n, path);

    return 0;
}