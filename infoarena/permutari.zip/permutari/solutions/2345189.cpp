#include <fstream>
using namespace std;

ifstream cin("permutari.in");
ofstream cout("permutari.out");
int n, a[11];
bool viz[11];

void back(int k) {
	if(k == n) {
		for(int i=0; i<n; i++)
			cout << a[i] + 1 << ' ';
		cout << '\n';
	}
	for(int i=0; i<n; i++)
		if(!viz[i])
			a[k] = i, viz[i] = 1, back(k + 1), viz[i] = 0;
}

int main() {
	ios_base::sync_with_stdio(0);
	cin >> n;
	back(0);
	return 0;
}
