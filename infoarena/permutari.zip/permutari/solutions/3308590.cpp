#include <fstream>

using namespace std;

ifstream cin("permutari.in");
ofstream cout("permutari.out");

int v[10];

void afisare(int n) {
    for (int i = 0 ; i < n ; ++i) {
        cout << v[i] << " ";
    }
    cout << "\n";
}

bool ok(int k) {
    for (int i = 0 ; i < k ; ++i) {
        if (v[i] == v[k]) return false;
    }
    return true;
}

void back(int n, int k) {
    for (int i = 0 ; i < n ; ++i) {
        v[k] = i;
        if (ok(k)) {
            if (k == n) afisare(n);
            else back(n, k + 1);
        }
    }
}

int main() {
    int n; cin >> n;
    back(n, 0);
    return 0;
}