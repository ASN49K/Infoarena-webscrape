#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int used[10], rez[10], n;

void bkt(int pas)
{
    if(pas == n + 1)
    {
        for(int i = 1; i <= n; ++i)
            fout << rez[i] << ' ';
        fout << '\n';
        return;
    }

    for(int i = 1; i <= n; ++i)
        if(!used[i])
        {
            rez[pas] = i;
            used[i] = 1;

            bkt(pas + 1);

            used[i] = 0;
            rez[pas] = 0;
        }
}

int main()
{
    fin >> n;

    bkt(1);
    return 0;
}
