#include <bits/stdc++.h>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int st[10],n;
bool vz[10];

void afis()
{
    for(int i=1;i<=n;i++)g<<st[i]<<' ';
    g<<'\n';
}

bool solutie(int p)
{
    return p==n;
}

void bk(int p)
{
    for(int i=1;i<=n;i++)
        if(vz[i]==0)
    {
        vz[i]=1;
        st[p]=i;
        if(solutie(p))afis();
        else bk(p+1);
        vz[i]=0;
    }
}

int main()
{
    f>>n;
    bk(1);
    return 0;
}
