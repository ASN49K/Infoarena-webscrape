#include <bits/stdc++.h>

using namespace std;

//ifstream fin ("input"); ofstream fout ("output");
ifstream fin ("permutari.in"); ofstream fout ("permutari.out");

int perm[10];
bool used[10];

void back(int pos, int n) {

    if (pos == n + 1) {
        for (int i = 1; i <= n; ++i)
            fout << perm[i] << ' ';
        fout << '\n';
        return;
    }
    for (int i = 1; i <= n; ++i) {
        if (!used[i]) {
            perm[pos] = i;
            used[i] = true;
            back(pos + 1, n);
            used[i] = false;
        }
    }
}

int main() {

    int n;
    fin >> n;
    back(1, n);
    return 0;
}