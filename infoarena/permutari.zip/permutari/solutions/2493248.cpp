#include <bits/stdc++.h>
using namespace std;
int n,i,a[200005];
int main(){
    ifstream fin;
    fin.open("permutari.in");
    ofstream fout;
    fout.open("permutari.out");
    fin>>n;
    for(i=1;i<=n;i++) a[i]=i;
    sort(a+1,a+n+1);
    do{
        for(i=1;i<=n;i++) fout<<a[i]<<" ";
        fout<<"\n";
    }while(next_permutation(a,a+n));
    return 0;
}
