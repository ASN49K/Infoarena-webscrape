#include <fstream>
#include<iostream>
using namespace std;
 
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int v[10],n;
void Init(int k)
{
    v[k] = 0; 
}
int Print()
{
    for(int i=1;i<=n;i++)
    fout<<v[i]<<" ";
    fout<<'\n';
}
int Succesor (int k)
{
    if(v[k]<n)
    {
        v[k]++;
        return 1;
    }
    else return 0; 
}
int Valid(int k)
{
    for(int i =1;i < k; i++)
    if(v[k] == v[i]) return 0;
    return 1; 
}
int Backtrack (int n)
{
    int k=1,isS,isV;
    Init(k);
    while(k>0)
    {
    isS=0;isV=0;
    if (k<=n) 
    do{ 
    isS=Succesor(k);
    if (isS) isV=Valid(k);
    } while (isS == 1 && isV == 0);
    if(isS != 0){
    if(k==n)
    Print();
    else { k++; Init(k);} 
    }
    else k--;   
    }   

}
int main()
{
  int i;
  fin>>n;
  Backtrack(n);
}