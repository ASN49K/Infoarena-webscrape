#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, x[9];
bool p[9];

void afis()
{
    for(int i=1; i<=n; i++)
        fout<<x[i]<<' ';
    fout<<'\n';
}

void btk(int k)
{
    for(int i=1; i<=n; i++)
        if(!p[i])
    {
        x[k]=i;
        p[i]=1;

        if(k==n)
            afis();
        else btk(k+1);

        p[i]=0;
    }
}

int main()
{
    fin>>n;
    fin.close();

    btk(1);
    fout.close();

    return 0;
}
