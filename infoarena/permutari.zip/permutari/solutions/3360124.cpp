#include <bits/stdc++.h>
using namespace std;
int n,perm[10],folosit[10];
void gen(int k){
    int i;
    if(k==n){
        for(i=0;i<n;i++){
            cout << perm[i];
            if(i<n-1)
                cout << " ";
        }
        cout << "\n";
        return;
    }
    for(i=1;i<=n;i++){
        if(folosit[i]==0){
            perm[k]=i;
            folosit[i]=1;
            gen(k+1);
            folosit[i]=0;
        }
    }
}
int main(){
    freopen("permutari.in","r",stdin);
    freopen("permutari.out","w",stdout);
    cin >> n;
    gen(0);
    return 0;
}
