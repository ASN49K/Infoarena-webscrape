#include<iostream>
#include<fstream>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int n, v[25];
void backTracking(int p)
{
    if(p > n)
    {
        for(int i = 1; i <= n; i++)
            g << v[i] << " ";
        g << '/n';
    }
    else{
        for(int i = 1; i <= n; i++)
        {
            v[p] = i;
            int ok = 1;
            for(int j = 1; j < p &&ok == 1; j++)
                if(v[j] == v[p])
                    ok= 0;
            if(ok == 1)
                backTracking(p + 1);
        }
    }
}
int main()
{
    f >> n;
    backTracking(1);

}
