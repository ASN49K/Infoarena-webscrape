#include <bits/stdc++.h>

using namespace std;

int T[100], P[100];
ifstream fin("permutari.in"); ofstream fout("permutari.out");
int main(){
    int n;
    fin >> n;
    vector<int> vec(n);
    for(int i = 0; i<n; i++){
        vec[i] = i+1;
    }
    do{
        for(auto d : vec){
            fout << d << " ";
        }
        fout << endl;
    } while(next_permutation(vec.begin(), vec.end()));
}
