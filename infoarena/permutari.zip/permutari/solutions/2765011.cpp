#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int x[10], n;

void Afis()                  ///afisam solutia
{
    for(int i=1; i<=n; i++)
        fout<<x[i]<<" ";
    fout<<'\n';
}

bool Solutie(int k)         ///verificam daca permutarea actuala este o solutie finala
{
    if(k==n)
        return 1;
    return 0;
}

bool OK(int k)              ///verificam conditiile interne <=> toate elementele sunt distincte
{
    for(int i=1; i<k; i++)
        if(x[i]==x[k])
            return 0;
    return 1;
}

void bkt(int k)
{
    for(int i=1; i<=n; i++)
    {
        x[k]=i;
        if(OK(k)==1)
            if(Solutie(k)==1)
                Afis();
            else
                bkt(k+1);
    }
}

int main()
{
    fin>>n;
    bkt(1);
    return 0;
}
