#include <bits/stdc++.h>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int a[105] , n ;

void afis()
{
    for ( int i = 1 ; i <= n ; i++)
        g << a[i] << " ";
    g << '\n';
}
bool ok(int poz)
{
    for ( int i = 1 ; i < poz ; i++)
        if(a[i] == a[poz])
            return false;
    return true;
}

void bkt(int k)
{
    for ( int i = 1 ; i <= n ; i++)
    {
        a[k] = i;
        if( ok(k) )
            if(k == n)
                afis();
            else
                bkt(k + 1);
    }
}
int main()
{
    f >> n ;

    bkt(1);
    return 0;
}
