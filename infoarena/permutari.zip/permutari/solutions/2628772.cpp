#include <fstream>
#include <vector>
using namespace std;
ifstream cin( "permutari.in" );
ofstream cout( "permutari.out" );
int n, v[ 9 ];
vector< int > ras;

void perm( int pas ){
    if( pas == n + 1 ){
        for( int i = 1; i < ras.size(); i++ )
            cout << ras[ i ] << ' ';
        cout << '\n';
        return;
    }
    for( int i = 1; i <= n; i++ ){
        if( v[ i ] == 0 ){
            ras.push_back( i );
            v[ i ] = 1;
            perm( pas + 1 );
            ras.pop_back();
            v[ i ] = 0;
        }
    }
}
int main()
{
    cin >> n;
    ras.push_back( 0 );
    perm( 1 );
    return 0;
}
