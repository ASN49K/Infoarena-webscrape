#include <bits/stdc++.h>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n, st[15], fr[15];


void Afis(int n)
{
    for(int i = 1; i <= n; i++)
        fout << st[i] << " ";
    fout << "\n";
}

void Back(int top)
{
    if(top == n + 1) Afis(n);
    else for(int i = 1; i <= n; i++)
        if(fr[i] == 0)
    {
        st[top] = i;
        fr[i] = 1;
        Back(top + 1);
        fr[i] = 0;
    }
}
int main()
{
    fin >> n;
    Back(1);
    return 0;
}
