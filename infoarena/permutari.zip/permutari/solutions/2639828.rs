use std::fs::File;
use std::io::{Read, Write, BufWriter};

fn bkt<W: Write>(i: usize, n: usize, perm : &mut Vec<usize>, fout: &mut BufWriter<W>) {
  if i == n {
    for elem in perm {
      fout.write(format!("{} ", elem).as_bytes()).unwrap();
    }
    fout.write("\n".as_bytes()).unwrap();
  } else {
    for j in i..n {
      perm.swap(i, j);
      bkt(i + 1, n, perm, fout);
    }
    for j in (i..n).rev() {
      perm.swap(i, j);
    }
  }
}

fn main() {
  let mut fin = File::open("permutari.in").unwrap();
  let mut fout = BufWriter::new(File::create("permutari.out").unwrap());

  let mut line = String::new();
  fin.read_to_string(&mut line).unwrap();

  let n : usize = line.trim().parse().unwrap();
  
  bkt(0, n, &mut (1..n+1).collect(), &mut fout);
  fout.flush().unwrap();
}

