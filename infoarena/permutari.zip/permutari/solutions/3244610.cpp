#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;

int n, v[9];

int fact(int nrf) {
    int factorial = 1;
    for (int i = 1; i <= nrf; i++) {
        factorial *= i;
    }
    return factorial;
}

int main() {
    ifstream fin("permutari.in");
    ofstream fout("permutari.out");
    fin >> n;
    for(int i = 1; i <= n; i++) {
        v[i] = i;
    }
    int nr = fact(n);
    for(int i = 1; i <= nr; i++) {
        for(int i = 1; i <= n; i++) {
            fout << v[i] << ' ';
        }
        next_permutation(v + 1, v + n + 1);
        fout << '\n';
    }
}
