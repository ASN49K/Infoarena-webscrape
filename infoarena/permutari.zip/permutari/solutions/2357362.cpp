#include <fstream>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");
int n, s[9];
short int viz;
auto flip = [](int pos) {viz ^= (1 << pos); };
auto check = [](int pos) {return (bool)(((1 << pos) & viz) >> pos); };
void perm(int i)
{
	if (i == n)
	{
		for (int j = 0; j < n; g << s[j++] << " ");
		g << "\n";
		return;
	}
	for (int v = 1; v <= n; v++)
	{
		if (!check(v))
		{
			s[i] = v;
			flip(v);
			perm(i + 1);
			flip(v);
		}
	}
}
int main()
{
	f >> n;
	perm(0);
	return 0;
}