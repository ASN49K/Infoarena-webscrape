#include <bits/stdc++.h>

using namespace std;

int N;
int v[10];

int main(){

    freopen("permutari.in", "r", stdin);
    freopen("permutari.out", "w", stdout);

    scanf("%d", &N);
    for(int i = 1; i <= N; i++){
        v[i] = i;
        printf("%d ", v[i]);
    }
    printf("\n");

    while(next_permutation(v + 1,v + N + 1)){
        for(int i = 1; i <= N; i++)
            printf("%d ", v[i]);
        printf("\n");
    }

    return 0;
}
