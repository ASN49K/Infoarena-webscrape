#include <vector>
#include <algorithm>
#include <iostream>
#include <climits>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int main()
{
    ios::sync_with_stdio(0); cin.tie(0);

   // freopen("permutari.in","r",stdin);
   // freopen("permutari.out","w",stdout);

    int n;
    fin>>n;
    
    vector<int> v;
    v.resize(n+1);
    for(int i=1;i<=n;++i)
        v[i]=i;
    
    do
    {
        for(int i=1;i<n;++i)
        {
            fout<<v[i]<<' ';
        }
        fout<<v[n]<<'\n';
    } while (
        next_permutation(v.begin(),v.end())
    );
    


    return 0;
}