#include <bits/stdc++.h>
using namespace std;
#define NMAX 100005
int n, arr[NMAX];

ifstream f("permutari.in");
ofstream g("permutari.out");

int main()
{
    f >> n;
    for(int i=0;i<n;++i)
        arr[i] = i+1;
    do
    {
        for(int i=0;i<n;++i)
            cout<<arr[i]<<' ';
        g <<'\n';
    }while(next_permutation(arr, arr+n));
}