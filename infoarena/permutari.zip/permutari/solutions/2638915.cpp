#include <fstream>
#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>
#include <queue>
#include <cmath>
#include <string>
#include <set>
using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int sol[10], n;


bool OK(int pos)
{
	for (int i = 1; i < pos; i++)
		if (sol[i] == sol[pos])
			return false;
	return true;
}

void print()
{
	for (int i = 1; i <= n; i++)
		out << sol[i] << ' ';
	out << '\n';
}

void bkt(int pos)
{
	if (pos == n + 1)
	{
		print();
	}
	else
	{
		for (int i = 1; i <= n; i++)
		{
			sol[pos] = i;
			if (OK(pos))
				bkt(pos + 1);
		}
	}
}

int main()
{
	in >> n;
	bkt(1);
}