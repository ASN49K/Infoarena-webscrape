#include <bits/stdc++.h>
using namespace std;

int main() {
	ifstream cin("permutari.in");
  	ofstream cout("permutari.out");
  	int n, v[8] = {1, 2, 3, 4, 5, 6, 7, 8};
    cin >> n;
    do {
        for (int i = 0; i < n; ++i) {
            cout << v[i] << " ";
        }
        cout << "\n";
    } while (next_permutation(v, v + n));
  	cout.close();
    return 0;
}
