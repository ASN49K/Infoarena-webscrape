#include <bits/stdc++.h>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
const int N = 10;
int n,k,s[N];
void bkt(int);
int main()
{
    f>>n;
    bkt(1);

    return 0;
}
void bkt(int p)
{
    /// conditia de oprire
    if(p==n+1)
    {
        for(int i=1;i<=n;i++)
            g<<s[i]<<' ';
        g<<'\n';
        return;
    }
    /// generez solutie partiala
    for(int j=1;j<=n;j++)
    {
        int folosit=false;
        for(int q=1;q<p;q++)
            if(s[q]==j)
                folosit=true;
        if(!folosit)
        {
            s[p]=j;
            bkt(p+1);/// avansez la pozitia urmatoare
        }
    }
}
