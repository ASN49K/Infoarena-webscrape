#include <fstream>

#define SPACE " "
#define NL "\n"

using namespace std;

bool check(int *v, const int N, int i) {
    for (int j = i - 1; j >= 0; --j) {
        if (v[j] == v[i])
            return false;
    }
    return true;
}

void perm(ofstream &out, const int &N) {
    int i = 0, j;
    int max_val = N;
    int init_val = 0;

    int v[N];
    for (i = 0; i < N; i++)
        v[i] = init_val;

    bool valid;
    i = 0;

    while (i >= 0) {
        valid = false;

        while (!valid && v[i] <= max_val) {
            v[i]++;
            valid = check((int *) v, N, i);
        }

        if (v[i] <= max_val) {
            if (i == N - 1) {
                // am gasit solutie
                for (j = 0; j < N; j++)
                    out << v[j] << SPACE;
                out << NL;
            } else {
                // inaintez cu formarea solutiei
                ++i;
            }
        } else {
            // ma intorc pentru a forma o noua solutie
            v[i] = init_val;
            --i;
        }
    }
}

int main(void) {
    ifstream in("permutari.in");
    ofstream out("permutari.out");

    int N;
    in >> N;
    
    perm(out, N);

    in.close();
    out.close();
    return 0;
}
