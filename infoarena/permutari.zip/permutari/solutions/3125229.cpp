#include <bits/stdc++.h>

using namespace std;

ifstream f ("permutari.in");
ofstream g ("permutari.out");

const int nmax = 23;

int v[nmax], viz[nmax], n;

void solve(int lvl)
{
    if (lvl == n + 1)
    {
        for (int i = 1; i <= n; ++i)
            g << v[i] << ' ';
        g << '\n';
        return;
    }

    for (int i = 1; i <= n; ++i)
    {
        if (viz[i])
            continue;

        v[lvl] = i;
        viz[i] = 1;
        solve(lvl + 1);
        viz[i] = 0;
    }
}

int main()
{
    f >> n;

    solve(1);

    return 0;
}
