#include <bits/stdc++.h>
using namespace std;

int main() {
    ifstream fin("permutari.in");
    ofstream fout("permutari.out");

    int N;
    fin >> N;

    vector<int> p(N);
    iota(p.begin(), p.end(), 1);

    do {
        for (int i = 0; i < N; ++i) {
            fout << p[i] << (i == N - 1 ? "" : " ");
        }
        fout << "\n";
    } while (next_permutation(p.begin(), p.end()));

    fin.close();
    fout.close();

    return 0;
}









