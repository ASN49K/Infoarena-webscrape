#include <stdio.h>
#include <stdlib.h>
  FILE*fin;
  FILE*fout;
int v[10],n;
int fol(int k){
  for(int i = 1; i < k; i++)
    if(v[k] == v[i])
      return 0;
  return 1;
}
void back (int k){
  for(int i=1; i<=n ; i++){
    v[k] = i;
    if( fol(k) ){
      if(k == n){
        for(int j = 1; j <= n;j++)
          fprintf(fout,"%d ",v[j]);
        fprintf(fout,"\n");
      }
      else
        back(k+1);
    }
  }
}
int main()
{

  fin =fopen("permutari.in","r");
  fout = fopen("permutari.out","w");
  fscanf(fin,"%d",&n);
  back(1);
  return 0;
}
