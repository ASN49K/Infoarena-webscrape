#include <fstream>

using namespace std;
ifstream cin("permutari.in");
ofstream cout("permutari.out");
int n;
int vf[9],v[9];
void bkt(int x)
{
    if(x==n+1)
    {for(int i=1;i<=n;i++)
        cout<<v[i]<<" ";
        cout<<'\n';}
        else
        {
            for(int j=1;j<=n;j++)
                if(vf[j]==0)
            {
                v[x]=j;
                vf[j]=1;
                bkt(x+1);
                vf[j]=0;
            }
        }
}
int main()
{
    cin>>n;
    bkt(1);
    return 0;
}
