#include <iostream>
#include <fstream>
using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");
const int maxn = 10;
bool viz[maxn];
int v[maxn];
int n;

void backtrack(int poz)
{
    if(poz == n + 1)
    {
        for(int i = 1; i <= n; i++)
            out << v[i] << " ";
        out << "\n";
        return;
    }
    for(int i = 1; i <= n; i++)
    {
        if(!viz[i])
        {
            viz[i] = 1;
            v[poz] = i;
            backtrack(poz + 1);
            viz[i] = 0;
        }
    }
}

int main()
{
    in >> n;
    backtrack(1);
    return 0;
}
