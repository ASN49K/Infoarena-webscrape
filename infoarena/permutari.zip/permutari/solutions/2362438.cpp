#include <bits/stdc++.h>

using namespace std;

int n;

vector <int> v;
bool viz[10];

ifstream fin("permutari.in");
ofstream fout("permutari.out");

void gen()  {
    if(v.size() == n)  {
        for(auto x : v)
            fout << x << " ";
        fout << "\n";
        return;
    }
    for(int i = 1;i <= n;i++)  {
        if(viz[i] == 0)  {
            viz[i] = 1;
            v.push_back(i);
            gen();
            viz[i] = 0;
            v.pop_back();
        }
    }
}

int main()  {
    fin >> n;
    gen();
    return 0;
}
