#include <bits/stdc++.h>
using namespace std;
ifstream  in("permutari.in");
ofstream  out("permutari.out");
int n,i;
vector <int> p;

int main()
{
	in >> n ;
	for (i=1;i<=n;i++)
	{
		p.push_back(i);
	}
		for (i=0;i<n;i++)
		{
			out << p[i]<<" ";
		}
		out << "\n";
	while (next_permutation(p.begin(),p.end()))
	{
		for (i=0;i<n;i++)
		{
			out << p[i]<<" ";
		}
		out << "\n";	
	}
    return 0;
}
