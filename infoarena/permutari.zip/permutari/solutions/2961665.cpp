#include <iostream>
#include <fstream>
using namespace std;


ifstream fin("permutari.in");
ofstream fout("permutari.out");


int n, fol[26], k, contor = 0, aux1 = 0, aux2 = 0;

void gen(int lg, char sir[11]) {
  if (lg == k + 1 && n + 1 != k) {
        for (int i = 1; i <= n; ++i) {

      aux1 = sir[i] - 'a' + 1;
     // cout << aux1;
    }
    //cout << endl;
    if(aux1 != aux2) {
    for (int i = 1; i <= n; ++i) {

      fout << sir[i] - 'a' + 1 << " ";
    }
    fout << "\n";
    }
    aux2 = aux1;
    //cout << aux2 << endl;
    return;
  }
  else if (lg == k + 1 && n + 1 == k) {
        for (int i = 1; i <= n; ++i) {

      aux1 = sir[i] - 'a' + 1;
      fout << aux1 << " ";
    }
    fout << endl;
    if(aux1 != aux2) {
    for (int i = 1; i <= n; ++i) {

   //   cout << sir[i] - 'a' + 1;
    }
    //cout << "\n";
    }
    aux2 = aux1;
    //cout << aux2 << endl;
    return;
  }
  for (char c = 'a'; c < 'a' + k; ++c) {
    if (fol[c - 'a'] == 0) {
      sir[lg] = c;
      fol[c - 'a'] = 1;
      gen(lg + 1, sir);
      fol[c - 'a'] = 0;
      // La intoarcerea din recursivitate este important sa marcam ca nu mai
      // folosim litera curenta
    }
  }
}

int main() {
    char text[11];
    fin >> k;
    n = k;
  gen(1, text);
  return 0;
}
