#include<bits/stdc++.h>
using namespace std;
ifstream F("permutari.in");
ofstream G("permutari.out");
int n,a[8],i;
int main()
{
    for(F>>n;i<n;a[i]=i+1,G<<++i<<' ');
    for(;G<<'\n',next_permutation(a,a+n);)
        for(i=0;i<n;G<<a[i++]<<' ');
    return 0;
}
