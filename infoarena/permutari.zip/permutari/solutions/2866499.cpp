#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

const int NMAX = 10;
int a[NMAX],ver[NMAX],n;

void permutari(int n,int ind=1){
    if(ind==n+1){
        for(int i=1;i<=n;i++){
            fout << a[i] << ' ';
        }
        fout << '\n';
        return;
    }
    for(int i=1;i<=n;i++){
        if(ver[i]==true) continue;
        a[ind]=i;
        ver[i]=true;
        permutari(n,ind+1);
        ver[i]=false;
    }
}

int main()
{
    fin >> n;
    permutari(n);
    return 0;
}
