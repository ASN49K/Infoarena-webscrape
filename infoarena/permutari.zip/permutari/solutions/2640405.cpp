#include <bits/stdc++.h>
#define ll long long
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, v[10], fr[10];

void gen(int lg) {
    if (lg == n + 1) {
        for (int i = 1; i < lg; i++)
            fout << v[i] << ' ';
        fout << '\n';
        return;
    }

    for (int i = 1; i <= n; i++)
        if (!freq[i]) {
            fr[i] = 1;
            v[lg] = i;
            gen(lg + 1);
            fr[i] = 0;
        }
}

int main() {
    fin >> n;
    gen(1);

    return 0;
}
