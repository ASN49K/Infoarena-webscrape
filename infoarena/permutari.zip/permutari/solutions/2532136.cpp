#include <bits/stdc++.h>

using namespace std;

ifstream in;
ofstream out;

int n;
vector<int> v;

int main()
{
    in.open("permutari.in");
    out.open("permutari.out");
    
    in>>n;
    for(int i=1;i<=n;i++)
        v.push_back(i);
    do{
        for(int i=0;i<n;i++)
            out<<v[i]<<" ";
        out<<endl;
    }while (next_permutation(v.begin(), v.end()));
    return 0;
}
