#include <fstream>

using namespace std;

long long fac ( int n ) {
  long long fact = 1;
  for ( int i = 2; i <= n; i ++ )
    fact *= i;
  return fact;
}

void afisare_permutare ( int lungime, const int& nr, ofstream& fout ) {
  bool folosit[ 9 ];
  int i, cpy_nr, de_folosit;
  cpy_nr = nr;

  for ( i = 0; i < 9; i ++ )
    folosit[ i ] = false;
  for ( i = lungime - 1; i >= 0; i -- ) {
    de_folosit = ( cpy_nr / fac( i ) )+ 1;
    int l = 0;
    while ( de_folosit > 0 ) {
      l ++;
      while ( folosit[ l ] )
        l ++;
      de_folosit --;
    }
    fout << l << " ";
    folosit[ l ] = true;
    cpy_nr %= fac( i );
  }
}



int main()
{

    int n, i;

    ifstream cin ( "permutari.in" );
    ofstream cout ( "permutari.out" );
    cin >> n;

    for ( i = 0; i < fac( n ); i ++ ) {
      afisare_permutare( n, i, cout );
      cout << "\n";
    }



    return 0;
}
