#include <fstream>

using namespace std;

ifstream cin( "permutari.in" );
ofstream cout( "permutari.out" );

int v[10], viz[10], n;

void bkt( int poz ){
  int i;
  if( poz == n ){
    for( i = 0; i < n; ++i )
      cout << v[i] << " ";
    cout << "\n";
  }
  for( i = 1; i <= n; ++i ){
    if( !viz[i] ){
      viz[i] = 1;
      v[poz] = i;
      bkt(poz+1);
      viz[i] = 0;
    }
  }
}

int main()
{
    cin >> n;
    bkt(0);
    return 0;
}
