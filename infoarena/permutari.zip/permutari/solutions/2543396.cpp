#include <fstream>
#define dim 10
using namespace std;
int a[dim];
int f[dim];
int n;

ifstream fin("permutari.in");
ofstream fout("permutari.out");


void backtrack (int pas) {
    if (pas==n+1) {
        for (int i=1;i<=n;i++) fout<<a[i]<<" ";
        fout<<"\n";
    }
    else {
        for (int i=1;i<=n;i++) {
            if (f[i]==0) {
                f[i]=1;
                a[pas]=i;
                backtrack(pas+1);
                f[i]=0;
            }
        }
    }
}

int main() {
    fin>>n;
    backtrack(1);
    return 0;
}
