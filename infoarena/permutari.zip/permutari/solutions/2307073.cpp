
#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n,x[10],use[10];

void afisare(){
int i;
for(i=1;i<=n;++i) fout << x[i] << " ";
fout << "\n";
}

void perm(int k){
int i;
if(k==n+1) afisare();
else for(i=1;i<=n;++i) if(!use[i]) {
    use[i]=1;
    x[k]=i;
    perm(k+1);
    use[i]=0;
}
}

int main(){
fin >> n;
perm(1);
}
