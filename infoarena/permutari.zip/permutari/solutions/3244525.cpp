#include <bits/stdc++.h>

using namespace std;

int v[10], n;
bool fr[10];

ifstream fin ( "permutari.in" );
ofstream fout ( "permutari.out" );

void permutari( int x ) {
    if ( x == n + 1 ) {
        for ( int i = 1; i <= n; i++ ) {
            fout << v[i] << ' ';
        }
        fout << '\n';
        return;
    }
    else {
        for ( int i = 1; i <= n; i++ ) {
            if ( fr[i] == 0 ) {
                fr[i] = 1;
                v[x] = i;
                permutari( x + 1 );
                fr[i] = 0;
            }
        }
    }
}

int main() {
    fin >> n;
    permutari( 1 );

    return 0;
}