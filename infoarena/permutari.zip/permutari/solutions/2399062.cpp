#include <fstream>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int n, f[9];
bool viz[9];

inline void bkt(int k, int nr)
{
    if (nr == n)
    {
        for (int i = 1; i <= n; ++i)
            out << f[i] << " ";
        out << '\n';
    }
    else
    {
        for (int i = 1; i <= n; ++i)
        {
            if (!viz[i])
            {
                viz[i] = 1;
                f[nr + 1] = i;
                bkt(i, nr + 1);
                viz[i] = 0;
            }
        }
    }
}

int main()
{
    in >> n;
    for (int i = 1; i <= n; ++i)
    {
        viz[i] = 1;
        f[1] = i;
        bkt(i, 1);
        viz[i] = 0;
    }
    return 0;
}
