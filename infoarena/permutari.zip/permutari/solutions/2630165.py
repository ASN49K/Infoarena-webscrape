def back(k, a):
    if k == n:
        g.write(str(a) + '\n')
    else:
        for i in range(1, n + 1):
            if i not in a:
                back(k + 1, a + [i])

with open("permutari.in", "r") as f, open("permutari.out", "w") as g:
    n = int(f.readline())
    back(0, [])