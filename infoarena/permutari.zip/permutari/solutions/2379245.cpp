#include <fstream>
using namespace std;
int x[20], n, k, ok;
ifstream f("permutari.in");
ofstream g("permutari.out");
void afisare()
{
    int i;
    for(i = 1; i <= n; i ++) g << x[i] <<" ";
    g << "\n";
}
void cont(int k, int &ok)
{
    int i;
    ok = 1;
    for(i = 1; i <= k - 1; i++)
        if (x[k] == x[i]) ok = 0;
}
int succesor(int k)
{
    if (x[k] < n)
    {
        x[k] = x[k] + 1;
        return 1;
    } else return 0;
}

int main()
{
    f >> n;
    k = 1;
    x[k] = 0;
    while (k > 0)
    {
        ok = 0;
        while (!ok && succesor(k))
            cont(k, ok);
        if (!ok) k --;
        else if (k == n) afisare();
                else
                {
                    k ++;
                    x[k] = 0;
                }
    }
    return 0;
}
