def read_gen(fname):
    with open(fname, 'rt') as fin:
        for line in fin:
            for val in line.split():
                yield int(val)

def bkt(step, used, perm, n, fout):

    if step == n + 1:
        for i in range(1, n + 1):
            fout.write('{} '.format(perm[i]))
        fout.write('\n')
    else:
        for i in range(1, n + 1):
            if used[i] is False:
                used[i] = True
                perm[step] = i
                bkt(step + 1, used, perm, n, fout)
                used[i] = False

if __name__ == "__main__":
    it = read_gen('permutari.in')
    n = next(it)
    used = [False for _ in range(n + 1)]
    perm = [0 for _ in range(n + 1)]
    with open('permutari.out', 'wt') as fout:
        bkt(1, used, perm, n, fout)
    
    