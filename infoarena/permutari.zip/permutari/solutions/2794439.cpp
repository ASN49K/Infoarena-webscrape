#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");

void perm (int n, int y, vector<int> aleg){
    if (y == n){
        vector<int> amvazut(n + 1, 0);
        bool ok = 0;
        for(int i = 0; i < n; i++){
            amvazut[aleg[i]]++;
            if (amvazut[aleg[i]] > 1)
                ok = 1;
        }
        if (ok == 0){
            for (int i = 0; i < n; i++)
                out<< aleg[i] << " ";
            out<< "\n";
        }
    }
    else
    {
        for (int i = 1; i <= n; i++){
            aleg[y] = i;
            perm(n, y + 1, aleg);
        }
    }
}
int main()
{
    int n, y = 0;
    vector<int> aleg(n, 0);

    in>> n;
    perm(n, y, aleg);
    return 0;
}
