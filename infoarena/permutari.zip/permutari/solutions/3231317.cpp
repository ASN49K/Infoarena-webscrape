#include <bits/stdc++.h>
#include <fstream>

using namespace std;
 
 ifstream fin ("permutari.in");
 ofstream fout ("permutari.out");
 
 int N;
 int v[8];
 int pus[8] = {0};
 void f(int step)
 {
     
     if(step > N)
      {
          for(int k = 1; k <= N; k++)
            fout << v[k] << ' ';
        fout << "\n";
        return;
      }
     
     for(int i = 1; i <= N; i++)
    {
        if(pus[i] == 0)
            {
                pus[i] = 1;
                v[step] = i;
                f(step + 1);
                pus[i] = 0;
            }
        
    }
 }
int main() 
{
    fin >> N;
    f(1);
}
    
