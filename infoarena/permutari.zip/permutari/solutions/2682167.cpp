#include <bits/stdc++.h>
using namespace std;
#define pb push_back
#define fi first
#define se second
#define MOD 1000000007

typedef vector<int> vi;
typedef vector<vi> vvi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef long long ll;
typedef vector<ll> vll;
typedef vector<vll> vvll;
typedef double ld;

ifstream fin("permutari.in");
ofstream fout("permutari.out");


int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    int n;
    fin >> n;
    vi v;
    for (int i = 1; i <= n; i++) {
        v.pb(i);
    }
    
    do {
        for (auto it : v) {
            fout << it << " ";
        }
        fout << "\n";
    } while (next_permutation(v.begin(), v.end()));
    
    return 0;
}