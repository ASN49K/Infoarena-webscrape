#include <stdio.h>
#include <stdlib.h>

#define MAXN 8
#define MARKED 1
#define UNMARKED 0

FILE *fin, *fout;

char v[ MAXN ], freq[ MAXN + 1 ];
int n;

void backt( int pos )
{
    int x;
    if( pos == n )
    {
        for( x = 0; x < n; x++ )
        {
            fputc( v[ x ] + '0', fout );
            fputc( ' ', fout );
        }
        fputc( '\n', fout );
    }
    else
    {
        for( x = 1; x <= n; x++ )
        {
            if( freq[ x ] == 0 )
            {
                v[ pos ] = x;
                freq[ x ] = MARKED;
                backt( pos + 1 );

                freq[ x ] = UNMARKED;
            }
        }
    }
}

int main()
{
    fin = fopen( "permutari.in", "r" );
    fscanf( fin, "%d", &n );
    fclose( fin );

    fout = fopen( "permutari.out", "w" );
    backt( 0 );
    fclose( fout );
    return 0;
}
