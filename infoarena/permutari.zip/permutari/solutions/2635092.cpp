#pragma GCC optimize("Ofast")
#include <bits/stdc++.h>

typedef long long ll;

const ll mod=1e9+7;

const int dx[] = {0, 1, 0, -1};
const int dy[] = {1, 0, -1, 0};

#define all(x) x.begin(),x.end()
#define allr(x) x.rbegin(),x.rend()
#define rc(x)  return cout<<x<<"\n",0
#define sz(s)  (int) s.size()
#define pb push_back
#define mp make_pair
#define fr first
#define sc second

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

ll t,n,a[10];

void scr() {
	for (int i=1; i<=n; i++) {
		g << a[i] << " ";
	}
	g << '\n';
}

void perm(int b) {
	if (b==n) {
		scr();
	}
	else {
		for (int i=b;i<=n; i++) {
			swap(a[b],a[i]);
			perm(b+1);
			swap(a[b],a[i]);
		}
	}
}

int main() {
ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	f >> n;
	for (int i=1; i<=n; i++) {
		a[i]=i;
	}
	perm(1);
	
}

