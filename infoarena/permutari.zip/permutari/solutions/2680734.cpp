#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int n;
int sol[10], f[10];
void bt(int k)
{
    if (k==n+1)
    {
        for (int i=1;i<=n;++i)
        {
            fout << f[i] << " ";
        }
        fout << "\n";
        return;
    }
    for (int i=1;i<=n;++i)
    {
        if (!sol[i])
        {
            f[k]=i;
            sol[i]=1;
            bt(k+1);
            sol[i]=0;
        }
    }
}

int main()
{
    fin >> n;
    bt(1);
    return 0;
}
