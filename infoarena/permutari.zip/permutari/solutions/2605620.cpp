#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

short N, sol[8];

bool Ok(short i)
{
    for(short j=1;j<i;j++)
        if(sol[i]==sol[j])
            return false;
    return true;
}

void Afisare()
{
    for(short i=1;i<=N;i++)
        fout<<sol[i]<<' ';
    fout<<'\n';
}

void Back(short i)
{
    if(i==N+1)
        Afisare();
    else
    {
        for(short j=1;j<=N;j++)
        {
            sol[i]=j;
            if(Ok(i))
                Back(i+1);
        }
    }
}

int main()
{
    fin>>N;
    Back(1);
    return 0;
}
