#include <iostream>
#include <fstream>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int n,x[9];
bool valid(int k)
{
    for(int i=1;i<k;i++)
        if(x[k]==x[i] )
        return 0;
    return 1;
}
void afis()
{

    for(int i=1;i<=n;i++)
        g<<x[i]<<' ';
    g<<'\n';
}
void backt(int k)
{for(int v=1;v<=n;v++)
{

x[k]=v;
if(valid(k))
{
if(k==n)
    afis();
    else
    backt(k+1);}

}


}
int main()
{f>>n;
backt(1);


    return 0;
}
