#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n;
int st[20];
bool f[20];

void afisare() {
    for (int i = 1; i <= n; ++i) {
        fout << st[i] << " ";
    }
    fout << endl;
}

void backtrack(int top) {
    if (top > n) {
        afisare();
        return;
    }

    for (int i = 1; i <= n; ++i) {
        if (f[i] == 0) {
            f[i] = 1;
            st[top] = i;
            backtrack(top + 1);
            f[i] = 0;
        }
    }
}

int main() {
    fin >> n;

    backtrack(1);

    return 0;
}
