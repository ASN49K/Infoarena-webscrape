#include <stdio.h>
#include <stdlib.h>

#define D 1
#define MAXN 8

FILE *in, *out;
int perm[MAXN];
int n;


void genPerm(int size, int freg){
  int i, p2;

  if(size == n){
    for(i = 0; i < n; i++)
      fprintf(out, "%d ", perm[i]);
    fprintf(out, "\n");
  }else{
    p2 = 1;
    for(i = 1; i <= n; i++){
      if(freg/p2%2 == 0){
        perm[size] = i;

        size++;
        genPerm(size, freg+p2);
        size--;
      }

      p2 *= 2;
    }
  }
}

int main()
{
    in = fopen("permutari.in", "r");
    fscanf(in, "%d", &n);
    fclose(in);

    out = fopen("permutari.out", "w");
    genPerm(0, 0);
    fclose(out);

    return 0;
}
