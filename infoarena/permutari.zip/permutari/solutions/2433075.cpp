#include <bits/stdc++.h>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int i,n;
vector<int> v;
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
        v.push_back(i);

    while(next_permutation(v.begin(),v.end()))
    {
      for(i=0;i<n;++i)
            g<<v[i]<< ' ';
      g<<"\n";

    }
    return 0;
}
