#include <fstream>
using namespace std;
ifstream   in("permutari.in");
ofstream out("permutari.out");
int x[100],k,n,nrsol;
void tipar()
{
    int i;
    for(i=1; i<=n; i++)
        out<<x[i]<<' ';
    out<<endl;
}
int valid(int k)
{
    int i;
    for(i=1; i<k; i++)
        if(x[k]==x[i])
            return 0;
    return 1;
}

void bkt ()
{

    k=1;
    x[k]=0;
    while(k>0)
        if(k==n+1)
        {
            tipar();
            nrsol++;
            k--;
        }
        else
         if(x[k]<n)
        {
            x[k]++;
            if( valid(k) )
            {
                k++;
                x[k]=0;
            }
        }
        else
            k--;

}

int main()
{

    in>>n;
    bkt();
    return 0;
}
