#include <bits/stdc++.h>

using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");
int n,i;
vector <int> v;
int main()
{
    fin>>n;
    for (i=1;i<=n;i++) v.push_back(i);
    for (i=0;i<n;i++)
        fout<<v[i]<<" ";
    fout<<'\n';
    while (next_permutation(v.begin(),v.end()))
    {
        for (i=0;i<n;i++)
            fout<<v[i]<<" ";
        fout<<'\n';
    }
    return 0;
}
