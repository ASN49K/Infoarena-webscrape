#include <iostream>
#include <fstream>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n, x[10], p[10];

void afisare() {
  for (int i = 1; i <= n; i++) {
    g << x[i] << ' ';
  }
  g << '\n';
}

void backtrack(int o) {
  for (int i = 1; i <= n; i++) {
    if (!p[i]) {
      x[o] = i;
      p[i] = 1;
      if (o == n) {
        afisare();
      }
      else backtrack(o + 1);
      p[i] = 0;
    }
  }
}

int main() {
  // f >> n;
  n = 3;
  backtrack(1);
}