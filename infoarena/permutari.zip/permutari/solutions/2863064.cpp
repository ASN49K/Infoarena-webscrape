#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <stack>
#define NMAX 2000005
using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");
int n,st[10];
bool valid(int k)
{
    for(int i=1;i<k;++i)
        if(st[i]==st[k])
            return false;
    return true;
}
bool solutie(int k)
{
    return (k==n);
}
void afisare()
{
    for(int i=1;i<=n;++i)
        fout << st[i] << " ";
    fout << '\n';
}
void back(int k)
{
    for(int i=1;i<=n;++i)
    {
        st[k]=i;
        if(valid(k))
        {
            if(solutie(k))
                afisare();
            else
                back(k+1);
        }
    }
}
int main()
{
    fin >> n;
    back(1);
    return 0;
}
