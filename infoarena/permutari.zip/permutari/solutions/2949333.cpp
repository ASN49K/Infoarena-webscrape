#include<bits/stdc++.h>
using namespace std;
ifstream F("permutari.in");
ofstream G("permutari.out");
int n,i,v[8];
int main()
{
    for(F>>n;i<n;v[i]=i+1,G<<++i<<' ');
    for(;G<<'\n',next_permutation(v,v+n);)
        for(i=0;i<n;G<<v[i++]<<' ');
    return 0;
}
