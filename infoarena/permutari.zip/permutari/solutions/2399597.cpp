#include <iostream>
#include <fstream>


using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");
int n,x[100],nr;
bool v[10];




void bkt(int k)
{
    int i;
    for (i=1; i<=n; i++)
        if (!v[i])
        {
            x[k]=i;
            v[i]=1;
            nr++;
            if(k==n)
            {for (int d=1; d<=k; d++)
                cout<<x[d]<<" ";
            cout<<endl;
            }

            else bkt(k+1);
            v[i]=0;
        }


}

int main()
{
    cin>>n;
    bkt (1);


}
