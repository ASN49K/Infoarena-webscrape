#include <bits/stdc++.h>
using namespace std;
string np = "permutari";
ifstream f(np + ".in");
ofstream g(np + ".out");

// #define f cin
// #define g cout

int n, v[10];
bool fq[10];

void back(int k)
{
    if (k > n)
    {
        for (int i = 1; i <= n; i++)
            g << v[i] << " ";
        g << '\n';
    }
    else
        for (int i = 1; i <= n; i++)
            if (!fq[i])
            {
                v[k] = i;
                fq[i] = 1;
                back(k + 1);
                fq[i] = 0;
            }
}
int main()
{
    ios_base::sync_with_stdio(false);
    f.tie(nullptr);

    f >> n;

    back(1);

    return 0;
}