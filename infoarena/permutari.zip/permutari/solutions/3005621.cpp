#include <fstream>
using namespace std;
ifstream cin("permutari.in");
ofstream cout("permutari.out");
int n, x[20], p[20];
void afisare(){
    for(int i = 1; i <= n; ++i){
        cout << x[i] << " ";
    }
    cout << '\n';
}
void bk(int k){
    for(int i = 1; i <= n; ++i){
        if(!p[i]){
            p[i] = 1;
            x[k] = i;
            if(k < n) bk(k+1);
            else afisare();
            p[i] = 0;
        }
    }
}
int main(){
    cin >> n;
    bk(1);
    return 0;
}
