#include <iostream>
#include <fstream>

using namespace std;
   ifstream in("permutari.in");
   ofstream out("permutari.out");
int v[9], f[10];
void perm(int poz, int n){
if(poz==n+1){
    for(int i=1; i<=n; i++)
        out<<v[i]<<" ";
    out<<'\n';
}
else{
    for(int j=1; j<=n; j++){
        if(f[j]==0){
        f[j]=1;
        v[poz]=j;
        perm(poz+1, n);
        f[j]=0;
      }
    }
}
}
int main()
{
    int n;
    in>>n;
    perm(1, n);
    return 0;
}
