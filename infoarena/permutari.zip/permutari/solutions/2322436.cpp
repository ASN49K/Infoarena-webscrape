#include <fstream>

using namespace std;
int use[28], n, b[28];
ifstream cin("permutari.in");
ofstream cout("permutari.out");
void bcktr(int pos)
{
	if (pos == n + 1)
	{
		for (int i = 1; i <= n; i++)
		{
			cout << b[i]<<" ";
		}
		cout << "\n";
	}
	else
	{
		for (int i = 1; i <= n; i++)
		{
			if (use[i] == 0)
			{
				use[i] = 1;
				b[pos] = i;
				bcktr(pos + 1);
				use[i] = 0;
			}
		}
	}
}

int main()
{
	ios_base::sync_with_stdio(false);
	cin >> n;
	bcktr(1);
	return 0;
}