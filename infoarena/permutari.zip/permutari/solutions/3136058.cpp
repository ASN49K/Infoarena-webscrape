#include <bits/stdc++.h>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int n,p[10];
int main()
{
    f>>n;
    for(int i=1;i<=n;i++)
        p[i]=i;
    do
    {
        for(int i=1;i<=n;i++)
            g<<p[i]<<' ';
        g<<'\n';
    }
    while(next_permutation(p+1,p+n+1));
    return 0;
}
