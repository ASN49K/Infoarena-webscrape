#include <bits/stdc++.h>

using namespace std;

FILE *fin, *fout;
int viz[ 10 ], v[10];
int n;

void afis(){
  int i;
  for( i = 1; i <= n; ++i )
    fprintf( fout, "%d ", v[i] );
  fprintf( fout, "\n" );
}

void bkt( int poz ){
  int i;
  if( poz == n + 1 ){
    afis();
    return;
  }
  for( i = 1; i <= n; ++i ){
    if( !viz[i] ){
      viz[i] = 1;
      v[poz] = i;
      bkt( poz + 1 );
      viz[i] = 0;
    }
  }
}

int main()
{
    fin = fopen( "permutari.in", "r" );
    fout = fopen( "permutari.out", "w" );
    fscanf( fin, "%d", &n );
    bkt(1);
    fclose( fin );
    fclose( fout );
    return 0;
}
