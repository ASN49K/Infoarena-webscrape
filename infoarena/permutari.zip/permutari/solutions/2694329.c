#include <stdio.h>
#include <stdlib.h>

FILE *fin, *fout;
int v[9],f[9];
int back(n,i){
  int j;

  if(i==n){
    for(j=0;j<n;j++){
      fprintf(fout,"%d ",v[j]+1);
    }
    fprintf(fout,"\n");

  } else{
    for(j=0;j<n;j++){
      if(f[j]==0){
        f[j]=1;
        v[i]=j;
        back(n,i+1);
        f[j]=0;
      }
    }
  }
}

int main(){
  int n;
  fin=fopen("permutari.in","r");
  fscanf(fin,"%d",&n);
  fclose(fin);

  fout=fopen("permutari.out","w");
  back(n,0);
  fclose(fout);

  return 0;
}
