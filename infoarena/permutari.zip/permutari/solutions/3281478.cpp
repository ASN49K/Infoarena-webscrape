#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

#define NMAX 15

int perm[NMAX];

int main() {
    int n;
    fin >> n;

    for (int i = 1; i <= n; ++i) {
        perm[i] = i;
    }

    do {
        for (int i = 1; i <= n; ++i) {
            fout << perm[i] << ' ';
        }
        fout << '\n';
    } while (next_permutation(perm + 1, perm + n + 1));
    return 0;
}
