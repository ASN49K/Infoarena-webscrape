#include <iostream>
#include <fstream>
using namespace std;

ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int n, sir[8], fr[9];

void gen(int lg) {
    if (lg == n) {
        for (int i = 0; i < lg; ++i) {
            fout << sir[i] << " ";
        }
        fout << "\n";
        return;
    }
    for (int i = 1; i <= n; ++i) {
        if (fr[i] == 0) {
            sir[lg] = i;
            fr[i] = 1;
            gen(lg + 1);
            fr[i] = 0;
        }
    }
}

int main() {
    fin >> n;
    gen(0);
    return 0;
}
