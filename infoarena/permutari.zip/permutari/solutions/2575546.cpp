#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <stack>
#include <cstring>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

const int DIM = 9;

int S[DIM],n,k;

void Print()
{
    for(int i=1;i<=n;i++)
        fout<<S[i]<<" ";
    fout<<'\n';
}

bool Sol(int k)
{
    if(k==n)
        return 1;
    return 0;
}

bool OK(int k)
{
    for(int i=1;i<k;i++)
    {
        if(S[i]==S[k])
            return 0;
    }
    return 1;
}

void Back(int k)
{
    for(int i=1;i<=n;i++)
    {
        S[k]=i;
        if(OK(k))
        {
            if(Sol(k))
                Print();
            else
                Back(k+1);
        }
    }
}
int main()
{
    fin>>n;
    Back(1);
}
