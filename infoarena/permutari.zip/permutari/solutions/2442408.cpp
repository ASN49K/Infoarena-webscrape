#include <iostream>
#include <fstream>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n, x[101];

bool valid(int k)
{
    for(int i = 1; i < k; i++)
        if(x[k] == x[i])
            return 0;
    return 1;
}

void afis()
{
    for(int i = 1; i <= n; i++)
        g << x[i] << ' ';
    g << endl;
}

void backt()
{
    int k = 1;
    x[1] = 0;
    while(k > 0)
        if(x[k] < n) ///mai avem elemente
        {
            x[k]++;///...cautare
            if(valid(k))///se verifica conditiile de continuare(v.c.c.)
            {
                if(k == n) ///este solutie
                {
                    afis();
                }
                else
                    x[++k] = 0; ///avansare+initializare
            }
        }
        else
            k--;///revenire
}

/**
void backt(int k)
{
    if(k <= n) ///mai avem elemente
        for(int i = 1; i <= n; i++)
        {
            x[k] = i;
            if(valid(k))
                backt(k + 1);
        }
    else
        afis();
}
*/

int main()
{
    f >> n;
    backt();
    return 0;
}
