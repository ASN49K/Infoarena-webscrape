#include <stdio.h>
FILE *fin, *fout;
char o[330];
int main()
{

    short n;
    fin = freopen("permutari.in", "r",stdin);
    fout = freopen("permutari.out", "w",stdout);
    fscanf(fin, "%d", &n);
    switch(n)
    {
    case 1:
        {
            fprintf(fout,"1");
            break;
        }
    case 4:
    {
        short a,b,c,d,v[5]= {1,0,0,0,0};
        for(a=1; a<=n; a++)
        {
            v[a]=1;
            for(b=1; b<=n ; b++)
            {
                if(!v[b])
   {
       v[b]=1;
       for(c=1; c<=n ; c++)
       {
           if(!v[c])
           {
               v[c]=1;
               for(d=1; d<=n ; d++)
               {
                   if(!v[d])
                {
              fprintf(fout,"%d %d %d %d\n",a,b,c,d);
                    }
                   }
                   v[c]=0;
               }
                    }
                    v[b]=0;
                }
            }
            v[a]=0;
        }
        break;
    }
    case 8:
    {
        short a,b,c,d,e,f,g,h,k=1,v[11]={1,0,0,0,0,0,0,0,0,0,0};
        k=1;
        while(k<=321)
        {
            o[k]=' ';
            o[k+2]=' ';
            o[k+4]=' ';
            o[k+6]=' ';
            o[k+8]=' ';
            o[k+10]=' ';
            o[k+12]=' ';
            o[k+14]='\n';k+=16;
        }
        k=0;
        for(a=1;a<=n;a++)
        {
                v[a]=1;
                for(b=1;b<=n;b++)
         {
             if(!v[b])
             {
     v[b]=1;
     for(c=1;c<=n;c++)
     {
         if(!v[c])
         {
             v[c]=1;
             for(d=1;d<=n;d++)
             {
                        if(!v[d])
                        {
                            v[d]=1;
    for(e=1;e<=n;e++)
    {
        if(!v[e])
        {
            v[e]=1;
            for(f=1;f<=n;f++)
            {
                if(!v[f])
                {
                    v[f]=1;

                    for(g=1;g<=n;g++)
                                   {
                          if(!v[g])
                          {
           v[g]=1;

           for(h=1;h<=n;h++)
           {
               if(!v[h])
               {
   o[k]='0'+a;
   o[k+2]=b+'0';
   o[k+4]=c+'0';
   o[k+6]=d+'0';
   o[k+8]=e+'0';
   o[k+10]=f+'0';
   o[k+12]=g+'0';
   o[k+14]=h+'0';k+=16;
   if(k==320)
                   {
                       fprintf(fout,"%s",o);
                       k=0;
       }

                           }
                       }
                       v[g]=0;
                   }
               }
                            v[f]=0;
                        }
                    }
                    v[e]=0;
                }
                        }
                        v[d]=0;
                    }
                }
                v[c]=0;
            }
                        }
                        v[b]=0;
                    }
                }
                v[a]=0;
        }
    }
    break;
    case 7:
        {
            short a,b,c,d,e,f,g,k=1,v[10]={1,0,0,0,0,0,0,0,0,0};

        k=1;
        while(k<=141)
        {
            o[k]=' ';k+=2;
            o[k]=' ';k+=2;
            o[k]=' ';k+=2;
            o[k]=' ';k+=2;
            o[k]=' ';k+=2;
            o[k]=' ';k+=2;
            o[k]='\n';k+=2;
        }
        k=0;
        for(a=1;a<=n;a++)
        {
                v[a]=1;
                for(b=1;b<=n;b++)
         {
             if(!v[b])
             {
     v[b]=1;
     for(c=1;c<=n;c++)
     {
         if(!v[c])
         {
             v[c]=1;
             for(d=1;d<=n;d++)
             {
                        if(!v[d])
                        {
                            v[d]=1;
    for(e=1;e<=n;e++)
    {
        if(!v[e])
        {
            v[e]=1;
            for(f=1;f<=n;f++)
            {
                if(!v[f])
     {
         v[f]=1;

         for(g=1;g<=n;g++)
                        {
               if(!v[g])
               {
        o[k]='0'+a;k+=2;
        o[k]=b+'0';k+=2;
        o[k]=c+'0';k+=2;
        o[k]=d+'0';k+=2;
        o[k]=e+'0';k+=2;
        o[k]=f+'0';k+=2;
        o[k]=g+'0';k+=2;
        if(k==140)
        {
            fprintf(fout,"%s",o);
            k=0;
        }
                    }
                }
                             v[f]=0;
                         }
                     }
                     v[e]=0;
                 }
             }
             v[d]=0;
         }
                }
                v[c]=0;
            }
                        }
                        v[b]=0;
                    }
                }
                v[a]=0;
        }
        break;
        }
        case 6:
        {
            short a,b,c,d,e,f,k=1,v[10]={1,0,0,0,0,0,0,0,0,0};

        k=1;
        while(k<=121)
        {
            o[k]=' ';k+=2;
            o[k]=' ';k+=2;
            o[k]=' ';k+=2;
            o[k]=' ';k+=2;
            o[k]=' ';k+=2;
            o[k]='\n';k+=2;
        }
        k=0;
        for(a=1;a<=n;a++)
        {
                v[a]=1;
                for(b=1;b<=n;b++)
         {
             if(!v[b])
             {
     v[b]=1;
     for(c=1;c<=n;c++)
     {
         if(!v[c])
         {
             v[c]=1;
             for(d=1;d<=n;d++)
             {
                        if(!v[d])
                        {
                            v[d]=1;
    for(e=1;e<=n;e++)
    {
        if(!v[e])
        {
            v[e]=1;
            for(f=1;f<=n;f++)
       {
           if(!v[f])
           {
     o[k]='0'+a;k+=2;
     o[k]=b+'0';k+=2;
     o[k]=c+'0';k+=2;
     o[k]=d+'0';k+=2;
     o[k]=e+'0';k+=2;
     o[k]=f+'0';k+=2;
     if(k==120)
     {
         fprintf(fout,"%s",o);
         k=0;
     }
                      }
                  }
                  v[e]=0;
              }
                   }
                   v[d]=0;
               }
           }
           v[c]=0;
       }
                   }
                        v[b]=0;
                    }
                }
                v[a]=0;
        }
        break;
        }
    }
    return 0;
}
