#include <bits/stdc++.h>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

const int NMAX = 15;
int n;
int arr[NMAX], frq[NMAX];

void backtracking(int k)
{
    if(k == n+1)
    {
        for(int i=1;i<=n;++i)
            g << arr[i] << ' ';
        g << '\n';
    }
    else
    {
        for(int i=1;i<=n;++i)
            if(!frq[i])
            {
                frq[i] = 1;
                arr[k] = i;
                backtracking(k+1);
                frq[i] = 0;
            }
    }
}

int main()
{
    f >> n;
    backtracking(1);
}
