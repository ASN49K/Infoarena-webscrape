#include <fstream>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n,x[9];
bool F[9]; ///F[i]=1 <=> valoarea a fost folosita

void afis()
{
    for(int i=1;i<=n;i++)
        g<<x[i]<<' ';
    g<<'\n';
}

void bt(int k)
{
    if(k <= n)
        for(int i=1;i<=n;i++)
    {
        if(F[i]==0)
        {
            x[k]=i;
            F[i]=1;
            bt(k+1);
            F[i]=0;
        }
    }
    else
        afis();
}

int main()
{
    f>>n;
    bt(1);
    f.close();
    g.close();
    return 0;
}
