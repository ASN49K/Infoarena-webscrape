#include <iostream>
#include <fstream>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int n;
const int NMAX = 9;
int solution[NMAX],f[NMAX];

void perm(int x)
{
    if(x==n+1)
    {
       for(int i=1;i<=n;i++)
       {
           out<<solution[i]<<" ";
       }
       out<<'\n';
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            if(f[i]==0)
            {
                f[i]=1;
                solution[x]=i;
                perm(x+1);
                f[i]=0;

            }
        }
    }
}

int main()
{
    in>>n;
    perm(1);
}
