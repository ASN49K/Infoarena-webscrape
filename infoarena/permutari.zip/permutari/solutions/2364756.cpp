
#include <fstream>

using namespace std;
ifstream cin("premutari.in");
ofstream cout("premutari.out");
int st[100],n;
void afisare(int p){
int i;
for(i=1;i<=p;++i)
cout<<st[i]<<" ";
cout<<endl;}
bool valid(int p)
{int i;
for(i=1;i<p;++i)
if (st[i]==st[p]) return false;

return true;}
void back(int p)
{
    int pval=1;
    for(pval=1;pval<=n;++pval)
    {
        st[p]=pval;
        if(valid(p))
        if(p==n) afisare(p);
        else back(p+1);
    }
}


int main()
{
cin>>n;

back(1);
    return 0;
}
