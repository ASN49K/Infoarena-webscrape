// Mihai Priboi

#include <bits/stdc++.h>

#define MAXN 8

FILE *fin, *fout;

int v[MAXN], f[MAXN + 1], n;

void bkt( int i ) {
  int j;
  if( i == n ) {
    for( j = 0; j < n; j++ )
      fprintf( fout, "%d ", v[j] );
    fprintf( fout, "\n" );
  }
  else {
    for( j = 1; j <= n; j++ ) {
      if( f[j] == 0 ) {
        v[i] = j;
        f[j] = 1;
        bkt( i + 1 );
        f[j] = 0;
      }
    }
  }
}

int main() {
  fin = fopen( "permutari.in", "r" );
  fscanf( fin, "%d", &n );
  fclose( fin );
  fout = fopen( "permutari.out", "w" );
  bkt(0);
  fclose( fout );
  return 0;
}
