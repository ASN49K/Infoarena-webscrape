#include <bits/stdc++.h>

using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n;
int v[20], fr[20];
inline void afisare()
{
    for(int i=1; i<=n; i++)
        fout << v[i] << " ";
    fout << "\n";   
}
inline void bkt(int k)
{
    for(int i=1; i<=n; i++)
    {
        if(!fr[i])
        {
            fr[i]=1;
            v[k]=i;
            if(k<n)
                bkt(k+1);
            else
                afisare();
            fr[i]=0;
        }
    }
}
int main()
{
    fin >> n;
    bkt(1);
    return 0;
}