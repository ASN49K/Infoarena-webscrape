#include <iostream>
#include<fstream>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");
int n,x[20],p[20],cnt=0;;

void afis(){
for(int i=1;i<=n;i++){
    g<<x[i]<<" ";
}
g<<'\n';
cnt++;
}
void back(int k){

for(int i=1;i<=n;i++){

if(!p[i]){
x[k]=i;
p[i]=1;
    if(k<n){
    back(k+1);
     }
    else{
    afis();

      }
p[i]=0;
}
}

}



int main()
{
f>>n;
back(1);
    return 0;
}
