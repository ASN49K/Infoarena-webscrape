#include <bits/stdc++.h>

using namespace std;

#define INFILE "permutari.in"
#define OUTFILE "permutari.out"

const int N_MAX = 8;

void afisare(vector<int> v){
    for(auto &it : v) cout << it << " ";
    cout << '\n';
}

void solve(){

    int n; cin >> n;
    vector<int> v;

    for(int i = 1; i <= n; ++i){
        v.push_back(i);
    }

    do{
        afisare(v);
    }while(next_permutation(v.begin(), v.end()));

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);
    solve();
    return 0;
}
