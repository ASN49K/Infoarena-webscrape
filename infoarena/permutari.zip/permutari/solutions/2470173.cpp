#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n, sol[50];

void afisare(int poz)
{
    for(int i=0; i<poz; i++)
        fout << sol[i] << ' ';
    fout << '\n';
}

int verificare(int x, int poz)
{
    for(int i=0; i<poz; i++)
        if(sol[i] == x) return 0;
    return 1;
}

void bkt(int poz)
{
    if(poz == n) afisare(poz);
    else
        for(int i=1; i<=n; i++)
            if(poz == 0 || verificare(i, poz)) {
                sol[poz] = i;
                bkt(poz+1);
            }
}

int main()
{
    fin >> n;

    bkt(0);

    return 0;
}
