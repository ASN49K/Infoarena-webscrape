#include <fstream>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");
int n, m, sol[10];
bool c[10];
void afis()
{
    for (int i = 1; i <= n; i++)
        g << sol[i] <<' ';
    g << '\n';
}
void bkt(int p)
{
    if (p - 1 == n)
    {
        afis();
        return;
    }
    for (int i = 1; i <= n; i++)
        if (!c[i])
        {
            sol[p] = i;
            c[i] = true;
            bkt(p+1);
            c[i] = false;
        }
}
int main()
{
    f >> n;
    bkt(1);
    f.close();
    g.close();
    return 0;
}
