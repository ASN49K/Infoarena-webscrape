#include <fstream>

using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int n,sol[15];
void afis()
{
    int i=0;
    for(i=1;i<=n;i++)
        g<<sol[i]<<' ';
    g<<'\n';
}
bool ok(int k)
{
    int i=0;
    for(i=1;i<k;i++)
        if(sol[k]==sol[i])
        return false;
    return true;
}
void Back(int k)
{
    int i=0;
    if(k>n)
        afis();
    else
        for(i=1;i<=n;i++)
        {
            sol[k]=i;
            if(ok(k)==true)
                Back(k+1);
        }
}
int main()
{
    f>>n;
    Back(1);
    return 0;
}
