#include <bits/stdc++.h>

using namespace std;

int n;

int v[15];

int f[15];

    ifstream fin("permutari.in");
    ofstream fout("permutari.out");

void bk(int k)
{
    for(int i=1;i<=n;++i)
    {
        if(f[i]==0)
        {
            f[i]=1;
            v[k]=i;
            if(k<n)
            {
                bk(k+1);
            }
            else
            {
                for(int i=1;i<=n;++i)
                {
                    fout<<v[i]<<" ";
                }
                fout<<"\n";
            }
            f[i]=0;
        }
    }
}

int main()
{
    fin>>n;
    bk(1);
    return 0;
}
