#include<iostream>
#include<fstream>
using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int st[9];
int f[9], n;

void Afisare()
{
    int i, j;
    for (j = 1; j <= n; j++)
    {
	fout << st[j] << " ";
    }
    fout << "\n";
}

void Back(int top)
{
   int i;
   if (top == n+1)
	Afisare();
   else
	for (i = 1; i <= n; i++)
	   if (f[i] == 0)
	   {
		f[i] = 1;
		st[top] = i;
		Back(top+1);
		f[i] = 0;
	   }
}

int main ()
{
   fin >> n;
   Back(1);
   return 0;
}
