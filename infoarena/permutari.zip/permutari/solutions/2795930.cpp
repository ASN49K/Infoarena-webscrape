#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream g("permutari.out");
int z,n;
int v[20],f[20];
void per(int p)
{
    int i, j;
    if(p==1)
    {
        j=1;
        while(f[j])
            j++;
        v[p]=j;
        for(i=z;i>=1;i--)
        {
            g<<v[i]<<" ";
        }
    }
    else
    {
        j=0;
        for(i=1;i<=p;i++)
        {
            j++;
            while(f[j])
                j++;
            v[p]=j;
            f[j]=1;
            per(p-1);
            f[j]=0;
        }
    }
    return ;
}
int main()
{
    fin>>n;
    z=n;
    per(n);
}
