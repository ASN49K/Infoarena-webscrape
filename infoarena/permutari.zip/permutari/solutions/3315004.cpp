#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("permutari.in")
ofstream fout ("permutari.out")

int v[8], uz[8], n;
void afis(){
    for(int i=1; i<=n; i++) fout<<v[i]<<" ";
    fout<<endl;
}
void bkt(int k){
    if(k==n+1){
        afis();
        return;
    }
    for(int i=1;i<=n;i++){
        if(uz[i]==0){
            v[k]=i;
            uz[i]=1;
            bkt(k+1);
            uz[i]=0;
        }
    }
}

int main()
{
    fin>>n;
    bkt(1);
    return 0;
}
