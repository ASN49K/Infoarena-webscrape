#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

const int NMax = 8;

int n;
int st[NMax + 5];
bool use[NMax + 5];

void Read(){
    fin >> n;
}

void Print(){
    for (int i = 1; i <= n; i++)
        fout << st[i] << ' ';
    fout << '\n';
}

void Backtracking(int level){
    for (int i = 1; i <= n; i++)
        if (!use[i]){
            use[i] = 1;
            st[level] = i;
            Backtracking(level + 1);
            use[i] = 0;
        }
    if (level == n)
        Print();
}

int main(){
    Read();
    Backtracking(1);
    return 0;
}
