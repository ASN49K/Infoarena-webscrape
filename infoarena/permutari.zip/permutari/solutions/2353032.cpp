#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int v[9], n;

int valid(int k){
    for(int i = 1; i < k; ++i)
        if(v[i] == v[k])
        return 0;
    return 1;
}

void sol(){
    for(int i = 1; i <= n; ++i)
        fout << v[i] << " ";
    fout << endl;
}

void back(int k){
    for(int i = 1; i <= n; ++i){
        v[k] = i;
        if(valid(k))
            if(k == n)
                sol();
            else back(k + 1);
    }
}

int main(){

    fin >> n;
    back(1);
    fin.close();
    fout.close();
    return 0;
}
