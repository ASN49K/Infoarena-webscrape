#include <fstream>
#include <vector>
using namespace std;

int n,m,cnt;
ifstream cin("permutari.in");
ofstream cout("permutari.out");
bool valid(vector<int> & v)
{
    int k=v.size();
    for(int i=0;i<k-1;i++)
    {
        if(v[i]==v[k-1])
            return false;
    }
    return true;
}

void back(vector<int> v)
{
    if(!valid(v))
        return;
    if(v.size()==m)
    {
        for(int x : v)
            cout << x << " ";
        cout << endl;
        //cnt++;
        return;
    }
    for(int i=1;i<=n;i++)
    {
        v.push_back(i);
        back(v);
        v.pop_back();
    }
}
int main()
{
    cin >> n;
    m=n;
    vector<int> vec;
    back(vec);
    //cout << cnt;
    return 0;
}
