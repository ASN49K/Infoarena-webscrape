#include <bits/stdc++.h>

using namespace std;
ifstream fi("permutari.in");
ofstream fo("permutari.out");
int n,perm[10],F[10];
void afis()
{
    for(int i=1;i<=n;i++)
        fo<<perm[i]<<" ";
    fo<<"\n";
}
void bkt(int pos)
{
    if(pos==n+1)
        afis();
    else
    {
        for(int i=1;i<=n;i++)
            if(F[i]==0)
            {
                F[i]=1;
                perm[pos]=i;
                bkt(pos+1);
                F[i]=0;
            }
    }
}
int main()
{
    fi>>n;
    bkt(1);
    fi.close();
    fo.close();
    return 0;
}
