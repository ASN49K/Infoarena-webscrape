#include <iostream>
#include <fstream>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int n;
int v[10];

void print()
{
    for(int i = 1; i <= n; i++)
        out << v[i] << ' ';
    out << '\n';
}

bool check(int index)
{
    for(int i = 1; i < index; i++)
        if(v[i] == v[index])
            return false;
    return true;
}

void gen_perm(int index)
{
    for(v[index] = 1; v[index] <= n; v[index]++)
    {
        if(index == n + 1)
        {
            print();
            return;
        }
        else if(check(index))
            gen_perm(index + 1);
    }
}

int main()
{
    in >> n;

    gen_perm(1);

    return 0;
}
