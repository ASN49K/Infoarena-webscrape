#include <fstream>

using namespace std;

ifstream cin("permutari.in");
ofstream cout("permutari.out");

int n, k, sol[10], viz[10];

void bkt(int poz);

int main()
{
    cin >> n;

    bkt(1);

    return 0;
}

void bkt(int poz)
{
    if(poz == n + 1)
    {
        for(int i = 1; i <= n; i++)
            cout << sol[i] << " ";

        cout << '\n';
    }

    else
    {
        for(int i = 1; i <= n; i++)
            if(viz[i] == 0)
            {
                sol[poz] = i;
                viz[i] = 1;

                bkt(poz + 1);

                sol[poz] = 0;
                viz[i] = 0;
            }
    }
}
