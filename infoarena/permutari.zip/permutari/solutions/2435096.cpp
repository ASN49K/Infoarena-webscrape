#include <stdio.h>
#include <algorithm>

inline void print(int n) {
	char snum[65];
	int i = 0;
	do {
		snum[i++] = n % 10 + '0';
		n /= 10;
	} while (n);

	--i;

	while (i >= 0) {
		putchar(snum[i--]);
	}

	putchar(' ');
}

inline int read() {
	int n = 0;
	char c = getchar_unlocked();

	while (!('0' <= c && c <= '9')) {
		c = getchar_unlocked();
	}

	while ('0' <= c && c <= '9') {
		n = (n << 3) + (n << 1) + c - '0';
		c = getchar_unlocked();
	}

	return n;
}

int main() {
	freopen("permutari.in", "r", stdin);
	freopen("permutari.out", "w", stdout);

	int n = read();
	int v[n];

	for (int i = 0 ; i < n ; ++i) {
		v[i] = i + 1;
	}

	do {
		for (int i = 0 ; i < n ; ++i) {
			print(v[i]);
		}

		putchar('\n');
	} while (std::next_permutation(v, v + n));
	return 0;
}