#include<bits/stdc++.h> 
#include<fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n,x[20],y[20];
void permutari(){
for(int i=1;i<=n;i++)
fout<<x[i]<<" ";
fout<<endl;}
void perm(int k){
int i;
if(k==n+1)
permutari();
else 
for(i=1;i<=n;i++)
if(!y[i]){
x[k]=i;y[i]=1;
perm(k+1);
y[i]=0;}}
int main(){
fout<<"n=";fin>>n;
perm(1);
return 0;
}
 

