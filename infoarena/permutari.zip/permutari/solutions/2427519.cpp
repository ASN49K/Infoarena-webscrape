#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int a[100],p[100],n;
int afis(){
	for(int i=1;i<=n;++i)
		fout<<a[i]<<" ";
	fout<<"\n";}
bool cond(int k){
	for(int i=1;i<k;++i)
		if(a[i]==a[k])	return 0;
	return 1;
}
int bt(int k){
	for(int i=1;i<=n;++i){
		if(!p[i]){
			a[k]=i;
			p[i]=1;
			if(cond(k))
				if(k==n)
					afis();
				else
					bt(k+1);
			p[i]=0;
		}
	}
}
int main(){
	fin>>n;
	bt(1);
	fin.close();
	fout.close();
}
