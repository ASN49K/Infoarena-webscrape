#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("combinari.in");
ofstream fout("combinari.out");

int n, v[19];

bool isPerm(int v[])
{
    int i, frecv[9] = {0};
    for(i = 1; i <= n; i++)
    {
        frecv[v[i]]++;
        if(frecv[v[i]] > 1)
        {
            return false;
        }
    }
    return true;
}

void back(int pos)
{
    int i;
    if(pos == n + 1)
    {
        if(isPerm(v))
        {
            for(i = 1; i <= n; i++)
            {
                fout << v[i] << " ";
            }
            fout << "\n";
        }
    }
    else
    {
        for(i = 1; i <= n; i++)
        {
            v[pos] = i;
            back(pos + 1);
        }
    }
}

int main()
{
    ifstream cin("permutari.in");
    ofstream cout("permutari.out");
    fin >> n;
    back(1);
    return 0;
}
