#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

bool verif(int nivel, int sol[])
{
    for (int i = 1; i < nivel; i++)
        if (sol[nivel] == sol[i])
            return false;
    return true;
}

void afisare(int k, int sol[])
{
    for (int i = 1; i <= k; i++)
        fout << sol[i] << ' ';
    fout << '\n';
}

void f(int nivel, int k, int sol[])
{
    for (int i = 1; i <= k; i++)
    {
        sol[nivel] = i;
        if (verif(nivel, sol))
            if (nivel == k)
                afisare(k, sol);
            else
                f(nivel+1, k, sol);
    }
}

int main()
{
    int k;
    fin >> k;
    int sol[k+1];
    f(1, k, sol);
    return 0;
}
