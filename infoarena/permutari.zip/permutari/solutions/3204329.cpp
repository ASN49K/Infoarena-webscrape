#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("permutari1.in");
ofstream fout("permutari1.out");
int n,x[8];
void Afis(){
    for(int j=1; j<=n; j++){
        fout<<x[j]<<" ";
    }
    fout<<endl;
}
bool Ok(int k){
    for(int i=1; i<k; ++i){
        if(x[k]==x[i]){
            return false;
        }
    }
    return true;
}
bool Solutie(int k){
 return k==n;
}

void back(int k){
 for (int i=1; i<=n; ++i){
    if(Solutie(k)){
        Afis();
    }else{
        back(k+1);
    }

 }

}

int main()
{
    fin>>n;
    back(1);
    return 0;
}
