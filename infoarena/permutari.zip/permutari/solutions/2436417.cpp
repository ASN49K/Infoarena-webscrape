#include <bits/stdc++.h>
using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int st[100],n,k;

bool valid(int k)
{
    for(int i=1;i<k;i++)
        if(st[k]==st[i])
        return 0;
    return 1;
}
void afisare(){
    for(int i=1;i<=n;i++)
        out<<st[i]<<" ";
    out<<'\n';
}

void bt(int k){
    for(int i=1;i<=n;i++)
    {
        st[k]=i;
        if(valid(k)){

            if(k==n)
                afisare();
        else
            bt(k+1);
        }
    }
}
int main(){
    in>>n;
    bt(1);
}
