#include <fstream>
#include <bitset>

using namespace std;

ifstream cin("permutari.in");
ofstream cout("permutari.out");

const int NMAX = 9;
int f[NMAX], x[NMAX];
int n;

void Afisare()
{
    for(int i = 1; i <= n; i++)
        cout << x[i] << ' ';
    cout << '\n';
}

void back(int k)
{
    for(int i = 1; i <= n; i++)
        if(!f[i])
        {
            f[i] = 1;
            x[k] = i;
            if(k == n)
                Afisare();
            else
                back(k + 1);
            f[i] = 0;
        }
}

int main()
{
    cin >> n;

    back(1);


    return 0;
}