#include <iostream>
#include <fstream>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int n;
int v[100];

bool valid(int x)
{
    for(int i = 1; i < x; i++)
        if(v[i] == v[x])
            return false;

    return true;
}

void print()
{
    for(int i = 1; i <= n; i++)
        out << v[i] << ' ';

    out << '\n';
}

void combi(int x)
{
    for(v[x] = 1; v[x] <= n; v[x]++)
    {
        if(valid(x))
        {
            if(x == n)
                print();
            else
                combi(x+1);
        }
    }
}

int main()
{
    in >> n;

    combi(1);

    return 0;
}
