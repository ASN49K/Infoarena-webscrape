#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

void bkt(int k, int n, vector<int> &st, vector<int> &visited, ofstream &fout) {
    for(int i = 1; i <= n; i++) {
        st[k] = i;

        int ok = 1;
        if (visited[i] == 1) {
            ok = 0;
        }

        if (ok) {
            visited[i] = 1;

            if (k == n) {
                for (int j = 1; j <= n; j++) {
                    fout << st[j] << ' ';
                }
                fout << endl;
            } else {
                bkt(k + 1, n, st, visited, fout);
            }
            visited[i] = 0;
        }
    }
}

int main() {
    ifstream fin("permutari.in");
    ofstream fout("permutari.out");

    int n;
    fin >> n;

    vector<int> st(n + 1, 0);
    vector<int> visited(n + 1, 0);
    bkt(1, n, st, visited, fout);

    return 0;
}