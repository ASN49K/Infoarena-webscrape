#include <iostream>
#include <fstream>


using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");


int n,nivel,sol[10];



bool ebun(int nivel)
{
    for(int i=1; i<nivel; i++)
        if(sol[i]==sol[nivel])
            return false;
    return true;


}

bool esol(int nivel)
{
    if(nivel==n)
        return true;
    else
        return false;

}

void Backtracking(int nivel)
{
    for(int i=1; i<=n; i++)
    {
        sol[nivel]=i;
        if(ebun(nivel))
        {

            if(esol(nivel))
            {
                for(int j=1; j<=n; j++)
                    fout<<sol[j]<<" ";
                fout<<endl;
            }
            else
                Backtracking(nivel+1);



        }

    }



}


int main()
{
    fin>>n;
    Backtracking(1);


}
