#include<bits/stdc++.h>
#include<vector>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n,i;

int main()
{

    fin>>n;
    vector<int> a;
    for(i=1;i<=n;i++)
    {
    a.push_back(i);
    }

    do{
        for(i=0; i< a.size();i++)
        {
            fout<<a[i]<<" ";
        }
        fout<<endl;
    } while(next_permutation(a.begin(), a.end()) );
    return 0;
}
