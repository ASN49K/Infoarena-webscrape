#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n,ap;
int v[11]={0};
int f[11];

int backtrack(int nr)
{
    if(nr==n+1)
        {
            for(int i=1;i<=n;i++)
            {
                fout<<v[i]<<" ";
            }
            fout<<"\n";
        }
    else
    for(int i=1;i<=n;i++)
    {
        if(f[i]==0){
        v[nr]=i;
        f[i]=1;
        backtrack(nr+1);
        f[i]=0;
        }

    }
}



int main()
{
    fin>>n;
    backtrack(1);
}
