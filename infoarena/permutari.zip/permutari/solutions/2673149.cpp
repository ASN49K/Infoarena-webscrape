#include <fstream>
#include <vector>
#include <numeric>
#include <algorithm>

int main() {
	std::ifstream fin("permutari.in");
	std::ofstream fout("permutari.out");
	int n;
	fin >> n;
	std::vector<int>v(n);
	std::iota(v.begin(), v.end(), 1);
	do {
		for (auto x : v) fout << x << " ";
		fout << "\n";
	} while (std::next_permutation(v.begin(), v.end()));
}