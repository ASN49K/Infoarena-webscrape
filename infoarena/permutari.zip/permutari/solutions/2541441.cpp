
#include <bits/stdc++.h>

using namespace std;

ifstream fin ("permutari.in");
ofstream fout("permutari.out");

vector<int>a;

int main()
{
    int i,n;
    fin>>n;
    for(i=1;i<=n;i++)
        a.push_back(i);
    do
    {
        for(i=0;i<n;i++)
            fout<<a[i]<<" ";
        fout<<"\n";
    }
    while(next_permutation(a.begin(),a.end()));
    return 0;
}
