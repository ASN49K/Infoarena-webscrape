#include <iostream>
#include <algorithm>
using namespace std;

int sir[9];

int main() {
    int n;
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        sir[i] = i;
    }
    do {
        for (int i = 1; i <= n; ++i) {
            cout << sir[i];
        }
        cout << "\n";
    } while(next_permutation(sir + 1 , sir + 1 + n));
    return 0;
}
