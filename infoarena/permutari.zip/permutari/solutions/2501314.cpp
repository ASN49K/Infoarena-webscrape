#include <iostream>
#include <fstream>
#define NMAX 2000001

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int viz[8]={0};

void permutari(int k,int n,int x)
{
    for(int i=1;i<=n;++i)
        if(!viz[i])
        {
            viz[i]=1;
            x=x*10+i;
            if(k==n)
                g<<x<<'\n';
            else
                permutari(k+1,n,x);
            x/=10;
            viz[i]=0;
        }
}

int main()
{

    int n;
    f>>n;

    permutari(1,n,0);

    return 0;
}
