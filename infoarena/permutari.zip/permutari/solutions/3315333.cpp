#include <bits/stdc++.h>
#define NMAX 10
using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int n, sol[NMAX];
bool uz[NMAX];

void gen (int k);

int main()
{
    fin>>n;
    gen(1);
    return 0;
}

void gen (int k)
{int i;
 if(k-1 == n)
   {for(i = 1; i <= n; i++)
       fout<<sol[i]<<' ';
    fout<<'\n';
   }
   else
   {for(i = 1; i <= n; i++)
       if(uz[i] == 0)
         {sol[k] = i; uz[i] = 1;
          gen(k + 1);
          uz[i] = 0;
         }
   }
}
