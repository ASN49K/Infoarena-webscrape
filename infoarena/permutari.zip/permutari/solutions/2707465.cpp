
#include<fstream>

using namespace std;
int sol[20],p[20];
int n,k;

ifstream in("combinari.in");
ofstream out("combinari.out");

void afisare(){
    for(int i = 1;i<=n;i++)
    out<<sol[i]<<' ';
    out<<"\n";
}

void bkt(int poz){
    for(int i=1; i<=n;i++)
    if(!p[i]){
        sol[poz]=i;
        p[i]=1;
        if(poz<n)
         bkt(poz+1);
        else
        afisare();
        p[i]=0;
}
    
}

int main(){
    in>>n;
    bkt(1);
    return 0;
}