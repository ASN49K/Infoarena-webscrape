#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int v[9], n;
bool marked[9];

void bkt(int pos){
  if(pos == n + 1){
    for (int i = 1; i <= n; ++i)
      fout<<v[i]<<" ";
    fout<<"\n";
  }
  else{
    for (int val = 1; val <= n; ++val)
      if (!marked[val]) {
        v[pos] = val;
        marked[val] = true;
        bkt(pos + 1);
        marked[val] = false;
      }
  }
}

int main()
{
    fin>>n;
    bkt(1);
    return 0;
}
