#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

void afisare(int k, int sol[])
{
    for (int i = 1; i <= k; i++)
        fout << sol[i] << ' ';
    fout << '\n';
}

void f(int nivel, int k, int sol[], bool used[])
{
    if(nivel == k+1)
        afisare(k, sol);
    else
        for(int i = 1; i <= k; i++)
            if(!used[i])
            {
                used[i] = true;
                sol[nivel] = i;
                f(nivel+1, k, sol, used);
                used[i] = false;
            }
}

int main()
{
    int k;
    fin >> k;
    int sol[10];
    bool used[10];
    f(1, k, sol, used);
    return 0;
}
