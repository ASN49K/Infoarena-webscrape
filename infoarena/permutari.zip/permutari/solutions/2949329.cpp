#include<bits/stdc++.h>
using namespace std;
ifstream F("permutari.in");
ofstream G("permutari.out");
int n,i,v[]={1,2,3,4,5,6,7,8};
int main()
{
    F>>n;
    do
        for(i=0;i<n;G<<v[i++]<<' ');
    while(G<<'\n',next_permutation(v,v+n));
    return 0;
}
