
#include <iostream>
#include <fstream>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int sol[10],n,f[10];

void bt(int x)
{
    if(x==n+1)
    {
        for(int i=1;i<=n;i++)
            out<<sol[i]<<" ";
        out<<'\n';
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            if(f[i]==0)
            {
                f[i]=1;
                sol[x]=i;
                bt(x+1);
                f[i]=0;
            }
        }
    }
}

int main()
{
    in>>n;
    bt(1);
}
