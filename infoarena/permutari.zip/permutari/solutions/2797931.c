#include <stdio.h>
#define MAX_PERM 14

void afis(int p);
void init(int p);
void perm(int p);
void next(int p, int c, int val);

FILE *fin, *fout;
int n;    // numarul elementelor de permutat
int max;  // numarul de permutari afisate
int v[MAX_PERM], mem[MAX_PERM];
int w[6][3] = {1, 2, 3, 1, 3, 2, 2, 1, 3, 2, 3, 1, 3, 1, 2, 3, 2, 1};


int main( void )
{

   fin = fopen("permutari.in", "r");
   fout = fopen("permutari.out", "w");
   fscanf(fin, "%d", &n);


   switch (n)
   {
      case 1:
         fprintf(fout, "1");
         break;
      case 2:
         fprintf(fout, "1 2\n2 1");
         break;
      case 3:
         afis(3);
         break;
      default:
         init(n);
         afis(n);
         perm(n);
   }


    return 0;
}

void afis(int p)
{
   int i,j,k;
   for (i=0; i<6; i++)
   {
      for(k=0; k<p-3; k++)
         fprintf(fout, "%d ", v[k]  );
      for(j=0; j<3; j++)
         fprintf(fout, "%d ", w[i][j]  );
      fprintf(fout, "\n");

   }
   return;
}



void init(int p)
{
   int i,j,k;
   max = 6;
   for(i=4; i<=p; i++)
      max *=i;
   for(k=0; k<p; k++)
      v[k] = k+1;
 

   for(i=0; i<6; i++)
      for(j=0; j<3; j++)
         w[i][j] += p-3;


   for(i=0; i<p; i++)
      mem[i] = i+1;
 
   return;
}




void perm(int p)
{
   int i;
   int c_6 = 0, c_24 = 0, c_120 = 0, c_720 = 0, c_5040 = 0, c_40320 = 0, c_362880 = 0; 
   for (i=6; i<max; i+=6)
   {
      c_6++;
      if (c_6 == 4)
      {
         c_6 = 0;
         c_24++;
         if (c_24 == 5)
         {
            c_24 = 0;
            c_120++;
            if (c_120 == 6)
            {
               c_120 = 0;
               c_720++;
               if (c_720 == 7)
               {
                  c_720 = 0;
                  c_5040++;
                  if (c_5040 == 8)
                  {
                     c_5040 = 0;
                     c_40320++;

                     if (c_40320 == 9)
                     {
                        //*********************
                        c_40320 = 0;
                        c_362880++;
                        //********************
                     }
                     else
                     {
                        next(p, p-9,c_40320);
                        afis(p);
                     }
                  }
                  else
                  {
                     next(p, p-8,c_5040);
                     afis(p);
                  }
               }
               else
               {
                  next(p, p-7,c_720);
                  afis(p);
               }
            }
            else
            {
               next(p, p-6,c_120);
               afis(p);
            }
         }
         else
         {
            next(p, p-5,c_24);
            afis(p);
         }
      }
      else
      {
         next(p, p-4,c_6);
         afis(p);
      }
   }
   return;
}


void next(int p, int c, int val)
{
   // p = numar de variabile
   // c = a cata variabila se modifica
   // val+1 = valoarea pe care o ia variabila
   int i,j,k;

   if (c==0)
   {
      v[c]++;
      for (i=0; i<p; i++)
      {
         for(j=1; j<=val; j++)
            v[c+j] = j;
         for(j=val+1; j<p; j++)
            v[j] = j+1;
      }
   }
   else

   {

      v[p-3] = w[5][0];
      v[p-2] = w[5][1];
      v[p-1] = w[5][2];

      k=v[c];
      v[c] = v[p-val];
      v[p-val] = k;

      for(i=1; i<p; i++)
         mem[i+c] = v[p-i]; 
      for(i=1; i<p; i++)
         v[i+c] = mem[i+c];

   }

   w[0][0] = v[p-3]; ///
   w[0][1] = v[p-2];
   w[0][2] = v[p-1];
   w[1][0] = v[p-3]; //
   w[1][1] = v[p-1];
   w[1][2] = v[p-2];
   w[2][0] = v[p-2]; //
   w[2][1] = v[p-3];
   w[2][2] = v[p-1];
   w[3][0] = v[p-2]; //
   w[3][1] = v[p-1];
   w[3][2] = v[p-3];
   w[4][0] = v[p-1]; //
   w[4][1] = v[p-3];
   w[4][2] = v[p-2];
   w[5][0] = v[p-1]; //
   w[5][1] = v[p-2];
   w[5][2] = v[p-3];


   return;
}
