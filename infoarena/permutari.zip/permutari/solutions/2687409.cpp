#include <fstream>

int Nr[9], Sol[9];

void bkt(int n)
{
    std::ofstream g("permutari.out");
    int k = 1;
    while(k)
        if(Sol[k] < n)
        {
            Sol[k]++;
            if(Nr[ Sol[k] ] == 1)
                continue;
            Nr[ Sol[k] ] = 1;
            if(k == n)
            {
                for(int i = 1; i <= n; i++)
                    g << Sol[i] << ' ';
                g << '\n';
                Nr[ Sol[k] ] = 0;
            }
            else
                Sol[++k] = 0;
        }
        else
            Nr[ Sol[--k] ] = 0;
}

int main()
{
    std::ifstream f("permutari.in");
    int N;
    f >> N;
    f.close();
    bkt(N);
    return 0;
}
