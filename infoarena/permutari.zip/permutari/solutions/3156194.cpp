/*#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream cin("nrtri.in");
ofstream cout("nrtri.out");
vector<int>v;
int n;
void read(){
cin>>n;
v.clear();
v.resize(n+1);
for(int i=1;i<=n;i++){
    cin>>v[i];
}
}
void solve(){
read();
sort(v.begin()+1,v.end());
int rasp=0;
for(int i=1;i<=n;i++){
    int k=i+1;
    for(int j=i+1;j<=n;j++){
        while(k<=n && v[i]+v[j]>=v[k]){
            k++;
        }
    rasp+=(k-j-1);
    }
}
cout<<rasp;
}
int main()
{
int t=1;
while(t--){
    solve();
}
}
*/
#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;
ifstream cin("nrtri.in");
ofstream cout("nrtri.out");
vector<int>v;
int n;
int cautBin(int i,int j){
int st=j;
int dr=n;
int mij;
int rasp=0;
while(st<=dr){
    mij=(st+dr)/2;
    if(v[i]+v[j]>=v[mij]){
     rasp=mij;
     st=mij+1;
    }else{
    dr=mij-1;
    }
}
return rasp;
}
void read(){
cin>>n;
v.clear();
v.resize(n+1);
for(int i=1;i<=n;i++){
    cin>>v[i];
}
}
void solve(){
read();
sort(v.begin()+1,v.end());
int rasp=0;
for(int i=1;i<=n;i++){
    for(int j=i+1;j<=n;j++){
     rasp+=cautBin(i,j)-j;
    }
}
cout<<rasp;
}
int main()
{
int t=1;
while(t--){
    solve();
}
}
