#include <iostream>
#include <fstream>
using namespace std;
int v[100],i;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int verif(int k)
{
    for (i=1;i<k;i++)
    {
        if (v[i]==v[k]) return 0;
    }
    return 1;
}
void afisare(int k)
{
    for (i=1;i<=k;i++)
    {
        fout << v[i] << " ";
    }
    fout << endl;
}
void backtracking(int n)
{
    int k=1;
    v[k]=0;
    while (k>0)
    {
        if (v[k]<n)
        {
            v[k]=v[k]+1;
            if (verif(k)!=0)
            {
                if (k==n) afisare(k);
                else
                {
                    k=k+1;
                    v[k]=0;
                }
            }
        }
        else k=k-1;
    }
}
int main()
{
    int n;
    fin >> n;
    backtracking(n);
}
