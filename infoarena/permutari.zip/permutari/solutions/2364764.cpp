# depslib dependency file v1.0
1551687866 source:c:\users\acer\oji\pregatire de olimpiada\main.cpp
	<iostream>

