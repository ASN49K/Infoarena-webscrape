#include <iostream>
#include <fstream>
using namespace std;

int n, fol[26], sir[11];

void gen(int lg, int sir[11]) {
  if (lg == n + 1) {
    for (int i = 1; i <= n; ++i) {
      fout << sir[i];
    }
    fout << "\n";
    return;
  }
  for (int c = 1; c < 1 + n; ++c) {
    if (fol[c - 1] == 0) {
      sir[lg] = c;
      fol[c - 1] = 1;
      gen(lg + 1, sir);
      fol[c - 1] = 0;
      // La intoarcerea din recursivitate este important sa marcam ca nu mai
      // folosim litera curenta
    }
  }
}

int main() {
    ifstream fin("permutari.in");
    ofstream fout("permutari.out");
    fin >> n;
    gen(1, sir);
    return 0;
}
