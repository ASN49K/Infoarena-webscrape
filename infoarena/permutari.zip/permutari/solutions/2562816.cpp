#include <bits/stdc++.h>
using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

const int DIM = 15;


bool viz[DIM];
int st[DIM];

void bt(int n,int k)
{
    if(k == n)
    {
        for(int i = 1; i <= n; i++)
            out << st[i] <<" ";
         out <<'\n';

    }
    else
    for(int i = 1; i <= n; i++)
    {
        if(viz[i] == false)
        {

            viz[i] = true;
            st[k + 1] = i;
            bt(n,k + 1);
            viz[i] = false;
        }
    }
}

int main()
{
    int n;
    in >> n;

    bt(n,0);


    return 0;
}
