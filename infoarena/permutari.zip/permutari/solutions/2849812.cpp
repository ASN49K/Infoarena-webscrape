#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n,v[9];
bool f[9];

void backtrack(int p) {
    if (p==n+1) {
        for (int i=1;i<=n;i++)
            fout<<v[i]<<" ";
        fout<<"\n";
    }
    else
        for (int i=1;i<=n;i++)
            if (f[i]==0) {
                v[p]=i;
                f[i]=1;
                backtrack(p+1);
                f[i]=0;
            }
}

int main() {
    fin>>n;
    backtrack(1);
    return 0;
}
