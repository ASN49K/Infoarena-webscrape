#include <bits/stdc++.h>
using namespace std;

int main()
{
    ifstream fin("permutari.in");
    ofstream fout("permutari.out");
    int n, i;
    fin >> n;
    vector<int> a(n);
    for (i = 1; i <= n; i++)
        a[i - 1] = i;
    do
    {
        for (int e : a)
            fout << e << " ";
        fout << "\n";
    }
    while(next_permutation(a.begin(), a.end()));
    return 0;
}
