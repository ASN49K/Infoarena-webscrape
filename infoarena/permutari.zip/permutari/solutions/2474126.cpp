#include <fstream>
using namespace std;

const int maxN=21;

int n;
int stk[maxN];
bool used[maxN];

ifstream f("permutari.in");
ofstream g("permutari.out");

void bkt(int k){
    if(k==n+1){
        for(int i=1;i<=n;i++){
            g<<stk[i]<<' ';
        }
        g<<'\n';
        return;
    }

    for(int i=1;i<=n;i++){
        if(!used[i]){
            stk[k]=i;
            used[i]=true;

            bkt(k+1);

            stk[k]=0;
            used[i]=false;
        }
    }
}

int main(){
    f>>n;
    bkt(1);

    return 0;
}