#include <bits/stdc++.h>

using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");
int st[15], v[15] , n;

void Afis (int n)
{
    for (int i = 1; i <= n; i++)
        fout << st[i] << " ";
    fout << "\n";
}

void Back (int k)
{
    if (k == n + 1)
    {
        Afis (n);
    }
    for (int i = 1; i <= n; i++)
        if (v[i] == 0)
        {
            v [i] = 1;
            st[k] = i;
            Back(k + 1);
            v[i] = 0;
        }
}

int main()
{
    fin >> n;
    Back(1);

    return 0;
}
