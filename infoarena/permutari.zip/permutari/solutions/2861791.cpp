#pragma region Template
#include <bits/stdc++.h>
using namespace std;
#define ll int int

// Files
ifstream fin("permutari.in");
ofstream fout("permutari.out");
#pragma endregion Template

int permutations[8];
bool visited[8];

void getPermutations(int n, int k) {
    if (k == n) {
        for (int i = 0; i < n; i++)
            fout << permutations[i] << ' ';
        fout << '\n';
    }
    else
        for (int i = 0; i < n; i++)
            if (visited[i] == false) {
                visited[i] = true;
                permutations[k] = i + 1;
                getPermutations(n, k + 1);
                visited[i] = false;
            }
}


void solve() {
    int n;  fin >> n;
    getPermutations(n, 0);
}

int main() {
    ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);

    int t = 1;  //cin >> t;
    while (t--) {
        solve();
    }

    return 0;
}