#include<cstdio>
int a[10],b[10];

void back(int k,int len)
{
     if(k-1 == len)   //afisam solutia
     {
         for(int i = 1; i <= len;i++)
           printf("%d ",a[i]);
         printf("\n");
     }
     else
     {
         for(int  i = 1; i <= len; i++)
            if(!b[i])  //daca valoarea nu-i folosita
           {
                 a[k] = i;
                 b[i] = 1; //o folosim
                 back(k+1,len); //trecem la pasul urmator
                 b[i] = 0; //o eliberam
           }
     }
}

int main()
{
    freopen("permutari.in","r",stdin);
    freopen("permutari.out","w",stdout);
    int n;
    scanf("%d",&n);
    back(1,n);
    fclose(stdin); fclose(stdout);
    return 0;
}
