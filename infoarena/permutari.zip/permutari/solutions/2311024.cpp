#include <bits/stdc++.h>
/// TONI BO$$ was here
/// #MLC

using namespace std;

int v[10],f[10];

void bkt(int i,int n)
{
    if(i>n)
    {
        for(int j=1; j<=n; j++)
            printf("%d ",v[j]);
        printf("\n");
    }
    else
        for(v[i]=1; v[i]<=n; v[i]++)
            if(!f[v[i]])
            {
                f[v[i]]=1;
                bkt(i+1,n);
                f[v[i]]=0;
            }
}

int main()
{
    int n;
    freopen("permutari.in","r",stdin);
    freopen("permutari.out","w",stdout);
    scanf("%d",&n);
    bkt(1,n);

    return 0;
}
