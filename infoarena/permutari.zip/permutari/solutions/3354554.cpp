#include <bits/stdc++.h>
using namespace std;

ifstream fin("permutari.in");
ofstream  fout("permutari.out");


vector<vector<int>> all;

void backtrack(int n, vector<int>&used, vector<int>&comb) {
    if (comb.size() == n) {
        all.push_back(comb);
        return;
    }

    for (int i = 1; i <= n; i++) {
        if (used[i]) continue;

        used[i] = 1;
        comb.push_back(i);

        backtrack(n, used, comb);
    
        used[i] = 0;
        comb.pop_back();
    }

}
int main(){
    int n;
    fin >> n;

    vector<int> used(n + 1, 0);
    vector<int> comb;

    backtrack(n, used, comb);

    int sz = all.size();

    for (int i = 0; i < sz; i++) {
        for (int j = 0; j < n; j++) {
            fout << all[i][j] << " ";
        }
        fout << "\n";
    }
    return 0;
}