# include <fstream>
using namespace std;

ifstream in ("permutari.in");
ofstream out("permutari.out");

const int NN = 10;
int N , sol[NN];


void afisare();
void back(int K);
bool verificare(int K);

int main(){
in >> N ;
back(1);

return 0;
}

void afisare(){
for(int i = 1 ;i <= N ; i ++)
    out << sol[i] << " ";
out << "\n";

}

void back(int K){
if(K>N)afisare();
else
   for(int i = 1 ; i<=N;i++)
{
 sol[K]=i;
    if(verificare(K)){
        back(K+1);
        sol[K]=0;
    }
}
}

bool verificare(int K)
 {

     for(int i = 1 ; i < K ; i ++)
       if(sol[i] == sol[K])return false;
       return true ;
 }
