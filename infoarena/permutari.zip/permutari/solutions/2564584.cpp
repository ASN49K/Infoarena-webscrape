#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int x[10];
int N;
bool viz[10];

void Back( int k )
{
    for( int i = 1; i <= N; ++i )
    {
        if( !viz[i] )
        {
            x[k] = i;
            viz[i] = 1;

            if( k == N ){
                for( int i = 1; i <= N; ++i )
                    fout << x[i] << ' ';fout << '\n';}
            else Back( k + 1 );
            viz[i] = 0;
        }
    }
}
void Solve()
{
    fin >> N;
    Back( 1 );
}
int main()
{
    Solve();
    return 0;
}
