#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");
bool is_visited[17];

void generate_permutation(short len, short n, short permutation[17]) {
	if (len == n + 1) {
		for (int i = 1; i <= n; ++i) {
			fout << permutation[i] << ' ';
		}
		fout << '\n';
	}
	for (int i = 1; i <= n; ++i) {
		if (!is_visited[i]) {
			permutation[len] = i;
			is_visited[i] = true;
			generate_permutation(len + 1, n, permutation);
			is_visited[i] = false;
		}
	}
}

int main() {
	short n, permutation[17] = { 0 };
	fin >> n;
	short length = 1;
	generate_permutation(length, n, permutation);
	return 0;
}