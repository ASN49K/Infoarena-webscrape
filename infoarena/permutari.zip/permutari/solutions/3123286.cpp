#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int N;

int main() {
    freopen("permutari.in", "r", stdin);
    freopen("permutari.out", "w", stdout);

    cin >> N;
    vector<int> perm;
    perm.reserve(N);
    for (int idx = 1; idx <= N; idx++) {
        perm.push_back(idx);
    }

    do {
        for (int idx = 0; idx < N; idx++) {
            if (idx > 0) {
                cout << " ";
            }
            cout << perm[idx];
        }
        cout << "\n";
    } while (next_permutation(perm.begin(), perm.end()));
    return 0;
}