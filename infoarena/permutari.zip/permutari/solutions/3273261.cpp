///Varianta 1
/*
#include <iostream>
#include <fstream>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n, x[9];

bool valid(int k)
{
    for(int i = 1; i < k; i++)
        if(x[k] == x[i]) return 0;
    return 1;
}

void afis()
{
    for(int i = 1; i <= n; i++)
        g << x[i] << ' ';
    g << '\n';
}

void bt(int k)
{
    if(k <= n)
        for(int i = 1; i <= n; i++)
        {
            x[k] = i;
            if(valid(k))
                bt(k + 1);
        }
    else
        afis();
}
int main()
{
    f >> n;
    bt(1);
    f.close();
    g.close();
    return 0;
}
*/
///Varianta 2
#include <iostream>
#include <fstream>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n, x[9];

bool F[9];

void afis()
{
    for(int i = 1; i <= n; i++)
        g << x[i] << ' ';
    g << '\n';
}

void bt(int k)
{
    if(k <= n)
        for(int i = 1; i <= n; i++)
        {
           if(F[i] == 0)
           {
               x[k] = i;
               F[i] = 1;
               bt(k + 1);
               F[i] = 0;
           }
        }
    else
        afis();
}
int main()
{
    f >> n;
    bt(1);
    f.close();
    g.close();
    return 0;
}
