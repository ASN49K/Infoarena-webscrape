#include <bits/stdc++.h>
using namespace std;
int v[8], i, j, n, cnt, p = 1;
int main()
{
    ifstream f("permutari.in");
    ofstream g("permutari.out");
    f >> n;
    for(i = 1; i <= n; i ++)
    {
        g << i << " ";
        v[i] = i;
        p = p * i;
    }
    g << "\n";
    while(next_permutation(v + 1, v + n + 1))
    {
        for(j = 1; j <= n; j ++)
            g << v[j] << " ";
        g << "\n";
        cnt ++;
        if(cnt == p) break;
    }
    return 0;
}
