#include <stdio.h>

int v[100], 
    u[100], 
    n;

FILE *fin, *fout;

void perm(int k) {

	 if(k == n + 1) {

	 	for(int i = 1; i <= n; ++i) fprintf(fout, "%d ", v[i]);

        fprintf(fout, "\n");  

	 } else {

	 	for(int i = 1; i <= n; ++i) {

	 		if(!u[i]) {

	 		    u[i] = 1;
	 		    v[k] = i;
	 		    perm(k + 1);
	 		    u[i] = 0;  	
	 		}
	 	} 

	 }

}

int main(int argc, char const *argv[])
{

	char *inFile = "permutari.in";
	char *outFile = "permutari.out";

	fin = fopen(inFile, "r");
	fout = fopen(outFile, "w");

	if(!fin || !fout) {
        printf("%s\n", "Error!");
	} 
	
    fscanf(fin, "%d", &n);
	perm(1);
       
	return 0;
}