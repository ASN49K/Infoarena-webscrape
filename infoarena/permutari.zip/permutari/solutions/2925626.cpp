#include<bits/stdc++.h>
std::ofstream G("permutari.out");
short n,i,v[]={1,2,3,4,5,6,7,8};
int main()
{
    std::ifstream("permutari.in")>>n;
    do
        for(i=0;i<n;G<<v[i++]<<' ');
    while(G<<'\n',std::next_permutation(v,v+n));
    return 0;
}
