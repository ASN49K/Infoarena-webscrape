#include <bits/stdc++.h>

using namespace std;
vector<int> v;
int fact[] = {NULL, 1, 2, 6, 24, 120, 720, 5040, 40320};
int main()
{
    ifstream cin("permutari.in");
    ofstream cout("permutari.out");

    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
        v.push_back(i);

    int cnt=fact[n];
    while(cnt>0)
    {
        for(auto x : v)
            cout<<x<<" ";
        cout<<'\n';
        next_permutation(v.begin(), v.end());
        cnt--;
    }

    return 0;
}
