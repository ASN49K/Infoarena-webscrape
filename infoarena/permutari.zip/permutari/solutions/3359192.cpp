#include <fstream>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int  n, x[9], fr[9];

void Afis() {
    for(int i = 1; i <= n; i++)
        g << x[i] << ' ';
    g << '\n';
}

void Back(int k) {
    if(k <= n)
        for(int i = 1; i <= n; i++) {
            if(!fr[i]) {
                fr[i] = 1;
                x[k] = i;
                Back(k + 1);
                fr[i] = 0;
            }
        }
    else Afis();
}

int main() {
    f >> n;
    Back(1);
    f.close();
    g.close();
    return 0;
}
