#include <fstream>

using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");

const int N_MAX = 8;
const int NIL = -1;
char v[N_MAX], nxt[N_MAX + 1];

void print(char v[], int n) {
	for(int i = 0; i < n; ++i)
		fout << (int) v[i] << ' ';
	fout.put('\n');
}

void generatePermutations(int pos, int n, char v[], char nxt[]) {
	if(pos == n)
		print(v, n);
	else{
		int l = nxt[0], ant = 0;
		while(l != NIL){
			v[pos] = l;
			nxt[ant] = nxt[l];
			generatePermutations(pos + 1, n, v, nxt);
			nxt[ant] = l;
			ant = l;
			l = nxt[l];
		}
	}
}

int main() {
	int n;
	fin >> n;

	for(int i = 0; i < n; ++i)
		nxt[i] = i + 1;
	nxt[n] = NIL;

	generatePermutations(0, n, v, nxt);

	fin.close();
	fout.close();
	return 0;
}