#include <fstream>
#include <bitset>

using namespace std;

ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int n, r[10];
bitset < 10 > viz;

void bkt ( int nr );

int main()
{
    fin >> n;
    bkt ( 1 );

    return 0;
}

void bkt ( int nr )
{
    int i;

    if ( nr == n + 1 )
    {
        for ( i = 1 ; i <= n ; i++ ) fout << r[i] << ' ';
        fout << '\n';
        return;
    }

    for ( i = 1 ; i <= n ; i++ )
        if ( viz[i] == 0 )
        {
            viz[i] = 1;
            r[nr] = i;
            bkt ( nr + 1 );
            viz[i] = 0;
        }
}
