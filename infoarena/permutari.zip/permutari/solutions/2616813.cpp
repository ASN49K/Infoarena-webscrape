#include <bits/stdc++.h>

using namespace std;
ifstream r("permutari.in");
ofstream w("permutari.out");
vector<int>s;
int n, viz[9];
void backtracking(int pas){
    if(pas==n+1){
        for(int i=1;i<s.size();i++){
            w<<s[i]<<" ";
        }
        w<<"\n";
        return;
    }
    for(int i=1;i<=n;i++){
        if(viz[i]==0){
            s.push_back(i);
            viz[i]=1;
            backtracking(pas+1);
            s.pop_back();
            viz[i]=0;
        }
    }
}
int main()
{
    r>>n;
    s.push_back(0);
    backtracking(1);
    return 0;
}
