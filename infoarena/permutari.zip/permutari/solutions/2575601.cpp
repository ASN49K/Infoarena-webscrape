// https://www.pbinfo.ro/probleme/123/permutari
// https://infoarena.ro/problema/permutari
#include <fstream>
#include <algorithm>
using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int n,x[9];

int main()
{
    fin>>n;
    for(int i=0;i<n;i++)
        x[i]=i+1;

    do{
        for(int i=0;i<n;i++)
            fout<<x[i]<<' ';
        fout<<endl;
    }while(next_permutation(x,x+n));

    return 0;
}
