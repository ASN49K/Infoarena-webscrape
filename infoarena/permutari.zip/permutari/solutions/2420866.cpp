#include<cstdio>
#define M 4000000
int n,k=1,s[9],i,o,l;
char r[M];
int main()
{
    freopen("permutari.in","r",stdin),freopen("permutari.out","w",stdout),scanf("%d",&n);
    while(k)
    {
        for(s[k]++,o=i=1;i<k&&o;i++)
            if(s[k]==s[i])
                o=0;
        if(o)
            if(s[k]<=n)
                if(k==n)
                {
                    for(i=1;i<=n;i++)
                        r[l++]=s[i]+48,r[l++]=32;
                    r[l++]=10;
                }
                else
                    s[++k]=0;
            else
                k--;
    }
    fwrite(r,1,l,stdout);
}
