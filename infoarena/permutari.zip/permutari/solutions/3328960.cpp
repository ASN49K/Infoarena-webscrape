#include <bits/stdc++.h>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int v[10],n;
void afisare()
{
    for(int j=1; j<=n; j++)
        g<<v[j]<<" ";
    g<<"\n";
}
bool ok(int k)
{
    for(int i=1; i<k; i++)
        if(v[i]==v[k])
            return 0;
    return 1;
}
void bkt(int k)
{
    for(int i=1; i<=n; i++)
    {
        v[k]=i;
        if(ok(k))
            if(k==n)
                afisare();
            else
                bkt(k+1);
    }
}
int main()
{
    f>>n;
    bkt(1);
    return 0;
}