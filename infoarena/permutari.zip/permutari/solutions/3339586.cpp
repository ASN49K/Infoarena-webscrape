#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n,x[10];
void afisare ()
{
    for(int i=1; i<=n; i++)
        fout<<x[i]<<" ";
    fout<<"\n";
}
bool valid(int k)
{
    for(int i=1; i<k; i++)
    {
        if(x[i]==x[k])
        {
            return 0;
        }
    }
    return 1;
}
void perm(int n)
{
    int k=1;
    x[k]=1;
    while(k>0)
    {
        if(x[k]<=n)
        {
            if(valid(k))
            {
                if(k==n)
                {
                    afisare();
                    x[k]++;
                }
                else
                    x[++k]=1;
            }
            else
                x[k]++;
        }
        else
            x[--k]++;

    }
}
int main()
{
    fin>>n;
    perm(n);
}
