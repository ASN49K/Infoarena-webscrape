#include <bits/stdc++.h>

using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");
int n;
vector<int> v;
bool next_perm(vector<int> &v){
    int cnt=0;
    int c=v.size();
for(int i=0;i<c;++i){
   if(v[i]==n-i){
    ++cnt;
   }
}
if(cnt==n){
    return false;
}else{
    bool r=0;
    int in=0;
for(int i=c-1;i>0 && r==0;--i){
    if(v[i-1]<v[i]){
        r=1;
        in=i-1;
    }
}
int j=c;
r=0;
while(j>in+1 && r==0){
    --j;
    if(v[j]>v[in]){
        r=1;
    }
}
int aux=v[in];
v[in]=v[j];
v[j]=aux;
reverse(v.begin()+in+1,v.end());
return true;
}
}
int main()
{
    fin>>n;
    for(int i=1;i<=n;++i){
        v.push_back(i);
    }
    do{
    for(int i=0;i<n;++i){
        fout<<v[i]<<' ';
    }
    fout<<'\n';
    }while(next_perm(v)==true);
    return 0;
}
