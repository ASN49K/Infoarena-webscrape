#include <fstream>
using namespace std;
int res[15], uz[15];
ifstream cin("permutari.in");
ofstream cout("permutari.out");
void back(int poz, int n) {
    int i;
    if (poz == n) {
        for (i = 1; i <= n; i++) {
	    cout << res[i] << ' ';
        }
        cout << '\n';
    } else {
        for (i = 1; i <= n; i++) {
            if (uz[i] == 0) {
                res[poz + 1] = i; 
                uz[i] = 1;
                back(poz + 1, n);
                uz[i] = 0;
            }
        }
    }
}

int main() {
    int n;
    cin >> n;
    back(0, n);
    return 0;
}