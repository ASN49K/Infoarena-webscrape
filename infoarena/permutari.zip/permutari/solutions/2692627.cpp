#include<fstream>
#include<vector>
#include<algorithm>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int sol[9], fol[9];
int n;
void tipar()
{
	for (int i = 1; i <= n; i++)
		fout << sol[i] << " ";
	fout << '\n';
}
void back(int k)
{
	if (k == n + 1)
		tipar();
	else
		for (int i = 1; i <= n; i++)
			if (fol[i] == 0)
			{
				sol[k] = i;
				fol[i] = 1;
				back(k + 1);
				fol[i] = 0;
			}
}

int main()
{
	fin >> n;
	back(1);
}