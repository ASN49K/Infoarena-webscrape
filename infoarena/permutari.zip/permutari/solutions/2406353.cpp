#include <fstream>
using namespace std;
ifstream cin("permutari.in");
ofstream cout("permutari.out");
int n,k1,s[100],f1[10];
void f(int k)
{
    if (k==n+1)
    {
        for (int i=1; i<=n; ++i)
            cout<<s[i]<<" ";
        cout<<"\n";
        return;
    }
    for (int i=1; i<=n; ++i)
    {
        if (i!=s[k-1] && !f1[i])
        {
            s[k]=i;
            f1[i]=1;
            f(k+1);
            f1[i]=0;
        }
    }
}
int main()
{
    cin>>n;
    f(1);
}
