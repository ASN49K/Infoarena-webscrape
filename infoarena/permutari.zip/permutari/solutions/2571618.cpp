
#include <bits/stdc++.h>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int n,x[10],ok[10];
void bkt(int k)
{
    if(k==n+1)
    {
        for(int i=1;i<=n;i++) g<<x[i]<<" ";
        g<<'\n';
        return;
    }
    for(int i=1;i<=n;i++)
    {
        if(ok[i]==0)
        {
            ok[i]=1;
            x[k]=i;
            bkt(k+1);
            ok[i]=0;
        }
    }
}
int main()
{

    f>>n;
    bkt(1);
}


