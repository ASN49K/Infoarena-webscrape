#include <iostream>
#include <fstream>
std::ifstream in("permutari.in");
std::ofstream out("permutari.out");

using namespace std;
int n;
int sol[10];
bool viz[10];

void afis()
{
    for(int i = 1; i<=n; i++)
        out<<sol[i]<<" ";
    out<<'\n';
}

void backt(int t)
{
    if(t == n + 1)
    {
        afis();
    }
    else
    {
        for(int i = 1; i<=n ; i++)
        {
            if(viz[i] == 0)
            {
                viz[i] = 1;
                sol[t] = i;
                backt(t+1);
                viz[i] = 0;
            }
        }
    }
}
int main()
{
    in>>n;
    backt(1);
    return 0;
}
