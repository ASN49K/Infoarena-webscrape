#include <iostream>
#include <fstream>

using namespace std;

ifstream f ("permutari.in");
ofstream g ("permutari.out");

int n, sol[9];

void Print()
{
    for (int i = 1; i <= n; i++)
    {
        g << sol[i] << " ";
    }
    g << "\n";
}

bool Ok(int k)
{
    for (int i = 1; i < k; i++)
    {
        if (sol[i] == sol[k])
        {
            return false;
        }
    }
    return true;
}

void Back(int k)
{
    for (int i = 1; i <= n; i++)
    {
        sol[k] = i;
        if (Ok(k) == true)
        {
            if (k == n)
            {
                Print();
            }
            else
            {
                Back(k + 1);
            }
        }
    }
}

int main()
{
    f >> n;
    Back(1);
}
