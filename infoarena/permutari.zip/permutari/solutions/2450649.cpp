
 #include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll const mod=1000000007;
ll const md=998244353;
ll mypowr(ll a,ll b) {ll res=1;a%=mod; assert(b>=0);
for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
ll mypow(ll a,ll b) {ll res=1;assert(b>=0);
for(;b;b>>=1){if(b&1)res=res*a;a=a*a;}return res;}
ifstream in("permutari.in");
ofstream out("permutari.out");
#define mp make_pair
#define pb push_back
#define pf push_front
#define fi first
#define se second

ll n;
int vec[15];

void build(ll x){
if(x==n+1){
    for(int i=1;i<=n;++i){
        out<<vec[i]<<" ";
    }
    out<<'\n';
    return;
}
for(int i=1;i<=n;++i){
    int ok=1;
    for(int j=1;j<x;++j){
        if(vec[j]==i)ok=0;
    }
    if(ok){
        vec[x]=i;
        build(x+1);
    }
}

}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    cout<<fixed<<setprecision(15);


    in>>n;
    build(1);





    return 0;
}
