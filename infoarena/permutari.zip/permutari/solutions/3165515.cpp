#include <iostream>
#include <fstream>
using namespace std;

ifstream f ("permutari.in");
ofstream g ("permutari.out");

const int NMAX = 8;
int n, x[NMAX+1];

bool valid(int k) {
    for (int i=1; i<k; i++)
        if (x[i] == x[k])
            return 0;
    return 1;
}

void afis() {
    for (int i=1; i<=n; i++)
        g << x[i] << ' ';
    g << '\n';
}

void backTracking(int k) {
    if (k <= n) {
        for(x[k]=1; x[k] <= n; x[k]++)
            if (valid(k))
                backTracking(k+1);
    } else
        afis();
}

int main()
{
    f >> n;
    backTracking(1);
    return 0;
}
