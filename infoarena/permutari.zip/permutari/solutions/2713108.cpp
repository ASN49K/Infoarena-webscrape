
#include <bits/stdc++.h>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n,v[10];

void afisare(int v[],int n)
{
    for (int i=1;i<=n;i++)
        g<<v[i]<<" ";
    g<<'\n';
}

void permutari(int v[],int n)
{
    do{
        afisare(v,n);
    } while (next_permutation(v+1,v+n+1));
}

int main()
{
    f>>n;
    for (int i=1;i<=n;i++)
        v[i]=i;
    permutari(v,n);
    return 0;
}
