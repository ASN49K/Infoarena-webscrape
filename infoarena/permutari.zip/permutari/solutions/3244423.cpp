#include <bits/stdc++.h>

using namespace std;

int v[10],fr[10],n;
ofstream *file;

void backtraking(int x)
{
    if(x == n+1)
    {
        for(int i=1; i<=n; ++i) *file<<v[i]<<' ';
        *file<<'\n';
    }
    else
    {
        for(int i=1; i<=n; ++i)
        {
            if(!fr[i])
            {
                fr[i] = 1;
                v[x] = i;
                backtraking(x+1);
                fr[i] = 0;
            }
        }
    }
}

int main()
{
    ifstream fin ("permutari.in");
    ofstream fout ("permutari.out");
    ios::sync_with_stdio(false); fin.tie(0); fout.tie(0);
    fin>>n;
    file = &fout;
    backtraking(1);
    return 0;
}
