#include <fstream>
#define NMAX 10
using namespace std;
ifstream  fin("permutari.in");
ofstream fout("permutari.out");
int N,v[NMAX],uz[NMAX];

void afisare()
{
    for(int i=1; i<=N; i++)
    {
        fout<< v[i] << " ";
    }
    fout<< "\n";
}

void BACK(int k)
{
    for(int i=1; i<=N; i++)
    {
        if(!uz[i])
        {
            v[k]=i;
            uz[i]=1;

            if(k==N)
            {
                afisare();
            }
            else
            {
                BACK(k+1);
            }
            uz[i]=0;
        }
    }
}

int main()
{
    fin>>N;

    BACK(1);

    return 0;
}
