#include <bits/stdc++.h>

using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");

int n, k, i, s[10], uz[10];

void afisare(int n)
{
    for ( int i = 1 ; i <= n ; i ++ )
        g << s[i]<<" " ;
    g << '\n' ;
}

void bkt(int k)
{
    if( k == n + 1)
        afisare(n);
    else
    {
        for( int i = 1 ; i <= n ; i ++ )
            if ( uz[i] == 0)
        {

            s[k]=i;
            uz[i]=1;
            bkt(k+1);
            uz[i]=0;
        }
    }
}
int main()
{
    f >> n;
    bkt(1);
    return 0;
}
