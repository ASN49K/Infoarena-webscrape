#include <fstream>

using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n,v[10];
bool valid(int k)
{
    if (k>n)
        return false;
    for (int i=1; i<k; i++)
        if (v[i]==v[k])
            return false;
    return true;
}
bool verif(int k)
{
    if (k==n)
        return true;
    return false;
}
void tipar(int k)
{
    for (int i=1; i<=k; i++)
        fout<<v[i]<<' ';
    fout<<'\n';

}
void bkt(int k)
{
    for (int i=1; i<=n; i++)
    {
        v[k]=i;
        if (valid(k))
        {
            if(verif(k))
                tipar( k);
            else
                bkt(k+1);
        }
    }
}



int main()
{
    fin>>n;
    bkt(1);


    return 0;
}
