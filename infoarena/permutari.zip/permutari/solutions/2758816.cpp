#include <fstream>
#include <vector>
#include <stack>
#include <algorithm>


using namespace std;

int main()
{
    ifstream cin("permutari.in");
    ofstream cout("permutari.out");
         

    int N;
    cin >> N;

    vector<bool> visited(N + 1, false);
    vector<int> back;

    back.push_back(0);
    while(!back.empty()){
        
        bool succ, ev;
        do{
            
            if(back[back.size() - 1] < N){
                succ = true;
                ++back[back.size() - 1];
            }
            else succ = false;
            if(succ){
                if(!visited[back[back.size() - 1]]){
                    ev = true;
                    visited[back[back.size() - 1]] = true;
                }
                else ev = false;
            }

        }while(succ && !ev);

        if(succ){
            if(back.size() < N){
                back.push_back(0);
            }
            else{
                for(int i = 0; i < N; ++i)
                    cout << back[i] << " ";
                cout << "\n";
                visited[back[back.size() - 1]] = false;
            }
        }
        else{
            back.pop_back();
            if(!back.empty())
                visited[back[back.size() - 1]] = false;
        }

    }
  
    cin.close();
    cout.close();

    return 0;
}