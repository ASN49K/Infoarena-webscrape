#include <bits/stdc++.h>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");

void permutari(vector<long>& arr, size_t size, size_t permCtr) {
    if (permCtr == size) {
        for (size_t j = 0; j < size; ++j)
            fout << arr[j] << ' ';
        fout << '\n';
    }
    else {
        for (size_t j = permCtr; j < size; ++j) {
            swap(arr[permCtr], arr[j]);
            permutari(arr, size, permCtr + 1);
            swap(arr[j], arr[permCtr]);
        }
    }
}

void solve() {
    int nrPerm;
    fin >> nrPerm;
    vector<long> ans(8);
    for (int i = 0; i < nrPerm; ++i)  ans[i] = i + 1;
    permutari(ans, nrPerm, 0);
}

int main() {
    ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);

    int t = 1;  //cin >> t;
    while (t--)
    {
        solve();
    }

    return 0;
}