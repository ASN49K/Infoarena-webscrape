#include <bits/stdc++.h>

using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int x[11],p[11],n,k;
void afisare(){
    for(int i=1;i<=n;++i)
        fout<<x[i]<<" ";
    fout<<'\n';
}
void bk(int k){
    for(int i=1;i<=n;++i)
        if(!p[i]){
            p[i]=1;
            x[k]=i;
            if(k==n) afisare();
            else bk(k+1);
            p[i]=0;
        }
}
int main()
{
    fin>>n;
    bk(1);
    return 0;
}
