// https://www.pbinfo.ro/probleme/123/permutari
// https://infoarena.ro/problema/permutari
#include <fstream>
#include <string.h>
using namespace std;
ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

int n,x[9];
bool t[10]={};

bool verif(int poz)
{
    bool t[10]={};
    for(int i=0;i<=poz;i++)
    {
        if(t[x[i]]!=0)
            return 0;
        t[x[i]]=1;
    }
    return 1;
}

void backtracking(int poz)
{
    int i;
    if(poz == n)
    {
        for(i=0;i<n;i++)
            fout<<x[i]<<' ';
        fout<<endl;

    }else{
        for(i=1;i<=n;i++)
        {
            x[poz] = i;
            if(t[i]==0)
            {
                t[i]=1;
                backtracking(poz+1);
                t[i]=0;
            }

        }
    }
}

int main()
{
    fin>>n;

    backtracking(0);

    return 0;
}
