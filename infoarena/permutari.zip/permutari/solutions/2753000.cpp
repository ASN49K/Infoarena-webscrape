#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int N, fol[10], v[10];

void gen(int lg) {
    if (lg == N + 1) {
        for (int i = 1; i <= N; ++i) {
            fout << v[i] << " ";
        }
        fout << "\n";
        return;
    }
    for (int i = 1; i <= N; ++i) {
        if (fol[i] == 0) {
            v[lg] = i;
            fol[i] = 1;
            gen(lg + 1);
            fol[i] = 0;
        }
    }
}

int main() {
    fin >> N;
    gen(1);
    return 0;
}
