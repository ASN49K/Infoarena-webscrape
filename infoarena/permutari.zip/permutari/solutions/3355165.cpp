#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <algorithm>
#include <queue>
#include <stack>
#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
vector<int> sol;
vector<int> visited;
int n;
void back(int u) {
    if(u == n + 1) {
        for(int i = 1; i <= n; i++) {
            fout<<sol[i]<<" ";
        }
        fout<<"\n";
        return;
    }
    for(int i = 1; i <= n; i++) {
        if(visited[i] == 0) {
            sol[u] = i;
            visited[i] = 1;
            back(u + 1);
            visited[i] = 0;
        }
    }

}

int main() {
    fin>>n;
    sol.assign(n + 1, 0);
    visited.assign(n + 1, 0);
    back(1);
    return 0;
}