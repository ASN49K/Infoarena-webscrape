#include <fstream>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n, v[10], rez[10], k = 1;

void back(int);
void print();

int main() {

	f >> n;
	back(1);

	return 0;
}

void back(int k) {
	for (int i = 1; i <= n; i++) {
		if (!v[i] && k <= n) {
			rez[k] = i;
			v[i] = 1;
			back(k + 1);
			v[i] = 0;
		}
	}
	if (k == n) print();
}

void print() {
	for (int i = 1; i <= n; i++) g << rez[i] << ' ';
	g << '\n';
}