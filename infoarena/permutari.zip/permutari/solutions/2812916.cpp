#include <fstream>
using namespace std;

ifstream cin ("permutari.in");
ofstream f("permutari.out");

bool p[45000];
int x[45000];
int n;

void afisare(){
    for (int i = 1;i <= n;++i)
        f << x[i] << " ";
        f << '\n';
}
void back(int k){
    for (int i =1; i <=n;++i)
        if (!p[i]){
            x[k] = i;
            p[i] = 1;
            if (k < n)
                back(k+1);
            else
                afisare();
            p[i] = 0;
        }
}

int main(){
    cin >> n;
    back(1);
}
