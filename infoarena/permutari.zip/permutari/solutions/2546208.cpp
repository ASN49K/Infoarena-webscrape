#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

vector<int> a;
int n;

int main()
{
    int i;
    fin >> n;
    for(i = 1;i <= n;i++)
        a.push_back(i);
    do
    {
        for(auto x : a)
            fout << x << " ";
        fout << "\n";
    }
    while(next_permutation(a.begin(),a.end()));
    return 0;
}
