//
// Created by borce on 5/21/2026.
//

#include <iostream>
#include<fstream>
#include<queue>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n;
int frecv[9];
int stiva[9];
void backtrack(int pas) {
    pas++;
    if (pas > n) {
        fout<<"\n";
        for (int i = 1; i <= n; i++)
            fout << stiva[i] << " ";
        fout << "\n";
    }
    else {
        for (int i = 1; i <= n; i++) {
            if (frecv[i] == 0) {
                frecv[i] = 1;
                stiva[pas] = i;
                backtrack(pas);
                frecv[i] = 0;
            }
        }
    }

}
int main() {
    fin>>n;
    backtrack(0);

}