#include <map>
#include <set>
#include <list>
#include <cmath>
#include <ctime>
#include <deque>
#include <queue>
#include <stack>
#include <string>
#include <bitset>
#include <cstdio>
#include <limits>
#include <vector>
#include <climits>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <numeric>
#include <sstream>
#include <iostream>
#include <algorithm>
#include <unordered_map>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");


int N;
vector<int>curr;
vector<int>viz;


void back(int k) {
    // afisam permutarea daca am completat cele N pozitii
    if (k == N) {
        for (int i = 0; i < N; i++)
            out << curr[i] << " ";
        out << "\n";
        return;
    }

    for (int i = 1; i <= N; i++) {
        if (!viz[i]) {
            curr[k] = i;
            viz[i] = true;  // Am folosit numarul i, nu il mai folosim
            back(k + 1);
            viz[i] = false;
        }
    }
}


int main() {
    /* Enter your code here. Read input from STDIN. Print output to STDOUT */
    ios::sync_with_stdio(false);
    in >> N;

    curr.resize(N);
    viz.resize(N + 1, false);

    back(0);

    in.close();
    out.close();
    return 0;
}