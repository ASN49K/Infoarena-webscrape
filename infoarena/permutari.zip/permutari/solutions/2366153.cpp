#include <bits/stdc++.h>

using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");

void printArr(int arr[], int n)
{
    for(int i = 0; i < n; ++i)
        fout << arr[i] << ' ';
    fout << '\n';
}

void permutations(int str[], int i, int n)
{
    if(i == n - 1)
    {
        printArr(str, n);
        return;
    }
    for(int j = i; j < n; j++)
    {
        swap(str[i], str[j]);

        permutations(str, i + 1, n);

        swap(str[i], str[j]);
    }
}

int main()
{
    int a[10];
    int n;
    fin >> n;

    for(int i = 0; i < n; ++i)
        a[i] = i + 1;

    permutations(a, 0, n);
}
