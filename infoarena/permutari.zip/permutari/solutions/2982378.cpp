#include <bits/stdc++.h>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int s[10],n;
int ddaeng()
{
    for(int i=1;i<=n;i++)
        g<<s[i]<<" ";
    g<<'\n';
}
void ugh(int k)
{
    if(k>n)
        ddaeng();
    else
    {
        for(int i=1;i<=n;i++)
        {
            s[k]=i;
            int ok=1;
            for(int j=1;j<k;j++)
            {
                if(s[j]==s[k])
                {
                    ok=0;
                    break;
                }
            }
            if(ok==1)
                ugh(k+1);
        }
    }
}
int main()
{
    f>>n;
    ugh(1);
    return 0;
}
