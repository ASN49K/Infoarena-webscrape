#include <bits/stdc++.h>

using namespace std;

ifstream f ("permutari.in");
ofstream g ("permutari.out");

short n;
short a[10];
bool used[10];

void bkt(short k)
{
    if(k == n + 1)
    {
        for(short i = 1 ; i <= n ; i++)
            g << a[i] << ' ';

        g << '\n';
    }
    else
    {
        for(short i = 1 ; i <= n ; i++)
        {
            if(!used[i])
            {
                a[k] = i;
                used[i] = 1;

                bkt(k + 1);
                used[i] = 0;
            }
        }
    }
}

int main()
{
    f >> n;
    bkt(1);

    return 0;
}
