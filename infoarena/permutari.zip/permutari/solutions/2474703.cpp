#include <bits/stdc++.h>
using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");
int v[9],n;
void afis()
{
    int i;
    for(i=1; i<=n; i++)
        out<<v[i]<<' ';
    out<<'\n';
}
bool verif(int k)
{
    int i;
    for(i=1; i<=k-1; i++)
        if(v[i]==v[k])
            return 0;
    return 1;
}
void backt(int poz)
{
    int i;
    for(i=1; i<=n; i++)
    {
        v[poz]=i;
        if(verif(poz))
            if(poz==n)
                afis();
            else
                backt(poz+1);
    }
}
int main()
{
    in>>n;
    backt(1);
    return 0;
}
