#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, v[15], f[15];

void afis()
{
    for(int i = 1; i <= n; i++)
        fout << v[i] << ' ';
    fout << '\n';
}

void backt(int k)
{
    for(int i = 1; i <= n; i++)
    {
        if(f[i] == 0)
        {
            v[k] = i;
            f[i] = 1;
            if(k == n)
                afis();
            else
                backt(k + 1);
            f[i] = 0;
        }
    }
}

int main()
{
    fin >> n;
    backt(1);
}








