#include <fstream>

using namespace std;
ifstream cin ("permutari.in");
ofstream cout ("permutari.out");
int n, use[10], sol[10];
void afisare()
{
    for(int i=1; i<=n; i++)
        cout << sol[i] << ' ';
    cout << endl;
}
void perm(int k)
{
    int i, j;
    if (k==n+1)
        afisare();
    else
    {
        for(i=1; i<=n; i++)
            if(use[i]==0)
            {
                use[i]=1;
                sol[k]=i;
                perm(k+1);
                use[i]=0;
            }
    }
}
int main()
{
    cin >> n;
    perm(1);
    return 0;
}
