#include <bits/stdc++.h>
#define ll long long
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n, v[10], freq[10];

void permute(int size) {
    if (size == n + 1) {
        for (int i = 1; i < size; i++)
            fout << v[i] << " ";
        fout << "\n";

        return;
    }

    for (int i = 1; i <= n; i++)
        if (!freq[i]) {
            freq[i] = 1;
            v[size] = i;
            permute(size + 1);
            freq[i] = 0;
        }
}

int main() {
    fin >> n;
    permute(1);

    return 0;
}
