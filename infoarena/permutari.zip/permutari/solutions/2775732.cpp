#include <iostream>
#include <fstream>

using namespace std;

void next_perm_manual(int n, int p[])
{
    int i, j, k, min;

    for(k = n - 1; k > 0; k--)
        if (p[k] < p[k + 1])
            break;

    min = p[k + 1], j = k + 1;
    for (i = k + 1; i <= n; i++)
        if (p[i] < min && p[i] > p[k])
            min = p[i], j = i;

    swap(p[k], p[j]);

    i = k + 1, j = n;
    while (i < j) {
        swap(p[i], p[j]);
        i++, j--;
    }
}

int main(void)
{
    int n, i, j;
    int p[] = {0, 1, 2, 3, 4, 5, 6, 7, 8};
    long long int f = 1;

    ifstream fin("permutari.in");
    ofstream fout("permutari.out");

    fin >> n;

    for(i = 1; i <= n; i++)
        f *= i;

    for(i = 0; i < f; i++) {
        for( j = 1; j <= n; j++)
            fout << p[j] << " ";
        next_perm_manual(n, p);
        fout << '\n';
    }

    return 0;
}
