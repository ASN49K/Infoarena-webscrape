/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>

using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int main()
{
    
    int n;
    fin>>n;
    vector<int> v(n);
    for(int i = 0; i < n; i++)
    {
        v[i] = i + 1;
    }
    do 
    {
       for(int elem : v)
       {
           fout<< elem <<' ';
       }
       
       fout<<'\n';
       
    }while(next_permutation(v.begin(), v.end()));///returneaza false in momentul in care nu a gasit o permutare mai mare lexicografic

    /// permutari cu n elem
    /// prima pozitie poate fi umpluta in n moduri
    /// a doua pozitie are la dispozitie doar n - 1 elemente
    /// a treia pozitie n - 2  
    /// n!
    return 0;
}