#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, a[9], fr[9];

void permutare(int lg) {
    if (lg == n + 1) {
        for (int i = 1; i < lg; i++)
            fout << a[i] << " ";
        fout << "\n";
        return;
    }
    for (int i = 1; i <= n; i++)
        if (!fr[i]) {
            fr[i] = 1;
            a[lg] = i;
            permutare(lg + 1);
            fr[i] = 0;
        }
}
int main() {
    fin >> n;
    permutare(1);
}