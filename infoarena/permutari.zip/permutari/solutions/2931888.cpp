#include <bits/stdc++.h>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

void generate(uint n) {
	vector<uint> st(n);

	function<void(uint)> __generate = [&](uint k) {
		if (k == n) {
			for (int x : st)
				fout << x << ' ';
			fout << '\n';
			return;
		}

		for (uint i = 1; i <= n; ++i) {
			bool ok = 1;
			for (uint j = 0; j < k && ok; ++j)
				if (st[j] == i)
					ok = 0;

			if (ok) {
				st[k] = i;
				__generate(k + 1);
			}
		}
	};

	__generate(0);
}

int main() {
	

	uint n;
	fin >> n;

	generate(n);
}