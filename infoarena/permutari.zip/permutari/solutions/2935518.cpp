#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n;
vector <int> v;
bool frv[9];

void Print() {
    for (int num : v) {
        fout << num << ' ';
    }
    fout << '\n';
}

void BKT() {
    if (v.size() == n) {
        Print();
        return;
    }

    for (int i = 1; i <= n; i++) {
        if (frv[i]) {
            continue;
        }
        v.push_back(i);
        frv[i] = true;
        BKT();
        v.pop_back();
        frv[i] = false;
    }
}

int main() {
    fin >> n;
    BKT();
}