#include <bits/stdc++.h>
using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");
vector<int> v;
int n;
int main()
{
    in>>n;
    for(int i=1;i<=n;++i)
        v.push_back(i);
    do
    {
        for(int x:v)
            out<<x<<' ';
        out<<'\n';
    }while(next_permutation(v.begin(),v.end()));
    return 0;
}
