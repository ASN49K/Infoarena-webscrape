#import<bits/stdc++.h>
main(){int n,v[]={1,2,3,4,5,6,7,8};std::ifstream("permutari.in")>>n;std::ofstream g("permutari.out");do for(int i=0;i<n;++i) g<<v[i]<<' ';while(g<<'\n',std::next_permutation(v,v+n));}
