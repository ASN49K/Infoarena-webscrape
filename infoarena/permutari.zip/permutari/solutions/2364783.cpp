# depslib dependency file v1.0
1551689348 source:c:\users\acer\oji\pregatire de olimpiada\main.cpp
	<fstream>

