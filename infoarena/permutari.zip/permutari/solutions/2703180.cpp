#include <iostream>
#include <fstream>
using namespace std;

ifstream in ("permutari.in");
ofstream out ("permutari.out");

int n;
int st[15];
bool v[15];

void Back(int top)
{
    if(top==n+1)
    {
        for(int i=1;i<=n;i++)
            out<<st[i]<<" ";
        out<<'\n';
        return;
    }
    for(int i=1;i<=n;i++)
    {
        if(!v[i]){
            st[top]=i;
            v[i]=true;
            Back(top+1);
            v[i]=false;
        }
    }
}

int main()
{
    in>>n;
    Back(1);
    return 0;
}
