#include <bits/stdc++.h>
using namespace std;

void permuRecu(vector<vector<int>>& res, vector<int> arr, int idx) {
	// dc idx aj la dimens arr adaug permut la rez
	if (idx == arr.size()) {
        res.push_back(arr);
        return;
    }

	// permutam cu swapuri
	for (int i = idx; i < arr.size(); i++) {
		swap(arr[idx], arr[i]);
		// apel recursiv pt a crea permutari pt elem urmator
		permuRecu(res, arr, idx + 1);
		// backtracking
		swap(arr[idx], arr[i]);
	}

}

vector<vector<int>> permutari(vector<int>& arr) {
	vector<vector<int>> res;
	permuRecu(res, arr, 0);
	return res;
}

int main() {
	freopen("permutari.in", "r", stdin);
	freopen("permutari.out", "w", stdout);
	int n;
	cin >> n;
	vector<int> arr(n);
	int k = 0;
	for(int i = 1; i <= n; i++) {
		arr[k++] = i;
	}
	vector<vector<int>> res = permutari(arr);

	sort(res.begin(), res.end());

	for (vector<int> it : res) {
		for(int i = 0; i < it.size(); i++) {
			cout << it[i] << " ";
		}
		cout << endl;
	}
}