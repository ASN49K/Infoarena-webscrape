#include <fstream>

using namespace std;

ifstream fin  ("permutari.in");
ofstream fout ("permutari.out");

int n, x[10];

inline bool isOk (int k){
    int i;
    for (i=1; i<k; i++){
        if (x[k] == x[i])
            return false;
    }
    return true;
}

inline void print (){
    int i;
    for (i=1; i<=n; i++){
        fout << x[i] << " ";
    }
    fout << "\n";
}

inline void bkt (int k){
    int i;
    for (i=1; i<=n; i++){
        x[k] = i;
        if (isOk (k)){
            if (k == n){
                print();
            }
            else{
                bkt(k+1);
            }
        }
    }
}

int main(){
    fin >> n;
    bkt(1);
    return 0;
}
//recapitulare
