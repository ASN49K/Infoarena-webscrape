#include <iostream>
#include <fstream>


using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");
int n,x[100],nr;

bool verifcc(int k)
{
    for (int i=0;i<k;i++)
        if (x[i]==x[k])
        return false;
    return true;
}


void bkt(int k)
{
    int i;
    for (i=1;i<=n;i++)
    {
        x[k]=i;
        if (verifcc(k))
            if (k==n-1)
        {  nr++;
           for (int d=0;d<=k;d++)
            g<<x[d]<<" ";
           g<<endl;
        }
        else bkt(k+1);
    }
}

int main()
{
 f>>n;
 bkt (0);


}
