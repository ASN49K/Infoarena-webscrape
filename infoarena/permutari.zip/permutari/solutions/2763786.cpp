#include <fstream>
 
using namespace std;
 
ifstream fin("permutari.in");
ofstream fout("permutari.out");
 
int n, p[10], x[10];

void afisare() {
    for(int i = 1; i <= n; i++) {
        fout << x[i] << " ";
    }
    fout << "\n";
}

void back(int k) {
    for(int i = 1; i <= n; i++) {
        if(!p[i]) {
            p[i] = 1;
            x[k] = i;
            if(k < n) {
                back(k + 1);
            } else {
                afisare();
            }
            p[i] = 0;
        }
    }
}
 
int main() {
    fin >> n;
    fin.close();
    back(1);
    fout.close();
    return 0;
}