#include <bits/stdc++.h>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

vector<int> v;
bool valid(int k)
{
    for(int i=0; i<k; i++)
        if(v[i]==v[k])
            return 0;
    return 1;
}
void perm(int n)
{
    int k;
    v.resize(n);
    k=0;
    v[k]=1;
    while(k>=0)
    {
        while(v[k]<=n)
        {
            if(valid(k))
                if(k==n-1)
                {
                    for(auto a:v)
                        g<<a<<' ';
                    g<<"\n";
                }
                else
                {
                    k++;
                    v[k]=0;
                }
            v[k]++;
        }
        k--;
        v[k]++;
    }
}
int main()
{
    int n;
    f>>n;
    perm(n);
    f.close();
    g.close();
    return 0;
}
