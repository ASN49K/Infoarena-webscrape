#include <bits/stdc++.h>

using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n;
int v[11];
int verificare(int cnt)
{
    for (int i=1;i<cnt;i++)
    {
        if (v[i]==v[cnt])
            return 0;
    }
    return 1;
}
int backt(int cnt)
{
    for (int i=1;i<=n;i++)
    {
        v[cnt]=i;
        if (verificare(cnt))
        {
            if (cnt==n)
            {
                for (int i=1;i<=n;i++)
                    fout<<v[i]<<" ";
                fout<<'\n';
            }
            else backt(cnt+1);
        }
    }
}
int main()
{
    fin>>n;
    backt(1);
    return 0;
}
