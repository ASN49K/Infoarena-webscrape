#include <iostream>
#include <fstream>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n,pos,v[10],ap[10];

void afis(){
    for(int i=1;i<=n;i++)
        g<<v[i]<<" ";
    g<<'\n';
}

void backt(int pos){
    if(pos<=n){
        for(int i=1;i<=n;i++){
            if(!ap[i]){
                v[pos]=i;
                ap[i]=1;
                if(pos==n)afis();
                else backt(pos+1);
                ap[i]=0;
            }
        }
    }
}

int main()
{
    f>>n;
    backt(1);
    return 0;
}
