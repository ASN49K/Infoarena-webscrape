#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, p[20], fr[20];

void permutari(int length) {
	if (length == n + 1) {
		for (int i = 1; i <= n; ++i) {
			fout << p[i] << " ";
		}
		fout << '\n';
		return;
	}
	for (int i = 1; i <= n; ++i) {
		if (fr[i] == 0) {
			p[length] = i;
			fr[i] = 1;
			permutari(length + 1);
			fr[i] = 0;
		}
	}
}

int main() {
	fin >> n;
	permutari(1);
	return 0;
}
