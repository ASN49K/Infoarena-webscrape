#include <bits/stdc++.h>

using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");
void perm(vector<int>v,vector<int>outp,int n,int poz,int prev)
{
    v[prev]=1;
    outp.push_back(prev);
    for(int i=1;i<=n;i++)
    {
        if(v[i]==0)
        {
            if(poz+1==n)
            {
                for(int j=1;j<n;j++)
                {
                    out<<outp[j]<<" ";
                }
                out<<i<<'\n';
                continue;
            }
            perm(v,outp,n,poz+1,i);
        }
    }
}
int main()
{
int n;
in>>n;
vector<int>v(n+1);
vector<int>p;
perm(v,p,n,0,0);
    return 0;
}
