#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("permutari.in");
ofstream fout ("permutari.out");

const int NMAX=9;
int viz[NMAX];
int v[NMAX];
int n;

void backt(int k)
{
    int i;
    if(k==n+1)
    {
        for(i=1;i<=n;i++)
            fout<<v[i]<<" ";
        fout<<"\n";
    }
    else
    {
        for(i=1;i<=n;i++)
            if(viz[i]==0)
        {
            v[k]=i;
            viz[i]=1;
            backt(k+1);
            viz[i]=0;
        }
    }
}

int main()
{
    int i;
    fin>>n;
    backt(1);
    return 0;
}
