#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int v[10];
int n;
int ok(int k)
{
    for(int i=1;i<k;i++)
    {
        if(v[k]==v[i])
        {
            return false;
        }
    }
    return true;
}
void afisare()
{
    for(int i=1;i<=n;i++)
    {
        fout<<v[i]<<" ";
    }
    fout<<'\n';
}
void f(int k)
{
    for(int i=1;i<=n;i++)
    {
        v[k]=i;
        if(ok(k)==true)
        {
            if(k==n)
            {
                afisare();
            }
            else
            {
                f(k+1);
            }
        }
    }
}
int main ()
{
    fin>>n;
    f(1);
    fin.close();
    fout.close();
    return 0;
}
