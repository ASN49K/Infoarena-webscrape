#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n;
vector <int> v;

int main()
{
    fin >> n;

    for(int i = 1; i <= n; i++)
        v.push_back(i);

    do
    {
        for(int i = 0; i < n; i++)
            fout << v[i] << " ";
        fout << "\n";

    }
    while(next_permutation(v.begin(), v.end()));

    fin.close();
    fout.close();
    return 0;
}
