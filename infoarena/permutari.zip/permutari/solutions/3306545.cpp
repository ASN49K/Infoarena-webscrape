#include <iostream>
#include <queue>
#include <algorithm>
#include <set>
#include <map>
#include <stack>
#include <vector>
#include <string>
#include <deque>
#include <unordered_map>
#include <unordered_set>
#include <cmath>
#include <iomanip>

using namespace std;

#define ll long long

int n;

void ReadData() {
    cin >> n;
}

void dfs(int size, vector<int> toUse, vector<int> used){
    if (size == 0){
        for(int val: used)
            cout << val << " ";
        cout << "\n";
        return;
    }

    for (int i = 0; i < toUse.size(); i++) {
        int val = toUse[i];
        vector<int> newToUse = toUse;
        newToUse.erase(newToUse.begin() + i);
        
        vector<int> newUsed = used;
        newUsed.push_back(val);

        dfs(size - 1, newToUse, newUsed);
    }
}

void Solve() {
    vector<int> toUse;
    for (int i = 1; i <= n; i++){
        toUse.push_back(i);
    }

    
    dfs(n, toUse, {});
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);


    int t = 1;
    // cin >> t; // Uncomment for multiple test cases
    while (t--) {
        ReadData();
        Solve();   
    }
    return 0;
}