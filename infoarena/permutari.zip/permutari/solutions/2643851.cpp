#include <iostream>
#include <fstream>
using namespace std;

    ifstream fin ("permutari.in");
    ofstream fout ("permutari.out");

    int v[10];
    int frecventa [9];
    int n;
    void genereaza (int lungime ) {
        if (lungime == n) {
            for (int i=0;i<n;i++)
                fout<<v[i]<<" ";
                fout<<'\n';
        }
        for (int i=1;i<=n;i++) {
            if (frecventa[i]==0) {
                v[lungime]=i;
                frecventa[i]=1;
                genereaza (lungime+1);
                frecventa[i]=0;
            }


        }
    }
int main()
{
    fin>>n;
    genereaza (0);
    return 0;
}
