#include <bits/stdc++.h>
using namespace std;

int v[9], n;

int main(){
    ifstream cin("permutari.in");
    ofstream cout("permutari.out");

    cin >> n;
    for(int i = 1; i <= n; ++i)
        v[i] = i;

    do{
        for(int i = 1; i <= n; ++i)
            cout << v[i] << ' ';
        cout << '\n';
    }while(next_permutation(v + 1, v + n + 1));


    cin.close(), cout.close();
}
