#include <bits/stdc++.h>
#define NMAX 1009
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n;
int v[NMAX];
void gen(int k);
bool uz[NMAX];
void afis();

int main()
{
    fin>>n;
    gen(1);
    return 0;
}
void gen(int k)
{
  int i;
  if(k==n+1)
  {afis();return;}
  for(i=1;i<=n;i++)
  if(!uz[i])
  {
    v[k]=i;
    uz[i]=1;
    gen(k+1);
    uz[i]=0;
  }
}
void afis()
{
  int i;
  for(i=1;i<=n;i++)
        fout<< v[i]<<" ";
  fout<<'\n';
}
