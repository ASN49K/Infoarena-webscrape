#include <iostream>
#include<fstream>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n, sol[100];
bool c[100];

void bkt(int p)
{
    if(p-1 == n)
    {
        for(int i=1; i<=n; i++)
            g<<sol[i]<<" ";
        g<<"\n";
        return ;
    }

    for(int i=1; i<=n; i++)
    {
        if(!c[i])
        {
            sol[p] = i;
            c[i] = true;
            bkt(p+1);
            c[i] = false;
        }
    }

}

int main()
{
    f>>n;
    bkt(1);
    return 0;
}
