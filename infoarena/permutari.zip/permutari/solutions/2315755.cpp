#include <bits/stdc++.h>
#define MOD 1999999973

long long put( long long x, long long p ) {
    if ( p == 1 )
        return x;
    if ( p % 2 == 0 ) {
        return put( ( x * x ) % MOD, p / 2 );
    } else {
        return ( ( put( ( x * x ) % MOD, p / 2 ) ) * x ) % MOD;
    }
}

int main() {
    FILE *fin, *fout;
    long long x, p;
    fin = fopen( "lgput.in", "r" );
    fout = fopen( "lgput.out", "w" );
    fscanf( fin, "%lld%lld", &x, &p );
    fprintf( fout, "%lld", put( x, p ) );
    fclose( fin );
    fclose( fout );
    return 0;
}
