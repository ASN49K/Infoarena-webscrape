#include <iostream>
#include <fstream>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int k,s[10],n;
int valid(int k)
{
    int i;
    for(i=1; i<k; i++)
        if(s[i]==s[k])
            return 0;
    return 1;
}
void tipar(int k)
{
    int i;
    for(i=1; i<=k; i++)
        g<<s[i]<<" ";
    g<<'\n';
}
void back(int k)
{
    int i;
    for(i=1; i<=n; i++)
    {
        s[k]=i;
        if(valid(k))
            if(k==n)
                tipar(k);
            else
                back(k+1);
    }

}
int main()
{
    f>>n;
    back(1);
    return 0;
}
