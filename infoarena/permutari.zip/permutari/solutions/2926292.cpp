#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

vector<int>a;

int main()
{
    int n, i;
    fin >> n;
    for (i = 1; i <= n; i++)
        a.push_back(i);
    do
    {
        for(int e:a)
            fout << e << " ";
        fout << "\n";
    }
    while(next_permutation(a.begin(), a.end()));
    fout.close();
    return 0;
}
