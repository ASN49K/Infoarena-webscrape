#include <iostream>
#include <fstream>
using namespace std;
ifstream f("permutari.in");
ofstream o("permutari.out");

int sol[9], n;

void print()
{
    for (int i = 1; i <= n; i++)
        o << sol[i] << " ";
    o << "\n";
}

bool valid(int k)
{
    if (k == 1)
        return true;
    for (int i = 1; i < k; i++)
        if (sol[i] == sol[k])
            return false;
    return true;
}

void back(int k)
{

    if (k == n + 1)
        print();

    for (int i = 1; i <= n; i++)
    {
        sol[k] = i;
        if (valid(k))
            back(k + 1);
    }
}

int main()
{
    f >> n;
    back(1);
}