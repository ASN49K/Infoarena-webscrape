#include <bits/stdc++.h>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int n,i,j,v[10],k,pas,lg,fol[10];
void afis()
{
    for(int i=1;i<=n;i++)
        fout<<v[i]<<" ";
    fout<<'\n';
}
void bkt(int poz)
{
    if(poz==n+1)
    {
        afis();
        return;
    }
    for(int i=1;i<=n;i++)
        if(fol[i]==0)
        {
            fol[i]=1;
            v[poz]=i;
            bkt(poz+1);
            fol[i]=0;
        }
}
int main()
{
    fin>>n;
    bkt(1);
    return 0;
}
