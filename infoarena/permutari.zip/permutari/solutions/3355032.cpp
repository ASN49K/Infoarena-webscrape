#include <bits/stdc++.h>
using namespace std;
#define NMAX 8

int n;
int v[NMAX], f[NMAX];

ifstream fin("permutari.in");
ofstream fout("permutari.out");

void perm(int pos) {

    if (pos == n) {
        for (int i = 0; i < n - 1; ++i)
            fout << v[i] << ' ';
        fout << v[n-1] << '\n';
        return;
    }

    for (int i = 1; i <= n; ++i) {
        if (f[i] == 0) {
            v[pos] = i;
            f[i] = 1;
            perm(pos + 1);
            f[i] = 0;
        }
    }

    return;
}

int main() {

    fin>>n;
    perm(0);
    return 0;
}
