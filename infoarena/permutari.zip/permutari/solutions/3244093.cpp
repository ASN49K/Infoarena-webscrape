#include <iostream>
#include <fstream>
using namespace std;
ifstream f("permutari.in");
ofstream g("permutari.out");
int v[9],n;

bool valid(int k) {
    for(int i=1; i<=k-1; i++) {
        if(v[i]==v[k]) {
            return 0;
        }
    }
    return 1;
}

void tipar(int k) {
    for(int i=1; i<=k; i++) {
        g<<v[i]<<' ';
    }
    g<<"\n";
}

void bk() {
    int k;
    bool gasit=0;
    k=1;
    v[k]=0;
    while(k>0) {
        gasit=0;
        while(v[k]<n&&!gasit) {
            v[k]++;
            gasit=valid(k);
        }
        if(gasit) {
            if(k==n) {
                tipar(k);
            } else {
                k++;
                v[k]=0;
            }
        } else {
            k--;
        }
    }
}

int main() {
    f>>n;
    bk();
    f.close();
    g.close();
    return 0;
}
