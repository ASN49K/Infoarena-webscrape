#include <fstream>
using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int v[9], n;

void afisare() {
    for (int i = 0; i < n; i ++) {
        out << v[i] << ' ';
    }
    out << endl;
}

void bkt(int k) {
    if (k == n) {
        afisare();
    }

    for (int i = 1; i <= n; i ++) {
        bool verif = true;
        for (int j = 0; j < k && verif; j ++) {
            if (v[j] == i) {
                verif = false;
            }
        }

        if (verif) {
            v[k] = i;
            bkt(k + 1);
        }
    }
}

int main()
{
    in >> n;
    bkt(0);
    return 0;
}
