// C program to print all permutations with duplicates allowed 
#include <stdio.h> 
#include<stdlib.h>
#include <string.h> 
#define _CRT_SECURE_NO_WARNINGS

FILE *fs;

/* Function to swap values at two pointers */
void swap(char *x, char *y)
{
	char temp;
	temp = *x;
	*x = *y;
	*y = temp;
}

/* Function to print permutations of string
This function takes three parameters:
1. String
2. Starting index of the string
3. Ending index of the string. */
void permute(char *a, int l, int r)
{
	int i;
	if (l == r)
		//printf("%s\n", a);
		fprintf(fs, "%s \n",a);

	else
	{
		for (i = l; i <= r; i++)
		{
			swap((a + l), (a + i));
			permute(a, l + 1, r);
			swap((a + l), (a + i)); //backtrack 
		}
	}
}

/* Driver program to test above functions */
int main()
{
	FILE *fp;
	int n,i;
	fp = fopen("permutari.txt", "r+");
	fs = fopen("permutari.out", "w");
	if (fp == NULL)
	{
		printf("Eroare citire");
		exit(1);
	}
	
	fscanf(fp, "%d", &n);
	//printf("%d\n",n);


	char str[20]="",aux[20];
	

	for (i = 1; i <= n; i++){
		itoa(i, aux, 10);
		strcat(str, aux);
	}

		//printf("%s",str);
	    n = strlen(str);
	    permute(str, 0, n - 1);
	return 0;
}