#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

#define NMAX 15

int perm[NMAX];
bool uz[NMAX];

void afisare(int n) {
    for (int i = 1; i <= n; ++i) {
        fout << perm[i] << ' ';
    }
    fout << '\n';
}

void back(int k, int n) {
    for (int i = 1; i <= n; ++i) {
        if (!uz[i]) {
            uz[i] = 1;
            perm[k] = i;

            if (k == n) {
                afisare(n);
            } else {
                back(k + 1, n);
            }

            uz[i] = 0;
        }
    }
}

int main() {
    int n;
    fin >> n;

    back(1, n);
    return 0;
}
