#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
int main()
{
    int n;
    fin>>n;
    vector<int> a;
    for(int i = 1;i<=n;i++){
        a.push_back(i);
        fout<<i<<" ";
    }
    fout<<'\n';
    while(next_permutation(a.begin(),a.end()))
    {
        for(int i = 0;i<n;i++)
        {
            fout<<a[i]<<" ";
        }
        fout<<'\n';
    }
    return 0;
}
