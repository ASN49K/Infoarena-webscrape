#include <bits/stdc++.h>
#define MAXN 8
using namespace std;
ifstream fin( "permutari.in" );
ofstream fout( "permutari.out" );
int n , v[MAXN + 1] , f[MAXN + 1];
void afis() {
    int i;
    for( i = 1 ; i <= n ; i++ )
        fout << v[i] << ' ';
    fout << '\n';
}
void gen( int pos ) {
    int j;
    if( pos == n + 1 )
        afis();
    for( j = 1 ; j <= n ; j++ )
        if( !f[j] ) {
            f[j] = 1;
            v[pos] = j;
            gen( pos + 1 );
            f[j] = 0;
        }
 }
int main() {
    fin >> n;
    gen( 1 );
    return 0;
}
