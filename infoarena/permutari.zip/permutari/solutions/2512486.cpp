#include <fstream>
#include <algorithm>

using namespace std;

ifstream cin("permutari.in");
ofstream cout("permutari.out");

int n,a[9];

int fact(int n)
{
    int sol=1;
    for(int i=1;i<=n;i++)
        sol*=i;
    return sol;
}

int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)
        a[i]=i;

    for(int k=1;k<=fact(n);k++)
    {
        for(int i=1;i<=n;i++)
            cout<<a[i]<<' ';
        cout<<'\n';

        next_permutation(a+1,a+n+1);
    }

    return 0;
}
