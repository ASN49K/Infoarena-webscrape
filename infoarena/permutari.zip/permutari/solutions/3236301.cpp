#include <iostream>
#include <fstream>
using namespace std;
int N, a[100],k=0;
ifstream f("permutari.in");
    ofstream g("permutari.out");




void af(int n)
{
    for(k=0;k<N;k++)
    {
        g<<a[k]<<" ";
    }
    g<<endl;
}

bool valid(int n)
{
    for(k=0;k<n;k++)
    {   if(a[n]==a[k]) return false;
    }
   return true;
}


void backtrack(int n) {
    for (int i=1;i<= N;++i) {
        a[n]=i;
        if (valid(n)) {
            if (n==N-1) {
                af(n);
            }
            else
                backtrack(n+1);
        }
    }
}




int main()
{
    int n;
    f>>N;
    backtrack(0);
    f.close();
    g.close();
    return 0;
}
