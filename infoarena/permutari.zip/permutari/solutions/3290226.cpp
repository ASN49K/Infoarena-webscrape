#include <fstream>

using namespace std;

ifstream cin ("permutari.in");
ofstream cout ("permutari.out");

int n;
int v[10];

void afis (){
    for (int i = 1; i <= n; ++i)
        cout << v[i] << ' ';
    cout << '\n';
}

int ok (int k){
    for (int i = 1; i < k; ++i)
        if (v[i] == v[k]) return false;
    return true;
}

void backt (int k){
    for (int i = 1; i <= n; ++i){
        v[k] = i;
        if (ok(k)){
            if (k == n)
                afis();
            else
                backt(k + 1);
        }
    }
}

int main()
{
    cin >> n;
    backt(1);

    return 0;
}
