#include <fstream>
#include <iostream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n,x[10];
int verifca(int p);
void bkt(int);

int main()
{
    fin>>n;
    bkt(1);
    return 0;
}

int verifica(int p)
{
    int v[11]={0,0,0,0,0,0,0,0,0,0};
    for(int i=1;i<=p;i++)
        v[x[i]]++;

    for(int i=1;i<=8;i++)
        cout<<"i: "<<i<<"  "<<"v[i]: "<<v[i]<<endl;

    for(int i=1;i<=n;i++)
        if(v[i]!=1)
            return 0;
    if(p!=n)
        return 0;
    return 1;

}

void display(int p)
{
    for(int i=1;i<=p;i++)
        fout<<x[i]<<" ";
    fout<<'\n';
}

void bkt(int p)
{
    if(p>n)
        return;
    for(int i=1;i<=n;i++)
    {
        x[p]=i;
        if(verifica(n))
            display(n);
        else
            bkt(p+1);

    }
}