#include<fstream>
#include<iostream>
using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int n,a[10];
bool v[10];

void BK(int k)
{
	if (k == n + 1)
	{
		for (int i = 1; i <= n; ++i)
		{
			g << a[i] << ' ';
		}
		g << '\n';
		return;
	}
	for (int i = 1; i <= n; ++i)
	{
		if (!v[i])
		{
			v[i] = true;
			a[k] = i;
			BK(k + 1);
			v[i] = false;
		}
	}
}

int main()
{
	f >> n;
	BK(1);
}