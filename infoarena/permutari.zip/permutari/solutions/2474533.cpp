//#include <iostream>
#include <fstream>

using namespace std;

ifstream cin("permutari.in");
ofstream cout("permutari.out");

int n;
int v[9];
int ap[9];

void afis()
{
	for(int i=0; i<n; i++) cout<<v[i]<<" ";
	cout<<"\n";
}

void bkt(int poz)
{
	if(poz==n) afis();
	for(int i=1; i<=n; i++)
	{
		if(ap[i]==0)
		{
			ap[i]=1;
			v[poz]=i;
			bkt(poz+1);
			v[poz]=0;
			ap[i]=0;
		}
	}
}

int main() 
{
	cin>>n;
	bkt(0);
}