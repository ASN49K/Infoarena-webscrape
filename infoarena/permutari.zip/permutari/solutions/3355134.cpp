#include <vector>
#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int N;

vector<int> sol;
vector<bool> vizitat;

void bkt(int pas) {
    if(pas == N) {
        for(int i = 0; i < N; i++) {
             fout << sol[i] << " ";
        }
        fout << "\n";
        return;
    }

    for(int i = 1; i <= N; i++) {
        if(!vizitat[i]) {
            vizitat[i] = true;
            sol[pas] = i;
            bkt(pas + 1);
            vizitat[i] = false;
        }
    }
}

int main() {
    fin >> N;

    sol.resize(N);
    vizitat.assign(N + 1, false);

    bkt(0);

    fin.close();
    fout.close();
    return 0;
}