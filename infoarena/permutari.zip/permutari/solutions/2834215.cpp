#include <bits/stdc++.h>
using namespace std;

ifstream file_in("permutari.in");
ofstream file_out("permutari.out");

int N, slot[9];
bool used[9];

void show()
{
	for (int i = 1; i <= N; ++i)
		file_out << slot[i] << ' ';
	file_out << '\n';
}

void back_track(int K)
{
	for(int i = 1; i <= N; ++i)
		if (!used[i])
		{
			used[i] = true;
			slot[K] = i;

			if (K == N) show();
			else back_track(K + 1);

			used[i] = false;
		}

}

int main()
{
	file_in >> N;
	back_track(1);
	return 0;
}