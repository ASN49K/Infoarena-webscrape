#include <bits/stdc++.h>

using namespace std;

ifstream f("permutari.in");
ofstream g("permutari.out");

int main()
{
    int n;
    f >> n;
    vector<int> v(n);
    for (int i = 0; i < n; i++)
        v[i] = i + 1;

    do {
        for (int i = 0; i < n; i++)
            g << v[i] << " ";
        g << "\n";
    } while (next_permutation(v.begin(), v.end()));

    f.close();
    g.close();
    return 0;
}
