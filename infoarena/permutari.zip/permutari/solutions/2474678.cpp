#include <fstream>

using namespace std;

ifstream in("permutari.in");
ofstream out("permutari.out");

int sol[25],n,poz;

void afisare()
{
    for(int i=0; i<n; i++)
        out<<sol[i]<<" ";
    out<<'\n';
}

int validare(int poz)
{
    for(int i=0; i<poz; i++)
        for(int j=i+1; j<=poz; j++)
        {
            if(sol[i]==sol[j])
                return 0;
        }
    return 1;
}

void bkt(int poz)
{
    if(poz==n)
        afisare();
    else
    {
        for(int i=1; i<=n; i++)
        {
            sol[poz]=i;
            if(validare(poz))
                bkt(poz+1);
        }
    }
}

int main()
{
    in>>n;
    bkt(0);
    return 0;
}
