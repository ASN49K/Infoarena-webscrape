#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n, x[21], viz[21];

void afisare() {
    for (int i = 1; i <= n; i++)
        fout << x[i] << " ";
    fout << "\n";
}

void back(int k) {
    if (k > n)
        afisare();
    else {
        for (int i = 1; i <= n; i++)
            if (!viz[i]) {
                x[k] = i;
                viz[i] = 1;
                back(k + 1);
                viz[i] = 0;
            }
    }
}

int main()
{
    fin >> n;
    back(1);
    return 0;
}
