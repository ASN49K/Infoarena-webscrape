#include <iostream>
#define FIN "permutari.in"
#define FOUT "permutari.out"
#define SIZE 100

using namespace std;

int stack[SIZE],
    level,
    n;

void init() {

     stack[ level ] = 0;
}

int succ() {

    if(stack[level] < n) {

      stack[level]++;

      return 1;
    }
    return 0;
}

int valid() {

    for(int i = 1; i < level; ++i) {

        if( stack[ level ] == stack[ i ] ) return 0;
    }

    return 1;
}

int sol() {

    return level == n;
}

void display_solution() {

     for(int i = 1; i <= n; ++i) {

         cout<<stack[i]<<" ";
     }

     cout<<endl;
}


void backtracking() {

     int h, v;

     level = 1;

     init();

     while( level > 0 ) {

           h = 1; v = 0;

           while(h && !v) {
                h = succ();
                if(h) {
                  v = valid();
                }
           }

           if(h) {

              if(sol()) {
                display_solution();
              } else {
                level++;
                init();
              }

           } else {
               level--;
           }
     }
}

int main(int argc, char const *argv[]) {

  freopen(FIN, "r",stdin);
  freopen(FOUT, "w",stdout);

  cin>>n;
  backtracking();

  return 0;
}

/*
nivelul: 1
nivelu:  2
nivelul: 1
*/
