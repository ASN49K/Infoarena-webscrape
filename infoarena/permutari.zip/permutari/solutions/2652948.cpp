#include <fstream>
#include <vector>
#include <algorithm>
#include <numeric>

using namespace std;

int main(int argc, char const *argv[])
{
	ifstream fin("permutari.in");
	ofstream fout("permutari.out");

	int N;
	fin >> N;

	vector<int> perm(N);
	iota(perm.begin(), perm.end(), 1);

	do {
		for (auto v : perm)
			fout << v << " ";
		fout << "\n";
	} while (next_permutation(perm.begin(), perm.end()));

	return 0;
}