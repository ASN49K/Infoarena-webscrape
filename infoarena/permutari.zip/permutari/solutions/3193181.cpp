#include <bits/stdc++.h>

using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

#define N_MAX 8

int n;
int v[N_MAX], fq[N_MAX];
void bkt(int pos) {
  int i;
  if(pos == n) {
    for(i = 0; i < n; ++i) {
      fout << v[i] + 1 << ' ';
    }
    fout << '\n';
  }else{
    for(i = 0; i < n; ++i) {
      if(!fq[i]) {
        v[pos] = i;
        fq[i] = 1;
        bkt(pos + 1);
        fq[i] = 0;
      }
    }
  }
}

int main()
{
  fin >> n;
  bkt(0);
  return 0;
}
