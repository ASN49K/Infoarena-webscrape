#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const int Nmax = 10;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int n;
vector<int> permutare;
bool used[Nmax];

void backtrack(int poz)
{
    if (poz == n+1)
    {
        for (int i = 0; i < permutare.size(); ++i)
        {
            fout << permutare[i] << " ";
        }

        /*for (x : permutare)
        {
            fout << x << " ";
        }*/

        fout << "\n";
        return;
    }

    for (int i = 1; i <= n; ++i)
    {
        if (!used[i])
        {
            permutare.push_back(i);
            used[i] = true;
            backtrack(poz + 1);

            permutare.pop_back();
            used[i] = false;
        }
    }
}

int main()
{
    fin>>n;

    backtrack(1);

    fin.close();
    fout.close();
    return 0;
}
