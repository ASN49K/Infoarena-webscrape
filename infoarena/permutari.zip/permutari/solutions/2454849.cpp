#include <fstream>
using namespace std;
ifstream in("permutari.in");
ofstream out("permutari.out");
int v[9],vf[9],n;
void bkt(int poz)
{
    int i;
    if(poz==n)
    {
        for(i=1; i<=n; i++)
            out<<v[i]<<" ";
        out<<'\n';
        return;
    }
    for(i=1; i<=n; i++)
    {
        if(vf[i]==0)
        {
            vf[i]=1;
            v[poz+1]=i;
            bkt(poz+1);
            v[poz+1]=vf[i]=0;
        }
    }
    return;
}
int main()
{
    in>>n;
    bkt(0);
    return 0;
}
