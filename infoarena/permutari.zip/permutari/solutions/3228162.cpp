#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("permutari.in");
ofstream fout("permutari.out");

int stiva[8];
int counter = 1;
int n;

void afis(){
  for(int i = 1; i<=n; i++)
    fout << stiva[i] << " ";
  fout << endl;  
}

bool verify(int x){
  bool isok = true;
  for(int i = 1; i<counter; i++){
    if(stiva[i] == x)
    {
      return false;
    }
  }
  return true;
}

void backtrack(){
  for(int i = 1; i<=n; i++){
    if (verify(i) == false)
      continue;
    stiva[counter++] = i;
    if(counter > n){
      afis();
      counter--;
      break;
    }  
    backtrack();
    counter--;
  }
}

int main(){
  fin >> n;
  backtrack();
}

