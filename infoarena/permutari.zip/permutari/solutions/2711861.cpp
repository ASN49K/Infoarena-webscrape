#include <iostream>
#include <fstream>

using namespace std;

ifstream f ("permutari.in");
ofstream g ("permutari.out");

int n,a[10],fr[10];

void afisare()
{
    for(int i=1;i<=n;i++)
    {
        g<<a[i];
    }
    g<<"\n";
}

bool verificare()
{
    for(int i=1;i<=n;i++)
    {
        fr[i]=0;
    }
    for(int i=1;i<=n;i++)
    {
        fr[a[i]]++;
    }
    for(int i=1;i<=n;i++)
    {
        if(fr[i]==0)
        {
            return false;
        }
    }
    return true;
}

void Back(int nivel)
{
    if(nivel==n+1)
    {
        if(verificare()==1)
            afisare();
    }
    else
    {
        for(int i=1;i<=n;i++)
        {
            a[nivel]=i;
            Back(nivel+1);
        }
    }
}

int main()
{
    f>>n;
    Back(1);
    return 0;
}
