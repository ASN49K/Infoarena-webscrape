#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;

int n,x[9];
bool F[9];

ifstream f("permutari.in");
ofstream g("permutari.out");

void afis()
{
    for(int i=1; i<=n; i++)
        g<<x[i]<<' ';
    g<<'\n';
}

bool valid(int k)
{
    for(int i=1; i<k; i++)
        if(x[i]==x[k])
            return 0;
    return 1;
}

void backt(int k)
{
    if(k<=n)
        for(int i=1; i<=n; i++)
        {
            if(F[i]==0)
            {
                x[k]=i;
                F[i]=1;
                backt(k+1);
                F[i]=0;
            }
        }
    else
        afis();
}

int main()
{
    f>>n;
    backt(1);
    f.close();
    g.close();
    return 0;
}
