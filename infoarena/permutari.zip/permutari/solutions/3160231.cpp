#include <iostream>
#include <fstream>
#include <vector>
#include <unordered_set>

using namespace std;

const string FILE_NAME = "permutari";
const string input = FILE_NAME + ".in";
const string output = FILE_NAME + ".out";

ifstream fin(input);
ofstream fout(output);

vector<int> sol;
unordered_set<int>used;

void print()
{
	for (int i : sol)
		fout << i << ' ';
	fout << '\n';
}

void permutari(int nivel, int n)
{
	for (int i = 1; i <= n; i++) {
		if (used.find(i) == used.end()) {
			used.insert(i);
			sol[nivel] = i;

			if (nivel < n) {
				if (nivel == n - 1) print();
				else permutari(nivel + 1, n);
			}

			used.erase(i);
		}
	}
}

int main()
{
	int n;
	fin >> n;
	sol = vector<int>(n);

	permutari(0, n);

	return 0;
}