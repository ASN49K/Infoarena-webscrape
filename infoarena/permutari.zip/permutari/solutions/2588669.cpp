#include <bits/stdc++.h>
using namespace std;
int a[6],n;

int main(){
	freopen("permutari.in", "r", stdin);
	freopen("permutari.out", "w", stdout);
	cin>>n;
	for(int i=0; i<n; i++) a[i]=i+1;
	do {
		for(int i=0; i<n; i++) cout<<a[i];
		cout<<endl;
	} while (next_permutation(a,a+n));
return 0;
}
