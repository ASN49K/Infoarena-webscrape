#include <fstream>
using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int pri0(string s, int &ind);
int pri1(string s, int &ind);
int pri2(string s, int &ind);


int pri0(string s, int &ind){
  int x=pri1(s, ind);
  while(s[ind]=='+'||s[ind]=='-'){
    if(s[ind]=='+') ind++, x+=pri1(s, ind);
    else ind++, x-=pri1(s, ind);
  }
  return x;
}

int pri1(string s, int &ind){
  int x=pri2(s, ind);
  while(s[ind]=='*'||s[ind]=='/'){
    if(s[ind]=='*') ind++, x*=pri2(s, ind);
    else ind++, x/=pri2(s, ind);
  }
  return x;
}

int pri2(string s, int &ind){
  int x=0;
  if(s[ind]=='('){
     ind++;
     x=pri0(s, ind);
     ind++;
  }
  else{
    while(s[ind]>='0'&&s[ind]<='9'){
      x=x*10+s[ind]-'0';
      ind++;
    }
  }
  return x;
}

int main()
{
    string s;
    fin>>s;
    int ind=0;
    fout<<pri0(s, ind);
    return 0;
}
