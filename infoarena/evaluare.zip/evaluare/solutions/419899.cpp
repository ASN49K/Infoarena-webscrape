//#include <iostream>
#include <string>
#include <fstream>

using namespace std;

string a;

ifstream cin("evaluare.in");
ofstream cout("evaluare.out");

void init_expr(int &st, int &dr)
{
    int nested = 0;
    if (a[dr] == ')' && a[st] == '(')
    {
        int i;
        for (i = st; i <= dr; ++i)
        {
            if (a[i] == '(') nested++;
            if (a[i] == ')') nested--;
            if (!nested && i != dr) break;
        }
        i--;
        if (i == dr)
        {
            st++; dr--;
            init_expr(st, dr);
        }
    } 
}

int split_position(int st, int dr)
{
    int nested = 0;
    for (int i = dr; i >= st; --i)
    {
        if (a[i] == '(') nested++;
        if (a[i] == ')') nested--;
        if (!nested && (a[i] == '+' || a[i] == '-')) return i;
    } 
    for (int i = dr; i >= st; --i)
    {
        if (a[i] == '(') nested++;
        if (a[i] == ')') nested--;
        if (!nested && (a[i] == '*' || a[i] == '/')) return i; 
    }  
    return -1;
}

inline int get_sign_code(char a)
{
    if (a == '+') return 1;
    if (a == '-') return 2;
    if (a == '*') return 3;
    if (a == '/') return 4;
    return 0;
}

bool is_number(int st, int dr)
{ 
    for (int i = st; i <= dr; ++i)
    {
        if (a[i] < '0' || a[i] > '9') return 0;
    }
    return 1;
}

int get_int(int st, int dr)
{
    int nr = 0;  
    for (int i = st; i <= dr; ++i)
    {
        nr = nr * 10;
        nr = nr + (a[i] - '0');
    }
    return nr;
}

int calc(int a, int b, int s)
{
    if (s == 1) return a + b;
    if (s == 2) return a - b;
    if (s == 3) return a * b;
    if (s == 4) return a / b; 
    return 0;  
}

int solve_expr(int st, int dr)
{
    init_expr(st, dr);
    if (is_number(st, dr)) return get_int(st, dr);
    int pos = split_position(st, dr);
    int sign = get_sign_code(a[pos]);
    return calc(solve_expr(st, pos - 1), solve_expr(pos + 1, dr), sign);   
}

int main()
{
    cin >> a;
    string inm;
    inm = '*';
    
    for (unsigned int i = 0; i < a.length() - 1; ++i)
    {
        if (a[i] >= '0' && a[i] <= '9' && a[i+1] == '(')
        {
            a.insert(i + 1, inm);
        }
    }
    
    cout << solve_expr(0, a.length() - 1);
}
