#include <fstream>
//#include <sstream>
#include <stack>
#include <limits>
#include <string>
using namespace std;

ifstream fi("evaluare.in");
ofstream fo("evaluare.out");

bool IsOperand(char C)
{
	if(C >= '0' && C <= '9') return true;
	if(C >= 'a' && C <= 'z') return true;
	if(C >= 'A' && C <= 'Z') return true;
	return false;
}


int priority(char a) {
    int temp;
    if (a == '^')
        temp = 1;
    else  if (a == '*' || a == '/')
        temp = 2;
    else  if (a == '+' || a == '-')
        temp = 3;
    return temp;
}

int main() {
    string infix,postfix;
    //cout << "Enter an arithmetic expression: " << endl;
    getline(fi, infix);

    stack<char> operator_stack;
    stack<int> nr_stack;

//    stringstream output;

    for (unsigned i = 0; i < infix.length(); i++) {
        if (infix[i] == '+' || infix[i] == '-' || infix[i] == '*' || infix[i] == '/' || infix[i] == '^') {
            while (!operator_stack.empty() && priority(operator_stack.top()) <= priority(infix[i])) {
                postfix += operator_stack.top();
                operator_stack.pop();
            }
            operator_stack.push(infix[i]);
        } else if (infix[i] == '(') {
            operator_stack.push(infix[i]);
        } else if (infix[i] == ')') {
            while (operator_stack.top() != '(') {
                postfix += operator_stack.top();
                operator_stack.pop();
            }
            operator_stack.pop();
        } else {
            {
                postfix +=',';
                while(IsOperand(infix[i]) and i < infix.length())
                {postfix += infix[i];i++;}
                i--;
        }
    }
    }
    while (!operator_stack.empty()) {

        postfix += operator_stack.top();
        operator_stack.pop();
    }

    for(unsigned i = 0; i < postfix.length() ; i++)
    {
        int nr=0;
        if(IsOperand(postfix[i])){
        while(IsOperand(postfix[i]) and i< postfix.length())
    {
        nr=nr*10+postfix[i]-'0';
        i++;
    }
        i--;
        nr_stack.push(nr);
    }
        else if(postfix[i]=='+'){
            int nr1=nr_stack.top();
            nr_stack.pop();
            int nr2=nr_stack.top();
            nr_stack.pop();
            nr_stack.push(nr1+nr2);
        }
        else if(postfix[i]=='-'){
            int nr1=nr_stack.top();
            nr_stack.pop();
            int nr2=nr_stack.top();
            nr_stack.pop();
            nr_stack.push(nr2-nr1);
        }
        else if(postfix[i]=='*'){
            int nr1=nr_stack.top();
            nr_stack.pop();
            int nr2=nr_stack.top();
            nr_stack.pop();
            nr_stack.push(nr1*nr2);
        }
        else if(postfix[i]=='/'){
            int nr1=nr_stack.top();
            nr_stack.pop();
            int nr2=nr_stack.top();
            nr_stack.pop();
            nr_stack.push(nr2/nr1);
        }

    }
   // cout << postfix << endl;
    fo << nr_stack.top();
    //cin.ignore(numeric_limits<streamsize>::max(), '\n');

    return 0;
}
