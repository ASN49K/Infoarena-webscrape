#include <stdio.h>
#include <vector>
#include <string.h>
#define MAX 100001
using namespace std;

vector<char> s;
char expr[MAX];
int a, b;
vector<int> v;

int eval(char op){
	b = v.back();
	v.pop_back();
	a = v.back();
	v.pop_back();
	switch(op){
		case '*': return a * b; break;
		case '+': return a + b; break;
		case '-': return a - b; break;
		default: return a / b;
	}
}

int main(){
	freopen("evaluare.in", "r", stdin);
	freopen("evaluare.out", "w", stdout);
	scanf("%s", expr);

	int x = 0, i;
	int lung = strlen(expr);

	for(i = 0; i < lung; i++){
		if('0' <= expr[i] && expr[i] <= '9')
			x = 10 * x + expr[i] - '0';
		
		else{
			if(i > 0 && '0' <= expr[i - 1] && expr[i - 1] <= '9'){
				v.push_back(x);
				x = 0;
			}

			if(expr[i] == '(')
				s.push_back(expr[i]);

			else if(expr[i] == ')'){
				while(s.back() != '('){
					v.push_back(eval(s.back()));
					s.pop_back();
				}
				s.pop_back();
			}

			else if(expr[i] == '*' || expr[i] == '/'){
				while(!s.empty() && (s.back() == '*' || s.back() == '/')){
					v.push_back(eval(s.back()));
					s.pop_back();
				}
				s.push_back(expr[i]);
			}

			else if(expr[i] == '+' || expr[i] == '-'){
				while(!s.empty() && s.back() != '('){
					v.push_back(eval(s.back()));
					s.pop_back();
				}
				s.push_back(expr[i]);
			}
		}
	}

	if(x != 0)
		v.push_back(x);
	
	while(!s.empty()){
		v.push_back(eval(s.back()));
		s.pop_back();
	}
	printf("%d\n", v.back());
	return 0;
}
