#include <cstdio>
#include <iostream>
#include <stack>    
#define MAX_S 100000

using namespace std;

char S[MAX_S];
stack<char> OP;
stack<int> NUM;

int readNumber(char* &p) {
    int n = 0;
    for (; *p >= '0' && *p <= '9'; ++p)
        n = 10 * n + *p - '0';
    return n;
}

// Resolves an operator on the result stack, performing whatever operations to
// the output stack that are needed.
void pushOperator(char p) {
    int b = NUM.top();
    NUM.pop();
    int a = NUM.top();
    NUM.pop();
    switch (p) {
        case '+':
            NUM.push(a + b);
            break;
        case '-':
            NUM.push(a - b);
            break;
        case '*':
            NUM.push(a * b);
            break;
        case '/':
            NUM.push(a / b);
    }
}

inline int prec(char p) {
    switch(p) {
        case '(':
            return 0;
        case '-':
        case '+':
            return 1;
        case '*':
        case '/':
            return 2;
    }
    return 2;
}

int main() {
    FILE *fin = fopen("evaluare.in", "r");
    FILE *fout = fopen("evaluare.out", "w");
    
    fgets(S, MAX_S, fin);
    char *p = S;

    while (*p != '\n') {
        if (*p >= '0' && *p <= '9') 
            NUM.push(readNumber(p));
        else {
            if (*p != '(' && *p != ')') {
                for (; !OP.empty() && prec(*p) <= prec(OP.top()); OP.pop())
                    pushOperator(OP.top());
                OP.push(*p);
            } else if (*p == ')') {
                for (; OP.top() != '('; OP.pop())
                    pushOperator(OP.top());
                OP.pop();
            } else
                OP.push(*p);
            ++p;
        }
    }
    for (; !OP.empty(); OP.pop())
        pushOperator(OP.top());

    fprintf(fout, "%d\n", NUM.top());

    return 0;
}
