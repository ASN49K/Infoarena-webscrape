#include <bits/stdc++.h>
using namespace std;
char s[100005];
int main()
{
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);
    fgets(s+1,1005,stdin);
    int n=strlen(s+1),i;
    --n;
    stack<char>st1;
    stack<int>st2;
    for(i=1;i<=n;i++)
    {
        if(s[i]>='0'&&s[i]<='9')
        {
            int nr=0;
            while(s[i]>='0'&&s[i]<='9')
            {
                nr=nr*10+s[i]-'0';
                ++i;
            }
            --i;
            st2.push(nr);
            continue;
        }
        if(s[i]==' ')continue;
        if(s[i]=='(')
        {
         st1.push(s[i]);
         continue;
        }
        if(s[i]=='+'||s[i]=='-')
        {
            if(st1.empty())
            {
                st1.push(s[i]);
                continue;
            }
            if(st1.top()=='(')
            {
                st1.push(s[i]);
                continue;
            }
            if(st1.top()=='*')
            {
                int x=st2.top();st2.pop();
                st2.top()*=x;
                st1.pop();
                st1.push(s[i]);
                continue;
            }
            if(st1.top()=='/')
            {
                int x=st2.top();st2.pop();
                st2.top()/=x;
                st1.pop();
                st1.push(s[i]);
                continue;
            }
            if(st1.top()=='+')
            {
                int x=st2.top();st2.pop();
                st2.top()+=x;
                st1.pop();
                st1.push(s[i]);
                continue;
            }
            if(st1.top()=='-')
            {
                int x=st2.top();st2.pop();
                st2.top()-=x;
                st1.pop();
                st1.push(s[i]);
                continue;
            }
        }
         if(s[i]=='*'||s[i]=='/')
        {
            if(st1.empty())
            {
                st1.push(s[i]);
                continue;
            }
            if(st1.top()=='(')
            {
                st1.push(s[i]);
                continue;
            }
            if(st1.top()=='*')
            {
                int x=st2.top();st2.pop();
                st2.top()*=x;
                st1.pop();
                st1.push(s[i]);
                continue;
            }
            if(st1.top()=='/')
            {
                int x=st2.top();st2.pop();
                st2.top()/=x;
                st1.pop();
                st1.push(s[i]);
                continue;
            }
            if(st1.top()=='+')
            {
                st1.push(s[i]);continue;
            }
            if(st1.top()=='-')
            {
                st1.push(s[i]);continue;
            }
        }
        if(s[i]==')')
        {
            while(!st1.empty())
            {
                if(st1.top()=='(')
                {
                    st1.pop();break;
                }
                if(st1.top()=='*')
            {
                int x=st2.top();st2.pop();
                st2.top()*=x;
                st1.pop();
                //st1.push(s[i]);
                continue;
            }
            if(st1.top()=='/')
            {
                int x=st2.top();st2.pop();
                st2.top()/=x;
                st1.pop();
                //st1.push(s[i]);
                continue;
            }
            if(st1.top()=='+')
            {
                int x=st2.top();st2.pop();
                st2.top()+=x;
                st1.pop();
                //st1.push(s[i]);
                continue;
            }
            if(st1.top()=='-')
            {
                int x=st2.top();st2.pop();
                st2.top()-=x;
                st1.pop();
                //st1.push(s[i]);
                continue;
            }
            }
        }
    }
    while(!st1.empty())
         {
                if(st1.top()=='(')
                {
                    st1.pop();break;
                }
                if(st1.top()=='*')
            {
                int x=st2.top();st2.pop();
                st2.top()*=x;
                st1.pop();
                //st1.push(s[i]);
                continue;
            }
            if(st1.top()=='/')
            {
                int x=st2.top();st2.pop();
                st2.top()/=x;
                st1.pop();
                //st1.push(s[i]);
                continue;
            }
            if(st1.top()=='+')
            {
                int x=st2.top();st2.pop();
                st2.top()+=x;
                st1.pop();
                //st1.push(s[i]);
                continue;
            }
            if(st1.top()=='-')
            {
                int x=st2.top();st2.pop();
                st2.top()-=x;
                st1.pop();
                //st1.push(s[i]);
                continue;
            }
            }
    cout<<st2.top();
    return 0;
}
