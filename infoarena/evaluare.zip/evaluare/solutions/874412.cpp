#include <cstdio>
char s[100010],*p;
long long termen();
long long factor();
long long numar();
long long main ()
{
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);
    gets(s);
    p=s;
    printf("%lld",termen());
    return 0;
}
long long termen()
{
    long long val=factor();
    while(*p=='+' || *p=='-')
        if(*p=='+')
        {
          ++p;
          val+=factor();
        }
        else
        {
            ++p;
            val-=factor();
        }
    return val;
}
long long factor ()
{
    long long val=numar();
    while(*p=='/' || *p=='*')
        if(*p=='*')
        {
            ++p;
            val*=numar();
        }
        else
        {
            ++p;
            val/=numar();
        }
    return val;
}
long long numar ()
{
    long long val=0;
    if(*p=='(')
    {
           ++p;
           val=termen();
           ++p;
    }
    else
    {
        while(*p>='0' && *p<='9')
        {
            val=val*10+(*p-'0');
            ++p;
        }
    }
    return val;
}
