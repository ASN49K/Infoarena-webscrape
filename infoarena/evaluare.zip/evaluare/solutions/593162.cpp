#include<fstream.h>
char v[100010];
int x=0, n;
int max=- (1LL << 50);

int extrage_nr()
{
	int nr=0;
	while(v[x]-'0'>=0 && v[x]-'0'<10 && x<=n)
	{
		nr=nr*10+(long long)v[x]-'0';
		x++;
	}
	return nr;
}

int expresie()
{
	int num[100020];
	int i, k=0, aux;
	char semne[100020];
	while(v[x]!=')' && x<=n)
	{
		if(v[x]=='(')
		{
			x++;
			num[k]=expresie();
			k++;
		}
		else if(v[x]=='+' || v[x]=='*' || v[x]=='/' || v[x]=='-')
		{
			semne[k-1]=v[x];
			x++;
		}
		else
		{
			num[k]=extrage_nr();
			k++;
		}
	}
	x++;
	for(i=0; i<k-1; ++i)
		if(semne[i]=='*' || semne[i]=='/')
		{
			if(semne[i]=='*')
				num[i+1]*=num[i];
			else
				num[i+1]=num[i]/num[i+1];
			num[i]=-2000000001;
		}
	for(i=0; i<k-1; ++i)
		if(semne[i]=='+' || semne[i]=='-')
		{
			aux=i+1;
			while(num[aux]==-2000000001)
				aux++;
			if(semne[i]=='-')
				num[aux]=num[i]-num[aux];
			else
				num[aux]+=num[i];
		}
	/*if(num[k-1]>max)
		max=num[k-1];*/
	return num[k-1];
}	

int main()
{
	int nr;
	ifstream f("evaluare.in");
	f.getline(v, 100001);
	n=strlen(v)-1;
	nr=expresie();
/*	if(nr>max)
		max=nr;
*/	ofstream g("evaluare.out");
	g<<nr;
	g.close();
	return 0;
}