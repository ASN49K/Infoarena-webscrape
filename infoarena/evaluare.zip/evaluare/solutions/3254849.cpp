#include <bits/stdc++.h>

using namespace std;

string s; 
int sz;

int solve(string s, int st, int dr, int initSemn)
{
    int nr = 0;
    int semn = initSemn;
    int rez = 0;
    int mul = 1;  
    bool seMul = false; 
    bool seDiv = false;

    for (int i = st; i < dr; i++)
    {
        if (isdigit(s[i]))
        {
            nr = nr * 10 + (s[i] - '0');
        }
        else if (s[i] == '*')
        {
            if (seMul)
            {
                mul *= nr;  
            }
            else
            {
                mul = nr;  
                seMul = true;
            }
            nr = 0;
        }
        else if (s[i] == '/')
        {
            if (seDiv)
            {
                mul /= nr;  
            }
            else
            {
                mul = nr;  
                seDiv = true; 
            }
            nr = 0;
        }
        else if (s[i] == '-')
        {
            if (seMul)
            {
                nr = mul * nr;
                seMul = false;
            }
            if (seDiv)
            {
                nr = mul / nr;  
                seDiv = false;
            }
            rez += semn * nr;
            semn = -1;
            nr = 0;
        }
        else if (s[i] == '+')
        {
            if (seMul)
            {
                nr = mul * nr;
                seMul = false;
            }
            if (seDiv)
            {
                nr = mul / nr;  
                seDiv = false;
            }
            rez += semn * nr;
            semn = 1;
            nr = 0;
        }
        else if (s[i] == '(')
        {
            int j = i + 1;
            int open = 1;
            while (j < sz)
            {
                if (s[j] == '(') open++;
                if (s[j] == ')') open--;
                if (open == 0) break;
                j++;
            }
            nr = solve(s, i + 1, j, 1);
            i = j;
        }
    }

    if (seMul) 
    {
        nr = mul * nr;
    }

    if (seDiv) 
    {
        nr = mul / nr;
    }

    return rez + semn * nr;
}

int main()
{
    ifstream cin("evaluare.in");
    ofstream cout("evaluare.out");
    cin >> s;
    s += '+';  
    sz = s.size();
    cout << solve(s, 0, sz, 1);
    return 0;
}
