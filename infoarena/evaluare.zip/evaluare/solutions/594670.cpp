#include<fstream>
using namespace std;
char s[100001];
int x=0,n;
long eval(int &k);
long termen(int &k)
{ long nr=0,z=0;
  while(s[k]=='('){ k++; x++; }
  while(s[k]<='9' && s[k]>='0') { nr=nr*10+s[k]-'0'; k++; z=1;}
   if(z==0)return 1;
 return nr;
}

long eval(int &k)
{ long rez=0,nr2=0;
    if(s[k]=='(') { x++; rez=eval(++k); }
    if(s[k]>='0' && s[k]<='9') rez=termen(k); 
    if(s[k]=='*') rez*= termen(++k);
    if(s[k]=='/') rez/= termen(++k);
    if(s[k]=='+') rez+=eval(++k);
	if(s[k]=='-') rez-=eval(++k);
	if(s[k]==')'){ x--; k++; }
   if(x==0 || k==n )return rez; 
}

int main()
{int k=0;
 ifstream f("evaluare.in");ofstream g("evaluare.out");
 f.getline(s,100001);
 n=strlen(s)-1;
 g<<eval(k);
 f.close();g.close();
return 0;}
