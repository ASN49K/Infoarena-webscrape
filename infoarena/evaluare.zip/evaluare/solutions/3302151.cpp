#include <bits/stdc++.h>
using namespace std;

constexpr char iname[] = "evaluare.in";
constexpr char oname[] = "evaluare.out";

string s;
int idx;

long long eval();

long long factor()
{
  long long rez = 0;
  if(s[idx] == '(') {
    ++idx;
    rez = eval();
    ++idx;
    return rez;
  }
  while(idx < s.size() && s[idx] >= '0' && s[idx] <= '9') {
    rez = rez*10 + (s[idx] - '0');
    ++idx;
  }
  return rez;
}

long long termen()
{
  long long rez = factor();
  while(idx < s.size() && (s[idx] == '*' || s[idx] == '/')) {
    if(s[idx] == '*') {
      ++idx;
      rez *= factor();
    } else {
      ++idx;
      rez /= factor();
    }
  }
  return rez;
}

long long eval()
{
  long long rez = termen();
  while(idx < s.size() && (s[idx] == '+' || s[idx] == '-')) {
    if(s[idx] == '+') {
      ++idx;
      rez += termen();
    } else {
      ++idx;
      rez -= termen();
    }
  }
  return rez;
}


int main()
{
  ifstream in(iname);
  in >> s;
  ofstream out(oname);
  out << eval();
  in.close();
  return 0;
}