#include <bits/stdc++.h>
using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char s[100005];
int n;
int Termen();
int Factor();

int Eval()
{
    int r = Termen();
    while (s[n] == '+' or s[n] == '-')
    {
        switch(s[n])
        {
            case '+' : {n++; r += Termen(); break;}
            case '-' : {n++; r -= Termen(); break;}
        }
    }
    return r;
}

int Termen()
{
    int r = Factor();
    while (s[n] == '*' or s[n] == '/')
    {
        switch(s[n])
        {
            case '*' : {n++; r *= Factor(); break;}
            case '/' : {n++; r /= Factor(); break;}
        }
    }
    return r;
}

int Factor()
{
    int r;
    if (s[n] == '(')
    {
        n++;
        r = Eval();
        n++;
    }
    else
    {
        r = 0;
        while (isdigit(s[n]))
        {
            r = r * 10 + s[n] - '0';
            n++;
        }
    }
    return r;
}

int main()
{
    n = 0;
    fin >> s;
    fout << Eval();
    return 0;
}
