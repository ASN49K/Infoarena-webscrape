#include <fstream>
#include <iostream>
#include <cstdio>
using namespace std;
char c;
int i;
ifstream f ("evaluare.in");
ofstream g ("evaluare.out");
long eval();
long number();
long prod();

long eval()
{
	long nr=prod();//inmultirea si inpartirea au prioritate asa ca incepem cu ea
	while((c=='+'||c=='-'))
	{
		if (c=='+')
		{	
			f>>c;//incepe termenul adunarii
			nr=nr+prod();
		}
		if (c=='-')
		{
			f>>c;
     		nr=nr-prod();
		}
	}
	return nr;
}

long prod()
{
	long nr=number();//orice expresie incepe cu un numar
	while ((c=='*')||(c=='/'))
	{   
		if (c=='*')
		{
			f>>c;
			nr=nr*number();
		}
		if (c=='/')
		{
			f>>c;
			nr=nr/number();//consideram ca expreia e valida deci ca number() nu va da 0
		}
	}
	return nr;
}

long number()
{
	long nr=0;
	if(c=='(')//daca e o paranteza avem o expresie de evaluat
	{
		f>>c;//prima cifra din noua expresie
		nr=eval();
		f>>c;//citim ")"
	}
	else
	{
		while ((c>='0')&&(c<='9')&&(!f.eof()))//formam numarul care poate avea si mai multe cifre
		{
			nr=nr*10+(c-'0');
			f>>c;
		}
	}
	return nr;//ne intoarcem sa calculam restul expresiei
} 

int main()
{
	f>>c;
	g<<eval();
	f.close();
	g.close();
	return 0;
}
