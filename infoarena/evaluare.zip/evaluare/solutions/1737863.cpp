#include <fstream>
#include <stack>
#include <string>
#include <cstring>
#define MAXN 100000
#define ll long long
std::ifstream input("evaluare.in");
std::ofstream output("evaluare.out");
std::stack<char> opstack;
ll position = 0, number, pow = 1;
int priority(char c1, char c2)
{
    if(c1 == '+' && c2 == '-') return 1; if(c1 == '-' && c2 == '+') return 1;
    if(c1 == '*' && c2 == '/') return 1; if(c1 == '/' && c2 == '*') return 1;

    if(c1 == '+' && c2 == '*') return 1; if(c1 == '+' && c2 == '/') return 1;
    if(c1 == '-' && c2 == '*') return 1; if(c1 == '-' && c2 == '/') return 1;
    
    return 0;
    
}
ll operation(char operatorSymbol, ll x, ll y)
{
    switch(operatorSymbol)
    {
        case '+': return x + y;
        case '-': return y - x;
        case '/': return y / x;
        case '*': return x * y;
    }
    
    printf("error operation");
    return -1;
}
void infixTOpostfix(std::string& infixExpression, std::string& postfixExpression)
{
    long pos = 0, length = infixExpression.size();
    
    while(pos < length)
    {
        if(std::strchr("+-/*", infixExpression[pos]))
        {
            if(!opstack.size()) opstack.push(infixExpression[pos]);
            else if(priority(infixExpression[pos],opstack.top()))                    {
                        postfixExpression = postfixExpression + opstack.top(); postfixExpression.append(" ");
                        opstack.pop();
                        opstack.push(infixExpression[pos]);
                    }
            else opstack.push(infixExpression[pos]);
        }
        else if('(' == infixExpression[pos]) opstack.push('(');
        else if(')' == infixExpression[pos])
        {
            //discarding ')'
            while(opstack.top() != '(') {
                postfixExpression = postfixExpression + opstack.top();
                postfixExpression.append(" ");
                opstack.pop();
            }
            opstack.pop();
        }
        else
        {
            while(std::strchr("0123456789", infixExpression[pos]) && pos < length)
                postfixExpression += infixExpression[pos++];
            
            postfixExpression.append(" ");
            pos--;
        }
        pos++;
    }
    
    while(pos == length && opstack.size() != 0)
    {
        postfixExpression = postfixExpression + opstack.top();
        postfixExpression.append(" ");
        opstack.pop();
    }
}
ll evaluate(ll x, ll y, char op)
{
    switch(op)
    {
        case '+': return x+y;
        case '-': return y-x;
        case '/': return y/x;
        case '*': return x*y;
    }
    
    printf("something bad happened");
    return -1;
}
ll evaluatePostFix(std::string& expression)
{
    char op;
    if(strchr("+-/*", expression[position]))
    {
        op = expression[position];
        position -= 2;
        return evaluate(evaluatePostFix(expression), evaluatePostFix(expression), op);
    }
    
    
    number = 0; pow = 1;
    while(expression[position] != ' ' && position >= 0)
    {
        number = number + (expression[position--] - '0') * pow;
        pow *= 10;
    }
    position--;
    return number;
    
    return -10;
}
int main()
{
    std::string infixExpression, postfixExpression;
    
    std::getline(input, infixExpression);
    
    infixTOpostfix(infixExpression, postfixExpression);
    
    position = postfixExpression.size() - 2;
    output << evaluatePostFix(postfixExpression);
    
    return 0;
}