#include <bits/stdc++.h>
#define LMAX 100005

using namespace std;

ifstream in ("evaluare.in");
ofstream out ("evaluare.out");

int p;
char s[LMAX];

long termen();
long factor();

long eval()
{
    long r=termen();
    while (s[p]=='+' || s[p]=='-')
    {
        if (s[p]=='+')
        {
            p++;
            r+=termen();
        }
        else
            if (s[p]=='-')
            {
                p++;
                r-=termen();
            }
    }
    return r;
}

long termen()
{
    long r=factor();
    while (s[p]=='*' || s[p]=='/')
    {
        if (s[p]=='*')
        {
            p++;
            r*=factor();
        }
        else
            if (s[p]=='/')
            {
                p++;
                r/=factor();
            }
    }
    return r;
}

long factor()
{
    long r=0;
    if (s[p]=='(')
    {
        p++;
        r=eval();
        p++;
    }
    else
        while (isdigit(s[p]))
        {
            r=r*10+s[p]-'0';
            p++;
        }
    return r;
}

int main()
{
    in >> s;
    out << eval();
    return 0;
}
