#include <iostream>
#include <stdio.h>
#include <string.h>
#include <fstream>


using namespace std;
double eval(int st, int dr);
char s[100005];

void trimm() {

    for(int i=strlen(s)-1; i >= 0 ; i--)
        if(s[i]=='(')
        {

            if(s[i+1]=='-')
                s[i+1]='#';
           for(int j=i;j<strlen(s);j++)
                if(s[j] == ')') {
                    double rez = eval(i+1, j-1);
                    char post[100];
                    strcpy(post, s+j+1);
                    strcpy(s+i, "");
                    if(rez > 0)
                        sprintf(s+i, "%lf", rez);
                    else
                        sprintf(s+i, "#%lf", -rez);
                    strcat(s, post);
                    int debug;
                    return;
                }
        }
}

double eval(int st, int dr)
{
    for(int i=dr; i>=st; i--)
        if(s[i]=='+')
            return eval(st, i-1) + eval(i+1, dr);
    for(int i=dr; i>=st; i--)
        if(s[i]=='-')
            return eval(st, i-1) - eval(i+1, dr);
    for(int i=dr; i>=st; i--)
        if(s[i]=='/')
            return eval(st, i-1) / eval(i+1, dr);
    for(int i=dr; i>=st; i--)
        if(s[i]=='*')
            return eval(st, i-1) * eval(i+1, dr);


    double bla;
    if(s[st] != '#')
        sscanf(s+st,"%lf", &bla);
    else
        sscanf(s+st+1,"%lf", &bla),
        bla*=(-1);
    return bla;
}

int main()
{
    /** ========sscanf=========
    char s[200]="mada are -21 de ani";

    int x;

    for(int i=0;i<strlen(s); i++)
        if(s[i]=='-' || isdigit(s[i]))
        {
            sscanf(s+i,"%d", &x);
            break;
        }
    cout << x;
*/

    ifstream f("evaluare.in");
    ofstream g("evaluare.out");

    f.getline(s,100005);

    while(strchr(s, '(') || strchr(s,')'))
        trimm();

    g << eval(0, strlen(s)-1);


    return 0;

}
