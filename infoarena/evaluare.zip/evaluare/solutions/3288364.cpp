#include <bits/stdc++.h>
#define DIM 100001
using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char s[DIM];

int i;

int expresie();

int termen();

int factor();

int constanta();

int expresie(){

    int ret = termen();

    while(s[i] == '+' || s[i] == '-'){

        if(s[i] == '+'){

            i++;

            ret+=termen();

        }

        else{

            i++;

            ret-=termen();

        }

    }

    return ret;

}

int termen(){

    int ret = factor();

    while(s[i] == '*' || s[i] == '/'){

        if(s[i] == '*'){

            i++;

            ret*=factor();

        }

        else{

            i++;

            ret/=factor();

        }

    }

    return ret;

}

int factor(){

    int ret;

    if(s[i] == '('){

        i++;

        ret = expresie();

        i++;

       }

    else{

        ret = constanta();

    }

    return ret;

}

int constanta(){

    int ret = 0;

    while(s[i] >= '0' && s[i] <= '9'){

        ret = ret*10 + s[i] - '0';

        i++;

    }

    return ret;

}

int main(){

    fin >> s;

    fout << expresie();

    return 0;

}
