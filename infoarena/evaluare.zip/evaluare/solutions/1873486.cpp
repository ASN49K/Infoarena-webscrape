#include <fstream>

using namespace std;

ifstream fin("eval.in");
ofstream fout("eval.out");

char S[100010], *p = S;
int expr();
int factor();
int termen();

int expr() {
    int K = termen();
    while(*p == '-' or *p == '+') {
        switch(*p) {
            case '+': {
                p++;
                K += termen();
                break;
            }
            default: {
                p++;
                K -= termen();
                break;
            }
        }
    }
    return K;
}

int termen() {
    int K = factor();
    while(*p == '*' or *p == '/') {
        switch(*p) {
            case '*': {
                p++;
                K *= factor();
                break;
            }
            default: {
                p++;
                K /= factor();
                break;
            }
        }
    }
    return K;
}

int factor() {
    int K = 0;
    if(*p == '(') {
        p++;
        K = expr();
        p++;
    }
    else {
        while(*p >= '0' and *p <= '9') {
            K = K*10 + (*p-'0');
            p++;
        }
    }
    return K;
}

int main() {
    fin>>S;
    fout<<expr();
    return 0;
}
