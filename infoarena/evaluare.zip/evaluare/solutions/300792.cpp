#include<fstream.h>
#include<string.h>
struct nod
{long e;
nod *s,*d;}*c;
char s[100100],e[100100];
long p[100100],v[100100],i,j,n,k;
nod* arb(long li,long ls)
{nod* c;
 long i,j,min;
 min=p[ls];i=ls;
 for(j=ls;j>=li;j--)
  if(p[j]<min)
  {min=p[j];i=j;}
 c=new nod;c->e=i;
 if(li==ls)c->s=c->d=0;
 else
 {c->s=arb(li,i-1);
  c->d=arb(i+1,ls);}
 return c;
}
long parc(nod* c)
{if(c)
  switch(e[c->e])
  {case '+':return parc(c->s)+parc(c->d);
   case '-':return parc(c->s)-parc(c->d);
   case '*':return parc(c->s)*parc(c->d);
   case '/':return parc(c->s)/parc(c->d);
   default :return v[c->e];
  }
}
int main()
{ifstream f("evaluare.in");
ofstream g("evaluare.out");
f.get(s,100002);
n=strlen(s);
for(;i<n;++i)
 switch(s[i])
 {case ')':j-=2;break;
  case '(':j+=2;break;
  case '+':p[k]=j+1;e[k++]='+';break;
  case '-':p[k]=j+1;e[k++]='-';break;
  case '*':p[k]=j+2;e[k++]='*';break;
  case '/':p[k]=j+2;e[k++]='/';break;
  default :{while(s[i]>='0'&&s[i]<='9')
	    {v[k]=v[k]*10+s[i]-'0';
	     ++i;}
	    p[k++]=2000000000;--i;}
 }
c=arb(0,k-1);
g<<parc(c);
return 0;
}
