#include <fstream>
#include <iostream>

using namespace std;

ifstream f ("evaluare.in");
ofstream g ("evaluare.out");

char s[ 100001 ];
int i;

int exp();
int ter();
int fct();

int exp(){
    int r = ter();
    while( s[ i ] == '+' || s[ i ] == '-' ){
        if( s[ i ] == '+' ){
            ++i;
            r = r + ter();
        }
        else{
            ++i;
            r = r - ter();
        }
    }
    return r;
}
int ter(){
    int r = fct();
    while( s[ i ] == '*' || s[ i ] == '/' ){
        if( s[ i ] == '*' ){
            ++i;
            r = r * fct();
        }
        else{
            ++i;
            r = r / fct();
        }
    }
    return r;
}
int fct(){
    int r;
    if( s[ i ] == '(' ){
        ++i;
        r = exp();
        ++i;
    }
    else{
        r = 0;
        while( s[ i ] >= '0' && s[ i ] <= '9' ){
            r = r * 10 + s[ i ] - '0';
            ++i;
        }
    }
    return r;
}
int main(){
    f >> s;
    i = 0;
    g << exp( );
}
