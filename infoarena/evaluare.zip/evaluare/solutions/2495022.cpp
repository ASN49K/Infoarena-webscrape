#include <bits/stdc++.h>

using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
int main()
{
stack < char > stv;
stack < int > stk;
string s;
vector < string > v;
    fin >> s;
    s = "(" + s + ")";
    int n = s.length();
    for(int i = 0; i < n; ++i)
    {
        if(s[i] == '(' || s[i] == '*' || s[i] == '/')
            stv.push(s[i]);
            else
        if(s[i] == ')')
        {
            while(stv.top() != '(')
            {
                string aux = "";
                aux += stv.top();
                v.push_back(aux);
                stv.pop();
            }
            stv.pop();
        } else
        if(s[i] == '+' || s[i] == '-')
        {
            while(stv.top() != '(' && (stv.top() == '*' || stv.top() == '/'))
            {
                string aux = "";
                aux += stv.top();
                v.push_back(aux);
                stv.pop();
            }
            stv.push(s[i]);
        } else
        {
            string aux = "";

            while(s[i] >= '0' && s[i] <= '9' && i < n) aux += s[i], ++i;

            --i;
            v.push_back(aux);
        }
    }
    int nr = v.size();
    //for(int i = 0; i < nr; ++i) cout << v[i];

    for(int i = 0; i < nr; ++i)
    {
        if(v[i] == "+" || v[i] == "-" || v[i] == "*" || v[i] == "/")
        {
            int val2 = stk.top();
            stk.pop();
            int val1 = stk.top();
            stk.pop();
            if(v[i] == "+") stk.push(val1 + val2);else
            if(v[i] == "-") stk.push(val1 - val2);else
            if(v[i] == "*") stk.push(val1 * val2);else
                stk.push(val1 / val2);
        } else
        {
            int val = 0;
            int n1 = v[i].length();
            for(int j = 0; j < n1; ++j) val = val * 10 + (v[i][j] - '0');
            stk.push(val);
        }
    }
    fout << stk.top();
    return 0;
}
