#include<stdio.h>
#include<vector>

using namespace std;

vector <int> p,l;
int n=-1;

void paranteza(int i,int j,int sw){
int semn,s=0,pr=0,q;
if(sw==0){
if(l[i+1]==-4){
q=i+3;
semn=-1;
}
else{
semn=1;
q=i+2;
}
}
else{
semn=1;
q=1;
j++;
}
while(q<=j){
pr=l[q-1];
while((l[q]==-5||l[q]==-6)&&q<j){
if(l[q]==-5)
pr*=l[q+1];
else
if(l[q]==-6)
pr/=l[q+1];
q+=2;
}
s=s+(semn*pr);
if(l[q]==-4)
semn=semn*(-1);
if(l[q]==-3)
    semn=1;
q+=2;
}
l.erase(l.begin()+i+1,l.begin()+j);
l[i]=s;
p.pop_back();
n=i;
}
void rezolva(){
freopen("evaluare.in","r",stdin);
char c;
int nr;
c=getc(stdin);
while((int)c!=10){
n++;
nr=0;
if(c=='('){
    p.push_back(n);
    l.push_back(-1);
    c=getc(stdin);
   }
else
    if(c=='+'){
    l.push_back(-3);
    c=getc(stdin);
    }
else
    if(c=='-'){
    l.push_back(-4);
    c=getc(stdin);
    }
else
    if(c=='*'){
    l.push_back(-5);
    c=getc(stdin);
    }
else
    if(c=='/'){
    l.push_back(-6);
    c=getc(stdin);
    }
else
    if(c==')'){
       paranteza(p[p.size()-1],n,0);
        c=getc(stdin);
    }
    else{
        while(c>='0'&&c<='9'){
            nr=nr*10+(c-'0');
            c=getc(stdin);
        }
        l.push_back(nr);
    }
}
paranteza(0,n,1);
fclose(stdin);
}
int main(){
rezolva();
freopen("evaluare.out","w",stdout);
printf("%d",l[0]);
fclose(stdout);
return 0;
}
