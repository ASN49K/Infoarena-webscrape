#include <fstream>
#include <cctype>

namespace Analyze {
  std::string str;
  int idx;

  int expr();
  int term();
  int fact();
  int num();

  int expr() {
    int ret = term();
    while( idx < (int)str.size() && (str[idx] == '+' || str[idx] == '-') ){
      if( str[idx] == '+' ){
        idx++;
        ret += term();
      }else{
        idx++;
        ret -= term();
      }
    }

    return ret;
  }
  
  int term() {
    int ret = fact();
    while( idx < (int)str.size() && (str[idx] == '*' || str[idx] == '/') ){
      if( str[idx] == '*' ){
        idx++;
        ret *= fact();
      }else{
        idx++;
        ret /= fact();
      }
    }

    return ret;
  }
  
  int fact() {
    if( str[idx] == '(' ){
      idx++;
      int ret = expr();
      idx++;
      return ret;
    }

    return num();
  }
  
  int num() {
    int ret = 0;
    while( idx < (int)str.size() && isdigit( str[idx] ) )
      ret = ret * 10 + str[idx++] - '0';
    return ret;
  }
}

int main() {
  std::ifstream fin("evaluare.in");
  std::ofstream fout("evaluare.out");

  std::string str;
  fin >> str;

  Analyze::str = str;
  Analyze::idx = 0;
  fout << Analyze::expr() << '\n';
  return 0;
}
