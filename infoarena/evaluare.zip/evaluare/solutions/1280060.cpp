#include<fstream>
#include<list>
#include<iostream>

using namespace std;

long int a[100000];

int main()
{
    ifstream fin("evaluare.in");
    ofstream fout("evaluare.out");
    list<int> sign;
    char ch;
    bool flag;
    long int i,nr1,nr2,count;
    for(i=0;!fin.eof();)
    {
            flag=0;
            fin>>ch;
            while(ch>='0'&&ch<='9')
            {
                                   a[i]*=10;
                                   a[i]+=(ch-'0');
                                   fin>>ch;
                                   flag=1;
                                   if(fin.eof())
                                   {
                                                break;
                                   }
            }
            if(flag==1)
            {
                       i++;
            }
            if(ch=='+')
            {
                       if(!sign.empty())
                       {
                                        while(sign.back()!=-1000000001&&sign.back()!=-1000000002&&!sign.empty())
                                        {
                                                                                                   if(sign.back()==1000000001)
                                                                                                   {
                                                                                                                              a[i]=1000000001;
                                                                                                                              i++;
                                                                                                                              sign.pop_back();
                                                                                                   }
                                                                                                   else if(sign.back()==1000000002)
                                                                                                   {
                                                                                                        a[i]=1000000002;
                                                                                                        i++;
                                                                                                        sign.pop_back();
                                                                                                   }
                                                                                                   else if(sign.back()==1000000003)
                                                                                                   {
                                                                                                        a[i]=1000000003;
                                                                                                        i++;
                                                                                                        sign.pop_back();
                                                                                                   }
                                                                                                   else
                                                                                                   {
                                                                                                       a[i]=1000000004;
                                                                                                       i++;
                                                                                                       sign.pop_back();
                                                                                                   }
                                        }
                       }
                       sign.push_back(1000000001);
            }
            else if(ch=='-')
            {
                 if(!sign.empty())
                 {
                                  while(sign.back()!=-1000000001&&sign.back()!=-1000000002&&!sign.empty())
                                  {
                                                                                             if(sign.back()==1000000001)
                                                                                             {
                                                                                                                        a[i]=1000000001;
                                                                                                                        i++;
                                                                                                                        sign.pop_back();
                                                                                             }
                                                                                             else if(sign.back()==1000000002)
                                                                                             {
                                                                                                  a[i]=1000000002;
                                                                                                  i++;
                                                                                                  sign.pop_back();
                                                                                             }
                                                                                             else if(sign.back()==1000000003)
                                                                                             {
                                                                                                  a[i]=1000000003;
                                                                                                  i++;
                                                                                                  sign.pop_back();
                                                                                             }
                                                                                             else
                                                                                             {
                                                                                                 a[i]=1000000004;
                                                                                                 i++;
                                                                                                 sign.pop_back();
                                                                                             }
                                  }
                 }
                 sign.push_back(1000000002);
            }
            else if(ch=='*')
            {
                 if(!sign.empty())
                 {
                                  while(sign.back()!=-1000000001&&sign.back()!=-1000000002&&sign.back()!=1000000001&&sign.back()!=1000000002&&!sign.empty())
                                  {
                                                                                                                                           if(sign.back()==1000000003)
                                                                                                                                           {
                                                                                                                                                                      a[i]=1000000003;
                                                                                                                                                                      i++;
                                                                                                                                                                      sign.pop_back();
                                                                                                                                           }
                                                                                                                                           else
                                                                                                                                           {
                                                                                                                                               a[i]=1000000004;
                                                                                                                                               i++;
                                                                                                                                               sign.pop_back();
                                                                                                                                           }
                                  }
                 }
                 sign.push_back(1000000003);
            }
            else if(ch=='/')
            {
                 if(!sign.empty())
                 {
                                  while(sign.back()!=-1000000001&&sign.back()!=-1000000002&&sign.back()!=1000000001&&sign.back()!=1000000002&&!sign.empty())
                                  {
                                                                                                                                           if(sign.back()==1000000003)
                                                                                                                                           {
                                                                                                                                                                      a[i]=1000000003;
                                                                                                                                                                      i++;
                                                                                                                                                                      sign.pop_back();
                                                                                                                                           }
                                                                                                                                           else
                                                                                                                                           {
                                                                                                                                               a[i]=1000000004;
                                                                                                                                               i++;
                                                                                                                                               sign.pop_back();
                                                                                                                                           }
                                  }
                 }
                 sign.push_back(1000000004);
            }
            else if(ch=='(')
            {
                 sign.push_back(-1000000001);
            }
            else
            {
                while(sign.back()!=-1000000001&&!sign.empty())
                {
                                               if(sign.back()==1000000001)
                                               {
                                                                          a[i]=1000000001;
                                                                          i++;
                                                                          sign.pop_back();
                                               }
                                               else if(sign.back()==1000000002)
                                               {
                                                    a[i]=1000000002;
                                                    i++;
                                                    sign.pop_back();
                                               }
                                               else if(sign.back()==1000000003)
                                               {
                                                    a[i]=1000000003;
                                                    i++;
                                                    sign.pop_back();
                                               }
                                               else
                                               {
                                                   a[i]=1000000004;
                                                   i++;
                                                   sign.pop_back();
                                               }
                }
                sign.pop_back();
            }
    }
    bool as=0;
    while(!sign.empty())
    {
                      if(sign.back()==1000000001)
                      {
                                                 a[i]=1000000001;
                                                 i++;
                                                 sign.pop_back();
                      }
                      else if(sign.back()==1000000002)
                      {
                           a[i]=1000000002;
                           i++;
                           sign.pop_back();
                      }
                      else if(sign.back()==1000000003)
                      {
                           a[i]=1000000003;
                           i++;
                           sign.pop_back();
                      }
                      else
                      {
                          a[i]=1000000004;
                          i++;
                          sign.pop_back();
                      }
    }
    for(int j=2;j<i;j++)
    {
            count=0;
            nr1=1;
            nr2=1;
            if(a[j]==1000000001)
            {
                                for(int k=j-1;count!=2;k--)
                                {
                                        if(a[k]!=-1000000005)
                                        {
                                                   if(count==0)
                                                   {
                                                               nr1=a[k];
                                                   }
                                                   else
                                                   {
                                                       nr2=a[k];
                                                   }
                                                   a[k]=-1000000005;
                                                   count++;
                                        }
                                }
                                a[j]=nr2+nr1;
            }
            else if(a[j]==1000000002)
            {
                 for(int k=j-1;count!=2;k--)
                 {
                         if(a[k]!=-1000000005)
                         {
                                    if(count==0)
                                    {
                                                nr1=a[k];
                                    }
                                    else
                                    {
                                        nr2=a[k];
                                    }
                                    a[k]=-1000000005;
                                    count++;
                         }
                 }
                 a[j]=nr2-nr1;
            }
            else if(a[j]==1000000003)
            {
                 for(int k=j-1;count!=2;k--)
                 {
                         if(a[k]!=-1000000005)
                         {
                                    if(count==0)
                                    {
                                                nr1=a[k];
                                    }
                                    else
                                    {
                                        nr2=a[k];
                                    }
                                    a[k]=-1000000005;
                                    count++;
                         }
                 }
                 a[j]=nr2*nr1;
            }
            else if(a[j]==1000000004)
            {
                for(int k=j-1;count!=2;k--)
                 {
                         if(a[k]!=-1000000005)
                         {
                                    if(count==0)
                                    {
                                                nr1=a[k];
                                    }
                                    else
                                    {
                                        nr2=a[k];
                                    }
                                    a[k]=-1000000005;
                                    count++;
                         }
                 }
                 if(nr2!=0) a[j]=nr2/nr1;
                 else
                 {
                     fout<<"esti debil";
                     as=1;
                     break;
                 }
            }
    }
    if(as==0) fout<<a[i-1];
}
