#include <fstream>
#include <cstring>
using namespace std;
ifstream f("expr.in");
ofstream g("expr.out");
char s[100001],*p;
int n;
int nr();
int eval();
int termen();
int factor();
int main()
{
    f.getline(s,100000);
    p=s;
    n=eval();
    g<<n;
    return 0;
}
int nr()
{
    int r=0;
    while(*p>='0' && *p<='9')
    {
        r*=10;
        r+=(int)*p-'0';
        p++;
    }
    return r;
}
int eval()
{
    int r=termen();
    while(*p=='+' || *p=='-')
    if(*p=='+')
    {
        p++;
        r+=termen();
    }
    else
    {
        p++;
        r-=termen();
    }
    return r;
}
int termen()
{
    int r=factor();
    while(*p=='*' || *p=='/')
    if(*p=='*')
    {
        p++;
        r*=factor();
    }
    else
    {
        p++;
        r/=factor();
    }
    return r;
}
int factor()
{
    int r=0;
    if(*p=='(')
       {
           p++;
           r=eval();
           p++;
       }
    else r=nr();
    return r;
}
