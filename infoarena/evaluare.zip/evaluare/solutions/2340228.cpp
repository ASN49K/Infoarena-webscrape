#include<fstream>
#include<cstring>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
char s[100002],n;

int calc(int i)
{
    int x=0,p=1,sol=0,ii;
    if(s[i]=='(')
    {
        x=calc(i+1);
        while(s[i]!=')')
            i++;
        i++;
    }
    else
    {
        while(s[i]>='0'&&s[i]<='9')
        {
            x*=10;
            x+=s[i]-48;
            i++;
        }
    }
    p*=x;
    while(i<=n&&s[i]!=')')
    {
        while(s[i]=='*'||s[i]=='/')
        {
            x=0;
            ii=i;
            i++;
            if(s[i]=='(')
            {
                x=calc(i+1);
                while(s[i]!=')')
                    i++;
                i++;
            }
            else
            {
                while(s[i]>='0'&&s[i]<='9'&&i<=n)
                {
                    x*=10;
                    x+=s[i]-48;
                    i++;
                }
            }
            if(s[ii]=='*')
                p*=x;
            else
                p/=x;
        }
        sol+=p;
        if(s[i]=='+')
            p=1;
        else
            p=-1;
        i++;
        x=0;
        if(s[i]=='(')
        {
            x=calc(i+1);
            while(s[i]!=')')
                i++;
            i++;
        }
        else
        {
            while(s[i]>='0'&&s[i]<='9'&&i<=n)
            {
                x*=10;
                x+=s[i]-48;
                i++;
            }
        }
        p*=x;
    }
    sol+=p;
    return sol;
}

int main()
{
    int sol;
    f.getline(s+1,100001);
    n=strlen(s+1);
    sol=calc(1);
    g<<sol;
    return 0;
}
