#include<stdio.h>
#include<fstream.h>
#include<string.h>
#define max 100010
char x[max], o[max];
long v[max], n, k, l, i;
FILE *f, *g;

void solve();
void calc();
long det();

int main()
{       f=fopen("evaluare.in", "r");
	g=fopen("evaluare.out", "w");
	fscanf(f, "%s", x);
	n=strlen(x);
	solve();
	return 0;
}

void solve()
{       for(i=0; i<n; i++)
	{       switch(x[i])
		{       case '*':
			case '/':
				while((o[l]=='*' || o[l]=='/') && l>0)
				{	calc(); l--;
				}
				l++; o[l]=x[i]; break;
			case '+':
			case '-':
				while(o[l]!='(' && l>0)
				{       calc(); l--;
				}
				l++; o[l]=x[i]; break;
			case '(':
				l++; o[l]=x[i]; break;
			case ')':
				while(o[l]!='(')
				{       calc();
					l--;
				}
				l--;
				break;
			default :
				k++; v[k]=det();
				break;
		}
	}
	while(l>0)
	{       calc(); l--;
	}
	fprintf(g, "%ld\n", v[1]);
	fclose(g);
}

void calc()
{       if(k==1)
		return;
	switch(o[l])
	{	case '+':
		case '-':
			while(o[l]=='+' || o[l]=='-')
			{	switch(o[l])
				{       case '+':
						v[k-1]=v[k-1]+v[k]; k--; break;
					case '-':
						v[k-1]=v[k-1]-v[k]; k--; break;
				}
				l--;
			}
			l++; break;
		case '*':
			v[k-1]=v[k-1]*v[k]; k--; break;
		case '/':
			v[k-1]=v[k-1]/v[k]; k--; break;

	}
}

long det()
{	long m;
	m=0;
	while(i<n && x[i]<58 && x[i]>47)
	{       m=m*10+(x[i]-'0');
		i++;
	}
	i--;
	return m;
}
