#include <fstream.h>
#include <string.h>
ifstream f("evaluare.in");
ofstream g("evaluare.out");
char e[100009]; long S[100000]; char op [100000]; long v1,v;
long n,i;

long numar(long &i)
	{
	long x=0;
	while(e[i]>='0'&&e[i]<='9'&&i<n)
	{x=x*10+(e[i]-'0');  i++;}
	i--;
	return x;
	}

long calcul (long a, long b, char o)
	{
	switch (o)
		{
		case '+': a+=b; break;
		case '-': a-=b; break;
		case '*': a*=b; break;
		case '/': a/=b; break;
		}
	return a;
	}

int prioritate (char a)
	{
	switch (a)
		{
		case '+':
		case '-': return 1;
		case '*':
		case '/': return 2;
		case '(': return 0;
		}
return 0;
	}

int main ()                             //  Zennon
	{
	f.getline(e,100008);
	n = strlen(e);
	for(i=0;i<n;i++)
	switch (e[i])
		{
		case '+':
		case '-':
		case '*':
		case '/': while(prioritate(op[v1])>=prioritate(e[i]))
			    {S[v-1]=calcul(S[v-1], S[v], op[v1]); v--; v1--;}
			     op[++v1]=e[i]; break;

		case '(': op[++v1]=e[i];
			    break;
		case ')': while( op[v1]!='(')
				{
				S[v-1]=calcul(S[v-1], S[v], op[v1]);
				v1--;v--;
				}
			    v1--;
			    break;
		default: S[++v]=numar(i);

		}
	while (v1)
		{
			S[v-1]=calcul(S[v-1], S[v], op[v1]);
			v1--; v--;
		}
	g<<S[1];
	f.close();
	g.close();
return 0;

	}
























