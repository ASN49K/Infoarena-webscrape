#include<stdio.h>
#include<string.h>

int i,n,v,lg;
char c,e[100];

long Eval();
long EvalFactor();
long EvalTermen();
long EvalExpresie();

int main()
{
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);
    scanf("%s",&e);
    
    lg=strlen(e);
    i=0;
    printf("%d",EvalExpresie());
    return 0;
}

long Eval()
{long f;
      for (f=0;e[i]>='0' && e[i]<='9'; i++)
          f=f*10+(e[i]-'0');
}

long EvalFactor()
{long f;
     if (e[i]=='('){
                  f=EvalExpresie();
                  i++;
     }
     else{
         f=Eval();
         i++;
     }
     return f;
}

long EvalTermen()
{long r=EvalFactor();
     while(i<lg && (e[i]=='*'|| e[i]=='/')){
                i++;
                if (e[i]=='*')
                   r*=EvalFactor();    
                else
                    r/=EvalFactor();
     }
     return r;
}

long EvalExpresie()
{long r=EvalTermen();
    while(i<lg && (e[i]=='+'|| e[i]=='-')){
          i++;
          if (e[i]=='+')
             r+=EvalTermen();
          else         
                       r-=EvalTermen();
    }
    return r;
}
