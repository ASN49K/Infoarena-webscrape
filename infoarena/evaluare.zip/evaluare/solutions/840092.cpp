#include<stdio.h>
#include<string.h>
#define hmax 2
char s [ 100010 ] ;
char *p = s ;
char operand [ 4 ] [ 4 ] = { "+-" , "*/" , "^" , "" } ;
long eval ( long ) ;
long semn ( long x , long y , char tip )
{
    if ( tip == '+' )
        return x + y ;
    if ( tip == '-' )
        return x - y ;
    if ( tip == '*' )
        return x * y ;
    if ( tip == '/' )
        return x / y ;
    return 0;
}
long element ( )
{
    long r = 0 ;
    if ( * p == '(' )
    {
        ++ p ;
        r = eval ( 0 ) ;
        ++ p ;
    }
    else
        while ( strchr("0123456789", * p ) )
            r = r * 10 + *( ++ p - 1 ) - '0';
    return r;
}
long eval ( long h )
{
    long r = ( h == hmax ) ? element ( ) : eval ( h + 1 ) ;
    while ( strchr ( operand [ h ] , * p ) )
        r = semn ( r , eval ( h + 1 ) , * ( ++ p - 1 ) ) ;
    return r ;
}
int main()
{
    freopen ( "evaluare.out" , "w" , stdout ) ;
    fgets(s, 100010, fopen("evaluare.in", "r"));
    printf ( "%ld" , eval ( 0 ) ) ;
    return 0;
}
