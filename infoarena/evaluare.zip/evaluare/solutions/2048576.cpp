#include<fstream>
#include<cstring>
#define f first
#define s second
#define DIM 150005
using namespace std;
int n, i, nr, u, j;
int c2[DIM];
pair<int, int> v[DIM];
char s[DIM], s2[DIM], c[DIM];
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
int main(){
    fin>> s2 + 1;
    n = strlen(s2 + 1);
    nr = 1;
    s[1] = '(';
    for(i = 1; i <= n; i++){
        if(s2[i] != '-'){
            s[++nr] = s2[i];
        }
        else{
            if(i == 1 || s2[i - 1] == '('){
                s[++nr] = '0';
                s[++nr] = '-';
            }
            else{
                s[++nr] = '-';
            }
        }
    }
    s[++nr] = ')';
    n = nr;
    nr = u = 0;
    for(i = 1; i <= n; i++){
        if(s[i] >= '0' && s[i] <= '9'){
            nr++;
            for(j = i; j <= n; j++){
                if(s[j] >= '0' && s[j] <= '9'){
                    v[nr].f = v[nr].f * 10 + s[j] - '0';
                }
                else{
                    break;
                }
            }
            i = j - 1;
            continue;
        }
        if(s[i] == '('){
            c[++u] = s[i];
            continue;
        }
        if(s[i] == ')'){
            while(c[u] != '('){
                nr++;
                v[nr] = make_pair(c[u], 1);
                u--;
            }
            u--;
            continue;
        }
        if(s[i] == '*' || s[i] == '/'){
            while(c[u] == '*' || c[u] == '/'){
                nr++;
                v[nr] = make_pair(c[u], 1);
                u--;
            }
            c[++u] = s[i];
            continue;
        }
        while(c[u] == '*' || c[u] == '/' || c[u] == '+' || c[u] == '-'){
            nr++;
            v[nr] = make_pair(c[u], 1);
            u--;
        }
        c[++u] = s[i];
    }
    u = 0;
    for(i = 1; i <= nr; i++){
        if(v[i].s == 0){
            c2[++u] = v[i].f;
            continue;
        }
        if(v[i].f == '+'){
            c2[u - 1] = c2[u - 1] + c2[u];
        }
        if(v[i].f == '-'){
            c2[u - 1] = c2[u - 1] - c2[u];
        }
        if(v[i].f == '*'){
            c2[u - 1] = c2[u - 1] * c2[u];
        }
        if(v[i].f == '/'){
            c2[u - 1] = c2[u - 1] / c2[u];
        }
        u--;
    }
    fout<< c2[1] <<"\n";
    return 0;
}

