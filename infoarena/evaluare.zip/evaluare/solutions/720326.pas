var s:array[1..100000] of char;
    t:text;
    n,i:longint;
    c:char;

function s2r(s:string):real;
var r:real; c:integer;
begin

  val(s,r,c);
  s2r:=r;
end;

function eval(left, right:integer):real;
var p1,p2,p3,p4,i,pp:longint; ss:string;
begin
  p1:=0;p2:=0;p3:=0;p4:=0; pp:=0;
  for i:=left to right do
  if s[i]='(' then inc(pp)
  else if s[i]=')' then dec(pp)
  else if pp=0 then
     case s[i] of
     '+':p1:=i;
     '-':p2:=i;
     '*':p3:=i;
     '/':p4:=i;
     end;

  if p1>p2 then eval:=eval(left,p1-1) + eval(p1+1,right)
  else if p2>0 then eval:=eval(left,p2-1) - eval(p2+1,right)
  else if p3>p4 then eval:=eval(left,p3-1) * eval(p3+1,right)
  else if p4>0 then eval:=eval(left,p4-1) / eval(p4+1,right)
  else if s[left]='(' then eval:=eval(left+1, right-1)
  else
  begin
  ss:='';
  for i:=left to right do ss:=ss+s[i];  eval:=s2r(ss);
  end;
end;

begin
  assign(t,'evaluare.in');
  reset(t);
  while not eoln(t) do
  begin
  n:=n+1;
  read(t,s[n]);
  end;
  close(t);

  assign(t,'evaluare.out');
  rewrite(t);
  write(t,trunc(eval(1, n)));
  close(t);
end.
