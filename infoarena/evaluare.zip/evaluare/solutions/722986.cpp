#include <cstdio>
#include <cstring>
#define CMax 100021

using namespace std;

char s[CMax];
int x;

int eval();

int factor(){
	int nr,rez=1,sm=1;
	bool inm=1,ok=1;
	while(ok)
	{
		sm=1;
		nr=0;
		if(s[x]=='-'){ sm*=-1; x++;}
		else
			if(s[x]=='+') x++;

		if(s[x]=='(') {
			x++;nr=eval();}
		else 
			for(;'0'<=s[x]&&s[x]<='9'; nr=nr*10+s[x]-48,x++);

		if(inm==1) rez*=nr;
		else if(nr) rez/=nr; else rez=0;

		if(s[x]=='/') inm=0,x++;
		else  if(s[x]=='*') inm=1,x++;
			else ok=0;
	}

	return rez;
}

int eval(){
	int tmp=0,nr=0,tot=0;
	while(s[x]!=')'){
		tot+=factor();
	}
	x++;
	return tot;
}

int main()
{
	freopen("evaluare.in","rt",stdin);
	freopen("evaluare.out","wt",stdout);

	scanf("%s",s);
	s[strlen(s)]=')';
	
	printf("%d",eval());

	return 0;
}