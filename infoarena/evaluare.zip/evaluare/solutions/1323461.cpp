#include <fstream>
using namespace std;
ifstream cin("evaluare.in");
ofstream cout("evaluare.out");

int eva(), prod(), term(), p, i;
char s[100005];

int eva()
{
    int k=prod();
    while (s[p]=='-' || s[p]=='+')
    if (s[p]=='-')
    {
        ++p;
        k-=prod();
    }
    else
    {
        ++p;
        k+=prod();
    }

    return k;
}

int prod()
{
    int k=term();
    while (s[p]=='*' || s[p]=='/')
    if (s[p]=='*')
    {
        ++p;
        k*=term();
    }
    else
    {
        ++p;
        k/=term();
    }

    return k;
}

int term()
{
    int sn=1,
    v=0;
    while (s[p]=='-')
    {
        ++p;
        sn=-sn;
    }
    if (s[p]=='(')
    {
        ++p;
        v=eva();
        ++p;
    }
    while (s[p]>='0' && s[p]<='9')
    {
        v=v*10 + s[p] - '0';
        ++p;
    }

    return v*sn;
}


int main()
{
    cin>>s;
    \
    cout<<eva();

    return 0;
}

