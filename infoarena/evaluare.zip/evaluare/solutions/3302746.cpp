#include <iostream>
#include <fstream>
using namespace std;

#ifdef LOCAL
#define fin cin
#define fout cout
#else
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
#endif
#define int long long int
string s;
int i=0;

int eval();

int fact() {
	int rez = 0;
	if (s[i] == '(') {
		i++;
		rez = eval();
		i++;
		return rez;
	}
	while (i < s.size() && s[i] >= '0' && s[i] <= '9') {
		rez = rez * 10 + s[i] - '0';
		i++;
	}
	return rez;
}

int term() {
	int rez = fact();
	while (i < s.size() && (s[i] == '*' || s[i] == '/')) {
		i++;
		if (s[i - 1] == '*') rez *= term();
		else rez /= term();
	}
	return rez;
}

int eval() {
	int rez = term();
	while (i < s.size() && (s[i] == '+' || s[i] == '-')) {
		i++;
		if (s[i - 1] == '+') rez += term();
		else rez -= term();
	}
	return rez;
}

int32_t main() {
	fin >> s;
	fout << eval();
}
