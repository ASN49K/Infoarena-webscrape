#include <cstdio>  
#include <cstring>  
   
#define LMAX 2  
char op[4][4] = { "+-", "*/", "^", "" };  
   
#define NX 100010  
char S[NX], *p = S;  
  
int eval( int a, int b, char op ) 
{  
     switch( op ) 
     {  
         case '+': return a + b;  
         case '-': return a - b;  
         case '*': return a * b;  
         case '/': return a / b;
         default : return 0;  
     }  
}  

int expr( int lev ) 
{  
     int x, y;  
       
     if( lev == LMAX )  
         if( *p == '(' )  
              ++p, x = expr(0), ++p;  
         else  
            for( x = 0; '0' <= *p && *p <= '9'; ++p )  
                 x = x * 10 + *p - '0';  
    else  
         for( x = expr(lev+1); strchr(op[lev], *p); x = y )  
             y = eval( x, expr(lev+1), *p++ );  
     return x;  
}  
 
int main() 
{  
     fgets( S, NX, fopen( "evaluare.in", "r" ) );  
     fprintf( fopen( "evaluare.out", "w" ), "%d\n", expr(0) );  
     return 0;  
}  
