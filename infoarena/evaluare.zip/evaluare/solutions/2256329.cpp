#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");

char s[100001],x;
int i=0;
int lg;

int expresie();
int termen();
int factor();

void cit()
{
    /*x=f.get();
    while(x!='\n'&&x!=' ')
    {
        lg++;
        s[lg]=x;
        x=f.get();
    }*/
    f.getline(s,100001);
    lg=strlen(s);

}


int termen()
{
    int t=factor();
    while(i<lg&&(s[i]=='+'||s[i]=='-'))
    {
        if(s[i]=='+')
        {
            i++;
            t=t+factor();
        }
        if(s[i]=='-')
        {
            i++;
            t=t-factor();
        }

    }
    return t;

}


int expresie()
{
    int t,nr=0;
    if(s[i]=='(')
    {
        i++;
        t=termen();
        i++;
    }
    else
    {
        while('0'<=s[i]&&s[i]<='9')
        {
            nr=nr*10+(s[i]-'0');
            i++;
        }
        t=nr;

    }
            return t;
}

int factor()
{
    int f=expresie();
    while(i<lg&&(s[i]=='*'||s[i]=='/'))
    {
        if(s[i]=='*')
        {
            i++;
            f=f*expresie();
        }

        if(s[i]=='/')
        {
            i++;
            f=f/expresie();
        }
    }
    return f;
}


int main()
{
    cit();
    g<<termen();
    return 0;
}
