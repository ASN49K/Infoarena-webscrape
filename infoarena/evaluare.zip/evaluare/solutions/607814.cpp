
#include <cstdio>
using namespace std;

int poz;
char s[1005];

int expresie();
int termen();
int factor();

int expresie()
{
    int val=termen();
    while(s[poz]=='+' || s[poz]=='-')
    {
        if(s[poz]=='+')
        {
            ++poz;
            val+=termen();
        }
        else
        {
            ++poz;
            val-=termen();
        }

    }
    return val;
}

int termen()
{
    int val=factor();
    while(s[poz]=='*'||s[poz]=='/')
    {
        if(s[poz]=='*')
        {
            ++poz;
            val*=factor();
        }
        else
        {
            ++poz;
            val/=factor();
        }
    }
    return val;
}

int factor()
{
    int val=0,semn=1;
    while(s[poz]=='-')
    {
        ++poz;
        semn=-semn;
    }
    if(s[poz]=='(')
    {
        ++poz;
        val=expresie();
        ++poz;
        return val*semn;
    }
    while(s[poz]>='0' && s[poz]<='9')
    {
        val=val*10+s[poz]-'0';
        poz++;
    }
    return val*semn;
}
int main()
{
    freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	scanf("%s",s);
    int v;
    v=expresie();
    printf("%d\n",v);
    return 0;
}