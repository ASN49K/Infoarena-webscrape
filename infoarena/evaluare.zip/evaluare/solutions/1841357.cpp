#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
int a[1000001],n,i,k,aux,nr,nr2,s1,nr3,nr4,s2,aux2;
char s[100001],x,x2,x3,x4;
int main()
{
    f.get(s,1000001);
    k=strlen(s);
    x='+';
    for(i=0;i<k;i++)
    {
        while(s[i]>='0' && s[i]<='9')
        {nr=nr*10+s[i]-48;
        i++;
        }
        if(s[i]=='(') {x3='+';
        nr3=0;
        nr4=0;
        s2=0;
        aux2=0;
        while (s[i]!=')') {i++;
        while(s[i]>='0' && s[i]<='9')
        {nr3=nr3*10+s[i]-48;
        i++;
        }
        x4=s[i];
        if(x3=='+') {s2=s2+nr3;
        nr4=nr3;
        }
        else if(x3=='-') {s2=s2-nr3;
        nr4=nr3;
        }
        else if(x3=='*') if(aux2==1) {s2=s2-nr4+nr4*nr3;
        nr4=nr4*nr3;
        }
                        else {s2=s2+nr4-nr4*nr3;
                        nr4=nr4*nr3;
                        }
        else if(aux2==1) {s2=s2-nr4+nr4/nr3;
        nr4=nr4/nr3;
        }
            else {s2=s2+nr4-nr4/nr3;
            nr4=nr4/nr3;
            }
        if(x3=='+') aux2=1;
        else aux2=0;
        x3=x4;
         nr3=0;

        }
        i++;
        nr=s2;
        x2=s[i];
        }

        else x2=s[i];
        if(x=='+') {s1=s1+nr;
        nr2=nr;
        }
        else if(x=='-') {s1=s1-nr;
        nr2=nr;
        }
        else if(x=='*') if(aux==1) {s1=s1-nr2+nr2*nr;
        nr2=nr2*nr;
        }
                        else {s1=s1+nr2-nr2*nr;
                        nr2=nr2*nr;
                        }
        else if(aux==1) {s1=s1-nr2+nr2/nr;
        nr2=nr2/nr;
        }
            else {s1=s1+nr2-nr2/nr;
            nr2=nr2/nr;
            }
        if(x=='+') aux=1;
        else aux=0;
        x=x2;
    //cout<<s1<<" ";
    nr=0;
    //cout<<i<<" ";
    }
    g<<s1;
    return 0;
}
