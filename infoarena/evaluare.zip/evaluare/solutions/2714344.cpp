#include <fstream>
#include<cstring>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char s[100005],*p;
int adun_scad();
int factor();///inmultire-impartire
int element();///se ocupa cu paranteze si valori
int adun_scad()
{
    int rez=factor();
    while(*p=='+'||*p=='-')
    {
        if(*p=='+')
        { p++;
          rez+=factor();
        }
        else
        {
            p++;
            rez-=factor();
        }
    }
    return rez;
}
int factor()
{
    int rez=element();
    while(*p=='*'||*p=='/')
    {
        if(*p=='*')
        {
            p++;
            rez*=element();
        }
        else
        {
            p++;
            rez/=element();
        }
    }
    return rez;
}
int element()
{
    int rez=0;
    if(*p=='(')
    {
        p++;
        rez=adun_scad();
        p++;
    }
    else
    {
        while(isdigit(*p))
        {
            rez=rez*10+*p-'0';
            p++;
        }
    }
    return rez;
}
int main()
{
    fin>>s;
    p=s;
    fout<<adun_scad();
    return 0;
}
