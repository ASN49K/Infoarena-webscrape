#include <stdio.h>
char e[100001], *p=e;int lgpol, pol[100001];struct nod{	int inf;	nod *urm;} *prim=NULL;void transExp();void transTerm();
void transFact();void transExp(){
	char c;
	transTerm();	while(*p=='+' || *p=='-'){
		c=*p;		p++;
		transTerm();		if(c=='+')			pol[lgpol++] = -1;		else pol[lgpol++] = -2;
	}
}void transTerm(){	char c;	transFact();	while(*p=='*' || *p=='/'){		c = *p; p++;		transFact();		if(c=='*')
			pol[lgpol++] = -3;
		else
			pol[lgpol++] = -4;
	}
}
void transFact(){	if(*p=='('){		p++;		transExp();		p++;	}	else{	while(*p>='0' && *p<='9') pol[lgpol] = pol[lgpol]*10 + *p-'0', p++;		lgpol++;	}
}
int eval(){int i=0;	while(i<lgpol){	if(pol[i]>=0){		nod *p = new nod;	p->inf = pol[i];	p->urm = prim;		prim = p;			i++;
		}
		else {
			int v=prim->inf;nod *p = prim; prim=prim->urm; delete p;if(pol[i]==-1) prim->inf+=v;		else if(pol[i]==-2) prim->inf-=v;			else if(pol[i]==-3) prim->inf*=v;			else if(pol[i]==-4) prim->inf/=v;
			i++;
		}
	}
	return prim->inf;
}

int main(){	FILE *f=fopen("evaluare.in", "r");FILE *g=fopen("evaluare.out", "w");fscanf(f, "%s", e);	transExp();	fprintf(g, "%d\n", eval());
	fclose(f);	fclose(g);	return 0;}
