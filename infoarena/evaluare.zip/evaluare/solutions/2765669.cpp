#include <bits/stdc++.h>
#include <cstdio>
using namespace std;

FILE *fin=freopen("evaluare.in","r",stdin),
     *fout=freopen("evaluare.out","w",stdout);
char expresion[100000];
int pos = 0;
int if_nr_or_();
int divide_X_op();
int plus_minus_operation()
{
    int nr = divide_X_op();
    while(expresion[pos] == '+' || expresion[pos] == '-')
    {
        switch(expresion[pos]){
            case '+':
                pos++;
                nr += divide_X_op();
            break;

            case '-':
                pos++;
                nr -= divide_X_op();
            break;}
    }
    return nr;
}
int divide_X_op()
{
    int nr = if_nr_or_();
    while(expresion[pos] == '*' || expresion[pos] == '/')
    {
        switch(expresion[pos]){
            case '*':
                pos++;
                nr *= if_nr_or_();
            break;

            case '/':
                pos++;
                nr /= if_nr_or_();
            break;}
    }
    return nr;
}
int if_nr_or_()
{
    int nr = 0;
    if(expresion[pos] == '(')
    {
        pos++;
        nr = plus_minus_operation();
        pos++;
    }
    else
    {
        while(expresion[pos] >= '0' && expresion[pos] <= '9')
        {
            nr = nr*10  + expresion[pos] - '0';
            pos++;
        }
    }
    return nr;
}
int main()
{
    gets(expresion);
    printf("%ld",plus_minus_operation());
}
