#include <cstdio>
#include <stack>
#include <cstring>
#include <algorithm>
#include <cctype>
#define mare 1000000000


using namespace std;

stack <int> ops;
int rez[100005];

char imp[100005];
int out[100005];
int conv(char a){
	if(a=='+') return mare+1;
	if(a=='-') return mare+2;
	if(a=='*') return mare+3;
	if(a=='/') return mare+4;
	if(a=='^') return mare+5;
	if(a=='(') return mare+6;
	if(a==')') return mare+7;

	return 50;
}
	
int prior(char a){
	if(a=='+') return 1;
	if(a=='-') return 1;
	if(a=='*') return 2;
	if(a=='/') return 2;
	if(a=='^') return 3;
	if(isdigit(a)) return 4;
	if(a=='(') return 5;
	return 50;
}

int main (){
	int n,i,sz=0,dim=0;;
	int nu=0;
	
	freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	
	scanf("%s", imp);
	n=strlen(imp);
	for(i=0;i<n;++i){
		if(prior(imp[i])==4){
			while(prior(imp[i])==4){
				nu=nu*10+imp[i]-'0';
				++i;
			}
			--i;
			out[++sz]=nu;
			nu=0;
		}
		else if(prior(imp[i])==5) ops.push(conv(imp[i]));
		else if(prior(imp[i])<4){
			while(ops.size()&&prior(ops.top())<prior(imp[i])){
				out[++sz]=ops.top();
				ops.pop();
			}
			ops.push(conv(imp[i]));
		}
		else if(imp[i]==')'){
			while(ops.top()!=conv('(')){
				out[++sz]=ops.top();
				ops.pop();
			}
			ops.pop();
		}
	}
	while(ops.size()){
		out[++sz]=ops.top();
		ops.pop();
	}
	
	for(i=1;i<=sz;++i){
		if(out[i]<1000000000) rez[++dim]=out[i];
		if(out[i]==1000000001) rez[dim-1]+=rez[dim--];
		if(out[i]==1000000002) rez[dim-1]-=rez[dim--];
		if(out[i]==1000000003) rez[dim-1]*=rez[dim--];
		if(out[i]==1000000004) rez[dim-1]/=rez[dim--];
	}
	printf("%d", rez[1]);
	
}
			
		
			
	