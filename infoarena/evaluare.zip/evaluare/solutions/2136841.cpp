#include <bits/stdc++.h>
using namespace std;
ifstream in("evaluare.in");
ofstream out("evaluare.out");
const int N=100001;
int i;
char s[N];
int expresie();
int termen();
int factor();
int expresie()
{
    int sum=termen();
    while(s[i]=='+'||s[i]=='-')
    {
        if(s[i]=='+')
        {
            i++;
            sum+=termen();
        }
        else
        {
            i++;
            sum-=termen();
        }
    }
    return sum;
}
int termen()
{
    int prod=factor();
    while(s[i]=='*'||s[i]=='/')
    {
        if(s[i]=='*')
        {
            i++;
            prod*=termen();
        }
        else
        {
            i++;
            prod/=termen();
        }
    }
    return prod;
}
int factor()
{
    int val=0,semn=1;
    while(s[i]=='-')
    {
        i++;
        semn=-semn;
    }
    if(s[i]=='(')
    {
        i++;
        val=expresie();
        i++;
        return semn*val;
    }
    while(s[i]>='0'&&s[i]<='9')
    {
        val=val*10+(s[i]-'0');
        i++;
    }
    return semn*val;
}
int main()
{
    in.get(s,N);
    out<<expresie();
    return 0;
}
