#include <fstream>
using namespace std;
ifstream cin("evaluare.in");
ofstream cout("evaluare.out");
int n,i,nr;
char s[100005];
int ad();
int inm();
int numar()
{
    if(s[i]=='(')
    {
        i++;
        nr=ad();
        i++;
    }
    else
    {
        nr=0;
        while(s[i]>='0'&&s[i]<='9')
        {
            nr=nr*10+s[i]-'0';
            i++;
        }
    }
    return nr;
}
int inm()
{
    int nr=numar();
    while(s[i]=='*'||s[i]=='/')
        if(s[i]=='*')
    {
        i++;
        nr=nr*numar();
    }
    else
    {
        i++;
        nr=nr/numar();
    }
    return nr;
}
int ad()
{
    int nr=inm();
    while(s[i]=='+'||s[i]=='-')
        if(s[i]=='+')
    {
        i++;
        nr=nr+inm();
    }
    else
        if(s[i]=='-')
    {
        i++;
        nr=nr-inm();
    }
    return nr;
}
int main()
{
    cin.getline(s,100005);
    cout<<ad();
    return 0;
}
