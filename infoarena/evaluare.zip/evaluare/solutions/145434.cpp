#include <stdio.h>

#define MAXN 1000005

char expr[MAXN], *p;

inline int operation( int x, int y, char c )
{
	if (c == '+')
		return x + y;
	if (c == '-')
		return x - y;
	if (c == '*')
		return x * y;
	if (c == '/')
		return x / y;
	
	return -1;
}

inline int eval();

inline int factor()
{
	int rez;
	if (*p == '(')
	{
		p++;
		rez = eval();
		p++;
		return rez;
	}

	for (rez = 0; '0' <= *p && *p <= '9'; p++)
		rez = rez * 10 + *p - '0';
	return rez;
}

inline int termen()
{
	int rez = factor();

	for (; *p == '*' || *p == '/'; )
	{
		char op = *p;

		p++;
		rez = operation( rez, factor(), op );
	}
	return rez;
}

inline int eval()
{
	int rez = termen();

	for (; *p == '+' || *p == '-'; )
	{
		char op = *p;

		p++;
		rez = operation( rez, termen(), op );
	}
	return rez;
}

int main()
{
	freopen("evaluare.in", "rt", stdin);
	freopen("evaluare.out", "wt", stdout);

	scanf("%s", expr);

	p = expr;
	printf("%d\n", eval());

	return 0;
}
