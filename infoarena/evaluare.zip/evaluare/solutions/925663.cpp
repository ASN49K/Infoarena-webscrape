#include <string>
#include <cstdlib>
#include <fstream>


using namespace std;

const int levMax = 2;
const int ERROR = - (1 << 29);
const string op[] = {"+-", "*/", "^"};

inline int eval(char op, int a, int b)
{
    switch(op)
    {
        case '+' : return a + b;
        case '-' : return a - b;
        case '*' : return a * b;
        case '/' : return a / b;
    }
    return ERROR;
}

inline int eval(int level, string::iterator& it, string::iterator& iend)
{
    int x = 0;
    if(level == levMax)
    {
        if('(' == *it)
        {
            ++it;
            x = eval(0, it, iend);
            ++it;
        }
        else if(*it >= '0' && *it <= '9')
             {
                 for(x = 0; it != iend && *it >= '0' && *it <= '9'; ++it)
                 {
                     x = x * 10 + *it - '0';
                 }
             }
    }
    else {
            for(x = eval(level + 1, it, iend); it != iend && string::npos != op[level].find(*it); )
            {
                char op = *it;
                ++it;
                x = eval(op, x, eval(level + 1, it, iend));
            }
         }
    return x;
}

int main()
{
    string exp;
    string::iterator it, iend;
    ifstream in("evaluare.in");
    ofstream out("evaluare.out");

    getline(in, exp);
    it = exp.begin();
    iend = exp.end();
    out << eval(0, it, iend) << '\n';

    return EXIT_SUCCESS;
}
