#include <bits/stdc++.h>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int st[100005];

char s[100005];

/*
'(' = -1;
'+' = -2;
'-' = -3;
'*' = -4;
'/' = -5;
*/

int main()
{
    int i, top = 0, p, j, nr, k;
    fin >> s;
    for(i = 0; s[i]; )
    {
        if(s[i] == '(')
            st[++top] = -1, i++;
        if(s[i] == '+')
            st[++top] = -2, i++;
        if(s[i] == '-')
            st[++top] = -3, i++;
        if(s[i] == '*')
            st[++top] = -4, i++;
        if(s[i] == '/')
            st[++top] = -5, i++;
        if('0' <= s[i] && s[i] <= '9')
        {
            nr = 0;
            while('0' <= s[i] && s[i] <= '9')
                nr = nr * 10 + (s[i] - '0'), i++;
            st[++top] = nr;
        }
        if(s[i] == ')')
        {
            p = top;
            while(st[p] != -1)
                p--;
            p++;
            while(p != top)
            {
                for(j = p; j <= top; j++)
                {
                    if(st[j] == -4)
                    {
                        st[j - 1] = st[j - 1] * st[j + 1];
                        for(k = j; k <= top; k++)
                            st[k] = st[k + 2];
                        top -= 2;
                    }
                    else if(st[j] == -5)
                    {
                        st[j - 1] = st[j - 1] / st[j + 1];
                        for(k = j; k <= top; k++)
                            st[k] = st[k + 2];
                        top -= 2;
                    }
                }
                for(j = p; j <= top; j++)
                {
                    if(st[j] == -2)
                    {
                        st[j - 1] = st[j - 1] + st[j + 1];
                        for(k = j; k <= top; k++)
                            st[k] = st[k + 2];
                        top -= 2;
                    }
                    else if(st[j] == -3)
                    {
                        st[j - 1] = st[j - 1] - st[j + 1];
                        for(k = j; k <= top; k++)
                            st[k] = st[k + 2];
                        top -= 2;
                    }
                }
            }
            st[p - 1] = st[p];
            top--;
            i++;
        }
    }
    p = 1;
    while(p != top)
    {
        for(j = p; j <= top; j++)
        {
            if(st[j] == -4)
            {
                st[j - 1] = st[j - 1] * st[j + 1];
                for(k = j; k <= top; k++)
                    st[k] = st[k + 2];
                    top -= 2;
            }
            else if(st[j] == -5)
            {
                st[j - 1] = st[j - 1] / st[j + 1];
                for(k = j; k <= top; k++)
                    st[k] = st[k + 2];
                    top -= 2;
            }
        }
        for(j = p; j <= top; j++)
        {
            if(st[j] == -2)
            {
                st[j - 1] = st[j - 1] + st[j + 1];
                for(k = j; k <= top; k++)
                    st[k] = st[k + 2];
                    top -= 2;
            }
            else if(st[j] == -3)
            {
                st[j - 1] = st[j - 1] - st[j + 1];
                for(k = j; k <= top; k++)
                    st[k] = st[k + 2];
                    top -= 2;
            }
        }
    }
    st[p - 1] = st[p];
    top--;
    i++;
    fout << st[1] << "\n";
    fin.close();
    fout.close();
    return 0;
}
