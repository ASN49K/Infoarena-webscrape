#include<iostream>
#include<fstream>
#include<string>

using namespace std;


string S;
string::iterator it;
long eval();

long factor(){
	long r = 0;
	if (*it == '('){
		++it;
		r=eval();
		++it;
	}
	else{
		while (*it >= '0' && *it <= '9'){
			r = r * 10 + (*it - '0');
			if (it < S.end()-1) ++it;
			else break;
		}
	}

	return r;
}

long termen(){
	long r = factor();
	while (*it == '*' || *it == '/'){
		switch (*it){
		case '*': ++it;
			r *= factor();
			break;
		case '/': ++it;
			r /= factor();
			break;
		}
	}
	return r;

}

long eval(){
	long r = termen();
	while (*it == '+' || *it == '-'){
		switch (*it){
		case '+':++it;
			r += termen();
			break;
		case '-':++it;
			r -= termen();
			break;
		}
	}
	return r;
}


int main(){
	ifstream f("evaluare.in", ios::in);//Change the name
	ofstream g("evaluare.out", ios::out);//Change the name
	
	f >> S;
	it = S.begin();

	g<<eval()<<'\n';

	f.close();
	g.close();
}