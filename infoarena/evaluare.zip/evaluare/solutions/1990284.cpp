#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
int calcul(char op,int a,int b){
           if(op=='+')
              return a+b;
           if(op=='-')
              return a-b;
           if(op=='*')
              return a*b;
           return a/b;
}
int stn[100001],k1,k2,nr;
char sto[100001],pr[256],S[100001];
int main()
{
    fin>>S;
pr['(']=0;
pr['+']=pr['-']=1;
pr['*']=pr['/']=2;
for(int i=0;S[i]!=0;i++)
    if(S[i]=='(')
       sto[++k1]=S[i];
    else
       if(S[i]>='0'&&S[i]<='9'){
          nr=0;
          while(S[i]>='0'&&S[i]<='9'){
                nr=nr*10+(S[i]-'0');
                i++;}
          i--;
          stn[++k2]=nr;}
       else
          if(S[i]==')'){
             while(sto[k1]!='('){
                   int k=calcul(sto[k1],stn[k2-1],stn[k2]);
                   k1--;
                   k2--;
                   stn[k2]=k;}
             k1--;  }
          else{
             while(k1>0&&pr[S[i]]<=pr[sto[k1]]){
                   int k=calcul(sto[k1],stn[k2-1],stn[k2]);
                   k1--;
                   k2--;
                   stn[k2]=k;}
             sto[++k1]=S[i];}
while(k1>0){
      int k=calcul(sto[k1],stn[k2-1],stn[k2]);
          k1--;
          k2--;
          stn[k2]=k;}
fout<<stn[1];


    return 0;
}
