//  Evaluarea unei expresii

#include <fstream>
#include <string>
using namespace std;

ifstream cin("evaluare.in");
ofstream cout("evaluare.out");

int i;
string s;

int expresie();
int termen();

int factor()
{
    int ans=0;

    if(s[i]=='(') {i++; ans=expresie(); i++;}
    else { ans=ans*10 + s[i]-'0'; i++; }

    return ans;
}

int expresie()
{
    int ans=termen();
    while(s[i]=='+' || s[i]=='-')
    {
        if(s[i]=='+') {i++; ans+=termen(); }
        else { i++; ans-=termen(); }
    }
    return ans;
}

int termen()
{
    int ans=factor();
    while(s[i]=='*' || s[i]=='/')
    {
        if(s[i]=='*') { i++; ans*=factor(); }
        else { i++; ans/=factor(); }
    }
    return ans;
}

int main()
{
    cin>>s;
    cout<<expresie();
    return 0;
}
