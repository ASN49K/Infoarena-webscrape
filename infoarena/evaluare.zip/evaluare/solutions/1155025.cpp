#include <fstream>
#include <stack>
#include <string>
#include <sstream>
#include <vector>

#define PLUSZ   1000000001
#define MINUSZ  1000000002
#define SZOR    1000000003
#define OSZT    1000000004

using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");

inline bool szam (const char temp)
{
    if (temp > 47 && temp < 58) return 1;
    return 0;
}

string s;
vector<long long> kifejezes;
stack<char> verem;
stack<long long>  eredm;
istringstream be;

char temp;
inline long long beolvas_szam ()
{
    long long ret=0;
    while (szam(s[0]))
    {
        ret *= 10;
        ret += s[0]-'0';
        s.erase(0,1);
    }
    if (ret) return ret;
}

void kiir_kifejezes (const vector<long long>& t)
{
    for (vector<long long>::const_iterator i = t.begin(); i<t.end(); i++)
    {
        if (*i < 1000000001) g << " " << *i;
        else
        {
            if (*i == SZOR) g << '*';
            else if (*i == OSZT) g << '/';
            else if (*i == PLUSZ) g << '+';
            else if (*i == MINUSZ) g << '-';
        }
    }
}

int main()
{
    f >> s;
    s = '(' + s + ')';

    while (s.length())
    {
        if (szam(s[0])) kifejezes.push_back(beolvas_szam ());
        else if (s[0] == '(')
        {
            verem.push(s[0]);
            s.erase(0,1);
        }
        else if (s[0] == ')' || s[0] == '+' || s[0] == '-')
        {
            temp = verem.top();
            while (temp != '(')
            {
                if (temp == '+') kifejezes.push_back(PLUSZ);
                else if (temp == '-') kifejezes.push_back(MINUSZ);
                else if (temp == '*') kifejezes.push_back(SZOR);
                else kifejezes.push_back(OSZT);
                verem.pop();
                temp = verem.top();
            }
            if (s[0] == ')')
                verem.pop();
            else
                verem.push(s[0]);
            s.erase(0,1);
        }
        else
        {
            temp = verem.top();
            while (temp != '+' && temp != '-' && temp != '(')
            {
                if (temp == '+') kifejezes.push_back(PLUSZ);
                else if (temp == '-') kifejezes.push_back(MINUSZ);
                else if (temp == '*') kifejezes.push_back(SZOR);
                else kifejezes.push_back(OSZT);
                verem.pop();
                temp = verem.top();
            }
            verem.push(s[0]);
            s.erase(0,1);
        }
    }
    //kiir_kifejezes(kifejezes);
    //g << "\n\n";

    long long t, t2, muv;
    for (vector<long long>::iterator i = kifejezes.begin(); i<kifejezes.end(); i++)
    {
        t = *i;
        if (t < 1000000001)
        {
            eredm.push(t);
        }
        else
        {
            muv = t;
            t = eredm.top();
            eredm.pop();
            t2 = eredm.top();
            eredm.pop();
            if (muv == PLUSZ) eredm.push(t + t2);
            else if (muv == MINUSZ) eredm.push(t2 - t);
            else if (muv == OSZT) eredm.push(t2 / t);
            else eredm.push(t * t2);
        }
    }
    g << eredm.top();
}
