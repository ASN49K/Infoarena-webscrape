#include <iostream>
#include <fstream>
#include <string>
#include <stack>

using namespace std;

string A;
int pos = 0;

int factor();
int termen();

int eval() {
  int r = termen();
  while(A[pos] == '+' || A[pos] == '-') {
    if (A[pos] == '+') {
      pos++;
      r += termen();
    }
    else {
      pos++;
      r -= termen();
    }
  }
  return r;
}

int termen() {
  int r = factor();
  while(A[pos] == '*' || A[pos] == '/') {
    if (A[pos] == '*') {
      pos++;
      r *= factor();
    }
    else {
      pos++;
      r /= factor();
    }
  }
  return r;
}

int factor() {
  int r = 0;
  if (A[pos] == '(') {
    pos++;
    r = eval();
    pos++;
  }
  else {
    while(A[pos] >= '0' && A[pos] <= '9') {
      r = r*10 + A[pos] - '0';
      pos++;
    }
  }
  return r;
}

int main()
{
  ifstream f ("evaluare.in");
  ofstream g ("evaluare.out");
  f >> A;
  int result = eval();
  g << result << '\n';

  return 0;
}
