#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream f("evaluare2.in");
ofstream g("evaluare2.out");
char S[110],*p=S;
long long expresie();
long long termenimp();
long long termenput();
long long factor();

long long ogl(long long x) {
    long long cop=0;
    while(x) {
        cop=cop*10+x%10;
        x/=10;
    }
    return cop;
}

long long expresie() {
    long long r=termenimp();
    while(*p=='+') {
        p++;
        r+=termenimp();
    }
    return r;
}

long long termenimp() {
    long long r=termenput();
    while(*p=='/') {
        p++;
        r/=termenput();
    }
    return r;
}

long long termenput() {
    long long r=factor();
    while(*p=='^') {
        p++;
        r=pow(r,termenput());
    }
    return r;
}

long long factor() {
    long long r=0;
    if(*p=='(') {
        p++;
        r=expresie();
        p++;
    } else if(*p=='!') {
        p++;
        r=ogl(factor());
    } else {
        while('0'<=*p&&*p<='9') {
            r=r*10+*p-'0';
            p++;
        }
    }
    return r;
}

int main() {
    f.getline(S,110);
    g<<expresie();
    f.close();
    g.close();
    return 0;
}
