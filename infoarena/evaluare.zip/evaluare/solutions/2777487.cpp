#include<fstream>
#include<cstring>

using namespace std;

ifstream f("evaluare.in");
ofstream g("evaluare.out");

char s[100005];
int n,i;

int factor();
int termen();

int calcul()
{
    int x;
    x=termen();

    while(s[i]=='+' || s[i]=='-')
    {
        if(s[i]=='+')
        {
            i++;
            x+=termen();
        }
        else
        {
            i++;
            x-=termen();
        }
    }
    return x;
}

int termen()
{
    int x;
    x=factor();

    while(s[i]=='*' || s[i]=='/')
    {
        if(s[i]=='*')
        {
            i++;
            x*=factor();
        }
        else
        {
            i++;
            x/=factor();
        }
    }
    return x;
}

int factor()
{
   int x=0;

   if(s[i]=='(')
   {
       i++;
       x=calcul();
       i++;
   }
   else
   {
        while(s[i]>='0' && s[i]<='9')
        {
            x=x*10+(s[i]-48);
            i++;
        }
   }
   return x;
}



int main()
{
    f.getline(s+1,sizeof s);
    n=strlen(s+1);
    i=1;
    int sol;
    sol=calcul();
    g<<sol;
    return 0;
}

