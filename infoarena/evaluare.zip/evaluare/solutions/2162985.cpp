#include <cstdio>
#include <algorithm>
#include <vector>
using namespace std;
#define NMAX 100005
#define LOGMAX 30
#define pwr(x) (1 << x)
int n, m, sparce[NMAX*2 + 5][LOGMAX], LOGA[NMAX*2 + 5], poz[NMAX];
vector<int> a[NMAX], e, h;

void BuildEuler(int nod, int dist){
    int i;
    e.push_back(nod);
    h.push_back(dist);

    if(!poz[nod] && nod != 1)
        poz[nod] = h.size() - 1;

    for(i=0; i<(int) a[nod].size(); i++){
        BuildEuler( a[nod][i], dist + 1);
        e.push_back(nod);
        h.push_back(dist);
    }
}

int main(){
    int i, j, low, high, l, k, x, y;
    FILE *fin, *fout;
    fin = fopen("lca.in", "r");
    fout = fopen("lca.out", "w");

    fscanf(fin, "%d %d", &n, &m);
    for(i=2; i<=n; i++){
        fscanf(fin, "%d ", &k);
        a[k].push_back(i);
    }

    BuildEuler(1, 0);

    //sparce
    n = h.size();
    for(i=0; i<n; i++)
        sparce[i][0] = i;
    for(i=2; i<=n; i++)
        LOGA[i] = LOGA[i/2] + 1;
    for(j=1; pwr(j)<=n; j++){
        for(i=0; i + pwr(j) - 1<=n; i++){
            if(h[ sparce[i][j-1] ] < h[ sparce[i + pwr(j-1)][j-1] ])
                sparce[i][j] = sparce[i][j-1];
            else sparce[i][j] = sparce[i + pwr(j-1)][j-1];
        }
    }

    for(i=1; i<=m; i++){
        fscanf(fin, "%d %d", &x, &y);
        low = min( poz[x], poz[y] );
        high = max( poz[x], poz[y]);

        l = high - low + 1;
        k = LOGA[l];
        if(h[ sparce[low][k] ] < h[ sparce[low + l - pwr(k)][k] ])
            fprintf(fout, "%d\n", e[sparce[low][k]]);
        else fprintf(fout, "%d\n", e[sparce[low + l - pwr(k)][k]]);
    }

    return 0;
}
