#include <bits/stdc++.h>

using namespace std;
string s;
long long i;
long long solve_numar(),solve_expr(),solve_factor(),solve_termen();
long long solve_numar(){
    long long nr=0;
    while(isdigit(s[i])){
        i++;
        nr=nr*10+(s[i]-'0');
    }
    return nr;
}
long long solve_factor(){
    long long cnt=0;
    if(s[i]=='('){
        i++;
        cnt=solve_expr();
        i++;
    }
    else{
        i++;
        cnt=solve_numar();
    }
    return cnt;
}
long long solve_termen(){
    long long cnt=solve_factor();
    while(s[i]=='*'||s[i]=='/'){
        if(s[i]=='*'){
            i++;
            cnt*=solve_factor();
        }
        else{
            i++;
            cnt/=solve_factor();
        }
    }
    return cnt;
}
long long solve_expr(){
    long long cnt=solve_termen();
    while(s[i]=='+'||s[i]=='-'){
        if(s[i]=='+'){
            i++;
            cnt+=solve_termen();
        }
        else{
            i++;
            cnt-=solve_termen();
        }
    }
    return cnt;
}
int main(){
    ifstream fin("evaluare.in");
    ofstream fout("evaluare.out");
    fin>>s;
    fout<<solve_expr();
    return 0;
}
