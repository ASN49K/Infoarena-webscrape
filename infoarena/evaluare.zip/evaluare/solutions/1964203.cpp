#import<fstream>
std::ifstream f("evaluare.in");
std::ofstream g("evaluare.out");
char s[100005],*c=s;int E(),F(),T();
int F(){int R;
if(*c=='('){c++,R=E(),c++;}
else for(R=0;*c>='0';R=R*10+*(c++)-'0');
return R;}
int T(){int R=F();
while(*c=='*'||*c=='/')
if(*c=='*')c++,R*=F();
else if(*c=='/')c++,R/=F();return R;}
int E(){
int R=T();
while(*c=='+'||*c=='-')
if(*c=='-')c++,R-=T();
else if(*c=='+')c++,R+=T();return R;}
main(){f.get(s,100002);g<<E();}
