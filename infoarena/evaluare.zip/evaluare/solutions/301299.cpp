#include<fstream.h>
char S[100001];
long i;
long t();
long f();
long e();
int main()
{ifstream f("evaluare.in");
ofstream g("evaluare.out");
f.get(S,100001);
g<<e();
return 0;
}
long e()
{long x=t();
 while(S[i]=='+'||S[i]=='-')
  if(S[i]=='+')
  {++i;
   x=x+t();}
  else if(S[i]=='-')
  {++i;
   x=x-t();}
 return x;
}
long t()
{long x=f();
 while(S[i]=='*'||S[i]=='/')
  if(S[i]=='*')
  {++i;
   x=x*f();}
  else if(S[i]=='/')
  {++i;
   x=x/f();}
 return x;
}
long f()
{long x=0;
 if(S[i]=='(')
 {++i;
  x=e();
  ++i;}
 else
  while(S[i]>='0'&&S[i]<='9')
  {x=x*10+S[i]-'0';
   ++i;}
 return x;
}
