#include <fstream>
#include <deque>
#include <vector>
#include <bitset>
#include <queue>
#include <algorithm>
#include <cstring>
#include <climits>

#define MOD 1000000007

using namespace std ;

ifstream cin ("evaluare.in") ;
ofstream cout ("evaluare.out") ;

char *urm_elem(char *a, char *cautat, int n) /// cauta in intervalul *a cu n ultimul semn care apartine multimii cautat SI NU ESTE INTRO PARANTEZA
{                                            /// si returneaza un pointer la pozitia sa
    int aux = 0 ;

    for(int f = n - 1 ; f >= 0 ; f --)
    {
        if(a[f] == ')')aux ++ ;
            else if(a[f] == '(') aux -- ;

        if(!aux && strchr(cautat, a[f]))return &a[f] ;
    }

    return 0 ;
}

long long eval_exp(char *a, int n)
{
    char *ptr ;

    if(ptr = urm_elem(&a[0], "+-", n)) /// verifica daca exista un plus/minus in intervalul dat care nu este intre paranteze
    {                                  /// daca exista ptr devine un pointer spre acel semn
        if(*ptr == '+')return eval_exp(a, ptr - a) + eval_exp(ptr + 1, n - (ptr - a) - 1) ; /// face operatia
        if(*ptr == '-')return eval_exp(a, ptr - a) - eval_exp(ptr + 1, n - (ptr - a) - 1) ;
    }

    if(ptr = urm_elem(&a[0], "*/", n))
    {
        if(*ptr == '*')return eval_exp(a, ptr - a) * eval_exp(ptr + 1, n - (ptr - a) - 1) ;
        if(*ptr == '/')return eval_exp(a, ptr - a) / eval_exp(ptr + 1, n - (ptr - a) - 1) ;
    }

    if(a[0] != '(') /// la sfarsitul apelurilor recursive, vom avea o gramada de numere
    {
    string aux ;

    for(int f = 0 ; f < n ; f ++)
        aux += a[f] ;

    return atoll(&aux[0]) ;
    }

    /// evaluam o paranteza, desfacand-o
    while(a[0] == '(' && a[n - 1] == ')')n -= 2, a ++ ; /// scoatem parantezele useless

    eval_exp(a, n) ;
}

int main()
{
    string a ;

    cin >> a ;

    cout << eval_exp(&a[0], a.size()) ;

    return 0 ;
}
