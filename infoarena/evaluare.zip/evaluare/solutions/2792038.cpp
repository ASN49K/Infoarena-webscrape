#include <bits/stdc++.h>

using namespace std;

int NR(char* &str)
{
    long long ans = 0;
    while('0' <= *str and *str <= '9')
    {
        ans= ans * 10 + (*str - '0');
        str ++;
    }
    ///cout << ans << '\n';
    return ans;
}
int E(char* &str);
int F(char* &str)
{
    int ans = 0;
    if (*str == '(')
    {
        str++; // '('
        ans = E(str);
        str++; // ')'
    }
    else
    {
        ans = NR(str);
    }
    return ans;
}
int T(char* &str);
int E(char* &str)
{
    int ans = T(str);
    while  (*str == '-' or *str == '+')
    {
        if ( *str == '-' )
        {
            str ++; // '-'
            ans -= T(str);
        }
        else
        {
            str ++; // '+'
            ans += T(str);
        }
    }
    return ans;
}

int T(char* &str)
{
    int ans = F(str);
    while (*str == '*' or *str == '/')
    {
        if (*str == '*')
        {
            str++; //'*'
            ans *= F(str);
        }
        else
        {
            str++;
            ans /= F(str);
        }
    }
    return ans;
}

int main()
{
    ifstream cin("evaluare.in");
    ofstream cout("evaluare.out");

    char s[10000];
    cin.get(s,10000);
    int n = strlen(s);
    char* p = s;
    int nr = E(p);
    cout << nr;

    return 0;
}
