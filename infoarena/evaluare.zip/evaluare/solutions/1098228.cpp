#include <cstdio>

using namespace std;
char c[100005],*p;

int eval();
int factor();
int termeni();

int factor()
{
    int r;
    if(*p == '(')
    {
        ++p;
        r = eval();
        ++p;
    }
    else
    {
        r = 0;
        while('0' <= *p && *p <= '9')
        {
            r = r * 10 + *p - 48;
            ++p;
        }
    }
    return r;
}

int termeni()
{
    int r;
    r = factor();
    while(*p == '*' || *p == '/')
    {
        if(*p == '*')
        {
            ++p;
            r = r * factor();
        }
        else
        {
            ++p;
            r = r / factor();
        }
    }
    return r;
}

int eval()
{
    int r;
    r = termeni();
    while(*p == '+' || *p == '-')
    {
        if (*p == '+')
        {
            ++p;
            r = r + termeni();
        }
        else
        {
            ++p;
            r = r - termeni();
        }
    }
    return r;
}

int main()
{
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);

    scanf("%s",c);
    p = c;
    printf("%d",eval());

    return 0;
}
