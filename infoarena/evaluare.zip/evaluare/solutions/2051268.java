import java.util.LinkedList;
import java.util.Stack;
import java.util.*;
import java.io.*;

class Reader {
    private BufferedReader br;

    public Reader() {
        try {
            br = new BufferedReader(new FileReader("evaluare.in"));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public String readFromFile() {
        String res = "";
        try {
            String line = br.readLine();
            res = line;
        } catch (Exception e) {
            System.out.println(e);
        }
        return res;
    }

    public void closeFile() {
        try {
            br.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}

class Writer {
}

class Expresie {
    private String expr;
    private int i = 0;

    public Expresie(String expr) {
        this.expr = expr;
    }

    public double eval() {
        double r = termen();

        while (expr.charAt(i) == '+' || expr.charAt(i) == '-') {
            char c = expr.charAt(i);
            switch (c) {
            case '+':
                i++;
                r += termen();
                break;
            case '-':
                i++;
                r -= termen();
            }
            if (i == expr.length())
                break;
        }

        return r;
    }

    private double termen() {
        double r = factor();
        while (expr.charAt(i) == '*' || expr.charAt(i) == '/') {
            int c = expr.charAt(i);
            switch (c) {
            case '*':
                i++;
                r *= factor();
                break;
            case '/':
                i++;
                r /= factor();
                break;
            }
            if (i == expr.length())
                break;
        }

        return r;
    }

    private double factor() {
        double r = 0;
        if (expr.charAt(i) == '(') {
            i++;
            r = eval();
            i++;
        } else {
            while (expr.charAt(i) >= '0' && '9' >= expr.charAt(i)) {
                r = r * 10 + Character.getNumericValue(expr.charAt(i));
                i++;
                if (i == expr.length())
                    break;
            }
        }
        return r;
    }

}

class Main {
    public static void main(String[] args) {
        Reader r = new Reader();
        Expresie expr = new Expresie(r.readFromFile());
        double result = expr.eval();

        try{
            PrintWriter writer = new PrintWriter("evaluare.out", "UTF-8");
            writer.print(result);
            writer.close();
        }catch(Exception e) {}
    }
}