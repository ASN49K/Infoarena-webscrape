#include <cstdio>
#include <cstring>
#define LMAX 2
#define NX 100010
using namespace std;
char S[NX], *p = S;
char op[4][4] = { "+-", "*/", "^", "" };

int eval( int a, int b, char o )
{
    switch( o )
    {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b;
    }
}

int expr( int lev )
{
    int x, y;
    if( lev == LMAX )
        if( *p == '(' )
            ++p, x = expr(0), ++p;
        else
            for( x = 0; *p >= '0' && *p <= '9'; ++p )
                x = x * 10 + *p - '0';
    else
        for( x = expr(lev+1); strchr(op[lev], *p); x = y )
            y = eval( x, expr(lev+1), *p++ );
    return x;
}

int main() {
    fgets( S, NX, fopen( "evaluare.in", "r" ) );
    fprintf( fopen( "evaluare.out", "w" ), "%d\n", expr(0) );
    return 0;
}
