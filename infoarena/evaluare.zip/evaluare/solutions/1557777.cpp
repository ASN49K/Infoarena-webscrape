#include<cstdio>
int t,i,j,k,l,m,n;
int cmmdc(int a,int b)
    {
    int r;
    while(b!=0)
        {
        r=a%b;
        a=b;
        b=r;
        }
    return a;
    }
int main ()
{
freopen("evaluare.in","r",stdin);
freopen("evaluare.out","w",stdout);
scanf("%d",&t);
for(j=1;j<=t;j++)
    {
    scanf("%d",&n);
    int x,y;
    scanf("%d%d",&x,&y);
    y/=cmmdc(x,y);
    for(i=3;i<=n;i++)
        {
        scanf("%d",&x);
        y/=cmmdc(x,y);
        }
    if(y==1)
        printf("1\n");
    else
        printf("0\n");
    }
return 0;
}
