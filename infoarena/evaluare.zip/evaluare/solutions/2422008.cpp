#include <bits/stdc++.h>
#define Dim 100007
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
int Expresie();
int Termen();
int Factor();
char S[Dim];
int index;

int Expresie()
{
    int r=Termen();
    while(S[index]=='+'||S[index]=='-')
    {
        index++;
        if(S[index-1]=='+') r+=Termen();
        else r-=Termen();
    }
    return r;
}

int Termen()
{
    int r=Factor();
    while(S[index]=='/'||S[index]=='*')
    {
        index++;
        if(S[index-1]=='/') r/=Factor();
        else r*=Factor();
    }
    return r;
}

int Factor()
{
    int sgn=1;
    while(S[index]=='-') sgn=-sgn,index++;

    if(S[index]=='(')
    {
        index++;
        int r=Expresie();
        index++;
        return r*sgn;
    }
    int r=0;

    while(S[index]>='0'&&S[index]<='9')
    r=r*10+(S[index]-'0'),index++;

    return r;
}

int main()
{
    freopen("evaluare.in","r",stdin); freopen("evaluare.out","w",stdout);
        cin.getline(S,Dim);
    g<<Expresie();

    return 0;
}
