#include <stdio.h>
#include <ctype.h>
FILE *fin,*fout;
char ch;

int e();

int num(){
  int r=0;

  while(isdigit(ch)){
    r=r*10+ch-'0';
    ch=fgetc(fin);
  }
  return r;
}

int f(){
  int r;
  ch=fgetc(fin);
  if(ch=='('){
      r=e();
      ch=fgetc(fin);
  }else
    r=num();
  return r;
}

int t(){
  int r=f();
  while(ch=='*' || ch=='/'){
    if(ch=='*')
      r*=f();
    else
      r/=f();
  }
  return r;
}

int e(){
  int r=t();
  while(ch=='+' || ch=='-'){
    if(ch=='+')
      r+=t();
    else
      r-=t();
  }
  return r;
}

int main(){
  fin=fopen("evaluare.in","r");
  fout=fopen("evaluare.out","w");

  fprintf(fout,"%d\n",e());
  fclose(fin);
  fclose(fout);
  return 0;
}
