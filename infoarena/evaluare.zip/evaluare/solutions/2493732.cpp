#include <bits/stdc++.h>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int addOrSub(string input, int &position);
int factor(string input, int &position);
int term(string input, int &position);


int evaluate(string input)
{
    int position = 0;
    return addOrSub(input, position);
}

int addOrSub(string input, int &position)
{
    int result = factor(input, position);

    while (position < input.size() && (input[position] == '+' || input[position] == '-'))
    {
        if (input[position] == '+')
        {
            position++;
            result = result + factor(input, position);
        }
        else if (input[position] == '-')
        {
            position++;
            result = result - factor(input, position);
        }
    }
    return result;
}

int factor(string input, int &position)
{
    int result = term(input, position);
    while (position < input.size() && (input[position] == '*' || input[position] == '/'))
    {
        if (input[position] == '*')
        {
            position++;
            result = result * factor(input, position);
        }
        else if (input[position] == '/')
        {
            position++;
            result = result / factor(input, position);
        }
    }
    return result;
}

int term(string input, int &position)
{
    int result = 0;

    if (input[position] == '(')
    {
        position++; /// '('
        result = addOrSub(input, position);
        position++; /// ')'
        return result;
    }
    while (position < input.size() && '0' <= input[position] && input[position] <= '9')
    {
        result = result * 10 + (input[position] - '0');
        position++;
    }
    return result;
}

int main()
{
    string input;
    fin >> input;
    fout << evaluate(input);

    return 0;
}
