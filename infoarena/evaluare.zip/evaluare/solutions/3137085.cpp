#include <fstream>
using namespace std;
ifstream cin("evaluare.in");
ofstream cout("evaluare.out");
int op[100001],k1,k2;
char semn[100001],s[100002],pr[256];
int calcul(char o,int x,int y){
    if(o=='+')
        return x+y;
    if(o=='-')
        return x-y;
    if(o=='/')
        return x/y;
    if(o=='*')
        return x*y;
}
int main()
{
    cin>>s;
    pr['+']=1,pr['-']=1;
    pr['*']=2,pr['/']=2;
    for(int i=0;s[i]!=0;i++)
    {
        if(s[i]=='(')
            semn[++k1]=s[i];
        else
            if(s[i]>='0'&&s[i]<='9')
        {
            int nr=0;
            while(s[i]>='0'&&s[i]<='9')
            {
             nr=nr*10+s[i]-'0';
                    i++;
            }
            op[++k2]=nr;
            i--;
        }
        else
            if(s[i]==')')
        {
            while(semn[k1]!='(')
            {
                int rez=calcul(semn[k1],op[k2-1],op[k2]);
                k1--;
                k2--;
                op[k2]=rez;
            }
            k1--;
        }
        else
        {
            while(k1>0&&pr[s[i]]<=pr[semn[k1]])
            {
                int rez=calcul(semn[k1],op[k2-1],op[k2]);
                k1--;
                k2--;
                op[k2]=rez;
            }
            semn[++k1]=s[i];
        }
    }
    while(k1>0)
    {
                int rez=calcul(semn[k1],op[k2-1],op[k2]);
                k1--;
                k2--;
                op[k2]=rez;
    }
    cout<<op[1];
    return 0;
}
