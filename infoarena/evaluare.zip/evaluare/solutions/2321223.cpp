#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
string eq;
int rez,i,num,sg;
bool fo=false;
char s;
int eval(),get_exp();
int get_num();
int main() {
    fin>>eq;
    int len=eq.size();
    fout<<eval();
    return 0;
}
int eval(){
    int sum=get_exp();
    while (eq[i]=='+' || eq[i]=='-'){
        ++i;
        if (eq[i-1]=='+'){
            sum+=get_exp();
        } else {
            sum-=get_exp();
        }
    }
    return sum;
}
int get_exp(){
    int prod=get_num();
    while (eq[i]=='*' || eq[i]=='/'){
        ++i;
        if (eq[i-1]=='*'){
            prod*=get_num();
        } else {
            prod/=get_num();
        }
    }
    return prod;
}
int get_num(){
    int sg,ret=0;
    if (eq[i]=='-'){
        sg=-1;
        ++i;
    } else sg=1;
    if (eq[i]=='('){
        ++i;
        ret=eval();
        ++i;
        return sg*ret;
    }
    while ('0'<=eq[i] && eq[i]<='9'){
        ret=ret*10+(eq[i]-'0');
        ++i;
    }
    return sg*ret;
}
