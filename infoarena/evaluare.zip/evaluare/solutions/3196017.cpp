#include <bits/stdc++.h>
using namespace std;
string str;
int pos;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int eval();
int termen();
int factor();

int main()
{
    fin >> str;
    fout << eval();
    return 0;
}

int eval(){
    int ans = termen();
    while(str[pos] == '+' || str[pos] == '-'){
        if(str[pos] == '+'){
            pos++;
            ans += termen();
        }else{
            pos++;
            ans -= termen();
        }
    }
    return ans;
}

int termen(){
    int ans = factor();
    while(str[pos] == '*' || str[pos] == '/'){
        if(str[pos] == '*'){
            pos++;
            ans *= factor();
        }else{
            pos++;
            ans /= factor();
        }
    }
    return ans;
}

int factor(){
    int ans = 0;
    if(str[pos] == '('){
        pos++;
        ans = eval();
        pos++;
    }else{
        while(isdigit(str[pos])){
            ans *= 10;
            ans += (str[pos]-'0');
            pos++;
        }
    }
    return ans;
}
