#include <cstdio>
#include <cstring>

using namespace std;

int poz, n;
char s[1000010];

int sayiAl()
{
    int S = 0;
    for(; '0' <= s[poz] && s[poz] <= '9'; ++poz)
    {
        S*= 10;
        S+= s[poz] - '0';
    }

    return S;
}

int coz()
{
    int S = 0, p = 1;

    while(s[poz] != ')')
    {
        if(s[poz] == '(')
        {
            ++poz;
            p*= coz();
        }
        else if(s[poz] == '*')
            ++poz;
        else if(s[poz] == '/')
        {
            ++poz;
            if(s[poz] = '(')
            {
                ++poz;
                p/= coz();
            }
            else p/= sayiAl();
        }
        else if('0' <= s[poz] && s[poz] <= '9')
            p*= sayiAl();
        else if(s[poz] == '+')
        {
            S+= p;
            p = 1;
            ++poz;
        }
        else if(s[poz] == '-')
        {
            S= p;
            p = -1;
            ++poz;
        }
    }
    S+= p;
    ++poz;

    return S;
}

int main()
{
    freopen("evaluare.in", "r", stdin);
    freopen("evaluare.out", "w", stdout);
    scanf("%s", &s);
    n = strlen(s);
    s[n] = ')';
    printf("%d", coz());
}
