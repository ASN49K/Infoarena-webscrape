#include<fstream.h>
ifstream f("evaluare.in");
ofstream g("evaluare.out");
char s[100005],stiva[100005],pol[100005][11];
int vf,n;
long v[500001];
int prioritate(char c)
{   if(c=='(') return 0;
	if(c=='+' || c=='-') return 1;
	if(c=='_')return 3; 
	return 2;
}

int main()
{ int i,k=0,j;
  s[0]='(';
  f.getline(s+1,100002);
  n=strlen(s);
  s[n++]=')';
  s[n]='\0';
  for(i=0;i<n;i++)
	 { if(s[i]=='(')stiva[++vf]='(';
	    else if(s[i]==')'){while(stiva[vf]!='(') pol[++k][0]=stiva[vf--],pol[k][1]=0;vf--;}
			else 	 
			  if(s[i]>='0' && s[i]<='9')
			  { ++k;
			    j=0;
				while(s[i]>='0' && s[i]<='9') pol[k][j++]=s[i++];
                pol[k][j]=0;				
				i--;
									
			  }
				    else //operator
						{ if(s[i]=='-'&& s[i-1]=='(')s[i]='_';
						  while (prioritate(stiva[vf])>=prioritate(s[i])) pol[++k][0]=stiva[vf--],pol[k][1]=0;
					      stiva[++vf]=s[i];
						}
	   }
  
 // g<<s<<'\n';
 // for(i=1;i<=k;i++) g<<pol[i]<<' ';
 //g<<'\n'; 
  // evaluarea expresiei
   vf=0;
    for(i=1;i<=k;i++)
		switch(pol[i][0])
{ case '_':v[vf]=-v[vf];break;
	  case '+':v[vf-1]+=v[vf],vf--;break;
	  case '-':v[vf-1]-=v[vf],vf--;break;
      case '*':v[vf-1]*=v[vf],vf--;break;
      case '/':v[vf-1]/=v[vf],vf--;break;
  default:
	  v[++vf]=atol(pol[i]);
		}
  g<<v[1]<<'\n';  
  f.close(); g.close();
  return 0;
}
  