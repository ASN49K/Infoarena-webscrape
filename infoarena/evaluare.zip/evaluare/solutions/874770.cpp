#include <iostream>
#include<fstream>
#include<cstring>
using namespace std;
char s[100002];
int n;
void calibrare(int &p, int &q)
{
    int ok,c,i;
      do
        {
            ok=1;
            if(s[p]=='(')
            {
                c=1;
                i=p;
                while(c!=0)
                {
                    i++;
                    if(s[i]=='(') c++;
                    else if(s[i]==')') c--;
                }
                if(i==q)
                {
                    p++;q--;ok=0;
                }
            }
        }
        while(!ok);
}
int caut_ul_op(int p, int q)
{
    int c,pm,ii,i;
    c=0;
    pm=-1;
    ii=-1;
    for(i=p;i<=q;i++)
    {
        if(s[i]=='(') c++;
        if(s[i]==')') c--;
        if (c==0)
        {
            if(s[i]=='+' || s[i]=='-') pm=i;
            if(s[i]=='/' || s[i]=='*') ii=i;
        }
    }
    if(pm!=-1) return pm;
    else return ii;
}
int nr(int p,int q)
{
    int i,x;
    x=0;
    for(i=p;i<=q;i++)
        x=x*10+s[i]-'0';
    return x;
}
int expresie(int p, int q)
{
    int k,v1,v2,v;
    calibrare(p,q);
    k=caut_ul_op(p,q);
    if(k==-1) return nr(p,q);
    v1=expresie(p,k-1);
    v2=expresie(k+1,q);
    v=v1+v2;
    if(s[k]=='-') v=v1-v2;
    if(s[k]=='*') v=v1*v2;
    if(s[k]=='/') v=v1/v2;
    return v;
}
int main()
{
    ifstream fin("evaluare.in");
    ofstream fout("evaluare.out");
    fin.get(s,100002,'\n');
    n=strlen(s);
    fout<<expresie(0,n-1);
    fout.close();
    return 0;
}
