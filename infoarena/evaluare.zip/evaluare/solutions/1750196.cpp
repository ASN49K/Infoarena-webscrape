#include <fstream>
#define maxn 100005
using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char sir[maxn], *p;

long long termen();
long long factor();

long long eval() {
    long long val = termen();
    while ( *p=='+' || *p=='-' ) {
        if (*p == '+') {
            p++;
            val = val + termen();
        }
        else {
            p++;
            val = val - termen();
        }
    }
    return val;
}

long long termen() {
    long long val = factor();
    while ( *p=='*' || *p=='/' ) {
            if (*p == '*') {
                p++;
                val = val * factor();
            }
            else {
                p++;
                val = val / factor();
            }

    }
    return val;
}

long long factor() {
    long long val = 0;
    if ( *p == '(' ) {
        ++p;
        val = eval();
        p++;
    }
    else {
        while ( *p >= '0' && *p <= '9') {
            val = val * 10 + *p - '0';
            p++;
        }
    }
    return val;
}

int main()
{
    p = sir;
    fin.get(sir, 100005);
    fout << eval();
    return 0;
}
