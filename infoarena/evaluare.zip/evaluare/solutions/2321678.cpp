#include <bits/stdc++.h>

FILE*fi;

int v[100000];

int k=0;

int expresie();
int factor();
int termen();

int expresie()
{
    int q=factor();
    while(v[k]=='+' || v[k]=='-')
    {
        if(v[k]=='+')
        {
            k++;
            q+=factor();
        }
        else
        {
            k++;
            q-=factor();
        }
    }
    return q;
}

int factor()
{
    int q=termen();
    while(v[k]=='*' || v[k]=='/'){
        if(v[k]=='*'){
            k++;
            q*=termen();
        }
        else if(v[k]=='/'){
            k++;
            q/=termen();
        }
    }
    return q;
}

int termen()
{
    int q=0;
    while(v[k]=='(')
    {
        k++;
        q=expresie();
        k++;
        return q;
    }
    while(v[k]>='0' && v[k]<='9'){
        q=q*10+v[k]-'0';
        k++;
    }
    return q;
}

int main()
{
    int n=0;
    char c;
    FILE*fo;
    fi=fopen("evaluare.in","r");
    fo=fopen("evaluare.out","w");
    c=fgetc(fi);
    while(c!='\n' && c!=EOF)
    {
        v[n]=c;
        n++;
        c=fgetc(fi);
    }
    fprintf(fo,"%d",expresie());
    fclose(fi);
    fclose(fo);
    return 0;
}
