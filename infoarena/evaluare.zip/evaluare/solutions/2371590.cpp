#include<iostream>
#include <fstream>
#include <cstring>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char v[100100];
int n,i;
int expresie();
int termen();
int factor();
int expresie()
{
    int r=termen();
    while(v[i]=='+'||v[i]=='-')
    {
        if(v[i]=='+')
        {
            i++;
            r+=termen();
        }
        else
        {
            i++;
            r-=termen();
        }
    }
    return r;
}
int termen()
{
    int r=factor();
    while(v[i]=='*'||v[i]=='/')
    {
        if(v[i]=='*')
        {
            i++;
            r*=factor();
        }
        else
        {
            i++;
            r/=factor();
        }
    }
    return r;
}
int factor()
{
    int r;
    if(v[i]=='(')
    {
        i++;
        r=expresie();
        i++;
    }
    else
    {
    r=0;
    while(v[i]>='0'&&v[i]<='9') r=r*10+v[i]-'0',i++;
    }
    return r;
}
int main()
{
    fin>>(v+1);
    n=strlen(v+1);
    i=1;
    fout<<expresie();
    return 0;
}
