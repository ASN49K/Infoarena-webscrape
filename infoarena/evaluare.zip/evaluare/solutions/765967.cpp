#include <iostream>
#include<string.h>
#include<stdio.h>

//Program pentru forma poloneza la dreapta*


char s[100002];

long long int i,d,f=1,stv,stv2,stiva2[100002];
char final[100002],stiva[100002];


int prior(char c)
{

    switch(c)
    {
        case '*':
        return 3;
        break;

        case '/':
        return 2;
        break;

        case '-':
        return 1;
        break;

        default:
        return 0;
}
}

int gasit(char c)
{
  char p[]="+-*/";
  int j;
  for(j=0; j<4; j++)if(p[j]==c)return 1;

  return 0;

}




using namespace std;

int main()
{
freopen("evaluare.in","r",stdin);
freopen("evaluare.out","w",stdout);


cin>>s;
long long int lun=strlen(s);


while(i<lun)
{

  if(s[i]>='0' && s[i]<='9'){ final[f]=s[i]; f++;  }
  if(s[i]=='('){ stv++; stiva[stv]='('; }

  if(gasit(s[i])){


final[f]=' '; f++;
      if(stv){ while(stiva[stv]!='(' && prior(s[i])<prior(stiva[stv])){ final[f]=stiva[stv]; f++; stv--;    }} stv++; stiva[stv]=s[i];    }

  if(s[i]==')')
  {


      while(stiva[stv]!='('){ final[f]=stiva[stv]; f++; stv--;    }
      stv--;
 }



i++;
}

while(stv)
{
  final[f]=stiva[stv];
  f++;
  stv--;


}
//gata formna dreapta poloneza





long long int sm=0;

for(i=1; i<f; i++)
{
  //cout<<final[i];


    if(final[i]>='0' && final[i]<='9'){  sm=sm*10+final[i]-48; }
    if( (final[i]<'0' || final[i]>'9') && (final[i-1]>='0' && final[i-1]<='9') ){ stv2++; stiva2[stv2]=sm; sm=0;  }
    if(final[i]=='+'){  long int aux; aux=stiva2[stv2]+stiva2[stv2-1];stv2--; stiva2[stv2]=aux;    }
    if(final[i]=='-'){  long int aux; aux=stiva2[stv2-1]-stiva2[stv2];stv2--; stiva2[stv2]=aux;   }
    if(final[i]=='*'){  long int aux; aux=stiva2[stv2]*stiva2[stv2-1];stv2--; stiva2[stv2]=aux;  }
    if(final[i]=='/'){  long int aux; aux=stiva2[stv2-1]/stiva2[stv2];stv2--; stiva2[stv2]=aux;   }

}

cout<<stiva2[1];


    return 0;
}
