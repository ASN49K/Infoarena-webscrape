#include <iostream>
#include <fstream>
#include <stack>
#include <cstring>
using namespace std;
char s[100005];
int p=0;
stack <char> op;
stack <int> nr;
int eval(int x, int y, char semn)
{
switch (semn)
{
case '+': return x+y;
case '-': return x-y;
case '*': return x*y;
case '/': return x/y;
}
}

int nextnum()
{
int numar=0;
while(s[p]>='0' && s[p]<='9')
numar=numar*10+(s[p++]-'0');
return numar;
}
int prioritate(char s1, char s2)
{
if(s1=='(')
return 1;
if((s1=='-' || s1=='+') && (s2=='*' || s2=='/'))
return 1;
return 0;
}

int main()
{
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
fin.getline(s,100005);
int n=strlen(s);
while(p<n)
{
switch (s[p])
{
case '(':{op.push(s[p++]);break;}
case')':{
while(op.top()!='(')
{
int v2=nr.top();
nr.pop();
int v1=nr.top();
nr.pop();
char semn=op.top();
op.pop();
nr.push(eval(v1,v2,semn));
}
op.pop();
p++;
break;
}
case'+':
case'-':
case'*':
case'/':{
if(op.empty() || prioritate(op.top(),s[p])==1)
{
op.push(s[p++]);
}
else
{
do{
int v2=nr.top();
nr.pop();
int v1=nr.top();
nr.pop();

char semn=op.top();
op.pop();
nr.push(eval(v1,v2,semn));
}while(!op.empty() && prioritate(op.top(),s[p])==0);
op.push(s[p++]);
}
break;
}
default :{
nr.push(nextnum());
}
}
}
while(!op.empty())
{
int v2=nr.top();
nr.pop();
int v1=nr.top();
nr.pop();
char semn=op.top();
op.pop();
nr.push(eval(v1,v2,semn));
}
fout<<nr.top();
return 0;
}
