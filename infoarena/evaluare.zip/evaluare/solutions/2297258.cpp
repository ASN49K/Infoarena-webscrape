
#include    <fstream>
#include    <string.h>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char c, semn[100005], st[100005];

int i, n, k, nr, gasitnr, fp[100005];

long long steval[100];

int main()
{
    while(fin >> c)
    {
        if(c >= '0' && c <= '9')
        {
            gasitnr =  1;
            nr = nr * 10 + (c - 48);
        }
        else
        {
            if(gasitnr)
            {
                n++;
                fp[n] = nr;
                nr = 0;
                gasitnr = 0;
            }
            if(c == '(' || c == '+' || c == '-' || c == '*' || c == '/')
            {
                k++;
                st[k] = c;
                if(st[k] == '+' || st[k] == '-')
                {
                    while(st[k-1] == '+' || st[k-1] == '-' || st[k-1] == '*' || st[k-1] == '/')
                    {
                        n++;
                        semn[n] = st[k-1];
                        st[k-1] = st[k];
                        k--;
                    }
                }
                if(st[k] == '*' || st[k] == '/')
                {
                    while(st[k-1] == '*' || st[k-1] == '/')
                    {
                        n++;
                        semn[n] = st[k-1];
                        st[k-1] = st[k];
                        k--;
                    }
                }
            }
            else if(c == ')')
            {
                while(st[k] != '(')
                {
                    n++;
                    semn[n] = st[k];
                    k--;
                }
                k--;
            }
        }
    }
    fin.close();
    if(gasitnr)
    {
        n++;
        fp[n] = nr;
        nr = 0;
        gasitnr = 0;
    }
    while(k)
    {
        n++;
        semn[n] = st[k];
        k--;
    }
    k = 0;
    for(i = 1; i <= n; i++)
    {
        if(semn[i] != '+' && semn[i] != '-' && semn[i] != '*' && semn[i] != '/')
        {
            k++;
            steval[k] = fp[i];
        }
        else
        {
            switch(semn[i])
            {
            case '+':
                steval[k-1] += steval[k];
                break;
            case '-':
                steval[k-1] -= steval[k];
                break;
            case '*':
                steval[k-1] *= steval[k];
                break;
            case '/':
                steval[k-1] /= steval[k];
                break;
            }
            k--;
        }
    }
    fout << steval[1];
    fout.close();
    return 0;
}
