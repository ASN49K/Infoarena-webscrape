#include<stdio.h>
#include<string.h>
char s[100013],*p; //in pascal, in loc de char *p; va fi int i; si se va folosi s[i], este variabila cu care parcurgem stringul
int n;
int eval();
int termen();
int factor();
//functiile vor fi definite dupa functia main()
int main()
{
        freopen("evaluare.in","r",stdin);
        freopen("evaluare.out","w",stdout);
        gets(s);
        p=s;
        n=eval();
        printf("%d\n",n);
}
int eval()//calculeaza valoarea unui sir de adunari / scaderi aflate intre paranteze
{
        int r;
        r=termen();//calculam primul element al sirului de adunari / scaderi
        while(*p=='+'||*p=='-')//se repeta operatiile cat timp mai sunt adunari si scaderi de efectuat
        switch (*p)
        {
        case '+':
                {
                        ++p;
                        r+=termen();//adunam la rezultat valoarea urmatorului element din sirul de adunari / scaderi
                        break;
                }
        case '-':
                {
                        ++p;
                        r-=termen();//scadem din rezultat valoarea urmatorului element din sirul de adunari / scaderi
                        break;
                }
        }
        return r;
}
int termen()//calculeaza valoarea unui sir de inmultiri/ impartiri
{
        int r;
        r=factor();//calculam primul element al sirului de inmultiri / impartiri
        while(*p=='*'||*p=='/')//se repeta operatiile cat timp mai sunt inmultiri si impartiri de efectuat
        switch(*p)
        {
        case '*':
                {
                        ++p;
                        r*=factor();//inmultim rezultatul cu valoarea numarului sau parantezei ce urmeaza in sirul de inmultiri / impartiri
                        break;
                }
        case '/':
                {
                        ++p;
                        r/=factor();//impartim rezultatul la valoarea numarului sau parantezei ce urmeaza in sirul de inmultiri / impartiri
                        break;
                }
        }
        return r;
}
int factor()
{
        int r;
        r=0;
        if(*p=='(') //inseamna ca urmeaza un sir de paranteze
        {
                ++p;//trecem de '('
                r=eval();//calculam valoarea parantezei
                ++p;//trecem de ')'
        }
        else//daca else atunci e un numar si il calculam
        {
                while('0'<=*p && *p<='9')
                {
                        r*=10;
                        r+=(int)*p-'0';
                        ++p;
                }
        }
        return r;
}
