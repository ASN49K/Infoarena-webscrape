#include <iostream>
#include <fstream>

#define NMAX 100000

using namespace std;

string s ;
int pointer ;

int Factor () ;
int Termen() ;
int Expresie() ;

int Factor () {
  int ok = 0 ;
  int r = 0 ;
  int semn = 1 ;
  if (s[pointer] == '-' ) {
    semn = -1 ;
    pointer++;
  }
  while (s[pointer] >= '0' && s[pointer] <= '9' ) {
    r = r * 10 + (s[pointer] - '0') ;
    ok = 1 ;
    pointer++;
  }
  if (ok == 0 ) {
    pointer++; /// '('
    r = Expresie() ;
    pointer++; /// ')'
  }
  return r ;
}

int Termen() {
  int prod ;
  prod = Factor() ;
  while (s[pointer] == '*' || s[pointer] == '/') {
    if (s[pointer] == '*' ) {
      pointer++;
      prod = prod * Factor() ;
    }
    else if (s[pointer] == '/' ) {
      pointer++;
      prod = prod / Factor() ;
    }
  }
  return prod ;
}

int Expresie () {
  int suma ;
  suma = Termen() ;
  while (s[pointer] == '+' || s[pointer] == '/') {
    if (s[pointer] == '+' ) {
      pointer++;
      suma = suma + Termen() ;
    }
    else if (s[pointer] == '-') {
      pointer++;
      suma = suma - Termen() ;
    }
  }
  return suma ;
}

int main() {

  ifstream fin ("evaluare.in") ;
  ofstream fout ("evaluare.out") ;
  fin >> s ;
  pointer = 0 ;
  fout << Expresie() ;
  return 0;
}
