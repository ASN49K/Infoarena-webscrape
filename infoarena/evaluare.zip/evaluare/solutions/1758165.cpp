#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;
char s[100001];
int lg=-1;
typedef struct node
{
    char inf;
    int val;
    node *left,*right;
} node;
int numar(char *s, int &i)
{
    int n=0;
    while(s[i]>='0' && s[i]<='9' && i<=lg)
        n=n*10+s[i++]-'0';
    i--;
    return n;
}
node *arbore(int &i);
node*factor(int &i)
{
    node *p;
    if(s[i]=='(')
        p=arbore(++i);
    else
    {
        p=new node;
        p->val=numar(s,i);
        p->left=p->right=NULL;
    }
    i++;
    return p;
}
node *termen(int &i)
{
    node*p,*r;
    r=factor(i);
    if(i>lg || (s[i]!='*' && s[i]!='/'))
        return r;
    p=new node;
    p->inf=s[i++];
    p->left=r;
    p->right=termen(i);
    return p;
}
node *arbore(int &i)
{
    node *p,*r;
    if(i>lg)
        return NULL;
    r=termen(i);
    if(i>lg || s[i]==')')
        return r;
    p=new node;
    p->left=r;
    p->inf=s[i++];
    p->right=arbore(i);
    return p;
}
int operatie(int a,int b,char op)
{
    switch (op)
    {
    case '+':
        return a+b;
        break;
    case '-':
        return a-b;
        break;
    case '*':
        return a*b;
        break;
    case '/':
        return a/b;
        break;
    }
}
void calc(node *p)
{
    if(p)
    {
        if(strchr("+-/*",p->left->inf))
            calc(p->left);

        if(strchr("+-/*",p->right->inf))
            calc(p->right);
        p->val=operatie(p->left->val,p->right->val,p->inf);
    }
}
int main()
{
    node *p=NULL;
    int i=0;
    ifstream f("evaluare.in");
    ofstream g("evaluare.out");
    f>>s[++lg];
    while(!f.eof())
        f>>s[++lg];
    lg--;
    p=arbore(i);
    calc(p);
    g<<p->val;
    f.close();
    g.close();
    return 0;
}
