#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define NMAX 200003

char fn[NMAX], fp[NMAX];
int val[NMAX/2], i;
int pozVal = -1, pozFn = -1, codLit = 0, pozFp = -1;
char opStack[NMAX/2], valStack[NMAX/2];
int vfOp = -1, vfVal = -1;

int isoperator(char ch)
{
	return ( (ch == '*') || (ch == '/') || (ch == '+') || (ch == '-') || (ch == '(') || (ch == ')') );
}
void Read(void)
{
	FILE *f = fopen("evaluare.in", "r");
	char ch;
	int nr;

	if(!f)
		perror("Eroare la deschiederea fisierului!");
	else
	{
		fn[++pozFn] = '(';

		while(!feof(f))
		{
			nr = 0;
			
			fscanf(f, "%c", &ch);
		
			if(isdigit(ch))
			{	
				fn[++pozFn] = (char)((codLit++) + 'a');
				
				while((isdigit(ch)) && (!feof(f)))
				{
					nr = nr*10 + (ch-'0');
					fscanf(f, "%c", &ch);
				}
			}
			
			if(nr != 0)
			{
				if(!feof(f))
					fn[++pozFn] = ch;
				
				val[++pozVal] = nr;
				nr = 0;
			}
			else
				fn[++pozFn] = ch;
		}

		fn[strlen(fn)] = ')';
		fn[strlen(fn)] = '\0';
	}
}

int OpStackIsEmpty(void)
{
	return (vfOp == -1);
}

char OpStackTop(void)
{
	return opStack[vfOp];
}

char OpStackPop(void)
{
	return opStack[vfOp--];
}

void Push_OpStack(char ch)
{
	opStack[++vfOp] = ch;
}
void BuildRPN(char ch)
{
	if(isalpha(ch))
	{
		fp[++pozFp] = ch;

		if(OpStackIsEmpty() == 0)
			if(OpStackTop() == '*' || OpStackTop() == '/')
				fp[++pozFp] = OpStackPop();

		return;
	}
		
	if(ch == ')')
	{
		while((ch = OpStackPop()) != '(')
		{
			fp[++pozFp] = ch;
		}

		return;
	}

	Push_OpStack(ch);
}
 
void Push_ValStack(int nr)
{
	valStack[++vfVal] = nr;
}

int ValStackPop(void)
{
	return valStack[vfVal--];
}

int EvalOp(int a, int b, char op)
{
	switch(op)
	{
	case '*': return a * b;
	case '/': return a / b;
	case '+': return a + b;
	case '-': return a - b;
	}
}
void EvalFP(char ch)
{
	if(isalpha(ch))
	{
		Push_ValStack( val[ch - 'a'] );
		return;
	}
	
	if(isoperator(ch))
		Push_ValStack(EvalOp(ValStackPop(), ValStackPop(), ch));

}
int main(void)
{
	Read();

	for(i = 0 ; i < strlen(fn); ++i)
		BuildRPN(fn[i]);

	for(i = 0; i < strlen(fp); ++i)
		EvalFP(fp[i]);

	printf("%d", ValStackPop());
	
	return 0;	
}