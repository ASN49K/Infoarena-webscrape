#include <stdio.h>
#include <stdlib.h>

#define NX 100010

struct node {
	int val;
	char op;
	struct node *l, *r;
};

typedef struct node node;

int res;
char S[ NX ], *p;
node *E;

node *expr();
node *term();
node *fact();

void cit() {
	fgets( S, NX, stdin );
}

node *expr() {
	node *x = term(), *y;
	
	while( *p == '+' || *p == '-' ) {
		y = (node *) malloc( sizeof( node* ) );
		y->op = *p++;
		y->l = x;
		y->r = term();
		x = y;
	}
	return x;
}

node *term() {
	node *x = fact(), *y;

	while( *p == '*' || *p == '/' ) {
		y = (node *) malloc( sizeof( node* ) );
		y->op = *p++;
		y->l = x;
		y->r = fact();
		x = y;
	}
	return x;
}

node *fact() {
	node *x;

	if( *p == '(' ) {
		p++;
		x = expr();
		p++;
	}
	else {
		x = (node *)malloc( sizeof( node* ) );
		x->op = '@';
		x->val = 0;
		while( *p >= '0' && *p <= '9' ) {
			x->val = x->val * 10 + *p - '0';
			p++;
		}
	}
	return x;
}

int eval( node *x ) {
	switch( x->op ) {
		case '@': return x->val;
		case '+': return eval( x->l ) + eval( x->r );
		case '-': return eval( x->l ) - eval( x->r );
		case '*': return eval( x->l ) * eval( x->r );
		case '/': return eval( x->l ) / eval( x->r );
	}
	return 0; //keeps compiler happy
}

void rez() {
	p = S;
	E = expr();
	res = eval( E );
}

void scr() {
	printf( "%d\n", res );
}

int main() {
	freopen( "evaluare.in", "r", stdin );
	freopen( "evaluare.out", "w", stdout );

	cit();
	rez();
	scr();

	return 0;
}

