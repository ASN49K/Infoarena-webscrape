#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;

#define NMAX 100001
#define TYPE long

class Expresie {
	public :
		char c[NMAX],*p;
		Expresie ();
		void citeste(ifstream &);
		TYPE evalueaza();
		TYPE termen();
		TYPE factor();
};

Expresie :: Expresie ()
{
	p=c;
}

void Expresie :: citeste(ifstream &f)
{
	f.get(c,NMAX-1);
	p=c;
}

TYPE Expresie :: evalueaza()
{
	TYPE r;
	r=termen();
	while(*p=='+' || *p=='-') 
		if(*p=='+') {
			p++;
			r=r+termen();
		}
		else {
			p++;
			r=r-termen();
		}
	return r;
}

TYPE Expresie :: termen()
{
	TYPE r;
	r=factor();
	while(*p=='*' || *p=='/') 
		if(*p=='*') {
			p++;
			r=r*factor();
		}
		else {
			p++;
			r=r/factor();
		}
	return r;
}

TYPE Expresie :: factor()
{
	TYPE r;
	if(*p=='(') {
		++p;
		r=evalueaza();
		++p;
	}
	else {
		r=0;
		while(*p>='0' && *p<='9') {
			r=r*10+(*p)-'0';
			p++;
		}
	}
	return r;
}

int main ()
{
	Expresie S;
	ifstream f("evaluare.in");
	ofstream g("evaluare.out");
	S.citeste(f);
	f.close();
	g<<S.evalueaza();
	g.close();
	return 0;
}