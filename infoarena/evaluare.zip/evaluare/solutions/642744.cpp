#include<fstream>
#include<cstdlib>
#include<cstring>
using namespace std;
struct nod{char info[10];nod*st,*dr;}*p;
int pfp[100003],ls;
char efp[100003][10],s[100003];
ofstream g("evaluare.out");
void prioritate(char s[],int &ls)
{int pr=0,i,k=0;//+- :1; */ : 10; a..z:1000; (+10)
  for(i=0;s[i];i++) 
	  if(s[i]=='+' || s[i]=='-') { efp[ls][0]=s[i]; pfp[ls]=1+pr; ls++; }
	     else
	  if(s[i]=='*' || s[i]=='/') { efp[ls][0]=s[i]; pfp[ls]=10+pr;ls++; }
	     else
	  if(s[i]=='(') pr+=10;
		 else
	  if(s[i]==')') pr-=10;
		                else 
						{k=0; 
						 while(s[i]<='9' && s[i]>='0')
						 {
						   efp[ls][k]=s[i];
						   k++;
						   i++;
						 } 
						 i--;
						 pfp[ls]=1000; ls++; 
						}
  ls--;	
}

nod *fpol(int li,int ls)
{int minpr=pfp[li],poz=li,i; nod*p;
   for(i=li;i<=ls;i++)
	if(pfp[i]<minpr){ minpr=pfp[i]; poz=i; }
	p=new nod;
	  strcpy(p->info,efp[poz]);
	if(li==ls)p->st=p->dr=0;
	   else
	 {
	  p->st=fpol(li,poz-1);  
	  p->dr=fpol(poz+1,ls);  
	 }
   return p;
}

long long eval(nod*p)
{
	if(p->info[0]=='+')return eval(p->st)+eval(p->dr);
	else
	if(p->info[0]=='-')return eval(p->st)-eval(p->dr);
	else
	if(p->info[0]=='*')return eval(p->st)*eval(p->dr);
	else
	if(p->info[0]=='/')return eval(p->st)/eval(p->dr);
	else          
	return atoll(p->info);
}
int main()
{
	ifstream f("evaluare.in");
	f.getline(s,100003);
	prioritate(s,ls);
	p=fpol(0,ls);
	g<<eval(p);
	f.close();g.close();
return 0;}
