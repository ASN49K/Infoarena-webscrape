#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <stdlib.h>
#define maxn 100005
#define maxn1 50100
using namespace std;
int main()


{ char a[maxn],c[10],d,p[maxn1];
int cif[maxn1],i,j,x,n,b,k,semn[maxn1],poz,max;
fstream f("evaluare.in",ios::in);
fstream g("evaluare.out",ios::out);
f.getline(a,maxn,'\n');
f.close();

for(i=1;i<=strlen(a)+3;i++)
    semn[i]=0;
x=0;j=0;n=0;i=0;
while(i<strlen(a))
    {

    if(strchr("+-",a[i]))
    {j++;i++;
    semn[j]=semn[j]+x+1;
    p[j]=a[i-1];}

    if(strchr("*/",a[i]))
    {j++;i++;
    semn[j]=semn[j]+x+10;
    p[j]=a[i-1]; }


    if(strchr("(",a[i]))
    {x=x+100;i++;}


    if(strchr(")",a[i]))
    {x=x-100;i++;}

    if(isdigit(a[i]))
    {n++;
    strcpy(c," ");
    b=i;
    k=0;
    c[k]=a[i];

    while(isdigit(a[b]))
    { b++;
    k++;
    c[k]=a[b];

    }

    i=b;
    cif[n]=atoi(c);
    }
}




while(j>0)
{max=0;
for(i=1;i<=j;i++)
    if(semn[i]>max)
{max=semn[i];
poz=i;}


  if(p[poz]=='+')
        cif[poz+1]=cif[poz]+cif[poz+1];
        else
  if(p[poz]=='-')
    cif[poz+1]=cif[poz]-cif[poz+1];
    else
  if(p[poz]=='*')
    cif[poz+1]=cif[poz]*cif[poz+1];
    else
  if(p[poz]=='/')
    cif[poz+1]=cif[poz]/cif[poz+1];

for(i=poz;i<=j;i++)
  {cif[i]=cif[i+1];
  semn[i]=semn[i+1];
  p[i]=p[i+1];}

j--;n--;
}
g<<cif[1];

g.close();

}
