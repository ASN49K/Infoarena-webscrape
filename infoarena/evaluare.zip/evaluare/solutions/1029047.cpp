#include <fstream>

using namespace std;

char sir[100005];
int poz;
//int n;

int termen();
int factor();

int eval()
{
    int r=termen();

    while(sir[poz]=='+' || sir[poz]=='-')
    {
        if(sir[poz]=='+')
        {
            poz++;
            r+=termen();
        }
        else if(sir[poz]=='-')
        {
            poz++;
            r-=termen();
        }
    }
    return r;
}

int termen()
{
    int r=factor();

    while(sir[poz]=='*' || sir[poz]=='/')
    {
        if(sir[poz]=='*')
        {
            poz++;
            r*=termen();
        }
        else if(sir[poz]=='/')
        {
            poz++;
            r/=termen();
        }
    }
    return r;
}

int factor()
{
    int r=0;
    if(sir[poz]=='(')
    {
        poz++;
        r=eval();
        poz++;
    }
    else while(sir[poz]>='0' && sir[poz]<='9')
    {
        r*=10;
        r+=(sir[poz]-'0');
        poz++;
    }
    return r;
}

int main()
{
    ifstream cin("evaluare.in");
    ofstream cout("evaluare.out");
    cin.get(sir,100005);
    cout<<eval()<<'\n';
    cin.close();
    cout.close();
    //n//=strlen(sir);
    return 0;
}
