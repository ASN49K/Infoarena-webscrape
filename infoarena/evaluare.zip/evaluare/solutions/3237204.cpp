#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

const int MAX_N = 100005;
const int MAX_OP_LEVEL = 2;
char op[4][4] = { "+-", "*/", "^", "" };

char s[MAX_N];
char *ptr = s;

void ReadExpression() {
    fgets(s, MAX_N, fopen("evaluare.in", "r"));
}

int Evaluate(int a, int b, char op) {
    switch (op) {
        case '+':
            return a + b;
        case '-':
            return a - b;
        case '*':
            return a * b;
        case '/':
            return a / b;
        default:
            cout << "Unidentified operand: " << op << '\n';
            return 1;
    }
}

int Expression(int lvl) {
    int x, y;

    if (lvl == MAX_OP_LEVEL) {
        if (*ptr == '(') {
            ptr++;
            x = Expression(0);
            ptr++;
        }
        else {
            for (x = 0; '0' <= *ptr && *ptr <= '9'; ptr++) {
                x *= 10;
                x += *ptr - '0';
            }
        }
    }
    else {
        for (x = Expression(lvl + 1); strchr(op[lvl], *ptr); x = y) {
            y = Evaluate(x, Expression(lvl + 1), *ptr++);
        }
    }

    return x;
}

void WriteResult(int result) {
    FILE *f = fopen("evaluare.out", "w");
    fprintf(f, "%d\n", result);
    fclose(f);
}

int main() {
    ReadExpression();
    int result = Expression(0);
    WriteResult(result);
    
    return 0;
}