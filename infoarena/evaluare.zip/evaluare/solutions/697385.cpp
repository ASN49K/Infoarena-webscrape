#include<fstream>
#define NMAX 100010

using namespace std;

ifstream f("evaluare.in");
ofstream g("evaluare.out");

char a[NMAX];
int i;

void Citeste()
{
	f.getline(a, NMAX);
}

int Termen();
int Factor();

int Evalueaza()
{
	int rez=Termen(), t2, sg;
	while (a[i]=='+' || a[i]=='-')
	{
		if (a[i]=='+') sg=1; else sg=-1;
		++i;
		t2=Termen()*sg;
		rez+=t2;
	}
	return rez;
}

int Termen()
{
	int rez=Factor(), f2;
	while (a[i]=='*' || a[i]=='/')
		if (a[i]=='*') ++i, f2=Factor(), rez*=f2;
		else  ++i, f2=Factor(), rez/=f2;
	return rez;
}

int Factor()
{
	int nr;
	if (a[i]=='(') ++i, nr=Evalueaza(), ++i;
	else while (a[i]>='0' && a[i]<='9') nr=nr*10+a[i++]-'0';
	return nr;
}

int main()
{
	Citeste();
	g<<Evalueaza()<<"\n";
	f.close();
	g.close();
	return 0;
}
