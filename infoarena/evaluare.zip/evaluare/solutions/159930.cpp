#include <stdio.h>
#include <string.h>
#define MAXL 100010
//dont try to understand this source, its sick n twisted and not even i understand it
//if it does work its because of some weird coincidence since, i assure you, my logic does not make sense

char s[MAXL];
int p,n;

long long wtf1();
long long wtf2(long long k);

int getnr()
{
	int nr=0;
	while (s[p]>='0' && s[p]<='9' && p<n)
	{
		nr=nr*10+s[p]-'0';
		p++;			
	}
	return nr;	
}
long long wtf1()
{
	long long k=0,nr=0,semn=0;
	while (s[p]!=')' && p<n)
	{
		semn=1; nr=0;
		if (s[p]=='(')
		{
			p++;
			semn=1;
			nr=wtf1();
			p++;
		}
		else
		{	semn=1;
			if (s[p]=='-' || s[p]=='+')
			{
				if (s[p]=='-')
					semn=-1;
				if (s[p]=='+')
					semn=1;
				p++;
			}
			if (s[p]=='(')
			{
				p++;
				nr=wtf1();
				p++;
			}
			else
				nr=getnr();
			
		}
		if (s[p]=='*' || s[p]=='/')
			if (s[p]=='*')
				k+=wtf2(semn*nr);
			else
				k+=wtf2(semn*nr);
		else
			k+=semn*nr;
		
	}
	return k;
}

long long wtf2(long long k)
{
	long long nr=1,op=0;
	
	while ((s[p]=='*' || s[p]=='/') && p<n)
	{
		op=0; nr=0;
		if (s[p]=='*')
			op=1;
		if (s[p]=='/')
			op=-1;
		p++;
		if (s[p]=='(')
		{
			p++;
			nr=wtf1();
			p++;
		}
		else
			nr=getnr();
		if (op==1)
			k*=nr;
		if (op==-1)
			k/=nr;	
	}
	return k;	
}


int main()
{
	freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	
	long long rez;
	
	gets(s);
	n=0;
	while ((s[n]>='0' && s[n]<='9') || s[n]=='-' || s[n]=='+' || s[n]=='*' || s[n]=='/' || s[n]=='(' || s[n]==')')
		n++;
	rez=wtf1();
	
	printf("%lld\n",rez);	
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
