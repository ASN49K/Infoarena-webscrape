#include<fstream>

using namespace std;

ifstream fin("exp.in");
ofstream fout("exp.out");

struct nod
{
	int type;
	char op;
	int nr;
	nod *st,*dr;
};
nod *r,*ps,*us;

struct stiva
{
	int t;
	char ch;
    int num;
};


stiva e[1000];

int n,p[1000];


void cit()
{
	char c;
	int add=0,sum;
	
	
	fin.get(c);
	while(c!='\n')
	{
		while(c==' ' && c!='\n') fin.get(c);
		
		if(c=='\n') return;
		
		if(c=='(') add+=10,fin.get(c);
		else
			if(c==')') add-=10,fin.get(c);
		    else
			 if(c=='+' || c=='-') { n++; e[n].t=1; e[n].ch=c; p[n]=1+add; fin.get(c); }
				else
					if(c=='*' || c=='/') { n++; e[n].t=1; e[n].ch=c; p[n]=10+add; fin.get(c); }
				    else
					{
						n++;
						e[n].t=2;
						
						sum=0;
						while(c>='0' && c<='9' && c!='\n')
						{
							sum=sum*10+c-'0';
							fin.get(c);
						}
						
						e[n].num=sum;
						p[n]=1000+add;
						
						
					}
	}
}

nod *creare(int i,int j)
{
	nod *q;
	int hh,h,min;
	
	q=new nod;
	min=10000;
	for(h=i;h<=j;h++)
		if(min>=p[h])
		{
			min=p[h];
			hh=h;
		}
		
	 if(e[hh].t==1)
	 {
		q->type=1;
		q->op=e[hh].ch;
	 }
	 else
	 {
		q->type=2;
		q->nr=e[hh].num;
	 }
		
	 
	if(i==j)
	{
		q->st=0;
		q->dr=0;
	}
	else
	{
		q->st=creare(i,hh-1);
		q->dr=creare(hh+1,j);
	}
	
	return q;
}


void add_elem(nod *q)
{
	nod *w;

	w=new nod;
	
	w=q;
	w->dr=0;
	w->st=0;
	
	if(ps==0)
		ps=us=w;
	else
	{
		us->dr=w;
		w->st=us;
		us=w;
	}
}


void postord(nod *k)
{
	if(k!=0)
	{
		postord(k->st);
		postord(k->dr);
		add_elem(k);
	}
}


void eval()
{
	nod *q,*x,*y,*z,*w,*urm;
	int aux;
	
	q=ps;
	
	while(q!=0)
	{
		while(q->type!=1 && q!=0)
			q=q->dr;
		
		urm=q->dr;
		x=q->st;
		y=x->st;
		z=y->st;
		
		
		if(q->op=='+') aux=y->nr+x->nr;
		if(q->op=='-') aux=y->nr-x->nr;
		if(q->op=='*') aux=y->nr*x->nr;
		if(q->op=='/') aux=y->nr/x->nr;
		
		w=new nod;
		w->type=2;
		w->nr=aux;
		w->st=0;
		w->dr=0;
		
		if(z==0) ps=w;
		else 
			z->dr=w,w->st=z;
	
		
		if(urm!=0) w->dr=urm,urm->st=w;
		
		q=urm;
	    delete x;
		delete y;
	}
}	


void afis()
{
	int i;
	
	for(i=1;i<=n;i++)
		if(e[i].t==1)
		fout<<e[i].ch<<" ";
		else
	       fout<<e[i].num<<" ";
		
	fout<<'\n';
	for(i=1;i<=n;i++)
		fout<<p[i]<<" ";
}

void afis2()
{
	nod *q;
	
	q=ps;
	while(q!=0)
	{
		if(q->type==1)
			fout<<q->op<<" ";
		else
			fout<<q->nr<<" ";
		
		q=q->dr;
	}
}


int main()
{
	cit();
	r=creare(1,n);
	
	n=0;
	postord(r);
	//afis2();
	eval();
	fout<<ps->nr;
	
	
	fin.close();
	fout.close();
	return 0;
}
 




