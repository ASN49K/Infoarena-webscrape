
#include <iostream>
using namespace std;
long long fact(int n , int t){
    long long  fact=1;
     
     if(n=t+1){
         for(int i =(n-t)+1; i<n; i++)
        fact=(fact *i)%666013;
        return fact;
        else if(n>=t+2){
            for(int i =(n-t)+1; i<n; i++)
        fact=(fact *i)%666013;
        return fact/n;
        }
}else{
    for(int i =1; i<=n; i++)
        fact=(fact *i);
    return fact; 
    }
}
int main()
{
  int  n,t;
  cin>>n>>t;
  cout<<fact(n,t);
  
}
