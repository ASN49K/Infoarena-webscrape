#include <cstdio>
#include <cstring>

#define file_in "evaluare.in"
#define file_out "evaluare.out"

char s[101000];
char *p=s;

int expresie();
int factor();
int termen();

int expresie(){
	
	int r=termen();
	
	while(*p=='+' || *p=='-')
		 if (*p=='+'){
			 p++;
			 r+=termen();
		 }
		 else{
			 p++;
			 r-=termen();
		 }
	return r;
}

int termen(){
	
	int r=factor();
	
	while(*p=='*' || *p=='/')
		 if (*p=='*'){
			 p++;
			 r*=factor();
		 }
		 else{
			 p++;
			 r/=factor();
		 }
	return r;
}

int factor(){
	
	int r=0;
	
	if (*p=='('){
		p++;
		r=expresie();
		p++;
	}
	else{
		while(*p>='0' && *p<='9'){
			r=r*10+*p-'0';
			p++;
		}
	}
	
	return r;
}
	
	

int main(){
	
	freopen(file_in,"r",stdin);
	freopen(file_out,"w",stdout);
	
	gets(s);
	
	printf("%d\n", expresie());
	
	return 0;
	
}
