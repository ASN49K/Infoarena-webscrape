#include<fstream>
#define MAXN 100000

char T[MAXN];
char* p;
long eval();
long termen();
long factor();

int main() {
  std::ifstream in("evaluare.in");
  std::ofstream out("evaluare.out");
  in.getline(T,MAXN);
  p = T;
  long r = eval();

  out << "result " << r << std::endl;
  
}

long eval() {
  long r = termen();
  while(*p == '+' || *p == '-') {
    switch(*p){
    case '+':
      ++p;
      r += termen();
      break;
    case '-':
      ++p;
      r -= termen();
      break;
    }
  }
  return r;
}

long termen(){
  long r = factor();
  while(*p == '*' || *p == '/'){
    switch(*p) {
    case '*':
      ++p;
      r *= factor();
      break;
    case '/':
      ++p;
      r *= factor();
      break;
    }
  }
  return r;
}

long factor(){
  long r = 0;
  if(*p == '('){
    ++p;
    r+=eval();
    ++p;
  } else {
    while(*p >= '0' && *p <= '9'){
      r+= r*10 + *p - '0';
      ++p;
    }
  }
  return r;
}
