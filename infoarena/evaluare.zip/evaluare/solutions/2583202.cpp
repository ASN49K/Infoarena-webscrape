#include <bits/stdc++.h>

using namespace std;
ifstream fin ("evaluare.in");
ofstream fout ("evaluare.out");
char sir[100003],stiva[100003];long long stiva1[100003],last,last1,nr,nr1;
int main () {
	fin.getline(sir,1000);
	for(int i=0;i<(int)strlen(sir);++i) {
		if(sir[i]>='0' && sir[i]<='9') {
			nr=0;
			while(sir[i]>='0' && sir[i]<='9')
				nr=nr*10+sir[i]-'0',++i;
			stiva1[++last1]=nr;--i;
		}
		else if (sir[i]=='+' || sir[i]=='-') {
			while(stiva[last]=='+' || stiva[last]=='-'  || stiva[last]=='*' || stiva[last]=='/') {
				nr1=stiva1[last1];nr=stiva1[last1-1];last1-=2;
				if(stiva[last]=='+')
					stiva1[++last1]=nr+nr1;
				else if (stiva[last]=='-')
					stiva1[++last1]=nr-nr1;
				else if (stiva[last]=='*')
					stiva1[++last1]=nr*nr1;
				else
					stiva1[++last1]=nr/nr1;
				--last;
			}
			stiva[++last]=sir[i];
		}
		else if (sir[i]=='*' || sir[i]=='/') {
			while(stiva[last]=='*' || stiva[last]=='/') {
				nr1=stiva1[last1];nr=stiva1[last1-1];--last1;--last1;
				if(stiva[last]=='*')
					stiva1[++last1]=nr*nr1;
				else
					stiva1[++last1]=nr/nr1;
				--last;
			}
			stiva[++last]=sir[i];
		}
		else if (sir[i]=='(') 
			stiva[++last]=sir[i];
		else if (sir[i]==')') {
			while(stiva[last]!='(') {
				nr1=stiva1[last1];nr=stiva1[last1-1];last1-=2;
				if(stiva[last]=='+')
					stiva1[++last1]=nr+nr1;
				else if (stiva[last]=='-')
					stiva1[++last1]=nr-nr1;
				else if (stiva[last]=='*')
					stiva1[++last1]=nr*nr1;
				else if (stiva[last]=='/')
					stiva1[++last1]=nr/nr1;
				--last;
			}
			--last;
		}
	}
	while(last>0) {
		nr1=stiva1[last1];nr=stiva1[last1-1];last1-=2;
			if(stiva[last]=='+')
				stiva1[++last1]=nr+nr1;
			else if (stiva[last]=='-')
				stiva1[++last1]=nr-nr1;
			else if (stiva[last]=='*')
				stiva1[++last1]=nr*nr1;
			else if (stiva[last]=='/')
				stiva1[++last1]=nr/nr1;
			--last;
	}
	fout<<stiva1[last1];
	return 0;
}
