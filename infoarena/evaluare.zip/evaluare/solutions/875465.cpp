#include <iostream>
#include <fstream>
#include <string.h>
#include <stdio.h>
using namespace std;
char s[2560];
double rezultat[5000];
//char postfix[256][256];

struct stiva
{
    int numar;
    char operatie;
} postfix[100000];
int Prioritate(char v)
{
	if (v=='+' || v=='-') return 2;
	if (v=='*' || v=='/') return 3;
	//if (v=='(' || v==')') return 1;
	if (v=='^') return 4;
	return 0;
}

void ScrieOperator(int &i, int &j, char v)
{
	if (Prioritate(v)<=Prioritate(s[i]))
	{
		postfix[++j].operatie=s[i];
	    s[i]=v;
	}
	else
	{
        s[++i]=v;
	}
}

int main()
{
	ifstream f("evaluare.in");
	ofstream g("evaluare.out");
	char c[256];
	int nr=0;
	int i=-1;
	int j=-1;
	f.get(c,100000);
	// citire si scriere in forma postfixata
	for (int m=0;m<strlen(c);m++)
	{
		if (Prioritate(c[m])!=0 && c[m-1]=='(') j++;
		if (c[m]>=48 && c[m]<=58)
		{
			nr=nr*10+c[m]-48;
		}
		else
		{
			if (nr!=0)
			{
				postfix[++j].numar=nr;
				nr=0;
			}
			if (c[m]=='(')
			{
				s[++i]='(';
			}
			else
			{
				if (c[m]==')')
				{
					while (i>=0)
					{
						if (s[i]=='(') { s[i]=NULL; i--; break; }
						else
						{
							postfix[++j].operatie=s[i];
							s[i]=NULL;
							i--;
						}

					}
				}
				else
				{
					if (i==-1) s[++i]=c[m];
					else
					switch(c[m])
					{
					case '+': ScrieOperator(i,j,c[m]); break;
					case '-': ScrieOperator(i,j,c[m]); break;
					case '*': ScrieOperator(i,j,c[m]); break;
					case '/': ScrieOperator(i,j,c[m]); break;
					case '^': ScrieOperator(i,j,c[m]); break;
					}
				}
			}
		}
	}
	if (nr!=0)
        postfix[++j].numar=nr;

	for (int m=i;m>=0;m--)
		postfix[++j].operatie=s[m];

	// evaluare expresie in forma postfixata

    i=-1;

    for (int m=0;m<=j;m++)
    {
		if (postfix[m].numar!=0 || postfix[m].operatie==NULL)
        {
            rezultat[++i]=postfix[m].numar;
        }
        else
        {
            double a=rezultat[i];
            rezultat[i]=0;
            i--;
            double b=rezultat[i];
            switch(postfix[m].operatie)
            {
                case '+': rezultat[i]=a+b; break;
                case '-': rezultat[i]=b-a;  break;
                case '*': rezultat[i]=a*b; break;
                case '/': rezultat[i]=b/a; break;
            }
        }
    }



	/*for (int m=0;m<=j;m++)
	{
		if (postfix[m].numar!=0)
            g<<postfix[m].numar<<" ";
            else
            g<<postfix[m].operatie;
	}
	g<<endl;*/
	g<<rezultat[i];

	f.close();
	g.close();
}
