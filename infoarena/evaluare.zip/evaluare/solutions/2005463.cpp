#include <iostream>
#include <fstream>
#include <unordered_map>
#include <queue>
#include <stack>
#include <vector>

#define ll long long
#define ull unsigned long long
#define pb push_back
using namespace std;
ifstream in("evaluare.in");
ofstream out("evaluare.out");

const int NMax = 1e5 + 5;
const int inf = 1e9 + 5;

char str[NMax],*p = str;

int eval();
int termen();
int factor();

int main() {
    in>>str;

    out<<eval()<<'\n';

    in.close();out.close();
    return 0;
}

int eval() {
    int ans = termen();
    while (*p == '+' || *p == '-') {
        switch(*p++) {
        case '+':
            ans += termen();

            break;
        case '-':
            ans -= termen();

            break;
        }
    }

    return ans;
}

int termen() {
    int ans = factor();
    while (*p == '*' || *p == '/') {
        switch(*p++) {
        case '*':
            ans *= factor();

            break;
        case '/':
            ans /= factor();

            break;
        }
    }

    return ans;
}

int factor() {
    int ans = 0;

    if (*p == '(') {
        ++p;
        ans = eval();
        ++p;
    }
    else {
        while ('0' <= *p && *p <= '9') {
            ans = ans * 10 + *p++ - '0';
        }
    }

    return ans;
}
