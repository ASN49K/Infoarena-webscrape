#include <stdio.h>
#include <list>
FILE *fin, *fout;
std::list<long> num;
std::list<char> op;
bool ver(char ch1,char ch2)
{
     if(ch1=='*'||ch1=='/') return 1;
     if(ch1=='+'||ch1=='-')
     {
                           if(ch2!='*'&&ch2!='/') return 1;
     }
     return 0;
}
int main()
{
    fin = fopen("evaluare.in","r");
    fout = fopen("evaluare.out", "w");
    char ch;
    long nr;
    while(!feof(fin))
    {
                     fscanf(fin,"%c",&ch);
                     if('0'<=ch&&ch<='9')
                     {
                                         nr=0;
                                         do
                                         {
                                              nr*=10;
                                              nr+=(ch-'0');
                                              fscanf(fin,"%c",&ch);
                                              if(feof(fin)) break;  
                                         }while('0'<=ch&&ch<='9');
                                         num.push_back(nr);
                     }
                     if(feof(fin)) break;
                     if(ch==')')
                     {
                                while(1)
                                {
                                    if(op.back()=='(')
                                    {
                                                      op.pop_back();
                                                      break;
                                    }
                                    else
                                    {
                                        if(op.back()=='+') num.push_back(-1);
                                        else if(op.back()=='-') num.push_back(-2);
                                        else if(op.back()=='*') num.push_back(-3);
                                        else num.push_back(-4);
                                        op.pop_back();
                                    }
                                }
                     }
                     else
                     {
                         while(ver(op.back(),ch)==1)
                         {
                                  if(op.back()=='+') num.push_back(-1);
                                  else if(op.back()=='-') num.push_back(-2);
                                  else if(op.back()=='*') num.push_back(-3);
                                  else num.push_back(-4);
                                  op.pop_back();                   
                         }
                         op.push_back(ch);
                     }
    }
    while(!op.empty())
    {
                                  if(op.back()=='+') num.push_back(-1);
                                  else if(op.back()=='-') num.push_back(-2);
                                  else if(op.back()=='*') num.push_back(-3);
                                  else num.push_back(-4);
                                  op.pop_back();     
    }
    std::list<long>::iterator i,j;
    for(i=num.begin();++i!=num.end();)
    {
            if(*i<0)
            {
                    if(*i==-1)
                    {
                              *i=*--(j=i)+*----(j=i);
                    }
                    else if(*i==-2)
                    {
                              *i=*----(j=i)-*--(j=i);
                    }
                    else if(*i==-3)
                    {
                              *i=*--(j=i)**----(j=i);
                    }
                    else if(*i==-4&&*--(j=i)!=0)
                    {
                              *i=*----(j=i)/(*--(j=i));
                    }
                    if(num.size()>2) num.erase(----(j=i));
                    if(num.size()>1) num.erase(--(j=i));
            }
    }
    fprintf(fout,"%ld",num.front());
}
    
