program expresie;
var t:array[1..100001] of char;
    n:longint;
    b:array[1..1 shl 17] of char;


function adunare:longint;forward;

function paranteze:longint;
var p:longint;
Begin
  p:=0;
  if t[n]='('
    then
      begin
        inc(n);
        p:=adunare;
        inc(n)
      end
    else
      while (t[n]>='0') and (t[n]<='9') do
        begin
          p:=p*10+ord(t[n])-48;
          inc(n);
        end;
  paranteze:=p;
End;


function inmultire:longint;
var i:longint;
Begin
  i:=paranteze;
//  inc(n);
  while (t[n]='*') or (t[n]='/') do
          if t[n]='*'
        then
          begin
          inc(n);
           i:=i*paranteze
           end
        else
        begin
        inc(n);
           i:=i div paranteze;end;
  inmultire:=i;
End;

function adunare:longint;
var c:longint;
Begin
  c:=inmultire;
//  inc(n);
 while (t[n]='+') or (t[n]='-') do
       if t[n]='+'
        then
          begin
          inc(n);
          c:=c+inmultire;
          end
         else
        begin
        inc(n);
          c:=c-inmultire;
          end;
  adunare:=c;
End;


BEGIN
  assign(input,'evaluare.in');
  settextbuf(input,b);
  reset(input);
  readln(t);
  close(input);
  assign(output,'evaluare.out');
  rewrite(output);
  n:=1;
  write(adunare);
  close(output);
END.

