#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>

using namespace std;
int dx[4] = {1, 0,-1,0};
int dy[4] = {0,-1, 0,1};

#define nmax 100000
char ex[nmax+5],polo[2*nmax+5],stiva[nmax+5],ex1[100],ex2[nmax+5];

int i,j,k,len,vf,v1,v2,rez;

ifstream fin("expresie.in");
ofstream fout("expresie.out");

int main()
{
	fin>>ex;
	len = strlen(ex);
	polo[0] = ' ';
	k++;
	for (i=0;i<len;i++)
	{
		if (ex[i]== '(')
			stiva[vf++] = '(';
		if (ex[i] == ')')
		{
			polo[k++] = ' ';
			while (vf>0 && stiva[vf-1]!='(' )
				polo[k++] = stiva[--vf];
			vf--;
			polo[k++] = ' ';
		}
		if (ex[i]>= '0' && ex[i]<='9')
			polo[k++] = ex[i];
		if (ex[i] == '+')
		{
			while (vf>0 && stiva[vf-1]!='(')
				{
					polo[k++] = ' ';
					polo[k++] = stiva[--vf];
					
				}
			
			stiva[vf++] = '+';
			polo[k++] = ' ';
		}
		if (ex[i] == '-')
		{
			while (vf>0 && stiva[vf-1]!='(')
				polo[k++] = stiva[--vf];
			stiva[vf++] = '-';
			polo[k++] = ' ';
		}
		if (ex[i] == '*')
		{
			while (vf>0 && stiva[vf-1]!='(' && stiva[vf-1]!='+' && stiva[vf-1]!='-')
				polo[k++] = stiva[--vf];
			stiva[vf++] = '*';
			polo[k++] = ' ';
		}
		if (ex[i] == '/')
		{
			while (vf>0 && stiva[vf-1]!='(' && stiva[vf-1]!='+' && stiva[vf-1]!='-')
				polo[k++] = stiva[--vf];
			stiva[vf++] = '/';
			polo[k++] = ' ';
		}
	}
	polo[k++] = ' ';
	while (vf>0)
		polo[k++] = stiva[--vf];
		
	//cout<<polo;
	
	len = strlen(polo);
	i = 0;
	while (i< len)
		if (polo[i] == ' ' && polo[i+1]==' ')
			strcpy(polo+i,polo+i+1);
		else
			i++;
	//cout<<endl<<polo<<endl;
	for (i=0;i<strlen(polo);i++)
	{
		if (polo[i] == '+')
		{
			k = 0;
			for (j=i;j>=0;j--)
			{
				if (polo[j] == ' ')
					k++;
				if (k==3)
					break;
			}
			strncpy(ex1,polo+j+1,i-j);
			ex1[i-j] = 0;
			sscanf(ex1,"%d%d",&v1,&v2);
			rez = v1+v2;
			//itoa(rez,ex1,10);
			sprintf(ex1,"%d",rez);
			strcpy(ex2,polo+i+1);
			//strcpy(polo+j+1,polo+i+1);
			polo[j+1] = 0;
			strcat(polo,ex1);
			strcat(polo,ex2);
			i = j;
		}
		if (polo[i] == '*')
		{
			k = 0;
			for (j=i;j>=0;j--)
			{
				if (polo[j] == ' ')
					k++;
				if (k==3)
					break;
			}
			strncpy(ex1,polo+j+1,i-j);
			ex1[i-j] = 0;
			sscanf(ex1,"%d%d",&v1,&v2);
			rez = v1*v2;
			//itoa(rez,ex1,10);
			sprintf(ex1,"%d",rez);
			strcpy(ex2,polo+i+1);
			//strcpy(polo+j+1,polo+i+1);
			polo[j+1] = 0;
			strcat(polo,ex1);
			strcat(polo,ex2);
			i = j;
		}
		if (polo[i] == '/')
		{
			k = 0;
			for (j=i;j>=0;j--)
			{
				if (polo[j] == ' ')
					k++;
				if (k==3)
					break;
			}
			strncpy(ex1,polo+j+1,i-j);
			ex1[i-j] = 0;
			sscanf(ex1,"%d%d",&v1,&v2);
			rez = v1/v2;
			//itoa(rez,ex1,10);
			sprintf(ex1,"%d",rez);
			strcpy(ex2,polo+i+1);
			//strcpy(polo+j+1,polo+i+1);
			polo[j+1] = 0;
			strcat(polo,ex1);
			strcat(polo,ex2);
			i = j;
		}
		if (polo[i] == '-' && (polo[i+1]==' ' || polo[i+1] == 0))
		{
			k = 0;
			for (j=i;j>=0;j--)
			{
				if (polo[j] == ' ')
					k++;
				if (k==3)
					break;
			}
			strncpy(ex1,polo+j+1,i-j);
			ex1[i-j] = 0;
			sscanf(ex1,"%d%d",&v1,&v2);
			rez = v1-v2;
			//itoa(rez,ex1,10);
			sprintf(ex1,"%d",rez);
			strcpy(ex2,polo+i+1);
			//strcpy(polo+j+1,polo+i+1);
			polo[j+1] = 0;
			strcat(polo,ex1);
			strcat(polo,ex2);
			i = j;
		}
	}
	fout << atoi(polo);
	return 0;
}

