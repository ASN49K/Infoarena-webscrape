#include <fstream>
#include <stack>
#include <cstring>
#include <queue>
#define mare 2000000000
using namespace std;
char x[100005];
stack <int> stiva2;
stack <char> stiva;
queue <int> coada;
int main()
{
	int i, nr, fata;
	ifstream f("evaluare.in");
	ofstream g("evaluare.out");
	f.getline(x, 100005);
	int p=strlen(x);
	for(i=0; i<p; i++)
	{
		if(isdigit(x[i]))
		{
		nr=0;
		while(isdigit(x[i]))
		{
			nr=nr*10+(x[i]-48);
			i++;
		}
		coada.push(nr);
		}
		if(x[i]=='(')
		{
			stiva.push(x[i]);
		}
		else if(x[i]==')')
		{
			while(!stiva.empty() && stiva.top()!='(')
			{
				if(stiva.top()=='+')
						coada.push(mare+1);
					if(stiva.top()=='-')
						coada.push(mare+2);
					if(stiva.top()=='*')
						coada.push(mare+3);
					if(stiva.top()=='/')
						coada.push(mare+4);
				stiva.pop();
			}
			stiva.pop();
		}
		else if(x[i]=='+' || x[i]=='-')
		{
			if(!stiva.empty())
			{
				while(!stiva.empty() && (stiva.top()=='+' || stiva.top()=='-' || stiva.top()=='*' || stiva.top()=='/'))
				{
					if(stiva.top()=='+')
						coada.push(mare+1);
					if(stiva.top()=='-')
						coada.push(mare+2);
					if(stiva.top()=='*')
						coada.push(mare+3);
					if(stiva.top()=='/')
						coada.push(mare+4);
					stiva.pop();
				}
				stiva.push(x[i]);
			}
			else stiva.push(x[i]);
		}
		else if(x[i]=='*' || x[i]=='/')
		{
			if(!stiva.empty())
			{
				while(!stiva.empty() && (stiva.top()=='*' || stiva.top()=='/'))
				{
					if(stiva.top()=='*')
						coada.push(mare+3);
					if(stiva.top()=='/')
						coada.push(mare+4);
					stiva.pop();
				}
				stiva.push(x[i]);
			}
			else stiva.push(x[i]);
		}
	}
	while(!stiva.empty())
	{
		if(stiva.top()=='+')
						coada.push(mare+1);
					if(stiva.top()=='-')
						coada.push(mare+2);
					if(stiva.top()=='*')
						coada.push(mare+3);
					if(stiva.top()=='/')
						coada.push(mare+4);
		stiva.pop();
	}
	while(!coada.empty())
	{
		fata=coada.front();
		coada.pop();
		if(fata<mare)
		{
			stiva2.push(fata);
		}
		else if(fata==mare+1)
		{
			int unu=stiva2.top();
			stiva2.pop();
			int doi=stiva2.top();
			stiva2.pop();
			stiva2.push(unu+doi);
		}
		else if(fata==mare+2)
		{
			int unu=stiva2.top();
			stiva2.pop();
			int doi=stiva2.top();
			stiva2.pop();
			stiva2.push(doi-unu);
		}
		else if(fata==mare+3)
		{
			int unu=stiva2.top();
			stiva2.pop();
			int doi=stiva2.top();
			stiva2.pop();
			stiva2.push(unu*doi);
		}
		else if(fata==mare+4)
		{
			int unu=stiva2.top();
			stiva2.pop();
			int doi=stiva2.top();
			stiva2.pop();
			stiva2.push(doi/unu);
		}
	}
	g<<stiva2.top();
}