#include <fstream>
#include <cstring>
#define DIM 200004
using namespace std;

ifstream cin("evaluare.in");
ofstream cout("evaluare.out");

int q, care, contor, ramas, val, contor_operand, operand[DIM], stiva_int[DIM];
char v[DIM], stiva[DIM], poloneza[DIM];

int main()
{
    cin.getline(v+1, DIM);
    q = strlen(v+1);
    for(int i=1; i <= q; i++)
    {
        if(v[i] == '(')
        {
            contor++;
            stiva[contor] = '(';
        }
        else
        if(v[i] == ')')
        {
            while(stiva[contor] != '(')
            {
                ramas++;
                poloneza[ramas] = stiva[contor];
                stiva[contor] = ' ';
                contor--;
            }
            stiva[contor] = ' ';
            contor--;
        }
        else
        if(v[i] >= '0' && v[i] <= '9')
        {
            val = 0;
            while(v[i] >= '0' && v[i] <= '9')
            {
                val = val*10+(v[i]-'0');
                i++;
            }
            contor_operand++;
            operand[contor_operand] = val;
            ramas++;
            poloneza[ramas] = 'N';
            i--;
        }
        else
        if(v[i] == '*' || v[i] == '/')
        {
            contor++;
            stiva[contor] = v[i];
        }
        else
        if(v[i] == '+' || v[i] == '-')
        {
            while(stiva[contor] == '*' || stiva[contor] == '/')
            {
                ramas++;
                poloneza[ramas] = stiva[contor];
                contor--;
            }
            contor++;
            stiva[contor] = v[i];
        }
    }
    while(contor > 0)
    {
        ramas++;
        poloneza[ramas] = stiva[contor];
        stiva[contor] = ' ';
        contor--;
    }
    /*care = 0;
    for(int i=1; i <= ramas; i++)
    {

        if(poloneza[i] != 'N')
        cout << poloneza[i]  << ' ';
        else
        {
            care++;
            cout << operand[care] << ' ';
        }
    }*/

    care = 0;
    contor = 0;
    for(int i=1; i <= ramas; i++)
    {
        if(poloneza[i] == 'N')
        {
            care++;
            contor++;
            stiva_int[contor] = operand[care];
        }
        else
        {
            if(poloneza[i] == '+')
            stiva_int[contor-1] = stiva_int[contor-1]+stiva_int[contor];
            else
            if(poloneza[i] == '-')
            stiva_int[contor-1] = stiva_int[contor-1]-stiva_int[contor];
            else
            if(poloneza[i] == '*')
            stiva_int[contor-1] = stiva_int[contor-1]*stiva_int[contor];
            else
            if(poloneza[i] == '/')
            stiva_int[contor-1] = stiva_int[contor-1]/stiva_int[contor];

            stiva_int[contor] = 0;
            contor--;
        }
    }
    cout << stiva_int[1];
}
