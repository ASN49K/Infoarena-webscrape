#include <fstream>
#include <cstring>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int st2[100005],i,k2,k1,nr,rez;
char st1[100005],s[100005],pr[256];

int operatie(char op, int a, int b)
{
    if(op=='*')
        return a*b;
    if(op=='/')
        return a/b;
    if(op=='+')
        return a+b;
    if(op=='-')
        return a-b;

}

int main()
{
    fin.get(s,100005);
    pr['+']=pr['-']=1;
    pr['*']=pr['/']=2;
    pr['(']=3;
    for(i=0;s[i]!=0;i++)
    {
        if(s[i]>='0'&&s[i]<='9')
        {
            nr=0;
            while(s[i]>='0'&&s[i]<='9')
            {
                nr=nr*10+s[i]-'0';
                i++;
            }
            i--;
            st2[++k2]=nr;
        }
        else
            if(s[i]=='(')
                st1[++k1]='(';

            else
            if(s[i]==')'){
                while(st1[k1]!='(')
                {
                    rez=operatie(st1[k1],st2[k2-1],st2[k2]);
                    k1--;k2--;
                    st2[k2]=rez;
                }
                k1--;//elimin ( din stiva
            }
           else
           {
               while(k1>0&&pr[st1[k1]]>=pr[s[i]])
               {
                   rez=operatie(st1[k1],st2[k2-1],st2[k2]);
                   k1--;
                   k2--;
                   st2[k2]=rez;
               }
               st1[++k1]=s[i];
           }
    }
    while(k1>=1)
    {
        rez=operatie(st1[k1],st2[k2-1],st2[k2]);
        k1--;
        k2--;
        st2[k2]=rez;
    }
    fout<<st2[1];
    return 0;
}
