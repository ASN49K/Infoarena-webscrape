#include <stdio.h>   
#include <string.h>   
#define MAX 100001   
  
char a[MAX];   
int n;   
  
void citire()   
{   
   freopen ("evaluare.in","r",stdin);   
   fgets(a,MAX,stdin);   
   fclose (stdin);   
}   
  
long calcul(long a,long b,char c)   
{   
   switch (c)   
   {   
   case '+': return a+b;   
   case '-':  return a-b;   
   case '*': return a*b;   
   default:  return a/b;   
   }   
}   
  
long da(int st,int dr,char s1,char s2)   
{   
   int num=0;   
   for (int i=dr;i>=st;i--)   
   {   
       if (a[i]==')')   
      num++;   
       else  
     if (a[i]=='(')   
          num--;   
     else  
       if ((a[i]==s1 || a[i]==s2) && num==0)   
           return i;   
   }   
  
  return -1;   
}   
  
void paranteza(int &st,int &dr)   
{   
   int num=0;   
   for (int i=dr-1;i>st;i--)   
      if (a[i]==')')   
     num++;   
      else  
    if (a[i]=='(')   
       num--;   
   if (num==0 && a[st]=='(' && a[dr]==')')   
   {   
       st++;   
       dr--;     
       return ;
   }   
}   
  
long lal (int st,int dr)   
{   
   long nr=0;   
  for (int i=st;i<=dr;i++)   
       nr=nr*10+(a[i]-'0');   
    return nr;   
}   
  
long lol(int st,int dr)   
{   
  paranteza(st,dr);   
  long aux=da(st,dr,'+','-');   
  if (aux<1)   
     aux=da(st,dr,'*','/');   
   if (aux<1)   
       return lal(st,dr);   
   return calcul(lol(st,aux-1),lol(aux+1,dr),a[aux]);   
}   
  
int main ()   
{   
   citire();   
   n=strlen (a);   
   freopen ("evaluare.out","w",stdout);   
   printf ("%ld\n",lol(0,n-2));   
   fclose(stdout);   
   return 0;   
} 
