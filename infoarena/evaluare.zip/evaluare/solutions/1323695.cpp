#include <fstream>
#include <string.h>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
#define Lmax 100010
#define Nmax 55000
#define maxLv 3
 
char s[Lmax], *p;
char OP[4][4] = {"+-", "/*%", "^", ""};

int t[Nmax];
char op[Nmax];
 
void rez(int, int) ;
int pow(int, int) ;
int get_int() ;
int eval(int, int, char) ;
 
int main()
{
    fin.getline(s, Lmax);
    s[ strlen(s) ] = ')';
         
    p = s;
    rez(0, 0);
    
    fout << t[0] << '\n';
     
    return 0;
}
 
 
void rez(int Tst, int OPst)
{
    int nrop = OPst, nrt = Tst;
     
    while(*p != ')')
    {
        if(*p == '(')
        {
            p++;
            rez(nrt, nrop);
            ++nrt;
        }
        else if('0' <= *p && *p <= '9') t[nrt++] = get_int();
        else op[nrop++] = *p, ++p;
    }
    ++p;
     
    int i, j, k, lv;
     
    for(lv = maxLv - 1; lv >= 0; --lv)
    {
        for(j = Tst, i = OPst; i < nrop; )
            if(strchr(OP[lv], op[i]))
            {
                t[j] = eval(t[j], t[j+1], op[i]);
                 
                for(k = j + 2; k < nrt; ++k) t[k-1] = t[k];
                strcpy(op + i, op + i + 1);
                 
                --nrop; --nrt;
            }
            else ++i, ++j;
    }
}
 
 
int pow(int x, int y)
{
    if(!x) return 0;
    if(x == 1) return 1;
     
    int rez = 1;
     
    while(y)
    {
        if(y & 1) rez = (rez * x) % 26;
        x = (x * x) % 26;
        y >>= 1;
    }
     
    return rez;
}
 
 
int get_int()
{
    int x, semn = 1;
    if((*p) == '-') semn = -1, ++p;
    for(x = 0; '0' <= (*p) && (*p) <= '9'; ++p)
        x = x * 10 + (*p) - '0';
    return x * semn;
}
 
int eval(int a, int b, char op)
{
    switch(op)
    {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b;
        case '%': return a % b;
        case '^': return pow(a, b);
    }
    return 0;
}

