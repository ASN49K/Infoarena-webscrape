// Mihai Priboi

#include <bits/stdc++.h>

#define MAXN 100000

char s[MAXN];
int index;

int adunare();

int factor() {
  int nr;
  nr = 0;

  if( s[index] == '(' ) {
    index++;
    nr = adunare();
    index++;
  }
  else {
    while( s[index] >= '0' && s[index] <= '9' )
      nr = nr * 10 + s[index++] - '0';
  }

  return nr;
}

int inmultire() {
  int prod;

  prod = factor();
  while( s[index] == '*' || s[index] == '/' ) {
    if( s[index++] == '*' )
      prod *= factor();
    else
      prod /= factor();
  }

  return prod;
}

int adunare() {
  int sum;

  sum = inmultire();
  while( s[index] == '+' || s[index] == '-' ) {
    if( s[index++] == '+' )
      sum += inmultire();
    else
      sum -= inmultire();
  }

  return sum;
}

int main() {
  FILE *fin, *fout;
  int n;
  fin = fopen( "evaluare.in", "r" );
  fgets( s, MAXN, fin );
  fclose( fin );

  fout = fopen( "evaluare.out", "w" );
  index = 0;
  fprintf( fout, "%d", adunare() );
  fclose( fout );
  return 0;
}
