#include <fstream>
#include <cstring>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

#define LMAX 2
char op[4][4] = { "+-", "*/", "^", "" };

#define NX 100010
char S[NX], *p = S;

int eval(int x, int y, char c) {
	switch ( c ) {
		case '+': return x+y;
		case '-': return x-y;
		case '*': return x*y;
		case '/': return x/y;
	}
}

int expr( int lev ) {
	int x, y;

	if( lev == LMAX )
		if( *p == '(' )
			++p, x = expr(0), ++p;
		else
			for( x = 0; *p >= '0' && *p <= '9'; ++p )
				x = x * 10 + *p - '0';
	else
		for( x = expr(lev+1); strchr(op[lev], *p); x = y )
			y = eval( x, expr(lev+1), *p++ );
	return x;
}

int main(){
    fin.getline(S,100100);
    fout<<expr(0);
    return 0;
}
