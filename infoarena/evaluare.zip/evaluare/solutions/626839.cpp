#include <cstring>
#include <fstream>
using namespace std;
#define maxN 100001
#define prioritateMax 2
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char operatii[2][4] = {"+-", "*/"};
char *p, expr[maxN];

int evaluare(int nivel)
{
    int r = 0;
    if(nivel == prioritateMax)
    {
        if(*p == '(')
        {
            p++;
            r = evaluare(0);
            p++;
        }
        else
            for(;strchr("1234567890", *p) && *p != '\0'; p++)
                r = r*10 + ((*p) - '0');
    }
    else
    {
        r = evaluare(nivel+1);
        while(strchr(operatii[nivel], *p) && *p != '\0')
            switch(*p)
            {
                case '+' : p++; r += evaluare(nivel+1); break;
                case '-' : p++; r -= evaluare(nivel+1); break;
                case '*' : p++; r *= evaluare(nivel+1); break;
                case '/' : p++; r /= evaluare(nivel+1); break;
            }
    }
    return r;
}

int main()
{
    p = expr;
    fin >> expr;
    fout << evaluare(0);
    fout.close();
    return 0;
}
