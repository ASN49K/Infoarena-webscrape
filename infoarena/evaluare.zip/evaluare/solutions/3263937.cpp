#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");


int p1(string &sir, int &poz);

int p2(string &sir, int &poz){
    int total=p1(sir,poz);
    while(sir[poz]=='*' || sir[poz]=='/'){
        if(sir[poz]=='*'){
            poz++;
            total*=p1(sir,poz);
        }
        else{
            poz++;
            total/=p1(sir,poz);
        }
    }
    return total;
}

int p3(string &sir, int &poz){
    int total=p2(sir,poz);
    while(sir[poz]=='+' || sir[poz]=='-'){
        if(sir[poz]=='+'){
            poz++;
            total+=p2(sir,poz);
        }
        else{
            poz++;
            total-=p2(sir,poz);
        }
    }
    return total;
}

int p1(string &sir, int &poz){
    int total=0;
    if(sir[poz]=='('){
        poz++;
        total+=p3(sir,poz);
        poz++;
    }
    else{
        while(sir[poz]>='0' && sir[poz]<='9'){
            total*=10;
            total+=sir[poz]-'0';
            poz++;
        }
    }
    return total;
}

int main()
{
    string sir;
    fin>>sir;
    int poz=0;
    fout<<p3(sir,poz);
    return 0;
}
