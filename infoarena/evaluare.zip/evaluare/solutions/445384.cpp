#include<cstring>
#include<fstream>
#include<string>
#include<utility>
using namespace std;

#define through( i, x ) for ( i = x.begin(); i < x.end(); ++i )
#define elif else if
#define elsw else switch

typedef pair<int, string::iterator> p_intit;
typedef string::iterator str_it;

const int DEF = 2000000000;

void read();
void write();

p_intit compute_bracket( str_it i );
p_intit compute_number( str_it i );
inline bool isoperator( char ch )
{
	return ch == '+' || ch == '-' || ch == '*' || ch == '/';
}
void put_bracket();

string expr;
int mx = -2000000000;

int main()
{
	read();
	
	str_it i = expr.begin();
	mx = compute_bracket( i ).first;
	write();
	return 0;
}

void read()
{
	ifstream fin( "evaluare.in" );
	fin >> expr;
	fin.close();
}

void write()
{
	ofstream fout( "evaluare.out" );
	fout << mx;
	fout.close();
}

p_intit compute_bracket( str_it i )
{
	int sum_expr = 0, last_numb = DEF;
	int open_br = 1;
	bool must_change = false;
	p_intit aux;
	
	while ( open_br && i < expr.end() )
	{
		must_change = false;
		if ( *i == '(' )
		{
			aux = compute_bracket( i + 1 );
			must_change = true;
		}
		elif ( isdigit( *i ) )
		{
			aux = compute_number( i );
			must_change = true;
		}
		elif ( *i == ')' )
		{
			if ( last_numb != DEF )
				sum_expr += last_numb;
			break;
		}
		elif ( ( *i == '+' || *i == '-' ) && last_numb != DEF )
		{
			sum_expr += last_numb;
			last_numb = DEF;
		}
		
		if ( must_change )
		{
		if ( !( i - 1 > expr.begin() ) || !isoperator( *( i - 1 ) ) )
				last_numb = aux.first;
			elsw ( *( i - 1 ) )
			{
			case '+':
				if ( *( aux.second + 1 ) == '*' || *( aux.second + 1 ) == '/' )
					last_numb = aux.first;
				else
				{
					sum_expr += aux.first;
					last_numb = DEF;
				}
				break;
			case '-':
				if ( *( aux.second + 1 ) == '*' || *( aux.second + 1 ) == '/' )
					last_numb = aux.first;
				else
				{
					sum_expr -= aux.first;
					last_numb = DEF;
				}
				break;
			case '*':
				last_numb *= aux.first;
				break;
			case '/':
				last_numb /= aux.first;
				break;
			};
			i = aux.second;
		}
			
		++i;
	}
	
	if ( last_numb != DEF )
		sum_expr += last_numb;
			
	if ( sum_expr > mx )
		mx = sum_expr;
	
	return make_pair( sum_expr, i );
}

p_intit compute_number( str_it i )
{
	int number = 0;
	while ( isdigit( *i ) && i < expr.end() )
	{
		number *= 10;
		number += *i - '0';
		++i;
	}
	return make_pair( number, i - 1 );
}
