#include <iostream>
#include <fstream>

using namespace std;

char sir[100000],*p=sir;

long termen();
long factor();

long eval()
{
    long r = termen();
    while(*p=='+' || *p=='-')
    {
        switch(*p)
        {
        case '+':
            p++;
            r=r+termen();
            break;
        case '-':
            p++;
            r=r-termen();
            break;
        }
    }
    return r;
}

long termen()
{
    long r = factor();
    while(*p=='*' || *p=='/')
    {
        switch(*p)
        {
        case '*':
            ++p;
            r=r*factor();

            break;
        case '/':
            ++p;
            r=r/factor();

            break;
        }
    }
    return r;
}

long factor()
{
    long r=0;
    if(*p=='(')
    {
        ++p;
        r = eval();
        ++p;
    }
    else
    {
        while(*p>='0' && *p <= '9' )
        {
            r=r*10+ (*p)-'0';
            ++p;
        }
    }
    return r;
}

int main()
{
    ifstream in("evaluare.in");
    ofstream out("evaluare.out");
    in >> sir;
    out << eval();
    return 0;
}
