#include <bits/stdc++.h>

using namespace std;

ifstream fin("txt.in");
ofstream fout("txt.out");
char c[102], *p = c;

static inline int eval();
static inline int factor();
static inline int numar();
static inline int prod();

static inline int factor() {
    int x = 0;
    if(*p == '(') {
        p++;
        x = eval();
        p++;
    }
    else x = numar();
    return x;
}

static inline int prod() {
    int x = factor();
    while(*p == '*' || *p == '/') {
        if(*p == '*') {
            p++;
            x *= factor();
        }
        else {
            p++;
            x /= factor();
        }
    }
    return x;
}

static inline int numar() {
    int x = 0;
    while('0' <= *p && *p <= '9') {
        x = x * 10 + *p - '0';
        p++;
    }
    return x;
}

static inline int eval() {
    int x = prod();
    while(*p == '+' || *p == '-') {
        if(*p == '+') {
            p++;
            x += prod();
        }
        else {
            p++;
            x -= prod();
        }
    }
    return x;
}

int main() {
    fin >> c;
    fout << eval();

    return 0;
}
