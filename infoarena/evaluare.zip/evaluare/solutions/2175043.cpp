#include <fstream>

using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
const int nmax = 1000001;
char s[nmax],*p;
int eval();
int termen();
int factor();
int main() {
    fin >> s;
    p = s;
    fout << eval();
    return 0;
}
int eval() {
    int r = termen();
    while (*p == '+' || *p == '-')
        if (*p == '+') {
            p++;
            r = r + termen();
        }
        else {
            p++;
            r = r - termen();
        }
    return r;
}
int termen() {
    int r = factor();
    while (*p == '*' || *p == '/')
        if (*p == '*') {
            p++;
            r = r * factor();
        }
        else {
            p++;
            r = r / factor();
        }
    return r;
}
int factor() {
    int r = 0;
    if (*p == '(') {
        p++;
        r = eval();
        p++;
    } else {
        while (*p <= '9' && *p >= '0') {
            r = r * 10 + (int) *p - '0';
            p++;
        }
    }
    return r;
}
