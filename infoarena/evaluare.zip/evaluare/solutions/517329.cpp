#include <stdio.h>
#include <string.h>

char s[100001];

int paranteze (long &st, long &dr)
{
	long nr = 0;
	for(long i = st; i<=dr; i++)
		if( s[i] == '(')
			nr++;
	for(long i = st; i<=dr; i++)
		if( s[i] == ')')
			nr--;
	if(nr == 0)
		return 1;
	return 0;
}

long semn(long st, long dr, char c1, char c2)
{
	long nrr = 0;
	for(long i = st; i<=dr; i++)
	{
		if(s[i] == '(')
			nrr++;
		else
			if(s[i] == ')')
				nrr--;
			else
				if( (s[i] == 'c1' || s[i] == 'c2') && nrr == 0)
					return i;
	}
	return -1;
}

long transf(long st, long dr)
{
	long x = 0;
	for(long i = st; i<=dr; i++)
		x = x*10 + (s[i] - '0');
	return x;
}

int fct (long st, long dr)
{
	while(s[st] == ' ')
		st++;
	while(s[dr] == ' ')
		dr--;
	if(paranteze(st, dr))
	{
		long ss = semn(st, dr, '+', '-');
		if(ss == -1)
			ss = semn(st, dr, '*', '/');
		if(ss == -1)
			return transf(st, dr);
		long s1 = fct(st, ss-1), s2 = fct(ss+1, dr);
		switch(s[ss])
		{
			case '+': return s1+s2;
			case '-':  return s1-s2;
			case '*': return s1*s2;
			default:  return s1/s2;
		}
	}
}

int main ()
{
	freopen("evaluare.in", "r", stdin);
	freopen("evaluare.out", "w", stdout);
	
	//char s[90];
	fgets(s, 100000, stdin);
	long n =  strlen(s);

	printf("%ld\n", fct(0, n-1));

	return 0;
}
