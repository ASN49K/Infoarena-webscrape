#include <bits/stdc++.h>

using namespace std;
const long M = 100010;
char S[M], *p=S;
long termen();
long factor();

long eval() {
    long r = termen();
    while ( *p=='+' || *p=='-' ) {
        switch ( *p ) {
            case '+':
                ++p;                        // trecem peste semnul "+"
                r += termen();
                break;
            case '-':
                ++p;                        // trecem peste semnul "-"
                r -= termen();
                break;
        }
    }
    return r;
}

/*
 * Functia termen() se ocupa de continutul unui termen. Acesta este compus la randul
 * lui din factori inmultiti.
 */
long termen() {
    long r = factor();
    while ( *p=='*' || *p=='/' ) {
        switch ( *p ) {
            case '*' :
                ++p;
                r *= factor();
                break;
            case '/':
                ++p;
                r /= factor();
                break;
        }
    }
    return r;
}

long factor()
{
    long r = 0;
    if (*p == '(')
    {
        ++p;
        r = eval();
        ++p;
    } else
    {
        while (*p >= '0' && *p<='9')
        {
            r = r*10 + *p -'0';
            ++p;
        }

    }

    return r;

}

int main()
{
     fgets(S, M, fopen("evaluare.in", "r"));
    fprintf(fopen("evaluare.out", "w"), "%ld\n", eval());
    return 0;
}
