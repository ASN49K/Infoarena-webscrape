#include<stdio.h>
#include<string.h>
#define N 100005
#define RR 1000000001
int v[N], i, desc=0,op[N], stack[N],n, j=1, k=1;
char sir[N];
inline int rez(int a, int b, char c)
{
switch(c)
	{
		case '+': return a+b;
		case '-': return a-b;
		case '*': return a*b;
		case '/': return a/b;
	}
}

void rezolva()
	{int semn=1, nr;
		for(i=0;i<=n;i++)
		{
			if(sir[i]=='(')
				{
					stack[k]=RR+5;
					++k;
			}
			else if(sir[i]==')')
					{semn=1;
						for(--k;stack[k]!=RR+5;--k)
							{
								v[j]=stack[k];
								stack[k]=0;
								++j;}
						stack[k]=0;
			}
			else if(sir[i]=='+')
					{semn=1;
						if(stack[k-1]==RR+1 || stack[k-1]==RR+2 || stack[k-1]==RR+3 || stack[k-1]==RR+4)
						{
							while(stack[--k]==RR+1 || stack[k]==RR+2 || stack[k]==RR+3 || stack[k]==RR+4 && k>=1)
							{
								v[j]=stack[k];
								stack[k++]=0;
								++j;
							}
							stack[k++]=RR+1;
						}
						else 
						{
							stack[k]=RR+1; 
							++k;
						}
					}
			else if(sir[i]=='-')
					{if(stack[k-1]==RR+5)semn=-1;
			else if(stack[k-1]==RR+1 || stack[k-1]==RR+2 || stack[k-1]==RR+3 || stack[k-1]==RR+4)
							{
								while(stack[--k]==RR+1 || stack[k]==RR+2 || stack[k]==RR+3 || stack[k]==RR+4 && k>=1)
							{
								v[j]=stack[k];
								stack[k++]=0;
								++j;
								}
								stack[k++]=RR+2;
						}
			else 
						{
							stack[k]=RR+2; 
							++k;
						}
			}
			else if(sir[i]=='*')
					{semn=1;
						if(stack[k-1]==RR+3 || stack[k-1]==RR+4)
						{
							while(stack[--k]==RR+3 || stack[k]==RR+4 && k>=1)
							{
								v[j]=stack[k];
								stack[k++]=0;
								++j;
							}
							stack[k++]=RR+3;
						}
						else 
						{
							stack[k]=RR+3; 
							++k;
						}
					}
			else if(sir[i]=='/')
					{semn=1;
						if(stack[k-1]==RR+3 || stack[k-1]==RR+4)
							{
								while(stack[--k]==RR+3 || stack[k]==RR+4 && k>=1)
							{
								v[j]=stack[k];
								stack[k++]=0;
								++j;
								}
								stack[k++]=RR+4;
						}
						else 
						{
							stack[k]=RR+4; 
							++k;
						}
			}
			else if(i==n)
					{
						for(;k>0;)
							{
								v[j++]=stack[--k];
								stack[k]=0;
						}
			}
			else 
					{
						for(nr=0;sir[i]>='0' && sir[i]<='9';++i)
							nr=nr*10+sir[i]-'0';
						--i;
						v[j]=nr*semn;;
						semn=1;
						++j;
			}
		}
		
	}
	
int main()
	{
		freopen("evaluare.in","r",stdin);
		freopen("evaluare.out","w",stdout);
		scanf("%s",&sir);
		n=strlen(sir);
		rezolva();
		k=1;
		for(i=1;i<j;++i)
			if(v[i]==RR+1)
			{			
				stack[k-2]=rez(stack[k-2],stack[k-1],'+');
				stack[--k]=0;
			}
			else if(v[i]==RR+2)
			{
				stack[k-2]=rez(stack[k-2],stack[k-1],'-');
				stack[--k]=0;
			}
			else if(v[i]==RR+3)
			{
				stack[k-2]=rez(stack[k-2],stack[k-1],'*');
				stack[--k]=0;
			}
			else if(v[i]==RR+4)
			{
				stack[k-2]=rez(stack[k-2],stack[k-1],'/');
				stack[--k]=0;
			}
			else 
			{				
					stack[k]=v[i];
					++k;
			}	
		printf("%d\n",stack[1]);
		return 0;
	}
		