# include <fstream>
# include <cstring>

using namespace std;

ifstream f ("evaluare.in");
ofstream g ("evaluare.out");

int i;
char str[ 100003 ];

int evaluare();
int expresia();
int termenul();

int evaluare()
{
    int res = expresia();

    while (str[ i ] == '+' || str[ i ] == '-')
    {
        if (str[ i ] == '+')
            i ++, res += expresia();
        else
            i ++, res -= expresia();
    }

    return res;
}

int expresia()
{
    int res = termenul();

    while (str[ i ] == '*' || str[ i ] == '/')
    {
        if (str[ i ] == '*')
            i ++, res *= expresia();
        else
            i ++, res /= expresia();
    }

    return res;
}

int termenul()
{
    int res = 0;

    if (str[ i ] == '(')
    {
        i ++;
        res = evaluare();
        i ++;
    }
    else while(isdigit(str[ i ]))
        res = res * 10 + (str[ i ] - '0'), i ++;

    return res;
}
int main()
{
    f.getline(str, 100000);
    g << evaluare() << "\n";
    return 0;
}
