#include <iostream>
#include <string>
#include <fstream>
#include <stack>
#define NMAX 100001
using namespace std;

ifstream in("evaluare.in");
ofstream out("evaluare.out");

int n,x,y,rez;
string s;
char c;
stack<int> numere;
stack<char> semne;

int readNr(int &x)
{
    int rez = 0;
    while(s[x]>='0' && s[x]<='9' && x<n)
    {
        rez = rez*10 + s[x]-'0';
        x++;
    }
    //x--;
    return rez;
}

int getPriority(char c)
{
    int pr=0;
    switch(c)
    {
        case '(' : pr = 0; break;
        case '+' : pr = 1; break;
        case '-' : pr = 1; break;
        case '*' : pr = 2; break;
        case '/' : pr = 2; break;
    }

    return pr;
}

int calcNr(int x,int y,char c)
{
    int rez=0;
    switch(c)
    {
        case '+' : rez = y+x; break;
        case '-' : rez = y-x; break;
        case '*' : rez = x*y; break;
        case '/' : rez = y/x; break;
    }
    return rez;
}

void emptyStack()
{

    while(!semne.empty())
    {
      if(semne.top()=='(') return;

      c = semne.top(); semne.pop();
      x = numere.top(); numere.pop();
      y = numere.top(); numere.pop();

      numere.push(calcNr(x,y,c));
    }
}

int main()
{
    in >>s;
    n = s.size();

    int i = 0;
    while(i<n)
    {

      if(s[i]>='0' && s[i]<='9')
      {
          rez = readNr(i);
          numere.push(rez);


      }
      else
      {
          if(s[i]==')')
          {
              emptyStack();
          }
          else
          {

              while(!semne.empty() && getPriority(s[i])<=getPriority(semne.top()))
              {
                  c = semne.top(); semne.pop();
                  x = numere.top(); numere.pop();
                  y = numere.top(); numere.pop();
                  numere.push(calcNr(x,y,c));

              }
              semne.push(s[i]);
          }

          i++;
      }
    }

    emptyStack();

    out << numere.top();

    return 0;
}
