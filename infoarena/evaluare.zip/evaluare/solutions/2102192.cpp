#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>
#include <cmath>
#define MaxN 100005
using namespace std;

FILE*IN,*OUT;

int  Op[MaxN],Var[MaxN],VarSize=0,OpSize=0;
char str[MaxN];
void SolvePlus()
{
    VarSize--;
    OpSize--;
    Var[VarSize]+=Var[VarSize+1];
}
void SolveMinus()
{
    VarSize--;
    OpSize--;
    Var[VarSize]-=Var[VarSize+1];
}
void SolveMultiply()
{
    VarSize--;
    OpSize--;
    Var[VarSize]*=Var[VarSize+1];
}
void SolveDivide()
{
    VarSize--;
    OpSize--;
    Var[VarSize]/=Var[VarSize+1];
}
void SolveParenthesis()
{
    while(Op[OpSize]!=0)
    {
        if(Op[OpSize]==1)
            SolvePlus();
        else if(Op[OpSize]==2)
            SolveMinus();
        else if(Op[OpSize]==3)
            SolveMultiply();
        else SolveDivide();
    }
    OpSize--;
}
int main()
{
    IN=fopen("evaluare.in","r");
    OUT=fopen("evaluare.out","w");

    fscanf(IN,"%s",str+1);
    str[0]='(';
    str[strlen(str)]=')';

    for(int i=0;str[i]!=0;i++)
    {
        if(str[i]=='(')
            Op[++OpSize]=0;
        else if(str[i]=='+'||str[i]=='-')
        {
            while(Op[OpSize]>=1)
            {
                if(Op[OpSize]==1)
                    SolvePlus();
                else if(Op[OpSize]==2)
                    SolveMinus();
                else if(Op[OpSize]==3)
                    SolveMultiply();
                else SolveDivide();
            }
            if(str[i]=='-')
                Op[++OpSize]=2;
            else Op[++OpSize]=1;
        }
        else if(str[i]=='*'||str[i]=='/')
        {
            while(Op[OpSize]>=3)
            {
                if(Op[OpSize]==3)
                    SolveMultiply();
                else SolveDivide();
            }
            if(str[i]=='/')
                Op[++OpSize]=4;
            else Op[++OpSize]=3;
        }
        else if(str[i]==')')
            SolveParenthesis();
        else if(str[i]>='0'&&str[i]<='9')
        {
            int nr=0;
            while(str[i]>='0'&&str[i]<='9')
                nr=nr*10+str[i++]-'0';
            i--;
            Var[++VarSize]=nr;
        }
    }
    fprintf(OUT,"%d\n",Var[1]);
    return 0;
}
