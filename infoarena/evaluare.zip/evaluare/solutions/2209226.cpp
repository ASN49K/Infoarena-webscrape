#include <fstream>
#include <string.h>

using namespace std;

ifstream in("evaluare.in");
ofstream out("evaluare.out");

const int MAX = 100001;
char s[MAX], *p=s;

int expr();
int term();
int fact();

int main()
{
    in>>s;
    out<<expr();
    return 0;
}


int expr()
{
    int ans = term();
    while(*p == '+' || *p == '-')
    {
        char semn = *p;
        ++p;
        int val = term();
        if(semn == '+')
            ans = ans+val;
        else ans = ans-val;
    }
    return ans;
}

int term()
{
    int ans = fact();
    while(*p == '*' || *p == '/')
    {
        char semn = *p;
        p++;
        int val = fact();
        if(semn == '*')
            ans = ans*val;
        else ans = ans/val;
    }
    return ans;
}

int fact()
{
    if('0'<=*p and *p<='9')
    {
        int ans =0;
        while('0'<=*p and *p<='9')
        {
            ans =ans * 10 + *p-'0';
            ++p;
        }
        return ans;
    }
    else
    {
        ++p; // (
        int ans = expr();
        ++p; // )
        return ans;
    }
}
