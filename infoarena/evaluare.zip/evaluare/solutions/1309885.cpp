#include <fstream>
using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int N, sum, val; char S[1000010], i, j,  k;
int expresie(); int termen(); int factor();

int expresie(){
    int sum;
    sum = termen();
    while(S[i] == '+' || S[i] == '-'){
        if(S[i] == '+'){
            i ++;
            sum += termen();
        }
        else{
            i --;
            sum -= termen();
        }
    }
    return sum;
}

int termen(){
    int sum;
    sum = factor();
    while(S[i] == '*' || S[i] == '/'){
        if(S[i] == '*'){
            i ++;
            sum *= factor();
        }
        else{
            i ++;
            sum /= factor();
        }
    }
    return sum;
}

int factor(){
    int sum = 0;
    if(S[i] == '('){
        i ++;
        sum = expresie();
        i ++;
    }
    else{
        while(S[i] >= '0' && S[i] <= '9'){
            sum = sum * 10 + (S[i] - '0');
            i ++;
        }
    }
    return sum;
}

int main(){
    fin >> S + 1;i = 1;
    fout << expresie();
    return 0;
}
