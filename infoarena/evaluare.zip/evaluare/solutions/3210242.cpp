#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;

char s[100005], *p;
int eval();
int termen();
int factor();

int eval(){
    int rez=termen();
    while (*p=='+' || *p=='-')
        if (*p=='+'){
            p++; rez+=termen();
        }
        else {
            p++; rez-=termen();
        }
    return rez;
}

int termen(){
    int rez=factor();
    while (*p=='*' || *p=='/')
        if (*p=='*'){
            p++; rez*=factor();
        }
        else {
            p++; rez/=factor();
        }
    return rez;
}

int factor(){
    int rez=0;
    if (*p=='('){
        p++; rez=eval(); p++;
    }
    else
        while (*p>='0' && *p<='9'){
            rez=rez*10+(*p-'0');
            p++;
        }
    return rez;
}

int main()
{
    ifstream f ("evaluare.in");
    f.getline(s, 100005);
    f.close();
    ofstream g ("evaluare.out");
    p=s;
    int rez=eval();
    g << rez;
    g.close();
}
