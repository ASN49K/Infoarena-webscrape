/*

 * Se va folosi recursivitatea indirecta in rezolvarea problemei.

 * Vom observa ca orice expresie este "impartita" in urmatoarele componente:

 * 1) termeni ai unei adunari, separati de '+' sau '-'

 * 2) factori ai unui produs, separati de '*' sau '/'

 * 3) subexpresii, incadrate intre paranteze '(' si ')' sau numere formate numai din cifre.

 * Prezenta subexpresiilor ne indica faptul ca la un moment dat va fi necesara intoarcerea in cazul (1)

 * si implicit a necesitatii recursivitatii indirecte.

 */



#include <cstdio>



const long MAX = 100010;

char s[MAX];
int i = 0;



long termen();

long factor();



/*

 * Functia eval() va "aduna" toti termenii unei expresii/subexpresii.

 */

long eval() {

	long rezultat = termen();

	while ( s[i] =='+' || s[i]=='-' ) {

		switch ( s[i] ) {

			case '+':

				++i;						// trecem peste semnul "+"

				rezultat += termen();

				break;

			case '-':

				++i;						// trecem peste semnul "-"

				rezultat -= termen();

				break;

		}

	}

	return rezultat;

}



/*

 * Functia termen() se ocupa de continutul unui termen. Acesta este compus la randul

 * lui din factori inmultiti.

 */

long termen() {

    long rezultat = factor();
    while(s[i] == '*' || s[i] == '/')
    {
        switch(s[i])
        {
            case '*':
                i++;
                rezultat *= factor();
                break;
            case '/':
                i++;
                rezultat /= factor();
                break;

        }
    }

    return rezultat;
}


/*

 * Functia factor() va returna valoarea unui singur factor, care poate fi o subexpresie

 * sau un numar natural

 */

long factor() {

    long rezultat = 0;

    if(s[i] == '(')
    {
        i++;
        rezultat = eval();
        i++;
    }
    else
    {
        while(s[i] >= '0' && s[i] <= '9')
        {
            rezultat = rezultat * 10 + s[i] -'0';
            i++;
        }
    }
    return rezultat;
}



int main() {

    fgets(s, MAX, fopen("evaluare.in", "r"));
    fprintf(fopen("evaluare.out", "w"), "%ld\n", eval());

    return 0;

}
