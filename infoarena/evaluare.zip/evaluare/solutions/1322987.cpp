#include<fstream>
#include <string.h>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
int nr,od[100001],vf,vf1,ok,k,n,i;
char s[100001],pr[256],op[100001];
int calcul(char x,int a, int b){
            if(x=='+')
            return b+a;
            if(x=='-')
            return b-a;
            if(x=='*')
            return b*a;
            if(x=='/')
            return b/a;}

int main()
{ok=0;
pr[')']=0;
pr['+']=1;
pr['-']=1;
pr['*']=2;
pr['/']=2;;
    f>>s+1;
n=strlen(s+1);
for(i=1;i<=n;i++){
    if(s[i]>='0'&&s[i]<='9'){
            nr=nr*10+s[i]-'0';
        ok=1;}
    else{
        if(ok==1){
            od[++vf1]=nr;
            nr=0;
            ok=0;}
        if(s[i]=='(')
           op[++vf]='(';
           else{
                if(s[i]==')'){
                    while(vf>0&&op[vf]!='('){

                        k=calcul(op[vf--],od[vf1],od[vf1-1]);
                        vf1--;
                        od[vf1]=k;
                        }
                        vf--;
                       }
                else{
                    while(vf>0&&pr[s[i]]<=pr[op[vf]]){
                            k=calcul(op[vf],od[vf1],od[vf1-1]);
                            vf1--;
                            vf--;
                            od[vf1]=k;}
                            op[++vf]=s[i];}}}}
            if(ok==1){
                od[++vf1]=nr;
                ok=0;
                nr=0;
                while(vf>0){
                    k=calcul(op[vf],od[vf1],od[vf1-1]);
            vf--;
            vf1--;
            od[vf1]=k;
        }}
g<<od[1];
    return 0;
}
