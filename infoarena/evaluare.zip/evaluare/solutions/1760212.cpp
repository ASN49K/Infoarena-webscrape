#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;
char s[100001];
int fp[100001];
char st[100001];
int sc[100001];
int k,i,n;
inline int val(char a)
{
    switch(a)
    {
        case '(' :return 0;break;
        case ')' :return 0;break;
        case '/' :return 1;break;
        case '*' :return 1;break;
        case '+' :return 2;break;
        case '-' :return 2;break;
    }
}
int prioritate(char a, char b)
{
    return val(a)-val(b);
}
int semn(char s)
{
    switch(s)
    {

        case '/' :return -1;break;
        case '*' :return -2;break;
        case '+' :return -3;break;
        case '-' :return -4;break;
    }
}
long long int operatie(int a, int b, int s)
{
    switch(s)
    {
        case -1 :return a/b;break;
        case -2 :return a*b;break;
        case -3 :return a+b;break;
        case -4 :return a-b;break;
    }
}
int main()
{
    ifstream f("evaluare.in");
    ofstream g("evaluare.out");
    f.getline(s,100001);
    for(i=0; i<strlen(s); i++)
        if(s[i]>='0' && s[i]<='9')
        {
            n++;
            while(i<strlen(s) && s[i]>='0' && s[i]<='9')
            fp[n]=fp[n]*10+s[i++]-'0';
            i--;
        }

        else if(s[i]==')')
        {
            while(k>0 && st[k]!='(')
                fp[++n]=semn(st[k--]);
            k--;
            if(k<0)
                k++;
        }
        else if(k==0 ||(prioritate(s[i],st[k])>0 && st[k]=='(') || prioritate(s[i],st[k])<=0 ) ///stiva goala sau prioritate mai mare sau prioritate mica cu ultimul bagat '('
            st[++k]=s[i];
        else
            if(prioritate(s[i],st[k])>0)
        {
            while(k>0 && prioritate(s[i],st[k])>0)
            fp[++n]=semn(st[k--]);
            st[++k]=s[i];
        }
        while(k>0)
         fp[++n]=semn(st[k--]);
         for(i=1;i<=n;i++)
            cout<<fp[i]<<" ";
         cout<<endl<<endl;
         i=1;
         while(i<=n)
         {
             if(fp[i]>=0)
              sc[++k]=fp[i];
            else
                sc[--k]=operatie(sc[k],sc[k+1],fp[i]);
            i++;
        }
            cout<<sc[1];
            return 0;
}
