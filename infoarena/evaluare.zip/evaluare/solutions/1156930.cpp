/*
 * Se va folosi recursivitatea indirecta in rezolvarea problemei.
 * Vom observa ca orice expresie este "impartita" in urmatoarele componente:
 * 1) termeni ai unei adunari, separati de '+' sau '-'
 * 2) factori ai unui produs, separati de '*' sau '/'
 * 3) subexpresii, incadrate intre paranteze '(' si ')' sau numere formate numai din cifre.
 * Prezenta subexpresiilor ne indica faptul ca la un moment dat va fi necesara intoarcerea in cazul (1)
 * si implicit a necesitatii recursivitatii indirecte.
 */

#include <cstdio>
const long MAX = 100010;
char S[MAX], *p = S;

/*
 * Functia eval() va "aduna" toti termenii unei expresii/subexpresii.
 */

long eval()
{
    long r = termen();
    while ( *p=='+' || *p=='-' )
    {
        switch ( *p )
        {
            case '+':
                ++p;                        // trecem peste semnul "+"
                r += termen();
                break;
            case '-':
                ++p;                        // trecem peste semnul "-"
                r -= termen();
                break;
        }
    }
    return r;
}

/*
 * Functia termen() se ocupa de continutul unui termen. Acesta este compus la randul
 * lui din factori inmultiti.
 */

long termen()
{
    long r = factor();
    while ( *p=='*' || *p=='/' ) {
        switch ( *p ) {
            case '*' :
                ++p;
                r *= factor();
                break;
            case '/':
                ++p;
                r /= factor();
                break;
        }
    }
    return r;
}

/*
 * Functia factor() va returna valoarea unui singur factor, care poate fi o subexpresie
 * sau un numar natural
 */

long factor()
{
    long r=0;
    if ( *p == '(' ) {                      // avem o subexpresie
        ++p;                                // trecem peste '('
        r = eval();
        ++p;                                // trecem peste ')'
    } else {
        while ( *p>='0' && *p<='9' )  {       // avem un numar
            r = r*10 + *p - '0';
            ++p;
        }
    }
    return r;
}

int main()
{
    fgets(S, MAX, fopen("evaluare.in", "r"));
    fprintf(fopen("evaluare.out", "w"), "%ld\n", eval());
    return 0;
}
