#include <fstream>
#define mF "evaluare"
std::ifstream in(mF ".in");
std::ofstream out(mF ".out");
char V[100001], *i = V; int A();
int D()
{
	int r = 0; while ('0' <= *i and *i <= '9') (r *= 10) += *i++ - '0';
	return r;
}
int C() {return *i++ == '('? A(): (--i, D());}
int B()
{
	int r = C(); for (;;) {switch (*i++)
	{case '*': r *= C(); continue; case '/': r /= C(); continue;} break;}
	return --i, r;
}
int A()
{
	int r = B(); for (;;) {switch (*i++)
	{case '+': r += B(); continue; case '-': r -= B(); continue;} break;}
	return r;
}
int main() {in >> V; out << A();}

