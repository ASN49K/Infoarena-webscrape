#include <bits/stdc++.h>

using namespace std;

const int MAX_LEN = 100'00;
const int MAX_LVL = 2; // nivel maxim de prioritate

const char op[MAX_LVL + 1][4] = {"+-", "*/", ""};

char s[MAX_LEN], *p;
// *p este pointer la inceputul expresiei s

struct Node {
    int val;
    char op;
    Node *st;
    Node *dr;
    
    Node(int a = 0, char b = 0, Node *c = 0, Node *d = 0): val(a), op(b), st(c), dr(d) {}
} *root;
// *A este pointer la radacina arborelui

//  expresie = termen +- termen +- ... +- termen
//  termen = factor */ factor */ ... */ factor
//  fie factor = (expresie), fie factor = constanta 
  
Node *expresie(int lvl) {
    Node *x;
    
    if (lvl == MAX_LVL) {
        if (*p == '(') {
            p++;
            x = expresie(0); // expresie de nivel 0 (E(0))
            p++;
        } else {
            for (x = new Node(); *p >= '0' && *p <= '9'; p++)
                x->val = x->val * 10 + (*p - '0');
        }
    } else {
        // Evaluam expresia E[1](lvl + 1) op(lvl) E[2](lvl + 1) op(lvl) ...
        // Initial, x = E[1](lvl + 1). La al i-lea operator op(lvl), avem
        //    - x = E[1](lvl + 1) op(lvl) ... op(lvl) E[i](lvl + 1)
        //    - y = x op(lvl) E[i + 1](lvl + 1)
        x = expresie(lvl + 1);
        while (strchr(op[lvl], *p)) {
            Node* y = new Node(0, *p++, x, expresie(lvl + 1));
            x = y;
        }
    }
    
    return x;
}

int evaluare(Node *nod) {
    switch (nod->op) {
        case '+': return evaluare(nod->st) + evaluare(nod->dr);
        case '-': return evaluare(nod->st) - evaluare(nod->dr);
        case '*': return evaluare(nod->st) * evaluare(nod->dr);
        case '/': return evaluare(nod->st) / evaluare(nod->dr);
        default: return nod->val;
    }
}

int main() {
    ifstream f("evaluare.in");
    ofstream g("evaluare.out");
    
    s[0] = '0';
    s[1] = '+';
    int i = 2;
    while (f >> s[i])
        i++;
    s[i++] = '+';
    s[i++] = '0';
    s[i] = 0;
    
    p = s;
    
    root = expresie(0);
    g << evaluare(root) << "\n";
    
    f.close();
    g.close();
    return 0;
}
