#include <fstream>
#include <cstring>
#include <stack>
#define plus 1000000001
#define minus 1000000002
#define inm 1000000003
#define imp 1000000004
using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char s[100001];
int a[100001],n;

inline int P(char c)
{if(c=='+'||c=='-') return 1;
else return 2;
}

void Poloneza()
{stack <char> ST;
int i,nr;
char c;
for(i=0;s[i]!=0;i++)
   {if(s[i]=='(') ST.push(s[i]);
    if(s[i]>='0'&&s[i]<='9')
      {nr=0;
       while(s[i]>='0'&&s[i]<='9')
            {nr=nr*10+s[i]-'0';
             i++;
            }
       i--;
       a[n]=nr;n++;
      }
    if(s[i]==')')
      {while(ST.top()!='(')
            {c=ST.top();
             if(c=='+') a[n++]=plus;
             if(c=='-') a[n++]=minus;
             if(c=='*') a[n++]=inm;
             if(c=='/') a[n++]=imp;
             ST.pop();
            }
       ST.pop();
      }
    if(strchr("+-*/",s[i])!=0)
       {if(ST.empty()) ST.push(s[i]);
        else if(ST.top()=='(') ST.push(s[i]);
             else {while(!ST.empty()&&P(ST.top())>=P(s[i]))
                        {c=ST.top();
                         if(c=='+') a[n++]=plus;
                         if(c=='-') a[n++]=minus;
                         if(c=='*') a[n++]=inm;
                         if(c=='/') a[n++]=imp;
                         ST.pop();
                        }
                   ST.push(s[i]);
                  }
       }
   }
while(!ST.empty())
  {c=ST.top();
   if(c=='+') a[n++]=plus;
   if(c=='-') a[n++]=minus;
   if(c=='*') a[n++]=inm;
   if(c=='/') a[n++]=imp;
   ST.pop();
  }
}

void Evaluare()
{stack <int> ST;
int x,y,v,i;
for(i=0;i<n;i++)
    if(a[i]<plus) ST.push(a[i]);
    else {x=ST.top();ST.pop();
          y=ST.top();ST.pop();
          if(a[i]==plus) v=x+y;
          if(a[i]==minus) v=y-x;
          if(a[i]==inm) v=x*y;
          if(a[i]==imp)
            if(x!=0) v=y/x;
            else v=0;
          ST.push(v);
         }
fout<<ST.top();
}

int main()
{
fin.getline(s,100001);
Poloneza();
Evaluare();
    return 0;
}
