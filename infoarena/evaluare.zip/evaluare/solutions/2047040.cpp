// daca este (
    // vom avea inca un rezultat intermediar
// daca este cifra
    // daca are semn in fata:
        // daca inainte avem + sau - si dupa avem * sau /
            // facem * sau / si apoi - sau +
        // daca nu
            // facem calculul (cu rezultatul curent si cifra curenta)

#include <fstream>
#include <cstring>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char s[100003];
int  i = 0;

int expresie(), termen(), factor();

int expresie(){
    int r = termen();

    while(s[i] == '+' || s[i] == '-'){
        if(s[i] == '+'){
            i++;
            r += termen();
        }
        else{
            i++;
            r -= termen();
        }
    }
    return r;
}

int termen(){
    int r = factor();
    while(s[i] == '*' || s[i] == '/'){
        if(s[i] == '*'){
            i++;
            r*=factor();
        }
        else{
            i++;
            r/=factor();
        }
    }
    return r;
}

int factor(){
    int r = 0;
    if(s[i] == '('){
        i++;
        r=expresie();
        i++;
    }
    else{
        r = 0;
        while(s[i] >= '0' && s[i] <= '9'){
            r*=10;
            r+=s[i] - '0';
            i++;
        }
    }
    return r;
}

int main(){
    fin>>s;
    fout<<expresie();
    return 0;
}
