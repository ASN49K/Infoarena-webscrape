#include <stdio.h>
FILE *f;
char c;
long termen();
long numar();
long eval()
{long s=termen();
 while(c=='+'||c=='-')
 {if(c=='+')
  {c=fgetc(f);
   s+=termen();
  }
  else
  {c=fgetc(f);
   s-=termen();
  }
 }
 return s;
}

long termen()
{long s=numar();
 while(c=='*'||c=='/')
 {if(c=='*')
  {c=fgetc(f);
   s*=numar();
  }
  else
  {c=fgetc(f);
   s/=numar();
  }
 }
 return s;
}

long numar()
{long s;
 if(c=='(')
 {c=fgetc(f);
  s=eval();
  c=fgetc(f);
 }
 else
 {s=0;
   while(c>='0'&&c<='9')
  {s=s*10+c-'0';
   c=fgetc(f);
  }
 }
 return s;
}
int main ()
{f=fopen("eval.in","r");
 FILE *fout=fopen("eval.out","w");
 c=fgetc(f);
 fprintf(fout,"%ld",eval());
 fclose(f);
 fclose(fout);
 return 0;
}
