#include <cstdio>
#include <string>
#define maxn 100001

int eval();
int termen();
int fact();
char a[maxn],*p;

inline int fact()
{
	int t=0;
	if(*p=='(')++p,t=eval(),++p;
	else
		for(;*p>='0' && *p<='9';++p) t=t*10+*p-'0';
	return t;
}

inline int termen()
{
	int t=fact();
	while(1)
	{
		if(*p == '*')++p,t*=fact();
		else if(*p == '/') ++p, t/=fact();
		else break;
	}
	return t;
}
inline int eval()
{
	int t=termen();
	while(1)
	{
		if(*p == '+') ++p,t+=termen();
		else if(*p == '-') ++p,t-=termen();
		else break;
	}
	return t;
}


int main()
{
	freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	scanf("%s\n", &a);
	p=a;
	printf("%d\n", eval());
	return 0;
}
