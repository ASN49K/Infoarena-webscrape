#include <stdio.h>

using namespace std;
char c[100005],stiva[333330],*st;
int v[333330],*vt,lenghtN;
void citire(){

    scanf("%s",c);
}

int citireNumar(int i){
    int n=0;
    while(c[i]<=57&&c[i]>=48){

        n=n*10+c[i++]-48;

    }
    *++vt=n;
    return i;

}

int strlenght(char c[]){
    int a;
    for(a=0;c[a];)
    a++;
    return a;

}

char prioritete(char c){

    switch (c){
        case '(' :
        return 1;
        case '-' :
        case '+' :
        return 2;
        case '*' :
        case '/' :
        return 3;
    }

}

int calcul(int m,int n,char c){

    switch(c){

        case '*' :
        return m*n;
        case '/' :
        return m/n;
        case '-' :
        return m-n;
        case '+' :
        return m+n;
        default :
        return 10;
    }

}

int main()
{
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);

    citire();
    lenghtN=strlenght(c);
    vt=v;
    st=stiva;

    for(int i=0;i<=lenghtN-1;i++){

        if(c[i]<=57&&c[i]>=48){

            i=citireNumar(i)-1;

        }else{
            if(c[i]=='(')
               {
                   *++st='(';
                   continue;
               }
            if(c[i]==')'){

                while(*st!='('){
                    *(vt-1)=calcul(*(vt-1),*vt,*st--);
                    --vt;
                }
                st--;
                continue;
            }
            while(prioritete(c[i])<=prioritete(*st)){

                *(vt-1)=calcul(*(vt-1),*vt,*st--);
                --vt;
            }
            *++st=c[i];
        }
    }
    while(st!=stiva){

        *(vt-1)=calcul(*(vt-1),*vt,*st--);
        --vt;
    }

    printf("%d",*vt);

    return 0;
}
