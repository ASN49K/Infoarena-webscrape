#include <stdint.h>
#include <fstream>
#define valmax 100001
using namespace std;
fstream f1("evaluare.in", ios::in);
fstream f2("evaluare.out", ios::out);
char sir[valmax], *p;
int32_t expresie();
int32_t factor()
{
    ///returneaza valoarea factorului daca acesta este un  numar
    ///sau calcueaza  valoarea expresiei din paranteza
    int32_t val=0;
    if(*p=='(')
    {
        p++;
        val=expresie();
        p++;
    }
    else
    {
        while((*p>='0')&&(*p<='9'))
        {
            val=val*10+*p-'0';
            p++;
        }
    }

    return val;
}
int32_t termen()
///primesti un termen si il descompui in factori inmultindu i/ impartindu i
{
    int32_t f=factor();
    while((*p=='*')||(*p=='/'))
    {
        if(*p=='*')
        {
            p++;
            f*=factor();
        }
        else
        {
            p++;
            f/=factor();
        }
    }
    return f;
}
int32_t expresie()
///rezolva o expresie separand termenii si  adunandu i/ scazandu i
{
    int32_t t= termen();
    while((*p=='-')||(*p=='+'))
    {
        if(*p=='-')
        {
            p++;
            t-=termen();
        }
        else
        {
            p++;
            t+=termen();
        }
    }
    return t;
}
int main()
{
    f1>>sir;
    p=sir;
    f2<<expresie();
    return 0;
}
