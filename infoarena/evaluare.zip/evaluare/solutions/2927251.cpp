#include <fstream>
#include <cstring>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char x[100001];
int i=1;
int expresie();
int inmultire();
int operatie()
{
    int y=0;
    if(x[i]=='(')
    {
        i++;
        y=expresie();
        i++;
    }
    else
    {

        while(x[i]>='0' && x[i]<='9')
        {
            y=y*10+(x[i]-'0');
            i++;
        }

    }
    return y;

}
int expresie()
{
    int y=inmultire();
   while(x[i]=='+' || x[i]=='-')
   {
      if(x[i]=='+')
      {
          i++;
          int z=inmultire();
          y=y+z;
      }
      else if(x[i]=='-')
      {
          i++;
          int z=inmultire();
          y=y-z;
      }
   }

     return y;

}
int inmultire()
{
    int y=operatie();
    while(x[i]=='*' || x[i]=='/')
    {
        if(x[i]=='*')
        {
            i++;
            y=y*operatie();
        }
        else
        {
            i++;
            y=y/operatie
            ();
        }
    }
    return y;
}

int main()
{
    fin>>x+1;
    int p=expresie();
    fout<<p;



    return 0;
}
