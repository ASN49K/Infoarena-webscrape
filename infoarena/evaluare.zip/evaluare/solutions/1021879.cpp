#include <stdio.h>

FILE *f=fopen("evaluare.in","r");
FILE *g=fopen("evaluare.out","w");

int i;
char v[100001];

int grad2();
int grad1();
int pn();

int main()
{
	fscanf(f,"%s",&v);

	fprintf(g,"%d",grad1());

	return 0;
}

int grad1()
{
	long sol=grad2();
	while(v[i]=='+'||v[i]=='-')
		if(v[i]=='+')
		{
			i++;
			sol+=grad2();
		}
		else
		{
			i++;
			sol-=grad2();
		}
	return sol;
}

int grad2()
{
	long sol=pn();
	while(v[i]=='*'||v[i]=='/')
		if(v[i]=='*')
		{
			i++;
			sol*=pn();
		}
		else
		{
			i++;
			sol/=pn();
		}
	return sol;
}

int pn()
{
	long sol=0;
	if(v[i]=='(')
	{
		i++;
		sol+=grad1();
		i++;
	}
	else
		while(v[i]>='0'&&v[i]<='9')
		{
			sol=sol*10+v[i]-'0';
			i++;
		}
	return sol;
}