#include <cstring>
#include <fstream>

using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char s[100005];
int e1=0,e2=0;

int numar(int st,int dr)
{
    int nr=0;
    for(int i=st;i<=dr;i++)
    {
        nr=nr*10+(s[i]-48);
    }
    return nr;
}

int semn(int st,int dr,char s1,char s2)
{
    int cnt=0;
    for(int i=dr;i>=st;i--)
    {
        if(s[i]==')') cnt++;
        else if(s[i]=='(') cnt--;
        if((s[i]==s1||s[i]==s2)&&cnt==0)
            return i;
    }
    return -1;
}

int eval(int st,int dr)
{
    int poz=semn(st,dr,'+','-');
    if(poz!=-1)
    {

        int e1=eval(st,poz-1);
        int e2=eval(poz+1,dr);


        if(s[poz]=='+')
            return e1+e2;
        else
            return e1-e2;
    }
    ///___________________

    poz=semn(st,dr,'*','/');
    if(poz!=-1)
    {

        int e1=eval(st,poz-1);
        int e2=eval(poz+1,dr);


        if(s[poz]=='*')
            return e1*e2;
        else
            return e1/e2;
    }

    if(s[st]=='('&&s[dr]==')')
        return eval(st+1,dr-1);
    return numar(st,dr);
}

int main()
{

    fin.getline(s,100002);
    fout<<eval(0,strlen(s)-1);
    return 0;
}
