#include<cstdio>
#include<cstring>
#include<cctype>
#include<vector>
using namespace std;

int ee(vector<int> v)
{
	int r=0,t;
	vector<int>::iterator it=v.begin();
	t=*it;
	it++;
	for(;it!=v.end();it++){
		int op=*it;
		it++;
		int nr=*it;
		switch(op){
		case -1:
			r+=t;
			t=nr;
			break;
		case -2:
			t*=nr;
			break;
		case -3:
			r+=t;
			t=-nr;
			break;
		case -4:
			t/=nr;
		}
	}
	return r+t;
}
int parse(char *s)
{
	vector<int> v;
	while(strlen(s)){
		if(*s=='('){
			char *ss=s+1;
			int br=1;
			while(br){
				if(*ss=='(')
					br++;
				else if(*ss==')')
					br--;
				ss++;
			}
		    *(ss-1)='\0';
			v.push_back(parse(s+1));
			s=ss;
		}
		else if(isdigit(*s)){
			int n=0;
			while(isdigit(*s)){
				n=n*10+*s-'0';
				s++;
			}
			v.push_back(n);
		} else {
			if(*s=='+')
				v.push_back(-1);
			if(*s=='*')
				v.push_back(-2);
			if(*s=='-')
				v.push_back(-3);
			if(*s=='/')
				v.push_back(-4);
			s++;
		}
	}
	return ee(v);
}
char s[100005];
int main()
{
	freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	gets(s);
	printf("%d",parse(s));
	return 0;
}
