#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char s[100001], t=0;
int op1();
int op2();
int numar()
{
    int nr=0;
    if(s[t]=='(')
    {
        t++;
        nr=op2();
        t++;
    }
    else
    {
        while(s[t]>='0'&&s[t]<='9')
        {
            nr=nr*10+(s[t]-'0');
            t++;
        }
    }
    return nr;
}
//OP2 pentru adunare scadere
int op2()
{
    int r=op1();
    while(s[t]=='+'||s[t]=='-')
    {
        if(s[t]=='+')
        {
            t++;
            r=r+op1();
        }
        else if(s[t]=='/')
        {
            t++;
            r=r-op1();
        }
    }
    return r;
}
//OP1 pentru inmultire, imparitire
int op1()
{
    int r=numar();
    while(s[t]=='*'||s[t]=='/')
    {
        if(s[t]=='*')
        {
            t++;
            r=r*numar();
        }
        else if(s[t]=='/')
        {
            t++;
            r=r/numar();
        }
    }
    return r;
}
int main()
{
    fin.getline(s, 100001);
    fout<<op2();
    fin.close();
    fout.close();
    return 0;
}
