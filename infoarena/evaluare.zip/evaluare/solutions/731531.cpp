#include <stdio.h>
#define MAX 100004
char e[MAX],*p;

int termen();
int factor();

int eval(){
    int r=termen();
    while(*p=='+'||*p=='-'){
    switch(*p){
        case '+':
            p++;
            r+=termen();
            break;
        case '-':
            p++;
            r-=termen();
            break; } }
    return r;
}

int termen(){
    int r=factor();
    while(*p=='*'||*p=='/'){
        switch(*p){
            case '*':
                p++;
                r*=factor();
                break;
            case '/':
                p++;
                r/=factor();
                break;
        }
    }
    return r;
}

int factor(){
    int r=0;
    if(*p=='('){
        p++;
        r=eval();
        p++; } else {
            while('0'<=*p&&*p<='9'){
                r=r*10+*p-'0';
                p++; }
        }
    return r;
}

int main(){
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);
        fgets(e,MAX-1,stdin);
        p=e;
    printf("%d\n",eval());
}
