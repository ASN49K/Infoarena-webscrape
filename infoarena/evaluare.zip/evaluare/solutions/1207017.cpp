#include<fstream>
using namespace std;
int i;
char ch[100003];
int expresie();
int termen();
int factor();
int expresie(){
    int r=termen();
    if(ch[i]=='+' || ch[i]=='-'){
        if(ch[i]=='+'){
            i++;
            r+=termen();
        }else{
        i++;
        r-=termen();
    }
    return r;
    }
}
int termen(){
    int r=factor();
    if(ch[i]=='*' || ch[i]=='/'){
        if(ch[i]=='*'){
            i++;
            r*=factor();
        }else{
            i++;
            r/=factor();
        }
    }
    return r;
}
int factor(){
    int r;
    if(ch[i]=='('){
            i++;
            r=expresie();
            i++;
    }else{
        r=0;
        while(ch[i]>='0' && ch[i]<='9'){
            r=r*10+(ch[i]-'0');
            i++;
        }
    }
    return r;
}
ifstream in("evaluare.in");
ofstream out("evaluare.out");
int main(){
    in>>ch;
    out<<expresie();
return 0;
}
