
#include <fstream>
#include <string>

using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char deeznuts[10005];

int solve(int &p);
int prod(int &p);
int fact(int &p);
int getnr(int &p);


int main()
{
    fin>>deeznuts;
    int poz=0;
    fout<<solve(poz);
}

int solve(int &p)
{
    int t1=prod(p),t2;
    while(deeznuts[p]=='+' || deeznuts[p]=='-'){
        int ver=0;
        if(deeznuts[p]=='+')
            ver=1;
        else
            ver=-1;

        ++p;

        t2=prod(p);
        if(ver==true)t1+=ver*t2;
        else t1-=ver*t2;
    }
    return t1;
}

int prod(int &p)
{
    int f1=fact(p),f2;
    while(deeznuts[p]=='*' || deeznuts[p]=='/'){
        int ver=0;
        if(deeznuts[p]=='*')
            ver=1;
        else
            ver=-1;
        ++p;
        f2=fact(p);
        if(ver==1)
            f1*=f2;
        else
            f1/=f2;
    }
    return f1;
}

int fact(int &p)
{
    int rez;
    if(deeznuts[p]=='('){
        ++p;
        rez=solve(p);
        ++p;
    }
    else {
        rez=getnr(p);
    }
    return rez;
}

int getnr(int &p)
{
    int sol=0;
    while(deeznuts[p]>='0' && deeznuts[p]<='9'){
        sol=sol*10+deeznuts[p]-'0';
        ++p;
    }

    return sol;
}
