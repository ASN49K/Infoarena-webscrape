#include <bits/stdc++.h>
using namespace std;

int nr();
int mic();
int mare();
int imens();

string t; 
int poz = 0;

int nr() {
	int temp = 0;
	while(t[poz]>='0' and t[poz]<='9')
		temp = temp * 10 + (t[poz++] - '0');
	return temp;
}

int mic() {
	int temp = 0;
	if(t[poz]=='(') poz++, temp = imens(), poz++;
	else temp = nr();
	return temp;
}

int mare() {
	int temp = mic();
	while(t[poz]=='*' or t[poz]=='/') 
		t[poz++]=='*' ? temp *= mic() : temp /= mic();
	return temp;
}

int imens() {
	int temp = mare();
	while(t[poz]=='+' or t[poz]=='-') 
		t[poz++]=='+' ? temp += mare() : temp -= mare();
	return temp;
}

int main() {
	ifstream f("evaluare.in");
	ofstream g("evaluare.out");
	f >> t;
	g << imens();
	return 0;
}
