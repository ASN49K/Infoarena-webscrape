#include<fstream.h>
#define g 100005
using namespace std;
int p;
char e[g];

int evaluare(),termen(),factor();
int main()
 {
  ifstream be ("evaluare.in");
  ofstream ki ("evaluare.out");
  be.getline (e,g,'\n');
  be.close();
  ki<<evaluare()<<'\n';
  ki.close();
  return 0;
 }

int evaluare ()
 {
  int r=termen();
  while (e[p]=='+' || e[p]=='-')
     if (e[p]=='+')
       { p++;
	 r+=termen(); }
       else
	 { p++;
	   r-=termen(); }
  return r;
 }
int termen ()
 {
  int r=factor();
  while (e[p]=='*' || e[p]=='/')
     if (e[p]=='*')
       {
	p++;
	r*=factor();
       }
     else
       {
	p++;
	r/=factor();
       }
  return r;
 }
int factor ()
 {
  int r=0;
  if (e[p]=='(')
    {
     p++;
     r=evaluare();
     p++;
    }
  else
    while (e[p]>='0' && e[p]<='9')
      {
       r=r*10+e[p]-48;
       p++;
      }
  return r;
 }