#include <cstdio>
#include <stack>
#include <cstring>
using namespace std;

char a[100005];
int test = 1000000000;
stack <int>nre;
stack <char>semne;


void calcul(char semn)
{
    int x = nre.top();
    nre.pop();
    int y = nre.top();
    nre.pop();

    int nrr=0;
    switch(semn){
        case '+':
            nrr = x+y;
            break;
        case '-':
            nrr = y-x;
            break;
        case '*':
            nrr = x*y;
            break;
        case '/':
            nrr = y/x;
            break;
    }
    nre.push(nrr);
    semne.pop();
}


void formnr(int &i)
{
    int nr=0;
    while(a[i] >= '0' && a[i] <= '9')
    {
        nr = nr*10 + a[i]-'0';
        i++;
    }
    i--;
    nre.push(nr);
}

void eliber()
{
    char semn = semne.top();
    while(!semne.empty() && semn != '(')
    {
        calcul(semn);
        if(!semne.empty())
            semn = semne.top();
    }
}

void eliber_ori()
{
    char semn = semne.top();
    while(!semne.empty() && semn != '(' && semn != '+' && semn != '-')
    {
        calcul(semn);
        if(!semne.empty())
            semn = semne.top();
    }
}



int main()
{
    freopen("evaluare.in", "r", stdin);
    freopen("evaluare.out", "w", stdout);
    scanf("%s", a);
    int op = strlen(a);
    for(int i=0; i<op; i++)
    {
        if(a[i] >= '0' && a[i] <= '9')
            formnr(i);
        if(a[i] == '(')
            semne.push(a[i]);
        if(a[i] == ')')
        {
            if(!semne.empty())
                eliber();
            semne.pop();
        }
        if(a[i] == '+' || a[i] == '-')
        {
            if(!semne.empty())
                eliber();
            semne.push(a[i]);
        }
        if(a[i] == '*' || a[i] == '/')
        {
            if(!semne.empty())
                eliber_ori();
            semne.push(a[i]);
        }
    }
    while(!semne.empty())
    {
        calcul(semne.top());
    }
    printf("%d", nre.top());
    return 0;
}
