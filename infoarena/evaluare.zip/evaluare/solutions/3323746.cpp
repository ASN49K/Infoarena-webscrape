#include <bits/stdc++.h>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char s[100001];
int i = 0;

int Find_addsub();
int Find_multdiv();
int Find_phr();
int Find_digit();

int Find_digit(){
    int r = 0;
    while(s[i]>='0' and s[i]<='9'){
        r = r*10+(s[i]-'0');
        i++;
    }
    return r;
}

int Find_multdiv(){
    int r = Find_phr();
    while(s[i]=='*' or s[i]=='/'){
        if(s[i]=='*'){
            i++;
            r *= Find_phr();
        }else{
            i++;
            r /= Find_phr();
        }
    }
    return r;
}

int Find_addsub(){
    int r = Find_multdiv();
    while(s[i]=='+' or s[i]=='-'){
        if(s[i]=='+') {
            i++;
            r += Find_multdiv();
        }else{
            if(s[i] == '-') {
                i++;
                r -= Find_multdiv();
            }
        }
    }
    return r;
}

int Find_phr(){
    int r;
    if(s[i]=='('){
        i++;
        r = Find_addsub();
        i++;
    }else r = Find_digit();
    return r;
}

int main()
{
    fin >> s;
    fout << Find_addsub();
    return 0;
}
