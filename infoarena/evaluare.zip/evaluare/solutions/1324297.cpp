#include<iostream>
#include<fstream>
using namespace std;
char s[100002];
int i;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
int expresie();
int termen();
int factor();
int expresie(){
    int r;
    r=termen();
    while(s[i]=='+'|| s[i]=='-'){
        if(s[i]=='+'){
            i++;
            r=r+termen();
        }
        else{
            i++;
            r=r-termen();
        }
    }
    return r;
}
int termen(){
    int r;
    r=factor();
    while(s[i]=='*'|| s[i]=='/'){
        if(s[i]=='*'){
            i++;
            r=r*factor();
        }
        else{
            i++;
            r=r/factor();
        }
    }
    return r;
}
int factor(){
    int r;
    if(s[i]=='('){
       i++;
       r=expresie();
       i++;
    }
    else{
        r=0;
        while(s[i]>='0'&& s[i]<='9'){
            r=r*10+s[i]-'0';
            i++;
        }
    }
    return r;
}
int main(){
    ifstream fin("evaluare.in");
    ofstream fout("evaluare.out");
    fin>>s;
    i=0;
    fout<<expresie();
    return 0;
}

