#include <cstdio>
#include <cstring>
 
using namespace std;
 
int poz;
char sir[100010];
 
int get_num()
{
    int s=0;
    for(;'0'<=sir[poz] && sir[poz]<='9';poz++) s=s*10+sir[poz]-'0';
    return s;
}
 
int solve()
{
    int s=0,p=1;
    while(sir[poz]!=')')
    {
        if(sir[poz]=='(')
        {
            poz++;
            p*=solve();
        }
        else if(sir[poz]=='*') poz++;
        else if(sir[poz]=='/')
        {
            poz++;
            if(sir[poz]=='(')
            {
                poz++;
                p/=solve();
            }
            else p/=get_num();
        }
        else if('0'<=sir[poz] && sir[poz]<='9') p*=get_num();
        else if(sir[poz]=='+')
        {
            s+=p;
            p=1;
            poz++;
        }
        else if(sir[poz]=='-')
        {
            s+=p;
            p=-1;
            poz++;
        }
    }
    s+=p;
    poz++;
    return s;
}
 
int main()
{
    freopen("evaluare.in", "r", stdin);
    freopen("evaluare.out", "w", stdout);
    scanf("%s",sir);
    int n=strlen(sir);
    sir[n]=')';
    printf("%d",solve());
    return 0;
}

