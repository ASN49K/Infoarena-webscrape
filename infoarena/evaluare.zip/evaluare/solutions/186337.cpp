#include <stdio.h>
#include <string>

using namespace std;

#define maxn 100010
#define maxl 2

int p;
char e[maxn];
string op[maxl+1] = {"+-", "*/", ""};

int eval(int lev);

int oper(int lev, char x)
{
	int i, l = op[lev].size();
	for (i=0; i<l; i++) 
		if (op[lev][i] == x) return 1;
	return 0;
}

int calc(int x, int y, char semn)
{
	if (semn == '+') return x+y;
	if (semn == '-') return x-y;
	if (semn == '*') return x*y;
	return x/y;
}

int el()
{
	int rez = 0;

	if (e[p] == '(') 
	{
		p++;
		rez = eval(0);
		p++;
	}
	else while (e[p]>='0' && e[p]<='9') rez = rez*10 + e[p++]-'0';

	return rez;
}

int eval(int lev)
{
	int rez;

	if (lev == maxl) rez = el();
	else rez = eval(lev+1);

	while (oper(lev, e[p]))
	{
		char aux = e[p++];
		rez = calc(rez, eval(lev+1), aux);
	}

	return rez;
}

int main()
{
	freopen("evaluare.in", "r", stdin);
	freopen("evaluare.out", "w", stdout);

	scanf("%s", e);

	printf("%d\n", eval(0));

	return 0;
}
