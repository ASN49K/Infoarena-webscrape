#include<fstream>
#include<string>

using namespace std;

ifstream in("evaluare.in");
ofstream out("evaluare.out");

char expr[100005];
int n;
int val_expr=0;//valoare finala a expresiei



void Citire()
{
	in.getline(expr,100002);
	n=strlen(expr);
	if(expr[n-1]=='\n') { expr[n-1]=NULL; n--; }
	
}
int calc(int &i);
int calculeaza(int &i);
int paranteza(int &i);
int semn(char x) // determina daca val se va aduna sau scadea din val_expr;
{
	if(x=='+') return 1;
	if(x=='-') return -1;
}

int calc(int &i)
{
	int x=0;
	
	while(i<n&&expr[i]>='0'&&expr[i]<='9')
	{
	 x=x*10+expr[i]-48;
	 i++;
	}
 return x;
}

int calculeaza(int &i)
{
	int val=1,x;
	char op;
	if(expr[i]=='(') { val=paranteza(i); i++; return val;}
	else val=calc(i);
	if(i<n&&expr[i]=='*'||expr[i]=='/')
		while(i<n&&expr[i]!='+'&&expr[i]!='-'&&expr[i]!=')')
			{
			   op=expr[i];
			   i++;
			   if(expr[i]=='(')
				   x=calculeaza(i);
			   if(expr[i]>='0'&&expr[i]<='9') x=calc(i);
			   if(op=='*') val=val*x;
			   if(op=='/') val=val/x;
			   
			}
		return val;
}

int paranteza(int &i)
{
	int val=0;
	int val_par=0;
	char op='+';
	i++;
	while(i<n&&expr[i]!=')')
	{
		if(expr[i]=='+'||expr[i]=='-'||expr[i]=='*'||expr[i]=='/')
			{ op=expr[i]; i++; }
		if(expr[i]>='0'&&expr[i]<='9')
			val=calculeaza(i);
		if(expr[i]=='(') val=calculeaza(i);
		if(op=='-'||op=='+') 
			val_par=val_par+semn(op)*val;
		op=expr[i];
		
	}
   return val_par;
}

void Rezolvare()
{
	int val=0;
	char op='+';
	int i;
	
	for(i=0;i<n;i++)
	{
		if(expr[i]=='+'||expr[i]=='-'||expr[i]=='*'||expr[i]=='/')
			{ op=expr[i]; i++; }
		if(expr[i]>='0'&&expr[i]<='9')
			val=calculeaza(i);
		if(expr[i]=='(') val=calculeaza(i);
		if(!(expr[i]==')'&&expr[i-1]==')'))
		{
			if(op=='-'||op=='+') 
			val_expr=val_expr+semn(op)*val;
			if(op=='*') val_expr=val_expr*val;
			if(op=='/') val_expr=val_expr/val;
			if(expr[i]=='+'||expr[i]=='-'||expr[i]=='*'||expr[i]=='/')
				op=expr[i];
		}
	}
	out<<val_expr;
}
int main()
{
	Citire();
	Rezolvare();
	return 0;
}