#include<stdio.h>
#include<string.h>
#define N 100005
int v[N], i, desc=0,op[N], stack[N],n, j=1, k=1;
char sir[N];
inline int rez(int a, int b, char c)
{
switch(c)
	{
		case '+': return a+b;
		case '-': return a-b;
		case '*': return a*b;
		case '/': return a/b;
	}
}

void rezolva()
	{int nr;
		for(i=0;i<=n;i++)
		{
			if(sir[i]=='(')
				{
					stack[k]=-5;
					++k;
			}
			else if(sir[i]==')')
					{
						for(--k;stack[k]!=-5;--k)
							{
								v[j]=stack[k];
								stack[k]=0;
								++j;}
						stack[k]=0;
			}
			else if(sir[i]=='+')
					{
						if(stack[k-1]==-1 || stack[k-1]==-2 || stack[k-1]==-3 || stack[k-1]==-4)
						{
							while(stack[--k]==-1 || stack[k]==-2 || stack[k]==-3 || stack[k]==-4 && k>=1)
							{
								v[j]=stack[k];
								stack[k++]=0;
								++j;
							}
							stack[k++]=-1;
						}
						else 
						{
							stack[k]=-1; 
							++k;
						}
					}
			else if(sir[i]=='-')
					{
						if(stack[k-1]==-1 || stack[k-1]==-2 || stack[k-1]==-3 || stack[k-1]==-4)
							{
								while(stack[--k]==-1 || stack[k]==-2 || stack[k]==-3 || stack[k]==-4 && k>=1)
							{
								v[j]=stack[k];
								stack[k++]=0;
								++j;
								}
								stack[k++]=-2;
						}
						else 
						{
							stack[k]=-2; 
							++k;
						}
			}
			else if(sir[i]=='*')
					{
						if(stack[k-1]==-3 || stack[k-1]==-4)
						{
							while(stack[--k]==-3 || stack[k]==-4 && k>=1)
							{
								v[j]=stack[k];
								stack[k++]=0;
								++j;
							}
							stack[k++]=-3;
						}
						else 
						{
							stack[k]=-3; 
							++k;
						}
					}
			else if(sir[i]=='/')
					{
						if(stack[k-1]==-3 || stack[k-1]==-4)
							{
								while(stack[--k]==-3 || stack[k]==-4 && k>=1)
							{
								v[j]=stack[k];
								stack[k++]=0;
								++j;
								}
								stack[k++]=-4;
						}
						else 
						{
							stack[k]=-4; 
							++k;
						}
			}
			else if(i==n)
					{
						for(;k>0;)
							{
								v[j++]=stack[--k];
								stack[k]=0;
						}
			}
			else 
					{
						for(nr=0;sir[i]>='0' && sir[i]<='9';++i)
							nr=nr*10+sir[i]-'0';
						--i;
						v[j]=nr;
						++j;
			}
		}
		
	}
	
int main()
	{
		freopen("evaluare.in","r",stdin);
		freopen("evaluare.out","w",stdout);
		scanf("%s",&sir);
		n=strlen(sir);
		rezolva();
		k=1;
		for(i=1;i<j;++i)
			if(v[i]==-1)
			{			
				stack[k-2]=rez(stack[k-2],stack[k-1],'+');
				stack[--k]=0;
			}
			else if(v[i]==-2)
			{
				stack[k-2]=rez(stack[k-2],stack[k-1],'-');
				stack[--k]=0;
			}
			else if(v[i]==-3)
			{
				stack[k-2]=rez(stack[k-2],stack[k-1],'*');
				stack[--k]=0;
			}
			else if(v[i]==-4)
			{
				stack[k-2]=rez(stack[k-2],stack[k-1],'/');
				stack[--k]=0;
			}
			else 
			{				
					stack[k]=v[i];
					++k;
			}	
		printf("%d\n",stack[1]);
		return 0;
	}
		