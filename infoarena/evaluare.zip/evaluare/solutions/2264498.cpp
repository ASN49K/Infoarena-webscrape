#include <fstream>
using namespace std;
ifstream in("evaluare.in");
ofstream out("evaluare.out");
const int nmax=100000;
char op[nmax/2+5];
int  polo[nmax+5];
int pr(char ch)
{
    switch (ch)
    {
    case '+':
        return 1;
    case '-':
        return 1;
    case '*':
        return 2;
    case '/':
        return 2;
    default :
        return 0;
    }
}
int main()
{
    char x;
    int top,top1,s,ok;
    top=top1=0;
    x=in.get();
    while(!in.eof() and x!=' ' and x!='\n')
    {
        ok=1;
        if(x>='0' and x<='9')
        {
            s=ok=0;
            while(x>='0' and x<='9')
            {
                s=s*10+(x-'0');
                x=in.get();
            }
            polo[++top1]=s;
        }
        else if(x=='(')
            op[++top]=x;
        else if(x==')')
        {
            while(op[top]!='(' and top)
            {
                if(op[top]=='+')
                    polo[top1-1]+=polo[top1];
                if(op[top]=='-')
                    polo[top1-1]-=polo[top1];
                if(op[top]=='*')
                    polo[top1-1]*=polo[top1];
                if(op[top]=='/')
                    polo[top1-1]/=polo[top1];
                top1--;
                top--;
            }
            top--;
        }
        else
        {
            if(top==0 || op[top]=='(' || pr(op[top])<pr(x))
                op[++top]=x;
            else
            {
                while(top>0 and pr(x)<=pr(op[top]))
                {
                    if(op[top]=='+')
                        polo[top1-1]+=polo[top1];
                    if(op[top]=='-')
                        polo[top1-1]-=polo[top1];
                    if(op[top]=='*')
                        polo[top1-1]*=polo[top1];
                    if(op[top]=='/')
                        polo[top1-1]/=polo[top1];
                    top1--;
                    top--;
                }
                op[++top]=x;
            }
        }
        if(ok)
            x=in.get();
    }
    while(top)
    {
        if(op[top]=='+')
            polo[top1-1]+=polo[top1];
        if(op[top]=='-')
            polo[top1-1]-=polo[top1];
        if(op[top]=='*')
            polo[top1-1]*=polo[top1];
        if(op[top]=='/')
            polo[top1-1]/=polo[top1];
        top1--;
        top--;
    }
    out<<polo[top1];

    return 0;

}
