#include<fstream.h>
#include<string.h>
#define max 100010
char x[max], o[max/2];
long v[max/2], n, k=-1, l=-1, i;
ifstream f("ev2.in");
ofstream g("evaluare.out");

void solve();
void calc();
long det();

int main()
{       f.getline(x, max);
	n=strlen(x);
	solve();
	return 0;
}

void solve()
{       for(i=0; i<n; i++)
	{       switch(x[i])
		{       case '*':
			case '/':
				while((o[l]=='*' || o[l]=='/') && l>=0)
				{	calc(); l--;
				}
				l++; o[l]=x[i]; break;
			case '+':
			case '-':
				while((o[l]=='+' || o[l]=='-') && l>=0)
				{       calc(); l--;
				}
				l++; o[l]=x[i]; break;
			case '(':
				l++; o[l]=x[i]; break;
			case ')':
				while(o[l]!='(')
				{       calc();
					l--;
				}
				l--;
				break;
			default :
				k++; v[k]=det();
				while(o[l]=='*' || o[l]=='/')
				{	calc(); l--;
				}
				break;
		}
	}
	while(l>=0)
	{       calc(); l--;
	}
	g<<v[0]<<'\n';
}

void calc()
{       switch(o[l])
	{	case '+':
		case '-':
			if(k==0 && o[l]=='-')
			{	v[k]=-v[k];
				break;
			}
			while(o[l]=='+' || o[l]=='-')
			{	switch(o[l])
				{       case '+':
						v[k-1]=v[k-1]+v[k]; k--; break;
					case '-':
						v[k-1]=v[k-1]-v[k]; k--; break;
				}
				l--;
			}
			l++; break;
		case '*':
			v[k-1]=v[k-1]*v[k]; k--; break;
		case '/':
			v[k-1]=v[k-1]/v[k]; k--; break;

	}
}

long det()
{	long m;
	m=0;
	while(i<n && x[i]<58 && x[i]>47)
	{       m=m*10+(x[i]-'0');
		i++;
	}
	i--;
	return m;
}