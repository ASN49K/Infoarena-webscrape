#include<stdio.h>
#include<ctype.h>
char E[100010],*c;
int ret;
void read(),solve();
int suma(),prod(),par(),num();
int main()
{
	read();
	solve();
	return 0;
}
void read()
{
	freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	c=E;
	scanf("%s",c);
}
void solve()
{
	printf("%d",suma());
}
int suma()
{
	int ret=prod();
	while(*c=='+'||*c=='-')
		if(*c=='+')
		{
			c++;
			ret+=prod();
		}
			else
			{
				c++;
				ret-=prod();
			}
		return ret;
}
int prod()
{
	int ret=par();
	while(*c=='*'||*c=='/')
	{
		if(*c=='*')
		{
			c++;
			ret*=par();
		}
		else
		{
			c++;
			ret/=par();
		}
	}
	return ret;
}
int par()
{
	int ret;
	if(*c=='(')
	{
		c++;
		ret=suma();
		c++;
	}
	else
	{
		ret=num();
	}
	return ret;
}
int num()
{
	int ret=0;
	while(isdigit(*c))
	{
		ret*=10;
		ret+=*c-'0';
		c++;
	}
	return ret;
}
