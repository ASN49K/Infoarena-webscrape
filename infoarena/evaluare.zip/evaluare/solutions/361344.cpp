#include <fstream>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
#define nmax 100001
char S[nmax],*p=S;
long eval();
long factor();
long termen();
long eval()
 {
 long r=termen();
 while(*p=='+'||*p=='-')
  {
  if(*p=='+')
   {
   p++;
   r+=termen();
   }
  else
   {
   p++;
   r-=termen();
   }
  }
 p++;
 return r;
 }
long termen()
 {
 long r=factor();
 if(*p=='*'||*p=='/')
  {
  if(*p=='*')
   {
   p++;
   r*=factor();
   }
  else if(*p=='/')
   {
   p++;
   r/=factor();
   }
  }
 return r;
 }
long factor()
 {
 long r=0;
 while(*p>='0'&&*p<='9')
  {
  r=r*10+(*p-'0');
  p++;
  }
 if(*p=='(')
  {
  p++;
  r+=eval();
  }
 return r;
 }
int main()
 {
 f.getline(S,nmax);
 g<<eval();
 return 0;
 }
