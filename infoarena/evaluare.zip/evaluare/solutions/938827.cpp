#include <fstream>

using namespace std;

char a[100010];
int poz;

inline int eval();
inline int termen();
inline int factor();

inline int eval()
{
    int rez = termen();
    while (a[poz] == '+' || a[poz] == '-')
        if (a[poz] == '+')
        {
            poz++;
            rez += termen();
        }
        else
        {
            poz++;
            rez -= termen();
        }
    return rez;
}

inline int termen ()
{
    int rez = factor();
    while (a[poz] == '*' || a[poz] == '/')
        if (a[poz] == '*')
        {
            poz++;
            rez *= factor();
        }
        else
        {
            poz++;
            rez /= factor();
        }
    return rez;
}

inline int factor()
{
    int rez;
    if (a[poz] == '(')
    {
        poz++;
        rez = eval();
        poz++;
    }
    else
    {
        rez = 0;
        while (a[poz] >= '0' && a[poz] <= '9' && a[poz])
        {
            rez = rez * 10 + (a[poz] - '0');
            poz++;
        }
    }
    return rez;
}

int main()
{
    ifstream f ("evaluare.in");
    f>>a;
    f.close();
    ofstream g ("evaluare.out");
    g<<eval();
    g.close();
    return 0;
}
