#include <bits/stdc++.h>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char s[100002], *p;

static inline int Eval();
static inline int Term();
static inline int Factor();

static inline int Eval() {
    int rez = Term();
    while(*p == '+' || *p == '-') {
        if(*p == '+') {
            p++;
            rez += Term();
        }
        else {
            p++;
            rez -= Term();
        }
    }
    return rez;
}

static inline int Term() {
    int rez = Factor();
    while(*p == '*' || *p == '/') {
        if(*p == '*') {
            p++;
            rez *= Term();
        }
        else {
            p++;
            rez /= Term();
        }
    }
    return rez;
}

static inline int Factor() {
    int rez = 0;
    if(*p == '(') {
        p++;
        rez = Eval();
        p++;
    }
    else {
        while('0' <= *p || *p <= '9') {
            rez = rez * 10 + (int)*p - '0';
            p++;
        }
    }
    return rez;
}

int main() {
    fin >> s;
    p = s;

    fout << Eval();

    return 0;
}
