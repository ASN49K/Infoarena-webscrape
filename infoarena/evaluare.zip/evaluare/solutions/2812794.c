#include <stdio.h>
#include <stdlib.h>
#define MAX_LINE 100001

int eval(char **p);
int termen(char **p);
int factor(char **p);

int main()
{
    FILE *f = fopen("evaluare.in", "r");
    FILE *g = fopen("evaluare.out", "w");
    char *s = malloc(MAX_LINE);
    char **p;
    fscanf(f, "%s", s);
    p = &s;
    fprintf(g, "%d", eval(p));
    return 0;
}

int eval(char **p)
{
    int r = termen(p);
    while (**p == '+' || **p == '-')
        if(**p == '+') {
            (*p)++;
            r = r + termen(p);
        }
        else {
            (*p)++;
            r = r - termen(p);
        }
    return r;
}

int termen(char **p)
{
    int r = factor(p);
    while(**p == '*' || **p == '/')
        if(**p == '*'){
            (*p)++;
            r = r * factor(p);
        }
        else{
            (*p)++;
            r = r / factor(p);
        }
    return r;
}

int factor(char **p)
{
    int r = 0;
    if(**p == '(')
    {
        (*p)++;
        r = eval(p);
        (*p)++;
    }
    else{
        while(**p <= '9' && **p >= '0'){
            r = r * 10 + (int)**p - '0';
            (*p)++;
        }
    }
    return r;
}
