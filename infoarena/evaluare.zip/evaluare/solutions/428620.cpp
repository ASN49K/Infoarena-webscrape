# include <stdio.h>
# define nmax 100005

char s[nmax],*p;

long termen();
long factor();

long eval()
{
	long r=termen();
	while (*p=='+' || *p=='-')
	{
		if (*p=='+')
		{
			++p;
			r+=termen();
			break;
		}
		else
		if (*p=='-')
		{
			++p;
			r-=termen();
			break;
		}
	}
	return r;
}

long termen()
{
	long r=factor();
	while (*p=='*' || *p=='/')
	{
		if (*p=='*')
		{
			++p;
			r*=factor();
			break;
		}
		else
		if (*p=='/')
		{
			++p;
			r/=factor();
			break;
		}
	}
	return r;
}

long factor()
{
	long r=0;
	if (*p=='(')
	{
		++p;
		r=eval();
		++p;
	}
	else
		while (*p>='0' && *p<='9')
		{
			r=r*10+*p-'0';
			++p;
		}
	return r;
}

int main()
{
	freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	fgets(s,nmax,stdin);
	p=s;
	printf("%ld", eval());
	return 0;
}
