#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <cstring>

using namespace std;
ifstream in("evaluare.in");
ofstream out("evaluare.out");

#define pb push_back
#define ll long long
const int strMax = 1e5 + 5;
const int lvlMax = 2;

int N;
char str[strMax],*p;
const char lvlOp[2][3] = {'+','-','\0','*','/','\0'};

// metoda fara recursivitate indirecta (link 4)
int eval(int);
int compute(int,int,char);
// eval(i) = evalueaza o expresie considerand ca este pe nivelul i
// compute(a,b,op) = face operatia: a op b

int main() {

    in>>(str);
    p = str;

    out<<eval(0)<<'\n';

    in.close();out.close();
    return 0;
}

int eval(int lvl) {
    int ans = 0;
    if (lvl == lvlMax) {
        if (*p == '(') {
            ++p;
            ans = eval(0);
            ++p;
        }
        else {
            while ('0' <= *p && *p <= '9') {
                ans = ans * 10 + (*p++ - '0');
            }
        }
    }
    else {
        for(ans = eval(lvl+1); strchr(lvlOp[lvl],*p) != nullptr && *strchr(lvlOp[lvl],*p) != '\0'; ) {
            char op = *p++;
            ans = compute(ans,eval(lvl+1),op);
        }
    }

    return ans;
}

int compute(int v1,int v2,char op) {
    switch (op) {
    case '+': return v1+v2;
    case '-': return v1-v2;
    case '*': return v1*v2;
    case '/': return v1/v2;
    }
}
