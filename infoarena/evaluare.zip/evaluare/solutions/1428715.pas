program siruri;
var     nr:array[1..1000001] of longint;
        bi:array[1..65535] of byte;
        used:array[1..1000001] of 0..1;
        f:text;
        n,p:longint;

procedure scrie(x:longint);
var g:text;
begin
 assign(g,'siruri.out'); rewrite(g);
 writeln(g,x);
 close(g);
end;

procedure sol1;
var     i,j,s,k:longint;
        v:array[1..1000001] of byte;
        max,val,min:longint;
        ch:char;
begin
        for i:=1 to n do
        begin
                read(f,ch);
                v[i]:=ord(ch);
        end;
        nr[n]:=1;
        max:=v[n];
        for i:=n-1 downto 1 do
                if v[i]>max then
                begin
                        max:=v[i];
                        nr[i]:=1;
                        end
                else
                begin
                        val:=maxlongint;
                        for j:=i+1 to n do
                        if (v[i]<=v[j]) and (v[j]<=val) then
                                begin
                                        val:=v[j];
                                        nr[i]:=(nr[i]+nr[j]) mod 41357;
                                end;
                end;
        s:=nr[1];
        min:=maxlongint;
        for i:=2 to n do
                if min>v[i] then
                begin
                        min:=v[i];
                        s:=(s+nr[i])mod 41357;
                end;
        scrie(s);

end;

procedure sol2;
var     i,j,st,nrp:longint;
        v:array[1..1000001] of char;
begin
        for i:=1 to n do
                read(f,v[i]);
        nrp:=0;
        for i:=1 to n do
                if used[i]=0 then
                begin
                        used[i]:=1;
                        st:=i;
                        for j:=i+1 to n do
                                if (v[st]<=v[j])and(used[j]=0) then
                                begin
                                        st:=j;
                                        used[j]:=1;
                                end;
                                nrp:=nrp+1;
                        end;
        scrie(nrp);
end;

begin
        assign(f,'siruri.in'); reset(f);
        settextbuf(f,bi);
        readln(f,p,n);
        if p=1 then
                sol1
        else
                sol2;
end.
