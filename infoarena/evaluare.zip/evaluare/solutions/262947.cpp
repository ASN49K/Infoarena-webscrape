#include <stdio.h>
#define NMAX 100010

char s[NMAX],*p;

int eval();
int factor();
int termen();

int eval()
{
 int r=termen();

 while (*p=='+' || *p=='-')
	{
	 if (*p=='+')
		{
		 p++;
		 r+=termen();
		}
	  else
	 if (*p=='-')
		{
		 p++;
		 r-=termen();
		}
	}
 return r;

}

int termen()
{
 int r=factor();

 while (*p=='*' || *p=='/')
	{
	 if (*p=='*')
		{
		 p++;
		 r*=factor();
		}
	  else
	 if (*p=='/')
		{
		 p++;
		 r/=factor();
		}
	}


 return r;

}

int factor()
{
 int r=0;

 if (*p=='(')
	{
	 p++;
	 r=eval();
	 p++;
	}
  else
    while (*p>='0' && *p<='9')
	 {
	  r=r*10+*p-48;
	  p++;
	 }

 return r;
}

int main()
{
  freopen("evaluare.in","r",stdin);
  freopen("evaluare.out","w",stdout);

  fgets(s,NMAX,stdin);
  p=s;
  printf("%d\n", eval());

  return 0;
}