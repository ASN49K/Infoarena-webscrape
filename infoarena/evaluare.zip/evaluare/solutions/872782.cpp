#include<fstream>
#include<string.h>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
int gr(char t)
{
	if(t=='*'||t=='/')
	return 1;
	else
	if(t=='+'||t=='-')
	return 0;
	return -1;
}
int stack[100100],n,i,k,ts,t;
char s[100100],exp[100100],sts[100100];
int main ()
{
	f>>s;
	n=strlen(s);
	for(i=0;i<n;++i)
	{
		if(s[i]=='(')
			sts[++ts]='(';
			else
			if(s[i]>='0'&&s[i]<='9')
			{
				while(s[i]>='0'&&s[i]<='9')
				{
					exp[++t]=s[i];
					i++;
				}
				++t;
				i--;
			}
			else
			if(s[i]==')')
			{
				for(k=ts;sts[k]!='(';--k)
				exp[++t]=sts[k];
				ts=k-1;
			}
			else
			{
				if(gr(s[i])<=gr(sts[ts]))
				{
					for(k=ts;sts[k]!='('&&k>=1;--k)
					exp[++t]=sts[k];
					if(sts[k]=='(')
					ts=k-1;
					else
					ts=k;
					sts[++ts]=s[i];
				}
				else
				sts[++ts]=s[i];
			}
	}
	for(k=ts;k>=1;--k)
	exp[++t]=sts[k];
	ts=0;
	for(i=1;i<=t;++i)
	{
		if(exp[i]>='0'&&exp[i]<='9')
		{
			++ts;
			stack[ts]=0;
			while(exp[i]>='0'&&exp[i]<='9')
			{
				stack[ts]=stack[ts]*10+exp[i]-48;
				++i;
			}
		}
		else
		{
			switch(exp[i])
			{
				case '+': stack[ts-1]=stack[ts-1]+stack[ts];break;
				case '-': stack[ts-1]=stack[ts-1]-stack[ts];break;
				case '*': stack[ts-1]=stack[ts-1]*stack[ts];break;
				case '/': stack[ts-1]=stack[ts]/stack[ts-1];break;
			}
			--ts;
		}
	}
	g<<stack[1];
	return 0;
}
			
					
				
				
				
