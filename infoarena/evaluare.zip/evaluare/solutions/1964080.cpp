#include <cstdio>
#include <algorithm>
#include <vector>
#include <cstring>

#define in "evaluare.in"
#define out "evaluare.out"
#define NMAX (100000 + 7)

using namespace std;
char s[NMAX];
int poz = 1;

int evaluare();
int termen();
int factor();

int main()
{
    freopen(in, "r", stdin);
    freopen(out, "w", stdout);
    scanf("%s\n", s+1);
    printf("%d", evaluare());
    return 0;
}

int evaluare()
{
    int r = termen();
    while(s[poz] == '+' || s[poz] == '-')
    {
        if(s[poz] == '+') {poz++;r += termen();}
        else {poz++;r -= termen();}
    }
    return r;
}
int termen()
{
    int r = factor();
    while(s[poz] == '*' || s[poz] == '/')
    {
        if(s[poz] == '*') {poz++;r *= factor();}
        else {poz++;r /= factor();}
    }
    return r;
}
int factor()
{
    if(s[poz] == '(')
    {
        ++poz;
        int ans = evaluare();
        ++poz;
        return ans;
    }
    int r = 0;
    while(s[poz] <= '9' && s[poz] >= '0')
    {
        r = r*10 + s[poz] - '0';
        ++poz;
    }
    return r;
}
