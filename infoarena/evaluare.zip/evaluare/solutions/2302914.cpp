#include <cstdio>
#include <stack>
#include <cstring>
using namespace std;


char s[100001];
stack<int>nre;
stack<char>semne;

void eliber(int i)
{
    while(!semne.empty() && semne.top() != '(')
    {
        if(semne.top() == '+')
        {
            int x=nre.top();
            nre.pop();
            int y = nre.top();
            nre.pop();
            nre.push(x+y);
            semne.pop();
        }
        else if(semne.top() == '-')
        {
            int x=nre.top();
            nre.pop();
            int y = nre.top();
            nre.pop();
            nre.push(y-x);
            semne.pop();
        }
        else if(semne.top() == '*')
        {
            int x=nre.top();
            nre.pop();
            int y = nre.top();
            nre.pop();
            nre.push(x*y);
            semne.pop();
        }
        else if(semne.top() == '/')
        {
            int x=nre.top();
            nre.pop();
            int y = nre.top();
            nre.pop();
            nre.push(y/x);
            semne.pop();
        }
    }
}

void eliber_ori(int i)
{
    while(!semne.empty() && semne.top() != '(')
    {
        if(semne.top() == '*')
        {
            int x=nre.top();
            nre.pop();
            int y = nre.top();
            nre.pop();
            nre.push(x*y);
            semne.pop();
        }
        else if(semne.top() == '/')
        {
            int x=nre.top();
            nre.pop();
            int y = nre.top();
            nre.pop();
            nre.push(y/x);
            semne.pop();
        }
        else break;
    }
}

void formnr(int &i)
{
    int nrrr=0;
    while(s[i] >= '0' && s[i] <= '9')
    {
        nrrr=nrrr*10+(s[i]-'0');
        i++;
    }
    nre.push(nrrr);
}



int main()
{
    freopen("evaluare.in", "r", stdin);
    freopen("evaluare.out", "w", stdout);
    scanf("%s", s);
    int n=0;
    for(int i=0; i<strlen(s); i++)
    {
        if(s[i] >= '0' && s[i] <= '9')
            formnr(i);
        if(s[i] == '(')
            semne.push(s[i]);
        if(s[i] == '+' || s[i] == '-')
        {
            if(!semne.empty())
                eliber(i);
            semne.push(s[i]);
        }
        if(s[i] == '*' || s[i] == '/')
        {
            eliber_ori(i);
            semne.push(s[i]);
        }
        if(s[i] == ')')
        {
            eliber(i);
            semne.pop();
        }

    }
    while(!semne.empty())
    {
        int nr=0;
        if(semne.top() == '-')
        {
            int x = nre.top();
            nre.pop();
            int y = nre.top();
            nre.pop();
            nre.push(y-x);
        }
        if(semne.top() == '*')
        {
            int x = nre.top();
            nre.pop();
            int y = nre.top();
            nre.pop();
            nre.push(y*x);
        }
        if(semne.top() == '/')
        {
            int x = nre.top();
            nre.pop();
            int y = nre.top();
            nre.pop();
            nre.push(y/x);
        }
        if(semne.top() == '+')
        {
            int x = nre.top();
            nre.pop();
            int y = nre.top();
            nre.pop();
            nre.push(y+x);
        }
        semne.pop();
    }
    printf("%d", nre.top());
    return 0;
}
