#include <fstream>
#include <cstring>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
int i,n;
char s[100100];

int termen();
int expresie();
int factor();


int termen()
{
    int t=factor();
    while(i<n&&s[i]=='+'||s[i]=='-')
    {
        i++;
        if(s[i-1]=='+')t=t+factor();
        else t=t-factor();
    }
    return t;
}
int factor()
{
    int t=expresie();
    while(i<n&&s[i]=='*'||s[i]=='/')
    {
        i++;
        if(s[i-1]=='*')t=t*expresie();
        else t=t/expresie();
    }
    return t;
}
int expresie()
{
    int t;
    if(s[i]=='(')
    {
        i++;
        t=termen();
        i++;
    }
    else {int nr=0;
          while(isdigit(s[i]))
                {
                    nr=nr*10+(s[i]-'0');
                    i++;
                }
        t=nr;}
        return t;
}
int main()
{
    f.getline(s,100005);
    n=strlen(s);
    i=0;
    g<<termen();
    return 0;
}
