#include <fstream>
using namespace std;
ifstream f("evaluare.in"); ofstream g("evaluare.out");
char s[100001],st1[100001];
int vf1,vf2,st2[100001],pr[300];
void operatie()
{   switch(st1[vf1])
    {   case '+' : st2[vf2-1]+=st2[vf2]; break;
        case '-' : st2[vf2-1]-=st2[vf2]; break;
        case '*' : st2[vf2-1]*=st2[vf2]; break;
        case '/' : st2[vf2-1]/=st2[vf2]; break;
    }
    vf2--; vf1--;
}
int main()
{   f>>s;
    pr['(']=pr[')']=0;
    pr['+']=pr['-']=1;
    pr['*']=pr['/']=2;
    for(int i=0;s[i];i++)
    {   if('0'<=s[i] && s[i]<='9')
        {   int nr=0;
            while('0'<=s[i] && s[i]<='9') {nr=nr*10+s[i]-'0'; i++;}
            i--;
            st2[++vf2]=nr;
        }
        else
            if(s[i]=='(') st1[++vf1]='(';
            else
                if(s[i]==')')
                {   while(st1[vf1]!='(') operatie();
                    vf1--;
                }
                else
                {   while(vf1 && pr[st1[vf1]]>=pr[s[i]]) operatie();
                    st1[++vf1]=s[i];
                }
    }
    while(vf1) operatie();
    g<<st2[1]; g.close(); f.close(); return 0;
}
