program evaluare_expresie;
type expres=array[1..100000] of char;
     termeni=array[1..100000] of longint;
var a,o:expres;
    t:termeni;
    i,n,p,pd,pi,j:word;
    semn:shortint;
    f:text;
procedure citire;
begin
assign(f,'evaluare.in'); reset(f);
i:=1;
a[i]:='(';
while not seekeof(f) do begin
                     i:=i+1;
                     read(f,a[i])
                     end;
a[i+1]:=')';
n:=i+1;
close(f);
end;

procedure scrie(s:longint);
begin
assign(f,'evaluare.out'); rewrite(f);
write(f,s);
close(f);
end;
{
procedure intermediate;
var i:word;
begin
writeln(g,'n=',n);
for i:=1 to n do write(g,t[i]:1:0,' ');
writeln(g);
for i:=1 to n do write(g,o[i],' ');
writeln(g);
end;
}
function pard:word;
var i:word;
begin
for i:=n downto 1 do
        if o[i]='(' then break;
pard:=i;
end;

function pari:word;
var i:word;
begin
for i:=pd to n do
        if o[i]=')' then break;
pari:=i;
end;

procedure permutare;
var k:word;
begin
for k:=i to n-2 do begin
                   o[k]:=o[k+2];
                   t[k]:=t[k+2]
                   end;
pi:=pi-2;
n:=n-2;
end;

procedure eliminparanteza;
var i,k:word;
begin
k:=pard;
t[k]:=t[k+1];
for i:=k+1 to n-2 do t[i]:=t[i+2];
o[k]:=#0;
for i:=k+1 to n-2 do o[i]:=o[i+2];
p:=p-1;
n:=n-1;
end;

procedure inmultire;
begin
while i<pi do begin
              if o[i]='*' then begin
                               t[i-1]:=t[i-1]*t[i+1];
                               permutare;
                               end
                          else i:=i+1;

             end;
end;

procedure impartire;
begin
while i<pi do begin
              if o[i]='/' then begin
                               t[i-1]:=t[i-1] div t[i+1];
                               permutare;
                               end
                          else i:=i+1;
             end;
end;

procedure adunare;
begin
while i<pi do begin
              if o[i]='+' then begin
                               t[i-1]:=t[i-1]+t[i+1];
                               permutare;
                               end
                          else i:=i+1;

             end;
end;

procedure scadere;
begin
while i<pi do begin
              if o[i]='-' then begin
                               t[i-1]:=t[i-1]-t[i+1];
                               permutare;
                               end
                          else i:=i+1;

             end;
end;

begin
citire;
for i:=1 to n do
        if a[i]='(' then p:=p+1;
i:=1;
j:=1;
semn:=1;
while i<=n do begin
              if (a[i]='-')and(a[i+1]='(') then begin o[j]:='-';
                                                      i:=i+1;
                                                      j:=j+1;
                                                end
                                           else
              if (a[i]='-')and(a[i-1]='(') then begin i:=i+1;
                                                      semn:=-1;
                                                end
                                           else
              if (a[i]>='(')and(a[i]<='/') then begin
                                                      o[j]:=a[i];
                                                      i:=i+1;
                                                      j:=j+1;
                                                end
                                                else begin
                                                     t[j]:=0;
                                                     while (a[i]<='9')and(a[i]>='0') do begin
                                                                                        t[j]:=t[j]*10+ord(a[i])-48;
                                                                                        i:=i+1;
                                                                                        end;
                                                     t[j]:=t[j]*semn;
                                                     j:=j+1;
                                                     semn:=1;
                                                     end;
              end;
while p>0 do begin
             pd:=pard;
             pi:=pari;
             i:=pd+1;
             inmultire;
             pd:=pard;
             pi:=pari;
             i:=pd+1;
             impartire;
             pd:=pard;
             pi:=pari;
             i:=pd+1;
             scadere;
             pd:=pard;
             pi:=pari;
             i:=pd+1;
             adunare;
             eliminparanteza;
             end;
scrie(t[1]);
end.
