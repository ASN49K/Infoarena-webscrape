#include<stdio.h>
#include<string.h>
#include<stdlib.h>
inline short op(char c)
     {if(c=='(') return 0;
      if(c=='+'||c=='-') return 1;
      if(c=='/'||c=='*') return 2;
      if(c=='^') return 4;
      return -1;
     }
char expresie[100001],forma[100001],st[100001];
int n,lg=-1,vf,i;
short p;
long v[100001],a,b;
int main()
  {
   freopen("evaluare.in","rt",stdin);
   freopen("evaluare.out","wt",stdout);
   gets(expresie);
   n=strlen(expresie);
   while(i<n)
	if(expresie[i]>='0'&&expresie[i]<='9')
	  {while(expresie[i]>='0'&&expresie[i]<='9') forma[++lg]=expresie[i++];
           forma[++lg]='.';
	   }else if(expresie[i]=='(') st[++vf]=expresie[i++];
		  else if(expresie[i]==')')
			 {while(st[vf]!='('&&vf) forma[++lg]=st[vf--];
			  --vf; ++i;
			  }else {p=op(expresie[i]);
				 while(p<=op(st[vf])&&vf>0)
				      forma[++lg]=st[vf--];
				 st[++vf]=expresie[i++];
				 }
   while(vf>0) forma[++lg]=st[vf--];
   puts(forma);
   for(vf=0,i=0;i<=lg;++i)
      if(forma[i]>='0'&&forma[i]<='9')
	     {
	      v[++vf]=atol(forma+i);
	      while(forma[i]>='0'&&forma[i]<='9') ++i;
	      }else {b=v[vf--]; a=v[vf--];
		          switch(forma[i])
		                {
		                 case '+': v[++vf]=a+b;break;
		                 case '-': v[++vf]=a-b;break;
		                 case '*': v[++vf]=a*b;break;
		                 case '/': v[++vf]=a/b;break;
		               }

		         }
   printf("%ld",v[1]);
   return 0;
  }
