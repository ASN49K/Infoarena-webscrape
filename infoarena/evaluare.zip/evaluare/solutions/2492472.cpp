#include <iostream>
#include <stack>

using namespace std;

int i, s;
char e[100];
stack<char>semn;
stack<int>num;

int main()
{
    cin.getline(e, 100);
    while(e[i]!='\0')
    {
        int nr=0;
        if(e[i]=='+'||e[i]=='-'||e[i]=='*'||e[i]=='/')
        {
            char c;
            if(!semn.empty())
                c=semn.top();
            else
                c=0;
            if(c=='+' && e[i]=='+')
            {
                nr=num.top();
                num.pop();
                nr+=num.top();
                num.pop();
                num.push(nr);
            }
            else if(c=='+' && e[i]=='-')
            {
                nr=num.top();
                num.pop();
                nr+=num.top();
                num.pop();
                semn.pop();
                semn.push(e[i]);
                num.push(nr);
            }
            else if(c=='-' && (e[i]=='-' || e[i]=='+'))
            {
                nr=num.top();
                num.pop();
                nr-=num.top();
                num.pop();
                nr*=-1;
                semn.pop();
                semn.push(e[i]);
                num.push(nr);
            }
            else if(c=='*' && e[i]=='*')
            {
                nr=num.top();
                num.pop();
                nr*=num.top();
                num.pop();
                num.push(nr);
            }
            else if(c=='*' && (e[i]=='/' || e[i]=='+' || e[i]=='-'))
            {
                nr=num.top();
                num.pop();
                nr*=num.top();
                num.pop();
                semn.pop();
                semn.push(e[i]);
                num.push(nr);
            }
            else if(c=='/' && (e[i]=='*' || e[i]=='+' || e[i]=='-'))
            {
                int _1=num.top();
                num.pop();
                nr=num.top()/_1;
                num.pop();
                semn.pop();
                semn.push(e[i]);
                num.push(nr);
            }
            else if(c=='/' && e[i]=='/')
            {
                nr=num.top();
                num.pop();
                nr/=num.top();
                num.pop();
                num.push(nr);
            }
            else
            {
                semn.push(e[i]);
            }
        }
        else if(e[i]==')')
        {
            char c=semn.top();
            while(c!='(')
            {
                if(c=='/')
                {
                    int _1=num.top();
                    num.pop();
                    nr=num.top()/_1;
                    num.pop();
                    num.push(nr);
                }
                else if(c=='-')
                {
                    nr=num.top();
                    num.pop();
                    nr-=num.top();
                    num.pop();
                    nr*=-1;
                    num.push(nr);
                }
                else if(c=='+')
                {
                    nr=num.top();
                    num.pop();
                    nr+=num.top();
                    num.pop();
                    num.push(nr);
                }
                else if(c=='*')
                {
                    nr=num.top();
                    num.pop();
                    nr*=num.top();
                    num.pop();
                    num.push(nr);
                }
                semn.pop();
                c=semn.top();
            }
        }
        else if(e[i]=='(')
        {
            semn.push(e[i]);
        }
        else
        {
            int somn=0;
            while(e[i]>='0' && e[i]<='9')
            {
                somn=somn*10+(int)e[i]-48;
                i++;
            }
            i--;
            num.push(somn);
        }
        i++;
    }
    int nr;
    while(!semn.empty())
    {
        char c=semn.top();
        if(c=='/')
        {
            int _1=num.top();
            num.pop();
            nr=num.top()/_1;
            num.pop();
            num.push(nr);
        }
        else if(c=='-')
        {
            nr=num.top();
            num.pop();
            nr-=num.top();
            num.pop();
            nr*=-1;
            num.push(nr);
        }
        else if(c=='+')
        {
            nr=num.top();
            num.pop();
            nr+=num.top();
            num.pop();
            num.push(nr);
        }
        else if(c=='*')
        {
            nr=num.top();
            num.pop();
            nr*=num.top();
            num.pop();
            num.push(nr);
        }
        semn.pop();
    }
    s=num.top();
    cout << s;
    return 0;
}
