#include <stdio.h>
#include <ctype.h>
#define N 100000

char s[N+1];
int p;
int expresie();
int termen();
int factor();

int expresie(){
  int sum=termen();
  while(s[p] == '+' || s[p] == '-'){
    if(s[p] == '+'){
      p++;
      sum+=termen();
    }
    else{
      p++;
      sum-=termen();
    }
  }
  return sum;
}
int termen(){
  int prod=factor();
  while(s[p] == '*' || s[p] == '/'){
    if(s[p] == '*'){
      p++;
      prod*=factor();
    }
    else{
      p++;
      prod/=factor();
    }
  }
  return prod;
}
int factor(){
  int semn=1,val=0;
  while(s[p]=='-'){
    p++;
    semn=-semn;
  }
  if(s[p] == '('){
    p++;
    val=expresie();
    p++;
    return semn*val;
  }
  while(isdigit(s[p]))
    val=val*10+(s[p++]-'0');
  return semn*val;
}

int main()
{
    FILE *fin,*fout;
    int i=0;
    fin=fopen("evaluare.in","r");
    fout=fopen("evaluare.out","w");
    while( (s[i++]=fgetc(fin)) != '\n' ){}
    fprintf(fout,"%d",expresie());
    fclose(fin);
    fclose(fout);
    return 0;
}
