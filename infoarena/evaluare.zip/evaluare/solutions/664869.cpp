#include<stdio.h>
#include<string.h>
#define maxn 100010

char s[maxn],*p=s;
int r;

int termen();
int factor();
int eval();
int eval()
{
	int r=termen();
	while(*p=='+'||*p=='-')
	{
		switch(*p)
		{
		case '+':++p;
			     r+=termen();
		         
				 break;
	    case '-': ++p;
			r-=termen();
		        
				 break;
		}
	}
return r;
}

int termen()
{
	int r=factor();
	while(*p=='*'||*p=='/')
	{
		switch(*p)
		{
		case '*':++p;
			r*=factor();
		          
				  break;
	    case '/': ++p;
			     r/=factor();
		         
				  break;
		}
	}
return r;
}

int factor()
{
	int r=0;
	if(*p=='(')
	{
		++p;
		r=eval();
		++p;
	}
	else 
	{
		while(*p>='0' && *p<='9')
		{
		  r=r*10+*p-'0';
		  ++p;
		}
	}
return r;
}

int main()
{
	freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	fgets(s,maxn,stdin);
	printf("%d",eval());
}