#include <fstream>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char s[100005];
int i;
int eval();
int termen(){
    int rez=0;
    if(s[i]=='('){
        i++;
        rez=eval();
        i++;
    }
    else
        while(s[i]>='0' && s[i]<='9'){
            rez=rez*10+s[i]-'0';
            i++;
        }
    return rez;
}
int factor(){
    int rez=termen();
    while(s[i]=='*' || s[i]=='/'){
        if(s[i]=='*'){
            i++;
            rez*=termen();
        }
        else{
            i++;
            rez/=termen();
        }
    }
    return rez;
}
int eval(){
    int rez=factor();
    while(s[i]=='+' || s[i]=='-'){
        if(s[i]=='+'){
            i++;
            rez+=factor();
        }
        else{
            i++;
            rez-=factor();
        }
    }
    return rez;
}
int main(){
    fin>>s;
    fout<<eval()<<"\n";
    fin.close();fout.close();
    return 0;
}
