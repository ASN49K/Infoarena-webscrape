#include<fstream> 
using namespace std; 
ifstream in("evaluare.in"); 
ofstream out("evaluare.out"); 

char s[100000]; 
int i; 

int eval(); 
int term(); 
int fact(); 

int eval() 
{
	int aux=term();
	while(s[i]=='+' || s[i]=='-') 
		if(s[i]=='+') 
		{
			i++;
			aux+=term(); 
		}
		else 
		{
			i++; 
			aux-=term(); 
		}
		
		return aux; 
}
		
int term() 
{
	int aux=fact(); 
	
	while(s[i]=='*' || s[i]=='/') 
		if(s[i]=='*') 
		{
			i++;
			aux*=fact(); 
		}
		else 
		{
			i++; 
			aux/=fact();
		}
return aux; 
}
			
	
int fact() 
{
	int aux=0; 
	
	if(s[i]=='(') 
	{
		i++; 
		aux=eval(); 
		i++; 
		return aux;
	}
	while(s[i]>='0' && s[i]<='9') 
	{
		aux=aux*10+s[i]-'0'; 
		i++; 
	}
	return aux; 
}
	
int main() 
{
	in>>s; 
	out<<eval(); 
	return 0; 
}
	