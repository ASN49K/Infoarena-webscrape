#include<stdio.h>
#include<string.h>

FILE *in,*out;

//functii
int calcul(int left,int right);

//constante
const int oo=(1<<30)-1;
const int Nmax=(int)1e5+1;

//variabile
char expresion[Nmax];

int main(void)
{
	in=fopen("evaluare.in","rt");
	fscanf(in,"%s",expresion);
	fclose(in);
	out=fopen("evaluare.out","wt");
	fprintf(out,"%d",calcul(0,strlen(expresion)-1));
	fclose(out);
	return 0;
}	

int calcul(int left,int right)
{
	int paranteze=0;
	int grad;
	int gradmin=oo;
	int pos;
	for(int i=left; i<=right; ++i)
	{
		if(expresion[i]== '(')
			paranteze++;
		else
			if(expresion[i]== ')')
				paranteze--;
			else
				if(expresion[i]== '+' || expresion[i]=='-')
				{
					grad=paranteze*2;
					if(grad<gradmin)
					{
						gradmin=grad;
						pos=i;
					}	
				}	
				else
					if(expresion[i]=='*' || expresion[i]=='/')
					{
						grad=paranteze*2+1;
						if(grad<gradmin)
						{
							gradmin=grad;
							pos=i;
						}	
					}	
	}	
	if(gradmin!=oo)
	{
		left=calcul(left,pos-1);
		right=calcul(pos+1,right);
		
		if(expresion[pos]=='+')
			return left+right;
		else
			if(expresion[pos]=='-')
				return left-right;
			else
				if(expresion[pos]=='*')
					return left*right;
				else
					return left/right;
	}
	int num=0;
	for(int i=left; i<=right; ++i)
		if(expresion[i]!= '(' && expresion[i]!=')')
			num=num*10+(expresion[i]-48);
	return num;
	
}	


