import java.io.*;
import java.util.Scanner;

public class Main {

    public static int findSings(String expr, char c1, char c2) {
        int level = 0;

        for (int i = 0; i < expr.length(); i++) {
            if (expr.charAt(i) == '(') {
                level++;
            } else if (expr.charAt(i) == ')') {
                level--;
            } else if (level == 0 && (expr.charAt(i) == c1 || expr.charAt(i) == c2)) {
                return i;
            }
        }
        return -1;
    }

    public static int evaluate(String expr) {
        System.out.println(expr);

        if (expr.length() == 0) {
            return 0;
        }


        int plusSignFound = findSings(expr, '+', '-');
        if (plusSignFound != -1) {
            switch (expr.charAt(plusSignFound)) {
                case '+':
                    return evaluate(expr.substring(0, plusSignFound)) + evaluate(expr.substring(plusSignFound+1));
                case '-':
                    return evaluate(expr.substring(0, plusSignFound)) - evaluate(expr.substring(plusSignFound+1));
            }
        }

        int multSignFound = findSings(expr, '*', '/');
        if (multSignFound != -1) {
            switch (expr.charAt(multSignFound)) {
                case '*':
                    return evaluate(expr.substring(0, multSignFound)) * evaluate(expr.substring(multSignFound+1));
                case '/':
                    return evaluate(expr.substring(0, multSignFound)) / evaluate(expr.substring(multSignFound+1));
            }
        }
        if (expr.charAt(0) == '(' && expr.charAt(expr.length()-1) == ')') {
            return evaluate(expr.substring(1, expr.length()-1));
        }
        return Integer.parseInt(expr);

    }

    public static void main(String[] args) throws FileNotFoundException {
        Scanner scanner = new Scanner(new BufferedInputStream(new FileInputStream("evaluare.in")));

        String s = scanner.nextLine();

        PrintStream output = new PrintStream(new FileOutputStream("evaluare.out"));
        output.println(evaluate(s));
    }
}
