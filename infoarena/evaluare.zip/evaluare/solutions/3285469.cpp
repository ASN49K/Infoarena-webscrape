#include <fstream>
#include <iostream>

using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
string s;
int i = 0;
int eval();
int eval1();
int eval2();
int eval3();
int eval()
{
    int r = eval1();
    while (s[i] == '+' || s[i] == '-')
    {
        if (s[i] == '+')
        {
            i++;
            r += eval1();
        }
        else
        {
            i++;
            r -= eval1();
        }
    }
    return r;
}
int eval1()
{
    int r = eval2();
    while (s[i] == '*' || s[i] == '/')
    {
        if (s[i] == '*')
        {
            i++;
            r *= eval2();
        }
        else
        {
            i++;
            r /= eval2();
        }
    }
    return r;
}
int eval2()
{
    int r;
    if (s[i] == '(')
    {
        i++;
        r = eval();
        i++;
    }
    else
    {
        r = eval3();
    }
    return r;
}
int eval3()
{

    int r = 0;
    while (isdigit(s[i]))
    {
        r = r * 10 + s[i] - '0';
        i++;
    }
    return r;
}
int main()
{

    fin >> s;
    fout << eval();
    return 0;
}