#include<algorithm>
using namespace std;

#define DIM 100001

long long rez;
char s[DIM],*p=s;

long long termen();
long long factor();

long long eval(){
	int rez=termen();

    while(*p=='+'||*p=='-')
        switch(*p){
            case '+':
                ++p;
                rez+=termen();
                break;
            case '-':
                ++p;
                rez-=termen();
                break;}
    return rez;}

long long termen(){
    int rez=factor();

    while(*p=='*'||*p=='/')
        switch(*p){
            case '*':
                ++p;
                rez*=factor();
                break;
            case '/':
                ++p;
                rez/=factor();
                break;}
    return rez;}

long long factor(){
    int rez;

    if(*p=='('){
        ++p;
        rez=eval();
        ++p;}
    else
        for(rez=0; isdigit(*p); rez=rez*10+*p-'0',++p);
    return rez;}

void read(){

    gets(s);}

void print(){

    printf("%lld",eval());}

int main(){

    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);

    read();
    print();
    return 0;}
