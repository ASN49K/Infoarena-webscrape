#include <iostream>
#include <fstream>
#include <algorithm>
#include <string>

using namespace std;

#define maxLeng 100010

char S[maxLeng], *p;

int Termen ();
int Factor ();


int Eval ()
{
	int R = Termen ();
	
	while (*p == '+' || *p == '-')
	{
		if (*p == '+') ++ p, R += Termen ();
		else ++ p, R -= Termen ();
	}

	return R;
}


int Termen ()
{
	int R = Factor ();
	
	while (*p == '*' || *p == '/')
	{
		if (*p == '*') ++ p, R *= Factor();
		else ++ p, R /= Factor ();
	}
	
	return R;
}


int Factor ()
{
	int R = 0;

	if (*p == '(')
	{
		++ p;
		R = Eval ();
		++ p;
	}
	else while (*p >= '0' && *p <= '9')
	{
		R = R * 10 + (*p) - '0';
		++ p;
	}
	
	return R;
}


int main()
{
	ifstream f ("evaluare.in");
	ofstream g ("evaluare.out");
	
	f.getline (S, maxLeng);
	
	p = S;
	
	g << Eval ();
	
	return 0;
}
