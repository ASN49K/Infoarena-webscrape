#include <bits/stdc++.h>
using namespace std;
#define ll                 long long 
#define all(v)             v.begin(), v.end()
ll ceil2(ll a, ll b) {
return (a + b - 1) / b;
}
// #include <ext/pb_ds/assoc_container.hpp> 
// #include <ext/pb_ds/tree_policy.hpp> 
// using namespace __gnu_pbds; 
// #define ordered_set tree<int, null_type,less<int>, rb_tree_tag,tree_order_statistics_node_update> 

#define mod 1999999973;

bool compare(char a, char b){
    if(a=='(') return 0;
    if(a=='*' || a=='/') return 1;
    else if(a!='*' && a!='/' && b!='*' && b!='/') return 1;
    else return 0;
}

void solve(){
    string s;cin>>s;
    ll n=s.length();
    vector<string> v;
    stack<char> st;
    for(int i=0; i<n; i++){
        string dig="";
        while(i<n && s[i]>='0' && s[i]<='9'){
            dig+=s[i];
            i++;
        }
        if(dig.length()) v.push_back(dig);
        if(i<n){
            if(s[i]==')'){
                // cout<<st.size()<<" ";
                while(!st.empty() && st.top()!='('){
                    v.push_back(string(1, st.top()));
                    st.pop();
                }
                st.pop();
            }
            else if(s[i]=='(') st.push(s[i]);
            else{
                while(!st.empty() && compare(st.top(), s[i])){
                    v.push_back(string(1, st.top()));
                    st.pop();
                }
                st.push(s[i]);
            }
            
        }
    }
    while(!st.empty() ){
        v.push_back(string(1, st.top()));
        st.pop();
    }

    // for(int i=0; i<v.size(); i++){
    //     cout<<v[i]<<" ";
    // }
    
    stack<ll> st2;
    for(int i=0; i<v.size(); i++){
        string sir=v[i];
        char c=v[i][0];
        if(v[i].length()>1 || (c>='0' && c<='9')){
            ll number=0;
            for(int j=0; j<v[i].length(); j++){
                number=number*10+v[i][j]-'0';
            }
            // cout<<number<<" ";
            st2.push(number);
        }
        else{
            // if(st2.size()<2) {cout<<i<<" ";return;}
            ll x=st2.top();st2.pop();
            ll y=st2.top();st2.pop();
            if(v[i]=="+"){
                st2.push((x+y));
            }
            else if(v[i]=="-"){
                st2.push((y-x));
            }
            else if(v[i]=="/"){
                st2.push((y/x));
            }
            else if(v[i]=="*"){
                st2.push((x*y));
            }
            
        }
    }
    // cout<<st2.size();
    // while(!st2.empty()){
    //     cout<<st2.top()<<" ";
    //     st2.pop();
    // }
    cout<<st2.top();
}


int main(){
    freopen("evaluare.in", "rt", stdin);
	freopen("evaluare.out", "wt", stdout);
   ios_base::sync_with_stdio(false); cin.tie(NULL);
//    ll t;cin>>t;while(t--){solve();cout<<endl;}
    solve();
}