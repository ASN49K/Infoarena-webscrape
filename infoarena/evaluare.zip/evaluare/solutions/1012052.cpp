#include <stdio.h>
#include <stdlib.h>
#include <vector>

using namespace std;

vector<char> operatorQueue;
vector<int> valueQueue;

int expressionLength = 0;
char expression[100001];
char buffer[100001];
int bufferSize = 0;



void readData(){
    char c;

    do {
        scanf("%c", &c);
        expression[expressionLength++] = c;
    } while (c != EOF && c!= '\n');

}

int computeNewValue(char op, int operand1, int operand2){
    int newValue = 0;

    switch(op){
        case '*':
            newValue = operand1*operand2;
        break;

        case '-':
            newValue = operand1-operand2;
        break;

        case '+':
            newValue = operand1+operand2;
        break;

        case '/':
            newValue = operand1/operand2;
        break;
    }

    return newValue;
}

void handleClosingBrackets(){
    char currentOperator = operatorQueue.back();
    operatorQueue.pop_back();


    while(currentOperator != '(') {
        int operand2 = valueQueue.back();
        valueQueue.pop_back();

        int operand1 = valueQueue.back();
        valueQueue.pop_back();

        int newValue = computeNewValue(currentOperator, operand1, operand2);
        valueQueue.push_back(newValue);

        currentOperator = operatorQueue.back();
        operatorQueue.pop_back();
    }

}

int firstHasBiggerPrecedence(char firstOperator, char secondOperator){

    if (firstOperator == '*' || firstOperator == '/'){
        if (secondOperator == '+' || secondOperator == '-'){
            return 1;
        } else {
            return 0;
        }
    } else {
        return 0;
    }
}


void handleNewOperator(char newOperator){

    if (operatorQueue.size() != 0){
        char currentOperator = operatorQueue.back();
        int operand1, operand2;

        while(currentOperator != '('
              && !firstHasBiggerPrecedence(newOperator, currentOperator)) {
            operatorQueue.pop_back();

            operand2 = valueQueue.back();
            valueQueue.pop_back();

            operand1 = valueQueue.back();
            valueQueue.pop_back();

            int newValue = computeNewValue(currentOperator, operand1, operand2);
            valueQueue.push_back(newValue);

            if (operatorQueue.size() == 0){
                break;
            }

            currentOperator = operatorQueue.back();
        }
    }

    operatorQueue.push_back(newOperator);
}

void handleNonNumberCase(char c){

   switch(c){
        case '(':
          operatorQueue.push_back(c);
        break;

        case ')':
            handleClosingBrackets();
        break;

        default:
            handleNewOperator(c);
   }

}


void solveProblem(){
    char c;

    for (int i=0; i<expressionLength; i++){
        c = expression[i];

        if (c <= '9' && c >= '0'){
            buffer[bufferSize++] = c;
        } else{

            if (bufferSize != 0) {
                buffer[bufferSize] = '\0';
                int operand = atoi(buffer);
                valueQueue.push_back(operand);
                bufferSize = 0;
            }

            handleNonNumberCase(c);
        }
    }

    if (bufferSize != 0) {
        buffer[bufferSize] = '\0';
        int operand = atoi(buffer);
        valueQueue.push_back(operand);
        bufferSize = 0;
    }


    int operand1, operand2, newValue;

    while (operatorQueue.size() != 0){
        c = operatorQueue.back();
        operatorQueue.pop_back();

        operand2 = valueQueue.back();
        valueQueue.pop_back();

        operand1 = valueQueue.back();
        valueQueue.pop_back();

        newValue = computeNewValue(c, operand1, operand2);
        valueQueue.push_back(newValue);
    }

}

int main()
{
    freopen("evaluare.in", "r", stdin);
    freopen("evaluare.out", "w", stdout);

    readData();

    solveProblem();

    printf("%d", valueQueue[0]);

    return 0;
}
