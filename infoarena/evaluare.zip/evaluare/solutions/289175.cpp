#include<stdio.h>
#include<cstring>

#define LMAX 2  
char op[4][4] = { "+-", "*/", "^", "" };  
   
#define NX 100010 
char s[NX],*p = s;

long eval(long a,long b,char op)
{
   switch(op)
   {
     case '+' : return a+b;
     case '-' : return a-b;
     case '*' : return a*b;
     case '/' : return a/b;        
     default  : return 0;
   }    
}

long expr(int lev)
{
   long x,y;
     
   if(lev == LMAX)
   {
       if(*p == '(')
         ++p,x = expr(0),++p;
       else
         for(x = 0; '0' <= *p && *p <= '9'; ++p)
           x = x * 10 + *p - '0';
   }     
   else
   {
       for(x = expr(lev+1); strchr(op[lev],*p); x = y)
         y = eval(x,expr(lev+1),*p++); 
   }
   return x;
}

int main()
{
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);
    
    scanf("%s",s);

    printf("%ld",expr(0));
    fclose(stdin); fclose(stdout);
    return 0;
}
