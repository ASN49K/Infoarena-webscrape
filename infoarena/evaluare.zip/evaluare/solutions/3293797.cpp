#include <bits/stdc++.h>

using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
string s;
int st[100003];
int vf;
int op1=1e9+1,op2=1e9+2,op3=1e9+3,op4=1e9+4;
int rez;
int main()
{
    fin>>s;
    for (int i=0;i<s.size();i++)
    {
        if (isdigit(s[i]))
        {
            int nr=0;
            while (i<s.size() && isdigit(s[i])) nr=nr*10+(s[i]-'0'),i++;
            i--;
            if (vf==0) st[++vf]=nr;
            else if (st[vf]==op1) vf--,st[vf]-=nr;
            else if (st[vf]==op2) vf--,st[vf]*=nr;
            else if (st[vf]==op3) vf--,st[vf]/=nr;
            else st[++vf]=nr;
        }
        else if (s[i]=='-') st[++vf]=op1;
        else if (s[i]=='*') st[++vf]=op2;
        else if (s[i]=='/') st[++vf]=op3;
        else if (s[i]=='(') st[++vf]=op4;
        else if (s[i]==')')
        {
            int nr=0;
            while (st[vf]!=op4) nr+=st[vf],vf--;
            vf--;
            if (vf==0) st[++vf]=nr;
            else if (st[vf]==op1) vf--,st[vf]-=nr;
            else if (st[vf]==op2) vf--,st[vf]*=nr;
            else if (st[vf]==op3) vf--,st[vf]/=nr;
            else st[++vf]=nr;
        }
    }
    for (int i=1;i<=vf;i++)
        rez=rez+st[i];
    fout<<rez;
    return 0;
}
