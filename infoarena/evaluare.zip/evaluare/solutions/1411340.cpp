#include <fstream>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
char *p = new char[100005];
int evaluateExpresion();
int evaluateMultiplication();
int evaluateNumber();
int evaluateNumber()
{
    int result=0;
    if((*p)=='(')
    {
        p++;
        result+=evaluateExpresion();
        p++;
    }
    else
    {
        while(*p>='0' && *p<='9')
        {
            result=result*10+*p-'0';
            ++p;
        }
    }
    return result;
}
int evaluateMultiplication()
{
    int result=evaluateNumber();
    while(*p=='*' || *p=='/')
    {
        if(*p=='*')
        {
            ++p;
            result*=evaluateNumber();
        }
        else
        {
            ++p;
            result/=evaluateNumber();
        }
    }
    return result;
}

int evaluateExpresion()
{
    int result=evaluateMultiplication();
    while(*p=='+' || *p=='-')
    {
        if(*p=='+')
        {
            ++p;
            result+=evaluateMultiplication();
        }
        else
        {
            ++p;
            result+=evaluateMultiplication();
        }
    }
    return result;
}
int main()
{
    f>>p;
    g<<evaluateExpresion()<<"\n";
    return 0;
}
