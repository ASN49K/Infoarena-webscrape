#include <iostream>
#include <fstream>
#define MAX 100002
using namespace std;
char s[MAX];
int pos;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int expresie();
int termen();
int factor();

int main()
{
    fin >> s;
    pos = 0;
    fout << expresie();
    return 0;
}

int expresie(){
    int r = termen();
    while(s[pos] == '+' || s[pos] == '-'){
        if(s[pos] == '+'){
            pos++;
            r += termen();
        }else{
            pos++;
            r -= termen();
        }
    }
    return r;
}

int termen(){
    int r = factor();
    while(s[pos] == '*' || s[pos] == '/'){
        if(s[pos] == '*'){
            pos++;
            r *= factor();
        }else{
            pos++;
            r /= factor();
        }
    }
    return r;
}

int factor(){
    int r = 0;
    if(s[pos] == '('){
        pos++;
        r = expresie();
        pos++;
    }else{
        r = 0;
        while(s[pos] >= '0' && s[pos] <= '9'){
            r *= 10;
            r += s[pos]-'0';
            pos++;
        }
    }
    return r;
}
