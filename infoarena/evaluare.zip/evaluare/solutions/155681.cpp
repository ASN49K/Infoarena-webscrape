#include <cstdio>
#define Nmax 100002

FILE *fin=freopen("evaluare.in","r",stdin),
     *fout=freopen("evaluare.out","w",stdout);
  
char A[Nmax];

int k;
     
int termen();
int factor();

int eval()
{
  int r = termen();
  while(A[k] == '+' || A[k] == '-')
  {
    
    switch(A[k])
    {
      case '+':
        k++;
        r += termen();
      break;
       
      case '-':
        k++;
        r -= termen();
      break;
    }
  }
  return r;
}

int termen()
{
  int r = factor();
  while(A[k] == '*' || A[k] == '/')
  {
    
    switch(A[k])
    {
      case '*':
        k++;
        r *= factor();
      break;
       
      case '/':
        k++;
        r /= factor();
      break;
    }
  }
  return r;
}    
     
int factor()
{
  int r = 0;
  
  if( A[k] == '(')
  {
    ++k;
    r= eval();
    ++k;
  }
  
  else 
    while (A[k] >= '0' && A[k] <= '9')
    {
      r=r*10 +  A[k] - '0';
      ++k;
    }
  return r;
}
     
int main()
{
  gets(A);
  
  printf("%d\n",eval());
  return 0;
}
