#include <fstream>
#include <cstring>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
int i=0; char a[100003];
int factor();
int termen();

int expresie(){
int p=termen();
if(a[i]=='+'){i++; p+=termen(); }else if(a[i]=='-'){i++; p-=termen();}
return p;
}

int termen(){
int p=factor();
if(a[i]=='*'){i++;p*=factor();} else if(a[i]=='/'){i++; p/=factor();}
return p;
}

int factor(){ int p=0;
if(a[i]=='('){i++; p=expresie(); i++;}
else if(isdigit(a[i]))
    while(isdigit(a[i])){p=p*10+(a[i]-'0'); i++;}
return p;
}

int main()
{
    fin.get(a,100001);
    fout<<expresie();
    return 0;
}
