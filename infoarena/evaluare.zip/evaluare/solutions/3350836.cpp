#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char s[100005], *p = s;

int eval(int a, int b, char op)
{
    switch(op)
    {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b;
    }
    return 0;
}

int expr(int lev)
{
    int x, y;

    if(lev == 2)
    {
        if(*p == '(')
        {
            ++p;
            x = expr(0);
            ++p; // trece peste ')'
        }
        else
        {
            x = 0;
            while(*p >= '0' && *p <= '9')
            {
                x = x * 10 + (*p - '0');
                ++p;
            }
        }

        return x;
    }

    x = expr(lev + 1);

    while((lev == 0 && (*p == '+' || *p == '-')) || (lev == 1 && (*p == '*' || *p == '/')))
    {
        char op = *p;
        ++p;
        y = expr(lev + 1);
        x = eval(x, y, op);
    }

    return x;
}

int main()
{
    fin >> s;
    fout << expr(0);

    return 0;
}