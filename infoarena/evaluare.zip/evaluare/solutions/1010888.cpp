#include<fstream>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
char s[100001];
int i=0; 
long eval();
long termen();
long factor(); 
long eval()
{
    long r=termen();
    while(s[i]=='+' || s[i]=='-')
    {
        if(s[i]=='+')
        {
            i++;
            r=r+termen();
             
        }
        if(s[i]=='-')
        {
            i++;
            r=r-termen();
        }
    }
    return r;
}
long termen()
{
    long r=factor();
    while(s[i]=='/' || s[i]=='*')
    {
        if(s[i]=='*')
        {
            i++;
            r=r*factor();
         
        }
        if(s[i]=='/')
        {
            i++;
            r=r/factor();
        }
    }
    return r;
     
}
long factor()
{
    long r=0;
    if (s[i]=='(')
    {
        i++;
        r=eval();
        i++;
    }
    else
    {   
        while(s[i]>='0'&& s[i]<='9')
        {
            r=r*10 + long(s[i]-'0');
            i++;
             
        }
    }
    return r;
} 
int main()
{
    f.getline(s,100001);
    g<<eval();
    return 0;
}