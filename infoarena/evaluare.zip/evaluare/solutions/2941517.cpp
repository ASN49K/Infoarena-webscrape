#include <fstream>
#include <stack>
using namespace std;

ifstream fin ("evaluare.in");
ofstream fout ("evaluare.out");
stack<int> numbers;
stack<char>op;
char s[100001];

int calc(int a,int b, char op) {

    if( op == '-') return a-b;
    if( op == '+') return a+b;
    if(op == '*') return a*b;
    if(op == '/') return a/b;
}
int grad(char t) {

    if(t == '*' || t == '/')
        return 2;
    if(t == '-' || t == '+')
        return 1;
    return 0;
}

int evaluate(){

    int length = strlen(s+1);
    for ( int i = 1; i <= length; i++ ){
        if(s[i] == ' ') continue;
        if(s[i] == '(')
        op.push(s[i]);

        if(s[i] >= '0' and s[i] <= '9')
        {
            int number = 0;
            while(i <= length and s[i] >= '0' and s[i] <= '9') { 
                number = number *10 + s[i] - '0';
                ++i;
            }
            --i;
               numbers.push(number);
        }else
        if(grad(s[i])) {
            while(op.size() > 0 and grad(s[i]) <= grad(op.top())) {
                int val2 = numbers.top();
                numbers.pop();
                int val1 = numbers.top();
                numbers.pop();
                char opr = op.top();
                op.pop();
                int rez = calc(val1,val2,opr);
             
                numbers.push(rez);
            }
            op.push(s[i]);
        }

        else if(s[i] == ')') {
            while(op.size() > 0 && op.top() != '(') {
                   int val2 = numbers.top();
                numbers.pop();
                int val1 = numbers.top();
                numbers.pop();
                char opr = op.top();
                op.pop();
                int rez = calc(val1,val2,opr);
                   fout << "BAG " << " "  << val1 << " " << opr << " "<<val2 << " " << rez << "\n";
          
                numbers.push(rez);
            }
            if(op.size() > 0 )
                op.pop();
        }
        }
    while(op.size() > 0) {
                int val2 = numbers.top();
                numbers.pop();
                int val1 = numbers.top();
                numbers.pop();
                char opr = op.top();
                op.pop();
                int rez = calc(val1,val2,opr);
             
                numbers.push(rez);
       
    }

   return numbers.top();
    } 


int main() {
    fin >> (s+1);
    fout << evaluate();

}