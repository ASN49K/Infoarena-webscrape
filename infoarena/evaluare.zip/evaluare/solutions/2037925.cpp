#include <fstream>
#include <deque>
#include <cstring>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

deque <char> Op;
deque <int> Val;

int Prioritate(char c)
{
   if(strchr("*/",c)) return 2;
   if(strchr("+-",c)) return 1;
}

bool isOperator(char c)
{
  if(strchr("+-*/",c)) return 1;

  return 0;
}

void Do()
{
  int a,b;

  b=Val.back();
  Val.pop_back();

  a=Val.back();
  Val.pop_back();

  if(Op.back()=='+') Val.push_back(a+b);
  if(Op.back()=='*') Val.push_back(a*b);
  if(Op.back()=='/') Val.push_back(a/b);
  if(Op.back()=='-') Val.push_back(a-b);

  Op.pop_back();
}


void Read()
{
  char x;
  int nr=0;

  while(fin>>x)
  {
    if(isdigit(x)) nr=nr*10+(int)(x-'0');
    else { if(nr>0) Val.push_back(nr);
           //fout<<nr<<' ';
           nr=0;
         }
    if(x=='(') Op.push_back(x);
    if(x==')')
    {
      while(Op.back()!='(') Do();

      Op.pop_back();
    }
    if(isOperator(x))
      { while(!Op.empty() && Op.back()!='(')
          if(Prioritate(Op.back())>=Prioritate(x))
            Do();
          else break;
        Op.push_back(x);
      }
  }
  if(nr>0) Val.push_back(nr);

  while(!Op.empty()) Do();
}

void Print()
{
  fout<<Val.back()<<'\n';
  fout.close();
}

int main()
{
    Read();
    Print();

    return 0;
}
