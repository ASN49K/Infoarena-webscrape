#include<stdio.h>
#include<string.h>

char s[100000], *p=s;

int eval();
int termen();
int factor();
void cit()
{
	scanf("%s",&s);
	
}

int termen()
{
	long r=factor();
	
	while(*p=='*' || *p=='/')
	{
		switch(*p)
		{
		case '*':
			{
				++p;
				r*=factor();
				break;
			}
		case '/':
			{
				++p;
				r/=factor();
				break;
			}
		}
	}
	return r;
}

int factor()
{
	long r=0;
	if(*p=='(')
	{
		++p;
		r=eval();
		++p;
	}
	else
	{
		while(*p>='0' && *p<= '9')
		{
			r=r*10 + *p-'0';
			++p;
		}
	}
	return r;
}




int eval()
{
	long r=termen();
	
	while(*p=='+' || *p=='-')
	{
		switch(*p)
		{
		case '+':
			{
				++p;
				r+=termen();
				break;
			}
		case '-':
			{
				++p;
				r-=termen();
				break;
			}
		}
	}
	
	return r;
}


int main()
{
	freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	
	cit();
	printf("%d",eval());
	
	
	return 0;
}