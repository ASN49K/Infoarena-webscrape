#include <fstream>
#include <cstring>

using namespace std;
int i = 0,n;
char s[100001];
ifstream f("evaluare.in");
ofstream g("evaluare.out");
int termen();
int expresie();
int factor();

int termen()
{
    int t=factor();
    while(i<n&&(s[i]=='+'||s[i]=='-'))
    {
        if (s[i] == '+')
        {i++;
        t=t+factor();}
        if(s[i] == '-')
        {
            i ++ ;
            t = t - factor() ;
        }

    }
    return t;
}
int expresie()
{
    int t;
    if(s[i]=='(')
    {   i++;
        t=termen();
        i++;

    }
    else {
        int nr = 0 ;
    while ('0' <= s[i] && s[i] <= '9')
    {
        nr = nr * 10 + (s[i] - '0');
        i ++ ;
    }
    t = nr ; }


    return t;
}
int factor()
{
    int f=expresie();
    while(i<n&&(s[i]=='*'||s[i]=='/'))
    {
        if (s[i] == '*')
        {i++;
        f=f*expresie();}
        if (s[i] == '/')
        {
            i ++ ;
            f /= expresie() ;
        }

    }
    return f;
}



int main()
{

        f.getline(s , 100001);
        n = strlen(s) ;
        g << termen() ;


    return 0;
}
