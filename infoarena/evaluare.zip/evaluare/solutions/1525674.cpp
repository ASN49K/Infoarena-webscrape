#include <stdio.h>
#include <cstring>

#define maxdim 100005

int p;
char A[maxdim];

int evaluateLevel2(), evaluateTerm();

int evaluateLevel1() {
	int r = evaluateLevel2();

	while (A[p] == '+' || A[p] == '-') {
		char op = A[p++];
		if (op == '+') {
			r += evaluateLevel2();
		} else {
			r -= evaluateLevel2();
		}
	}

	return r;
}

int evaluateLevel2() {
	int r = evaluateTerm();

	while (A[p] == '*' || A[p] == '/') {
		char op = A[p++];
		if (op == '*') {
			r *= evaluateTerm();
		} else {
			r /= evaluateTerm();
		}
	}

	return r;
}

int evaluateTerm() {

	if (A[p] == '(') {
		++p;
		int r = evaluateLevel1();
		++p;
		return r;
	}

	int r = 0;
	while (A[p] >= '0' && A[p] <= '9') {
		r = r * 10 + A[p] - '0';
		++p;
	}
	return r;
}

int main() {

	freopen("evaluare.in", "r", stdin);
	freopen("evaluare.out", "w", stdout);

	scanf("%s", A+1);
	p = 1;

	printf("%d\n", evaluateLevel1());

	return 0;
}
