#include <iostream>
#include <fstream>
#include <cstring>



using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");


char s[100001];


int nr(int stanga, int dreapta)
{
    int num=0;
    for(int i=stanga; i<=dreapta; i++)
        num=num*10+(s[i]-'0');

    return num;
}
int cauta(int stanga, int dreapta, char s1, char s2)
{
    int nr=0;
    for(int i=dreapta; i>=stanga; i--)
    {
        if(s[i]==')')
            nr++;
        if(s[i]=='(')
            nr--;
        if(nr==0 && (s1==s[i] || s2==s[i]))
            return i;
    }


    return -1;
}

int rez(int stanga, int dreapta)
{
    int k=cauta(stanga,dreapta,'+','-');
    if(k!=-1)
    {
        int ex1=rez(stanga,k-1);
        int ex2=rez(k+1,dreapta);
        if(s[k]=='+')
            return ex1+ex2;
        return ex1-ex2;
    }


    k=cauta(stanga,dreapta,'*','-/');
    if(k!=-1)
    {
        int ex1=rez(stanga,k-1);
        int ex2=rez(k+1,dreapta);
        if(s[k]=='*')
            return ex1*ex2;
        return ex1/ex2;
    }


    if(s[stanga]=='(' && s[dreapta]==')')
        return rez(stanga+1,dreapta-1);
    return nr(stanga,dreapta);
}
int main()
{
    f.getline(s,100001);
    int n=strlen(s);
    g<<rez(0,n-1);

    return 0;
}
