#include <cstdio>
#include <cstring>
#define NMax 100005

char e[NMax+1];
int p,lg;
int Expresie();
int Factor();
int Termen();
int Get();

void Read()
{
    fgets(e,NMax,stdin);
    lg = strlen(e);
    if(e[lg-1]=='\n' ) --lg;
}

int Get()
{
    int numar = 0;
    while(e[p]>='0' && e[p]<='9') numar = numar*10 + e[p++] - '0';
    return numar;
}

int Factor()
{
    int f;
    if( e[p] == '(' ){
        ++p;
        f = Expresie();
        ++p;
    } else f = Get();
    return f;
}

int Termen()
{
    int f = Factor();
    while(p < lg && ( e[p] == '*' || e[p] == '/' ) )
    {
        if( e[p] == '*' ) { ++p; f = f * Factor(); }
        else { ++p; f = f / Factor(); }
    }
    return f;
}

int Expresie()
{
    int op, t = Termen();
    while(p < lg && ( e[p] == '+' || e[p] == '-' ) )
    {
        if( e[p] == '+' ) op = 1;
        else op = -1;
        ++p;
        t = t + op*Termen();
    }
    return t;
}

int main(){
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);

    Read();
    printf("%d\n", Expresie() );



return 0;
}
