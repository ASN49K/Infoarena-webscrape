#include<stdio.h>

char ch[100010],*p=ch;
long long add(void);
long long  multi(void);
long long nr(void);

long long add(){
long long  r=multi();

if(*p=='+'){p++;r+=add();return r;}
else
if(*p=='-'){p++;r-=add();return r;}
return r;
}

long long  multi(){
long long  r=nr();

if(*p=='*'){p++;r*=multi();return r;}
else
	if(*p=='/'){p++;r/=multi();return r;}
return r;
}
long long  nr(){
long long r=0;
if(*p=='(')
	{p++;r=add();p++;}
else
	while(*p>='0'&&*p<='9')
		{r=(r*10)+(*p-'0');p++;}
	return r;
}
int main(){
freopen("evaluare.in","r",stdin);
freopen("evaluare.out","w",stdout);

scanf("%s",ch);
printf("%d",add());
return 0;}

