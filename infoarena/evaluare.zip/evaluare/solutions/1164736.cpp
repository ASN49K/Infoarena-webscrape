#include<cstdio>

using namespace std;

int r,i;
char w[100100];
int eval(),termen(),factor();

int eval()
{
    int r=termen();
    while(w[i]=='+' || w[i]=='-')
    {
        if(w[i]=='+') ++i,r+=termen();
        else ++i,r-=termen();
    }
    return r;
}

int termen()
{
    int r=factor();
    while(w[i]=='*' || w[i]=='/')
    {
        if(w[i]=='*') ++i,r*=factor();
        else ++i,r/=factor();
    }
    return r;
}

int factor()
{
    int r=0;
    if(w[i]=='(')
    {
        ++i;
        eval();
        ++i;
    }
    else while(w[i]>='0' && w[i]<='9')
    {
        r=r*10+w[i]-'0';
        ++i;
    }
    return r;

}

int main()
{
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);
    scanf("%s",w);
    i=0;
    printf("%d\n",eval());
    return 0;
}
