//ALEXANDRU MICLEA

#include <vector>
#include <algorithm>
#include <string>
#include <cstring>
#include <queue>
#include <map>
#include <set>
#include <unordered_map>
#include <time.h>
#include <iomanip>
#include <deque>
#include <math.h>
#include <cmath>
#include <assert.h>
#include <stack>
#include <bitset>
#include <random>
#include <chrono>
#include <iostream>
#include <array>

using namespace std;
using ll = long long;

//VARIABLES



//FUNCTIONS

void kmp(string s) {
    int maxx = 0;
    int cnt = 0;

    int n = s.size();
    vector <int> pi(n);

    for (int i = 1; i < n; i++) {
        int j = pi[i - 1];
        while (j > 0 && s[i] != s[j]) j = pi[j - 1];
        if (s[i] == s[j]) j++;
        pi[i] = j;
    }
    //for (int i = 1; i < n; i++) cout << pi[i] << ' ';

    int ok = 0;
    if (pi[n - 1]) {
        for (int i = 1; i < n - 1; i++) {
            if (pi[i] == pi[n - 1]) {
                ok = 1;
                cout << s.substr(n - pi[n - 1], pi[n - 1]);
                break;
            }
            else if (pi[pi[n - 1] - 1]) {
                ok = 1;
                cout << s.substr(n - pi[pi[n - 1]], pi[pi[n - 1]] + 1);
                break;
            }
        }
    }

    if (ok == 0) cout << "Just a legend";
}

//MAIN
int main() {

    string s;
    cin >> s;

    kmp(s);
    
    return 0;
}