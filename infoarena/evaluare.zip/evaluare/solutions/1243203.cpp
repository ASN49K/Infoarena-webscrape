#include <cstdio>

#define NMAX 100005
#define isDigit(x) ((x) >= '0' && (x) <= '9')

using namespace std;

char expr[NMAX];

int solve(int &pos);

int parseInt(int &pos)
{
  int res = 0;
  while(isDigit(expr[pos]))
  {
    res = res * 10 + expr[pos] - '0';
    pos++;
  }
  return res;
}

int term(int &pos)
{
  int t;
  if(isDigit(expr[pos]))
  {
    t = parseInt(pos);
  }
  else if(expr[pos] == '(')
  {
    pos++;
    t = solve(pos);
    pos++;
  }
  return t;
}

int prodDiv(int &pos)
{
  int t = term(pos);
  while(expr[pos] == '*' || expr[pos] == '/')
  {
    if(expr[pos] == '*')
    {
      pos++;
      t *= term(pos);
    }
    else
    {
      pos++;
      t /= term(pos);
    }
  }
  return t;
}

int solve(int &pos)
{
  int res = prodDiv(pos);
  while(expr[pos] == '+' || expr[pos] == '-')
  {
    if(expr[pos] == '+')
    {
      pos++;
      res += prodDiv(pos);
    }
    else
    {
      pos++;
      res -= prodDiv(pos);
    }
  }
  return res;
}

void read()
{
  freopen("evaluare.in", "r", stdin);
  freopen("evaluare.out", "w", stdout);
  scanf("%s", expr);
}

int main() {
  int pos = 0;
  read();
  int rez = solve(pos);
  printf("%d", rez);
	return 0;
}
