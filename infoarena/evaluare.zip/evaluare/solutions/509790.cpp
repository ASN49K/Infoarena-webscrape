#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
char s[100010];
unsigned long lg;
struct nod
{
    char info[20];
    struct nod *st,*dr;
};
typedef nod* Arbore;
Arbore r;
Arbore CreareArbore(long&);
Arbore Termen(long&);
Arbore Factor(long&);
long long rezultat(Arbore r)
{
    switch(r->info[0])
    {
        case '+': return rezultat(r->st)+rezultat(r->dr);break;
        case '-': return rezultat(r->st)-rezultat(r->dr);break;
        case '*': return rezultat(r->st)*rezultat(r->dr);break;
        case '/': return rezultat(r->st)/rezultat(r->dr);break;
        default: return atol(r->info);
    }
}
int main()
{
    long i=0;
    f>>s;
    lg=strlen(s)-1;
    r=CreareArbore(i);
    g<<rezultat(r);
    f.close();
    g.close();
    return 0;
}
Arbore CreareArbore(long &i)
{
    Arbore p,r1;
    char t[20];
    int j=0;
    if(i>lg)
       return NULL;
    r1=Termen(i);
    if(i>lg || s[i]==')')
       return r1;
    p=new nod;
    if(!(s[i]>='0' && s[i]<='9'))
    {
         t[0]=s[i++];
         t[1]='\0';
         strcpy(p->info,t);
    }
    else
    {
        while(s[i]>='0' && s[i]<='9')
        {
            t[j++]=s[i];
            i++;
        }
        t[j]='\0';
        strcpy(p->info,t);
    }
    p->st=r1;
    p->dr=CreareArbore(i);
    return p;
}
Arbore Termen(long &i)
{
    Arbore p,r1;
    char t[20];
    int j=0;
    r1=Factor(i);
    if(i>lg || s[i]!='*')
       return r1;
    p=new nod;
    if(!(s[i]>='0' && s[i]<='9'))
    {
         t[0]=s[i++];
         t[1]='\0';
         strcpy(p->info,t);
    }
    else
    {
        while(s[i]>='0' && s[i]<='9')
        {
            t[j++]=s[i];
            i++;
        }
        t[j]='\0';
        strcpy(p->info,t);
    }
    p->st=r1;
    p->dr=Termen(i);
    return p;
}
Arbore Factor(long &i)
{
    Arbore p;
    char t[20];
    int j=0;
    if(s[i]=='(')
    {
        ++i;
        p=CreareArbore(i);
        i++;
        return p;
    }
    p=new nod;
    if(!(s[i]>='0' && s[i]<='9'))
    {
         t[0]=s[i++];
         t[1]='\0';
         strcpy(p->info,t);
    }
    else
    {
        while(s[i]>='0' && s[i]<='9')
        {
            t[j++]=s[i];
            i++;
        }
        t[j]='\0';
        strcpy(p->info,t);
    }
    p->st=p->dr=NULL;
    return p;
}
