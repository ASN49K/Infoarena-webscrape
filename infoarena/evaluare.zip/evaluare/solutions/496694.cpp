#include <stdio.h>
#include <stack>
FILE *f,*g;
using namespace std;
struct cp{int x; char y;} aux,nr[100000];

stack <cp> sm;
stack <int> sol;
int nn;
int nr2;
inline  int ord(char ch)
{
 if (ch=='(') return -4;
 if (ch==')') return -3;
 if (ch=='+' || ch=='-') return -2;
 if (ch=='*' || ch=='/') return -1;
}

void ins(cp & smn)
{
    if (smn.x==-4) sm.push(smn);
        else {
    while (sm.size()>0 && sm.top().x>=smn.x)
            {
          nr[++nn]=sm.top();
          sm.pop();
            }
    if (smn.x!=-3) sm.push(smn);
    else sm.pop();
        }
}

void citire() {
int nr2;
char c;
fscanf(f,"%c",&c);
while (!feof(f)) {

        if (c>='0' && c<='9') {
            nr2=0;
            while (c>='0' && c<='9') {
                   nr2=nr2*10+(c-'0');
                   fscanf(f,"%c",&c);
                    }
            nr[++nn].x=nr2;
            continue;
            }
        if (c=='\n') {
            while (sm.size()>0) {
                    nr[++nn]=sm.top();
                    sm.pop();
                    }
            break;
            }
        aux.x=ord(c); aux.y=c;
        ins(aux);
        fscanf(f,"%c",&c);
        }
}

void solve() {
int i,n1,n2,rs;
for (i=1;i<=nn;i++)
    if (nr[i].x<0)
        {
        n1=sol.top();
        sol.pop();
        n2=sol.top();
        sol.pop();
        if (nr[i].y=='+') rs=n1+n2;
        if (nr[i].y=='-') rs=n2-n1;
        if (nr[i].y=='*') rs=n2*n1;
        if (nr[i].y=='/') rs=n2/n1;
        sol.push(rs);
        }
    else sol.push(nr[i].x);

}

int main() {
f=fopen("evaluare.in","r");
g=fopen("evaluare.out","w");
citire();
int i;
solve();
fprintf(g,"%d",sol.top());
fclose(g);
return 0;
}
