#include <stdio.h>
#include <fstream>

using namespace std;

int	plus_minus(char *s, int i);
int get_number(char *s, int *i);

int	eval(char *s)
{
	//int r;

	/*r = plus_minus(s);
	while (*s != '\0' && *s >= '0' && *s <= '9')
	{
		r = r * 10 + (*s - '0');
		s++;
	}*/
	return (plus_minus(s, 0));
}

int	plus_minus(char *s, int i)
{
	int r;

	r = 0;
	while (s[i] != '\0' && s[i] >= '0' && s[i] <= '9')
	{
		r = r * 10 + (s[i] - '0');
		i++;
	}
	while (s[i] == '-' || s[i] == '+')
	{
		i++;
		if (s[i - 1] == '-')
			r -= get_number(s, &i);
		else
			r += get_number(s, &i);
	}
	return (r);
}

int	get_number(char *s, int *i)
{
	int r;

	r = 0;
	while (s[*i] != '\0' && s[*i] >= '0' && s[*i] <= '9')
	{
		r = r * 10 + (s[*i] - '0');
		*i = *i + 1;
	}
	return (r);
}

int	eval_expr(char *str)
{
//	trim(str);
	//if (str == 0)
		//return (0);
	return (plus_minus(str, 0));
}

int main()
{
	ifstream f("evaluare.in");
	ofstream g("evaluare.out");
	char s[100000];
	f.get(s, 100000);
	g << eval_expr(s);
}
