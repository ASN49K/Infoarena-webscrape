#include<stdio.h>   
#include<string.h>   
#include<ctype.h>   
void read(),solve();   
char s[100005],op[100005];   
int v[100005],l,V,O,i,val,j,op0,vv,oo;    
int main()   
{   read();   
    solve();   
    printf("%d",v[1]);   
    return 0;   
}   
void read()   
{   freopen("evaluare.in","r",stdin);   
    freopen("evaluare.out","w",stdout);   
    scanf("%s",s);   
    l=strlen(s);   
}   
void solve()   
{   for(i=0;i<l;i++)   
    {   //if(s[i]=='-'&&s[i-1]=='('){ v[++V]=-1; op[++O]='*'; continue;}   
        if(isdigit(s[i])) { val=0;   
                           while(isdigit(s[i])){ val*=10; val+=(int)(s[i]-'0'); i++;}   
                           i--;   
                           if(op[O]=='*'){ v[V]*=val; O--;}   
                           else if(op[O]=='/'){ v[V]/=val; O--;}   
                           else v[++V]=val;   
                           continue;   
                         }   
        if(s[i]==')'){   
                        op0=0;j=O;   
                        while(op[j]!='('){op0++;j--;}   
                        for(vv=V-op0+1,oo=j+1;vv<=V;vv++,oo++)   
                        { if(op[oo]=='+') v[V-op0]+=v[vv];   
                             else v[V-op0]-=v[vv];   
                        }   
                        O=j-1;   
                        V=V-op0;   
                        if(op[O]=='*'){ v[V-1]*=v[V];V--; O--;}   
                          else if(op[O]=='/'){ v[V-1]/=v[V]; V--; O--;}   
                        continue;   
                      }   
        if(strchr("(+-*/",s[i]))op[++O]=s[i];   
    }   
    op0=0;j=O;   
                        while(j){op0++;j--;}   
                        for(vv=V-op0+1,oo=j+1;vv<=V;vv++,oo++)   
                        { if(op[oo]=='+') v[V-op0]+=v[vv];   
                             else v[V-op0]-=v[vv];   
                        }   
                        O=j-1;   
                        V=V-op0;   
}  
