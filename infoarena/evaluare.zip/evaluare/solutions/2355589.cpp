#include <iostream>
#include <fstream>
#include <string>
#include <stack>

using namespace std;

ifstream in("evaluare.in");
ofstream out("evaluare.out");

string s;
int poz = 0;
stack <char> signs;
stack <int> numbers;

int calc(int v1, int v2, char s)
{
    switch(s)
    {
    case '+' :
        return v1 + v2;
    case '-' :
        return v1 - v2;
    case '*' :
        return v1 * v2;
    case '/' :
        return v1 / v2;
    }
}
void add()
{
    int val2 = numbers.top();
    numbers.pop();
    int val1 = numbers.top();
    numbers.pop();
    char sign = signs.top();
    signs.pop();
    numbers.push(calc(val1, val2, sign));
}

int nmbr(){
    int res = 0;
    while(s[poz] >= '0' && s[poz] <= '9')
        res = res * 10 + (s[poz++] - '0');
    return res;
}

bool order(char s1, char s2){
    if(s1 == '(')
        return 1;
    if((s1 == '+' || s1 == '-') && (s2 == '*' || s2 == '/'))
        return 1;
    return 0;
}

int main()
{
    in >> s;

    while(poz < s.size())
    {
        if(s[poz] == '(')
        {
            signs.push(s[poz++]);
            continue;
        }
        if(s[poz] == ')')
        {
            while(signs.top() != '(')
                add();
            signs.pop();
            poz++;
            continue;
        }
        if(s[poz] == '+' || s[poz] == '-' || s[poz] == '*' || s[poz] == '/'){
                if(signs.empty() || order(signs.top(), s[poz]))
                    signs.push(s[poz++]);
                    continue;
        }
        else{
            do{
                add();
            }while(!signs.empty() && order(signs.top(), s[poz]));
            signs.push(s[poz++]);
            continue;
        }
        numbers.push(nmbr());
    }

    while(!signs.empty())
        add();
    out << numbers.top();
    return 0;
}
