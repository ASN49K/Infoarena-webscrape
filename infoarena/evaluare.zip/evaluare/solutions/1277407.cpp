#include <fstream>
#define Lung 100003
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
char x[Lung];
int i;
int eval();
int termen();
int factor();

int eval(){
    int r = termen();
    while(x[i] == '+' || x[i] == '-'){
        if(x[i] == '+'){
            ++i;
            r += termen();
        }
        if(x[i] == '-'){
            ++i;
            r -= termen();
        }
    }
    return r;
}
int termen(){
    int r = factor();
    while(x[i] == '*' || x[i] == '/'){
        if(x[i] == '*'){
            ++i;
            r *= factor();
        }
        if(x[i] == '/'){
            ++i;
            r /= factor();
        }
    }
    return r;
}
int factor(){
    int r = 0;
    if(x[i] == '('){
        ++i;
        r = eval();
        ++i;
    }else{
        while(x[i] <='9' && x[i] >='0'){
            r = r*10 + x[i]-'0';
            ++i;
        }
    }
    return r;
}
int main()
{
    f.getline(x,Lung);
    g << eval();
    return 0;
}
