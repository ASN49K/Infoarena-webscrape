#include <fstream>
#include <cstring>
using namespace std;

ifstream fin ("evaluare.in");
ofstream fout ("evaluare.out");

char s[100005];
int i, lg;

int expresie();
int termen();
int factor();

int main()
{
    fin.getline(s, 100005);
    lg=strlen(s);
    i=0;
    fout<<expresie();
    return 0;
}

int expresie() ///operatori + sau -
{
    int sum=termen(); ///primul termen
    while (i<lg && (s[i]=='+' || s[i]=='-'))
        if (s[i]=='+') {i++; sum+=termen();}
        else {i++; sum-=termen();}
    return sum;
}

int termen() ///operatori * sau /
{
    int prod=factor(); ///primul factor
    while (i<lg && (s[i]=='*' || s[i]=='/'))
        if (s[i]=='*') {i++; prod*=factor();}
        else {i++; prod/=factor();}
    return prod;
}

int factor()
{
    int semn=1, val=0;
    if (s[i]=='-') i++,semn=-1;
    if (s[i]=='(')
    {
        i++; val=expresie(); i++;
        return val*semn;
    }
    while (i<lg && s[i]>='0' && s[i]<='9')
        val=val*10+s[i++]-'0';
    return val*semn;
}