#include <iostream>
#include <fstream>
#include <string>

using namespace std;

char s[100010], *p = s;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

long long termen();
long long factor();

long long expresie()
{
    long long t = termen();
    while(*p == '+' || *p == '-')
    {
        if(*p == '+')
        {
            p++;
            t += termen();
            //break;
        }
        if(*p == '-')
        {
            p++;
            t -= termen();
           // break;
        }
    }

    return t;
}

long long termen()
{
    long long f = factor();
    while(*p == '*' || *p == '/')
    {
        if(*p == '*')
        {
            p++;
            f *= factor();
            //break;
        }
        if(*p == '/')
        {
            p++;
            f /= factor();
           // break;
        }
    }

    return f;
}

long long factor()
{
    long long x = 0;
    if(*p == '(')
    {
        p++;
        x = expresie();
        p++;
    }
    else
    {
        while(*p >= '0' && *p <= '9')
        {
            x = x*10 + *p - '0';
            p++;
        }
    }

    return x;
}

int main()
{
    fin.get(s, 100010);
    fout << expresie();
    return 0;
}
