#include <cstdio>
#include <cstring>
#define LMAX 100001
void expresie();
void termen();
void factor();
int calculare();
char c[LMAX];
char rez[LMAX];
int i=0;
int lc,lrez=0;

int main()
{
	freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	fgets(c,LMAX,stdin);
	lc=strlen(c);
	while(!c[lc] || c[lc]=='\n' || c[lc]==EOF)
		lc--;
	expresie();
	printf("%d",calculare());
	
	return 0;
}

void expresie()
{
	termen();
	char a;
	while((c[i]=='+' || c[i]=='-') && i<lc)
	{
		a=c[i];
		i++;
		termen();
		rez[++lrez]=a;
	}
}

void termen()
{
	factor();
	char a;
	while((c[i]=='*'|| c[i]=='/')&& i<lc)
	{
		a=c[i];
		i++;
		termen();
		rez[++lrez]=a;
	}
}

void factor()
{
	if(c[i]=='(' && i<lc)
	{
		i++;
		expresie();
		i++;
	}
	else
	{
		while(c[i]>='0' && c[i]<='9')
			rez[++lrez]=c[i++];
		rez[++lrez]=' ';
	}
}

int calculare()
{
	int N[LMAX],nr=0;
	int x;
	int semn,adaugare,i2;
	for(int i=1;i<=lrez;i++)
		if(rez[i]>='0' && rez[i]<='9')
		{
			x=0;
			while(rez[i]>='0' && rez[i]<='9')
				x=x*10+rez[i++]-'0';
			N[++nr]=x;
		}
		else if(rez[i]=='+' || rez[i]=='-' || rez[i]=='*' || rez[i]=='/')
		{
			if(rez[i]=='+') 
			{
				semn=0,adaugare=1,i2=i;
				while(rez[i]=='+')
					semn++,i++;
				i--;
				while(adaugare<=semn)
				{
					N[nr-semn]+=N[nr-semn+adaugare];
					adaugare++;
				}
				nr-=semn;
			}
			else if(rez[i]=='-') 
			{
				semn=0,adaugare=1,i2=i;
				while(rez[i]=='-')
					semn++,i++;
				i--;
				while(adaugare<=semn)
				{
					N[nr-semn]-=N[nr-semn+adaugare];
					adaugare++;
				}
				nr-=semn;
			}
			else if(rez[i]=='*')
			{
				semn=0,adaugare=1,i2=i;
				while(rez[i]=='*')
					semn++,i++;
				i--;
				while(adaugare<=semn)
				{
					N[nr-semn]*=N[nr-semn+adaugare];
					adaugare++;
				}
				nr-=semn;
			}
			else
			{
				semn=0,adaugare=1,i2=i;
				while(rez[i]=='/')
					semn++,i++;
				i--;
				while(adaugare<=semn)
				{
					N[nr-semn]/=N[nr-semn+adaugare];
					adaugare++;
				}
				nr-=semn;
			}
		}
	return N[1];
}
