#include<stdio.h>
#include<string.h>
char v[100001],s1[100];
int k,x,aux,n,i,t,j,ok;
struct nod
{
	int inf,clc;
	nod *nxt,*ant;
};
nod *s2,*s3,*c,*p,*u,*c3,*p3,*u3;
int op(int a, int b, int s)
{
	if(s==3)return a+b;
	if(s==4)return a-b;
	if(s==1)return a*b;
	if(s==2)return a/b;
	return 0;
}
int main()
{
	freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	scanf("%s",&v);
	n=strlen(v)+1;
	c=new nod;
	c->inf=0;
	c->clc=0;
	c->nxt=NULL;
	c->ant=NULL;
	p=u=c;
	for(i=0;i<n;i++)
	{
		if(v[i]>='0'&&v[i]<='9')
		{
			aux=0;
			while(v[i]>='0'&&v[i]<='9')
			{
				aux=aux*10+v[i]-48;
				i++;
			}
			i--;
			c=new nod;
			c->inf=aux;
			c->clc=0;
			u->nxt=c;
			c->ant=u;
			c->nxt=NULL;
			u=c;
		}
		else if(v[i]=='(')
				s1[++x]=v[i];
		else if(v[i]=='+'||v[i]=='-')
				if(x>0&&s1[x]!='(')
				{
					while(x>0&&s1[x]!='(')
					{
						c=new nod;
						u->nxt=c;
						c->ant=u;
						c->nxt=NULL;
						u=c;
						if(s1[x]=='*')
							c->clc=1,c->inf=0;
						if(s1[x]=='/')
							c->clc=2,c->inf=0;
						if(s1[x]=='+')
							c->clc=3,c->inf=0;
						if(s1[x]=='-')
							c->clc=4,c->inf=0;
						s1[x]='\0';
						x--;
					}
					x++;
					s1[x]=v[i];
				}
				else s1[++x]=v[i];
		else if(v[i]=='*'||v[i]=='/')
				s1[++x]=v[i];
		else if(v[i]==')')
		{
			while(s1[x]!='(')
			{
				c=new nod;
				u->nxt=c;
				c->ant=u;
				c->nxt=NULL;
				u=c;
				if(s1[x]=='*')
					c->clc=1,c->inf=0;
				if(s1[x]=='/')
					c->clc=2,c->inf=0;
				if(s1[x]=='+')
					c->clc=3,c->inf=0;
				if(s1[x]=='-')
					c->clc=4,c->inf=0;
				s1[x]='\0';
				x--;
			}
			s1[x]='\0';
			x--;
		}
	}
	while(x>0)
	{
		c=new nod;
		u->nxt=c;
		c->ant=u;
		c->nxt=NULL;
		u=c;
		if(s1[x]=='*')
			c->clc=1,c->inf=0;
		if(s1[x]=='/')
			c->clc=2,c->inf=0;
		if(s1[x]=='+')
			c->clc=3,c->inf=0;
		if(s1[x]=='-')
			c->clc=4,c->inf=0;
		x--;
	}
	p=p->nxt;
	ok=1;
	while(ok)
	{
		c=p->nxt->nxt;
		ok=1;
		while(c)
		{
			if(c->clc!=0)
				if(c->ant->clc==0&&c->ant->ant->clc==0)
				{
					aux=op(c->ant->ant->inf,c->ant->inf,c->clc);
					p3=c->ant->ant;
					p3->nxt=c->nxt;
					if(c->nxt)c->nxt->ant=p3;
					c=p3;
					c->inf=aux;
					ok=0;
				}
			c=c->nxt;
		}
	}
	printf("%d",p->inf);
	return 0;
}