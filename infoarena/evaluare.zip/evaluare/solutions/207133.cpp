#include <cstdio>
#define N 100010
char sir[N],*p=sir;
long produs();
long termen();

long suma()
{long s=produs();
 while(*p=='+'||*p=='-')
 {switch(*p)
  {case '+':++p;s+=produs();break;
   case '-':++p;s-=produs();break;
  }
 }
 return s;
}

long produs()
{long s=termen();
 while(*p=='*'||*p=='/')
 {switch(*p)
  {case '*':++p;s*=termen();break;
   case '/':++p;s/=termen();break;
  }
 }
return s;
}

long termen()
{long s=0;
 if(*p=='(')
 {++p;
  s=suma();
  ++p;
 }
 else
 {while(*p>='0'&&*p<='9')
  {s=s*10+*p-'0';
   ++p;
  }
 } 
 return s;
}

int main ()
{ fgets(sir, N, fopen("eval.in", "r"));
    fprintf(fopen("eval.out", "w"), "%ld\n", suma());
    return 0;

}
