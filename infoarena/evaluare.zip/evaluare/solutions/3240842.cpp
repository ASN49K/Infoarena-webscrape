#include <fstream>
using namespace std;
ifstream  fin("evaluare.in");
ofstream fout("evaluare.out");
char e[100009],*p=e;
long long Factor();
long long Termen();
long long Expresie();

long long Factor()
{
    long long r=0;

    while(*p>='0' && *p<='9')
    {
        r=r*10+*p-'0';
        p++;
    }

    return r;
}

long long Termen()
{
    long long r=Factor();
    while(*p=='*' || *p=='/')
    {
        if(*p=='*')
        {
            p++;
            r*=Factor();
        }
        else
        {
            p++
            r/=Factor();
        }
    }

    return r;
}

long long Expresie()
{
    long long r=Termen();

    while(*p=='+' || *p=='-')
    {
        if(*p=='+')
        {
            p++;
            r+=Termen();
        }
        else
        {
            p++;
            r-=Termen();
        }
    }

    return r;
}


int main()
{
    fin.get(e,100009);

    fout<< Expresie();

    return 0;
}
