#include <bits/stdc++.h>

using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
char c[100050];
int pos;

int add();

int fact()
{
    int res=0;
    if(c[pos]=='(')
    {
        pos++;
        res=add();
        pos++;
    }
    else
    while(c[pos]>='0' and c[pos]<='9')
    {
        res*=10;
        res+=c[pos]-'0';
        pos++;
    }
    return res;
}

int mult()
{
    int res=fact();
    while(c[pos]=='*' or c[pos]=='/')
    {
        if(c[pos]=='*')
        {
            pos++;
            res*=fact();
            
        }
        else
            {
                pos++;
                res/=fact();
            }
    }
    return res;
}

int add()
{
    int res=mult();
    while(c[pos]=='+' or c[pos]=='-')
    {
        if(c[pos]=='+')
        {
            pos++;
            res+=mult();
        }
        else
        {
            pos++;
            res-=mult();
        }
    }
    return res;
}

int main()
{f>>c;
g<<add();
   return 0;
}
