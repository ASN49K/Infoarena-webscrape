#include <cstdio>
#include <string>
using namespace std;
const int NMAX = 100505;
char A[NMAX];

/* expr -> term (+ | -) expr | term 
 * term -> factor (* | /) term | factor
 * factor -> ([0-9]*) | ( expr )
 */

int parseExpr(char*&);
int parseTerm(char*&);
int parseFactor(char*&);

inline int parseExpr(char*& A) {
  int lhs = parseTerm(A);
  if (*A == '+' || *A == '-') {
    int sgn = *A == '+' ? 1 : -1;
    int rhs = parseExpr(++A);
    return lhs + rhs * sgn;
  }
  return lhs;
}

inline int parseTerm(char*& A) {
  int lhs = parseFactor(A);
  if (*A == '*' || *A == '/') {
    char sgn = *A;
    int rhs = parseTerm(++A);
    return sgn == '*' ? lhs * rhs : lhs / rhs;
  }
  return lhs;
}

inline int parseFactor(char*& A) {
  if (isdigit(*A)) {
    int no = 0;
    while (isdigit(*A)) {
      no = no * 10 + *A - '0';
      A++;
    }
    return no;
  }
  // parse (
  int res = parseExpr(++A);
  // parse )
  A++;
  return res;
}

int main() {
  freopen("evaluare.in", "r", stdin);
  freopen("evaluare.out", "w", stdout);
  
  fgets(A + 1, NMAX, stdin);
  char* B = A + 1;
  printf("%d\n", parseExpr(B));
  return 0;
}
