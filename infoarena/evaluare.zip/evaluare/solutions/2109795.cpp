// codari: - =-1, +=-2, /=-11, *=-12, (=-21, )=-22

#include <iostream>
#include <cstdio>
#include <stack>
#include <cstring>

using namespace std;

stack<int>valori;
stack<int>operanzi;

int numar=0,n,ok;
char sir[100005];

int verif(int x)
{
    if (operanzi.top()<=x-10)
    {
        return 1;
    }
    return 0;
}

void operare()
{
    int a=valori.top();
    valori.pop();
    int b=valori.top();
    valori.pop();
    int c=operanzi.top();
    operanzi.pop();
    if (c==-11)
        valori.push(b-a);
    else if (c==-12)
        valori.push(a+b);
    else if (c==-21)
        valori.push(b/a);
    else if (c==-22)
        valori.push(a*b);
}

void paranteza()
{
    while (operanzi.top()!=-1)
    {
        int a=valori.top();
        valori.pop();
        int b=valori.top();
        valori.pop();
        int c=operanzi.top();
        operanzi.pop();
        if (c==-11)
            valori.push(b-a);
        else if (c==-12)
            valori.push(a+b);
        else if (c==-21)
            valori.push(b/a);
        else if (c==-22)
            valori.push(a*b);
    }
    operanzi.pop();
}

void parcurgere()
{
    while (!operanzi.empty())
    {
        int a=valori.top();
        valori.pop();
        int b=valori.top();
        valori.pop();
        int c=operanzi.top();
        operanzi.pop();
        if (c==-11)
            valori.push(b-a);
        else if (c==-12)
            valori.push(a+b);
        else if (c==-21)
            valori.push(b/a);
        else if (c==-22)
            valori.push(a*b);
    }
    printf("%d",valori.top());
}

int main()
{
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);
    fgets(sir,100001,stdin);
    n=strlen(sir);
    if (sir[n-1]=='\n')
    {
        sir[n-1]=='\0';
        n--;
    }
    for (int i=0; i<n; i++)
    {
        if (sir[i]>='0' && sir[i]<='9')
        {
            numar=numar*10+(sir[i]-'0');
            ok=1;
        }
        else
        {
            if (ok==1)
                valori.push(numar);
            if (sir[i]=='-')
            {
                if (verif(-11)==1)
                {
                    operare();
                }
                operanzi.push(-11);
            }
            else if (sir[i]=='+')
            {
                if (verif(-11)==1)
                {
                    operare();
                }
                operanzi.push(-12);
            }
            else if (sir[i]=='*')
            {
                if (verif(-11)==1)
                {
                    operare();
                }

                operanzi.push(-22);
            }
            else if (sir[i]=='/')
            {
                if (verif(-11)==1)
                {
                    operare();
                }
                operanzi.push(-21);
            }
            else if (sir[i]=='(')
            {
                operanzi.push(-1);
            }
            else
            {
                paranteza();
            }
            ok=0;
            numar=0;
        }
    }
    valori.push(numar);
    parcurgere();

    return 0;
}
