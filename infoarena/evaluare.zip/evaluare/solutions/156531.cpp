#include <stdio.h>
#include <string.h>
#define NMAX 100002

char Exp[NMAX];

long long evalExp(int l, int r) {
	int i;
	/*for (i = l; i <= r; ++ i)
		printf("%c", Exp[i]);
	printf("\n");*/
	
	int nPar = 0, iDiv = -1;
	
	for (i = r; i >= l; -- i) {
		if (Exp[i] == ')') {
			++ nPar;
			continue;
		}
		if (Exp[i] == '(') {
			-- nPar;
			continue;
		}
		
		if (nPar == 0) {
			if (Exp[i] == '+')
				return evalExp(l, i - 1) + evalExp(i + 1, r);
			if (Exp[i] == '-')
				return evalExp(l, i - 1) - evalExp(i + 1, r);
			
			if (Exp[i] == '*' || Exp[i] == '/')
				iDiv = i;
		}
	}
	
	if (iDiv != -1)
		if (Exp[iDiv] == '*')
			return evalExp(l, iDiv - 1) * evalExp(iDiv + 1, r);
		else
			return evalExp(l, iDiv - 1) / evalExp(iDiv + 1, r);
	
	if (Exp[l] == '(' && Exp[r] == ')')
		return evalExp(l + 1, r - 1);
	
	long long x;
	sscanf(Exp + l, "%ld", &x);
	return x;
}

int main() {
	
	freopen("evaluare.in", "r", stdin);
	freopen("evaluare.out", "w", stdout);
	
	scanf("%s", Exp);
	long long ans = evalExp(0, strlen(Exp) - 1);
	printf("%ld\n", ans);
	
	return 0;
}
