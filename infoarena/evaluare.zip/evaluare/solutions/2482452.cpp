#include <iostream>
#include <fstream>

using namespace std;

ifstream f("evaluare.in");
ofstream g("evaluare.out");

bool isDigit(char c);
int termen(char *(&p));
int eval(char *(&p));
int factor(char *(&p));

bool isDigit(char c)
{
    return (c>='0' && c<='9');
}

int factor(char *(&p))
{
    int x=0;
    cout<<*p<<' ';
    while(isDigit(*p))
        x=x*10+(*p-'0'),++p;
    cout<<x<<'\n';
    return x;
}

int termen(char *(&p))
{
    int x;
    if(*p=='(')
    {
        x=eval(++p);
        while(*p=='*' || *p=='/')
    {
        if(*p=='*')
            x*=factor(++p);
        else
            x/=factor(++p);
    }
        return x;
    }
    x=factor(p);
    while(*p=='*' || *p=='/')
    {

        if(*p=='*')
            x*=factor(++p);
        else
            x/=factor(++p);
    }
    return x;
}

int eval(char *(&p))
{
    int res=termen(p);
    while(*p!='\00' && *p!=')')
    {
        if(*p=='+')
        {
            ++p;
            int x=termen(p);
            res+=x;
        }
        else
        {
            ++p;
            int x=termen(p);
            res-=x;
        }

    }
    ++p;
    return res;
}

int main()
{
    char s[1000];
    f>>s;
    char *p=s;
    g<<eval(p);
    return 0;
}
