#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <deque>
#include <list>
#include <string>
#include <algorithm>
using namespace std;
ifstream ff("evaluare.in");
ofstream gg("evaluare.out");

int i=0;
string ss;
int exp();

int trm(){
	int x=0;
	if(ss[i]=='('){ i++; x=exp(); i++; } else {
		while('0'<=ss[i]&&ss[i]<='9') x=x*10+ss[i++]-'0';
	}
	return x;
}

int fct(){
	int x = trm();
	while(ss[i]=='*'||ss[i]=='/'){
		if(ss[i]=='*'){ i++; x*=fct(); } else
		if(ss[i]=='/'){ i++; x/=fct(); }
	}
	return x;
}

int exp(){
	int x = fct();
	while(ss[i]=='+'||ss[i]=='-'){
		if(ss[i]=='+'){ i++; x+=fct(); } else
		if(ss[i]=='-'){ i++; x-=fct(); };
	}
	return x;
}

int main(){
	ff >> ss;
	ss += "\0";
	gg << exp();
	return 0;
}
