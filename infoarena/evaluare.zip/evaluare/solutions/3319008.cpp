#include <fstream>
#include <queue>
#include <stack>
#include <map>
#include <string>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

bool isDigit(char ch){
    return ch >= '0' && ch <= '9';
}

bool isOperator(char ch){
    return ch == '+' || ch == '-' || ch == '/' || ch == '*';
}

int main() {

    string expression;
    fin >> expression;

    map<char, int> precedenceRules;
    precedenceRules.insert(pair('+', 0));
    precedenceRules.insert(pair('-', 0));
    precedenceRules.insert(pair('*', 1));
    precedenceRules.insert(pair('/', 1));
    precedenceRules.insert(pair('(', -1));

    int index = 0;
    queue<int> outputQueue;
    stack<char> operatorStack;
    while(index < expression.size()){
        if(isDigit(expression.at(index))){
            int number = 0;

            while(index < expression.size() && isDigit(expression.at(index))){
                number = number * 10 + (expression.at(index) - '0');
                index++;
            }

            outputQueue.push(number);
            index--;
        }else if(isOperator(expression.at(index))){
            char currentOperator = expression.at(index);

            while(!operatorStack.empty() && precedenceRules.at(operatorStack.top()) > precedenceRules.at(currentOperator)){
                outputQueue.push(-(int)operatorStack.top());
                operatorStack.pop();
            }

            operatorStack.push(currentOperator);
        }else{
            if(expression.at(index) == '(')
                operatorStack.push('(');
            else{
                while(operatorStack.top() != '('){
                    outputQueue.push(-operatorStack.top());
                    operatorStack.pop();
                }

                operatorStack.pop();
            }
        }

        index++;
    }

    while(!operatorStack.empty()){
        outputQueue.push(-operatorStack.top());
        operatorStack.pop();
    }

    vector<int> result;
    while(!outputQueue.empty()){
        if(outputQueue.front() > 0)
            result.push_back(outputQueue.front());
        else{
            int currOp = -outputQueue.front();
            if((char)currOp == '+')
                result[result.size() - 2] += result[result.size() - 1];
            else if((char) currOp == '-')
                result[result.size() - 2] -= result[result.size() - 1];
            else if((char)currOp == '/')
                result[result.size() - 2] /= result[result.size() - 1];
            else
                result[result.size() - 2] *= result[result.size() - 1];

            result.pop_back();
        }

        outputQueue.pop();
    }

    fout << result[0];

    return 0;
}


