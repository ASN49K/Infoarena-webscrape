#include <fstream>
#include <string>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
string s;		
int n, i;

int termen();
int factor();

int expresie() {
	int val = 0;
	val = termen();
	while (i < n && s[i] != ')') {
		if (s[i] == '+') {
			++i;
			val += termen();
		}
		if (s[i] == '-') {
			++i;
			val -= termen();
		}
	}
	return val;
}

int termen() {
	int val = 1;
	if (s[i] == '(') {
		++i;
		val = expresie();
		++i;
	} else {
		val = factor();
	}
	while (i < n && s[i] != '+' && s[i] != '-' && s[i] != ')') {
		if (s[i] == '*') {
			++i;
			val *= factor();
		}
		if (s[i] == '/') {
			++i;
			val /= factor();
		}
	}
	return val;
}

int factor() {
	int val = 0;
	while (i < n && s[i] >= '0' && s[i] <= '9') {
		val = val * 10 + (s[i] - '0');
		++i;
	}
	return val;
}

int main() {
	fin >> s;
	n = s.size();
	i = 0;
	fout << expresie();
	return 0;
}