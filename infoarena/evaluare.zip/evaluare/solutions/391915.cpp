#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>


FILE *in=fopen("expresie.in","r");
FILE *out=fopen("expresie.out","w");

char expr[100];
int n,nr=0;
float val_expr=0;//valoare finala a expresiei



void Citire()
{
	fgets(expr,1000,in);
	n=strlen(expr);
	if(expr[n-1]=='\n') { expr[n-1]=NULL; n--; }

}
float calc(int &i);
float calculeaza(int &i);
float paranteza(int &i);
int semn(char x) // determina daca val se va aduna sau scadea din val_expr;
{
	if(x=='+') return 1;
	if(x=='-') return -1;
}
float calc(int &i)
{
	float x=0,nr1=0;
	int x2=0;

	while(i<n&&expr[i]>='0'&&expr[i]<='9')
	{
	 x=x*10+expr[i]-48;
	 i++;
	}
	if(expr[i]=='.')
		 {
			 i++;
			 while(i<n&&expr[i]>='0'&&expr[i]<='9')
				{
					x2=x2*10+expr[i]-48;
					nr1++;
					i++;
				 }
		 }

	x=x+x2/pow(10,nr1);

 return x;
}

float calculeaza(int &i)
{
	float val=1,x;
		char op;
	if(expr[i]=='(') { val=paranteza(i); i++; nr++;}
	else 
		{
			val=calc(i);
			if(expr[i]=='*'||expr[i]=='/'&&nr<=1)
				while(expr[i]!='+'&&expr[i]!='-'&&expr[i]!=')'&&i<n)
					{
					   op=expr[i];
					   i++;
					   if(expr[i]=='(')
						   x=calculeaza(i);
					   if(expr[i]>='0'&&expr[i]<='9') x=calc(i);
					   if(op=='*') val=val*x;
					   if(op=='/') val=val/x;
			   
					}
		}
		return val;
		
}

float paranteza(int &i)
{
	float val=0;
	float val_par=0;
	char op='+';
	i++;
	while(expr[i]!=')'&&i<n)
	{
		if(expr[i]=='+'||expr[i]=='-'||expr[i]=='*'||expr[i]=='/')
			{ op=expr[i]; i++; }
		if(expr[i]>='0'&&expr[i]<='9')
			val=calculeaza(i);
		if(expr[i]=='(') val=calculeaza(i);
		if(op=='-'||op=='+') 
			val_par=val_par+semn(op)*val;
		if(op=='*') val_par=val_par*val;
		if(op=='/') val_par=val_par/val;
		op=expr[i];
		
	}
   return val_par;
}

void Rezolvare()
{
	float val=0;
	char op='+';
	int i;
	
	for(i=0;i<n;i++)
	{
		if(expr[i]=='+'||expr[i]=='-'||expr[i]=='*'||expr[i]=='/')
			{ op=expr[i]; i++; }
		if(expr[i]>='0'&&expr[i]<='9')
			val=calculeaza(i);
		if(expr[i]=='(') val=calculeaza(i);
		if(!(expr[i]==')'&&expr[i-1]==')'))
		{
			if(op=='-'||op=='+') 
			val_expr=val_expr+semn(op)*val;
			if(op=='*') val_expr=val_expr*val;
			if(op=='/') val_expr=val_expr/val;
			if(expr[i]=='+'||expr[i]=='-'||expr[i]=='*'||expr[i]=='/')
				op=expr[i];
		}
	}
	fprintf(out,"%.3f",val_expr);
}
int main()
{
	Citire();
	Rezolvare();
	return 0;
}
