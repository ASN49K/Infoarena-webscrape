#include <fstream>
#include <stack>
#include <cstring>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
bool simbol(char c)
{
    return c=='+' || c=='-' || c=='*' || c=='/';
}
bool cifra(char c)
{
    return c>='0' && c<='9';
}
int op(int x,int y,int ind)
{
    if(ind==1)
        return x*y;
    if(ind==2)
        return x/y;
    if(ind==3)
        return x+y;
    if(ind==4)
        return x-y;
}
stack <int> num,semne;
char c[100011];
int cod[200],i,n,nr1,nr2,nr;
int main()
{
    f>>c;
    cod['*']=1;
    cod['/']=2;
    cod['+']=3;
    cod['-']=4;
    cod['(']=5;
    n=strlen(c);
    for(i=0;i<n;i++)
    {
        if(simbol(c[i])==1)
        {
            while(semne.empty()==false && semne.top()<cod[c[i]])
            {
                nr2=num.top();
                num.pop();
                nr1=num.top();
                num.pop();
                nr1=op(nr1,nr2,semne.top());
                semne.pop();
                num.push(nr1);
            }
            semne.push(cod[c[i]]);
        }
        else
        if(c[i]=='(')
            semne.push(cod[c[i]]);
        else
            if(cifra(c[i])==1)
            {
                nr=0;
                while(cifra(c[i])==1)
                {
                    nr=nr*10+c[i]-'0';
                    i++;
                }
                i--;
                num.push(nr);
            }
            else
            {
            while(semne.top()!=5)
            {
                nr2=num.top();
                num.pop();
                nr1=num.top();
                num.pop();
                nr1=op(nr1,nr2,semne.top());
                semne.pop();
                num.push(nr1);
            }
            semne.pop();
            }
    }
    while(semne.empty()==false)
    {
        nr2=num.top();
        num.pop();
        nr1=num.top();
        num.pop();
        nr1=op(nr1,nr2,semne.top());
        semne.pop();
        num.push(nr1);
    }
    g<<num.top();
    return 0;
}
