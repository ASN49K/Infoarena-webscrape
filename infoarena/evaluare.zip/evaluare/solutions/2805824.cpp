#include <cstdio>
#define N 100002
#include <cstring>

using namespace std;
FILE* f, * g;

int stiva[N], p[N], n;
char c[N];

int adun(int a, int b)
{
    return (a + b);
}
int scad(int a, int b)
{
    return (a - b);
}
int inm(int a, int b)
{
    return (a * b);
}
int imp(int a, int b)
{
    return (a / b);
}
int cauta(int op, int a, int b)
{
    if (op == -2)
        return adun(a, b);
    if (op == -3)
        return scad(a, b);
    if (op == -4)
        return inm(a, b);
    if (op == -5)
        return imp(a, b);
}
int main()
{
    f = fopen("evaluare.in", "r");
    g = fopen("evaluare.out", "w");
    int lg, nr, j, op1, op2;
    fscanf(f, "%s", &c);
    lg = strlen(c);
    for (int i = 0;i < lg;++i)
    {
        if (c[i] == '(')
        {
            stiva[++n] = -1;
            p[++p[0]] = n;
        }
        else
            if (c[i] == '+')
                stiva[++n] = -2;
            else
                if (c[i] == '-')
                    stiva[++n] = -3;
                else
                    if (c[i] == '*')
                        stiva[++n] = -4;
                    else
                        if (c[i] == '/')
                            stiva[++n] = -5;
                        else
                            if (c[i] >= '0' && c[i] <= '9')
                            {
                                nr = 0;
                                while (c[i] >= '0' && c[i] <= '9' && i <= lg)
                                {
                                    nr = nr * 10 + c[i] - '0';
                                    ++i;
                                }
                                --i;
                                stiva[++n] = nr;
                            }
                            else
                            {
                                op1 = -4;
                                op2 = -5;
                                for (j = p[p[0]];j <= n;j += 2)
                                {
                                    if (stiva[j] == op1 || stiva[j] == op2)
                                    {
                                        stiva[j - 1] = cauta(stiva[j], stiva[j - 1], stiva[j + 1]);
                                        for (int k = j;k < n - 1;++k)
                                            stiva[k] = stiva[k + 2];
                                        j -= 2;
                                        n -= 2;
                                    }
                                }
                                op1 = -2;
                                op2 = -3;
                                for (j = p[p[0]];j <= n;j += 2)
                                {
                                    if (stiva[j] == op1 || stiva[j] == op2)
                                    {
                                        stiva[j - 1] = cauta(stiva[j], stiva[j - 1], stiva[j + 1]);
                                        for (int k = j;k < n - 1;++k)
                                            stiva[k] = stiva[k + 2];
                                        j -= 2;
                                        n -= 2;
                                    }
                                }
                                for (j = p[p[0]];j < n;++j)
                                    stiva[j] = stiva[j + 1];
                                --p[0];
                                --n;
                            }
    }
    op1 = -4;
    op2 = -5;
    for (j = 2;j <= n;j += 2)
    {
        if (stiva[j] == op1 || stiva[j] == op2)
        {
            stiva[j - 1] = cauta(stiva[j], stiva[j - 1], stiva[j + 1]);
            for (int k = j;k < n - 1;++k)
                stiva[k] = stiva[k + 2];
            n -= 2;
            j -= 2;
        }
    }
    op1 = -2;
    op2 = -3;
    for (j = 2;j <= n;j += 2)
    {
        if (stiva[j] == op1 || stiva[j] == op2)
        {
            stiva[j - 1] = cauta(stiva[j], stiva[j - 1], stiva[j + 1]);
            for (int k = j;k < n - 1;++k)
                stiva[k] = stiva[k + 2];
            j -= 2;
            n -= 2;
        }
    }
    fprintf(g, "%d", stiva[1]);
    fclose(f);
    fclose(g);
    return 0;
}