#include <stdio.h>
#include <string.h>
#define maxn 100010

char op[4][4]={"+-","*/","^",""};
char s[maxn],*p=s;

int eval(int a,int b,char op)
{
    switch(op)
    {
        case '+': return a+b;
        case '-': return a-b;
        case '*': return a*b;
        case '/': return a/b;
    }
}
int expr(int lev)
{
    int x,y;
    if(lev==2)
     if(*p=='(') ++p,x=expr(0),++p;
     else
      for(x=0; *p>='0' && *p<='9'; ++p)
       x=x*10+(*p-'0');
    else
     for(x=expr(lev+1); strchr(op[lev],*p); x=y)
      y=eval(x,expr(lev+1),*p++);
    return x;
}
int main()
{
   fgets(s,maxn,fopen("evaluare.in","r"));
   fprintf(fopen( "evaluare.out", "w" ),"%d\n",expr(0));
   return 0;
}

