#include <bits/stdc++.h>
#define N 100008

using namespace std;

ifstream fin("apel.in");
ofstream fout("apel.out");

int n;
char s[N];
char t[N];
map< char, int > prec;
map< char, string > val;
map< char, pair< string, string > > fc;


void Citire()
{
    int i;
    fin >> s + 1;
    n = strlen( s + 1 );
    prec['('] = 0;
    prec[')'] = 0;
    prec['+'] = 1;
    prec['-'] = 1;
    prec['*'] = 2;
    prec['/'] = 2;
    while( fin >> t + 1 )
    {
        if( t[1] >= 'a' && t[1] <= 'z' )
        {
            i = 3;
            string nr = "";
            while( isdigit( t[i] ) )
                nr += t[i++];
            val[ t[1] ] = nr;
        }
        else
        {
            i = 2;
            string par = "";
            while( t[i] != '=' )
            {
                if( isalpha( t[i] ) )
                    par += t[i];
                i++;
            }
            i++;
            fc[ t[1] ].first = par;
            string exp = "";
            while( t[i] )
                exp += t[i++];
            fc[ t[1] ].second = exp;
        }
    }
}

stack<char> ops;
stack<int> values;

inline int rez( int val1, int val2, char op )
{
    if( op == '+' )
        return val1 + val2;
    if( op == '-' )
        return val1 - val2;
    if( op == '*' )
        return val1 * val2;
    if( op == '/' )
        return val1 / val2;
    return 0;
}

void Rezolvare_exp( char s[] )
{
    int i;
    n = strlen(s + 1);
    for( i=1; i<=n; i++ )
    {
        if( isdigit( s[i] ) )
        {
            int nr = 0;
            while( isdigit( s[i] ) )
                nr = nr * 10 + ( s[i] - '0' ), i++;
            i--;
            values.push( nr );
            continue;
        }
        if( s[i] == '(' )
        {
            ops.push( s[i] );
            continue;
        }
        if( s[i] == ')' )
        {
            while( !ops.empty() && ops.top() != '(' )
            {
                int val1, val2;
                val2 = values.top();
                values.pop();
                val1 = values.top();
                values.pop();
                char op;
                op = ops.top();
                ops.pop();
                values.push( rez( val1, val2, op ) );
            }
            ops.pop();
            continue;
        }
        if( s[i] == '+' || s[i] == '-' || s[i] == '*' || s[i] == '/' )
        {
            while( !ops.empty() && prec[ ops.top() ] >= prec[ s[i] ] )
            {
                int val1, val2;
                val2 = values.top();
                values.pop();
                val1 = values.top();
                values.pop();
                char op;
                op = ops.top();
                ops.pop();
                values.push( rez( val1, val2, op ) );
            }
            ops.push( s[i] );
        }
    }
    while( !ops.empty() )
    {
        int val1, val2;
        val2 = values.top();
        values.pop();
        val1 = values.top();
        values.pop();
        char op;
        op = ops.top();
        ops.pop();
        values.push( rez( val1, val2, op ) );
    }

    fout << values.top();
}

void Functia( char s[], char t[] )
{
    cout << s + 1 << "\n";
    int i, j;
    for( i=1; t[i]; i++ )
        t[i] = 0;
    int parametru = 1;
    map< char, string > valori;
    for( i=3; s[i]; i++ )
    {
        if( s[i] == ',' )
        {
            parametru++;
            continue;
        }
        if( isdigit( s[i] ) )
        {
            string nr = "";
            while( isdigit( s[i] ) )
                nr += s[i], i++;
            i--;
            cout << nr << "\n";
            valori[ fc[ s[1] ].first[parametru - 1] ] = nr;
            continue;
        }
        if( s[i] >= 'a' && s[i] <= 'z' )
        {
            cout << s[i] << "\n";
            valori[ fc[ s[1] ].first[parametru - 1] ] = val[ s[i] ];
            continue;
        }
        if( s[i] >= 'A' && s[i] <= 'Z' )
        {
            char aux[N];
            int m = 0;
            int p = 0;
            for( j = i + 1; s[j]; j++ )
            {
                if( s[j] == '(' ) p++;
                if( s[j] == ')' ) p--;
                if( p == 0 ) break;
            }
            for( int k = i; k<=j; k++ )
                aux[++m] = s[k];
            i = j;
            char exp[N];
            Functia( aux, exp );
            string w = "";
            m = 1;
            while( exp[m] )
                w += exp[m++];
            valori[ fc[ s[1] ].first[parametru - 1] ] = w;
        }
    }

    int m = 0;
    for( i=0; i < fc[ s[1] ].second.size(); i++ )
    {
        if( isalpha( fc[ s[1] ].second[i] ) )
        {
            char parametru = fc[ s[1] ].second[i];
            t[++m] = '(';
            for( j=0; j<valori[parametru].size(); j++ )
                t[++m] = valori[parametru][j];
            t[++m] = ')';
        }
        else
        {
            t[++m] = fc[ s[1] ].second[i];
        }
    }
}

void Rezolvare()
{
    int i;
    Functia( s, t );
    cout << t + 1;
    Rezolvare_exp( t );
}

int main()
{
    Citire();
    Rezolvare();
    //cout << sizeof( Lee ) / 1024.0 / 1024.0;
    return 0;
}
