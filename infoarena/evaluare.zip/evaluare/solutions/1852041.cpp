#include <bits/stdc++.h>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char sir[100010], *p=sir;
long termen();
long factor();
long eval() {
    long r = termen();
    while ( *p=='+' || *p=='-' ) {
        if(*p == '+') p++, r += termen();
        else if(*p == '-') p++, r -= termen();
    }
    return r;
}
long termen() {
    long r = factor();
    while ( *p=='*' || *p=='/' ) {
        if(*p == '*') p++, r *= factor();
            else if(*p == '/') p++, r /= factor();
    }
    return r;
}
long factor() {
    long r=0;
    if ( *p == '(' ) {
        p++;
        r = eval();
        p++;
    } else {
        while ( *p>='0' && *p<='9' )  {
            r = r*10 + *p - '0';
            p++;
        }
    }
    return r;
}

int main() {
    fin.getline(sir,100010);
    fout<<eval();
    return 0;
}
