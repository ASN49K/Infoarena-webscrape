#include <bits/stdc++.h>

using namespace std;

string expr;
stack<char> op;
stack<long> val;

long op_priority(char op) {
	if (op == '*' || op == '/')
		return 1;
	if (op == '+' || op == '-')
		return 0;
	return -1;
}

long eval(long a, long b, char op) {
	long c;
	switch(op) {
		case '+':
			c = a + b;
			break;
		case '-':
			c = a - b;
			break;
		case '*':
			c = a * b;
			break;
		case '/':
			c = a / b;
			break;
		default:
			c = -1;
	}

	return c;
}

void eval_expr() {
	long b = val.top();
	val.pop();
	long a = val.top();
	val.pop();

	val.push(eval(a, b, op.top()));

	cout << a << op.top() << b << '=' << val.top() << '\n';

	op.pop();
}

int main() {
	freopen("evaluare.in", "r", stdin);
	freopen("evaluare.out", "w", stdout);

	cin >> expr;

	for (int i = 0; i < expr.length(); ++ i) {
		char token = expr[i];

		if (expr[i] >= '0' && expr[i] <= '9') {
			string num;
			while (expr[i] >= '0' && expr[i] <= '9') {
				num.push_back(expr[i]);
				++ i;
			}
			-- i;
			num.push_back('\0');
			val.push(atoi(num.c_str()));
		} else if (token == '(') {
			op.push(token);
		} else if (token == ')') {
			while (op.top() != '(') eval_expr();
			op.pop();
		} else {
			while (!op.empty() && op_priority(op.top()) >= op_priority(token)) {
				eval_expr();
			}
			op.push(token);
		}
	}

	cout << op.size() << ' ' << val.size() << '\n';

	// while (op.size()) {
	// 	cout << op.top() << ' ';
	// 	op.pop();
	// }
	// cout << '\n';

	// while (val.size()) {
	// 	cout << val.top() << ' ';
	// 	val.pop();
	// }
	// cout << '\n';


	while (!op.empty()) {
		eval_expr();
	}

	cout << val.top() << '\n';


	return 0;
}