#include <bits/stdc++.h>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
string s;

stack <int> s_nr, s_nr_inv;
stack <char> s_op, s_op_inv;

int solve(int &i) {

    stack <int> s_nr2, s_nr_inv2;
    stack <char> s_op2, s_op_inv2;

    ++i;
    while (s[i] != ')') {
        int x = 0;
        if( i < s.size() && s[i] == '(' ) {
           x = solve(i);
        }
        else {
            while (s[i] != ')' && s[i] >= '0' && s[i] <= '9') {
                x = x*10 + (int)(s[i]-'0');
                i++;
            }
        }
            if(!s_op2.empty()) {
                char op = s_op2.top();

                if (op=='*') {
                    int y = s_nr2.top();
                    s_nr2.pop();
                    s_op2.pop();

                    s_nr2.push( x*y );
                }
                if (op=='/') {
                    int y = s_nr2.top();
                    s_nr2.pop();
                    s_op2.pop();

                    s_nr2.push( y/x );
                }
                if (op=='+' || op=='-') {
                    s_nr2.push(x);
                }
            }
            else {
                s_nr2.push(x);
            }

            if(s[i] != ')') {
                s_op2.push((char)s[i]);
                ++i;
            }
    }
    ++i;

    while (!s_nr2.empty()) {
        s_nr_inv2.push( s_nr2.top() );
        s_nr2.pop();
    }

    while (!s_op2.empty()) {
        s_op_inv2.push( s_op2.top() );
        s_op2.pop();
    }

    if(!s_op_inv2.empty()) {

        while(!s_op_inv2.empty()) {
            int x = s_nr_inv2.top();
            s_nr_inv2.pop();
            int y = s_nr_inv2.top();
            s_nr_inv2.pop();

            char op = s_op_inv2.top();
            s_op_inv2.pop();

            if (op == '+') {
                s_nr_inv2.push(x+y);
            }
            if (op == '-') {
                s_nr_inv2.push(x-y);
            }
        }
    }

    return s_nr_inv2.top();

}

int main()
{
    f >> s;

    int i=0;
    while (i<s.size()) {
        int x = 0;
        if( i < s.size() && s[i] == '(' ) {
           x = solve(i);
        }
        else {

            while (i<s.size() && s[i] >= '0' && s[i] <= '9') {
                x = x*10 + (int)(s[i]-'0');
                ++i;
            }
        }

        if(!s_op.empty()) {
            char op = s_op.top();

            if (op=='*') {
                int y = s_nr.top();
                s_nr.pop();
                s_op.pop();

                s_nr.push( x*y );
            }
            if (op=='/') {
                int y = s_nr.top();
                s_nr.pop();
                s_op.pop();

                s_nr.push( y/x );
            }
            if (op=='+' || op=='-') {
                s_nr.push(x);
            }
        }
        else {
            s_nr.push(x);
        }

        if(i < s.size() && s[i] != '(' && s[i] != ')') {
            s_op.push((char)s[i]);
        }
        i++;
    }

    while (!s_nr.empty()) {
        s_nr_inv.push( s_nr.top() );
        s_nr.pop();
    }

     while (!s_op.empty()) {
        s_op_inv.push( s_op.top() );
        s_op.pop();
    }

    while(!s_op_inv.empty()) {
        int x = s_nr_inv.top();
        s_nr_inv.pop();
        int y = s_nr_inv.top();
        s_nr_inv.pop();

        char op = s_op_inv.top();
        s_op_inv.pop();

        if (op == '+') {
            s_nr_inv.push(x+y);
        }
        if (op == '-') {
            s_nr_inv.push(x-y);
        }
    }

    g << s_nr_inv.top();
    return 0;
}
