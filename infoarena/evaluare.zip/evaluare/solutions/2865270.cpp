#include <cstdio>
#include <algorithm>
#include <vector>
#include <queue>
#include <set>
#include <map>
#include <cstring>
#include <climits>
#define NMAX 50003
using namespace std;

int n,nivOp=0,nivNum=0;
char stivOp[NMAX],s[NMAX];
int stivNum[NMAX];

FILE *fin,*fout;

int calc(int a,int b,char op)
{
    if(op=='+')
    {
        return a+b;
    }
    else if(op=='-')
    {
        return a-b;
    }
    else if(op=='*')
    {
        return a*b;
    }
    else if(op=='/')
    {
        return a/b;
    }
    return 0;
}

int rang(char ch)
{
    if(ch=='+' || ch=='-')
    {
        return 1;
    }
    else if(ch=='*' || ch=='/')
    {
        return 2;
    }
    return 0;
}

int main()
{

    fin=fopen("evaluare.in","r");
    fout=fopen("evaluare.out","w");

    fgets(s,NMAX,fin);
    n=strlen(s)-1;
    for(int i=0; i<=n; i++)
    {
        char ch=s[i];
        if(ch=='(')
        {
            stivOp[++nivOp]='(';
        }
        else if(ch==')')
        {
            //caut pana dau de caracterul (
            while(nivOp>0 && stivOp[nivOp]!='(')
            {
                int rez=calc(stivNum[nivNum-1],stivNum[nivNum],stivOp[nivOp]);
                stivNum[--nivNum]=rez;
                nivOp--;
            }
            nivOp--;    
            
        }
        else{
            if(ch>='0' && ch<='9')
            {
                //e num
                int val=ch-'0';
                int j=i+1;
                while(s[j]>='0' && s[j]<='9' && j<=n)
                {
                    val=val*10+s[j]-'0';
                    j++;
                }
                i=j-1;
                stivNum[++nivNum]=val;
            }
            else{
                //e operator
                while(nivOp>0 && rang(ch)<rang(stivOp[nivOp]))
                {
                    int rez=calc(stivNum[nivNum-1],stivNum[nivNum],stivOp[nivOp]);
                    stivNum[--nivNum]=rez;
                    nivOp--;
                }
                stivOp[++nivOp]=ch;
            }
        }
    }
    while(nivOp>0)
    {
        int rez=calc(stivNum[nivNum-1],stivNum[nivNum],stivOp[nivOp]);
        stivNum[--nivNum]=rez;
        nivOp--;
    }
    fprintf(fout,"%d",stivNum[1]);
    return 0;
}