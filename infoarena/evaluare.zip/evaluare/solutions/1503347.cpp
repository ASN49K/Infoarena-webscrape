#include <cstdio>
#include <fstream>
#include <stack>
#include <cstring>
#include <iostream>
using namespace std;

stack <char> car;
stack <int> num;
char s[100010];

void math()
{
    int a=num.top();
    num.pop();
    int b=num.top();
    num.pop();

    if(car.top()=='+')
        num.push(b+a);
    if(car.top()=='-')
        num.push(b-a);
    if(car.top()=='*')
        num.push(b*a);
    if(car.top()=='/')
        num.push(b/a);
    car.pop();
}

void rez()
{
    int a;
    int l=strlen(s);
    for(int i=0; i<l; i++)
    {
        a=0;
        if(s[i]=='(')
            car.push(s[i]);
        else if(s[i]=='*'||s[i]=='/')
        {
            if(car.top()=='*'||car.top()=='/')
                math();

            car.push(s[i]);

        }

        else if(s[i]=='+'||s[i]=='-')
        {
            if(car.top()!='(')
                math();
            car.push(s[i]);

        }
        else if(s[i]==')')
        {
            while(car.top()!='(')
                math();

            car.pop();
        }
        else
        {
            while(isdigit(s[i]))
            {
                a=a*10+(s[i]-'0');
                i++;
            }
            i--;
            num.push(a);

        }

    }


}

int main()
{
    FILE *f=fopen("evaluare.in","r");
    fscanf(f,"%s",s);
    s[strlen(s)]=')';
    s[strlen(s)+1]=0;
    car.push('(');
    rez();
    f=fopen("evaluare.out","w");
    fprintf(f,"%d",num.top());

    return 0;
}
