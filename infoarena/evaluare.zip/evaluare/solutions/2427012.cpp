#include <bits/stdc++.h>

#define Nmax 100000

using namespace std;

ifstream fin ("evaluare.in");
ofstream fout ("evaluare.out");

char S[1 + Nmax + 5];
int index = 0;

int math ();

int fact ()
{
    int integer = 0, sign = 1;
    if (S[index] == '-')
        ++index, sign = -1;
    if (S[index] == '(')
    {
        ++index;
        integer = math ();
        ++index;
    }
    else while (isdigit (S[index]))
            integer = integer * 10 + S[index] - '0', ++index;
    return sign * integer;
}

int term ()
{
    int sum = fact ();
    while (S[index] == '*' || S[index] == '/')
        if (S[index++] == '*')
            sum *= fact ();
        else
            sum /= fact ();
    return sum;
}

int math ()
{
    int sum = term ();
    while (S[index] == '+' || S[index] == '-')
        if (S[index++] == '+')
            sum += term ();
        else
            sum -= term ();
    return sum;
}

int main()
{
    fin >> S;
    fout << math ();
    return 0;
}
