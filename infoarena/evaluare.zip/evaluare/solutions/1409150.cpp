#include <cstdio>
#include <cctype>
#define NMAX 100005

using namespace std;

char s[NMAX], *p = s;
int termen(), factor();

int eval(){
    int r = termen();
    while(*p == '+' || *p == '-')
        if(*p == '+'){
            ++p;
            r += termen();
        }else if(*p == '-'){
            ++p;
            r -= termen();
        }
    return r;
}

int termen(){
    int r = factor();
    while(*p == '*' || *p == '/'){
        if(*p == '*'){
            ++p;
            r *= factor();
        }else if(*p == '/'){
            ++p;
            r /= factor();
        }
    }
    return r;
}

int factor(){
    int r = 0;
    if(*p == '('){
       ++p;
       r = eval();
       ++p;
    }else{
        while(isdigit(*p)){
            r = r * 10 + *p - '0';
            ++p;
        }
    }
    return r;
}

int main(){
    freopen("evaluare.in", "r", stdin);
    freopen("evaluare.out", "w", stdout);
    scanf("%s", s);
    printf("%d\n", eval());
    return 0;
}
