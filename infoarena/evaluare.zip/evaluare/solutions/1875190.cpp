#include <bits/stdc++.h>
using namespace std;
int i;
char s[100009];
int factor();
int suma();
int termen();
int factor()
{
    int sum,term;
    if(s[i]=='(')
    {
        i++;
        sum=suma();
        i++;
        return sum;
    }
    term=0;
    while(s[i]>='0'&&s[i]<='9')
    {
        term=term*10+s[i]-48;
        i++;
    }
    return term;
}
int suma()
{
    int nr;
    nr=termen();
    while(s[i]=='+'||s[i]=='-')
    {
        if(s[i]=='+')
        {
            i++;
            nr+=termen();
        }
        else
        {
            i++;
            nr-=termen();
        }
    }
    return nr;
}
int termen()
{
    int nr;
    nr=factor();
    while(s[i]=='/'||s[i]=='*')
    {
        if(s[i]=='/')
        {
            i++;
            nr/=factor();
        }
        else
        {
            i++;
            nr*=factor();
        }
    }
    return nr;
}
int main()
{
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);
    gets(s+1);
    i=1;
    printf("%d\n",suma());
    return 0;
}
