#include <fstream>
#include <cstring>
using namespace std;

ifstream f("evaluare.in");
ofstream g("evaluare.out");
char s[100013],*p;
int n;

int eval();
int termen();
int factor();
int main()
{
    f.get(s,100000);
    p=s;
    n=eval();
    g<<n;
}
int eval()
{
    int r;
    r=termen();
    while(*p=='+'||*p=='-')
    {
        if(*p='+')
        {
            ++p;
            r+=termen();
        }
        if(*p='-')
        {
            ++p;
            r-=termen();
        }
    }
    return r;
}
int termen()
{
    int r,x;
    r=factor();
    while(*p=='*'||*p=='/')
    {
        if(*p='*')
        {
            ++p;
            r*=factor();
        }
        if(*p='/')
        {
            ++p;
            x=factor();
            if(x!=0)
            r/=x;
        }
    }
    return r;
}
int factor()
{
    int r;
    r=0;
    if(*p='(')
    {
        ++p;
        r=eval();
        ++p;
    }
    else
    {
        while('0'<=*p && *p<='9')
        {
            r*=10;
            r+=(int)*p-'0';
            ++p;
        }
    }
    return r;
}






