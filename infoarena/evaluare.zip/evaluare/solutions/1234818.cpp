#include <fstream>
#include <stack>
#include <cctype>
#include <string>
#include <iostream>
	
enum State{Op, Number};
long long CompMult(std::stack<long long>&nums, std::stack<char>& ops)
{
	char op = ops.top();
	ops.pop();
	long long a, b = nums.top();
	nums.pop();
	if (!ops.empty() && (ops.top() == '*' || ops.top() == '/'))
		a = CompMult(nums, ops);
	else{
		a = nums.top();
		nums.pop();
	}
	if (op == '*')
		return a * b;
	return a / b;
}
long long Compute(const char* expr) 
{
	std::stack<long long> nums;
	std::stack<char> ops;
	State s = Number;
	while (*expr) {
		if (s == Number) {
			if (*expr == '(') {
				ops.push(*expr);
				++expr;
			}
			else if (*expr != ')'){
				long long num = 0;
				while (std::isdigit(*expr)) {
					num = (num * 10) + (*expr) - '0';
					expr++;
				}
				nums.push(num);
				if (!ops.empty() && (ops.top() == '*' || ops.top() == '/')) {
					num = CompMult(nums, ops);
					nums.push(num);
				}
				s = Op;
			}
		}
		else if (*expr != ')'){
			ops.push(*expr);
			++expr;
			s = Number;
		}
		if (*expr == ')') {
				while (ops.top() != '(') {
					long long a, b, c;
					b = nums.top();
					nums.pop();
					a = nums.top();
					nums.pop();
					if (ops.top() == '+')
						c = a + b;
					else
						c = a - b;
					nums.push(c);
					ops.pop();
				}
				ops.pop();
				s = Op;
				++expr;
		}
	}
	if (!ops.empty() && (ops.top() == '*' || ops.top() == '/')) {
		long long c = CompMult(nums, ops);
		nums.push(c);
	}
	while (!ops.empty()) {
		long long a, b, c;
		b = nums.top();
		nums.pop();
		a = nums.top();
		nums.pop();
		if (ops.top() == '+')
			c = a + b;
		else
			c = a - b;
		nums.push(c);
		ops.pop();
	}
	return nums.top();
}

int main()
{
	std::ifstream f("evaluare.in");
	std::ofstream g("evaluare.out");
	std::string s;
	f >> s;
	g << Compute(s.c_str()) << "\n";
	f.close();
	g.close();
	return 0;
}