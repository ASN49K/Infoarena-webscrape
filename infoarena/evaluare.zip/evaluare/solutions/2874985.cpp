#include <bits/stdc++.h>
using namespace std;

ifstream f("evaluare.in");
ofstream g("evaluare.out");
// #define f cin
// #define g cout
struct mdata
{
    int type; //0-op
              //1-nr
              //2-(
    int nr;
    char op;
};
vector<mdata> s;
int32_t main()
{
    s.push_back({0, 0, '+'});
    for (char ch; f >> ch;)
    {
        // for (auto i : s)
        //     if (i.type == 0)
        //         g << i.op << ' ';
        //     else if (i.type == 1)
        //         g << i.nr << ' ';
        //     else
        //         g << "( ";
        // g << '\n';
        if (isdigit(ch))
        {
            if (s.back().type != 1)
                s.push_back({1, 0, 0});
            s.back().nr = s.back().nr * 10 + ch - '0';
        }
        else if (ch == '(')
            s.push_back({2, 0, 0});
        else if (ch == '+' || ch == '-')
        {
            if (s.size() > 3 && s.end()[-1].type == 1 && s.end()[-2].type == 0 && s.end()[-3].type == 1)
            {
                int n1 = s.end()[-3].nr, n2 = s.end()[-1].nr, op = s.end()[-2].op;
                cout << n1 << char(op) << n2 << '\n';
                if (op == '+')
                    n1 += n2;
                else if (op == '-')
                    n1 -= n2;
                else if (op == '*')
                    n1 *= n2;
                else
                    n1 /= n2;
                s.pop_back();
                s.pop_back();
                s.pop_back();
                s.push_back({1, n1, 0});
            }
            s.push_back({0, 0, ch});
        }
        else if (ch == '*' || ch == '/')
        {
            if (s.size() > 3 && s.end()[-1].type == 1 && (s.end()[-2].op == '*' || s.end()[-2].op == '/') && s.end()[-3].type == 1)
            {
                int n1 = s.end()[-3].nr, n2 = s.end()[-1].nr, op = s.end()[-2].op;
                if (op == '+')
                    n1 += n2;
                else if (op == '-')
                    n1 -= n2;
                else if (op == '*')
                    n1 *= n2;
                else
                    n1 /= n2;
                s.pop_back();
                s.pop_back();
                s.pop_back();
                s.push_back({1, n1, 0});
            }
            s.push_back({0, 0, ch});
        }
        else
        {
            while (s.end()[-2].type != 2)
            {
                int n1 = s.end()[-3].nr, n2 = s.end()[-1].nr, op = s.end()[-2].op;
                if (op == '+')
                    n1 += n2;
                else if (op == '-')
                    n1 -= n2;
                else if (op == '*')
                    n1 *= n2;
                else
                    n1 /= n2;
                s.pop_back();
                s.pop_back();
                s.pop_back();
                s.push_back({1, n1, 0});
            }

            auto ac = s.back();
            s.pop_back();
            s.pop_back();
            s.push_back(ac);
        }
    }
    while (s.size() > 3)
    {
        int n1 = s.end()[-3].nr, n2 = s.end()[-1].nr, op = s.end()[-2].op;
        if (op == '+')
            n1 += n2;
        else if (op == '-')
            n1 -= n2;
        else if (op == '*')
            n1 *= n2;
        else
            n1 /= n2;
        s.pop_back();
        s.pop_back();
        s.pop_back();
        s.push_back({1, n1, 0});
    }
    g << s.back().nr;
    return 0;
}
