#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;
find

main()
{
    debug("da");
}
