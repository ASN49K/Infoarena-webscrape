#include<fstream>
using namespace std;
ifstream cin("evaluare.in");
ofstream cout("evaluare.out");
char c;
int A(int l)
{
    int r;
    if(!l)
        for(r=A(1);c=='+'||c=='-';c=='+'?cin>>c,r+=A(1):(cin>>c,r-=A(1)));
    else if(l==1)
        for(r=A(2);c=='*'||c=='/';c=='*'?cin>>c,r*=A(2):(cin>>c,r/=A(2)));
    else if(c=='(')
        cin>>c,r=A(0),cin>>c;
    else
        for(r=0;c>47&&c<58;r=r*10+c-48,cin>>c);
    return r;
}
int main()
{
    return cin>>c,cout<<A(0),0;
}
