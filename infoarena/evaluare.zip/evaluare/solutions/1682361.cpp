#include <fstream>

using namespace std;
char s[100005],*p=s;

ifstream in("evaluare.in");
ofstream out("evaluare.out");

int term();
int fact();
int eval()
{
    int nr=term();
    while(*p=='+' || *p=='-')
    {
        if(*p=='+')
        {
            p++; nr+=term();
        }
        if(*p=='-')
        {
            p++; nr-=term();
        }
    }
    return nr;
}

int term()
{
    int nr=fact();
    while(*p=='*' || *p=='/')
    {
        if(*p=='*')
        {
            p++; nr*=fact();
        }
        if(*p=='/')
        {
            p++; nr/=fact();
        }
    }
    return nr;
}

int fact()
{
    int nr=0;
    if(*p=='(')
    {
        p++; nr=eval(); p++;
    }
    while(*p>='0' && *p<='9')
    {
        nr*=10; nr+=*p-'0'; p++;
    }
    return nr;
}

int main()
{
    in.getline(s,100004);
    out<<eval()<<'\n';
    return 0;
}
