#include <iostream>
#include <fstream>
using namespace std;

ifstream f("evaluare.in");
ofstream g("evaluare.out");

string expresie;

int get_expresie_val(int &ind);
int get_term(int &ind);
int get_factor(int &ind);
int get_number(int &ind);

int main()
{
    f>>expresie;
    int indice=0;
    g<<get_expresie_val(indice);
    return 0;
}

int get_expresie_val(int &ind)
{
    int res=get_term(ind);
    while(expresie[ind]=='+' || expresie[ind]=='-')
    {
        ind++;
        if(expresie[ind-1]=='+')
            res+=get_term(ind);
        else
            res-=get_term(ind);
    }
    return res;
}

int get_term(int &ind)
{
    int res=get_factor(ind);
    while(expresie[ind]=='*' || expresie[ind]=='/')
    {
        ind++;
        if(expresie[ind-1]=='*')
            res=res*get_factor(ind);
        else
            res=res/get_factor(ind);
    }
    return res;
}

int get_factor(int &ind)
{
    if(expresie[ind]!='(')
        return get_number(ind);
    else
    {
        ind++;
        int res=get_expresie_val(ind);
        ind++;
        return res;
    }
}

int get_number(int &ind)
{
    int nr=0;
    while(isdigit(expresie[ind]))
    {
        nr=nr*10+(expresie[ind]-'0');
        ind++;
    }
    return nr;
}
