#include <iostream>
#include <fstream>
#include <cstring>
#include <stack>

using namespace std;
ifstream in("evaluare.in");
ofstream out("evaluare.out");

#define ll long long
const int strMax = 2e6 + 5;
#define mod 9973

int N;
char str[strMax],*p = str;

struct nodArb {
    int nr;
    char op;
    nodArb *st,*dr;
    nodArb (int _nr = 0,char _op = '\0',nodArb *_st = 0,nodArb *_dr = 0) {
        nr = _nr;
        op = _op;
        st = _st;
        dr = _dr;
    }
};

nodArb *eval();
nodArb *termen();
nodArb *factor();
int compute(nodArb*);

int main() {
    in>>str;
    nodArb *root = eval();
    out<<compute(root)<<'\n';


    in.close();out.close();
    return 0;
}

nodArb *eval() {
    nodArb *ans = termen();
    while (*p == '+' || *p == '-') {
        switch (*p++) {
        case '+': ans = new nodArb(0,'+',ans,termen()); break;
        case '-': ans = new nodArb(0,'-',ans,termen()); break;
        }
    }
    return ans;
}

nodArb *termen() {
    nodArb *ans = factor();
    while (*p == '*' || *p == '/') {
        switch (*p++) {
        case '*': ans = new nodArb(0,'*',ans,factor()); break;
        case '/': ans = new nodArb(0,'/',ans,factor()); break;
        }
    }
    return ans;
}

nodArb *factor() {
    nodArb *ans = 0;
    if ('0' <= *p && *p <= '9') {
        int nr = 0;
        while ('0' <= *p && *p <= '9') {
            nr = nr * 10 + *p++ - '0';
        }
        ans = new nodArb(nr);
    }
    else {
        ++p;
        ans = eval();
        ++p;
    }
    return ans;
}

int compute(nodArb* nod) {

    switch (nod -> op) {
    case '+': return compute(nod -> st) + compute(nod -> dr);
    case '-': return compute(nod -> st) - compute(nod -> dr);
    case '*': return compute(nod -> st) * compute(nod -> dr);
    case '/': return compute(nod -> st) / compute(nod -> dr);
    default: return nod -> nr;
    }
}
