#include <cstdio>

#define NMAX 100003

using namespace std;

int i;
char s[NMAX];

int unu();
int doi();
int trei();

int trei()
{
    int rez = 0;

    if(s[i] == '(')
    {
        ++ i;
        rez = unu();
        ++ i;
    }
    else
    {
        while(s[i] >= '0' && s[i] <= '9')
        {
            rez = rez * 10 + s[i] - '0';
            ++ i;
        }
    }

    return rez;
}

int doi()
{
    int rez = trei();

    while(s[i] == '*' || s[i] == '/')
    {
        ++ i;

        if(s[i - 1] == '*')
            rez *= trei();
        else
            rez /= trei();
    }

    return rez;
}

int unu()
{
    int rez = doi();

    while(s[i] == '+' || s[i] == '-')
    {
        ++ i;

        if(s[i - 1] == '+')
            rez += doi();
        else
            rez -= doi();
    }

    return rez;
}

int main()
{
    freopen("evaluare.in", "r", stdin);
    freopen("evaluare.out", "w", stdout);

    fgets(s, NMAX, stdin);

    printf("%d\n", unu());

    return 0;
}
