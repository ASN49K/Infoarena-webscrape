#include<fstream>

using namespace std;

//int prim(int x); // definesc doar prototipul(antetul functiei)

int expresie();
int termen();
int factor();

char s[100090];
int i;

int expresie() {
	int r = termen();
	while (s[i] == '+' || s[i] == '-') {
		if (s[i] == '+') {
			i++;
			r = r + termen();
		} else {
			i++;
			r = r - termen();
		}
	}
	return r;
}

int termen() {
	int r = factor();
	while (s[i] == '*' || s[i] == '/') {
		if (s[i] == '*') {
			i++;
			r*=factor();
		} else {
			i++;
			r /= factor();
		}
	}
	return r;
}

int factor() {
	int r;
	if (s[i] == '(') {
		i++;
		r = expresie();
		i++;
	} else {
		r = 0;
		while (s[i] >= '0' && s[i] <= '9') {
			r = r * 10 + s[i] - '0';
			i++;
		}
	}
	return r;
}

int main()
{
	ifstream f("evaluare.in");
	ofstream g("evaluare.out");
	f.get(s,100090);
	g<<expresie();
}


int prim(int x) {
	for (int i=2;i*i<=x;i++)
		if(x%i == 0)
			return 0;
	return 1;
}
	