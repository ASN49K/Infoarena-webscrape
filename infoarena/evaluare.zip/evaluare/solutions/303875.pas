var   f,g:text;
      i,cod,x:longint;
      c:array[1..100001] of char;


function  suma(poz:longint):longint;forward;
function  produs(poz:longint):longint;forward;


function   suma(poz:longint):longint;
var     ok:boolean;
        termen:longint;
begin
 ok:=true;
 i:=poz;
 if c[i]='-' then begin
  inc(i);
  ok:=false;
 end;
 suma:=0;
 while c[i]<>')' do begin
  if (c[i]='+') or (c[i]='-') then begin
   if ok then suma:=suma+termen
         else suma:=suma-termen;
   if c[i]='+' then ok:=true
               else ok:=false;
   inc(i);
  end
  else termen:=produs(i);
 end;
 if c[i]=')' then inc(i);
 if ok then suma:=suma+termen
       else suma:=suma-termen;
end;


function   produs(poz:longint):longint;
var   ok:boolean;
      factor:longint;
      fact:string;
begin
produs:=1;
fact:='';factor:=-1;
i:=poz;
ok:=true;
while (c[i]<>'+') and (c[i]<>'-') and (c[i]<>')') do begin
 if c[i]='(' then factor:=suma(i+1)
             else if (c[i]='*') or (c[i]='/') then begin
              if factor=-1 then val(fact,factor,cod);
              fact:='';
              if ok then produs:=produs*factor
                    else produs:=produs div factor;
              if c[i]='*' then ok:=true
                               else ok:=false;
              inc(i);
              factor:=-1;
             end
             else begin
              fact:=fact+c[i];
              inc(i);
             end;
end;
if factor=-1 then val(fact,factor,cod);
if ok then produs:=produs*factor
      else produs:=produs div factor;
end;





begin
assign (f,'evaluare.in');reset(f);
assign (g,'evaluare.out');rewrite (g);
i:=0;
while not eof(f) do begin
 inc(i);
 read (f,c[i]);
end;
c[i+1]:=')';
x:=suma(1);
writeln (g,x);
close(f);
close(g);
end.
















