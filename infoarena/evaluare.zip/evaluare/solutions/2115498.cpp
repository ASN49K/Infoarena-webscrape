#include <bits/stdc++.h>
#define LMAX 100000

using namespace std;
ifstream fi("evaluare.in");
ofstream fo("evaluare.out");
char C[LMAX+10];
int n, nr, cif, a, b, rez;
stack <char> OPS;
stack <int> VAL;

bool eCifra(char c)
{
    return (c>='0' && c<='9');
}

bool eSemn(char c)
{
    return (c=='+' || c=='-' || c=='*' || c=='/');
}

bool arePrecedent(char op1, char op2)
/// returneaza 1 daca op1 are precedent, adica daca ordinul lui op1 <= ordinul lui op2
{
    if(op2=='(' || op2==')')
        return 0;
    if((op1=='*' || op1=='/') && (op2=='+' || op2=='-'))
        return 0;
    return 1;
}

int operatie(int a, int b, char c)
{
    switch(c)
    {
    case '+':
        return a+b;
        break;
    case '-':
        return a-b;
        break;
    case '*':
        return a*b;
        break;
    case '/':
        return a/b;
    }
}

int main()
{
    fi>>C+1;
    n=strlen(C+1);
    for(int i=1; i<=n; i++)
    {
        if(eCifra(C[i]))
        {
            cif=C[i]-'0';
            nr=nr*10+cif;
        }
        else
        {
            if(nr!=0)
            {
                VAL.push(nr);
                nr=0;
            }
            if(C[i]=='(')
               OPS.push(C[i]);
            else
            {
                if(C[i]==')')
                {
                    while(OPS.top()!='(')
                    {
                        b=VAL.top();
                        VAL.pop();
                        a=VAL.top();
                        VAL.pop();
                        rez=operatie(a, b, OPS.top());
                        OPS.pop();
                        VAL.push(rez);
                    }
                    OPS.pop();
                }
                else
                {
                    if(eSemn(C[i]))
                    {
                        while(!OPS.empty() && arePrecedent(C[i], OPS.top()))
                        {
                            b=VAL.top();
                            VAL.pop();
                            a=VAL.top();
                            VAL.pop();
                            rez=operatie(a, b, OPS.top());
                            OPS.pop();
                            VAL.push(rez);
                        }
                        OPS.push(C[i]);
                    }
                }
            }
        }
    }
    if(nr!=0)
        VAL.push(nr);
    while(!OPS.empty())
    {
        b=VAL.top();
        VAL.pop();
        a=VAL.top();
        VAL.pop();
        rez=operatie(a, b, OPS.top());
        OPS.pop();
        VAL.push(rez);
    }
    fo<<VAL.top();
//    while(!VAL.empty())
//    {
//        fo<<VAL.top()<<" ";
//        VAL.pop();
//    }
    fi.close();
    fo.close();
    return 0;
}
