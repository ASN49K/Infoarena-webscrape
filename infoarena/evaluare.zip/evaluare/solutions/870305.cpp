#include <fstream>
using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int i;
string S;
int termen(), factor();

int eval() {
    int r = termen();
    while (S[i] == '+' || S[i] == '-') {
        if (S[i] == '+') {
            ++i;
            r += termen();
        }else {
            ++i;
            r -= termen();
        }
    }
    return r;
}

int termen() {
    int r = factor();
    while (S[i] == '*' || S[i] == '/') {
        if (S[i] == '*') {
            ++i;
            r *= factor();
        }else {
            ++i;
            r /= factor();
        }
    }
    return r;
}

int factor() {
    int r = 0;
    if (S[i] == '(') {
        ++i;
        r = eval();
        ++i;
    }else {
        while ('0' <= S[i] && S[i] <= '9') {
            r = r * 10 + S[i] - '0';
            ++i;
        }
    }
    return r;
}

int main() {
    getline(fin, S);
    fin.close();
    fout << eval();
    fout.close();
    return 0;
}
