#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int prioritate(char c)                 //functie care returneaza prioritatea operatorilor
{
    if(c=='('||c==')')return 0;
       else
         if(c=='+'||c=='-')return 1;
        else
            if(c=='*'||c=='/')return 2;
    return 0;
}
int main()
{
    char E[110003],FP[110003],S[110000], aux[4],sirnr[20],*p;
    int i,vf,nr,semn,S1[150000],R,k,l;
    FILE *f,*g;

    f=fopen("evaluare.in","r");
    g=fopen("evaluare.out","w");

    fscanf(f,"%s",E);             //citesc expresia care trebuie evaluata
    //fgets(E,100000,f);
    //puts(E);
    //E[strlen(E)-1]=0;

    strcpy(FP,"(");               //copiez in FP (
    strcat(FP,E);                 //concatenez E la FP
    strcat(FP,")");               //concatenez la FP )
    strcpy(E,FP);                 //copiez in E FP

    //puts(E);
    //strcpy(FP,"");
    FP[0]=0;  //forma poloneza postfixata (initial sirul vid)
    vf=0;            //varful stivei in care pastrez operatorii
    l=-1;
    for(i=0;E[i]!=0;i++)       //parcurg expresia
    {
        if(E[i]>='0' && E[i]<='9')   //daca am citit o cifra
        {
            //nr=0;
            if (E[i-1]=='-' && E[i-2]=='('&&i-2>=0) semn=-1; //verific daca in fata cifrei este -
                                                             //si in fata lui - (
                             else semn=1;                    //atunci semnul numarului este -
            k=0;  //in sirnr construiesc numarul
                  //k este indice in acest sir numarul construit
            if (semn==-1)
            {
                //sirnr[0]='-';  //adaug semnul minus
                //k++;
                l++;
                FP[l]='-';
            }
            while(E[i]>='0' && E[i]<='9') //cat timp E[i] este cifra
            {
               // nr=nr*10+E[i]-48;
               // sirnr[k]=E[i];            //se adauga in sirnr
               // k++;
               l++;
               FP[l]=E[i];
                i++;

            }
            //sirnr[k]=0;    //pun NULL la sfarsit (NULL=0)
            //nr=nr*semn;

            //itoa(nr,sirnr,10);
            //strcat(FP,sirnr);      //concatenez sirnr la FP
            //strcat(FP," ");        //si un spatiu
            l++;
            FP[l]=' ';
            i--;
           // puts(FP);
        }
         else
            if(E[i]=='+'||(E[i]=='-' &&E[i-1]!='(')||E[i]=='*'||E[i]=='/') //caracterul citit este operator
         {
             while(prioritate(S[vf])>=prioritate(E[i])) //cat timp prioritatea operatorului este <= cu cea
                                                        //a operatorului aflat in varful stivei
             {
                 //aux[0]=S[vf];          //adaug in FP operatorul si un spatiu
                 //aux[1]=' ';
                 //aux[2]=0;
                 //strcat(FP,aux);
                 l++;
                 FP[l]=S[vf];
                 l++;
                 FP[l]=' ';
                 vf--;
             }
             vf++;
             S[vf]=E[i];
         }
           else
             if(E[i]=='(')
                {
                    vf++;
                    S[vf]=E[i];  //adaug in stiva paranteza deschisa (
                }
               else
               if(E[i]==')')
                {
                   while(S[vf]!='(') //extrag din stiva toti operatorii pana la ) si ii adaug in FP urmati de cate un spatiu
                   {
                       //aux[0]=S[vf];
                       //aux[1]=' ';
                       //aux[2]=0;
                       //strcat(FP,aux);
                       l++;
                       FP[l]=S[vf];
                       l++;
                       FP[l]=' ';
                       vf--;
                   }
                   vf--;
                }
        //for(int j=1;j<=vf;j++)
            //printf("%c ",S[j]);
        //printf("\n");
        //printf("%d ",i);
    }
    //puts(FP);
    l++;
    FP[l]=0;
    p=strtok(FP," "); //in forma poloneza postfixata entitatile sunt separate prin spatiu
    vf=0;             //varful stivei in care calculez valoarea expresiei
    while(p!=NULL)
    {
        if(*p=='+' || (*p=='-' && *(p+1)==0) ||*p=='*' || *p=='/')
         {
             if(*p=='+') R=S1[vf]+S1[vf-1];
             if(*p=='-') R=S1[vf-1]-S1[vf];
             if(*p=='*') R=S1[vf]*S1[vf-1];
             if(*p=='/') R=S1[vf-1]/S1[vf];
             vf--;
             S1[vf]=R;  //pun in stiva rezultatul operatiei
         }
           else
           {
               vf++;
               S1[vf]=atoi(p);  //pun in stiva operandul
           }
        p=strtok(NULL," ");
    }
    fprintf(g,"%d\n",S1[1]);  //afisez rezultatul
    fclose(f);
    fclose(g);
    return 0;

}
