#include <iostream>
#include <fstream>
using namespace std;

char c[100005], *p = c;
long termen();
long factor();

long eval()
{
    long long int r;
    r = termen();
    while (*p == '+' or *p == '-')
    {
        if (*p == '+')
        {
            ++p;
            r += termen();
            break;
        }
        else
        {
            ++p;
            r -= termen();
            break;
        }
    }
    return r;
}

long termen()
{
    long long int r;
    r = factor();
    while (*p == '*' or *p == '/')
    {
        if (*p == '*')
        {
            ++p;
            r *= factor();
            break;
        }
        else
        {
            ++p;
            r /= factor();
            break;
        }
    }
    return r;
}

long factor()
{
    long long int r = 0;
    if (*p == '(')
    {
        ++p;
        r = eval();
        ++p;
    }
    else
    {
        while (*p >= '0' and *p <= '9')
        {
            r = r * 10 + int(*p) - '0';
            ++p;
        }
    }
    return r;
}

int main()
{
    ifstream fin("evaluare.in");
    ofstream fout("evaluare.out");
    fin.getline(c, 100005);
    fout << eval();
    return 0;
}
