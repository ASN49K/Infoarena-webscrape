#include <iostream>
#include <fstream>
using namespace std;

ifstream fin ("evaluare.in");
ofstream fout ("evaluare.out");

string sir;

int eval (int &i);
int termen (int &i);
int factor (int &i);

int eval (int &i) {
    int ans = termen(i);
    while(sir[i] == '+' || sir[i] == '-') {
        if(sir[i] == '+') {
            i += 1;
            ans += termen(i);
        } else if(sir[i] == '-') {
            i += 1;
            ans -= termen(i);
        }
    }
    return ans;
}

int termen(int &i) {
    int ans = factor(i);
    while(sir[i] == '*' || sir[i] == '/') {
        if(sir[i] == '*') {
            i += 1;
            ans *= termen(i);
        } else if(sir[i] == '/') {
            i += 1;
            ans /= termen(i);
        }
    }
    return ans;
}

int factor(int &i) {
    int ans = 0;
    if(sir[i] == '(') {
        i += 1;
        ans = eval(i);
        i += 1;
    } else {
        while(isdigit(sir[i])) {
            ans = ans * 10 + (int)sir[i] - '0';
            i += 1;
        }
    }
    return ans;
}

int main()
{
    getline(fin, sir);
    int i = 0; fout << eval(i);
    return 0;
}
