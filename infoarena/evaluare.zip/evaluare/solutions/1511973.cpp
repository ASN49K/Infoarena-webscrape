#include <stdio.h>
#define maxn 100010
using namespace std;
 
char s[maxn];
int k = 0;
 
int eval();
int factor();
int termen();
 
 
 
int eval()
{
    int sol = termen();
 
    while(s[k] == '+' || s[k] == '-')
    {
        k++;
 
        if(s[k - 1] == '+')
            sol += termen();
        else
            sol -= termen();
    }
 
    return sol;
}
 
 
 
int termen()
{
    int sol = factor();
 
    while(s[k] == '*' || s[k] == '/')
    {
        k++;
 
        if(s[k - 1] == '*')
            sol *= factor();
        else
            sol /= factor();
 
    }
 
    return sol;
}
 
 
 
int factor()
{
    int sol = 0;
 
    if(s[k] == '(')
    {
        k++;
        sol = eval();
        k++;
    }
    else
        for(; s[k] >= '0' && s[k] <= '9'; k++)
            sol = sol * 10 + s[k] - '0';
 
    return sol;
}
 
 
 
 
int main()
{
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w", stdout);
 
    scanf("%s",s);
    printf("%d",eval());
 
    fclose(stdin);
    fclose(stdout);
 
    return 0;
}