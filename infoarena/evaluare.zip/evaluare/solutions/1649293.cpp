#include <stdio.h>
#include <cctype>
using namespace std;
char c;
int expresie();
int termen();
int factor();
int expresie()
{
    int raspuns = termen();
    while(c=='+' or c=='-')
    {
        if(c=='+')
        {
            c=fgetc(stdin);
            raspuns += termen();
        }
        if(c=='-')
        {
            c=fgetc(stdin);
            raspuns -= termen();
        }
    }
    return raspuns;
}
int termen()
{
    int raspuns = factor();
    while(c=='*' or c=='/')
    {
        if(c=='*')
        {
            c=fgetc(stdin);
            raspuns *= factor();
        }
        if(c=='/')
        {
            c=fgetc(stdin);
            raspuns /= factor();
        }
    }
    return raspuns;
}
int factor()
{
    int raspuns = 0, semn = 1;
    while(c=='-')
    {
        semn = -semn;
        c = fgetc(stdin);
    }
    while(c=='(')
    {
        c = fgetc(stdin);
        raspuns = expresie();
        c = fgetc(stdin);
        return semn*raspuns;
    }
    while(isdigit(c))
    {
        raspuns = raspuns*10 + c - '0';
        c=fgetc(stdin);
    }
    return semn*raspuns;
}
int main()
{
    freopen("evaluare.in", "r", stdin);
    freopen("evaluare.out", "w", stdout);
    c=fgetc(stdin);
    printf("%d\n", expresie());
    fclose(stdin);
    fclose(stdout);
    return 0;
}
