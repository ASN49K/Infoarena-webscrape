#include <fstream>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
string sir;
int poz;
int divmul();
int concatbr();

int plusminus()
{
    int nr=divmul();
    while(sir[poz]=='+' || sir[poz]=='-')
    {
        if(sir[poz]=='+')
        {
            poz++;
            nr+=divmul();
        }
        else
        {
            poz++;
            nr-=divmul();
        }
    }
    return nr;
}

int divmul()
{
    int nr=concatbr();
    while(sir[poz]=='*' || sir[poz]=='/')
    {
        if(sir[poz]=='*')
        {
            poz++;
            nr*=concatbr();
        }
        else
        {
            poz++;
            nr/=concatbr();
        }
    }
    return nr;
}

int concatbr()
{
    int nr=0;
    if(sir[poz]=='(')
    {
        poz++;
        nr=plusminus();
        poz++;
    }
    else
    {
        while(sir[poz]>='0' && sir[poz]<='9')
        {
            nr*=10;
            nr+=sir[poz]-'0';
            poz++;
        }
    }
    return nr;
}

int main()
{
    fin>>sir;
    fout<<plusminus();
    return 0;
}
