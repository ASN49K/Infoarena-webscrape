#include <fstream>
#include <iostream>
#include <vector>
#include <string>
using namespace std;

const int bracket = 1e9 + 1, times = 1e9 + 2, divide = 1e9 + 3, Minus = 1e9 + 4;

int st[100001], top;

int main()
{
    string s;
    ifstream fin("evaluare.in");
    fin >> s;
    for (int i = 0; i < s.size(); i++)
        if (s[i] == '+')
            continue;
        else if (s[i] == '-')
            st[++top] = Minus;
        else if (s[i] == '/')
            st[++top] = divide;
        else if (s[i] == '*')
            st[++top] = times;
        else if (s[i] == '(')
            st[++top] = bracket;
        else // s[i] este cifra, fie este paranteza inchisa
        {
            int x = 0;
            if (isdigit(s[i]))
            {
                while (isdigit(s[i]))
                    x = x * 10 + s[i++] - '0';
                i--;
            }
            else
            {
                while (st[top] != bracket)
                    x += st[top--];
                top--;
            }
            if (top == 0)
                st[++top] = x;
            else if (st[top] == Minus)
                st[top] = -x;
            else if (st[top] == divide)
            {
                top--;
                st[top] /= x;
            }
            else if (st[top] == times)
            {
                top--;
                st[top] *= x;
            }
            else
                st[++top] = x;
        }
    ofstream fout("evaluare.out");
    int sum = 0;
    while (top > 0)
        sum += st[top--];
    fout << sum;
    return 0;
}