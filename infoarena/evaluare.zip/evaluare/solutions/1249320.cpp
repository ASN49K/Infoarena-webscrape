#include<fstream>
#include<iostream>
#include<stack>
using namespace std;
stack<int> x;
stack<char> c;
int main()
{
    ifstream si;
    si.open("evaluare.in");
    ofstream so;
    so.open("evaluare.out");
    string s="(";
    char a;
    while(si>>a)
        s+=a;
    s+=')';
    cout<<s;
    int n=s.length(),z;
    int i,d,e,f;
    for(i=0;i<n;++i)
    {
        if('0'<=s[i]&&s[i]<='9')
        {
            z=0;
            while('0'<=s[i]&&s[i]<='9')
            {
                z=z*10+s[i]-'0';
                ++i;
            }
            --i;
            x.push(z);
        }
        else
        {
            if(s[i]=='+'||s[i]=='-'||s[i]=='*'||s[i]=='/'||s[i]=='(')
            {
                cout<<endl<<c.size()<<endl;
                a=s[i];
                c.push(a);
                cout<<endl<<c.size()<<' '<<c.top()<<endl;
            }
            else
            {

                cout<<c.size()<<endl;
                cout<<i;
                cout<<c.top();
                while(c.top()!='(')
                {
                    a=c.top();
                    c.pop();
                    d=x.top();
                    x.pop();
                    e=x.top();
                    x.pop();
                    if(c.top()=='*')
                    {
                        f=x.top();
                        x.pop();
                        switch(a)
                        {
                            case '+':x.push(d+e*f); break;
                            case '-':x.push(e*f-d); break;
                            case '*':x.push(d*e*f); break;
                            case '/':x.push(e*f/d); break;
                        }
                    }
                    else
                        if(c.top()=='/')
                        {
                            f=x.top();
                            x.pop();
                            switch(a)
                            {
                                case '+':x.push(d+f/e); break;
                                case '-':x.push(f/e-d); break;
                                case '*':x.push(d*f/e); break;
                                case '/':x.push(f/e/d); break;
                            }
                        }
                        else
                        {
                            switch(a)
                            {
                                case '+':x.push(d+e); break;
                                case '-':x.push(e-d); break;
                                case '*':x.push(d*e); break;
                                case '/':x.push(e/d); break;
                            }
                        }
                }
                c.pop();
            }
        }
    }
    so<<x.top();
}
