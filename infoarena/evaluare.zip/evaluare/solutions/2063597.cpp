#include <fstream>
#include <string.h>
#include <stack>
#include <queue>

using namespace std;

ifstream fin ("evaluare.in");
ofstream fout ("evaluare.out");

stack <char> ST;
stack <int> SN;
queue <string> FP;
string aux;

char s[100005];
int nr;
int i,n;

int prioritate(char o)
{
    switch (o)
       {case '+':return 1;
        case '-':return 1;
        case '*':return 2;
        case '/':return 2;
       }
    return 0;
}

////adaug un char in coada de stringuri
void Tudor(char c)
{
  aux.clear();
  aux.push_back(c);
  FP.push(aux);
}

void operatie(char o)
{ double x=SN.top();SN.pop();
  double y=SN.top();SN.pop();

    switch (o)
       {case '+':SN.push(x+y);break;
        case '-':SN.push(y-x);break;
        case '*':SN.push(x*y);break;
        case '/':SN.push(y/x);break;
       }

}

int main()
{
    fin>>s;
    ////toate parantezele devin rotunde
    for(i=0;s[i];++i)
       if(s[i]=='{'||s[i]=='[')s[i]='(';
       else if(s[i]=='}'||s[i]==']')s[i]=')';

    ////adaug prima paranteza deschisa in Stiva
    ST.push('(');
    for(i=0;s[i];++i)
        if(s[i]=='(')ST.push(s[i]);
        else
         if(s[i]>='0'&&s[i]<='9') //am ajuns la un numar
           { aux.clear();
             while(s[i]>='0'&&s[i]<='9')
             { aux.push_back(s[i]);
               ++i;
             }
             FP.push(aux);
             --i;
           }
           else
            if(s[i]==')')
             { while(ST.top()!='('){Tudor(ST.top());
                                    ST.pop();}
               ST.pop();
             }
           else  //// avem operator
            { while(prioritate(ST.top()>=prioritate(s[i])))
               {Tudor(ST.top());
                ST.pop();
               }
              ST.push(s[i]);
            }
////am ajuns la sfarsit si extrag tot din stiva si pun in FP
    while(ST.top()!='('){Tudor(ST.top());
                         ST.pop();}

////--------calculul valorii expresiei
    while(!FP.empty())
       {aux=FP.front();
        if(aux[0]>='0'&& aux[0]<='9')
        {////construiesc numarul din sirul de caractere
            nr=0;
            n=aux.length();
            for(i=0;i<n;++i)nr=nr*10+(aux[i]-'0');
            SN.push(nr);
        }
        else operatie(aux[0]);

        FP.pop();
       }
    fout<<SN.top();

    fin.close(); fout.close();
    return 0;
}
