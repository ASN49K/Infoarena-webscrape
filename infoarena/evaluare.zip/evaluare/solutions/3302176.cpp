#include <iostream>
#include <fstream>
#include <string>

using namespace std;

ifstream f("evaluare.in");
ofstream g("evaluare.out");

string s;
int idx;

int eval();

int factor ()
{
    if ( s[idx] == '(')
    {
        idx++;
        int fact = eval();
        idx++;
        return fact;
    }

    int fact = 0;
    while (idx < s.size() && s[idx] >= '0' && s[idx] <= '9')
    {
        fact = fact * 10 + s[idx] - '0';
        idx++;
    }
    return fact;
}
int termen()
{
    int rez = factor();
    while (idx < s.size() && ( s[idx] == '*' || s[idx] == '/'))
    {
        if ( s[idx] == '*')
        {
            idx++;
            rez = rez * factor();
        }
        else if (s[idx] == '/')
        {
            idx++;
            rez = rez / factor();
        }
    }
    return rez;
}
int eval()
{
    int sum = termen();

    while ( idx < s.size() && ( s[idx] == '+' || s[idx] == '-' ) )
    {
        if ( s[idx] == '+')
        {
            idx++;
            sum = sum + termen();
        }
        else if (s[idx] == '-')
        {
            idx++;
            sum = sum + termen();
        }
    }

    return sum;
}
int main()
{
    f >> s;
    g << eval() << "\n";
    return 0;
}
