#include<fstream>
#include<cstring>
#include<algorithm>
#define N 100005

using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int lg,i;
char e[100005];

int formareNr();
int Expresie();
int Termen();
int Factor();

inline int FormareNr(){
    /* Functia transforma cifrele in numar si returneaza numarul format */

    int nr = 0;
    while(e[i] >= '0' && e[i] <= '9' && i < lg){
              nr = nr * 10 + e[i] - '0';
              i++;
          }

    return nr;
}

int Factor(){

    int f;

    if(e[i] == '('){  /// daca intalnim o paranteza rezolvam expresia din paranteza intai
        i++;
        f = Expresie();   /// rezolvam expresia din paranteza
        i++;   /// sarim peste paranteza inchisa
        return f;   /// returnam valoarea parantezei ca factor
    }

    else
        return FormareNr(); /// returnam numarul ca factor

}

int Termen(){
    /* Functia termen returneaza termenii din expresie
    Termenii sunt formati direct cand sunt legati printr-un + sau -
    Daca intre termeni se afla * sau /, termenul se va obtine prin
efectuarea operatiilor */

    int f = Factor();

    while(i < lg && (e[i] == '*' || e[i] == '/')){  /// rezolvam inmultirile si impartirile intai
        char op=e[i];
        i++;
        if(op == '*')
            f = f * Factor();
        else
            f = f / Factor();
          }
    return f;
}

int Expresie()
{   /// consideram ca o expresie este formata din mai multi termeni -> expresie = t1 + t2 + t3 - t4...

    int f = Termen();

    while(i < lg && (e[i] == '+' || e[i] == '-')){  /// acum rezolvam adunarile si scaderile
        char op = e[i];
        i++;
        if(op == '+')
            f = f + Termen();
        else
            f = f - Termen();
    }

    return f;
}

int main()
{
    fin>>e;
    lg = strlen(e);
    fout<<Expresie();
    return 0;
}
