#include <fstream>
#include <cstring>

using namespace std;

ifstream f("evaluare.in");
ofstream g("evaluare.out");

int e[100005], oper[51005], postfix[100005], ko=0, rez[100005], r=0, j;

char e1[100005];

const int MAX=1000000000, D=1111111111;

bool operand(int x)
{
    if(x>MAX) return 1;
    return 0;
}

void actualizeaza1(int x)
{
    int i=x, q=0;

    while(!oper[i]) i++, q++;

    for(i=i; oper[i]; i++)  {
            oper[i-q]=oper[i];
    }

   ko-=q;

}

void actualizeaza2(int x)
{
    int i, q=1;

    oper[x]=0;

    for(i=x; oper[i]!=MAX+6; i++, q++);

    oper[i]=0;

    i++;

    for(i=i; oper[i]; i++) oper[i-q]=oper[i];

    ko-=q;
}

int main()
{
    f.getline(e1, 100003);

    int l1=strlen(e1), i, kp=0, koc, l=0, nr;

    for(i=0;i<l1;i++) {
    if(e1[i]=='+') e[++l]=MAX+1;
    else if(e1[i]=='-') e[++l]=MAX+2;
    else if(e1[i]=='*') e[++l]=MAX+3;
    else if(e1[i]=='/') e[++l]=MAX+4;
    else if(e1[i]=='(') e[++l]=MAX+5;
    else if(e1[i]==')') e[++l]=MAX+6;
    else {
       nr=0;
     while(strchr("0123456789", e1[i]) && i<l1)  {
      nr*=10;
      nr+=e1[i]-48;
      i++;
      }
      i--;
      e[++l]=nr;
     }

    }

    for(i=1;i<=l;i++) {
           if(e[i]==MAX+5 && e[i+1]==MAX+2) {
           e[i+2]*=(-1);
           for(j=i+1;j<=l-1;j++) e[j]=e[j+1];
           l--;
           i--;
         }
      if(e[i]==MAX+5 && e[i+2]==MAX+6) {
          for(j=i;j<l;j++) e[j]=e[j+1];
          l--;
          for(j=i+1;j<l;j++) e[j]=e[j+1];
          l--;
          i--;
      }
    }

    for(i=1;i<=l;i++)  {
        if(operand(e[i]))  {
           oper[++ko]=e[i];
           if(oper[ko]==MAX+3 || oper[ko]==MAX+4)  {
               koc=ko-1;
               while((oper[koc]==MAX+3 || oper[koc]==MAX+4) && koc) {
                  postfix[++kp]=oper[koc];
                  oper[koc]=0;
                  koc--;
               }
               actualizeaza1(koc+1);
           }

           else if(oper[ko]==MAX+1 || oper[ko]==MAX+2)  {
               koc=ko-1;
               while((oper[koc]==MAX+1 || oper[koc]==MAX+2 || oper[koc]==MAX+3 || oper[koc]==MAX+4) && koc) {
                  postfix[++kp]=oper[koc];
                  oper[koc]=0;
                  koc--;
               }
                actualizeaza1(koc+1);
           }

           else if(oper[ko]==MAX+6)  {
               koc=ko;
               while(oper[--koc]!=MAX+5) {
                  if(oper[koc]) postfix[++kp]=oper[koc];
                  oper[koc]=0;
               }

             actualizeaza2(koc);
           }

        }

        else postfix[++kp]=e[i];

    }

    for(i=ko;i>=1;i--) if(oper[i] && oper[i]<MAX+5) postfix[++kp]=oper[i];

    for(i=1;i<=kp;i++)  rez[++r]=postfix[i];

    for(i=1;i<=r;i++) g<<rez[i]<<" ";
    g<<'\n';

    int a, b;

    for(i=1;i<=r;i++)  if(operand(rez[i])) {
        j=i;
        while(operand(rez[j]) || rez[j]==D) j--;
        a=rez[j];
        rez[j]=D;

        j--;

        while((operand(rez[j]) || rez[j]==D) && j) j--;
        b=rez[j];
        rez[j]=D;

        if(rez[i]==MAX+1) rez[i]=b+a;
        else if(rez[i]==MAX+2) rez[i]=b-a;
        else if(rez[i]==MAX+3) rez[i]=b*a;
        else if(rez[i]==MAX+4) rez[i]=b/a;
    }

    g<<rez[r];

    f.close();
    g.close();
    return 0;
}
