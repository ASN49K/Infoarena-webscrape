#include <fstream>
#include <string.h>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
char s[1000000];
int i=0;
int paranteza();
int operat()
{
    if(s[i]=='(')
    {
        i++;
        return paranteza();
    }
    int rez=0,semn=1;
    if(s[i]=='-')
    {
        semn=-1;
        i++;
    }
    if(strchr("+-*/",s[i]))
        i++;
    if(strchr("()",s[i]))
    {
        i++;
        return paranteza()*semn;
    }
    while(s[i]>='0' && s[i]<='9')
    {
        rez=rez*10+s[i]-'0';
        i++;
    }
    return rez*semn;
}
int inmult()
{
    int rez=0,op=0;
    rez=operat();
    while(s[i]=='*' || s[i]=='/')
    {
        if(s[i]=='*')
            rez=rez*operat();
        else
            rez=rez/operat();
    }
    return rez;
}
int paranteza()
{
    int rez=0,op=0;
    while(s[i]!=')')
    {
        op=operat();
        if(s[i]=='+' || s[i]=='-')
        {
            rez=rez+op;
        }
        else
        {
            if(s[i]=='*')
            {
                rez=rez+op*inmult();
                op=0;
            }
            else
                if(s[i]=='/')
                {
                    rez=rez+op/inmult();
                    op=0;
                }
        }
    }
    rez+=op;
    i++;
    return rez;
}
int main()
{
    int n;
    f>>s;
    n=strlen(s);
    s[n]=')';
    g<<paranteza();
    return 0;
}
