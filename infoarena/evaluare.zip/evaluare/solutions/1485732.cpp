#include<cstdio>
#include<cstring>
int n,i,j;
char s[100100],c;
FILE *f,*g;
int termen();
int factor();
int expresie(){
    int r=termen();
    while(s[i]=='+'||s[i]=='-'){
        if(s[i]=='+'){
            i++;
            r+=termen();
        }
        else{
            i++;
            r-=termen();
        }
    }
    return r;
}
int termen(){
    int r=factor();
    while(s[i]=='*'||s[i]=='/'){
        if(s[i]=='*'){
            i++;
            r*=factor();
        }
        else{
            i++;
            r/=factor();
        }
    }
    return r;
}
int factor(){
    int r;
    if(s[i]=='('){
        i++;
        r=expresie();
        i++;
    }
    else{
        r=0;
        while(s[i]>='0'&&s[i]<='9'){
            r=r*10+s[i]-'0';
            i++;
        }
    }
    return r;
}
int main(){
    f=fopen("evaluare.in","r");
    g=fopen("evaluare.out","w");
    fscanf(f,"%s",s);
    n=strlen(s);
    fprintf(g,"%d",expresie());







    fclose(f);
    fclose(g);
    return 0;
}
