#include <iostream>
#include <fstream>
#include <string>
using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
string sir;
int i;
int aduna();
int produs();
int exp();
int aduna()
{
    int rez=produs();
    while(sir[i]=='+' || sir[i]=='-')
    {
        if(sir[i]=='+')
        {
            ++i;
            rez=rez+produs();
        }
        if(sir[i]=='-')
        {
            ++i;
            rez=rez-produs();
        }
    }
    return rez;
}
int produs()
{
    int rez=exp();
    while(sir[i]=='*' || sir[i]=='/')
    {
        if(sir[i]=='*')
        {
            ++i;
            rez=rez*exp();
        }
        if(sir[i]=='/')
        {
            ++i;
            rez=rez/exp();
        }
    }
    return rez;
}
int exp()
{
    int rez=0;
    if(sir[i]=='(')
    {
        ++i;
        rez=aduna();
        ++i;
    }
    else
    {
        while(sir[i]>='0' && sir[i]<='9')
        {
            rez=rez*10+(sir[i]-'0');
            i++;
        }
    }
    return rez;
}
int main()
{
    f>>sir;
    g<<aduna();
    return 0;
}
