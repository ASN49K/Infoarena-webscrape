#include <bits/stdc++.h>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char s[100005];
int poz;
int Termen(int &poz);
int Factor(int &poz);

int Eval(int &poz)
{
    int answer = Termen(poz);
    while(s[poz])
    {
        cout << "eval " << poz << " " << s[poz] << " " << answer << "\n";
        if(s[poz] == '+')
            answer += Termen(++poz);
        else if(s[poz] == '-')
            answer -= Termen(++poz);
        else
        {
            poz++;
            return answer;
        }

    }
    return answer;

}

int Termen(int &poz)
{
    int answer = Factor(poz);
    while(s[poz])
    {
        cout << "termen " << poz << " " << s[poz] << " " << answer << "\n";
        if(s[poz] == '*')
        {
            answer *= Factor(++poz);
            continue;
        }
        else if(s[poz] == '/')
        {
            answer /= Factor(++poz);
            continue;
        }
        else return answer;

    }
    return answer;

}
int Factor(int &poz)
{
    if(s[poz] == '(')
    {
      //  cout << "hey";
        return Eval(++poz);
    }
    int x = 0;
    while('0' <= s[poz] && s[poz] <= '9')
        x = x * 10 + s[poz++] - '0';
    cout << "factor " << poz << " " << s[poz] << " " << x << "\n";
    return x;
}


int main()
{
    fin >> (s + 1);
    int poz = 1;
    fout << Eval(poz);
    return 0;
}
