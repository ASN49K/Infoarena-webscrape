#include <fstream>
#include <iostream>
#include <algorithm>
#include <string>
#include <sstream>
#include <cstdlib>

using namespace std;

string a;

long s2r (int left,int right)
{
    int i,n=0;
    for (i=left; i<=right; i++)
        n=n*10+a[i]-'0';
    return n;
}

long long int eval(int left, int right)
{
    int p1 =-1, p2 =-1, p3 =-1, p4 =-1, pp =0;
    for (int i = right; i >= left; i--)
        if (a[i]=='(') pp++;
            else if (a[i]==')') pp--;
            else if (pp==0)
            {
                if (a[i]=='+') return eval(left,i-1)+eval(i+1,right);
                if (a[i]=='-') return eval(left,i-1)-eval(i+1,right);
                if (a[i]=='*') p3=i;
                if (a[i]=='/') p4=i;
            }

    if (p3>p4) return eval(left,p3-1)*eval(p3+1,right);
        else if (p4>0) return eval(left,p4-1)/eval(p4+1,right);
        else if (a[left]=='(') return eval(left+1,right-1);
        else return s2r(left,right);
}

int main ()
{
    ifstream f("evaluare.in");
    ofstream g("evaluare.out");
    f >> a;
    g << eval(0,a.length()-1);
    return 0;
}
