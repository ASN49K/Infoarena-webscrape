#include<iostream>
#include<string.h>
#include<fstream>
using namespace std;
ifstream h("evaluare.in");
ofstream g("evaluare.out");
char a[100000];
int n;
int f(int x,int y)
{
    int v1,v2,w,c=0,i;
    if(a[y]==')')
    {
        c++;
        for(i=y-1;i>=x;i--)
        {
            if(a[i]==')') c++;
            else if(a[i]=='(')
            {
                c--;
                if(c==0) break;
            }
        }
        if(i==x) return f(x+1,y-1);
    }#include<iostream>
#include<string.h>
using namespace std;
char a[10000];
int n;
int f(int x,int y)
{
    int v1,v2,w,c=0,i;
    if(a[y]==')')
    {
        c=1;
        for(i=y-1;i>=x;i--)
        {
            if(a[i]==')') c++;
            else if(a[i]=='(')
            {
                c--;
                if(c==0) break;
            }
        }
        if(i==x) return f(x+1,y-1);
    }
    for(i=y;i>=x;i--)
    {
        if(a[i]=='+'||a[i]=='-')
        {
            v1=f(x,i-1);
            v2=f(i+1,y);
            if(a[i]=='+')return (v1+v2);
            return v1-v2;
        }
    }
    for(i=y;i>=x;i--)
    {
        if(a[i]=='*'||a[i]=='/')
        {
            v1=f(x,i-1);
            v2=f(i+1,y);
            if(a[i]=='*') return (v1*v2);
            return (v1/v2);
        }
    }
    w=0;
    for(i=x;i<=y;i++)
    {
        w=w*10+(a[i]-'0');
    }
    return w;
}
int main()
{
    cin.get(a,10000);
    cin.get();
    n=strlen(a);
    cout<<f(0,n-1);
    return 0;
}

    c=0;
    for(i=y;i>=x;i--)
    {
        if(a[i]==')') c++;
        else if(a[i]=='(') c--;
        if((a[i]=='+'||a[i]=='-')&&c==0)
        { if(a[i]==')') c++;
            else if(a[i]=='(')
            {
                c--;
                if(c==0) break;
            }
            v1=f(x,i-1);
            v2=f(i+1,y);
            if(a[i]#include<iostream>
#include<string.h>
using namespace std;
char a[10000];
int n;
int f(int x,int y)
{
    int v1,v2,w,c=0,i;
    if(a[y]==')')
    {
        c=1;
        for(i=y-1;i>=x;i--)
        {
            if(a[i]==')') c++;
            else if(a[i]=='(')
            {
                c--;
                if(c==0) break;
            }
        }
        if(i==x) return f(x+1,y-1);
    }
    for(i=y;i>=x;i--)
    {
        if(a[i]=='+'||a[i]=='-')
        {
            v1=f(x,i-1);
            v2=f(i+1,y);
            if(a[i]=='+')return (v1+v2);
            return v1-v2;
        }
    }
    for(i=y;i>=x;i--)
    {
        if(a[i]=='*'||a[i]=='/')
        {
            v1=f(x,i-1);
            v2=f(i+1,y);
            if(a[i]=='*') return (v1*v2);
            return (v1/v2);
        }
    }
    w=0;
    for(i=x;i<=y;i++)
    {
        w=w*10+(a[i]-'0');
    }
    return w;
}
int main()
{
    cin.get(a,10000);
    cin.get();
    n=strlen(a);
    cout<<f(0,n-1);
    return 0;
}
=='+')return (v1+v2);
            return v1-v2;
        }
    }
    c=0;
    for(i=y;i>=x;i--)
    {
        if(a[i]==')') c++;
        else if(a[i]=='(') c--;
        if((a[i]=='*'||a[i]=='/')&&c==0)
        {
            v1=f(x,i-1);
            v2=f(i+1,y);
            if(a[i]=='*') return (v1*v2);
            return (v1/v2);
        }
    }
    w=0;
    for(i=x;i<=y;i++)
    {
        w=w*10+(a[i]-'0');
    }
    return w;
}
int main()
{
    h.get(a,10000);
    h.get();
    n=strlen(a);
    g<<f(0,n-1);
    h.close();
    g.close();
    return 0;
}

