#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#define N 100010

using namespace std;

char sir[N] ;
int i;

int termen();
int factor();


int eval() {
    int r = termen();
    while ( sir[i]=='+' || sir[i]=='-' ) {
        switch ( sir[i] ) {
            case '+':
                i++;                        // trecem peste semnul "+"
                r += termen();
                break;
            case '-':
                i++;                        // trecem peste semnul "-"
                r -= termen();
                break;
        }
    }
    return r;
}


int termen() {
    int r = factor();

    while ( sir[i]=='*' || sir[i]=='/' ) {
        switch ( sir[i] ) {
            case '*' :
                i++;
                r *= factor();
                break;
            case '/':
                i++;
                r /= factor();
                break;
        }
    }
    return r;
}

int factor() {
    int r=0;
    if ( sir[i] == '(' ) {                      // avem o subexpresie
        i++;                                // trecem peste '('
        r = eval();
        i++;                                // trecem peste ')'
    } else {
        while ( sir[i]>='0' && sir[i]<='9' )  {       // avem un numar
            r = r*10 + sir[i] - '0';
            i++;
        }
    }
    return r;
}

int main(){

    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);

    scanf("%s",sir);

    printf("%d",eval());

    return 0;
}
