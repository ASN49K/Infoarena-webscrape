#include <iostream>
#include <fstream>
#include <string>

using namespace std;

ifstream fin ( "evaluare.in" );
ofstream fout ( "evaluare.out" );

string s;
int i;

int solve ();
int factor ();
int termen ();

int solve () {
    
    int sum = factor ();
    
    while ( s[i] == '+' || s[i] == '-' ) {
        
        if ( s[i] == '+' ) {
            i++;
            sum = sum + factor ();
        }
        else {
            i++;
            sum = sum - factor ();
        }
    }
    
    return sum;
        
}

int factor () {
    
    int prod = termen ();
    
    while ( s[i] == '*' || s[i] == '/' ) {
  
        if ( s[i] == '*' ) {
            i++;
            prod = prod * termen ();
        }
        else {
            i++;
            prod = prod / termen ();
        }
    }
    
    return prod;
}

int termen () {
    
    int nr = 0;
    int semn = 1;
    
    if ( s[i] == '-' ) {
        semn = -semn;
        i++;
    }
    
    if ( s[i] == '(' ) {
        
        i++;
        
        nr = solve ();
        nr = nr * semn;
        
        i++;
        
        return nr;
        
    }
    
    while ( '0' <= s[i] && s[i] <= '9' ) {
        nr = nr * 10 + ( s[i] - '0' );
        i++;
    }
    
    nr = nr * semn;
    
    return nr;
}

int main () {
    
    fin >> s;
    
    fout << solve ();
    
    return 0;
}
