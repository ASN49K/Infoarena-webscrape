#include<stdio.h>
#include<string.h>
#include<ctype.h>
void read(),solve();
char s[100005],op[100005];
int v[100005],l,V,O,i,val; 
int main()
{	read();
	solve();
	printf("%d",v[1]);
	return 0;
}
void read()
{	freopen("evaluare.in","r",stdin);
	freopen("evaluare.out","w",stdout);
	scanf("%s",s);
	l=strlen(s);
	op[0]='#';
}
void solve()
{	for(i=0;i<l;i++)
    {   if(s[i]=='-'&&s[i-1]=='('){ v[++V]=-1; op[++O]='*'; continue;}
		if(isdigit(s[i])) { val=0;
						   while(isdigit(s[i])){ val*=10; val+=(int)(s[i]-'0'); i++;}
						   i--;
						   if(op[O]=='*'){ v[V]*=val; O--;}
						   else if(op[O]=='/'){ v[V]/=val; O--;}
						   else v[++V]=val;
						   continue;
	                     }
	    if(s[i]==')'){ while(op[O]!='('){ if(op[O]=='+') v[V-1]+=v[V];
		                                  else v[V-1]-=v[V];
		                                  V--; O--;
		                                }
		                O--;
						if(op[O]=='*'){ v[V-1]*=v[V];V--; O--;}
						  else if(op[O]=='/'){ v[V-1]/=v[V]; V--; O--;}
						continue;
		              }
		if(strchr("(+-*/",s[i]))op[++O]=s[i];
	}
	while(O)
	{   if(op[O]=='+') v[V-1]+=v[V];
	      else v[V-1]-=v[V];
		V--; O--;
		
	}
}
