#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char s[100005],ch,op[100005];
int n,i,j,k,l,x,top1,top2,st[100005];

int pr(char c)
{
    if(c=='+' or c=='-')
        return 1;
    if(c=='*' or c=='/')
        return 2;
    return 0;
}

void eval(int t1,int t2)
{

    if(op[t2]=='+')
        st[t1-1]+=st[t1];
    if(op[t2]=='-')
        st[t1-1]-=st[t1];
    if(op[t2]=='*')
        st[t1-1]*=st[t1];
    if(op[t2]=='/')
        st[t1-1]/=st[t1];

    return;

}


int main()
{
    fin.getline(s,100003);
    l=strlen(s);
    //fout<<l<<endl;
    for(i=0;i<l;i++)
    {
        //fout<<s[i]<<endl;
        if(isdigit(s[i]))
        {
            x=0;
            while(isdigit(s[i]))
            {
                x=x*10+s[i]-'0';
                i++;
            }
            i--;
            st[++top1]=x;
        }
        else
        {
            if(top2==0 || s[i]=='(' || pr(op[top2])<pr(s[i]))
               op[++top2]=s[i];
               else
            if(s[i]==')')
            {
                while(op[top2]!='(')
                {
                    eval(top1,top2);
                    top1--;
                    top2--;
                }
                top2--;
            }
            else
            {
                if(pr(s[i])<=pr(op[top2]))
                {
                    while(pr(s[i])<=pr(op[top2]))
                    {
                        eval(top1,top2);
                            top1--;
                            top2--;
                    }
                    op[++top2]=s[i];

                }
            }
        }
    }
    //fout<<top2<<endl;
    while(top2)
    {
        eval(top1,top2);
        top1--;
        top2--;
    }

    fout<<st[1];
    return 0;
}
