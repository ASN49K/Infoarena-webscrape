#include <bits/stdc++.h>
#define NMAX 100005
#define infile "evaluare.in"
#define outfile "evaluare.out"

using namespace std;

long eval();
long term();
long valoare();

char s[NMAX];
char *p = s;

long eval()
{
    long r = term();
    while (*p == '+' || *p == '-')
    {
        switch(*p)
        {
        case '+':
            ++p;
            r += term();
            break;
        case '-':
            ++p;
            r -= term();
            break;
        }
    }
    return r;
}

long term()
{
    long r = valoare();
    while (*p == '*' || *p == '/')
    {
        switch (*p)
        {
        case '*':
            ++p;
            r *= valoare();
            break;
        case '/':
            ++p;
            r /= valoare();
            break;
        }
    }
    return r;
}

long valoare()
{
    long r = 0;

    if (*p == '(')
    {
        ++p;
        r = eval();
        ++p;
    }
    else
    {
        while (*p >= '0' && *p <= '9')
        {
            r = r * 10 + *p - '0';
            ++p;
        }
    }

    return r;
}

int main()
{
    freopen(infile, "r", stdin);
    freopen(outfile, "w", stdout);

    fgets(s, NMAX, stdin);
    printf("%ld", eval());

    fclose(stdin);
    fclose(stdout);
    return 0;
}
