#include <fstream>
using namespace std;
ifstream f ("evaluare.in");
ofstream g ("evaluare.out");
char s[100003];
int i;
int termen();
int fact();
int eval() //evaluarea
{
    int r=termen(); //se apeleaza de sus in jos pt rezolvarea multiplelor paranteze si pt crearea numerelor in parsare
    while(s[i]=='+'||s[i]=='-') //nivelul acesta rezolva ultimul grad de importanta, + si -
    {
        if(s[i]=='+') {i++;r=r+termen();}
        else {i++;r=r-termen();}
    }
    //am terminat pe moment cu + si -
    return r; //returnam ce am obtinut
}
int termen() //acest nivel rezolva / si *
{
    int r=fact();
    while(s[i]=='*'||s[i]=='/') //cat timp avem acest tip de operatie
    {
        if(s[i]=='*') {++i;r=r*fact();} //le facem
        else {++i;r=r/fact();}
    }
    return r; //r.urile in fiecare subprogram sunt variabile diferite
}
int fact()
{
    int r=0; //nivelul unde genram numarul
    if(s[i]=='(') {++i;r=eval();++i;} //intram in alta paranteza, avem de 2 ori ++i pt ca sarim si peste ')'
    while(s[i]<='9'&&s[i]>='0') {r=r*10+s[i]-'0';++i;} //cream numarul
    return r;
}
int main()
{
    f.getline(s,100003); //citim sirul
    g<<eval(); //afisam raspunsul
    return 0;
}
