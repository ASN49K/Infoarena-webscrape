#include <fstream.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

char buffer[10000];
long length;
char *c;

long expresie();
long termen();
long factor();

int main() {

    ifstream fin("evaluare.in");
    ofstream fout("evaluare.out");

    fin.get(buffer, 100001);
    buffer[strlen(buffer)] = 0;
    length = strlen(buffer);

    c = buffer;

    fout<<expresie();

    return 0;
}


long expresie() {

    long x = termen();
    while ((*c == '+' || *c == '-') && (c-buffer+1 <= length)) {
	if (*c == '+') {
	    c++;
	    x += termen();
	} else if (*c == '-') {
	    c++;
	    x -= termen();
	}
    }

    return x;


}

long termen() {

    long x=factor();
    while ((*c == '*' || *c == '/') && (c-buffer+1 <= length)) {
	if (*c == '*') {
	    c++;
	    x = x * factor();
	} else if (*c == '/') {
	    c++;
	    x = x / factor();
	}
    }

    return x;

}

long factor() {

    long aux;
    if (isdigit(*c)) {
	aux = atof(c);
	while (isdigit(*c))
	    c++;
    } else {
	if (c-buffer+1 <= length) {
	    c++;
	    aux = expresie();
	    c++;
	}
    }

    return aux;

}
