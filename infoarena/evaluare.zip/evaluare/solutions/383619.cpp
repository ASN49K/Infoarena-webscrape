#include<stdio.h>
int o;
char v[101010],*p=v;
long long termen();
long long factor();

long long eval()
{
    long long r=termen();
    while(*p=='+'||*p=='-')
    {
        if(*p=='+')
        {
            ++p;
            r+=termen();
        }
        else if(*p=='-')
        {
            ++p;
            r+=termen();
        }
    }
    return r;
}

long long termen()
{
        long long r = factor();
        while(*p=='*'||*p=='/')
    {
        if(*p=='*')
        {
            ++p;
            r*=termen();
        }
        else if(*p=='/')
        {
            ++p;
            r/=termen();
        }
    }
    return r;

}



long long factor()
{
    long long r=0;
    if(*p== '(')
    {
        ++p;
        r=eval();
        ++p;
    }
    else
    {
        while(*p>='0'&&*p<='9')
        {
            r=r*10+*p-'0';
            ++p;
        }
    }
    return r;
}




int main()
{
freopen("evaluare.in","r",stdin);
freopen("evaluare.out","w",stdout);
while(scanf("%c",&v[o])==1)
++o;
printf("%lld",eval());

}
