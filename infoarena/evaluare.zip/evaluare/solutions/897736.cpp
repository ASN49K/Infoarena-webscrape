#include <fstream>
#include <iostream>
#include <string>
#include <cassert>
using namespace std;

string s;
unsigned int i = -1;

int N(), E(), I();

int N ()
{
	++i;
	int aux = 0;
	if (s[i] == '(')
		aux = E(), ++i;
	else
	{
		while (s[i] >= '0' && s[i] <= '9' && i < s.size())
			aux = aux * 10 + s[i++] - '0';
	}
	return aux;
}

int I ()
{
	int aux = N();
	cout << aux << " ";
	while ((s[i] == '*' || s[i] == '/' )&& i < s.size())
		aux = s[i] == '*' ? aux * N() : aux / N();
	return aux;	
}

int E ()
{
	int aux = I();
	while ((s[i] == '+' || s[i] == '-' ) && i < s.size())
		aux += (s[i] == '+' ? I() : -I());
	return aux;
}	
		
int main ()
{
	ifstream fin ("evaluare.in");
	fin >> s;
	fin.close();
	ofstream fout ("evaluare.out");
	fout << E();
	fout.close ();
	return 0;
}
