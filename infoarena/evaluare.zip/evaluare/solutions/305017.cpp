#include<iostream>
#include<string>
#include<fstream>
using namespace std;
string a;
string ::iterator it;
int termen(),factor(),nr();
int termen()
{
	int r=factor();
	while(*it=='+'||*it=='-')
		if(*it++=='+')
			r+=factor();
		else
			r-=factor();
	return r;
}
int factor()
{
	int r=nr();
	while(*it=='*'||*it=='/')
		if(*it++=='*')
			r*=nr();
		else
			r/=nr();
	return r;
}
int nr()
{
	int r=0;
	if(*it=='(')
		it++,r=termen(),it++;
	else
		while('0'<=*it&&*it<='9')
			r=r*10+*it++ -'0';
	return r;
}
int main()
{
	ifstream f("evaluare.in");
	ofstream g("evaluare.out");
	f>>a;
	it=a.begin();
	g<<termen()<<'\n';
	return 0;
}