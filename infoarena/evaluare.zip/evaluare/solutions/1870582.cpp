#include <iostream>
#include <fstream>
#include <string.h>

using namespace std;

#define NX (1<<17)
char S[ NX ], *p;
char op[4][4] = { "+-", "*/", "^", "" };

class nod {
public:
    int val;
    char opcode;
    nod *st, *dr;

    nod(int a=0, char b=0, nod *c=0, nod *d=0)
    {
        val=a;
        opcode=b;
        st = c;
        dr = d;
    }
};

nod * T;

nod * expr (int ordin)
{
    nod *x, *y;
    if(ordin==2) //avem deja inmultiri si impartiri
    {
        if(*p=='(')
        {
            ++p;
            //cout<<p-S;
            x = expr(0);
            ++p;
            //cout<<p-S;
        }
        else
        {
            x=new nod();
            for(; *p>='0' && *p<='9';++p)
            {
                //cout<<p-S;
                x->val=x->val*10+*p-'0';    ///dc e un numar din mai multe cifre le citim pe toate
            }
        }
    }
    else
        {
        x=expr(ordin+1);
        for(; strchr(op[ordin], *p); x=y)
        {
           // cout<<p-S;
            y = new nod(0, *p++, x, expr(ordin+1));
            //cout<<p-S;
            }
        }
    return x;


}
int eval(nod *n)
{
    switch(n->opcode)
    {
        case '+':
           // cout<<n->opcode<<" "<<n->val<<"\n";
            return eval(n->st) + eval(n->dr);
        case '-':
          //  cout<<n->opcode<<" "<<n->val<<"\n";
            return eval(n->st) - eval(n->dr);
        case '*':
           // cout<<n->opcode<<" "<<n->val<<"\n";
            return eval(n->st) * eval(n->dr);
        case '/':
            //cout<<n->opcode<<" "<<n->val<<"\n";
            return eval(n->st) / eval(n->dr);
        default:
            //cout<<n->opcode<<" "<<n->val<<"\n";
            return n->val;
    }
}
int main ()
{

    ifstream input ("evaluare.in");
    ofstream output ("evaluare.out");

    input>>S;
    S[strlen(S)]='.'; //- fara asta nu merge!!!
    p=S;
    T = expr (0);
    output<<eval(T);
    return 0;
}
