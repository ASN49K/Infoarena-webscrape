#include <iostream>
#include <cstdio>
#define NMax 100010
using namespace std;
char S[NMax],*p=S;
long Termen();
long Factor();

long Evalueaza()
{
    long r=Termen();
    while(*p=='+' || *p=='-')
    {
        switch(*p)
        {
            case '+':
                ++p;
                r=r+Termen();
                break;
            case '-':
                ++p;
                r=r-Termen();
                break;
        }
    }
    return r;
}

long Termen()
{
    long r=Factor();
    while(*p=='*' || *p=='/')
    {
        switch(*p)
        {
            case '*':
                ++p;
                r=r*Factor();
                break;
            case '/':
                ++p;
                r=r/Factor();
                break;
        }
    }
    return r;
}

long Factor()
{
    long r=0;
    if(*p=='(')
    {
        ++p;
        r=Evalueaza();
        ++p;
    }
    else
    {
        while(*p>='0' && *p<='9')
        {
            r=r*10+*p-'0';
            ++p;
        }
    }
    return r;
}

int main()
{
    fgets(S,NMax,fopen("evaluare.in","r"));
    fprintf(fopen("evaluare.out", "w"),"%ld\n",Evalueaza());
}
