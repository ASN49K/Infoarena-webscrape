#include <fstream>

using namespace std;
ifstream in("evaluare.in");
ofstream out("evaluare.out");
const int NMAX=100000,MOD=1000000000;
int tpop,tpnr;
int nr[NMAX+5];
char op[NMAX+5];
int prior(int c)
{
    switch(c)
    {
    case '+':
    case '-':return 1;
    case '*':return 2;
    case '/':return 3;
    }
    return 0;
}
int main()
{
    int k=0,ok=0,a,b;
    long long x=0;
    char ch,oper;
    while(in.get(ch))
    {
        if(ch>='0' && ch<='9')
        {
            x=x*10+(ch-'0');
            x=x%MOD;
            ok=1;
        }
        else
        {
            if(ok==1)
            {
                nr[++tpnr]=x%MOD;
                x=0;
                ok=0;
            }
            if(ch=='(')
                op[++tpop]=ch;
            else if(ch==')')
            {
                while(op[tpop]!='(')
                {
                    oper=op[tpop];
                    a=nr[tpnr-1];
                    b=nr[tpnr];
                    switch(oper)
                    {
                        case '+':nr[tpnr-1]=(a+b)%MOD;break;
                        case '-':nr[tpnr-1]=(a-b)%MOD;break;
                        case '*':nr[tpnr-1]=(a*b)%MOD;break;
                        case '/':nr[tpnr-1]=(a/b)%MOD;break;
                    }
                    tpop--;
                    tpnr--;
                }
                tpop--;
            }
            else
            {
                if(tpop==0 || op[tpop]=='(' || prior(ch)>prior(op[tpop]))
                    op[++tpop]=ch;
                else
                {
                    while(tpop!=0 && prior(op[tpop])>=prior(ch))
                    {
                        oper=op[tpop];
                        tpop--;
                        a=nr[tpnr-1];
                        b=nr[tpnr];
                        switch(oper)
                        {
                            case '+':nr[tpnr-1]=(a+b)%MOD;break;
                            case '-':nr[tpnr-1]=(a-b)%MOD;break;
                            case '*':nr[tpnr-1]=(a*b)%MOD;break;
                            case '/':nr[tpnr-1]=(a/b)%MOD;break;
                        }
                        tpnr--;
                    }
                    op[++tpop]=ch;
                }
            }
        }
    }
    while(tpop!=0 && op[tpop]!='\n')
    {
        oper=op[tpop];
        tpop--;
        a=nr[tpnr-1];
        b=nr[tpnr];
        switch(oper)
        {
            case '+':nr[tpnr-1]=(a+b)%MOD;break;
            case '-':nr[tpnr-1]=(a-b)%MOD;break;
            case '*':nr[tpnr-1]=(a*b)%MOD;break;
            case '/':nr[tpnr-1]=(a/b)%MOD;break;
        }
        tpnr--;
    }
    out<<nr[tpnr]%MOD;
    return 0;
}
