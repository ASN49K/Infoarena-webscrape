//#include <iostream>
#include <fstream>
using namespace std;
char c [100002];
int i=0;
int termen();
int factor();
int evaluare ()
{
    int t=termen();
    while ( c[i]=='+' || c[i]=='-' )
    {
        switch(c[i])
        {
            case '+':
                i++;                        // trecem peste semnul "+"
                t=t+termen();
                break;
            case '-':
                i++;                        // trecem peste semnul "-"
                t=t-termen();
                break;
        }
    }
    return t;
}
int termen()
{
    /*cout<<c[i]<<endl;
    if(c[i]!=EOF)
    {
        i++;
        return (int)c[i-1]-48;

    }
    else
        return 0;
        */
    int f=factor();
    while ( c[i]=='*' || c[i]=='/' )
    {
        switch(c[i])
        {
            case '*':
                i++;
                f=f*factor();
                break;
            case '/':
                i++;
                f=f/factor();
                break;
        }
    }
    return f;
}
int factor()
{
    /*if(c[i]!=EOF)
    {
        i++;
        return (int)c[i-1]-48;

    }
    else
        return 0;*/
    int e=0;
    if (c[i]=='(')
    {
        i++;
        e=evaluare();
        i++;
    }
    else
        {
        while (c[i]>='0' && c[i]<='9')
        {
            e=e*10+c[i]-48;
            i++;
        }
    }
    return e;
}
int main ()
{
    ifstream in ("evaluare.in");
    ofstream out ("evaluare.out");
    in>>c;
    out<<evaluare();
    in.close();
    out.close();
return 0;
}
