#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
char s[100005], *p;
int eval();
int termen();
int factor();
int eval(){
    int rez=termen();
    while(*p=='+' || *p=='-')
    {
        if(*p=='+')
    {
        p++;
        rez+=termen();
    }
    else
    {
        p++;
        rez-=termen();
    }
    }
    return rez;
}
int termen()
{
  int rez=factor();
  while(*p=='*' || *p=='/')
  {
      if(*p=='*')
      {
      p++;
      rez*=factor();
      }
      else
      {
        p++;
        rez/=factor();
      }
  }
  return rez;
}
int factor()
{
   int rez=0;
   if(*p=='(')
      {
        p++;
        rez=eval();
        p++;
      }
      else while(*p>='0' && *p<= '9')
      {
          rez=rez*10+(*p-'0');
          p++;
      }
      return rez;
}
int main()
{
    p=s;
    ifstream f("evaluare.in");
    ofstream g("evaluare.out");
    f.getline(s, 100005);
    int rez=eval();
    g << rez;

}
