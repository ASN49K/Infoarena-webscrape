#include <fstream>
#include <stack>
#include <vector>
#include <string.h>
using namespace std;

ifstream cin("evaluare.in");
ofstream cout("evaluare.out");
#define MAXSIR 100005

int ord(char semn)
{
    if(semn=='(' || semn==')')
        return 3;
    if(semn=='*' || semn=='/')
        return 2;
    if(semn=='+' || semn=='-')
        return 1;
}

stack<int> st;
char expr[MAXSIR],polish[MAXSIR], sir[MAXSIR];
int i,j,n,polish_c=-1,expr_c,nr;
int main()
{
    cin.getline(sir,MAXSIR-1); n=strlen(sir);
    for(i=0; i<n; i++)
    {
        if(sir[i]=='(' || sir[i]==')' || sir[i]=='+' || sir[i]=='-' || sir[i]=='*' || sir[i]=='/')
        {
            if(sir[i]==')')
            {
                while(polish[polish_c]!='(')
                    expr[expr_c++]=polish[polish_c--];
                polish_c--;
                continue;
            }

            if(ord(sir[i]) < ord(polish[polish_c]) && polish[polish_c]!='(')
            {
                while( polish_c>-1 && ord(sir[i]) < ord(polish[polish_c]))
                    expr[expr_c++]=polish[polish_c--];

                polish[++polish_c]=sir[i];

            }
            else
                polish[++polish_c]=sir[i];
        }
        else
        {
            while(isdigit(sir[i]))
            {
                expr[expr_c++]=sir[i++];
            }
            i--;
            expr[expr_c++]=' ';
        }
    }
    while(polish_c> -1)
        expr[expr_c++]=polish[polish_c--];

    for(i=0; i<expr_c; i++)
    {
        if(isdigit(expr[i]))
        {
            nr=0;
            while(isdigit(expr[i]))
                nr=nr*10+expr[i++]-'0';
            st.push(nr);
        }
        else
        {
            int a=st.top(); st.pop();
            int b=st.top(); st.pop();
            if(expr[i]=='+')
                st.push(a+b);
            if(expr[i]=='-')
                st.push(b-a);
            if(expr[i]=='/')
                st.push(b/a);
            if(expr[i]=='*')
                st.push(a*b);
        }
    }
    cout<<st.top();




}
