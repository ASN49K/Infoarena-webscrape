#include <bits/stdc++.h>

using namespace std;

ifstream f("evaluare.in");
ofstream g("evaluare.out");

int i;
string s;
stack<int> St;
vector<pair<int,int> > ans;

int read()
{
    int ret=0;
    while(i<s.size()&&'0'<=s[i]&&s[i]<='9')
    {
        ret=ret*10+(s[i]-'0');
        i++;
    }
    return ret;
}

int main()
{
    f>>s;
    for(i=0; i<s.size();)
    {
        if(s[i]=='(')
        {
            St.push(5);
            i++;
            continue;
        }
        if(s[i]==')')
        {
            while(St.top()!=5)
            {
                ans.push_back({1,St.top()});
                St.pop();
            }
            St.pop();
            i++;
            continue;
        }
        if('0'<=s[i]&&s[i]<='9')
        {
            ans.push_back({0,read()});
            continue;
        }
        if(s[i]=='+'||s[i]=='-')
        {
            while(St.size()&&St.top()!=5)
            {
                ans.push_back({1,St.top()});
                St.pop();
            }
            St.push(s[i]=='+'?1:2);
            i++;
            continue;
        }
        while(St.size()&&St.top()>=3&&St.top()<=4)
        {
            ans.push_back({1,St.top()});
            St.pop();
        }
        St.push(s[i]=='*'?3:4);
        i++;
    }
    while(St.size())
    {
        ans.push_back({1,St.top()});
        St.pop();
    }
//    for(auto it:ans)
//        g<<it.first<<' '<<it.second<<'\n';
    for(auto it:ans)
        if(it.first==0)
            St.push(it.second);
        else
        {
            int poz1=St.top();St.pop();
            int poz2=St.top();St.pop();
            if(it.second==1)St.push(poz2+poz1);
            if(it.second==2)St.push(poz2-poz1);
            if(it.second==3)St.push(poz2*poz1);
            if(it.second==4)St.push(poz2/poz1);
        }
    g<<St.top();
    return 0;
}
