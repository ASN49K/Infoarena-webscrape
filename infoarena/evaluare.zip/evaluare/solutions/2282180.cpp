#include <fstream>

using namespace std;

ifstream fin("data.in");
ofstream fout("data.out");

const int N=100000+5;

int p;
char s[N];

inline int termen();
inline int factor();
inline int expresie();

inline int expresie()
{
    int ans=termen();
    while(s[p]=='+' || s[p]=='-')
    {
        p++;
        if(s[p-1]=='+')
        {
            ans+=termen();
        }
        else
        {
            ans-=termen();
        }
    }
    return ans;
}

inline int termen()
{
    int ans=factor();
    while(s[p]=='*' || s[p]=='/')
    {
        p++;
        if(s[p-1]=='*')
        {
            ans*=factor();
        }
        else
        {
            ans/=factor();
        }
    }
    return ans;
}

inline int factor()
{
    int sgn=1;
    int val;
    while(s[p]=='-')
    {
        sgn*=-1;
        p++;
    }
    if(s[p]=='(')
    {
        p++;
        val=sgn*expresie();
        p++;
        return sgn*val;
    }
    else
    {
        int val=0;
        while('0'<=s[p] && s[p]<='9')
        {
            val=10*val+s[p]-'0';
            p++;
        }
        return sgn*val;
    }
}

int main()
{
    fin.getline(s,N);
    fout<<expresie()<<"\n";
    return 0;
}
