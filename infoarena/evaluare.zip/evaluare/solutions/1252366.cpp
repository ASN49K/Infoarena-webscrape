#include <fstream>

using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char e[100010],*p;
int suma(),produs(),paranteza(),numar();
int main()
{
    fin>>e;
    p=e;
    fout<<suma();
    return 0;
}
int suma()
{
    int rez=produs();
    while(*p=='+'||*p=='-')
    {
        if(*p=='+')
        {
            p++;
            rez+=produs();
        }
        else
        {

            p++;
            rez-=produs();
        }
    }
    return rez;
}

int produs()
{
    int rez=paranteza();
    while(*p=='*'||*p=='/')
    {
        if(*p=='*')
        {
            p++;
            rez*=paranteza();
        }
        else
        {

            p++;
            rez/=paranteza();
        }
    }
     return rez;
}
int paranteza()
{
    if(*p>='0'&&*p<='9')
        return numar();
    p++;
    int rez=suma();
    p++;
    return rez;
}
int numar()
{
    int rez=0;
      while(*p>='0'&&*p<='9')
      {
          rez=10*rez+*p-'0';
          p++;
      }
      return rez;

}


