#include<fstream>
#include<cstring>
#include<cctype>
//evaluarea unei expresii
using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

const int N = 100001;
char s[N];
int p = 0;
int termen();
int expresie();
int factor();
//deci avem o expresie, ea e impartita in termeni, termenii in factori.
//asa ca vom avea 3 subprograme ce apeleaza una pe alta
//subprogramul ~expresie~ va apela subprogramul ~termen~, subprogramul ~termen~ va apela subprogramul ~factor~, iar subprogramul
//~factor~ va apela subprogramul ~expresie~
//se creeaza un circuit

int termen()
{
	int prod = factor();
	if (s[p] == '*' || s[p] == '/')
	{
		if (s[p] == '*')
		{
			p++;
			prod = prod * factor();
		}
		else if (s[p] == '/')
		{
			p++;
			prod = prod / factor();
		}
	}
	return prod;
}
int expresie()
{
	int sum = termen();
	while (s[p] == '+' || s[p] == '-')
	{
		if (s[p] == '+')
		{
			p++;
			sum += termen();
		}
		else if (s[p] == '-')
		{
			p++;
			sum -= termen();
		}
	}
	return sum;
}

int factor()
{
	int semn = 1, val=0;
	while (s[p] == '-')
	{
		p++;
		semn = -semn;
	}
	if (s[p] == '(')
	{
		p++;
		val = expresie();
		p++;
		return semn * val;
	}
	while (isdigit(s[p]))
	{
		val = val * 10 + (s[p] - '0');
		p++;
	}
	return semn * val;
}

int main()
{
	fin.getline(s, N);
	fout << expresie();
	return 0;
}