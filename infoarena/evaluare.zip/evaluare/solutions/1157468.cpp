#include <stdio.h>

using namespace std;
char s[100001];
long i,j,a[100001],n,p;
long calc (long x ,long y)
{
   long i,j,k,nr;
   j=k=0;
   nr=0;
   for (i=x;i<=y;i++)
        if (a[i]==-1000000001)
        {
            if (k==0)
                j=i;
            k++;
        }
        else if (a[i]==-1000000002)
        {
            k--;
            if (k==0)
                nr+=i-j;
        }
   long t=1;
   if ((y-x+1-nr)>0)
        t=y-x+1-nr;
    long b[y-x+1-nr],u;
    b[0]=0;
    u=0;
    for (i=x;i<=y;i++)
        if (a[i]==-1000000001)
        {
            if (k==0)
                j=i;
            k++;
        }
        else if (a[i]==-1000000002)
        {
            k--;
            if (k==0)
                if (b[u]>-1000000005)
                    b[++u]=calc(j+1,i-1);
                else
                    if (b[u]==-1000000005)
                        b[--u]*=calc(j+1,i-1);
                    else
                        b[--u]/=calc(j+1,i-1);
        }
        else
            if (k==0)
                if (b[u]>-1000000005)
                    b[++u]=a[i];
                else
                    if (b[u]==-1000000005)
                        b[--u]*=a[i];
                    else
                        b[--u]/=a[i];
    long sum;
    sum=b[1];
    for (i=2;i+1<=u;i+=2)
        if (b[i]==-1000000004)
            sum-=b[i+1];
        else
            sum+=b[i+1];
    return sum;
}
int main()
{
    freopen ("expresie.in","r",stdin);
    freopen ("expresie.out","w",stdout);
    scanf ("%s",&s[1]);
    j=0;
    for (i=1;s[i]!=0;i++)
    {
        j++;
        if (s[i]=='(')
            a[j]=-1000000001;
        if (s[i]==')')
            a[j]=-1000000002;
        if (s[i]=='+')
            a[j]=-1000000003;
        if (s[i]=='-')
            a[j]=-1000000004;
        if (s[i]=='*')
            a[j]=-1000000005;
        if (s[i]=='/')
            a[j]=-1000000006;
        if (s[i]>='0'&&s[i]<='9')
            {
                if (a[j-1]>0)
                    j--;
                a[j]=a[j]*10+s[i]-'0';
            }
    }
    n=j;
    p=0;
    printf ("%ld",calc (1,n));
    return 0;
}
