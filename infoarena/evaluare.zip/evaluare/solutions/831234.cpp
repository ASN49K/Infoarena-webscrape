#include <cstdio>
#include <cstring>
#define NMAX 100005

using namespace std;

char s [NMAX];
char op [NMAX];
long polo [NMAX];

void Read () {
    fgets (s , NMAX , stdin);
}

long prioritate (char opp) {
    if (opp == '+'|| opp == '-')
        return 1;
    return 2;
}

void Solve () {
    long n , nr = 0 , pr1 , pr2 , a , b ,  i , p = 0 , c;
    char ch;
    bool ok;
    n = strlen (s);
    for (i = 0 ; i < n ; i ++) {
        if (s [i] >= '0' && s [i] <= '9') {
            nr = nr * 10 + s [i] - '0';
            ok = 0;
        }
        else {
                if (ok == 0)
                    polo [++ polo [0]] = nr;
                nr = 0;
                ok = 1;
                ch = s [i];
                pr1 = prioritate (ch);
                if (ch == '(')
                    op [++ p] = ch;
                else
                    if (ch == ')')
                        while (p != 0) {
                            if (op [p] != '(') {
                                a = polo [polo [0] - 1];
                                b = polo [polo [0]];
                                switch (op [p]) {
                                    case '+' : {c = a + b ; break ;}
                                    case '-' : {c = a - b ; break ;}
                                    case '*' : {c = a * b ; break ;}
                                    case '/' : {c = a / b ; break ;}
                                }
                                polo [0] --;
                                polo [polo [0]] = c;
                            }
                            else {--p ; break;}
                            -- p;
                        }
                    else {
                    while (p != 0) {
                        if (op [p] != '(') {
                            pr2 = prioritate (op [p]);
                            if (pr1 <= pr2) {
                                a = polo [polo [0] - 1];
                                b = polo [polo [0]];
                                switch (op [p]) {
                                    case '+' : {c = a + b ; break ;}
                                    case '-' : {c = a - b ; break ;}
                                    case '*' : {c = a * b ; break ;}
                                    case '/' : {c = a / b ; break ;}
                                }
                                polo [0] --;
                                polo [polo [0]] = c;
                                -- p;
                            }
                            else break;
                        }
                        else break;
                    }
                    if (ch != '\n')
                        op [++ p] = ch;
                }
        }
    }
    while (p) {
        a = polo [polo [0] - 1];
        b = polo [polo [0]];
        switch (op [p]) {
            case '+' : {c = a + b ; break ;}
            case '-' : {c = a - b ; break ;}
            case '*' : {c = a * b ; break ;}
            case '/' : {c = a / b ; break ;}
        }
        polo [0] --;
        polo [polo [0]] = c;
        -- p;
    }
    printf ("%ld\n" , polo [2]);
}

int main () {

    freopen ("evaluare.in" , "r" , stdin);
    freopen ("evaluare.out" , "w" , stdout);

    Read ();
    Solve ();
    return 0;
}
