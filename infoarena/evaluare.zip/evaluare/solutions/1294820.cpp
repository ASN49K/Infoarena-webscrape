#include <fstream>
#include<iostream>
using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
string s;
int p=0,q;
int expr();
int termen();
int factor();
int sum;
int expr()
{
    sum=termen();
    while(s[p]=='+' || s[p]=='-')
        if(s[p]=='+')
        {
            p++;
            sum+=termen();
        }
        else
        {
            p++;
            sum-=termen();
        }
    return sum;
}
int termen()
{
    int prod=factor();
    while(s[p]=='*' || s[p]=='/')
        if(s[p]=='*')
        {
            p++;
            prod*=factor();
        }
        else
        {
            p++;
            prod/=factor();
        }
    return prod;
}
int factor()
{
    int semn=1,val=0;
    while(s[p]=='-')
    {
        p++;
        semn=-semn;
    }
    if(s[p]=='(')
    {
        p++;
        val=expr();
        p++;
        return semn*val;
    }
    while(s[p]>='0' && s[p]<='9')
    {
        val=val*10+s[p]-'0';
        p++;
    }
    return semn*val;
}
int main()
{
    fin>>s;
    q=expr();
    fout<<q;
    return 0;
}
