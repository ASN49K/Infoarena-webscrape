// https://www.infoarena.ro/problema/evaluare
#include <bits/stdc++.h>
using namespace std;
#define endl '\n'

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int i=0;
string s;

int expr();
int factor();
int termen();
int constanta();

int expr() {
  int r=termen();
  if (s[i]=='+' || s[i]=='-') {
    ++i;
    if (s[i-1]=='+') r += expr();
    else r -= expr();
  }
  return r;
}

int termen() {
  int r=factor();
  if (s[i]=='*' || s[i]=='/') {
    ++i;
    if (s[i-1]=='*') r *= termen();
    else r /= termen();
  }
  return r;
}

int factor() {
  int r=-1;
  if (s[i]=='(') {
    ++i;
    r = expr();
    ++i;
  } else r = constanta();
  return r;
}

int constanta() {
  int r=0;
  while (isdigit(s[i])) {
    r = r*10+s[i]-'0';
    ++i;
  }
  return r;
}

int main() {
  fin>>s;
  fout<<expr();
}