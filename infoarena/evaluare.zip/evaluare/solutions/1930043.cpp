#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
string s;
int p;
long termen();
long factor();
//+ sau -
long eval() {
    //r=rezultat
    long r = termen();
    while ( s[p]=='+' || s[p]=='-' )
    {
        if(s[p]=='+')
        {
            p++;
            r+=termen();
        }
        else if(s[p]=='-')
        {
            p++;
            r-=termen();
        }
    }
    return r;
}
//* sau /
long termen() {
    long r = factor();
    while ( s[p]=='*' || s[p]=='/' )
    {
        if(s[p]=='*')
        {
            p++;
            r*=factor();
        }
        else if(s[p]=='/')
        {
            p++;
            r/=factor();
        }
    }
    return r;
}
//( ) sau numere
long factor() {
    long r=0;
    if(s[p]=='(')
    {
        p++; // trecem peste '('
        r=eval();
        p++; // trecem peste ')'
    }
    else {
        while ( s[p]>='0' && s[p]<='9' )
        {
            r = r*10 + s[p] - '0';
            p++;
        }
    }
    return r;
}

int main() {
    fin>>s;
    fout<<eval();
    return 0;
}
