#include <cstring>
#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char s[100001];
int n, k = 0;
int solve()
{
    char semn[50001];
    int nr[50001], p = 1;
    while (s[k]!=')' && k<=n) // discutabil
    {
        if (s[k] >= '0' && s[k] <= '9') {
            nr[p] = 0;
        }
        while (s[k] >= '0' && s[k] <= '9')
        {
            nr[p] = nr[p]*10+(s[k]-'0');
            k++;
        }
        if (s[k] == '('){
            k++;
            nr[p] = solve();
        } else if (s[k] == ')') {
            k++;
            break;
        } else {
            semn[p]=s[k];
            k++;
            p++;
        }
    }

    /*
    for(int i=1;i<=p;i++) {
        fout<<nr[i]<<' ';
    }
    fout<<'\n';
    for(int i=1;i<p;i++) {
        fout<<semn[i]<<' ';
    }
    fout<<'\n';
    fout<<'\n';
    */

    for (int i = 1; i<p;) {
        if (semn[i] == '*') {
            nr[i] = nr[i] * nr[i+1];
            for (int j = i + 1; j<p; j++) {
                nr[j] = nr[j+1];
                semn[j-1] = semn[j];
            }
            //nr[p] = 0;
            //semn[p] = '';
            p--;
        } else if (semn[i] == '/') {
            nr[i] = nr[i] / nr[i+1];
            for (int j = i + 1; j<p; j++) {
                nr[j] = nr[j+1];
                semn[j-1] = semn[j];
            }
            //nr[p] = 0;
            //semn[p] = '';
            p--;
        } else {
            i++;
        }
    }
    int val = nr[1];
    for(int i=1; i<p; i++) {
        if (semn[i] == '-') {
            val = val - nr[i+1];
        } else if (semn[i] == '+') {
            val = val + nr[i+1];
        }
    }
    return val;
}
//(s[k] == '*' || s[k] == '/' || s[k] == '+' || s[k] == '-')
int main()
{
    fin.getline(s, 100001);
    n = strlen(s);
    fout<<solve();
    return 0;
}
