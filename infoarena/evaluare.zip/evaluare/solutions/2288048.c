#include<stdio.h>
char s[100000],*p=s;
int E(int l) {
    int x,y;
    if(l==2)
        if(*p=='(')
            p++,x=E(0),p++;
        else
            for(x=0;*p>='0'&&*p<='9';p++)
                x=x*10+*p-'0';
    else
        for(x=E(l+1);!l?(*p=='+'||*p=='-'):(*p=='*'||*p=='/');x=y)
            if(*p=='+')
                p++,y=x+E(l+1);
            else if(*p=='-')
                p++,y=x-E(l+1);
            else if(*p=='*')
                p++,y=x*E(l+1);
            else if(*p=='/')
                p++,y=x/E(l+1);
    return x;
}
int main() {
    freopen("evaluare.in","r",stdin),freopen("evaluare.out","w",stdout),gets(s),printf("%d",E(0));
}
