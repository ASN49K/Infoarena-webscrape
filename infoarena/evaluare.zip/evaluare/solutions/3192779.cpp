#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char s[100005];
int pos;

/// recursivitate indirecta,declaram functiile inainte
int add(); // se ocupa de + si -
int mult(); // se ocupa de * si /
int fact(); // se ocupa de () si factori

int add() {
        int res = mult();
        while (s[pos] == '+' || s[pos] == '-') {
                if (s[pos] == '+') {
                        pos++;
                        res+=mult();
                } else {
                        pos++;
                        res-=mult();
                }
        }
        return res;
}

int mult() {
        int res = fact();
        while(s[pos] == '*' || s[pos] == '/') {
                if (s[pos] == '*') {
                        pos++;
                        res*=fact();
                } else {
                        pos++;
                        res/=fact();
                }
        }
        return res;
}

int fact() {
        int res = 0;
        if (s[pos] == '(') {
                pos++;
                res = add();
                pos++;
        } else {
              while(isdigit(s[pos])) {
                        res*=10;
                        res+=s[pos] - '0';
                        pos++;
              }
        }
        return res;
}

int main() {
        fin>>s;
        fout<<add();
        return 0;
}
