#include <fstream>

using namespace std;

ifstream f("evaluare.in");
ofstream g("evaluare.out");

int f1();
int f2();
int f3();
int ind;
char s[100010];

int f1(){
    int ans = f2();
    while(s[ind] == '+' || s[ind] == '-'){
        if(s[ind] == '+'){
            ++ind;
            ans += f2();
        }
        else{
            ++ind;
            ans -= f2();
        }
    }

    return ans;
}

int f2(){
    int ans = f3();
    while(s[ind] == '*' || s[ind] == '/'){
        if(s[ind] == '*'){
            ++ind;
            ans *= f3();
        }
        else {
            ++ind;
            ans /= f3();
        }
    }

    return ans;
}

int f3(){
    int ans = 0;
    if(s[ind] == '('){
        ++ind;
        ans = f1();
        ++ind;
    }
    else{
        while(s[ind] >= '0' && s[ind] <= '9'){
            ans = ans*10 + (s[ind]-'0');
            ++ind;
        }
    }

    return ans;
}
int main()
{
    f >> s;
    g << f1();
    return 0;
}
