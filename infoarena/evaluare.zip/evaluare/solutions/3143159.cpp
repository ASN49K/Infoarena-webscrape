﻿#include <fstream>

using namespace std;

ifstream cin("evaluare.in");
ofstream cout("evaluare.out");

int n, i;
string s;

int factor();
int Expresie();
int termen();
int numarez();


int numarez()
{
	int simon = 0;
	while (s[i] >= '0' && s[i] <= '9')
	{
		simon = simon * 10 + (s[i] - '0');
		i++;
	}

	return simon;
}

int factor()
{
	int numar = 0;
	if (s[i] == '(')
	{
		i++;
		numar = Expresie();
		i++;
	}
	else numar = numarez();

	return numar;
}

int termen()
{
	int nr = factor();
	while (i < n - 1)
	{
		while (s[i] == '*' || s[i] == '/')
		{
			if (s[i] == '*')
				i++, nr *= factor();
			else i++, nr /= factor();
		}
	}

	return nr;
}


int Expresie()
{
	int rez;
	rez = termen();
	while (s[i] == '+' || s[i] == '-')
	{
		if (s[i] == '+')
			i++,rez += termen();
		else i++,rez -= termen();
	}
	return rez;
}

int main()
{
	cin >> s;
	n = s.size();
	cout << Expresie();
}