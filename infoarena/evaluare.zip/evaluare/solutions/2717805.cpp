#include <iostream>
#include <fstream>

using namespace std;
string file = "evaluare";
ifstream fin( file + ".in" );
ofstream fout( file + ".out" );
//grad1 + || -
//grad2 / || *
//grad3 ( || numere
int grad1(), grad2(), grad3(), i;
string s;
inline int grad1(){
    int r = grad2();
    while(s[i] == '+' || s[i] == '-'){
        if(s[i] == '+'){
            i++;
            r+=grad2();
        } else if (s[i] == '-'){
            i++;
            r+=grad2();
        }
    }
    return r;
}
inline int grad2(){
    int r = grad3();
    while(s[i] == '/' || s[i] == '*'){
        if(s[i] == '*') {
            i++;
            r*=grad3();
        } else if( s[i] == '/' ){
            i++;
            r/=grad3();
        }
    }
    return r;
}

inline int grad3(){
    int r = 0;
    if(s[i] == '('){
        i++;
        r = grad1();
        i++;
        return r;
    }
    while(s[i] >= '0' && s[i] <= '9')
        r = r * 10 + s[i++] - '0';
    return r;
}

int main(){
    fin>>s;
    fout<<grad1();
    return 0;
}
