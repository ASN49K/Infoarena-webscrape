#include<stdio.h>
#define infile "evaluare.in"
#define outfile "evaluare.out"
#define nmax (100*1001)
struct nod
{
	int val; //valoarea nodului
	char op; //operator
	int s,d; //pozitii pentru stanga si dreapta
} n[nmax]; //nodurile arborelui
char e[nmax]; //expresia
char *p=e; //pointer catre expresie
int nr; //numarul de ordine al ultimului nod folosit
int x; //radacina arborelui
int val; //valoarea expresiei

int expresie();
int termen();
int factor();

int expresie()
{
	int i,j;
	i=termen();
	while(*p=='+' || *p=='-') //daca nu s-a terminat expresia
	{
		nr++,j=nr; //nod pentru operatorul dintre expresii
		n[j].op=*p,p++; //operatorul
		n[j].s=i; //expresia din partea stanga
		n[j].d=termen(); //cealalta expresie
		i=j; //se schimba radacina expresiei
	}
	return i; //returnam radacina expresiei
}

int termen()
{
	int i,j;
	i=factor(); //termenul are cel putin un factor
	while(*p=='*' || *p=='/')
	{ //daca termenul mai are macar un factor
		nr++,j=nr; //mai facem un nod pentru operatorul dintre cei doi factori
		n[j].op=*p,p++; //operatorul
		n[j].s=i; //partea stanga
		n[j].d=factor(); //partea dreapta poate fi tot un termen
		i=j; //se schimba radacina termenului
	}
	return i; //radacina termenului
}

int factor()
{
	int i,j;
	if(*p=='(')
	{ //daca avem o expresie
		p++;
		i=expresie();
		p++;
	}
	else
	{ //daca avem un factor simplu
		nr++,i=nr;
		if(*p=='-') j=1,p++; else j=0;
		while(*p>='0'&&*p<='9') n[i].val=n[i].val*10+*p-'0',p++; //valoarea factorului
		if(j) n[i].val*=(-1);
	}
	return i; //returnam radacina factorului
}

int eval(int x)
{
	switch(n[x].op)
	{
		case '+': return eval(n[x].s) + eval(n[x].d);
		case '-': return eval(n[x].s) - eval(n[x].d);
		case '*': return eval(n[x].s) * eval(n[x].d);
		case '/': return eval(n[x].s) / eval(n[x].d);
		default: return n[x].val;
	}
}

void read()
{
	fgets(e,nmax,stdin);
}

void init()
{
	x=expresie(); //construim arborele
}

void solve()
{
	val=eval(x); //calculam
}

void write()
{
	printf("%d\n",val);
}

int main()
{
	freopen(infile,"r",stdin);
	freopen(outfile,"w",stdout);
	
	read();
	init();
	solve();
	write();
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}