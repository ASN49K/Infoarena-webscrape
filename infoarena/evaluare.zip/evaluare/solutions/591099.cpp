# include <cstdio>
# include <cstring>
# include <cmath>
# include <cstdlib>

#define MAX  100010
#define IN   "evaluare.in"
#define OUT  "evaluare.out"

char S[MAX], *p = S;

int subexp();
int fact();
int solve();
int f_abs() ;
int g() ;
int put() ;

int main() {
    freopen(IN,"r",stdin);
    freopen(OUT,"w",stdout);

    fgets(S, MAX, stdin);
    printf("%d",solve());

    return 0;
}

int solve() {
    int r = subexp();

    while ( *p == '+' || *p == '-' )
        if ( *p == '+' )
            ++p, r += subexp() ;
        else if ( *p == '-' )
            ++p, r -= subexp() ;

    return r;
}

int subexp() {
    int r = put();

    while ( *p == '*' || *p == '/' ) {
        if ( *p == '*' )
            ++p, r *= put() ;
        else if ( *p == '/' )
            ++p, r /= put() ;
    }

    return r;
}

int fact() {
    int r = 0 ;
    if ( *p == '(' ) {
        ++p, r = solve(), ++p;
    } else if ( *p == '|' ) {
        ++p, r = f_abs(), ++p ;
    } else if ( *p == 'g' ) {
        p += 2, r = g(), ++p ;
    } else {
        for ( ; *p >= '0' && *p <= '9' ; ++p ) {
            r = r * 10 + *p - '0';
        }
    }

    return r;
}

int put() {
    int r = fact() ;

    while ( *p == '^' ) {
        ++p, r = (int) pow (1.0 * r, 1.0 * put ());
    }
    return r ;
}

int f_abs() {
    int r = solve () ;
    return abs (r) ;
}

int g() {
    int r, rr ;
    r = solve (), ++p, rr = solve ();
    return r + rr ;
}

