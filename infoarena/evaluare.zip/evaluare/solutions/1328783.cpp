#include <iostream>
#include <cstdio>
#include <cstring>
#include <stack>

using namespace std;

#define mmx 100010

stack <char> sc ;
stack <int> si ;
char s[mmx] , pol[mmx][10] ;
int x , p ;

void citire() ;
void polonez() ;
void calcul() ;

int main()
{
    freopen( "evaluare.in" , "r" , stdin ) ;
    freopen( "evaluare.out" , "w" , stdout ) ;
    citire() ;
    polonez() ;
    calcul() ;
    return 0;
}

void citire()
{
    scanf( "%s" , s ) ;
    x = strlen(s) ;
    s[x] = ')' ;
    x ++ ;
}

int val( char c )
{
    if ( c == '(' )
        return -1 ;
    if ( c == '+' || c == '-' )
        return 0 ;
    if ( c == '*' || c == '/' )
        return 1 ;
}

void polonez()
{
    sc.push('(') ;
    for ( int i = 0 ; i < x ; i ++ )
        if ( s[i] == '(' )
            sc.push('(') ;
        else if ( s[i] == ')' )
        {
            while ( not sc.empty() && sc.top() != '(' )
            {
                pol[p++][1] = sc.top() ;
                sc.pop() ;
            }
            sc.pop() ;
        }
        else if ( isdigit(s[i]) )
        {
            while ( isdigit(s[i]) )
                pol[p][++pol[p][0]] = s[i++] ;
            p ++ ;
            i -- ;
        }
        else
        {
            while ( not sc.empty() && val(s[i]) <= val(sc.top()) )
            {
                pol[p++][1] = sc.top() ;
                sc.pop() ;
            }
            sc.push(s[i]) ;
        }
}

int vll( int a , int b , char h )
{
    if ( h == '+' )
        return a + b ;
    if ( h == '-' )
        return b - a ;
    if ( h == '*' )
        return a * b ;
    if ( h == '/' )
        return b / a ;
}

void calcul()
{
    for ( int i = 0 ; i < p ; i ++ )
        if ( pol[i][0] == 0 )
        {
            int a = si.top() ;
            si.pop() ;
            int b = si.top() ;
            si.pop() ;
            si.push( vll( a , b , pol[i][1] ) ) ;
        }
        else
        {
            int a = 0 ;
            for ( int j = 1 ; j <= pol[i][0] ; j ++ )
            {
                a *= 10 ;
                a += (int) pol[i][j] - 48 ;
            }
            si.push(a) ;
        }
    printf( "%d\n" , si.top() ) ;
}




