#include <cstdio>
#include <cctype>
using namespace std;

const int nmx = 100005;

char s[nmx], *p;

int eval();
int termen();
int factor();

int eval() {
    int rez = termen();
    while (*p == '+' || *p == '-') {
        if(*p == '+') {
            ++ p;
            rez += termen();
        } else {
            ++ p;
            rez -= termen();
        }
    }
    return rez;
}

int termen() {
    int rez = factor();
    while(*p == '/' || *p == '*'){
        if(*p == '/'){
            ++ p;
            rez /= factor();
        }
        else{
            ++ p;
            rez *= factor();
        }
    }
    return rez;
}

int factor() {
    int rez = 0;
    if(*p == '(') {
        ++ p;
        rez = eval();
        ++ p;
    } else
        while(*p <= '9' && *p >= '0') {
            rez = rez * 10 + *p - 48;
            ++ p;
        }
    return rez;
}

int main() {
    freopen("evaluare.in", "r", stdin);
    freopen("evaluare.out", "w", stdout);
    scanf("%s", s);
    p = s;
    printf("%d", eval());
    return 0;
}
