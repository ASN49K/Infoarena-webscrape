#include <bits/stdc++.h>

using namespace std;
ifstream f("evaluare.in");
ofstream g("evaluare.out");
vector<int> x;
char s[100010],*p;
int suma(),produs(),paranteza(),numar();
int main()
{
    f>>s;p=s;
    g<<suma();
    return 0;
}
int suma()
{
    int rez=produs();
    while(*p=='+'||*p=='-')
    {
        if(*p=='+'){p++;rez+=produs();}
        else       {p++;rez-=produs();}
    }
    return rez;
}
int produs()
{
    int rez=paranteza();
    while(*p=='*'||*p=='/')
    {
        if(*p=='*'){p++;rez*=paranteza();}
        else       {p++;rez/=paranteza();}
    }
    return rez;
}
int paranteza()
{
    int rez;
    if(*p=='('){p++;rez=suma();p++;}
    else rez=numar();
    return rez;
}
int numar()
{
    int rez=0;
    while(isdigit(*p))
    {
        rez=10*rez+*p-'0';
        p++;
    }
    return rez;
}
