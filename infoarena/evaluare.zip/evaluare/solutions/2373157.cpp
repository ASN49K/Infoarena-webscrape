#include <bits/stdc++.h>

using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char s[100005], pr[4][4]={"+-", "*/", "^", ""}, *p=s;

int eval(int a, int b, char c)
{
    switch(c)
    {
        case '+':
            return a+b;
        case '-':
            return a-b;
        case '*':
            return a*b;
        case '/':
            return a/b;
    }
}

int expr(int lvl)
{
    int x, y;
    if(lvl==2)
    {
        if(*p=='(')
        {
            p++;
            x=expr(0);
            p++;
        }
        else for(x=0; *p>='0' && *p<='9'; p++)
            x=x*10+*p-'0';
    }
    else for(x=expr(lvl+1); strchr(pr[lvl], *p); x=y)
        y=eval(x, expr(lvl+1), *p++);
    return x;
}

int main()
{
    fin.getline(s, 100005);
    fout << expr(0);
    return 0;
}
