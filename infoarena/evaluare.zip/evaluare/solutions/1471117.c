#include<stdio.h>
#include<stdlib.h>
char *s;
int E(char *&p) {
	int T(char*&);
	char c;
	int w,r=T(p);
	if(!(*p))
    	return r;
	while((c=*p)=='+'||c=='-')
		w=T(++p),r=(c=='+'?(r+w):(r-w));
	return r;
}
int T(char *&p) {
	int F(char*&);
	char c;
	int w,r=F(p);
	if(!(*p))
    	return r;
	while((c=*p)=='*'||c=='/')
      	w=F(++p),r=(c=='*'?(r*w):(r/w));
	return r;
}
int F(char *&p) {
	int r;
	if(*p=='(') {
		r=E(++p),p++;
      	return r;
	}
	return (int)strtod(p,&p);
}
int main() {
	freopen("evaluare.in","r",stdin),freopen("evaluare.out","w",stdout);
	s=(char*)malloc(100005*sizeof(char));
	gets(s),printf("%d",E(s));
}
