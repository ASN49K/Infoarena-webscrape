// Infoarena. Arhiva Educationala. Evaluarea unei Expresii.
// http://www.infoarena.ro/problema/evaluare

#include<iostream>
#include<fstream>
#include<string>
using namespace std;


char E[100001],*p=E;

int evaluate();
int termen();
int factor();

int main(){
    freopen("evaluare.in","r",stdin);
    freopen("evaluare.out","w",stdout);

    cin>>E;

    cout<<evaluate();
}

int evaluate(){
    int r=termen();
    while(*p=='+' || *p=='-'){
        if(*p=='+') {
            p++;
            r+=termen();
        }
        if(*p=='-'){
            p++;
            r-=termen();
        }
    }

    return r;
}

int termen(){
    int r=factor();
    while(*p=='*' || *p=='/'){
        if(*p=='*'){
            ++p;
            r*=factor();
        }
        if(*p=='/'){
            ++p;
            r/=factor();
        }
    }
    return r;
}
int factor(){
    int r=0;
    if(*p=='('){   //Avem o subexpresie
        ++p;       //Sarim peste '('
        r=evaluate();
        ++p;       //Sarim peste ')'
    }else{
        while(*p>='0' && *p<='9'){
            r=10*r+(*p-'0');
            ++p;
        }
    }
    return r;
}





