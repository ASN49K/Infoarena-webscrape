#include <fstream>
#include <cstring>
#include <cctype>
using namespace std;
ifstream cin("evaluare.in");
ofstream cout("evaluare.out");
const int nm=100005;
int polo[nm],vfpolo,op[nm],vfop,n;
char s[nm];
int main()
{
    cin.getline(s,nm);
    n=strlen(s);
    for(int i=0;i<n;i++)
    {
        if(isdigit(s[i]))
        {
            if(i==0)
            {
                polo[++vfpolo]=s[i]-'0';
                continue;
            }
            if(isdigit(s[i-1]))
                polo[vfpolo]=polo[vfpolo]*10+s[i]-'0';
            else
                polo[++vfpolo]=s[i]-'0';
        }
        if(s[i]=='(')
        {
            op[++vfop]='(';
            continue;
        }
        if(s[i]==')')
        {
            while(op[vfop]!='(')
            {
                vfpolo--;
                if(op[vfop]=='+')
                    polo[vfpolo]=polo[vfpolo]+polo[vfpolo+1];
                if(op[vfop]=='-')
                    polo[vfpolo]=polo[vfpolo]-polo[vfpolo+1];
                if(op[vfop]=='*')
                    polo[vfpolo]=polo[vfpolo]*polo[vfpolo+1];
                if(op[vfop]=='/')
                    polo[vfpolo]=polo[vfpolo]/polo[vfpolo+1];
                vfop--;
            }
            vfop--;
            continue;
        }
        if(s[i]=='*' or s[i]=='/')
        {
            while(vfop>0 and (op[vfop]=='*' or op[vfop]=='/'))
            {
                vfpolo--;
                if(op[vfop]=='*')
                    polo[vfpolo]=polo[vfpolo]*polo[vfpolo+1];
                if(op[vfop]=='/')
                    polo[vfpolo]=polo[vfpolo]/polo[vfpolo+1];
                vfop--;
            }
            op[++vfop]=s[i];
            continue;
        }
        if(s[i]=='+' or s[i]=='-')
        {
            while(vfop>0 and op[vfop]!='(')
            {
                vfpolo--;
                if(op[vfop]=='+')
                    polo[vfpolo]=polo[vfpolo]+polo[vfpolo+1];
                if(op[vfop]=='-')
                    polo[vfpolo]=polo[vfpolo]-polo[vfpolo+1];
                if(op[vfop]=='*')
                    polo[vfpolo]=polo[vfpolo]*polo[vfpolo+1];
                if(op[vfop]=='/')
                    polo[vfpolo]=polo[vfpolo]/polo[vfpolo+1];
                vfop--;
            }
            op[++vfop]=s[i];
        }
    }
    while(vfop)
    {
        vfpolo--;
        if(op[vfop]=='+')
            polo[vfpolo]=polo[vfpolo]+polo[vfpolo+1];
        if(op[vfop]=='-')
            polo[vfpolo]=polo[vfpolo]-polo[vfpolo+1];
        if(op[vfop]=='*')
            polo[vfpolo]=polo[vfpolo]*polo[vfpolo+1];
        if(op[vfop]=='/')
            polo[vfpolo]=polo[vfpolo]/polo[vfpolo+1];
        vfop--;
    }
    cout<<polo[1];
    return 0;
}
/**
4*3+2

**/
