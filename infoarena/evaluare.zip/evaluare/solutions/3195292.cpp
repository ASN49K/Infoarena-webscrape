#include <fstream>


using namespace std;
char s[100005];
int ind = 0;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
int expresie();
int termen();
int factor();
int nr();
int expresie(){
    int aux  = termen();
    while(s[ind]=='+' || s[ind]=='-'){
        if(s[ind]=='+')
            ind++,aux+=termen();
        else
            ind++,aux-=termen();
    }
    return aux;
}
int termen(){
    int aux = factor();
    while(s[ind]=='*' || s[ind]=='/'){
        if(s[ind]=='*')
            ind++,aux*=factor();
        else
            ind++,aux/=factor();
    }
    return aux;
}
int factor(){
    int rez = 0;
    if(s[ind]=='('){
        ind++;
        rez = expresie();
        ind++;
        return rez;
       }
    else{ /// am numar
        int nr = 0;
        while(s[ind]>='0' && s[ind]<='9'){
            nr=nr*10+(s[ind]-'0'),ind++;
        }
        return nr;
    }
}
int main(){
    fin>>s;
    fout<<expresie();

    return 0;
}
