#include <iostream>
#include <fstream>
#define inFile "evaluare.in"
#define outFile "evaluare.out"
#define N 100003


using namespace std;

char sir[N], poz;

void read();
void write();
int eval();
int expr();
int fact();

int main()
{
    read();
    write();
}

int eval()
{
    int num = expr();
    while(sir[poz] == '+' || sir[poz] == '-')
        switch(sir[poz]){
            case '+' :  poz++;
                        num += expr();
                        break;
            case '-' :  poz++;
                        num -= expr();
                        break;
        }
    return num;
}

int expr()
{
    int num = fact();
    while(sir[poz] == '*' || sir[poz] == '/')
        switch(sir[poz]){
            case '*' :  poz++;
                        num *= fact();
                        break;
            case '/' :  poz++;
                        num /= fact();
                        break;
        }
    return num;
}

int fact()
{
    int num = 0;
    if(sir[poz] == '('){
        poz++;
        num = eval();
        poz++;
    }else{
        while(sir[poz] >= '0' && sir[poz] <= '9'){
            num = num * 10 + sir[poz] - '0';
            poz++;
        }
    }
    return num;
}

void read()
{
    ifstream fin(inFile);
    fin>>sir;
    fin.close();
}

void write()
{
    ofstream fout(outFile);
    fout<<eval();
    fout.close();
}
