
#include <fstream>
#include <iostream>
using namespace std;

ifstream fin ("evaluare.in");
ofstream fout ("evaluare.out");

int NR, n;
char x, sir_rez[100001], stiva[100001];
unsigned long long rezultat, numere[100001], st[100001];

int operatie(int x, int y, char op)
{
    if(op == '+')
        return x+y;
    if(op == '*')
        return x*y;
    if(op == '/')
        return x/y;
    if (op == '-')
        return x-y;
    return 0;
}


int main() {
    
    int primul, nr, k, nrsemne, i;
    k = NR = n = 0;
    nr = 0;
    rezultat = 0;
    primul = 1;
    
    x = fin.get();
    while ((x >= '0' && x <= '9') || x == '+'||x == '-'|| x == '/' || x == '*' || x == '('|| x == ')')
    {
        if(x >= '0'&& x<= '9')
            nr = nr * 10 + x - '0';
        else
        {
            if (x == '+'|| x == '-'|| x == '/' || x == '*')
            {
                //adaugam ultimul numar
                if (nr > 0 && primul == 0) //exista nr. inainte si nu e primul
                {
                    n++;
                    sir_rez[n] = '_';
                    cout <<nr;
                    NR++;
                    numere[NR] = nr;
                    if((stiva[k] == '-'|| stiva[k] == '+') && (x == '*'|| x== '/'))
                    {//au prioritate * si /
                        primul = 1;
                        k++;
                        stiva[k] = x;
                        cout <<sir_rez[n];
                    }
                    else
                    {
                        n++;
                        sir_rez[n] = stiva[k];
                        cout <<sir_rez[n];
                        stiva[k] = x;
                    }
                    nr = 0;
                }
                else //este primul numar
                {
                    
                    if(nr > 0)
                    {
                        k++;
                        stiva[k] = x;
                        n++;
                        sir_rez[n] = '_';
                        cout <<nr;
                        NR++;
                        numere[NR] = nr;
                        primul = 0;
                        nr = 0;
                    }
                    else //nu exista niciun numar, a ramas un semn de dinaintea unei paranteze
                    {
                        if((stiva[k] == '*'|| stiva[k] == '/') && (x == '-'|| x== '+'))
                        {//are prioritate semnul de dinainte
                            n++;
                            sir_rez[n] = stiva[k];
                            stiva[k] = x;
                        }
                        else
                        {
                            k++;
                            stiva[k] = x;
                        }
                    }
                }
            }
            else
            {
                if(x == '(')
                {
                    primul = 1;
                    k++;
                    stiva[k] = x;
                    if (nr > 0)//adaugam numarul de dinaintea parantezei
                    {
                        n++;
                        sir_rez[n] = '_';
                        cout <<nr;
                        NR++;
                        numere[NR] = nr;
                        n++;
                        sir_rez[n] = stiva[k-1];
                        cout <<sir_rez[n];
                        nr = 0;
                    }
                }
                else //x == ')'
                {
                    if (nr > 0)//adaugam numarul de dinaintea parantezei
                    {
                        n++;
                        sir_rez[n] = '_';
                        cout <<nr;
                        NR++;
                        numere[NR] = nr;
                        n++;
                        sir_rez[n] = stiva[k];
                        cout <<sir_rez[n];
                        nr = 0;
                        k--;
                    }
                    //scadem din stiva semnele pana la prima '('
                    while (stiva[k] != '(')
                    {
                        n++;
                        sir_rez[n] = x;
                        cout <<sir_rez[n];
                        k--;
                    }
                    //adaugam la sirul rezultat semnul care era inaintea parantezei
                    k--;
                    //            if(k>=1)
                    //            {
                    //                n++;
                    //                sir_rez[n] = stiva[k];
                    //                cout << sir_rez[n];
                    //                k--;
                    //            }
                }
            }
        }
        x = fin.get();
    }
    if (nr > 0)//adaugam numarul de dinaintea parantezei
    {
        n++;
        sir_rez[n] = '_';
        cout <<nr;
        NR++;
        numere[NR] = nr;
        n++;
        sir_rez[n] = stiva[k];
        k--;
        cout <<sir_rez[n];
    }
    while(k>0)//adaugam la final semnele ramase nefolosite in stiva
    {
        n++;
        sir_rez[n] = stiva[k];
        k--;
    }
    
    nrsemne = 0;
    k = 1;
    st[1] = numere[1];
    i = 2;
    nr = 0;
    while (i<= n)
    {
        if(sir_rez[i] == '_')//numar
        {
            k++;
            st[k] = numere[i-nrsemne];
        }
        else
        {
            st[k-1] = operatie(st[k-1], st[k], sir_rez[i]);
            k--;
            nrsemne++;
        }
        i++;
    }
    fout << st[1];
    
    return 0;
}
