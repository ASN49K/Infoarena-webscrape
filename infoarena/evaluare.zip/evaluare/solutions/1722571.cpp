#include <fstream>
#include <string.h>
#include <iostream>
#define DIM 100005
using namespace std;

char s[DIM];
int p,len;

long long int getTerm();
long long int getFact();

long long int eval() {
    long long int ans=getTerm();
    while(s[p]=='+'||s[p]=='-') {
        p++;
        if(s[p-1]=='+')
            ans+=getTerm();
        else
            ans-=getTerm();
    }
    p++;
    return ans;
}

long long int getTerm() {
    long long int term=getFact();
    while(s[p]=='*'||s[p]=='/') {
        p++;
        if(s[p-1]=='*')
            term*=getFact();
        else
            term/=getFact();
    }
    return term;
}

long long int getFact() {
    if(s[p]=='(') {
        p++;
        return eval();
    }
    long long int fact=0;
    while(s[p]>='0'&&s[p]<='9')
        fact=fact*10+(s[p]-'0'),p++;
    return fact;
}

int main()
{
    ifstream fin("evaluare.in");
    ofstream fout("evaluare.out");
    fin.getline(s,DIM);
    len=strlen(s);
    fout<<eval();
    return 0;
}
