#include <fstream>
#include <cstring>
using namespace std;
int n;
int eval();
int factor();
int termen();
char s[100010],*p;
int main()
{
    ifstream f("evaluare.in");
    ofstream g("evaluare.out");
    f.get(s,100010);
    p=s;
    n=eval();
    g<<n;
    f.close();
    g.close();
    return 0;
}
int eval()
{
    int r;
    r=termen();
    while (*p=='+' || *p=='-')
        if (*p=='+')
        {
            p++;
            r+=termen();
        }
        else
        {
            p++;
            r=-termen();
        }
    return r;
}
int termen()
{
    int r;
    r=factor();
    while (*p=='*' || *p=='/')
        if (*p=='*')
        {
            p++;
            r*=factor();
        }
        else
        {
            p++;
            r/=factor();
        }
    return r;
}
int factor()
{
    int r=0;
    if (*p=='(')
    {
        p++;
        r=eval();
        p++;
    }
    else
    {

            while('0'<=*p && *p<='9')
            {
                r*=10;
                r+=*p-'0';
                ++p;
            }

    }
    return r;
}
