#include <stdio.h>
#include <ctype.h>

char c;
int E ();
int F () {
  int ans = 0;
  if (c == '(') {
    c=getchar_unlocked();
    ans=E();
    c=getchar_unlocked();
  }
  else
    while (isdigit(c)) {
      ans = (ans<<3) + (ans<<1) + c - '0';
      c=getchar_unlocked();
    }
  return ans;
}

int T () {
  int ans = F();
  while (c == '*' || c == '/')
    if (c == '*') {
      c=getchar_unlocked();
      ans *= F();
    }
    else {
      c=getchar_unlocked();
      ans /= F();
    }
  return ans;
}

int E () {
  int ans = T();
  while (c == '+' || c == '-')
    if (c== '+') {
      c=getchar_unlocked();
      ans += T();
    }
    else {
      c=getchar_unlocked();
      ans -= T();
    }
  return ans;
}

int main (void) {
  c=getchar_unlocked();
  printf("%d", E());
  return 0;
}
