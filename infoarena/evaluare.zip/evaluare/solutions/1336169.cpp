#include <fstream>
#include <cstring>
#define NR 100005
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

char a[NR],op[NR/2];
int v[NR/2];
void trag(int v[],int lg)
{
    for(int i=0;i<lg;i++)
        v[i]=v[i+1];
}
int calc(char b[])
{
    int lg=1,d=strlen(b);
    char aux[lg];
    if(b[0]!='-')
        op[1]='+';
    v[1]=0;
    for(int i=0;i<d;i++)
        if(b[i]>='0' && b[i]<='9')
            v[lg]=v[lg]*10+b[i]-'0';
        else
            op[++lg]=b[i],v[lg]=0;
    if(op[1]=='-')  v[1]=-v[1];
    op[0]='+';
    for(int i=2;i<=lg;i++)
        if(op[i]=='*')
        {
            v[i-1]=v[i-1]*v[i];
            strcpy(aux,op+i+1);
            op[i]='\0';
            strcat(op,aux);
            trag(v+i,lg);
            lg--; i--;
        }
        else
            if(op[i]=='/')
            {
                v[i-1]=v[i-1]/v[i];
                strcpy(aux,op+i+1);
                op[i]='\0';
                strcat(op,aux);
                trag(v+i,lg);
                lg--; i--;
            }
    for(int i=2;i<=lg;i++)
    {
        if(op[i]=='+')
            v[1]=v[1]+v[i];
        else
            v[1]=v[1]-v[i];
    }
    return v[1];
}
void convert(int n,char aux[])
{
    int p=0;
    while(n!=0)
        aux[p++]=(n%10)+'0',n=n/10;
    for(int i=0;i<p/2;i++)
        aux[i]=aux[p-i];
    aux[p]='\0';
}
int changeP(char b[])
{
    char k[NR],aux[20];
    int ok,j,d=strlen(b);
    for(int i=0;i<d;i++)
            if(b[i]=='(')
               {
                   ok=1;
                   for(j=i+1;j<d;j++)
                    if(b[j]=='(') ok++;
                    else
                        if(b[j]==')')
                        {
                            ok--;
                            if(ok==0) break;
                        }
                    b[j]='\0';
                    strcpy(k,b+i+1);
                    b[j]=')';
                    int n=changeP(k);
                    convert(n,aux);
                    strcpy(k,b+j+1);
                    b[i]='\0';
                    strcat(b,aux);
                    strcat(b,k);
                    d=strlen(aux)+strlen(k);
               }
    return calc(b);
}
int main()
{
    fin.getline(a,NR);
    fout<<changeP(a)<<'\n';
    return 0;
}
