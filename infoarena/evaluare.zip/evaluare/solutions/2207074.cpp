#include <iostream>
#include <math.h>
#include <fstream>

using namespace std;

ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int to_digit(char c)
{
	return c - '0';
}

int to_int(const string & str, int lt, int rt)
{
	int r = 0;
	for(int i = lt; i <= rt; i++){
		r *= 10;
		r += to_digit(str[i]);
	}
	return r;
}

int eval(const string & str, int lt = 0, int rt = -1)
{
	if(rt == -1){
		rt = str.size() - 1;
	}
	int depth = 0;
	for(int i = rt; i >= lt; i--){
		if(str[i] == ')'){
			depth++;
		}else if(str[i] == '('){
			depth--;
		}
		if(depth == 0){
			if(str[i] == '+'){
				return eval(str, lt, i - 1) + eval(str, i + 1, rt);
			}else if(str[i] == '-'){
				return eval(str, lt, i - 1) - eval(str, i + 1, rt);
			}
		}
	}
	for(int i = rt; i >= lt; i--){
		if(str[i] == ')'){
			depth++;
		}else if(str[i] == '('){
			depth--;
		}
		if(depth == 0){
			if(str[i] == '*'){
				return eval(str, lt, i - 1) * eval(str, i + 1, rt);
			}else if(str[i] == '/'){
				return eval(str, lt, i - 1) / eval(str, i + 1, rt);
			}
		}
	}
	for(int i = lt; i <= rt; i++){
		if(str[i] == '('){
			depth++;
		}else if(str[i] == ')'){
			depth--;
		}
		if(depth == 0){
			if(str[i] == '^'){
				return pow(eval(str, lt, i - 1), eval(str, i + 1, rt));
			}
		}
	}
	if(str[lt] == '(' && str[rt] == ')'){
		return eval(str, lt + 1, rt - 1);
	}else{
		return to_int(str, lt, rt);
	}
}

int main()
{
	cerr << "your mom gay";
	string str;
	fin >> str;
	fout << eval(str);
}