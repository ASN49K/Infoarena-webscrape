#include <fstream>
#include <algorithm>
#include <cstring>
using namespace std;

const int LUNGIME_SIR=100002;

/*
1 = +
2 = -
3 = *
4 = /
*/

/*
Prioritate:
+=1;
-=1;
*,/=2;
*/

struct semn
{
    int semn;
    int st;
    int dr;
    int prioritate;
};

bool comp(const semn &a, const semn &b)
{
    if(a.prioritate<b.prioritate)
    {
        return false;
    }
    return true;
}


int main()
{
    ifstream f("evaluare.in");
    ofstream g("evaluare.out");

    char expresie[LUNGIME_SIR];
    f.get(expresie,LUNGIME_SIR);

    int i;
    int nrNumere=0;
    int nrSemne=0;
    int nr_paranteze_active=0;
    int numere[1001];
    semn semne[1001];
    bool in_interior_numar=0;
    int rez=0;
    for(i=0;i<strlen(expresie);i++)
    {
        if(expresie[i]>='0' && expresie[i]<='9')
        {
            if(!in_interior_numar)
            {
                nrNumere++;
                in_interior_numar=1;
            }
            numere[nrNumere]=numere[nrNumere]*10+((int)expresie[i]-48);
        }
        else
        {
            in_interior_numar=0;
            if(expresie[i]=='+')
            {
                nrSemne++;
                semne[nrSemne].prioritate=1+10*(nr_paranteze_active);
                semne[nrSemne].semn=1;
                semne[nrSemne].st=nrNumere;
                semne[nrSemne].dr=nrNumere+1;
            }
            else
            if(expresie[i]=='-')
            {
                nrSemne++;
                semne[nrSemne].prioritate=1+10*(nr_paranteze_active);
                semne[nrSemne].semn=2;
                semne[nrSemne].st=nrNumere;
                semne[nrSemne].dr=nrNumere+1;
            }
            else
            if(expresie[i]=='*')
            {
                nrSemne++;
                semne[nrSemne].prioritate=2+10*(nr_paranteze_active);
                semne[nrSemne].semn=3;
                semne[nrSemne].st=nrNumere;
                semne[nrSemne].dr=nrNumere+1;
            }
            else
            if(expresie[i]=='/')
            {
                nrSemne++;
                semne[nrSemne].prioritate=2+10*(nr_paranteze_active);
                semne[nrSemne].semn=4;
                semne[nrSemne].st=nrNumere;
                semne[nrSemne].dr=nrNumere+1;
            }
            else
            if(expresie[i]=='(')
            {
                nr_paranteze_active++;
            }
            else
            if(expresie[i]==')')
            {
                nr_paranteze_active--;
            }
        }
    }

    sort(semne+1,semne+nrSemne+1,comp);

    for(i=1;i<=nrSemne;i++)
    {
        if(semne[i].semn==1)
        {
            numere[semne[i].st]+=numere[semne[i].dr];
            numere[semne[i].dr]=numere[semne[i].st];
        }
        else
        if(semne[i].semn==2)
        {
            numere[semne[i].st]-=numere[semne[i].dr];
            numere[semne[i].dr]=numere[semne[i].st];
        }
        else
        if(semne[i].semn==3)
        {
            numere[semne[i].st]*=numere[semne[i].dr];
            numere[semne[i].dr]=numere[semne[i].st];
        }
        else
        if(semne[i].semn==4)
        {
            numere[semne[i].st]/=numere[semne[i].dr];
            numere[semne[i].dr]=numere[semne[i].st];
        }
    }

    g<<numere[semne[nrSemne].st];

    return 0;
}
