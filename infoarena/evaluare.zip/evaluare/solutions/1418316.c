#include <stdio.h>
#include <stdlib.h>
FILE*fi,*fout;
char a;
inline int num(){
    int nr=0;
    while(a>='0'&&a<='9'){
        nr=nr*10+a-'0';
        a=fgetc(fi);
    }
    return nr;
}
int fact(){
    int x;
    if(a>='0'&&a<='9')
        x=num();
    else
        if(a=='('){
           a=fgetc(fi);
           x=E();
           a=fgetc(fi);
        }
        else
            if(a=='+'){
                a=fgetc(fi);
                x=x+fact();
            }
            else{
                a=fgetc(fi);
                x=x-fact();
            }
    return x;
}
int term(){
    int x;
    x=fact();
    while(a=='*'||a=='/')
        if(a=='*'){
            a=fgetc(fi);
            x=x*fact();
        }
        else{
            a=fgetc(fi);
            x=x/fact();
        }
    return x;
}
int E(){
    int x;
    x=term();
    while(a=='+'||a=='-')
        if(a=='+'){
            a=fgetc(fi);
            x=x+term();
        }
        else{
            a=fgetc(fi);
            x=x-term();
        }
    return x;
}
int main(){
    fi=fopen("evaluare.in" ,"r");
    fout=fopen("evaluare.out" ,"w");
    a=fgetc(fi);
    fprintf(fout,"%d" ,E());
    fclose(fi);
    fclose(fout);
    return 0;
}
