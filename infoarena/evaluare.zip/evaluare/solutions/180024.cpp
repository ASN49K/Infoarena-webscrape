#include<fstream.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");
char x[100001],polo[100001],st[100001],op[]="+-*/()",c;
int n,i,k,vf=0,l;
int y,st2[100001];
char pop()
{
if (vf>=1) return st[vf--];
return 0;
}
void push(char c)
{
st[++vf]=c;
}
int main()
{
 fin.getline(x,20);
 n=strlen(x);
 for(i=0;i<n;i++)
{
 if(!strchr(op,x[i]))
 {while(!strchr(op,x[i+1]))
 {  polo[k++]=x[i];i++;}
   polo[k++]=x[i];
   polo[k++]='>';
 }
else
switch (x[i])
{
case '(': push(x[i]);break;
case ')': while((c=pop())!='(') polo[k++]=c;break;
case '*': case '/': push(x[i]);break;
case '+': case '-': if ((st[vf]=='*') || (st[vf]=='/'))
		    {
		    polo[k++]=pop();
		    push(x[i]);
		    }
		    else push(x[i]);
		    break;
}
}
while((c=pop())!=0) polo[k++]=c;
polo[k++]=0;
 n=strlen(polo);
 l=0;

for(i=0;i<n;i++)
 {

  vf=0;
 while(isdigit(polo[i]))
  st[vf++]=polo[i++];

 if (polo[i]=='>')
  {
  st[vf]=0;
  st2[++l]=atoi(st);
  }

  if(polo[i]=='*')
    st2[l-1]=st2[l-1]*st2[l--];
   if(polo[i]=='+')
    st2[l-1]=st2[l-1]+st2[l--];
  if(polo[i]=='-')
    st2[l-1]=st2[l-1]-st2[l--];
  if(polo[i]=='/')
    st2[l-1]=st2[l-1]/st2[l--];
 }
fout<<st2[1];
return 0;
}