#include <bits/stdc++.h>
using namespace std ;
ifstream fin("evaluare.in") ;
ofstream fout("evaluare.out") ;
string s ;
#define ll long long
ll eval(),termen(),factor(),numar(),i ;
int main()
{
    fin>>s ;
    fout<<eval() ;
    return 0 ;
}
ll numar()
{
    ll nr=0 ;
    while(isdigit(s[i])) nr=nr*10+(s[i]-'0'),i++ ;
    return nr ;
}
ll eval()
{
    ll cnt=termen() ;
    while(s[i]=='+' || s[i]=='-')
    {
        if(s[i]=='+') i++,cnt+=termen() ;
        else i++,cnt-=termen() ;
    }
    return cnt ;
}
ll termen()
{
    ll cnt=factor() ;
    while(s[i]=='*' || s[i]=='/')
    {
        if(s[i]=='*') i++,cnt*=termen() ;
        else i++,cnt/=termen() ;
    }
    return cnt ;
}
ll factor()
{
    ll cnt ;
    if(s[i]=='(') i++,cnt=eval(),i++ ;
    else cnt=numar() ;
    return cnt ;
}
