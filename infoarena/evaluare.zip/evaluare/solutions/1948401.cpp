#include <fstream>
#include <vector>
#include <stack>
#include <string>
#include <cctype>
#include <cstdlib>
using namespace std;

const char in_file[] = "evaluare.in";
const char out_file[] = "evaluare.out";

ifstream fin(in_file);
ofstream fout(out_file);

vector<char>G;
deque<char>s;

void infixToPostfix(const string& expr)
{
	for (int i = 0; expr[i]; ++i)
			if (isdigit(expr[i]))
				G.push_back(expr[i]);
			else
			{
				G.push_back(' ');
				if (expr[i] == '(' || expr[i] == '*' || expr[i] == '/')
					s.push_back(expr[i]);
				else
					if (expr[i] == ')')
					{
						char ch = s.back();
						while (ch != '(' && s.size())
						{
							s.pop_back();
							G.push_back(ch);
							if (s.size())
								ch = s.back();
						}
						s.pop_back();
					}
					else
						if (expr[i] == '-' || expr[i] == '+')
						{
							char ch = s.back();
							while (ch == '/' || ch == '*' && s.size())
							{
								s.pop_back();
								G.push_back(ch);
								if (s.size())
									ch = s.back();
							}
							s.push_back(expr[i]);
						}
			}
	G.push_back(' ');
	for (; !s.empty(); G.push_back(s.back()), s.pop_back());
}

inline int doMath(int a ,int b, char op)
{
	switch (op)
	{
	case '+': return a + b; break;
	case '-': return a - b; break;
	case '*': return a * b; break;
	case '/': return a / b; break;
	case '%': return a % b; break;
	default: return 0;
		break;
	}
}

int calculate()
{
	deque <int> elem;
	int number = -1;
	for (int i = 0; i < G.size(); ++i)
	{
		if (isdigit(G[i]))
		{
			if (number == -1) number = 0;
			number = number * 10 + (G[i] - '0');
			continue;
		}
		else
			if (G[i] == ' ')
			{
				if (number == -1)	continue;
				elem.push_back(number); number = -1;
			}
			else
			{
				int e1 = elem.back(); elem.pop_back();
				int e2 = elem.back(); elem.pop_back();
				elem.push_back(doMath(e2, e1, G[i]));
			}
	}

	return elem.back();
}
int main()
{
	string expr;
	fin >> expr;
	infixToPostfix(expr);
	fout << calculate();
}
