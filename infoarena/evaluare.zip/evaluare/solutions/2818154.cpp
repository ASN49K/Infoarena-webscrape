#include <bits/stdc++.h>
using namespace std;

ifstream f("evaluare.in");
ofstream g("evaluare.out");

stack < char > operations;
stack < int > numbers;
char s[100005];
vector < int > nr;
vector < char > ops;
int aa;

void solve_nr() {
    int x = 0;
    while (isdigit(s[aa])!=0) {
        x = x*10 + s[aa]-'0';
        aa++;
    }
    numbers.push(x);
}

void solve_ops() {
    nr.push_back(numbers.top());
    numbers.pop();
    while (operations.empty()==0 && operations.top()!='(') {
        nr.insert(nr.begin(),numbers.top());
        ops.insert(ops.begin(),operations.top());
        numbers.pop();
        operations.pop();
    }
    if (operations.empty()==0) {
        operations.pop();
    }
    for (int i=0;i<ops.size();i++) {
        if (ops[i]=='*') {
            ops.erase(ops.begin()+i);
            nr[i+1]=nr[i]*nr[i+1];
            nr.erase(nr.begin()+i);
            i--;
        }
        else if (ops[i]=='/') {
            ops.erase(ops.begin()+i);
            nr[i+1]=nr[i]/nr[i+1];
            nr.erase(nr.begin()+i);
            i--;
        }
    }
    for (int i=0;i<ops.size();i++) {
        if (ops[i]=='+') {
            ops.erase(ops.begin()+i);
            nr[i+1]=nr[i]+nr[i+1];
            nr.erase(nr.begin()+i);
            i--;
        }
        else if (ops[i]=='-') {
            ops.erase(ops.begin()+i);
            nr[i+1]=nr[i]-nr[i+1];
            nr.erase(nr.begin()+i);
            i--;
        }
    }
    int auau = nr[0];
    numbers.push(nr[0]);
    nr.erase(nr.begin());
}

int main()
{
    f >> s;
    while (aa!=strlen(s)) {
        if (isdigit(s[aa])!=0) {
            solve_nr();
        }
        else if (s[aa]==')') {
            solve_ops();
            aa++;
        }
        else {
            operations.push(s[aa]);
            aa++;
        }
    }
    solve_ops();
    g << numbers.top();
    return 0;
}
