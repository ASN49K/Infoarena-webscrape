#include <fstream>

using namespace std;

int expresie();
int termen();
int factor();
int p;
char s[1000001];

int expresie()
{
    int sum = termen();
    while( s[p] == '+' || s[p] == '-' )
        if( s[p] == '+' )
        {
            p ++;
            sum += termen();
        }
        else
        {
            p ++;
            sum -= termen();
        }

    return sum;
}
int termen()
{
    int prod = factor();
    while(s[p] == '*' || s[p] == '/')
        if( s[p] == '*' )
        {
            p ++;
            prod *= termen();
        }
        else
        {
            p ++;
            prod /= termen();
        }
    return prod;

}
int factor()
{
    int semn = 1;
    int val = 0;
    while(s[p] == '-')
    {
        p ++;
        semn = -semn;
    }
    if(s[p] == '(')
    {
        p ++;
        val = expresie();
        p++; //paranteza inchisa

    return semn*val;}

    while(s[p] >= '0' && s[p] <= '9')
    {
        val = val * 10 + s[p] - '0';
        p ++;
    }
    return semn*val;

}

int main()
{
    ifstream in("evaluare.in");
    ofstream out("evaluare.out");
    in >> s;
    out << expresie();
    return 0;
}
