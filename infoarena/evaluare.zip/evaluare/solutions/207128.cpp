#include <cstdio>
#define N 100001
char sir[N],*p;
long produs();
long termen();

long suma()
{long s=produs();
 while(*p=='+'||*p=='-')
 {switch(*p)
  {case '+':++p;s+=produs();break;
   case '-':++p;s-=produs();break;
  }
 }
 return s;
}

long produs()
{long s=termen();
 while(*p=='*'||*p=='/')
 {switch(*p)
  {case '*':++p;s*=termen();break;
   case '/':++p;s/=termen();break;
  }
 }
return s;
}

long termen()
{long s=0;
 if(*p=='(')
 {++p;
  s=suma();
  ++p;
  return s;
 }
 while(*p>='0'&&*p<='9')
 {s=s*10+*p-48;
  ++p;
 } 
 return s;
}

int main ()
{FILE *fin=fopen("eval.in","r");
 FILE *fout=fopen("eval.out","w");
 fgets(sir,N,fin);
 p=sir;
 fprintf(fout,"%ld",suma());
 fclose (fout);
 return 0;
}
