#include<bits/stdc++.h>
using namespace std;
ifstream fin("evaluare.in");
ofstream fout("evaluare.out");

int expresie(const string& s,int& p){
    int result=termen(s,p);
    while(p<(int)s.size() && (s[p]=='+' || s[p]=='-'))
    {
        int sign=1-2*(s[p]=='-');
        p++;
        result+=sign*termen(s,p);
    }
    return result;
}
int termen(const string& s,int& p){
    int result=factor(s,p);
    while(p<(int)s.size() && (s[p]=='*' || s[p]=='/'))
    {
        p++;
        if(s[p-1]=='*')
            result*=factor(s,p);
        else
            result/=factor(s,p);
    }
    return result;
}
int factor(const string& s,int& p){
    if(s[p]=='(')
    {
        p++;
        int result=expresie(s,p);
        p++;
        return result;
    }
    else
        return numar(s,p);
}
int numar(const string& s,int& p){
    int result=0;
    while('0'<=s[p] && s[p]<='9')
    {
        result=result*10+(s[p]-'0');
        p++;
    }
    return result;
}

int main(){
    int p=0;
    string s;
    fin>>s;
    fout<<expresie(s,p);
}
