// This program was written by Mircea Rebengiuc
// on 21.06.2022
// for problem radixsort

#include <stdio.h>
#include <ctype.h>

#define MAXN 10000000

#define NBUCKET 256
#define LBUCKET 8
#define NBITS 31

#define byte unsigned char

// daca nu iau MLE e miracol

int v[MAXN]; // ~40MB
short w[MAXN]; // ~10MB
int index[2][MAXN]; // ~80MB
int freq[NBUCKET];
int start[NBUCKET];

FILE *fin, *fout;

int main(){
  fin = fopen( "radixsort.in", "r" );
  fout = fopen( "radixsort.out", "w" );

  int a, c;
  int n, i, j, x, t;

  fscanf( fin, "%d%d%d%d", &n, &a, v, &c );
  for( i = 1 ; i < n ; i++ )
    v[i] = (((long long)a) * v[i - 1] + v[0]) % c;

  t = 0;
  for( i = 0 ; i < n ; i++ )
    index[t][i] = i;

  for( x = 0 ; x < NBITS ; x += LBUCKET ){
    for( i = 0 ; i < NBUCKET ; i++ )
      freq[i] = 0;

    for( i = 0 ; i < n ; i++ ){
      w[i] = ((v[i] >> x) & (NBUCKET - 1));
      freq[w[i]]++;
    }

    if( freq[0] < n ){
      start[0] = 0;
      for( i = 1 ; i < NBUCKET ; i++ )
        start[i] = start[i - 1] + freq[i - 1];

      for( i = 0 ; i < n ; i++ ){
        j = index[t][i];
        index[t ^ 1][start[w[j]]++] = j;
      }

      t ^= 1;
    }
  }

  for( i = 0 ; i < n ; i += 10 )
    fprintf( fout, "%d ", v[index[t][i]] );
  fputc( '\n', fout );

  fclose( fin );
  fclose( fout );
  return 0;
}