#include <bits/stdc++.h>
#define nmax 10000005
#define bmax (0xff)+1
using namespace std;

ifstream f("radixsort.in");
ofstream g("radixsort.out");

int v[nmax],n;
int a,b,c;

int buc[nmax];
int s[bmax];

int cifr(const int &n, int k)
{
    return(n&(0xff)<<(k*8))>>(k*8);
}

int main()
{
    f>>n>>a>>b>>c;

    v[0]=b;
    for(int i=1;i<n;i++)
    {
        v[i]=((v[i-1]*a)%c+b)%c;
    }
    for(int k=0;k<4;k++)
    {
        memset(s,0,sizeof(s));
        for(int i=0;i<n;i++)
        {
            int c= cifr(v[i],k);
            s[c]++;
        }
        for(int i=1;i<bmax;i++)s[i]+=s[i-1];
        for(int i=bmax;i>=1;i--) s[i]=s[i-1];
        s[0]=0;
        for(int i=0;i<n;i++)
        {
            int c= cifr(v[i],k);
            buc[s[c]++]=v[i];
        }
        memcpy(v,buc,sizeof(v));
    }
    for(int i=0;i<n;i+=10)
    {
        g<<v[i]<<' ';
    }
    return 0;
}
