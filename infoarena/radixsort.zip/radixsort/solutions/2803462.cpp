#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdio>

using namespace std;

const int NMAX = 1e7;
const int BASE = 1<<16;

int n;
int v[NMAX];
int frecv[BASE];
int aux[NMAX];

void reorder( int xit ) {
    int i;
    for ( i = 0; i < BASE; i ++ )
        frecv[i] = 0;
    for ( i = 0; i < n; i ++ )
        frecv[( v[i] >> xit ) % 65536] ++;
    for ( i = 1; i < BASE; i ++ )
        frecv[i] += frecv[i - 1];
    for ( i = n - 1; i >= 0; i -- )
        aux[--frecv[( v[i] >> xit ) % 65536]] = v[i];
    for ( i = 0; i < n; i ++ )
        v[i] = aux[i];
}
void radix() {
    int xit;
    for ( xit = 0; xit < 2; xit ++ ) {
        reorder( 16 * xit );
    }
}
class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};
int main() {
    ifstream fin( "radixsort.in" );
    OutParser fout( "radixsort.out" );
    int a, b, c, i, x;
    fin >> n >> a >> b >> c;
    v[0] = b;
    x = b;
    for ( i = 1; i < n; i ++ ) {
        x = ( (long long)a * x + b ) % c;
        v[i] = x;
    }

    radix();

    for ( i = 0; i < n; i += 10 )
        fout << v[i] << ' ';
    return 0;
}
