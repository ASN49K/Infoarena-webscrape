#include <fstream>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

const int maxN = 10000005, base = 256;
int n, a, b, c, v[maxN], aux[maxN];
int freq[base + 5], poz[base + 5];

int main()
{
    fin >> n >> a >> b >> c;
    v[1] = b;
    for(int i = 2; i <= n; i++)
        v[i] = (long long) (1LL * v[i - 1] * a + b) % c;
    for(int i = 0, mask = 255; i < 32; i += 8, mask <<= 8)
    {
        for(int j = 1; j <= n; j++)
        {
            int cifra = (v[j] & mask) >> i;
            freq[cifra]++;
        }
        for(int j = 1; j < base; j++)
            freq[j] += freq[j - 1];
        for(int j = 1; j <= n; j++)
        {
            int cifra = (v[j] & mask) >> i;
            poz[cifra]++;
            int newpoz = poz[cifra];
            if(cifra > 0)
                newpoz += freq[cifra - 1];
            aux[newpoz] = v[j];
        }
        for(int j = 1; j <= n; j++)
            v[j] = aux[j];
        for(int j = 0; j < base; j++)
        {
            freq[j] = 0;
            poz[j] = 0;
        }
    }
    for(int i = 1; i <= n; i += 10)
		fout << v[i] << ' ';
    return 0;
}
