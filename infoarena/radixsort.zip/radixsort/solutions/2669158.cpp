#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void Beolvas(int& n, vector<int> &a)
{
	ifstream fin("radixsort.in");

	int x, y, z;
	fin >> n >> x >> y >> z;
	a.resize(n,0);
	a[0] = y;
	for (int i = 1; i < n; ++i)
		a[i] = (x * a[i - 1] + y) % z;
}

void Kiir(int n, vector<int> a)
{
	ofstream fout("radixsort.out");

	for (int i = 0; i < n; ++i)
		if (i % 10 == 0) fout << a[i] << " ";

	fout << "\n";
}

void nullaz(int v[], int n)
{
	for (int i = 0; i < n; ++i) v[i] = 0;
}

void Radix_sort(int n, vector<int> a)
{
	bool ok;
	int oszto = 1;
	int elof[11] = { 0 };
	vector<int> a2(n,0);

	do
	{
		ok = false;

		for (int i = 0; i < n; ++i)
			++elof[(a[i]/oszto)%10+1];

		for (int i = 1; i <= 10; ++i)
			elof[i] += elof[i - 1];

		for (int i = 0; i < n; ++i)
		{
			if ((a[i] / oszto) / 10 > 0) ok = true;

			a2[elof[(a[i] / oszto) % 10]] = a[i];
			++elof[(a[i] / oszto) % 10];
		}

		for (int i = 0; i < n; ++i) a[i] = a2[i];

		oszto *= 10;
		nullaz(elof, 11);
	} while (ok);

}

int main()
{
	int n;
	vector<int>a;
	Beolvas(n, a);

	Radix_sort(n, a);

	Kiir(n, a);
	
	return 0;
}
