#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;

ifstream in("radixsort.in");
ofstream out("radixsort.out");
int n, a, b, c, cnt;
int v[10000005];

signed main()
{
    in>>n>>a>>b>>c;

    v[1] = b;

    for(int i = 2; i<=n; i++)
    {
        v[i] = ((1LL * a * v[i-1]) % c + b) % c;
    }

    for(int bit = 0; bit <= 30; bit++)
    {
        vector<int> w[3];

        for(int i = 1; i<=n; i++)
        {
            if((v[i] & (1 << bit)))
            {
                w[1].push_back(v[i]);
            }
            else
            {
                w[0].push_back(v[i]);
            }
        }
    }

    for(int i = 1; i<=n; i+=10)
    {
        out<<v[i]<<" ";
    }
    return 0;
}
