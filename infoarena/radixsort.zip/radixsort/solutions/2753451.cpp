#include <fstream>
#include <queue>
#include <vector>

using namespace std;

vector<int> Generate(int n, int a, int b, int c) {
    vector<int> vec(n);
    vec[0] = b;

    for (int i = 1; i < n; i += 1) {
        vec[i] = (1LL * a * vec[i - 1] + b) % c;
    }
    return vec;
}

void Sort(vector<int>& vec) {
    int mask = (1 << 8) - 1;
    int steps = sizeof(int);

    for (int i = 0; i < steps; i += 1) {
        auto index = [i, mask](int num) { return (num & mask) >> (8 * i); };

        vector<int> count((1 << 8) + 1, 0);
        for (const auto& num : vec) {
            count[index(num) + 1] += 1;
        }
        for (size_t j = 1; j < count.size(); j += 1) {
            count[j] += count[j - 1];
        }

        vector<int> new_vec(vec.size());
        for (const auto& num : vec) {
            new_vec[count[index(num)]] = num;
            count[index(num)] += 1;
        }

        vec = new_vec;
        mask <<= 8;
    }
}

int main() {
    ifstream fin("radixsort.in");
    ofstream fout("radixsort.out");

    int n, a, b, c;
    fin >> n >> a >> b >> c;

    auto vec = Generate(n, a, b, c);

    Sort(vec);

    for (int i = 0; i < n; i += 10) {
        fout << vec[i] << " ";
    }
    fout << "\n";

    return 0;
}
