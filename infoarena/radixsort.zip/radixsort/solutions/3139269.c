#include <stdio.h>
#include <stdlib.h>

unsigned int Maximum(unsigned int a,unsigned int b){
    return (a>b) ? a:b;
}
unsigned int MaximumDigits(unsigned int num){

    if(num==0) return 1;

    unsigned int size=0;
    while(num){
        size+=1;
        num/=10;
    }

    return size;
}
void RadixSort(unsigned int *arr,unsigned int n,unsigned int maxIterations)
{
    unsigned int *bucketIndex=(unsigned int *)calloc(10, sizeof(unsigned int));
    unsigned int *bucketSize=(unsigned  int *)calloc(10, sizeof(unsigned int));
    unsigned int *tempArray=(unsigned  int *)calloc(n, sizeof(unsigned int));

    unsigned int div=1;
    for(unsigned int it=0;it<maxIterations;it++) {

        for(unsigned int i=0;i<n;i++)
            bucketSize[(arr[i]/div)%10]++;

        bucketIndex[0]=0;
        for(unsigned int i=1;i<10;i++)
            bucketIndex[i]=bucketIndex[i-1]+bucketSize[i-1];

        for(unsigned int i=0;i<n;i++)
            tempArray[bucketIndex[(arr[i]/div)%10]++]=arr[i];

        for(unsigned int i=0;i<n;i++)
            arr[i]=tempArray[i];


        bucketSize[0]=0;
        bucketSize[1]=0;
        bucketSize[2]=0;
        bucketSize[3]=0;
        bucketSize[4]=0;
        bucketSize[5]=0;
        bucketSize[6]=0;
        bucketSize[7]=0;
        bucketSize[8]=0;
        bucketSize[9]=0;

        div*=10;
    }

    free(bucketIndex);
    free(bucketSize);
    free(tempArray);
}
int main() {

    FILE *f=fopen("radixsort.in","r");
    FILE *g=fopen("radixsort.out","w");

    if(NULL==f || NULL==g)
        exit(1);

    unsigned int n,A,B,C,maxIterations=0;
    fscanf(f,"%u %u %u %u",&n,&A,&B,&C);

    unsigned int *arr=(unsigned int *)calloc(n, sizeof(unsigned int));
    unsigned long long x;

    A=A%C;
    B=B%C;
    arr[0]=B;
    for(unsigned int i=1;i<n;i++) {
        x=(((unsigned long long)(arr[i-1])%(unsigned long long)C*(unsigned long long)A)%(unsigned long long)C+(unsigned long long)B)%(unsigned long long)C;
        arr[i]=(unsigned int )x;
        maxIterations= Maximum(maxIterations, MaximumDigits(arr[i]));
    }
    RadixSort(arr,n,maxIterations);

    for(unsigned int i=0;i<n;i+=10)
        fprintf(g,"%llu ",arr[i]);

    fclose(f);
    fclose(g);
    free(arr);
    return 0;
}