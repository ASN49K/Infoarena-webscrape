#include <stdio.h>
#include <string.h>

#define NMAX 10000000
#define MAX_BITS 32
#define BITS_PER_STEP 8
const int BASE = ( 1 << BITS_PER_STEP );
const int MASK = BASE - 1;

int vec1[NMAX], vec2[NMAX];
int vecf[BASE], vec_ind[BASE];

void my_sort ( int vec[], int aux[], int num_n, int bits ) {

  if ( bits == MAX_BITS )
    return;

  memset(vecf, 0, sizeof(vecf));

  int ind;
  for ( ind = 0; ind < num_n; ind++ )
    ++vecf[vec[ind] >> bits & MASK];

  vec_ind[0] = 0;
  for ( ind = 1; ind < BASE; ++ind )
    vec_ind[ind] = vec_ind[ind - 1] + vecf[ind - 1];

  for ( ind = 0; ind < num_n; ++ind )
    aux[vec_ind[vec[ind] >> bits & MASK]++] = vec[ind];

  my_sort( aux, vec, num_n, bits + BITS_PER_STEP );

}

int main()
{
    FILE *fin, *fout;
    int num_n, num_a, num_b, num_c, ind;

    fin = fopen( "radixsort.in", "r" );
    fscanf( fin, "%d%d%d%d", &num_n, &num_a, &num_b, &num_c );
    fclose( fin );

    vec1[0] = num_b;
    for ( ind = 1; ind < num_n; ind++ )
      vec1[ind] = ( 1LL * num_a * vec1[ind - 1] + num_b ) % num_c;

    my_sort( vec1, vec2, num_n, 0 );

    fout = fopen( "radixsort.out", "w" );
    for ( ind = 0; ind < num_n; ind+=10 )
      fprintf( fout, "%d ", vec1[ind] );
    fclose( fout );
    return 0;
}
