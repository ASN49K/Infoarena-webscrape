#include <bits/stdc++.h>
using namespace std;
const int NMAX = 1e7+2;
const int BASE = 256;
int n,a,b,c,v[NMAX],maxi,nrc,f[BASE],w[NMAX];

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

int main()
{
    fin >> n >> a >> b >> c;
    v[1] = b;
    for(int i = 2; i <= n; i++){
        v[i] = (1LL*a*v[i-1]+b)%c;
        maxi = max(maxi, v[i]);
    }
    while(maxi){
        nrc++;
        maxi /= BASE;
    }
    for(int j = 1, offset = 0; j <= nrc; j++, offset += 8){
        memset(f, 0, sizeof(f));
        for(int i = 1; i <= n; i++){
            f[(v[i]>>offset)&255]++;
        }
        for(int i = 1; i < BASE; i++){
            f[i] += f[i-1];
        }
        for(int i = n; i >= 1; i--){
            w[ f[(v[i]>>offset)&255]-- ] = v[i];
        }
        memcpy(v, w, sizeof(w));
    }
    for(int i = 1; i <= n; i += 10){
        fout << v[i] << " ";
    }
    return 0;
}
