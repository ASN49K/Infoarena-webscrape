#include <bits/stdc++.h>

using namespace std;

ifstream in ("radixsort.in");
ofstream out ("radixsort.out");

const int NMAX = 1e7;
const int BITS = 12;
const int MASK = (1LL << BITS) - 1;
const int LGMAX = 32;

int idx[MASK + 1];
int f[MASK + 1];
int a[NMAX], aux[NMAX];

int main()
{
    int n, A, B, C;
    in >> n >> A >> B >> C;

    a[0] = B;

    for (int i=1; i<n; i++)
        a[i] =  ((long long) A * a[i-1] + B) % C;

    for (int bt=0; bt<LGMAX; bt += BITS)
    {
        memset(f, 0, sizeof(f));
        for (int i=0; i<n; i++)
            f[(a[i] >> bt) & MASK]++;
        idx[0] = 0;
        for (int i=1; i<=MASK; i++)
            idx[i] = idx[i-1] + f[i-1];
        for (int i=0; i<n; i++)
            aux[idx[(a[i] >> bt) & MASK]++] = a[i];
        swap(aux, a);
    }


    for (int i=0; i<n; i+=10)
        out << a[i] << ' ';

    return 0;
}
