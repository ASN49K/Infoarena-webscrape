#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e7;
const int BITS = 16;
const int BASE = (1 << BITS) - 1;
int v[NMAX];

int main() {
    ifstream fin( "radixsort.in" );
    ofstream fout( "radixsort.out" );
    int n, a, b, c;
    fin >> n >> a >> b >> c;
    v[0] = b;
    for ( int i = 1; i < n; i ++ ) {
        v[i] = ((long long)a * v[i - 1] + b) % c;
    }
    for ( int j = 0; j < 2; j ++ ) {
        vector<std::vector<int>> frecv(1 << BITS);
        for( int i = 0; i < n; i ++ )
            frecv[(v[i] >> (j * BITS)) & (BASE)].push_back( v[i] );
            
        int m = 0;
        for ( auto& f : frecv ) {
            for ( auto x : f ) {
                v[m++] = x;
            }
            f.clear();
        }
    }
    for ( int i = 0; i < n; i += 10 ) {
        fout << v[i] << ' ';
    }
    return 0;
}