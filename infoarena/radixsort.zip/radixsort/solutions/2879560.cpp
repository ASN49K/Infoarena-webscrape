#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define dbg(x) cout << #x <<": " << x << "\n";
#define sz(x) ((int)x.size())

using ll = long long;

const string fn = "radixsort";
// ifstream fin(fn + ".in");
ofstream fout(fn + ".out");

 
class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;
 
	char read_ch() {
		++sp;
		if (sp == 4096) {
			sp = 0;
			fread(buff, 1, 4096, fin);
		}
		return buff[sp];
	}
 
public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[4096]();
		sp = 4095;
	}
	
	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
	
	InParser& operator >> (long long &n) {
		char c;
		n = 0;
		while (!isdigit(c = read_ch()) && c != '-');
		long long sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}
};
InParser fin("radixsort.in");
void radixSort(vector<int> &a, int n){

	vector<int> fr(256, 0);
	vector<int> b(n + 1);

	for (int i = 0; i < 32; i += 8) {
		for (int j = 1; j <= n; ++j)
			fr[(a[j] >> i) & 255]++;
		for (int j = 1; j < 256; ++j)
			fr[j] += fr[j - 1];
		for (int j = n; j >= 1; --j)
			b[fr[(a[j] >> i) & 255]--] = a[j];

		a = b;
		fill(fr.begin(), fr.end(), 0);
	}

}



int main(){

	int n, A, B, C;
	fin >> n >> A >> B >> C;
	vector<int> v(n + 1);
	v[1] = B;
	for (int i = 2; i <= n; ++i)
		v[i] = (1LL * A * v[i - 1] + B) % C;
	
	radixSort(v, n);

	for (int i = 1; i <= n; i += 10)
		fout << v[i] << " ";

		return 0;
}