#include <iostream>
#include <bits/stdc++.h>
#define VMAX 10000005
#define INF 2147000000
using namespace std;
ifstream fin ("radixsort.in");
ofstream fout ("radixsort.out");

int numere[VMAX];
queue<int> grupe[10];
int a,b,c;

int main()
{
    int n,m,i,j,k,t,q,nr,p;
    fin>>n>>a>>b>>c;
    nr=0;
    for(i=1;i<=n;i++)
    {
        nr=(a*nr+b)%c;
        numere[i]=nr;
    }

    for(i=0,p=1;i<=10;i++,p*=10)
    {
        for(j=1;j<=n;j++)
        {
            grupe[(numere[j]/p)%10].push(numere[j]);
        }

        for(k=0,j=1;k<10;k++)
            for(;grupe[k].size();j++)
            {
                numere[j]=grupe[k].front();
                grupe[k].pop();
            }
    }

    for(i=1;i<=n;i+=10)
        fout<<numere[i]<<' ';
    fout<<'\n';

    return 0;
}
