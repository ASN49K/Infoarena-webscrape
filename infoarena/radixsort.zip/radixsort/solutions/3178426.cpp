#include <bits/stdc++.h>
using namespace std;

const int baza = (1 << 16);

int v[10000001];
int aux[10000001];
int fv[baza];

#ifndef HOME
    ifstream in("radixsort.in");
    ofstream out("radixsort.out");
    #define cin in
    #define cout out
#endif

int main()
{
#ifdef HOME
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#endif
    int n, a, b, c;
    cin >> n >> a >> b >> c;
    v[1] = b;
    for(int i = 2; i <= n; i++)
        v[i] = (1LL * a * v[i - 1] + b) % c;
    int cnt = 1;
    for(int i = 1; i <= n; i++)
        fv[v[i] % baza]++;
    for(int i = 1; i <= baza - 1; i++)
        fv[i] += fv[i - 1];
    for(int i = n; i >= 1; i--)
    {
        aux[fv[v[i] % baza]] = v[i];
        fv[v[i] % baza]--;
    }
    for(int i = 0; i <= baza - 1; i++)
        fv[i] = 0;
    ///a doua oara
    for(int i = 1; i <= n; i++)
        fv[(aux[i] >> 16) % baza]++;
    for(int i = 1; i <= baza - 1; i++)
        fv[i] += fv[i - 1];
    for(int i = n; i >= 1; i--)
    {
        v[fv[(aux[i] >> 16) % baza]] = aux[i];
        fv[(aux[i] >> 16) % baza]--;
    }
    for(int i = 1; i <= n; i += 10)
        cout << v[i] << " ";
    return 0;
}