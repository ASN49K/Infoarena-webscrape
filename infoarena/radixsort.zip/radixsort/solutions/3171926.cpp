#include <fstream>
#pragma GCC optimize("Ofast", "unroll-loops")
using namespace std;
#include <stdio.h>
#include <ctype.h>

class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;
 
    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }
 
 
public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }
 
    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }
 
    OutParser& operator << (long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }
 
    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};

ifstream in("radixsort.in");
OutParser out("radixsort.out");

int v[10000001],n,cnt[(1 << 16) + 1],aux[10000001];
void sorteaza(int v[], int aux[], int p)
{
    for(int i=1; i<=n; i++)
        cnt[(v[i]>>p)&((1 << 16) - 1)]++;
    for(int i=1; i<(1 << 16); i++)
        cnt[i]+=cnt[i-1];
    for(int i=n; i>=1; i--)
        aux[cnt[(v[i]>>p)&((1 << 16) - 1)]--]=v[i];
}
void radixsort()
{
    sorteaza(v, aux, 0);
    for(int i=0; i<(1 << 16); i++)
        cnt[i]=0;
    sorteaza(aux, v, 16);
}
int main()
{
    int a,b,c,i;
    in>>n>>a>>b>>c;
    v[1]=b;
    for(i=2; i<=n; i++)
        v[i]=(1LL*a*v[i-1]+b)%c;
    radixsort();
    for(i=1; i<=n; i+=10)
        out<<v[i]<<" ";
    return 0;
}