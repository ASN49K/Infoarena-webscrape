#include <fstream>

using namespace std;

ifstream cin("radixsort.in");
ofstream cout("radixsort.out");

#define DIM 10000001

int n, a, b, c, v[DIM];

static inline void RadixSort(int v[], int left, int right, int bit) {
    if(left > right || bit == -1)
        return;

    int i, j;

    ///punem bitii de 0 la stanga;
    for(i = left, j = left; i <= right; i++)
        if((v[i] & (1 << bit)) == 0) {
            swap(v[i], v[j]);
            j++;
        }

    RadixSort(v, left, j - 1, bit - 1);
    RadixSort(v, j, right, bit - 1);
}

int main() {
    cin >> n >> a >> b >> c;
    v[1] = b;
    for(int i = 2; i <= n; i++)
        v[i] = (1LL * a * v[i - 1] + b) % c;

    RadixSort(v, 1, n, 31);
    for(int i = 1; i <= n; i += 10)
        cout << v[i] << " ";

  return 0;
}
