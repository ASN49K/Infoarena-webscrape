#include <fstream>
#include <deque>
#include <vector>
#include <bits/stdc++.h>
using namespace std;

deque<unsigned int> bucket[2][256];
unsigned int n, a, b, c;
ifstream fin;
ofstream fout;


void rsort() {
  unsigned int i, val, k;
  for (i = 0, val = b; i < n; ++i, val = 1LL * (1LL * a * val + b) % c){
    bucket[0][val&0x000000ff].push_back(val);
  }
  for (i = 0; i < 256; ++i) {
    while (!bucket[0][i].empty()) {
      unsigned int &e = bucket[0][i].front();
      bucket[1][(e&0x0000ff00)>>8].push_back(e);
      bucket[0][i].pop_front();
    }
  }
  for (i = 0; i < 256; ++i) {
    while (!bucket[1][i].empty()) {
      unsigned int &e = bucket[1][i].front();
      bucket[0][(e&0x00ff0000)>>16].push_back(e);
      bucket[1][i].pop_front();
    }
  }
  for (i = 0; i < 256; ++i) {
    while (!bucket[0][i].empty()) {
      unsigned int &e = bucket[0][i].front();
      bucket[1][(e&0xff000000)>>24].push_back(e);
      bucket[0][i].pop_front();
    }
  }
  k = 0;
  for (i = 0; i < 256; ++i) {
    while (!bucket[1][i].empty()) {
      if(k % 10 == 0){
      		fout << bucket[1][i].front() << " ";
      }
      ++k;
      bucket[1][i].pop_front();
    }
  }
}

int main(){
	fin.open("radixsort.in");
	fout.open("radixsort.out");
	fin >> n >> a >> b >> c;
	rsort();	
}
