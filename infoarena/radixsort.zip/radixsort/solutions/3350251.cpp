#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
#define N 10000005
ll a, b, c, v[N];
int n;
ll getMax(ll v[], int n){
    ll mx = v[1];
    for(int i = 2; i<=n; i++){
        if(v[i] > mx) mx = v[i];
    }
    return mx;
}

void countSort(ll v[], int n, int p){
    ll ans[n+1];
    int count[10] = {0};
    for(int i = 1; i<=n; i++){
        int pthDigit = (v[i]/p)%10;
        count[pthDigit]++;
    }
    for(int i = 1; i<=9; i++){
        count[i] += count[i-1];
    }
    for(int i = n; i>=1; i--){
        int pthDigit = (v[i]/p)%10;
        ans[count[pthDigit]--] = v[i];
    }

    for(int i = 1; i<=n; i++){
        v[i] = ans[i];
    }
}

void radix(ll v[], int n){
    int m = getMax(v, n);
    for(int p = 1; m / p > 0; p *= 10)
        countSort(v, n, p);
}

int main(){
    fin >> n >> a >> b >> c;
    v[1] = b;
    for(int i = 2; i<=n; i++){
        v[i] = (a*v[i-1]+b)%c;
    }
    radix(v, n);
    for(int i = 1; i<=n; i+=10){
        fout << v[i] << ' ';
    }
    return 0;
}