#include <stdio.h>
#include <string.h>

#define MAX_N 10000000
#define MAX_BITS 32      // Numerele au maxim 32 biti
#define BITS_PER_STEP 8  // Impartim pe perechi de 8 biti
const int BASE = (1 << BITS_PER_STEP);
const int MASK = BASE - 1;

// Avem nevoie de un array auxiliar, pentru a aranja numerele dupa fiecare pas al algoritmului
int v1[MAX_N], v2[MAX_N];
int freq[BASE], ind[BASE];

void sort(int v[], int aux[], int n, int bits) {
  if (bits == MAX_BITS)
    return;

  // Resetam vectorul de frecventa la fiecare pas nou
  memset(freq, 0, sizeof(freq));

  int i;
  for (i = 0; i < n; ++i)
    ++freq[v[i] >> bits & MASK];

  ind[0] = 0;
  for (i = 1; i < BASE; ++i)
    ind[i] = ind[i - 1] + freq[i - 1];

  for (i = 0; i < n; ++i)
    aux[ind[v[i] >> bits & MASK]++] = v[i];

  // Interschimbare intre vectorul aux si v
  sort(aux, v, n, bits + BITS_PER_STEP);
}

int main() {
  FILE* fin = fopen("radixsort.in", "r");
  int n, i, a, b, c;
  fscanf(fin, "%d%d%d%d", &n, &a, &b, &c );
  v1[0] = b;
  for (i = 1; i < n; ++i)
    v1[i] = ( 1LL * a * v1[i - 1] + b ) % c;
  fclose(fin);

  sort(v1, v2, n, 0);

  FILE* fout = fopen("radixsort.out", "w");
  for (i = 0; i < n; i += 10)
    fprintf(fout, "%d ", v1[i]);
  fclose(fout);
  return 0;
}
