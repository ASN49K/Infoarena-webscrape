#include <fstream>
#include <vector>
#define mxbits 32
#define base 16
using namespace std;

int v[10000005];
vector<int> bucket[(1 << 4)];
void rsort(int n, int bits){
    if(bits == mxbits){
        return;
    }
    int i, b;
    unsigned int j;
    for(i = 0; i < n; i++){
        bucket[v[i] >> bits & (base - 1)].push_back(v[i]);
    }
    i = 0;
    for(b = 0; b < base; b++){
        for(j = 0; j < bucket[b].size(); j++){
            v[i++] = bucket[b][j];
        }
        bucket[b].clear();
    }
    rsort(n, bits + 4);
}
int main()
{
    ifstream cin("radixsort.in");
    ofstream cout("radixsort.out");
    int n, a, b, c;
    cin >> n >> a >> b >> c;
    v[0] = b;
    for(int i = 1; i < n; i++){
        v[i] = (a * v[i - 1] + b) % c;
    }
    rsort(n, 0);
    for(int i = 1; i <= n; i+=10){
        cout << v[i] << " ";
    }
    return 0;
}
