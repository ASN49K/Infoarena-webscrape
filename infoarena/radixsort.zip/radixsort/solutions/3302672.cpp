#include<bits/stdc++.h>
using namespace std;
ifstream in("radixsort.in");
ofstream out("radixsort.out");
int n,val=(1<<16),x,a,b,c,ct;
vector<queue<int>>bucket1(val),bucket2(val);
int main()
{in>>n>>a>>b>>c;
x=b;
bucket1[b%val].push(b);
    for(int i=1;i<n;i++)
{x=(1ll*x*a+b)%c;
bucket1[x%val].push(x);
}
for(int i=0;i<val;i++)
while(!bucket1[i].empty())
{int k=bucket1[i].front();
    bucket1[i].pop();
    bucket2[k/val].push(val);
}
for(int i=0;i<val;i++)
while(!bucket2[i].empty())
{int k=bucket2[i].front();
bucket2[i].pop();
ct++;
if(ct%10==1)
    out<<k<<" ";
}
}
