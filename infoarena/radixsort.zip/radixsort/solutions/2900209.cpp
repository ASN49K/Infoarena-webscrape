#include <iostream>
#include <fstream>
#include <vector>
#include <map>
using namespace std;

int v[10000000];

void mergeSort(int st, int dr){
    int m=(st+dr)/2;
    if(st<dr){
        mergeSort(st, m);
        mergeSort(m+1, dr);
    }
    int i=st, j=m+1, k=0, t[dr-st+1];
    while(i<=m && j<=dr) {
        if (v[i] < v[j]) t[k++] = v[i++];
        else t[k++] = v[j++];
    }
    while(i<=m) t[k++] = v[i++];
    while(j<=dr) t[k++] = v[j++];
    k=0;
    for(i=st; i<=dr; i++)
        v[i] = t[k++];
}


void pb1(){
    ifstream fin("algsort.in");
    ofstream fout("algsort.out");
    int n;
    fin>>n;
    for(int i=0;i<n;i++) fin>>v[i];
    mergeSort(0,n-1);
    for(int i=0;i<n;i++) fout<<v[i]<<' ';
}



int main() {
    ifstream fin("radixsort.in");
    ofstream fout("radixsort.out");
    int n, a, b, c;
    fin>>n>>a>>b>>c;
    v[0] = b;
    for(int i=1;i<n;i++)
        v[i] = (a * v[i-1] + b) % c;
    int p=0;
    vector<int> buckets[256], buckets_old[256];
    int base = 256;
    for(int i=0;i<n;i++){
        buckets_old[v[i]&255].push_back(v[i]);
    }
    for(int l = 0;l<5;l++){
        for(int i=0;i<256;i++) {
            for (auto x: buckets_old[i])
                buckets[(x >> p) & 255].push_back(x);
        }
        for(int i=0;i<buckets->size();i++)
        {
            buckets_old[i].clear();
            buckets_old[i] = buckets[i];
            buckets[i].clear();
        }

//        buckets_old = buckets;

        p += 8;
    }
//    int pas=10;
//    for(int i=0;i<buckets_old->size(); i++) {
//        int j;
//        for(j=10-pas;j<buckets_old[i].size();j+=10) {
//            fout<<buckets_old[i][j]<<' ';
//        }
//        pas = buckets_old[i].size()-j-1;
//    }
for(int i=0;i<n;i+=10) fout<<buckets_old[0][i]<<' ';
    return 0;
}
