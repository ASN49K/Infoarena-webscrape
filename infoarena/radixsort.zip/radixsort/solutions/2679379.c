#include <stdio.h>
#define MAX_N 10000000
#define MAX_B 31
#define GRUP_B 8
#define MASK ((1 << GRUP_B) - 1)
int v[MAX_N], v_aux[MAX_N], f[MASK], ind[MASK];
void radixsort( int n ) {
    int p, b, i;
    for ( b = 0; b < MAX_B; b += GRUP_B ) {
        for( i = 0; i < MASK; i++ )
            f[i] = 0;
        for ( i = 0; i < n; i++ )
            f[v[i] >> b & MASK]++;
        ind[0] = 0;
        for ( i = 1; i < MASK; i++ )
            ind[i] = ind[i - 1] + f[i - 1];
        for( i = 0; i < n; i++ ) {
            p = v[i] >> b & MASK;
            v_aux[ind[p]] = v[i];
            ind[p]++;
        }
        for( i = 0; i < n; i++ )
            v[i] = v_aux[i];
    }
}
int main() {
    FILE *fin, *fout;
    int n, a, b, c, i;
    fin = fopen( "radixsort.in", "r" );
    fscanf( fin, "%d%d%d%d", &n, &a, &b, &c );
    fclose( fin );
    v[0] = b;
    for ( i = 1; i < n; i++ )
        v[i] = ((long long)a * v[i - 1] + b) % c;
    radixsort( n );
    fout = fopen( "radixsort.out", "w" );
    for ( i = 0; i < n; i += 10 )
        fprintf( fout, "%d ", v[i] );
    fclose( fout );
    return 0;
}
