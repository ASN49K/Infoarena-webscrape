#include <fstream>
#include <iostream>
#include <queue>

using namespace std;

ifstream fi("radixsort.in");
ofstream fo("radixsort.out");
int n, i, iq, v[10000001], p10, p, a, b, c;
queue<int> q[10];

int main() {
    fi >> n >> a >> b >> c;
    v[1] = b;
    for (i = 2; i <= n; i++)
        v[i] = (1LL * a * v[i - 1] + b) % c;
    p10 = 1;
    for (p = 1; p <= 9; p++) {
        for (i = 1; i <= n; i++) {
            c = v[i] / p10 % 10;
            q[c].push(v[i]);
        }
        i = 0;
        for (iq = 0; iq <= 9; iq++)  // Punem elementele in v.        
            while (not q[iq].empty()) {
                i++;
                v[i] = q[iq].front();
                q[iq].pop();
            }
        p10 *= 10;
    }
    for (i = 1; i <= n; i += 10)
        fo << v[i] << ' ';
    return 0;
}



/*

849 770 67 347 201 618 66 495 13 45

     0   1   2   3   4   5   6   7   8   9
   770 201      13     495  66  67 618 849
                        45     347

770 201 13 495 45 66 67 347 618 849 

       0   1   2   3   4   5   6   7   8   9
      201  13          45      66 770     495
          618         347      67
                      849

201 13 618 45 347 849 66 67 770 495

     0   1   2   3   4   5   6   7   8   9
    13     201 347 495     618 770 849
    45
    66
    67

*/