#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define dbg(x) cout << #x <<": " << x << "\n";
#define sz(x) ((int)x.size())

using ll = long long;

const string fn = "radixsort";
ifstream fin(fn + ".in");
ofstream fout(fn + ".out");

int n, A, B, C;

int a[10000005];
int b[10000005];
int fr[256];
int main() {

	fin >> n >> A >> B >> C;
	a[1] = B;
	for (int i = 2; i <= n; ++i)
		a[i] = (A * a[i - 1] + B) % C;

	for (int i =  0; i < 32; i += 8) {

		fill(fr, fr + 256, 0);
		for (int j = 1; j <= n; ++j)
			fr[(a[j] >> i) & 255]++;
		for (int j = 1; j < 256; ++j)
			fr[j] += fr[j - 1];
		for (int j = n; j >= 1; --j)
			b[fr[(a[j] >> i) & 255]--] = a[j];
		for (int j = 1; j <= n; ++j)
			a[j] = b[j];
	}

	for (int i = 1; i <= n; i += 10)
		fout << a[i] << " ";


	return 0;
}