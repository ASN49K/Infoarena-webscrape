#include <bits/stdc++.h>

using namespace std;
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
vector <int>v;
vector <int> f[10];
void sorta(long long a,long long b,long long put)
{
    if(a<b&&put>0)
    {
        int l[10];
        for(long long i=a; i<=b; i++)
        {
            long long cif=v[i]/put%10;
            f[cif].push_back(v[i]);
        }
        long long cnt=a;
        for(long long i=0; i<=9; i++)
        {
            l[i]=f[i].size();
            for(auto it:f[i])
            {
                v[cnt]=it;
                cnt++;
            }
            f[i].clear();
        }
        long long ant=a;
        for(long long i=0; i<=9; i++)
        {
            sorta(ant,ant+l[i]-1,put/10);
            ant=ant+l[i];
        }
    }
}
int main()
{
    long long n,a,b,c;
    fin>>n>>a>>b>>c;
    v.push_back(b);
    for(long long i=2; i<=n; i++)
        v.push_back((v[i-2]*a+b)%c);
    long long put=1e10;
    sorta(0,n-1,put);
    for(long long i=0; i<n; i+=10)
        fout<<v[i]<<" ";
    return 0;
}
