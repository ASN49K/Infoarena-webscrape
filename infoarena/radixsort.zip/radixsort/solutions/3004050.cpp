#include <bits/stdc++.h>
#define int long long
using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

int n, A, B, C, a[10000005], fr[10], b[10000005];

void RADIX_SORT()
{
    int r = 1e9, i, p = 1;
    while (p <= r)
    {
        for (i = 0; i <= 9; i++)
            fr[i] = 0;
        for (i = 1; i <= n; i++)
            fr[a[i] / p % 10]++;
        for (i = 1; i <= 9; i++)
            fr[i] += fr[i - 1];
        for (i = n; i >= 1; i--)
        {
            b[fr[a[i] / p % 10]] = a[i];
            fr[a[i] / p % 10]--;
        }
        for (i = 1; i <= n; i++)
            a[i] = b[i];
        p *= 10;
    }

}

int32_t main()
{
    int i;
    fin >> n >> A >> B >> C;
    a[1] = B;
    for (i = 2; i <= n; i++)
        a[i] = (A * a[i - 1] + B) % C;
    RADIX_SORT();
    for (i = 1; i <= n; i += 10)
        fout << a[i] << " ";

    return 0;
}
