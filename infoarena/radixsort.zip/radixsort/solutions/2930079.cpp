#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")
#define MAX 10000000
#define fastio ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
#define FILES freopen("radixsort.in","r",stdin);\
              freopen("radixsort.out","w",stdout);
using namespace std;
int n, v[MAX + 5], cat, p = 1, nr[10], aux[MAX + 5], ind[12];
long long a, b, c;
inline void radixSort(int p, int iter, int mx)
{
    for(int i = 0; i <= 9; ++i)
        nr[i] = ind[i] = 0;
    for(int i = 1; i <= n; ++i)
    {
        if(iter == 1 && i > 1)
            v[i] = (v[i - 1] * a + b) % c;
        int digit = (v[i] / p) % 10;
        nr[digit]++, ind[digit]++;
    }
    for(int i = 1; i <= 9; ++i)
        nr[i] += nr[i-1];
    for(int i = 1; i <= n; ++i)
    {
        int digit = (v[i] / p) % 10;
        aux[nr[digit] - ind[digit] + 1] = v[i], ind[digit]--;
    }

    if(iter == mx)
    {
        for(int i = 1; i <= n; i += 10)
            cout << aux[i] << ' ';
        return;
    }
    else
    {
        for(int i = 1; i <= n; ++i)
            v[i] = aux[i];
    }
}
int main()
{
    fastio
    FILES
    cin >> n >> a >> b >> c;
    v[1] = b;
    cat = (int)(log10(c)) + 1;
    for(int i = 1; i <= cat; ++i, p *= 10)
        radixSort(p, i, cat);
}
