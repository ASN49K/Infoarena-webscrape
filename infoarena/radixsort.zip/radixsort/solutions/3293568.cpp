#include <bits/stdc++.h>

using namespace std;
int v[10000000];
int temp[10000000];
int main()
{
    int n,A,B,C,mx;
    fin>>n>>A>>B>>C;
    v[0]=B;
    mx=v[0];
    for(int i=1;i<n;i++)
    {
        v[i]=(1ll*A*v[i-1]+B)%C;
        mx=max(mx,v[i]);
    }
    long long r=1,idx=1;
    while(r<=mx)
    {
        int freq[10]={0};
        for(int i=0;i<n;i++)
            freq[v[i]/r%10]++;
        for(int i=1;i<10;i++)
            freq[i]+=freq[i-1];
        for(int i=n-1;i>=0;i--)
        {
            freq[v[i]/r%10]--;
            temp[freq[v[i]/r%10]]=v[i];
        }
        for(int i=0;i<n;i++)
            v[i]=temp[i];
        r*=10;
    }
    for(int i=0;i<n;i+=10)
        fout<<v[i]<<' ';
    return 0;
}
