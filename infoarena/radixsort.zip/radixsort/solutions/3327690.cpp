#include <bits/stdc++.h>

using namespace std;

#define N 10000000
#define X 32
#define PAS 8
#define B 256
#define MASK 255

int v[N+1], v2[N+1], f[B], s[B];
vector <int> bk[B];

void rsort(int v2[], int n, int bits){
    int i;

    if (bits == X)
        return;

    memset(f, 0, sizeof(f));

    for (i=0; i<n; i++)
        f[v[i] >> bits & MASK]++;

    s[0] = 0;
    for (i=1; i<B; i++)
        s[i] = s[i - 1] + f[i - 1];

    for (i=0; i<n; i++)
        v2[s[v[i] >> bits & MASK]++] = v[i];

    rsort(v2, n, bits + PAS);
}

int main()
{
    ifstream cin ("radixsort.in");
    ofstream cout ("radixsort.out");

    int n, a, b, c, i;

    cin >> n >> a >> b >> c;

    v[0] = b;
    for (i=1; i<n; i++)
        v[i] = (v[i - 1] * a + b) % c;

    rsort(v2, n, 0);

    for (i=0; i<n; i++)
        //if (i % 10 == 0)
            cout << v[i] << ' ';

    return 0;
}
