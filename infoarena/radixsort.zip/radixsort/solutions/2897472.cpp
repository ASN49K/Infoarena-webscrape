/// Preset de infoarena
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

const int maxN = 10000005, base = 1000;
int n, a, b, c, v[maxN];
vector <int> x[base + 5];

int main()
{
    fin >> n >> a >> b >> c;
    v[1] = b;
    for(int i = 2; i <= n; i++)
        v[i] = (1LL * v[i - 1] * a + b) % c;
    int pow = 1;
    for(int i = 1; i <= 5; i++)
    {
        for(int j = 0; j <= base; j++)
            x[j].clear();
        for(int j = 1; j <= n; j++)
        {
            int cifra = v[j] % base;
            if(pow > 1)
                cifra = (v[j] / (pow / base)) % base;
            x[cifra].push_back(v[j]);
        }
        int ind = 0;
        for(int j = 0; j <= base; j++)
            for(int elem : x[j])
                v[++ind] = elem;
        pow *= base;
    }
    for(int i = 0; i < n / 10; i++)
        fout << v[10 * i + 1] << ' ';
    if(n % 10 != 0)
        fout << v[10 * (n / 10) + 1] << ' ';
    return 0;
}
