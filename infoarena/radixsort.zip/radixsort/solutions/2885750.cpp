#include <bits/stdc++.h>

using namespace std;


int n, cnt, key, i;
int A, B, C;
int v[10000001];
queue<int> b[256];

int main()
{
  FILE *fin, *fout;
  fin = fopen ("radixsort.in", "r");
  fscanf (fin, "%d%d%d%d", &n, &A, &B, &C);
  fclose (fin);
  v[1] = B;
  for (i = 2; i <= n; ++i)
    v[i] = (1LL * A * v[i - 1] + B) % C;
  for (key = 0; key < 25; key += 8) {
    for (i = 1; i <= n; ++i)
      b[(v[i] >> key) & 255].push(v[i]);
    cnt = 0;
    for (i = 0; i <= 255 && cnt < n; ++i)
      while (!b[i].empty()) {
        v[++cnt] = b[i].front();
        b[i].pop();
      }
    }
  fout = fopen ("radixsort.out", "w");
  for (i = 1; i <= n; i = i + 10)
    fprintf (fout, "%d ", v[i]);
  fclose (fout);
  return 0;
}
