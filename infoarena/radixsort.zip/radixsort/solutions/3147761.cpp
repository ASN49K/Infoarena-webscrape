#include <fstream>

#define max_sz 10000001
using namespace std;
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

long long n,a,b,c;

int v[max_sz];
int aux[max_sz];



void radix_sort()
{
    int bits = 32;
    int baza=(1<<8)-1;
    int f[baza+1];
    int lv = 8;

    for(int i=0;i<bits;i+=lv)
    {
        for(int j=0;j<=baza;j++)
            f[j]=0;
        for(int j=1;j<=n;j++)
            f[(v[j]>>i)&baza]++;
        for(int j=1;j<=baza;j++)
            f[j]+=f[j-1];
        for(int j=n;j>=1;j--)
            aux[f[(v[j]>>i)&baza]--]=v[j];
        for(int j=1;j<=n;j++)
            v[j]=aux[j];
    }

}

int main()
{
    fin>>n>>a>>b>>c;
    v[1]=b;
    for(int i=2;i<=n;i++)
        v[i]=(a*v[i-1]+b)%c;
    radix_sort();
    for(int i=1;i<=n;i+=10)
        fout<<v[i]<<' ';

}

