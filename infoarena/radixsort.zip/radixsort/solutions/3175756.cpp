#include <fstream>
#define MAXN 10000001

using namespace std;

ifstream fin ("radixsort.in");
ofstream fout ("radixsort.out");

long long n, a, b, c, v[MAXN],aux;

void sort(long long  v[], int st,int  dr,long long  btn) {
    if (st>=dr || btn == -1)
        return;
	int i,j;
    for (i=st,j=st; i<=dr; ++i)
        if((v[i] & (1 << btn))==0) {
            aux=v[j];
            v[j]=v[i];
            v[i]=aux;
            j++;
        }
    sort(v,st,j-1,btn-1);
    sort(v,j,dr,btn-1);
}

int i;

int main() {
    fin>>n>>a>>b>>c;
    v[1]=b;
    for (i=2; i<=n; i++)
        v[i] = ((a * v[i-1])%c + b) % c;
    sort(v,0,n,30);
    fout<<v[1]<<' ';
    for (i=11; i<=n; i+=10)
        fout<<v[i]<<' ';
    return 0;
}
