#include <bits/stdc++.h>
using namespace std;

ifstream in("radixsort.in");
ofstream out("radixsort.out");

vector<vector<int>> bucket(12);
int a, b, c, n, val;
vector<int> v;

int main() {
    in >> n >> a >> b >> c;


    v.push_back(b);

    for (int i = 1; i < n; i++) {
        val = (a * v[i - 1] + b) % c;
        v.push_back(val);
    }

    // Find the maximum to know how many digits we need
    int max_val = *max_element(v.begin(), v.end());

    for (int power = 1; max_val / power > 0; power *= 10) {
        // Place elements in buckets
        for (int i = 0; i < n; i++) {
            int digit = (v[i] / power) % 10;
            bucket[digit].push_back(v[i]);
        }

        // Collect elements back into v
        v.clear();
        for (int i = 0; i < 10; i++) {
            for (int x : bucket[i]) {
                v.push_back(x);
            }
            bucket[i].clear();
        }
    }

    // Output the sorted array
    for(int i=0;i<n;i+=10)
    out<<v[i]<<" ";

    return 0;
}
