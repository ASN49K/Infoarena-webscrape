#include <bits/stdc++.h>
using namespace std;

void solve() {
  
  size_t n, a, b, c;
  cin >> n >> a >> b >> c;

  array<queue<unsigned>, 512 * 512> s;

  for (size_t i = 0, x = b; i < n; i++) {
    s[x & 0xffff].push(static_cast<unsigned>(x));
    x = (a * x + b) % c;
  }

  array<queue<unsigned>, 512 * 512> p = move(s);
  for (queue<unsigned>& q : p) {
    while (!q.empty()) {
      unsigned x = q.front(); q.pop();
      s[(x & 0xffff0000) >> 16].push(x);
    }
  }

  int i = 10;
  for (queue<unsigned>& q : s) {
    while (!q.empty()) {
      if (i++ == 10) cout << q.front() << ' ', i = 1;
      q.pop();
    }
  }

}

int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("radixsort.in", "r", stdin);
  freopen("radixsort.out", "w", stdout);
  #endif

  ios_base::sync_with_stdio(false), cin.tie(NULL);

  solve();
}
