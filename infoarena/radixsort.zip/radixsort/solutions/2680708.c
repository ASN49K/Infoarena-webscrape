#include <stdio.h>
#define NMAX 10000000
#define MAX_BITS 32
#define BPS 8
#define BASE ( 1 << BPS )
#define MASK BASE - 1

int v[NMAX], aux[NMAX];
int f[BASE], ind[BASE];

void radsort( int v[], int aux[], int n, int b ) {
  int i;
  if( b != MAX_BITS ) {
    for( i = 0; i < BASE; i++ )
      f[i] = 0;
    for( i = 0; i < n; i++ )
      f[v[i]>>b&(MASK)]++;
    ind[0] = 0;
    for( i = 1; i < BASE; i++ )
      ind[i] = ind[i-1] + f[i-1];
    for( i = 0; i < n; i++ )
      aux[ind[v[i]>>b&(MASK)]++] = v[i];
    radsort( aux, v, n, b + BPS );
  }
}

int main() {
    FILE *fin, *fout;
    int n, i, a, b, c;
    fin = fopen( "radixsort.in", "r" );
    fscanf( fin, "%d%d%d%d", &n, &a, &b, &c );
    fclose( fin );
    v[0] = b;
    for( i = 0; i < n; i++ )
      v[i] = ( (long long)a * v[i-1] + b ) % c;
    radsort( v, aux, n, 0 );
    fout = fopen( "radixsort.out", "w" );
    for( i = 0; i < n; i += 10 )
      fprintf( fout, "%d ", v[i] );
    fclose( fout );
    return 0;
}
