#include <bits/stdc++.h>
using namespace std;

ifstream f("radixsort.in");
ofstream g("radixsort.out");
#define cin f
#define cout g

int main() {
    int n, a, b, c;
    cin >> n >> a >> b >> c;
    int v[n + 1];
    int aux[n + 1];
    int frecv[256];
    v[1] = b;
    for(int i = 2; i <= n; i++) {
        v[i] = (1LL * a * v[i - 1] + b) % c;
    }

    for(int p = 0; p < 32; p += 8) {
        for(int i = 0; i < 256; i++) 
            frecv[i] = 0;
        
        for(int i = 1; i <= n; i++) 
            frecv[(v[i] >> p) & 255]++;
        
        for(int i = 1; i < 256; i++) 
            frecv[i] += frecv[i - 1];
        
        for(int i = n; i >= 1; i--) 
            aux[frecv[(v[i] >> p) & 255]--] = v[i];

        for(int i = 1; i <= n; i++) 
            v[i] = aux[i];
    }

    for(int i = 1; i <= n; i += 10) {
        cout << v[i] << " ";
    }
    return 0;
}