#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
vector<int> v(10000000);
vector<queue<int>> bucket(256);
int main() 
{
    ll n,a,b,c;
	fin>>n>>a>>b>>c;
	v[0]=b;
	for(int i=1; i<n; i++){
		v[i]=(a*v[i-1]+b)%c;
	}
	for(int put=0;put<32;put+=8){
		for(int i=0; i<n; i++){
			bucket[(v[i]>>put)&255].push(v[i]);
		}
		int index=0;
		for(int i=0; i<256; i++){
		    while(!bucket[i].empty()){
		        v[index++]=bucket[i].front();
		        bucket[i].pop();
		    }
		}
	}
	for(int i=0; i<n; i+=10){
		fout<<v[i]<<" ";
	}
}