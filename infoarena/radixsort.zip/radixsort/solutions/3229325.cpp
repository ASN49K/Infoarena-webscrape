#include <bits/stdc++.h>
using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

int n, a[10000005];
vector<int> b[15];

int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int i, maxi, pas;
    long long j;
    fin >> n;
    for(i=1; i<=n; i++)
    {
        fin >> a[i];
        maxi = max(a[i], maxi);
    }
    for(j=1; maxi / j > 0; j *= 10)
    {
        for(i=1; i<=n; i++)
            b[(a[i] / j) % 10].push_back(a[i]);
        n = 0;
        for(i=0; i<=9; i++)
        {
            for(auto w : b[i]) a[++n] = w;
            b[i].clear();
        }
    }
    for(i=1; i<=n; i++)
        fout << a[i] << " ";
    return 0;
}
