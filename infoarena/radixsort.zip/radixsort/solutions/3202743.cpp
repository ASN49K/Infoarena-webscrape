#include <fstream>
#include <algorithm>

using namespace std;

ifstream f("radixsort.in");
ofstream g("radixsort.out");
int v[10000001];
int m[10][10000001];
int n, a, b, c;
int xmax;

void radix_sort()
{
    short q = 0;
    while(xmax != 0)
    {
        q++;
        xmax /= 10;
    }

    int d = 1;

    for(short y = 1; y<=q; y++)
    {
        for(short i = 0; i<=9; i++)
        {
            m[i][0] = 0;
        }

        if(y == 1)
        {
            d = 1;
        }
        else
        {
            d = d * 10;
        }

        for(int i = 1; i<=n; i++)
        {
            m[(v[i]/d)%10][0]++;
            m[(v[i]/d)%10][m[(v[i]/d)%10][0]] = v[i];
        }

        int ind = 0;
        for(short i = 0; i<=9; i++)
        {
            for(int j = 1; j<=m[i][0]; j++)
            {
                ind++;
                v[ind] = m[i][j];
            }
        }
    }
}

int main()
{
    f>>n>>a>>b>>c;
    v[1] = b;
    xmax = v[1];
    for(int i = 2; i<=n; i++)
    {
        v[i] = (1LL*a * v[i-1] % c + b) % c;
        xmax = max(xmax, v[i]);
    }

    radix_sort();

    for(int i = 1; i<=n; i+=10)
    {
        g<<v[i]<<" ";
    }
    return 0;
}

/*#include <bits/stdc++.h>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

const int NMAX = 1e7;
const int BITS = 12;
const int LOGMAX = 32;
const int MASK = (1LL << BITS) - 1;

int n, a, b, c;
int v[NMAX], helper[NMAX], frq[MASK + 1], idx[MASK + 1];

int main() {
	ios_base :: sync_with_stdio(false);

	fin >> n >> a >> b >> c;
	v[0] = b;
	for(int i = 1; i < n; i++) {
		v[i] = ((long long) a * v[i - 1] + b) % c;
	}

	for(int bit = 0; bit < LOGMAX; bit += BITS) {
		memset(frq, 0, sizeof(frq));
		for(int i = 0; i < n; i++) {
			frq[(v[i] >> bit) & MASK]++;
		}
		idx[0] = 0;
		for(int i = 1; i <= MASK; i++) {
			idx[i] = idx[i - 1] + frq[i - 1];
		}
		for(int i = 0; i < n; i++) {
			helper[idx[(v[i] >> bit) & MASK]++] = v[i];
		}
		swap(helper, v);
	}

	for(int i = 0; i < n; i += 10) {
		fout << v[i] << " ";
	}
	fout << '\n';

	return 0;
}*/
