
#include <bits/stdc++.h>
using namespace std;

ifstream in("radixsort.in");
ofstream out("radixsort.out");

int fr[256];

int main() {
    int n, a, b, c;
    in >> n >> a >> b >> c;
    int v[n+1], aux[n+1];
    v[1] = b;
    for(int i = 2; i <= n; i++) {
        v[i] = (1LL * a * v[i - 1] + b) % c;
    }

    for(int p = 0; p < 32; p += 8) {
        for(int i = 0; i < 256; i++)
            fr[i] = 0;

        for(int i = 1; i <= n; i++)
            fr[(v[i] >> p) & 255]++;

        for(int i = 1; i < 256; i++)
            fr[i] += fr[i - 1];

        for(int i = n; i >= 1; i--)
            aux[fr[(v[i] >> p) & 255]--] = v[i];

        for(int i = 1; i <= n; i++)
            v[i] = aux[i];
    }

    for(int i = 1; i <= n; i += 10)
        out << v[i] << " ";
    return 0;
}
