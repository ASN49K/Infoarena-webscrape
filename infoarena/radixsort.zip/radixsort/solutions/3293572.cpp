#include <bits/stdc++.h>

using namespace std;
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
int v[2][10000000];
int main()
{
    int n,A,B,C;
    long long mx,mx2=1;
    fin>>n>>A>>B>>C;
    v[0][0]=B;
    mx=v[0][0];
    for(int i=1;i<n;i++)
    {
        v[0][i]=(1ll*A*v[0][i-1]+B)%C;
        mx=max(mx,1ll*v[0][i]);
    }
    while(mx/10)
    {
        mx2*=10;
        mx/=10;
    }
    int idx=0;
    while(mx<=mx2)
    {
        int freq[10]={0};
        for(int i=0;i<n;i++)
            freq[v[idx%2][i]/mx%10]++;
        for(int i=1;i<10;i++)
            freq[i]+=freq[i-1];
        for(int i=n-1;i>=0;i--)
        {
            freq[v[idx%2][i]/mx%10]--;
            v[(idx+1)%2][freq[v[idx%2][i]/mx%10]]=v[idx%2][i];
        }
        mx*=10,idx++;
    }
    for(int i=0;i<n;i+=10)
        fout<<v[idx%2][i]<<' ';
    return 0;
}
