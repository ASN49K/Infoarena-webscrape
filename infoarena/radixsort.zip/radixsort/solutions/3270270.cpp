#include <bits/stdc++.h>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
int n, a, b, c, v[10000002];
int cp[10000002];
int fr[12];

static inline void Sort(int put) {
    for(int i = 0; i <= 9; i++) fr[i] = 0;
    for(int i = 1; i <= n; i++) fr[(v[i] / put) % 10]++;
    for(int i = 1; i <= 9; i++) fr[i] += fr[i - 1];

    for(int i = n; i >= 1; i--) {
        cp[fr[(v[i] / put) % 10] - 1] = v[i];
        fr[(v[i] / put) % 10]--;
    }

    for(int i = 1; i <= n; i++) v[i] = cp[i];
}

static inline void Radix() {
    int ma = v[1];
    for(int i = 2; i <= n; i++) ma = max(ma, v[i]);

    for(unsigned long long i = 1; ma / i > 0; i *= 10) Sort(i);
}

int main() {
    fin >> n >> a >> b >> c;

    v[1] = b;
    for(int i = 2; i <= n; i++) v[i] = (long long)(a * v[i - 1] + b) % c;

    Radix();

    for(int i = 1; i <= n; i += 10) fout << v[i] << " ";

    return 0;
}
