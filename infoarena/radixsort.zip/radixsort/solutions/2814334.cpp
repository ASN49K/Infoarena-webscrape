#include <bits/stdc++.h>
using namespace std;

void radixSort(vector<int>& v){
    const int INT_BITS = 30;
    const int BUCKET_BITS = 8;
    const int BUCKET_SIZE = (1 << BUCKET_BITS);

    vector<vector<deque<int>>> buckets(2, vector<deque<int>>(BUCKET_SIZE));
    for(int num: v){
        buckets[0][num & (BUCKET_SIZE - 1)].push_back(num);
    }

    int step = 1;
    while(step * BUCKET_BITS <= INT_BITS){
        const int SHIFT_BITS = step * BUCKET_BITS;
        for(int i = 0; i < BUCKET_SIZE; ++i){
            while(!buckets[(step - 1) % 2][i].empty()){
                int num = buckets[(step - 1) % 2][i].front();
                buckets[step % 2][(num >> SHIFT_BITS) & (BUCKET_SIZE - 1)].push_back(num);
                buckets[(step - 1) % 2][i].pop_front();
            }
        }
        step += 1;
    }
    step -= 1;

    v.clear();
    for(int i = 0; i < BUCKET_SIZE; ++i){
        while(!buckets[step % 2][i].empty()){
            int num = buckets[step % 2][i].front();
            v.push_back(num);
            buckets[step % 2][i].pop_front();
        }
    }
}

int main(){
    ifstream cin("radixsort.in");
    ofstream cout("radixsort.out");

    int N;
    cin >> N;

    int A, B, C;
    cin >> A >> B >> C;

    vector<int> v(N);
    v[0] = B;
    for(int i = 1; i < N; ++i){
        v[i] = (A * v[i - 1] + B) % C;
    }

    radixSort(v);

    for(int i = 0; i < N; i += 10){
        cout << v[i] << " ";
    }

    cin.close();
    cout.close();
    return 0;
}