//sorteaza dupa fiecare cifra a ficarui numar
// complexitate O(kn), k=nr max de cifre al unui nr
#include <bits/stdc++.h>

using namespace std;
ifstream f("radixsort.in");
ofstream g("radixsort.out");

deque <int> backet[256];
int v[10000000];

int main()
{
    int n,a,b,c,i,j,t,poz;

    f>>n>>a>>b>>c;
    //generam numerele (nu ni-se dau)
    v[0]=b;
    for(i=1;i<n;i++)
        v[i]=(1LL*a*v[i-1]+b)%c;

    int pow=0;
    for(i=1;i<=4;i++)//impartim numerele in cate 4 bucati de cate 8 biti
    {
        for(j=0;j<n;j++)
        {
            poz=(v[j]>>pow)&255;
            backet[poz].push_back(v[j]);
        }

        j=0;
        for(t=0;t<=255;t++)//acum nr sunt sortate pentru primii i biti(de la coada)
            while(!backet[t].empty())
        {
            v[j++]=backet[t].front();
            backet[t].pop_front();
        }
        pow+=8;
    }
    for(i=0;i<n;i+=10)
        g<<v[i]<<' ';

//Obs: Se poate face si cu 10 backeturi pentru fiecare cifra in loc de 4 bytes.
    return 0;
}
