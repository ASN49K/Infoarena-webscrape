#include <fstream>

using namespace std;
ifstream in("radixsort.in");
ofstream out("radixsort.out");
long int n,a,b,c,i;
int v[10000000];
void radixsort(int v[], int n)
{
    int x[256], aux[n], j, i;
    for(i=0; i<32; i+= 8)
    {
        for(j=0;j<256;j++) x[j]=0;
        for(j=0;j<n;j++) x[(v[j] >> i) & 255] ++;
        for(j=1;j<256;j++) x[j] += x[j - 1];
        for (j=n-1;j>=0;j--)
        {
            x[(v[j]>>i)&255]--;
            aux[x[(v[j]>>i)&255]]=v[j];
        }
        for(j=0;j<n;j++)v[j]=aux[j];
    }
}
int main()
{
    in>>n>>a>>b>>c;
    v[0]=b;
    for(i=0;i<n;i++)
    {
        v[i]=(v[i-1]*a+b)%c;
    }
    radixsort(v,n);
    for(i=0;i<n;i+=10)
    {
        out<<v[i]<<" ";
    }
    return 0;
}
