#include <fstream>
#include <vector>

using namespace std;
ifstream f ("radixsort.in");
ofstream g ("radixsort.out");

int n , a1 , b , c , v[1000005] , maxi , divider = 0 , k = 0 , cnt = 0 , i;

vector < int > a[12];

int main() {


    f >> n >> a1 >> b >> c;
    v[1] = b;
    for (int i = 2 ; i <= n ; i++)
        v[i] = (1LL * a1 * v[i - 1] + b) % c , maxi = max (maxi , v[i]);


        divider = 1;
        while (divider < maxi)
        {
            for (int i = 1 ; i <= n ; i++)
            {
                int u = (v[i] / divider) % 10;
                a[u].push_back (v[i]);
            }
            k = 0;
            for (int i = 0 ; i <= 9 ; i++)
            {
                for (int j = 0 ;j < a[i].size() ; j++)
                {
                    k++;
                    v[k] = a[i][j];
                }
            }
            for (int i = 0 ; i <= 9 ; i++)
                a[i].clear();


            divider = divider * 10;
        }

        cnt = 1;
        while (cnt <= n)
        {
            g << v[cnt] <<" ";
            cnt = cnt + 10;
        }

    return 0;
}
