#include <fstream>
using namespace std;
ifstream  fin("radixsort.in");
ofstream fout("radixsort.out");
int N,A,B,C,v[10000002];
void rs(int *v, int r, int p, int q){
    if(r<0 || p>=q)return;
    int i=p,j=q;
    while(i<=j && !((v[i]>>r)&1))i++;
    while(j>=i &&  ((v[j]>>r)&1))j--;
    while(i<j){
        int aux=v[i]; v[i]=v[j]; v[j]=aux;
        while(i<=j && !((v[i]>>r)&1))i++;
        while(j>=i &&  ((v[j]>>r)&1))j--;
    }
    rs(v,r-1,p,  j);
    rs(v,r-1,j+1,q);
}
int main(){
    fin>>N>>A>>B>>C;
    v[1]=B;
    for(int i=2;i<=N;i++){
        v[i] = ((long long)A * v[i-1] + B) % C;
    }
    rs(v,30,1,N);
    for(int i=1;i<=N;i=i+10){
        fout<<v[i]<<" ";
    }

    fout.close();
    fin.close();
    return 0;
}
