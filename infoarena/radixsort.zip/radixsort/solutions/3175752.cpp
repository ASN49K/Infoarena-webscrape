#include <bits/stdc++.h>
#define int long long
using namespace std;

int v[500005];
void quicksort(int v[], int begin, int end)
{
    int pivot=v[(begin+end)/2];

    int b=begin,e=end;
    while(v[b]<pivot)
        b++;

    while(v[e]>pivot)
        e--;

    while(b<e)
    {
        swap(v[b], v[e]);

        b++;
        while(v[b]<pivot)
            b++;

        e--;
        while(v[e]>pivot)
            e--;
    }

    if (begin<e)
        quicksort(v, begin, e);
    if (e+1<end)
        quicksort(v, e + 1, end);
}


int32_t main()
{
    ifstream cin("radixsort.in");
    ofstream cout("radixsort.out");
    int n,a,b,c;
    cin>>n>>a>>b>>c;
    v[1]=b;
    for(int i=2;i<=n;i++)
        v[i]=(a*v[i-1]+b)%c;
    quicksort(v, 1, n);

    for(int i=1;i<=n;i+=10)
        cout<<v[i]<<" ";

    return 0;
}
