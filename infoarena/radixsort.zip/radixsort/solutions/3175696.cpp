#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

int v[10000001];

int main()
{
    ifstream cin("radixsort.in");
    ofstream cout("radixsort.out");
    int n, a, b, c, i;
    cin >> n >> a >> b >> c;
    v[1] = b;
    for(i = 2; i <= n; i++)
    {
        v[i] = (a * v[i - 1] + b) % c;
    }
    sort(v + 1, v + n + 1);
    for(i = 1; i <= n; i += 10)
    {
        cout << v[i] << " ";
    }
    return 0;
}
