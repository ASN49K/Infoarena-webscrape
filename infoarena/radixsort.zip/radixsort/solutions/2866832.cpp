#include <iostream>
#include <cstring>
#include <vector>
#include <fstream>
const int NMAX = 1.e8;
const int base = 8;

std::ifstream f("radixsort.in");
std::ofstream g("radixsort.out");

int t[2][NMAX + 5];
int fq[1 << base];

int main(){
    int n, i, j, k, a, b, c;
    
    f >> n >> a >> b >> c;

    t[0][0] = b;
    for(i = 1; i < n; i ++)
        t[0][i] = (1LL * a * t[0][i - 1] + b) % c;

    k = 0;
    for(i = 0; i < 32; i += base){
        for(j = 0; j < n; ++ j)
            fq[(t[k][j] >> i) & ((1 << base) - 1)] ++;
        for(j = 1; j < (1 << base); ++ j)
            fq[j] += fq[j - 1];
        for(j = n - 1; j >= 0; -- j){
            t[k ^ 1][fq[(t[k][j] >> i) & ((1 << base) - 1)] - 1] = t[k][j];
            fq[(t[k][j] >> i) & ((1 << base) - 1)] --;
        }
        memset(fq, 0, sizeof(fq));
        k = (k ^ 1);
    }
    for(i = 0; i < n; i += 10)
        g << t[k][i] << " ";
    return 0;
}