#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream  fin("radixsort.in");
ofstream fout("radixsort.out");
const int MOD=1000000;
int v[10000005],v2[10000005],poz[1000002],nr[1000002],n,vmax,p,A,B,C,c,i,cc,k,j,x;
int main()
{
    fin>>n>>A>>B>>C;
    v[1]=B;
    for(i=2;i<=n;i++)
    {
        v[i]=((long long)A*v[i-1]+B)%C;
        vmax=max(vmax,v[i]);
    }
    c=0;
    while(vmax>0)
    {
        c++;
        vmax=vmax/MOD;
    }
    p=1;
    for(cc=1;cc<=c;cc++)
    {
        for(i=1;i<=n;i++)
        {
            nr[v[i]/p%MOD]++;
        }
        poz[0]=0;
        for(i=1;i<=MOD-1;i++)
        {
            poz[i]=poz[i-1]+nr[i-1];
        }
        for(i=1;i<=n;i++)
        {
            x=v[i]/p%MOD;
            poz[x]++;
            v2[poz[x]]=v[i];
        }
        for(i=1;i<=n;i++)
        {
            v[i]=v2[i];
        }
        p=p*MOD;
    }
    for(i=1;i<=n;i=i+10)
    {
        fout<<v[i]<<" ";
    }
    fin.close();
    fout.close();
    return 0;
}
