#include <fstream>
#define MAXN 10000001

using namespace std;

ifstream fin ("radixsort.in");
ofstream fout ("radixsort.out");

long long n, a, b, c, v[MAXN];
void swap(int a, int b) {
    int aux;
    aux=b;
    b=a;
    a=aux;
}

void sort(long long  v[], long long  st,long long  dr,long long  btn) {
    if (st>=dr || btn == -1)
        return;
    long long i,j;
    for (i=st,j=st; i<=dr; ++i)
        if((v[i] & (1 << btn))==0) {
            swap(v[i],v[j]);
            j++;
        }
	sort(v,st,j-1,btn-1);
	sort(v,j,dr,btn-1);
}


int main() {
	fin>>n>>a>>b>>c;
	v[1]=b;
    for (int i=2;i<=n;i++)
        v[i] = ((a * v[i-1])%c + b) % c;
	sort(v,0,n,30);
	for (int i=1;i<=n;i+=10)
		fout<<v[i]<<' ';
    return 0;
}
