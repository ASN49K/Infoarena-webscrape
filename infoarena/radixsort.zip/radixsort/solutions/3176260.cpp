#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

int main()
{
    ifstream cin ("radixsort.in");
    ofstream fout ("radixsort.out");
    int n,a,b,c,ant,i;
    cin>>n>>a>>b>>c;
    int v[n];
    v[0]=b;
    for(i=1;i<n;i++)
        v[i]=(a*v[i-1]+b)%c;
    sort(v, v+n);
    for(i=0;i<n;i+=10)
        cout<<v[i]<< ' ';

    return 0;
}
