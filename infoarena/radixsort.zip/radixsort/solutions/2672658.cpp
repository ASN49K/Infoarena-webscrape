#include <bits/stdc++.h>
using namespace std;
ifstream f("radixsort.in");
ofstream g("radixsort.out");
long long n,a,b,c,k,i;
int v[10000001],aux[10000001],cnt[260],nr[260];
int radixsort(int v[],int aux[],int n,int x)
{
    memset(cnt,0,sizeof(cnt));
    for(int i=0;i<n;i++)
    {
        int cifra=((v[i]>>x)&255);
        cnt[cifra]++;
    }
    nr[0]=0;
    for(int i=1;i<256;i++)
        nr[i]=cnt[i-1]+nr[i-1];
    for(int i=0;i<n;i++)
        {
            int cifra=((v[i]>>x)&255);
            aux[nr[cifra]++]=v[i];
        }
}
int main()
{
    f>>n>>a>>b>>c;
    k=sizeof(v[0]);
    v[0]=b;
    for(i=1;i<n;i++)
        v[i]=(a*v[i-1]%c+b)%c;
    for(i=0;i<k;i++)
        if(i%2) radixsort(aux,v,n,i*8);
        else radixsort(v,aux,n,i*8);
    for(i=0;i<n;i+=10)
        g<<v[i]<<" ";
    return 0;
}
