// restrictii tampite
#include <bits/stdc++.h>

using namespace std;

const int N = 1e7 + 10;

int n, a, b, c;
int v[N], temp[N], offset[2];

int main() {
    ifstream cin("radixsort.in");
    ofstream cout("radixsort.out");

    cin >> n >> a >> b >> c;

    v[0] = b;
    for (int i = 1; i < n; i++) {
        v[i] = (1ll * a * v[i - 1] + b) % c;
    }

    for (int bit = 0; bit < 31; bit++) {
        memset(temp, 0, sizeof(temp));
        memset(offset, 0, sizeof(offset));
        
        for (int i = 0; i < n; i++) {
            if (v[i] & (1 << bit)) {
                offset[1]++;
            } else {
                offset[0]++;
            }
        }

        offset[1] = offset[0];
        offset[0] = 0;

        for (int i = 0; i < n; i++) {
            if (v[i] & (1 << bit)) {
                temp[offset[1]++] = v[i];
            } else {
                temp[offset[0]++] = v[i];
            }
        }

        for (int i = 0; i < n; i++) {
            v[i] = temp[i];
        }
    }

    for (int i = 0; i < n; i += 10) {
        cout << v[i] << ' ';
    }

    return 0;
}