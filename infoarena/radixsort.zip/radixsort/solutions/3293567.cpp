#include <bits/stdc++.h>

using namespace std;
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
int v[2][10000000];
int main()
{
    int n,A,B,C,mx;
    fin>>n>>A>>B>>C;
    v[0][0]=B;
    mx=v[0][0];
    for(int i=1;i<n;i++)
    {
        v[0][i]=(1ll*A*v[0][i-1]+B)%C;
        mx=max(mx,v[0][i]);
    }
    long long r=1,idx=0;
    while(r<=mx)
    {
        int freq[10]={0};
        for(int i=0;i<n;i++)
            freq[v[idx%2][i]/r%10]++;
        for(int i=1;i<10;i++)
            freq[i]+=freq[i-1];
        for(int i=n-1;i>=0;i--)
        {
            freq[v[idx%2][i]/r%10]--;
            v[(idx+1)%2][freq[v[idx%2][i]/r%10]]=v[idx%2][i];
        }
        r*=10,idx++;
    }
    for(int i=0;i<n;i+=10)
        fout<<v[idx%2][i]<<' ';
    return 0;
}
