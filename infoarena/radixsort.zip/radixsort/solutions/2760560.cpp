//sorteaza dupa fiecare cifra a ficarui numar
// complexitate O(kn), k=nr max de cifre al unui nr
#include <fstream>
#include <vector>

using namespace std;
ifstream f("radixsort.in");
ofstream g("radixsort.out");

vector <int> backet[65536];
int v[10000001];

int digits(int nr)
{
    int cnt=0;
    while(nr>0)
    {
        cnt++;
        nr=nr/10;
    }
    return cnt;
}
int main()
{
    long long n,a,b,c,i,j,t,helper;
    f>>n>>a>>b>>c;

    //generam numerele (nu ni-se dau)
    v[0]=b;
    for(i=1;i<n;i++)
    {
        helper=(a*v[i-1]+b)%c;
        v[i]=helper;//ca sa ramana v de tip int
    }

    int pow=0;
    for(i=1;i<=2;i++)
    {
        for(j=n-1;j>=0;j--)
        {
            int poz=(v[j]>>pow)&65535;
            backet[poz].push_back(v[j]);
        }

        j=0;
        for(t=0;t<=65535;t++)//acum nr sunt sortate pentru primele i cifre(de la coada)
            while(!backet[t].empty())
        {
            v[j++]=backet[t].back();
            backet[t].pop_back();
        }
        pow+=16;
    }

    for(i=0;i<n;i+=10)
        g<<v[i]<<' ';

    return 0;
}
