#include<bits/stdc++.h>

const int MAXN = 10000000;

using namespace std;

void rdxsort( int v[], int left, int right, int bitNumber ) {
    if ( left > right || bitNumber == -1 ) {
        return ;
    }
    int i, j;
    for ( i = left, j = left; i <= right; i++ ) {
        if ( ( v[i] & ( 1 << bitNumber ) ) == 0 ) {
            swap ( v[i], v[j] );
            j++;
        }
    }
    rdxsort( v, left, j - 1, bitNumber - 1 );
    rdxsort( v, j, right, bitNumber - 1 );
} 

int v[MAXN + 5];

int main() {
    ifstream cin ( "radixsort.in" );
    ofstream cout ( "radixsort.out" );
    ios::sync_with_stdio ( false );
    cin.tie ( nullptr );
    unsigned int n, a, b, c;
    cin >> n >> a >> b >> c;
    v[0] = b;
    for ( unsigned int i = 1; i < n; i++ ) {
        v[i] = ( a * v[i - 1] + b ) % c;
    }
    rdxsort(v, 0, n - 1, 31);
    for ( unsigned int i = 0; i < n; i += 10 ) {
        cout << v[i] << " ";
    }

    return 0;
}