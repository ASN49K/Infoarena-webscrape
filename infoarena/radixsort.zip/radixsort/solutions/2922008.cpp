#include <fstream>
#include <iostream>
#include <vector>
#include <cassert>
#include <cstring>
#include <set>
#include <unordered_map>
#include <memory>
#include <deque>
#include <queue>
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <sstream>
#include <bitset>
 
using namespace std;
 
 
ifstream f("radixsort.in");
ofstream g("radixsort.out");
 
const unsigned int BITS = 255;
unsigned int N;
 
void sort(const unsigned int p, unsigned int v[], unsigned int vcopy[]) {
    const unsigned int mask = BITS << p;
    unsigned int cnt[BITS + 1];
 
    memset(cnt, 0, sizeof(cnt));
    for (unsigned int i = 0; i < N; i++) {
        //g << v[i] << ' ';
        ++cnt[(v[i] & mask) >> p];
    }
    //g << '\n';
 
    unsigned int ptr[BITS + 1];
    ptr[0] = 0;
    for (unsigned int c = 1; c <= BITS; c++) {
        ptr[c] = ptr[c - 1] + cnt[c - 1];
    }
    
    for (unsigned int i = 0; i < N; i++) {
        const unsigned int c = (v[i] & mask) >> p;
        vcopy[ptr[c]++] = v[i];
    }
 
    if (p >= 24)
        return;
    
    sort(p + 8, vcopy, v);
}
 
int main() {
    unsigned int A, B, C;
 
    f >> N >> A >> B >> C;
    unsigned int v[N], vcopy[N];
    v[0] = B;
    for (unsigned int i = 1; i < N; ++i) {
        v[i] = (1ULL * A * v[i - 1] + B) % C;
    }
 
    sort(0, v, vcopy);
 
    stringstream s;
    for (unsigned int i = 0; i < N; i += 10)
        s << v[i] << ' ';
    s << '\n';
 
    g << s.str();
 
    f.close();
    g.close();
    return 0;
}