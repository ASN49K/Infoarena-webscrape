#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
ifstream fin ("radixsort.in");
ofstream fout("radixsort.out");
const int BAZA=100000;
int n,V[1000001],aux[1000001],f[BAZA],A,B,C,maxim;
void count_sort(int digit)
{
    memset(f,0,sizeof(f));
    for(int i=1;i<=n;i++)
        f[(V[i]/digit)%BAZA]++;
    for(int i=1;i<BAZA;i++)
        f[i]+=f[i-1];
    for(int i=1;i<=n;i++)
        aux[f[(V[i]/digit)%BAZA]--]=V[i];
    for(int i=1;i<=n;i++)
        V[i]=aux[i];
}
void radix_sort()
{
    maxim=0;
    for(int i=1;i<=n;i++)
        maxim=max(maxim,V[i]);
    for(int d=1;maxim/d>0;d*=BAZA)
        count_sort(d);
}
int main()
{
	fin>>n>>A>>B>>C;
    V[1]=B;
    for(int i=2;i<=n;i++)
        V[i]=(A*1LL*V[i-1]+B)%C;
    radix_sort();
    for(int i=1;i<=n;i+=10)
        fout<<V[i]<<" ";
	return 0;
}
