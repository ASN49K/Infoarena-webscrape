#include <bits/stdc++.h>

using namespace std;
#define NMAX 100002
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

int n,a,b,c;

int main()
{
    fin>>n>>a>>b>>c;
    int v[NMAX];
    v[1]=b%c;
    for(int i=2;i<=n;i++)
        v[i]=(a*v[i-1]+b)%c;
    sort(v+1,v+n+1);
    for(int i=1;i<=n;i+=10)
        fout<<v[i]<<" ";
    return 0;
}
