#include <bits/stdc++.h>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

const int NMAX = 1e7;
const int BITS = 12;
const int LOGMAX = 32;
const int MASK = (1LL << BITS) - 1;

int n, a, b, c;
int v[NMAX], helper[NMAX], frq[MASK + 1], idx[MASK + 1];

int main() {
	ios_base :: sync_with_stdio(false);

	fin >> n >> a >> b >> c;
	v[0] = b;
	for(int i = 1; i < n; i++) {
		v[i] = ((long long) a * v[i - 1] + b) % c;
	}

	for(int bit = 0; bit < LOGMAX; bit += BITS) {
		memset(frq, 0, sizeof(frq));
		for(int i = 0; i < n; i++) {
			frq[(v[i] >> bit) & MASK]++;
		}
		idx[0] = 0;
		for(int i = 1; i <= MASK; i++) {
			idx[i] = idx[i - 1] + frq[i - 1];
		}
		for(int i = 0; i < n; i++) {
			helper[idx[(v[i] >> bit) & MASK]++] = v[i];
		}
		swap(helper, v);
	}

	for(int i = 0; i < n; i += 10) {
		fout << v[i] << " ";
	}
	fout << '\n';

	return 0;
}