// restrictii tampite
#pragma GCC optimize("03")
#include <bits/stdc++.h>

using namespace std;

const int N = 1e7 + 10;
const int SIZE = 32;
const int RADIX = 16;
const int MASK = (1 << RADIX) - 1;

int n, a, b, c;
int v[N], temp[N], offset[1 << RADIX];

int main() {
    ifstream cin("radixsort.in");
    ofstream cout("radixsort.out");

    cin >> n >> a >> b >> c;

    v[0] = b;
    for (int i = 1; i < n; i++) {
        v[i] = (1ll * a * v[i - 1] + b) % c;
    }

    for (int i = 0; i * RADIX < SIZE; i++) {
        memset(offset, 0, sizeof(offset));

        const int bit_offset = i * RADIX;
        for (int j = 0; j < n; j++) {
            offset[(v[j] >> bit_offset) & MASK]++;
        }

        for (int j = 1; j < (1 << RADIX); j++) {
            offset[j] += offset[j - 1];  
        }

        for (int j = (1 << RADIX) - 1; j > 0; j--) {
            offset[j] = offset[j - 1];
        }
        offset[0] = 0;

        for (int j = 0; j < n; j++) {
            temp[offset[(v[j] >> bit_offset) & MASK]++] = v[j];
        }

        for (int j = 0; j < n; j++) {
            v[j] = temp[j];
        }
    }

    for (int i = 0; i < n; i += 10) {
        cout << v[i] << ' ';
    }

    return 0;
}