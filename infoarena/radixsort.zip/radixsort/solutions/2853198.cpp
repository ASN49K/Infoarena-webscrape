#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define dbg(i) (cout<<#i<<" = "<<(i)<<'\n')

using ll = long long;
using ui = unsigned int;
const string fn = "radixsort";

ifstream fin(fn + ".in");
ofstream fout(fn + ".out");

ui n;
ui a[10000001];

class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};

// OutParser fout("radixsort.out");

void radix(ui mask) {
    vector<ui> v[256];
    for (ui i = 1; i <= n; ++i)
        v[(a[i] >> mask) & 255].pb(a[i]);
    n = 0;
    for (ui i = 0; i < 256; ++i)
        for (vector<ui>::iterator it = v[i].begin(); it != v[i].end(); it++)
            a[++n] = *it;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie();

    ui A, B, C;
    fin >> n >> A >> B >> C;
    a[1] = B;
    ui i, j, k;
    for (i = 2; i <= n; ++i)
        a[i] = (1LL * A * a[i - 1] + B) % C;
    for (ui i = 0; i < 32; i += 8)
        radix(i);

    for (i = 1; i <= n; i += 10)
        fout << a[i] << " ";


    return 0;
}
