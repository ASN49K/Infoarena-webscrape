#include <bits/stdc++.h>
using namespace std;

ifstream in("radixsort.in");
ofstream out("radixsort.out");

vector<queue<int>> bucket(10); // folosim 10 cozi, una pentru fiecare cifră 0–9
int a, b, c, n, val;
vector<int> v;

int main() {
    in >> n >> a >> b >> c;

    v.push_back(b); // valoarea inițială este b

    // Generare secvență
    for (int i = 1; i < n; i++) {
        val = (a * v[i - 1] + b) % c;
        v.push_back(val);
    }

    // Găsim cea mai mare valoare pentru a ști câte cifre are
    int max_val = *max_element(v.begin(), v.end());

    // Pentru fiecare cifră semnificativă
    for (int power = 1; max_val / power > 0; power *= 10) {
        // Distribuim valorile în cozi (bucket-uri)
        for (int i = 0; i < n; i++) {
            int digit = (v[i] / power) % 10;
            bucket[digit].push(v[i]);
        }

        // Recompunem vectorul v din cozi
        v.clear();
        for (int i = 0; i < 10; i++) {
            while (!bucket[i].empty()) {
                v.push_back(bucket[i].front());
                bucket[i].pop();
            }
        }
    }

    // Scriem fiecare al 10-lea element
    for (int i = 0; i < n; i += 10) {
        out << v[i] << " ";
    }

    return 0;
}
