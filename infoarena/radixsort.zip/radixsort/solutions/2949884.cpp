#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int main() {

  typedef long long llong;
  const int nmax = 1e7 + 7;

  int n, a, b, c;
  static vector<int> r[1 << 16][2];

  freopen("radixsort.in", "r", stdin);
  // freopen("radixsort.out", "w", stdout);
  ios_base::sync_with_stdio(false), cin.tie(NULL);

  cin >> n >> a >> b >> c;

  const int h = (1 << 16) - 1;

  llong t = b;

  r[b & h][0].push_back(b);

  for (int i = 1; i < n; i++) r[(t = (t * a + b) % c) & h][0].push_back(t);

  for (int i = 0; i <= h; i++) for (int k : r[i][0]) r[(k & ~h) >> 16][1].push_back(k);
  
  int o = 10;

  for (int i = 0; i <= h; i++) {
    const vector<int>& v = r[i][1];
    int sz = v.size();
    for (int j = 0; j < sz; j++, o++) if (o == 10) cout << v[j] << ' ', o = 0;
  }

}