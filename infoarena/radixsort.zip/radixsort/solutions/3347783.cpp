#include<bits/stdc++.h>
#include<random>
#pragma GCC optimize("Ofast, O3, unroll-loops")
using namespace std;

int partition(vector<int> &v, int left, int right) {
    int pivot = v[left + rand() % (right - left + 1)];
    int i = left - 1;
    int j = right + 1;

    while (true) {
        do {
            i++;
        } while (v[i] < pivot);

        do {
            j--;
        } while (v[j] > pivot);

        if (i >= j)
            return j;

        swap(v[i], v[j]);
    }
}

void QuickSort(vector<int> &v, int left, int right) {
    if (left >= right) return;

    int p = partition(v, left, right);
    QuickSort(v, left, p);
    QuickSort(v, p + 1, right);
}

int main(){
    freopen("algsort.in", "r", stdin);
    freopen("algsort.out", "w", stdout);


    int n;
    scanf("%d", &n);

    vector<int> v(n + 1, 0);
    for(int i = 1; i <= n; i++){
        scanf("%d", &v[i]);
    }
    srand(time(NULL));

    for (int i = 1; i <= n; ++i) {
        int poz_aleatoare = rand() % i + 1; // [1, i]
        swap(v[i], v[poz_aleatoare]);
    }

    QuickSort(v, 1, n);

    for(int i = 1; i <= n; i++){
        printf("%d ", v[i]);
    }
    return 0;
}