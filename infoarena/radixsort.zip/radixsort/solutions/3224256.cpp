#include <bits/stdc++.h>

using namespace std;
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
#define ll long long
const int MOD=10000;
const int N=1e8+1;
int v[N],vc[MOD],vrez[N];
int main()
{
    int n,a,b,c,maxi,i;
    ll exp;
    fin>>n>>a>>b>>c;
    v[1]=b;
    maxi=v[1];
    for(i=2;i<=n;i++){
        v[i]=(1LL*a*v[i-1]+b)%c;
        maxi=max(maxi,v[i]);
    }
    exp=1;
    while(exp<maxi)
    {
        for(i=1;i<=n;i++)
            vc[(v[i]/exp)%MOD]++;
        for(i=1;i<MOD;i++)
            vc[i]+=vc[i-1];
        for(i=n;i>0;i--)
        {
            vrez[vc[(v[i]/exp)%MOD]]=v[i];
            vc[(v[i]/exp)%MOD]--;
        }
         for(i=1;i<=n;i++)
            v[i]=vrez[i];
        for(i=0;i<MOD;i++)
            vc[i]=0;
        exp*=MOD;
    }
    for(i=1;i<=n;i+=10)
        fout<<v[i]<<" ";
    return 0;
}
