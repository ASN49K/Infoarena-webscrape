#include <bits/stdc++.h>

using namespace std;

int main() {
    ifstream cin("radixsort.in");
    ofstream cout("radixsort.out");

    int n, a, b, c;
    cin >> n >> a >> b >> c;
    vector<int> v(n);

    v[0] = b;
    for (int i = 1; i < n; i++) {
        v[i] = (1ll * a * v[i - 1] + b) % c;
    }

    vector<int> temp[2];
    for (int bit = 0; bit < 31; bit++) {
        for (int i = 0; i < 2; i++) {
            temp[i].clear();
        }
        
        for (int i = 0; i < n; i++) {
            if (v[i] & (1 << bit)) {
                temp[1].push_back(v[i]);
            } else {
                temp[0].push_back(v[i]);
            }
        }

        v.clear();
        for (int i = 0; i < 2; i++) {
            for (auto &it : temp[i]) {
                v.push_back(it);
            }
        }
    }

    for (int i = 0; i < n; i += 10) {
        cout << v[i] << ' ';
    }

    return 0;
}