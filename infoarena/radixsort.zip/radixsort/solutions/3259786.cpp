#include <bits/stdc++.h>
#define mxbits 32
#define base 256
#define mask 255
using namespace std;

int v[10000005], v2[10000005];
int f[base], ind[base];
void rsort(int v[], int aux[], int n, int bits){
    if(bits == mxbits){
        return;
    }
    memset(f, 0, sizeof(f));
    int i;
    for(i = 0; i < n; i++){
        ++f[((v[i] >> bits) & mask)];
    }
    ind[0] = 0;
    for(i = 1; i < base; i++){
        ind[i] = ind[i - 1] + f[i - 1];
    }
    for(i = 0; i < n; i++){
        aux[ind[((v[i] >> bits) & mask)]++] = v[i];
    }
    rsort(aux, v, n, bits + 8);
}
int main()
{
    ifstream cin("radixsort.in");
    ofstream cout("radixsort.out");
    int n, a, b, c;
    cin >> n >> a >> b >> c;
    v[0] = b;
    for(int i = 1; i < n; i++){
        v[i] = (a * v[i - 1] + b) % c;
    }
    rsort(v, v2, n, 0);
    for(int i = 0; i < n; i+=10){
        cout << v[i] << " ";
    }
    return 0;
}
