#include <fstream>
#include <bits/stdc++.h>

using namespace std;

ifstream  fin("radixsort.in");
ofstream fout("radixsort.out");

int N;
long long A,B,C;
vector<long long> v;

void quick_sort(vector<long long>& v){
    sort(v.begin(), v.end());
}

int main()
{
    fin>>N>>A>>B>>C;
    long long last = B;
    v.push_back(B);
    for(int i=2;i<=N;i++){
        last = (A * last + B) % C;
        v.push_back(last);
    }
    quick_sort(v);
    for(int i=0;i<N;i+=10)
        fout<<v[i]<<' ';
    return 0;
}
