#include <bits/stdc++.h>
using namespace std;

int n, a, b, c;

int main() {
    ifstream cin("radixsort.in");
    ofstream cout("radixsort.out");
    cin >> n >> a >> b >> c;
    vector<int> v(n + 1);
    vector<int> aux(n + 1);
    v[1] = b;
    for (int i = 2; i <= n; ++i) {
        v[i] = ((long long)a * v[i - 1] + b) % c;
    }
    for (int p = 1; p <= 1e9; p *= 10) {
        vector<int> cif[10];
        for (int i = 1; i <= n; ++i) {
            cif[v[i] / p % 10].push_back(v[i]);
        }
        int k = 0;
        for (int i = 0; i <= 9; ++i) {
            for (auto j : cif[i]) {
                aux[++k] = j;
            }
        }
        for (int i = 1; i <= n; ++i) {
            v[i] = aux[i];
        }
    }
    for (int i = 1; i <= n; i += 10) {
        cout << v[i] << " ";
    }
}
