#include <bits/stdc++.h>

using namespace std;

ifstream in("radixsort.in");
ofstream out("radixsort.out");

void countSort(vector<int> v, int n, int exp) {
    int output[n];
    int i, count[10] = {0};

    for (i = 0; i < n; i++)
        count[(v[i] / exp) % 10]++;

    for (i = 1; i < 10; i++)
        count[i] += count[i - 1];

    for (i = n - 1; i >= 0; i--) {
        output[count[(v[i] / exp) % 10] - 1] = v[i];
        count[(v[i] / exp) % 10]--;
    }

    for (i = 0; i < n; i++)
        v[i] = output[i];
}

void radixsort(vector<int> &v, int n) {
    int m = *max_element(v.begin(), v.end());
    for (int exp = 1; m / exp > 0; exp *= 10)
        countSort(v, n, exp);
}

int main() {
    int N, A, B, C;
    vector<int> v;
    in >> N >> A >> B >> C;
    int x;
    for (int i = 1; i <= N; ++i) {
        if (x == 1) {
            v.push_back(B);
        } else {
            x = (A * v[i - 1] + B) % C;
            v.push_back(x);
        }
    }
    radixsort(v, v.size() - 1);
    for (int i = 1; i < int(v.size()); ++i) {
        out << v[i] << ' ';
    }

    return 0;
}