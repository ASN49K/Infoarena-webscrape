#define _CRT_SECURE_NO_WARNINGS
#include <bits/stdc++.h>
using namespace std;
const char nl = '\n';
const char sp = ' ';
const int inf = 0x3f3f3f3f;
const int mod = 666013;
const char out[2][4]{ "NO", "YES" };
#define all(a) a.begin(), a.end()
using ll = long long;
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

const int nmax = 1e7;
ll n, a, b, c;
int* v, * w;
int frq[10]{ 0 };
int st[10]{ 0 };

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	fin >> n >> a >> b >> c;
	v = new int[n + 5];
	w = new int[n + 5];
	v[1] = b;
	for (int i = 2; i <= n; ++i) {
		v[i] = (a * v[i - 1] + b) % c;
	}
	ll p = 1;
	while (true) {
		for (int i = 0; i < 10; ++i) {
			frq[i] = 0;
		}
		for (int i = 1; i <= n; ++i) {
			frq[(v[i] / p) % 10]++;
		}
		if (frq[0] == n) {
			break;
		}
		st[0] = 1;
		for (int i = 1; i < 10; ++i) {
			st[i] = st[i - 1] + frq[i - 1];
		}
		for (int i = 1; i <= n; ++i) {
			w[st[(v[i] / p) % 10]++] = v[i];
		}
		swap(v, w);
		p *= 10;
	}
	for (int i = 1; i <= n; i += 10) {
		fout << v[i] << sp;
	}
	fout << nl;
}
