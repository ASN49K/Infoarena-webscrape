#include <fstream>
#include <algorithm>

using namespace std;

ifstream f("radixsort.in");
ofstream g("radixsort.out");
int v[10000005];
int m[10][10000005];
int n, a, b, c;
int xmax;

void radix_sort()
{
    int q = 0;
    while(xmax != 0)
    {
        q++;
        xmax /= 10;
    }

    int d = 1;

    for(int y = 1; y<=q; y++)
    {
        for(int i = 0; i<=9; i++)
        {
            m[i][0] = 0;
        }

        if(y == 1)
        {
            d = 1;
        }
        else
        {
            d = d * 10;
        }

        for(int i = 1; i<=n; i++)
        {
            m[(v[i]/d)%10][0]++;
            m[(v[i]/d)%10][m[(v[i]/d)%10][0]] = v[i];
        }

        int ind = 0;
        for(int i = 0; i<=9; i++)
        {
            for(int j = 1; j<=m[i][0]; j++)
            {
                ind++;
                v[ind] = m[i][j];
            }
        }
    }
}

int main()
{
    f>>n>>a>>b>>c;
    v[1] = b;
    xmax = v[1];
    for(int i = 2; i<=n; i++)
    {
        v[i] = (1LL*a * v[i-1] % c + b) % c;
        xmax = max(xmax, v[i]);
    }

    radix_sort();

    for(int i = 1; i<=n; i+=10)
    {
        g<<v[i]<<" ";
    }
    return 0;
}
