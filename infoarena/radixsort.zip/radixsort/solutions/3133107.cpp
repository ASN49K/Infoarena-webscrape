#define nume "radixsort"

#ifndef INFOARENA
#define fisier "../algorithm solutions/" nume
#define DBG
#else
#define fisier nume
#endif

#include <algorithm>
#include <cassert>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <vector>
#ifdef INFOARENA
#include <tr1/unordered_set>
#include <tr1/unordered_map>
using namespace std::tr1;
#else
#include <unordered_set>
#include <unordered_map>
#endif

using namespace std;

ifstream fin(fisier".in");
ofstream fout(fisier".out");

#define MAX_N 10000000 + 1
#define RADIX 0xFF
#define RADIX_SIZE 8
#define TOTAL_BYTES sizeof(numbers[0])

int n;
int numbers[MAX_N];

#define get_byte(x) ((x>>(byte * 8))&RADIX)

void countsort(int A[], int B[], int byte) {
    int counter[1<<RADIX_SIZE];
    int index[1<<RADIX_SIZE];
    
    memset(counter, 0, sizeof(counter));
    
    for(int i = 0; i < n; i ++)
        ++counter[get_byte(A[i])];
    
    index[0] = 0;
    
    for(int i = 1; i < 1<<RADIX_SIZE; i ++)
        index[i] = index[i-1] + counter[i-1];
    
    for(int i = 0; i < n; i ++)
        B[index[get_byte(A[i])]++] = A[i];
}
void radixsort() {
    int *temp = new int[n]; // avem nevoie de un array ca spatiu temporar
    for (int i = 0; i < TOTAL_BYTES; i ++) {
        if(i % 2 == 0)
            countsort(numbers, temp, i);// sortez dupa byte-ul i
        else
            countsort(temp, numbers, i);
    }
}
void read()
{
    int a,b,c;
    fin>>n>>a>>b>>c;
    
    numbers[0] = b % c;
    for(int i = 1; i < n; i ++)
        numbers[i] = (1LL * a * numbers[i-1] % c + b) % c;
}
void write(ofstream& f)
{
    for(int i = 0; i < n; i +=10)
        f << numbers[i]<< ' ';
    f<<endl;
}

int main()
{
    read();
    
    radixsort();
//    sort(numbers, numbers + n);
    
    write(fout);
    
    return 0;
}