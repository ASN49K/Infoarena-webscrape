#include <stdio.h>
#include <stdlib.h>

#define MAXN 10000000
#define GRUP 8
#define MASK 255

int v[MAXN], auxv[MAXN], frecv[MASK + 1];

void radixsort(int n, int max){
  int i, nrbits, t, aux;
  for(nrbits = 0; 0 < (max >> nrbits); nrbits += GRUP){
    for(i = 0; i < n; i++){
      frecv[v[i] >> nrbits & MASK]++;
    }
    t = frecv[0];
    frecv[0] = 0;
    for(i = 1; i <= MASK; i++){
      aux = frecv[i];
      frecv[i] = frecv[i - 1] + t;
      t = aux;
    }
    for(i = 0; i < n; i++){
      auxv[frecv[v[i] >> nrbits & MASK]] = v[i];
      frecv[v[i] >> nrbits & MASK]++;
    }
    for(i = 0; i < n; i++){
      v[i] = auxv[i];
      if(i <= MASK){
        frecv[i] = 0;
      }
    }
  }
}

int main()
{
    FILE *fin, *fout;
    int n, a, b, c, i, max;
    fin = fopen("radixsort.in", "r");
    fscanf(fin, "%d%d%d%d", &n, &a, &b, &c);
    fclose(fin);
    max = v[0] = b;
    for(i = 0; i < n; i++){
      v[i] = (a * v[i - 1] + b) % c;
      if(max < v[i]){
        max = v[i];
      }
    }
    radixsort(n, max);
    fout = fopen("radixsort.out", "w");
    for(i = 0; i < n; i += 10){
      fprintf(fout, "%d ", v[i]);
    }
    fclose(fout);
    return 0;
}
