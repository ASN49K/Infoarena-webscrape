#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;
long long n, a, b, c, cur, l = 1, l2 = 0;
vector <long long> v;
vector <long long> v2;
ifstream f ("radixsort.in");
ofstream g ("radixsort.out");
int main()
{
    f >> n >> a >> b >> c;
    v.push_back( b );
    cur = b;
    for( int i = 2; i <= n; ++i )
    {
        cur = (a * cur + b) % c;
        v.push_back( cur );
        ++l;
        //if( (i - 1) % 10 == 0 )
        //{
        //    ++l;
        //}
    }
    sort( v.begin(), v.begin() + n );
    int st = 0;
    while( st < l )
    {
        //g << v[st] << " ";
        if( st % 10 == 0 )
            v2.push_back( v[st] ), ++l2;
        ++st;
    }
    st = 0;
    while( st < l2 )
    {
        g << v2[st] << " ";
        ++st;
    }
    return 0;
}
