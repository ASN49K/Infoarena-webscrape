#include <iostream>
#include <fstream>
#include <vector>
#define MOD 1000000
#define nmax 10000005
using namespace std;
ifstream  fin("radixsort.in");
ofstream fout("radixsort.out");
int v[nmax],v2[nmax],poz[MOD+2],nr[MOD+2],n,vmax,c,i,cc,k,j,x;
long long p,A,B,C;
int main()
{
    fin>>n>>A>>B>>C;
    v[1]=B;
    vmax=v[1];
    for(i=2;i<=n;i++)
    {
        v[i]=(A*v[i-1]+B)%C;
        vmax=max(vmax,v[i]);
    }
    c=0;
    do
    {
        c++;
        vmax=vmax/MOD;
    } while(vmax>0);
    p=1;
    for(cc=1;cc<=c;cc++)
    {
        for(i=1;i<=n;i++)
        {
            nr[(v[i]/p)%MOD]++;
        }
        poz[0]=0;
        for(i=1;i<=MOD-1;i++)
        {
            poz[i]=poz[i-1]+nr[i-1];
        }
        for(i=1;i<=n;i++)
        {
            x=v[i]/p%MOD;
            poz[x]++;
            v2[poz[x]]=v[i];
        }
        for(i=1;i<=n;i++)
        {
            v[i]=v2[i];
        }
        for(i=0;i<=MOD-1;i++)
        {
            nr[i]=0;
        }
        p=p*MOD;
    }
    for(i=1;i<=n;i=i+10)
    {
        fout<<v[i]<<" ";
    }
    fin.close();
    fout.close();
    return 0;
}
