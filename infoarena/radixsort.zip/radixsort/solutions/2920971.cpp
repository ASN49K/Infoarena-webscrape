#include <bits/stdc++.h>
#define nmax 10000005
#define bmax (0xff)+5
using namespace std;

ifstream f("radixsort.in");
ofstream g("radixsort.out");

int v[nmax],n;
int a,b,c;

int buc[nmax];
int s[bmax];

int cifr(const int &n, const int &k)
{
    return ((n&(0xff)<<(k*8))>>(k*8));
}

int main()
{
    f>>n>>a>>b>>c;

    v[0]=b;
    long long inm;
    int i,k;
    for(i=1;i<n;i++)
    {
        inm=v[i-1];
        inm=(inm*a)%c;
        v[i]=(inm+b)%c;
        //cout<<v[i]<<' ';
    }
    for(k=0;k<4;k++)
    {
        memset(s,0,sizeof(s));
        for(i=0;i<n;i++)
        {
            s[cifr(v[i],k)]++;
        }
        for(i=1;i<bmax;i++)s[i]+=s[i-1];
        for(i=bmax-1;i>=1;i--) s[i]=s[i-1];
        s[0]=0;
        for(i=0;i<n;i++)
        {
            buc[s[cifr(v[i],k)]++]=v[i];
        }
        memcpy(v,buc,sizeof(v));
    }
    for(int i=0;i<n;i+=10)
    {
        g<<v[i]<<' ';
    }
    return 0;
}
