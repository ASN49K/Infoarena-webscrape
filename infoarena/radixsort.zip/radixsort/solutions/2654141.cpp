#include <fstream>
#include <vector>

using namespace std;

void radixsort(vector<uint> &vect)
{
	vector<uint> temp(vect.size());
	temp.reserve(vect.size());

	vector<uint> buckets(256);

	for (uint round = 0; round < sizeof(uint); round++) {
		for (uint i = 0; i < buckets.size(); i++)
			buckets[i] = 0;

		for (auto v : vect) {
			buckets[(v >> (round*8)) % 256]++;
		}

		for (uint i = 1; i < buckets.size(); i++)
			buckets[i] += buckets[i-1];

		for (int i = vect.size()-1; i >= 0; i--)
		{
			uint b = ((vect[i]) >> (round*8)) % 256;
			buckets[b]--;
			temp[buckets[b]] = vect[i];
		}

		temp.swap(vect);
	}

}


int main(int argc, char const *argv[])
{
	ifstream fin("radixsort.in");
	ofstream fout("radixsort.out");

	unsigned long long N, A, B, C;
	fin >> N >> A >> B >> C;

	vector<uint> v(N);
	v[0] = B;
	for (uint i = 1; i < N; i++)
	{
		v[i] = (((A * v[i-1]) % C + B) % C);
	}

	radixsort(v);
	for (uint i = 0; i < N; i += 10)
		fout << v[i] << ' ';

	return 0;
}