#include <cstdio>
#include <cstring>

using namespace std;

#define RADIX 1<<8
int counts[RADIX];

void radixsort(int numbers[], int aux[], int n, int current_byte) {
    memset(counts, 0, sizeof(counts));

	for(int i=0; i<n; ++i)
		++counts[(numbers[i] >> current_byte) & 0xFF];

	for(int i=1; i< RADIX; ++i)
		counts[i] += counts[i-1];

	for(int i=n - 1; i>=0; --i)
		aux[--counts[(numbers[i] >> current_byte) & 0xFF]] = numbers[i];
}


int numbers[10000001];
int aux[10000001];


int main() {
	freopen("radixsort.in", "r", stdin);
	freopen("radixsort.out", "w", stdout);

	int n, a, b, c, total_bytes = sizeof(numbers[0]);

	scanf("%d", &n);
	scanf("%d%d%d", &a, &b, &c);
   	numbers[0] = b;
    for(int i=1; i<n; ++i)
        numbers[i] = (1LL * a * numbers[i-1] % c + b) % c;

	for(int i=0; i<total_bytes; ++i)
		if (i&1)
			radixsort(aux, numbers, n, i * 8);
		else
			radixsort(numbers, aux, n, i * 8);


	for(int i=0; i<n; i += 10)
		printf("%d ", numbers[i]);


	return 0;
}
