#include <fstream>
#include <vector>

using namespace std;

ifstream f("radixsort.in");
ofstream g("radixsort.out");

int n, a, b, c, maxi;
vector<int> v, aux;

void radsort(int b)
{
    aux.clear(); int fr[35];
    for(int i = 0; i <= 32; i ++) fr[i] = 0;

    for(auto x : v)
        fr[(x / b) % 32] ++, aux.push_back(0);

    for(int i = 1; i <= 31; i ++) fr[i] += fr[i - 1];

    for(int i = n - 1; i >= 0; i --)
    {
        int ind = fr[(v[i] / b) % 32] - 1;
        aux[ind] = v[i]; fr[(v[i] / b) % 32] --;
    }

    v = aux;
}

int main()
{
    f >> n >> a >> b >> c;
    v.push_back(b);
    for(int i = 1; i < n; i ++)
    {
        int x = (a * v.back() + b) % c;
        maxi = max(maxi, x); v.push_back(x);
    }

    for(int i = 1; i < maxi; i *= 32)
        radsort(i);

    for(int i = 0; i < n; i += 10)
        g << v[i] << " ";
    return 0;
}
