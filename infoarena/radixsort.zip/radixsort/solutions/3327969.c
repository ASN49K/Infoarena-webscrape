#include <stdio.h>
#include <string.h>

#define NMAX 10000000
#define BITS_PER_STEP 4
#define BASE (1 << BITS_PER_STEP)
#define MASK (BASE - 1)

int v[NMAX], freq[BASE], aux[NMAX];

void radixSort( int v[], int begin, int end, int bit ) {
  int i, a;

  if ( begin < end && bit >= 0 ) {
    memset( freq, 0, sizeof( freq ) );

    for ( i = begin; i <= end; i++ )
      freq[(v[i] >> bit) & MASK]++;
    for ( i = 1; i < BASE; i++ )
      freq[i] += freq[i - 1];

    for ( i = begin; i <= end; i++ ) {
      freq[a = (v[i] >> bit) & MASK]--;
      aux[freq[a] + begin] = v[i];
    }

    for ( i = begin; i <= end; i++ )
      v[i] = aux[i];

    i = begin;
    while ( i < end ) {
      a = i;
      while ( i < end && ((v[i] >> bit) & MASK) == ((v[i + 1] >> bit) & MASK) )
        i++;
      radixSort( v, a, i, bit - BITS_PER_STEP );
      i++;
    }
  }
}

int main() {
  FILE *fin, *fout;
  int n, a, b, c, i;

  fin = fopen( "radixsort.in", "r" );
  fscanf( fin, "%d%d%d%d", &n, &a, &b, &c );
  fclose( fin );

  v[0] = b;
  for ( i = 1; i < n; i++ )
    v[i] = ((long long)a * v[i - 1] + b) % c;

  radixSort( v, 0, n - 1, 28 );

  fout = fopen( "radixsort.out", "w" );
  for ( i = 0; i < n; i += 10 )
    fprintf( fout, "%d ", v[i] );
  fputc( '\n', fout );
  fclose( fout );

  return 0;
}
