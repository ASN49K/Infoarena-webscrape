#include<cstdio>
#include<vector>
#include<algorithm>
using namespace std;
FILE*in=fopen("radixsort.in","r");
FILE*out=fopen("radixsort.out","w");
/*vector<int>*/ int w[4][1000000];
int it[4];
long long n,a,b,c,i,maxx,po=0,ct,j;
long long v[10000009];
int main()
{
    fscanf(in,"%d%d%d%d",&n,&a,&b,&c);
    v[0]=b;
    maxx=b;
    for(i=1;i<n;i++)
    {
        v[i]=(long long)(a*v[i-1]+b)%c;
        maxx=max(maxx,v[i]);
    }
    while((1<<po)<=maxx)
    {
        for(i=0;i<n;i++)
        {
            int buc=(v[i]>>po)%4;
            w[buc][it[buc]]=v[i];
            it[buc]++;
        }
        ct=0;
        for(i=0;i<4;i++)
        {
            for(j=0;j<it[i];j++)
            {
                v[ct]=w[i][j];
                ct++;
            }
            it[i]=0;
        }
        po+=2;
    }
    for(i=0;i<n;i+=10)
    {
        fprintf(out,"%d ",v[i]);
    }
}
