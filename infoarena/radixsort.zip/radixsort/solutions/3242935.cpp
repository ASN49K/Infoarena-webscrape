#include <fstream>
#include <iostream>
#include <algorithm>
using namespace std;

const int szamrendszer = 256;
int t[10*1000*1000];
int uj[10*1000*1000];

void stabil_counting_sort(int n, int exp)
{
    int db[szamrendszer] = {};

    for (int i = 0; i < n; ++i)
        db[ t[i]/exp % szamrendszer ]++;

    int hova[szamrendszer];

    hova[0] = 0;
    for (int i = 1; i < szamrendszer; i++)
        hova[i] = hova[i-1] + db[i-1];

    for (int i = 0; i < n; ++i) {
        int szj = t[i]/exp % szamrendszer;
        int pos = hova[szj];
        ++hova[szj];

        uj[pos] = t[i];
    }

    for (int i = 0; i < n; ++i)
        t[i] = uj[i];
}

int main()
{
    ifstream be("radixsort.in");
    ofstream ki("radixsort.out");

    int n;
    long long A, B, C;
    be >> n >> A >> B >> C;

    t[0] = B;
    int maximum = t[0];

    for (int i = 1; i < n; i++) {
        t[i] = (A * t[i-1] + B) % C;
        maximum = max(maximum, t[i]);
    }

    for (long long exp = 1; maximum / exp > 0; exp *= szamrendszer)
        stabil_counting_sort(n, exp);

    // növekvő?
    /*
    for (int i = 1; i < n; i++)
        if (t[i] < t[i-1])
            cout << "BAJ: " << i << endl;
    cout << "check1 vege..." << endl;
    */

    for (int i = 0; i < n; i+=10)
        ki << t[i] << " ";

    ki << endl;
    return 0;
}

int main2()
{
    ifstream out("output.txt");
    ifstream ok("/home/john/Downloads/grader_test7.ok");

    long long x;
    while (ok >> x) {
        long long y;
        if (out >> y) {
            if (x != y)
                cout << "kulonbozik: " << x << " " << y << endl;
            else
                ;//cout << ".";
        }
        else {
            cout << "out tul rovid!\n";
        }
    }

    if (out >> x)
        cout << "out tul hosszu\n";

    cout << "\nvege\n";
    return 0;
}

