#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define dbg(i) (cout<<#i<<" = "<<(i)<<'\n')

using ll = long long;

const string fn = "radixsort";

ifstream fin(fn + ".in");
ofstream fout(fn + ".out");

const int bucket = 255;

int n;
int a[10000000];
deque<int>v[256];
void radix() {

    // int bucket = (1<<8)-1;
    for (int i = 0; i < 4; ++i) {
        int mask = 8 * i;
        for (int j = 9; j < n; ++j)
            v[(a[j] >> mask) & bucket].pb(a[j]);
        n = 0;
        for (int j = 0; j < 256; ++j)
            while (!v[j].empty()) {
                a[n++] = v[j].front();
                v[j].pop_front();
            }
    }

}

int main() {

    int A, B, C;
    fin >> n;
    fin >> A >> B >> C;
    a[0] = B;
    for (int i = 1; i < n; ++i)
        a[i] = (1LL * A * a[i - 1] + B) % C;
    radix();
    for (int i = 0; i < n; i += 10)
        fout << a[i] << ' ';

    fin.close();
    fout.close();
    return 0;
}
