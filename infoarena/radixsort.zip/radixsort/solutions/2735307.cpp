#include <bits/stdc++.h>
using namespace std;
ifstream f("radixsort.in");
ofstream g("radixsort.out");
//#define int long long
const int Max = 1e7 + 1;
void nos()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
}
int n,a,b,c;
void read()
{
    f>>n>>a>>b>>c;
}
int v[Max],aux[Max];
int cnt[300];
const int BYTE = 8;
void solve()
{
    int i,j;
    v[1] = b;
    for(i=2; i<=n; i++)
        v[i] = (1LL*a*v[i-1] + b) % c;
//radix sort
    for(int i = 1; i <= 4; i++)
    {
        for(int j = 0; j < (1 << BYTE); j++)
            cnt[j] = 0;
        for(int j = 1; j <= n; j++)
            cnt[(v[j] >> ((i - 1) * BYTE)) & ((1 << BYTE) - 1)]++;
        for(int j = 0; j < (1 << BYTE); j++)
            cnt[j + 1] += cnt[j];
        for(int j = n; j >= 1; j--)
            aux[cnt[(v[j] >> ((i - 1) * BYTE)) & ((1 << BYTE) - 1)]--] = v[j];
        for(int j = 1; j <= n; j++)
            v[j] = aux[j];
    }
//radix sort
    for(i=1; i<=n; i+=10)
        g<<v[i]<<' ';
}
void restart()
{

}

int32_t main()
{

    read();
    solve();
    restart();

    return 0;
}
