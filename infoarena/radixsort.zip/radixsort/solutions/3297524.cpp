#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e7;
const int BASE = 65536;

int v[NMAX];

vector <int> frecv[BASE];

int main() {
    ifstream fin( "radixsort.in" );
    ofstream fout( "radixsort.out" );
    int n, a, b, c;
    fin >> n >> a >> b >> c;
    v[0] = b;
    for ( int i = 1; i < n; i ++ ) {
        v[i] = ((long long)a * v[i - 1] + b) % c;
        frecv[v[i] % BASE].push_back( v[i] );
    }
    int m = 0;
    for ( int i = 0; i < BASE; i ++ ) {
        for ( auto x : frecv[i] ) {
            v[m++] = x;
        }
        frecv[i].clear();
    }
    for ( int i = 0; i < n; i ++ ) {
        frecv[v[i] / BASE].push_back( v[i] );
    }
    m = 0;
    for ( int i = 0; i < BASE; i ++ ) {
        for ( auto x : frecv[i] ) {
            v[m++] = x;
        }
        frecv[i].clear();
    }
    for ( int i = 0; i * 10 < n; i ++ ) {
        fout << v[i * 10] << ' ';
    }
    return 0;
}