#include <bits/stdc++.h>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
long long n, a, b, c, x;
int cp[10000002], fr[12];
int v[10000002];

static inline void Sort(int put) {
    for(int i = 0; i <= 9; i++) fr[i] = 0;

    for(int i = 1; i <= n; i++) fr[(v[i] / put) % 10]++;
    for(int i = 1; i <= 9; i++) fr[i] += fr[i - 1];
    for(int i = n; i >= 1; i--) {
        cp[fr[(v[i] / put) % 10]] = v[i];
           fr[(v[i] / put) % 10]--;
    }

    for(int i = 1; i <= n; i++) v[i] = cp[i];
}

int main() {
    fin >> n >> a >> b >> c;

    x = b;
    v[1] = x;
    for(int i = 2; i <= n; i++) v[i] = (a * x + b) % c;

    int ma = v[1];
    for(int i = 2; i <= n; i++) ma = max(ma, v[i]);

    for(int i = 1; ma / i > 0; i *= 10) Sort(i);

    for(int i = 1; i <= n; i += 10) fout << v[i] << " ";
    fout << "\n";

    return 0;
}
