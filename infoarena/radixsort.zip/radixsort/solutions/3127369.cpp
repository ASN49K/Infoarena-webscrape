#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <bits/stdc++.h>

///#include <tryhardmode>
///#include <GODMODE::ON>
///Back in business...

using namespace std;

ifstream fin ("radixsort.in");
ofstream fout ("radixsort.out");

const int NMAX=1e7;
const int MASK=(1<<12)-1;

int v[NMAX+5];
int aux[NMAX+5];
int frecv[MASK+5];
int ind[MASK+5];

int main()
{
    int n,a,b,c,i,j,e;
    fin>>n>>a>>b>>c;
    v[0]=b;
    for(i=1;i<n;i++)
        v[i]=(1LL*(1LL*a*v[i-1]+b))%c;
    for(e=0;e<32;e+=12)
    {
        ind[0]=0;
        for(i=0;i<n;i++)
            frecv[(v[i]>>e) & MASK]++;
        for(i=1;i<=MASK;i++)
            ind[i]=ind[i-1]+frecv[i-1];
        for(i=0;i<n;i++)
            aux[ind[(v[i]>>e) & MASK]++]=v[i];
        swap(aux,v);
        memset(frecv,0,sizeof(frecv));
    }
    for(i=0;i<n;i+=10)
        fout<<v[i]<<" ";
    return 0;
}
