#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma GCC optimize("Ofast")

unsigned int byte[] = {0xff, 0xff00, 0xff0000, 0xff000000};

static inline void pass(int pass_nr, unsigned int *array, unsigned int *out, int N) {
    int count[256], index[256], i, sum, j, shift = (3 << pass_nr);
    
    memset(count, 0, 256*sizeof(int));
    memset(count, 0, 256*sizeof(int));
    
	for (i = 0; i < N; i++) {
	    count[(array[i] >> shift) & 0xff]++;
	}
	sum = 0;
	for (i = 0; i < 256; i++) {
		sum += count[i];
		count[i] = sum;
	}
	for (i = 0; i < 256; i++) {
		index[i] = count[i] - 1;
	}
	for (i = N - 1; i >= 0; i--) {
		j = (array[i] >> shift) & 0xff;
	    out[index[j]] = array[i];
	    index[j]--;
	}
}

static inline int compar(const void *a, const void *b) {
	unsigned int *x = (unsigned int *)a;
	unsigned int *y = (unsigned int *)b;
	
	/*if (*x > *y) return 1;
	if (*x == *y) return 0;
	return -1;*/
	
	return (*x > *y) + (*x == *y)*0 + (*x < *y)*(-1);
}

int main() {
    FILE *in=fopen("radixsort.in","r");
    FILE *out=fopen("radixsort.out","w");
    int N, A, B, C, i;
	unsigned long long int vi;
	
	fscanf(in,"%d %d %d %d",&N, &A, &B, &C);

	unsigned int *array_in  = malloc(N * sizeof(unsigned int));
	unsigned int *array_out = malloc(N * sizeof(unsigned int));
	
	vi = B;
	for (i = 0; i < N; i++) {
		if (i) {
		    //vi = (A * vi + B) % C;
		    vi = 1;
	    }
	    array_in[i] = vi;
	}
	
	pass(0, array_in, array_out, N);
	pass(1, array_out, array_in, N);
	pass(2, array_in, array_out, N);
	pass(3, array_out, array_in, N);
	
    //qsort(array_in, N, sizeof(unsigned int), compar);
	
	for (i = 0; i < N; i += 10)
	    fprintf (out, "%d ", array_in[i]);

	fclose(in);
	fclose(out);
	
	return 0;
}
