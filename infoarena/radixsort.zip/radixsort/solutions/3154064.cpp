#include <fstream>

using namespace std;
ifstream cin("radixsort.in");
ofstream cout("radixsort.out");
int v[10000001],aux[10000001];
void rad(int v[], int n, int mod)
{
    int vf[11]={0},i;
    for(i=1;i<=n;i++)
        vf[v[i]%mod/(mod/10)]++;
    for(i=0;i<=9;i++)
        vf[i]+=vf[i-1];
    for(i=n;i>=1;i--)
        aux[vf[v[i]%mod/(mod/10)]--]=v[i];
    for(i=1;i<=n;i++)
        v[i]=aux[i];
}
int main()
{
    int n,a,b,c,i;
    long long p;
    cin>>n>>a>>b>>c;
    v[1]=b;
    int nrm=v[1];
    for(i=2;i<=n;i++)
    {
        v[i]=(1LL*a*v[i-1]+b)%c;
        nrm=max(nrm,v[i]);
    }
    for(p=1;p<=nrm;p*=10)
        rad(v,n,p*10);
    for(i=1;i<=n;i+=10)
        cout<<v[i]<<" ";
    return 0;
}
