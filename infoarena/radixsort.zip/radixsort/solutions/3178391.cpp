#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")
using namespace std;

int v[10000001];
//int aux[10000001];
//int fv[10];

class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;
 
    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }
 
 
public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }
 
    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }
 
    OutParser& operator << (long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }
 
    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};

#ifndef HOME
    ifstream in("radixsort.in");
    OutParser out("radixsort.out");
    #define cin in
    #define cout out
#endif

int main()
{
#ifdef HOME
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#endif
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n, a, b, c;
    cin >> n >> a >> b >> c;
    v[1] = b;
    for(int i = 2; i <= n; i++)
        v[i] = (1LL * a * v[i - 1] + b) % c;
    /*for(int put = 1; put <= 1'000'000'000; put *= 10)
    {
        for(int i = 1; i <= n; i++)
            fv[v[i] / put % 10]++;
        for(int i = 1; i <= 9; i++)
            fv[i] += fv[i - 1];
        for(int i = n; i >= 1; i--)
        {
            aux[fv[v[i] / put % 10]] = v[i];
            fv[v[i] / put % 10]--;
        }
        for(int i = 1; i <= n; i++)
            v[i] = aux[i];
        for(int i = 0; i <= 9; i++)
            fv[i] = 0;
    }*/
    sort(v + 1, v + n + 1);
    for(int i = 1; i <= n; i += 10)
        cout << v[i] << " ";
    return 0;
}