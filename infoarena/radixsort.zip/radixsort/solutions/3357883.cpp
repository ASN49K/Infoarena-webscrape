#include <fstream>

using namespace std;

ifstream cin("radixsort.in");
ofstream cout("radixsort.out");

int v[10100100];
int aux[10100100];
int fv[256];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n, a, b, c;
    cin >> n >> a >> b >> c;

    v[0] = 0;
    for (int i = 1; i <= n; i++) {
        long long nr = 1LL * v[i - 1] * a + b;
        nr %= c;
        v[i] = (int)nr;
    }

    for (int shift = 0; shift < 32; shift += 8) {
        for (int i = 0; i < 256; i++) {
            fv[i] = 0;
        }

        for (int i = 1; i <= n; i++) {
            int nr = (v[i] >> shift) & 255;
            fv[nr]++;
        }

        for (int i = 1; i < 256; i++) {
            fv[i] += fv[i - 1];
        }

        for (int i = n; i >= 1; i--) {
            int nr = (v[i] >> shift) & 255;
            aux[fv[nr]] = v[i];
            fv[nr]--;
        }

        for (int i = 1; i <= n; i++) {
            v[i] = aux[i];
        }
    }

    for (int i = 1; i <= n; i += 10) {
        cout << v[i] << " ";
    }

    return 0;
}