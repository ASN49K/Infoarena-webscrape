#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#define get_byte(x) (((x)>>(byte * 8))& 255)
int n;
int numbers[10000001];
void countsort(const int A[], int B[], int byte) {
    int counter[1<<8];
    int index[1<<8];

    memset(counter, 0, sizeof(counter));

    for(int i = 0; i < n; i ++)
        ++counter[get_byte(A[i])];

    index[0] = 0;

    for(int i = 1; i < (1<<8); i ++)
        index[i] = index[i-1] + counter[i-1];

    for(int i = 0; i < n; i ++)
        B[index[get_byte(A[i])]++] = A[i];
}
void radixsort() {
    int *temp = new int[n]; // avem nevoie de un array ca spatiu temporar
    for (int i = 0; i < sizeof(numbers[0]); i ++) {
        if(i % 2 == 0)
            countsort(numbers, temp, i);// sortez dupa byte-ul i
        else
            countsort(temp, numbers, i);
    }
}

int main(){
    ifstream fin("radixsort.in");
    ofstream fout("radixsort.out");
    int a,b,c;
    fin >> n >> a >> b >> c;
    numbers[0] = b % c;
    for(int i = 1; i < n; i ++)
        numbers[i] = (1LL * a * numbers[i-1] % c + b) % c;
    radixsort();

    for(int i = 0; i < n; i +=10)
        fout << numbers[i]<< ' ';
    fout << "\n";
    return 0;
}