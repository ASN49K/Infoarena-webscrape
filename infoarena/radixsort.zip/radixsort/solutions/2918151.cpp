#define MAX_N 10000000
#define BUCKET_BITS 16

#include <fstream>
#include <list>
using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

int n, a, b, c;
list<int> buckets[2][1 << BUCKET_BITS];

int main()
{
	fin >> n >> a >> b >> c;
	for (int i = 1, x = b; i <= n; ++i, x = ((static_cast<long long>(a) * x) + b) % c)
		buckets[0][x % (1 << BUCKET_BITS)].push_back(x);
	for (int i = 0; i < (1 << BUCKET_BITS); ++i)
		for (int x : buckets[0][i])
			buckets[1][x >> BUCKET_BITS].push_back(x);
	for (int i = 0, count = 0; i < (1 << BUCKET_BITS); ++i)
		for (int x : buckets[1][i])
		{
			if ((count % 10) == 0)
				fout << x << ' ';
			++count;
		}
	fin.close();
	fout.close();
	return 0;
}