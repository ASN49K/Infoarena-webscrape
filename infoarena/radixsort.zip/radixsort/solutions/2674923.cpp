// Radix sort with base 2

#include <stdio.h>

void swap(int& a, int& b) {
  int aux = a;
  a = b;
  b = aux;
}

#define MAX_N 10000000

int v[MAX_N];

void sort(int v[], int left, int right, int bitNumber) {
  if (left >= right || bitNumber == -1)
    return;

  int i, j;
  for (i = left, j = left; i <= right; ++i)
    if ((v[i] & (1 << bitNumber)) == 0) {
      swap(v[i], v[j]);
      ++j;
    }

  sort(v, left, j - 1, bitNumber - 1);
  sort(v, j, right, bitNumber - 1);
}

int main() {
  FILE* fin = fopen("radixsort.in", "r");
  int n, a, b, c, i;
  fscanf(fin, "%d%d%d%d", &n, &a, &b, &c);
  fclose(fin);

  v[0] = b;
  for (i = 1; i < n; ++i)
    v[i] = ((long long)a * v[i - 1] + b) % c;

  sort(v, 0, n - 1, 30);

  FILE* fout = fopen("radixsort.out", "w");
  for (i = 0; i < n; i += 10)
    fprintf(fout, "%d ", v[i]);
  fclose(fout);
  return 0;
}
