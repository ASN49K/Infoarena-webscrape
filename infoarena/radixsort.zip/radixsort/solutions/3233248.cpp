#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <cstdint>

using namespace std;

// Function to generate the next number in the sequence
long long generateNext(long long prev, long long A, long long B, long long C) {
    return (A * prev + B) % C;
}

void countingSort(vector<long long>& arr, int n, long long exp) {
    vector<long long> output(n);
    int count[10] = {0};

    for (int i = 0; i < n; i++) {
        count[(arr[i] / exp) % 10]++;
    }

    for (int i = 1; i < 10; i++) {
        count[i] += count[i - 1];
    }

    for (int i = n - 1; i >= 0; i--) {
        output[count[(arr[i] / exp) % 10] - 1] = arr[i];
        count[(arr[i] / exp) % 10]--;
    }

    for (int i = 0; i < n; i++) {
        arr[i] = output[i];
    }
}

void radixSort(vector<long long>& arr, int n) {
    long long maxElement = *max_element(arr.begin(), arr.end());

    for (long long exp = 1; maxElement / exp > 0; exp *= 10) {
        countingSort(arr, n, exp);
    }
}

int main() {
    ifstream infile("radixsort.in");
    ofstream outfile("radixsort.out");

    long long N, A, B, C;
    infile >> N >> A >> B >> C;

    vector<long long> v(N);
    v[0] = B;

    // Generate the sequence directly into the vector
    for (int i = 1; i < N; i++) {
        v[i] = generateNext(v[i - 1], A, B, C);
    }

    radixSort(v, N);

    for (int i = 0; i < N; i += 10) {
        outfile << v[i] << " ";
    }

    infile.close();
    outfile.close();

    return 0;
}
