#include <bits/stdc++.h>
using namespace std;

using ll = long long;

const string fn = "radixsort";

ifstream fin(fn + ".in");
ofstream fout(fn + ".out");

int n;
int a[10000005];

void radix()
{
    vector<int> b0, b1;
    for (int bit = 0; bit < 32; ++bit)
    {
        b0 = b1 = vector<int>();
        for (int i = 1; i <= n; ++i)
            if ((a[i] & (1 << bit)) == 0)
                b0.push_back(a[i]);
            else b1.push_back(a[i]);
        n = 0;
        for (int num : b0)
            a[++n] = num;
        for (int num : b1)
            a[++n] = num;
    }
}

int main()
{
    int A, B, C;
    fin >> n >> A >> B >> C;
    a[1] = B;
    for (int i = 2; i <= n; ++i)
        a[i] = (A * a[i - 1] + B) % C;
    radix();
    for (int i = 1; i <= n; i += 10)
        fout << a[i] << " ";
    fout << '\n';
    fin.close();
    fout.close();
    return 0;
}