#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

const int MAXN=10000000

int v[MAXN + 1], aux[MAXN + 1];
int frecv[10];

int main()
{
    int A, B, C, N, i, p10;
    fin >> N >> A >> B >> C;
    v[1] = B;
    for (i = 2; i <= N; i++)
    {
        v[i] = (1LL * A * v[i - 1] + B) % C;
    }
    for (p10 = 1; p10 <= 1000000000; p10 *= 10)
    {
        for (i = 1; i <= N; i++)
        {
            frecv[v[i] / p10 % 10]++;
        }
        for (i = 1; i <= 9; i++)
        {
            frecv[i] += frecv[i - 1];
        }
        for (i = N; i >= 1; i--)
        {
            aux[frecv[v[i] / p10 % 10]] = v[i];
            frecv[v[i] / p10 % 10]--;
        }
        for (i = 1; i <= N; i++)
        {
            v[i] = aux[i];
        }
        for (i = 0; i <= 9; i++)
        {
            frecv[i] = 0;
        }
    }
    for (i = 1; i <= N; i += 10)
    {
        fout << v[i] << " ";
    }
    return 0;
}
