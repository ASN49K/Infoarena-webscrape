#include <stdio.h>
#include <stdlib.h>
///in antepenultima sursa uitasem un <= :)
#define MAXN 10000000
#define GRUP 16
#define MASK 65535
#define MAXBITS 32

int v[MAXN], auxv[MAXN], frecv[MASK + 1];

void radixsort(int n){
  int i, nrbits, t, aux;
  for(nrbits = 0; nrbits < MAXBITS; nrbits += GRUP){
    for(i = 0; i < n; i++){
      frecv[v[i] >> nrbits & MASK]++;
    }
    t = frecv[0];
    frecv[0] = 0;
    for(i = 1; i <= MASK; i++){
      aux = frecv[i];
      frecv[i] = frecv[i - 1] + t;
      t = aux;
    }
    for(i = 0; i < n; i++){
      auxv[frecv[v[i] >> nrbits & MASK]++] = v[i];
    }
    for(i = 0; i < n; i++){
      v[i] = auxv[i];
    }
    for(i = 0; i <= MASK; i++){
      frecv[i] = 0;
    }
  }
}

int main()
{
    FILE *fin, *fout;
    int n, a, b, c, i;
    fin = fopen("radixsort.in", "r");
    fscanf(fin, "%d%d%d%d", &n, &a, &b, &c);
    fclose(fin);
    v[0] = b;
    for(i = 1; i < n; i++){
      v[i] = ((long long)a * v[i - 1] + b) % c;
    }
    radixsort(n);
    fout = fopen("radixsort.out", "w");
    for(i = 0; i < n; i += 10){
      fprintf(fout, "%d ", v[i]);
    }
    fclose(fout);
    return 0;
}
