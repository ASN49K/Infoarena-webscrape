#include <bits/stdc++.h>
using namespace std;

ifstream f("radixsort.in");
ofstream g("radixsort.out");

long long v[10000005];
long long a,b,c,n;
long long digit[11];
long long maxx,pw=1;
long long vt[10000005];

void solve() {
    f >> n >> a >> b >> c;
    v[0]= maxx = b;
    for (int i=1;i<n;i++) {
        v[i] = (a*v[i-1]+b)%c;
        maxx = max(maxx,v[i]);
    }
    while (maxx) {
       pw*=10; maxx/=10;
       fill(digit,digit+10,0);
       for (int i=0;i<n;i++) {
            digit[(v[i]%pw)/(pw/10)]++;
       }
       for (int i=1;i<=9;i++) {
            digit[i] += digit[i-1];
       }
       for (int i=9;i>=1;i--) {
            digit[i] = digit[i-1];
       }
       digit[0] = 0;
       for (int i=0;i<n;i++) {
            vt[digit[(v[i]%pw)/(pw/10)]] = v[i];
            digit[(v[i]%pw)/(pw/10)]++;
       }
       for (int i=0;i<n;i++) {
            v[i] = vt[i];
       }
    }
    for (int i=0;i<n;i+=10) {
        g << v[i] << " ";
    }
}


int main()
{
    solve();
    return 0;
}
