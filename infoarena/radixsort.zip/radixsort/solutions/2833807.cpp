#include <bits/stdc++.h>

using namespace std;

ifstream in("radixsort.in");
ofstream out("radixsort.out");

int a[10000005],n,A,B,C;

int main()
{
    in >> n >> A >> B >> C;
    a[1] = B;
    for (int i = 2; i <= n; i++)
        a[i] = (A * a[i - 1] + B) % C;
    long long p10 = 1;
    vector<int>ant[15],act[15];
    for (int i = 1; i <= n; i++)
        ant[1].push_back(a[i]);
    while (ant[0].size() != n)
    {
        for (int j = 0; j <= 9; j++)
            act[j].clear();
        for (int j = 0; j <= 9; j++)
            for (int i = 0; i < ant[j].size(); i++)
                act[(ant[j][i] / p10) % 10].push_back(ant[j][i]);
        p10 *= 10;
        for (int j = 0; j <= 9; j++)
        {
            ant[j].clear();
            for (int i = 0; i < act[j].size(); i++)
                ant[j].push_back(act[j][i]);
        }
    }
    for (int i = 0; i < n; i += 10)
        out << act[0][i] << " ";
    return 0;
}
