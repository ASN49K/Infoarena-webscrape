#include <bits/stdc++.h>

using namespace std;

int main()
{
    int n, a, b, c;
    cin >> n >> a >> b >> c;

    int MAX = 0;
    vector<int> v(n);
    v[0] = b;
    for (int i = 1; i < n; i++) {
        v[i] = (a * v[i - 1] + b) % c;
        MAX = max(MAX, v[i]);
    }
        
    int activ = 0;
    const int B = 10;
    int putereCurenta = 1;
    //int MAX = max(b, c - 1);

    vector<vector<queue<int>>> q(2, vector<queue<int>>(10));

    for (int i = 0; i < n; i++)
        q[0][0].push(v[i]);

    while (putereCurenta <= MAX) {
        for (int i = 0; i < B; i++) {
            while (q[activ][i].size() != 0) {
                int x = q[activ][i].front();
                q[activ][i].pop();

                int cif = x / putereCurenta % B;
                q[1 - activ][cif].push(x);
            }
        }

        activ = 1 - activ;
        putereCurenta *= B;
    }

    int count = 0;
    for (int i = 0; i < B; i++) {
        while (q[activ][i].size() != 0) {
            v[count] = q[activ][i].front();
            count++;
            q[activ][i].pop();
        }
    }

    for (int i = 0; i < n; i += 10)
        cout << v[i] << ' ';

    cout << '\n';
    return 0;
}