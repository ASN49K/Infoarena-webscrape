#include <bits/stdc++.h>
#define MAX 10000000
#define fastio ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
#define FILES freopen("radixsort.in","r",stdin);\
              freopen("radixsort.out","w",stdout);
using namespace std;
int n, v[MAX + 5], cat, p = 1, a, b, c;
vector<int>nr[10];
void radixSort(int p)
{
    int pos = 1;
    for(int i = 0; i <= 9; ++i)
        nr[i].clear();
    for(int i = 1;i <= n; ++i)
        nr[(v[i] / p) % 10].push_back(v[i]);
    for(int i = 0; i <= 9; ++i)
        for(auto j : nr[i]) v[pos++] = j;
}
int main()
{
    fastio
    FILES
    cin >> n >> a >> b >> c;
    v[1] = b;
    for(int i = 2;i <= n; ++i)
        v[i] = (v[i-1] * a + b) % c, cat = max(cat, (int)(log10(v[i])) + 1);
    for(int i = 1; i <= cat; ++i, p *= 10)
        radixSort(p);
    for(int i = 1;i <= n; i += 10)
        cout << v[i] << ' ';
}
