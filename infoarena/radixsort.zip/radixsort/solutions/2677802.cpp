#include <bits/stdc++.h>
using namespace std;
#define x1 "radixsort.in"
#define x2 "radixsort.out"
ifstream in(x1);
ofstream out(x2);
#define MAX_N 10000000
#define MAX_BITS 32
#define BITS_PER_STEP 8
const int BASE = (1 << BITS_PER_STEP);
const int MASK = BASE - 1;
int v1[MAX_N], v2[MAX_N];
int f[BASE], v3[BASE];

void sortr(int v[], int aux[], int n, int bits) {
    if (bits == MAX_BITS)
        return;
    memset(f, 0, sizeof(f));
    int i;
    for (i = 0; i < n; ++i)
        ++f[v[i] >> bits & MASK];
    v3[0] = 0;
    for (i = 1; i < BASE; ++i)
        v3[i] = v3[i - 1] + f[i - 1];
    for (i = 0; i < n; ++i)
        aux[v3[v[i] >> bits & MASK]++] = v[i];
    sortr(aux, v, n, bits + BITS_PER_STEP);
}
int main() {
    int n, a, b, c, i;
    in >> n >> a >> b >> c;
    v1[0] = b;
    for(i = 1; i < n; i++)
        v1[i] = (v1[i - 1] * a + b) % c;
    sortr(v1, v2, n, 0);
    for(i = 0; i < n; i += 10)
        out << v1[i] << " ";
    return 0;
}
