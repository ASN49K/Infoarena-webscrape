#include <fstream>
#include <vector>

using namespace std;

int main()
{
    ifstream fin("radixsort.in");
    ofstream fout("radixsort.out");

    int n, a, b, c;
    fin >> n >> a >> b >> c;

    vector<int> v(n + 1);

    v[1] = b;
    for (int i = 2; i <= n; ++i)
    {
        v[i] = (a * v[i - 1] + b) % c;
    }

    vector<int> count(257, 0);
    for (int j = 1; j <= 4; ++j)
    {
        for (int i = 1; i <= n; ++i)
        {
            count[(v[i] & ((1LL << 8 * j) - 1)) >> (8 * (j - 1))]++;
        }

        for (int i = 1; i < 256; ++i)
        {
            count[i] += count[i - 1];
        }

        vector<int> sorted(n + 1);
        for (int i = n; i >= 1; --i)
        {
            sorted[count[(v[i] & ((1LL << 8 * j) - 1)) >> (8 * (j - 1))]--] = v[i];
        }

        for (int i = 1; i <= n; ++i)
        {
            v[i] = sorted[i];
        }

        count.assign(257, 0);
    }

    for (int i = 1; i <= n; i += 10)
    {
        fout << v[i] << " ";
    }

    fout << "\n";
}