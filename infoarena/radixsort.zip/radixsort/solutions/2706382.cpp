#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

const int MAX_N = 10000000;
const int NO_BUCKETS = (1 << 8);

uint32_t numbers[MAX_N];

uint32_t get_byte(uint32_t number, int byte) {
    uint32_t mask = 0xFF;
    return ((number >> (byte * 8)) & mask);
}

void radixsort(int n, uint32_t * numbers) {
    uint32_t * temp = (uint32_t *) malloc(n * sizeof(uint32_t));
    int * buckets = (int *) malloc(NO_BUCKETS * sizeof(int));

    for (int i = 0; i < sizeof(uint32_t); i++) {
        memset(buckets, 0, sizeof(int) * NO_BUCKETS);

        for (int j = 0; j < n; j++) {
            buckets[get_byte(numbers[j], i)]++;
        }
        for (int j = 1; j < NO_BUCKETS; j++) {
            buckets[j] += buckets[j - 1];
        }
        for (int j = n - 1; j >= 0; j--) {
            temp[buckets[get_byte(numbers[j], i)]-- - 1] = numbers[j];
        }

        memcpy(numbers, temp, n * sizeof(uint32_t));
    }

    free(temp);
    free(buckets);
}

int main() {
    int n, a, b, c;
    FILE * f;

    f = fopen("radixsort.in", "r");
    fscanf(f, "%d%d%d%d", &n, &a, &b, &c);
    fclose(f);

    numbers[0] = b % c;
    for (int i = 1; i < n; i++) {
        numbers[i] = (1LL * a * numbers[i - 1] % c + b) % c;
    }

    radixsort(n, numbers);

    f = fopen("radixsort.out", "w");
    for (int i = 0; i < n; i += 10) {
        fprintf(f, "%d ", numbers[i]);
    }
    fclose(f);

    return 0;
}