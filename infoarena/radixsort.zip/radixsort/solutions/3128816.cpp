#include <iostream>
#include <vector>
#include <fstream>

using namespace std;
ifstream f("radixsort.in");
ofstream g("radixsort.out");

void radixSort(vector<int>& arr) {
    int n = arr.size();
    int maxVal = arr[0];
    for (int i = 1; i < n; i++) {
        if (arr[i] > maxVal) {
            maxVal = arr[i];
        }
    }

    for (int exp = 1; maxVal / exp > 0; exp *= 10) {
        vector<int> count(10, 0);
        vector<int> output(n);

        for (int i = 0; i < n; i++) {
            int digit = (arr[i] / exp) % 10;
            count[digit]++;
        }

        for (int i = 1; i < 10; i++) {
            count[i] += count[i - 1];
        }

        for (int i = n - 1; i >= 0; i--) {
            int digit = (arr[i] / exp) % 10;
            output[count[digit] - 1] = arr[i];
            count[digit]--;
        }

        for (int i = 0; i < n; i++) {
            arr[i] = output[i];
        }
    }
}

void printVector(vector<int>& arr) {
    for (int i = 0; i < arr.size(); i++) {
        g << arr[i] << " ";
    }
    g << endl;
}

int main() {
    int n;
    f >> n;
    vector<int> arr;
    for(int i = 0; i < n; ++i){
        int x;
        f >> x;
        arr.push_back(x);
    }
    radixSort(arr);
    printVector(arr);
    return 0;
}
