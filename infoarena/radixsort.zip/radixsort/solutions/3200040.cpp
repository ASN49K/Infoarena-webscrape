#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream  fin("radixsort.in");
ofstream fout("radixsort.out");
vector<int> vec[1005];
const int MOD=1000;
int v[10000005],n,vmax,p,A,B,C;
int main()
{
    fin>>n>>A>>B>>C;
    v[1]=B;
    for(int i=2;i<=n;i++)
    {
        v[i]=((long long)A*v[i-1]+B)%C;
        vmax=max(vmax,v[i]);
    }
    int c=0;
    while(vmax>0)
    {
        c++;
        vmax=vmax/MOD;
    }
    p=1;
    for(int cc=1;cc<=c;cc++)
    {
        for(int i=1;i<=n;i++)
        {
            vec[v[i]/p%MOD].push_back(v[i]);
        }
        int k=0;
        for(int i=0;i<=MOD-1;i++)
        {
            for(int j=0;j<vec[i].size();j++)
            {
                k++;
                v[k]=vec[i][j];
            }
            vec[i].clear();
        }
        p=p*MOD;
    }
    for(int i=1;i<=n;i=i+10)
    {
        fout<<v[i]<<" ";
    }
    fin.close();
    fout.close();
    return 0;
}
