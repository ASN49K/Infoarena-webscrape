#include <bits/stdc++.h>
#define ui unsigned int

using namespace std;

ifstream f("radixsort.in");
ofstream g("radixsort.out");

vector<ui> radix(vector<ui> a)
{
    //i know, many magic numbers
    vector<ui> buckets[256];
    ui comp=255;
    for(int mod=0; mod<=32; mod+=8)
    {
        for(int i=0; i<a.size(); i++)
        {
            cout<<(a[i]>>mod)<<'\n';
            buckets[(a[i]>>mod)&comp].push_back(a[i]);
        }
        ui k=0;
        for(int i=0; i<=comp; i++)
        {
            while(!buckets[i].empty())
            {
                a[k]=buckets[i].back();
                k++;
                buckets[i].pop_back();
            }
        }
    }
    return a;
}

int main()
{
    ui n,a,b,c,nr;
    vector<ui> v;
    f>>n>>a>>b>>c;
    nr=b;
    for(int i=0; i<n; i++)
    {
        nr=(a*nr+b)%c;
        v.push_back(nr);
    }
    v=radix(v);
    //for(int i=0; i<n; i++)
    //{
        //g<<v[i]<<' ';
    //}
    //g<<'\n';
    for(int i=0; i<n; i++)
    {
        if(i%10==0)g<<v[i]<<' ';
    }
    return 0;
}
