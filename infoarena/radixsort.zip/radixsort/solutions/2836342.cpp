/*#include <bits/stdc++.h>

using namespace std;

ifstream in("radixsort.in");
ofstream out("radixsort.out");

long long n,A,B,C;
vector<int>ant[256],act[256];

int main()
{
    in >> n >> A >> B >> C;
    ant[1].push_back(B);
    for (int i = 1; i < n; i++)
    {
        long long nr = (A * ant[1][i - 1] + B) % C;
        ant[1].push_back(nr);
        cout << nr << ' ';
    }
    int p256 = 0;
    for (int q = 0; q <= 4; q++)
    {
        for (int i = 0; i < 256; i++)
            while (ant[i].size())
            {
                act[(ant[i].front() >> p256) & 255].push_back(ant[i].front());
                ant[i].pop_back();
            }
        for (int i = 0; i < 256; i++)
        {
            for (int j = act[i].size() - 1; j >= 0; j--)
                ant[i].push_back(act[i][j]);
            act[i].clear();
        }
        p256 += 8;
    }
    int u = 0;
    for (int i = 0; i < n; i += 10)
        out << ant[0][i] << " ";
    return 0;
}
*/
#include <bits/stdc++.h>

using namespace std;

ifstream in("radixsort.in");
ofstream out("radixsort.out");

long long n,A,B,C;
vector<int>ant[256],act[256];

int main()
{
    in >> n >> A >> B >> C;
    ant[1].push_back(B);
    for (int i = 1; i < n; i++)
    {
        long long nr = (A * ant[1][i - 1] + B) % C;
        ant[1].push_back(nr);
    }
    int p256 = 0;
    for (int q = 0; q <= 3; q++)
    {
        for (int i = 0; i < 256; i++)
            for (int j = 0; j < ant[i].size(); j++)
                act[(ant[i][j] >> p256) & 255].push_back(ant[i][j]);
        for (int i = 0; i < 256; i++)
            ant[i].clear(),ant[i].shrink_to_fit();
        for (int i = 0; i < 256; i++)
        {
            reverse(act[i].begin(),act[i].end());
            while (act[i].size())
            {
                ant[i].push_back(act[i][act[i].size() - 1]);
                act[i].pop_back();
            }
            act[i].shrink_to_fit();
        }
        p256 += 8;
    }
    int u = 0;
    for (int i = 0; i < 256; i++)
    {
        for (int j = 0; j < ant[i].size(); j++)
        {
            u++;
            if (u == 10)
                u = 0;
            if (u == 1)
                out << ant[i][j] << " ";
        }
    }
    return 0;
}
