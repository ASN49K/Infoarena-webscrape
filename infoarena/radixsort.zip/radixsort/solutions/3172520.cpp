
#include <fstream>
#include <iostream>
#include <cstring>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

#define MAX_N 10000000 + 1
#define RADIX 0xFF
#define RADIX_SIZE 8
#define TOTAL_BYTES sizeof(numere[0])

int n;
int numere[MAX_N];

#define get_byte(x) ((x>>(byte * 8))&RADIX)

void countsort(int A[], int B[], int byte) {
    int counter[1<<RADIX_SIZE];
    int index[1<<RADIX_SIZE];

    memset(counter, 0, sizeof(counter));

    for(int i = 0; i < n; i ++)
        ++counter[get_byte(A[i])];

    index[0] = 0;

    for(int i = 1; i < 1<<RADIX_SIZE; i ++)
        index[i] = index[i-1] + counter[i-1];

    for(int i = 0; i < n; i ++)
        B[index[get_byte(A[i])]++] = A[i];
}
void radixsort() {
    int *temp = new int[n]; // avem nevoie de un array ca spatiu temporar
    for (int i = 0; i < TOTAL_BYTES; i ++) {
        if(i % 2 == 0)
            countsort(numere, temp, i);// sortez dupa byte-ul i
        else
            countsort(temp, numere, i);
    }
}
void read()
{
    int a,b,c;
    fin>>n>>a>>b>>c;

    numere[0] = b % c;
    for(int i = 1; i < n; i ++)
        numere[i] = (1LL * a * numere[i-1] % c + b) % c;
}
void write(ofstream& f)
{
    for(int i = 0; i < n; i +=10)
        f << numere[i]<< ' ';
    f<<endl;
}

int main()
{
    read();

    radixsort();
//    sort(numere, numere + n);

    write(fout);

    return 0;
}
