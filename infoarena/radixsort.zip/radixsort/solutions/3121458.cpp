#include <bits/stdc++.h>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

int n,a,b,c,v[10000005],i,p,putere,val,j,j2;
vector <int> fr[10];

int main()
{
fin>>n>>a>>b>>c;
v[1] = b;
for(i=2;i<=n;i++){
    v[i] = (a * v[i-1] + b) % c;
}
putere = 1;
for(p=1;p<=9;p++){
    for(i=1;i<=n;i++){
    val = (v[i] / putere) % 10;
    fr[val].push_back(v[i]);
    }
    n = 0;
    for(j=0;j<=9;j++){
        for(j2=0;j2<fr[j].size();j2++){
            v[++n] = fr[j][j2];
        }
        fr[j].clear();
    }
    putere *= 10;
}
for(i=1;i<=n;i+=10){
    fout << v[i] << " ";
}
 return 0;
}
