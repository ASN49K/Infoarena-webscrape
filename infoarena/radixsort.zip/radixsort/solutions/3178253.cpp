#include <iostream>
#include <fstream>
#define int long long

using namespace std;

int v[10000001];

void Sort(int v[], int l, int r, int b)
{
    if(l >= r || b == -1)
    {
        return;
    }
    int i, j, aux;
    for(i = l, j = l; i <= r; i++)
    {
        if((v[i] & (1 << b)) == 0)
        {
            aux = v[i];
            v[i] = v[j];
            v[j] = aux;
            j++;
        }
    }
    Sort(v, l, j - 1, b - 1);
    Sort(v, j, r, b - 1);
}

signed main()
{
    ifstream cin("radixsort.in");
    ofstream cout("radixsort.out");
    int n, a, b, c, i;
    cin >> n >> a >> b >> c;
    v[1] = b;
    for(i = 2; i <= n; i++)
    {
        v[i] = (a * v[i - 1] + b) % c;
    }
    Sort(v, 1, n, 30);
    for(i = 1; i <= n; i += 10)
    {
        cout << v[i] << " ";
    }
    return 0;
}
