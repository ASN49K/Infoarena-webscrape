#include<bits/stdc++.h>
using namespace std;
ifstream in("heap_sort.in");
ofstream out("heap_sort.out");
int n,val=(1<<16),x,a,b,c,ct;
vector<vector<int>>bucket1(val),bucket2(val);
int main()
{in>>n>>a>>b>>c;
bucket1[b%val].push_back(b);
    for(int i=1;i<n;i++)
{x=(1ll*x*a+b)%c;
bucket1[x%val].push_back(x);
}
for(int i=0;i<val;i++)
for(auto k:bucket1[i])
bucket2[k/val].push_back(k);

for(int i=0;i<val;i++)
for(auto k:bucket2[i])
{ct++;
if(ct%10==1)
    out<<k<<" ";
}
}
