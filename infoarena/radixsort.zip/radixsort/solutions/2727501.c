#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#pragma GCC optimize("Ofast")

int count[256][4], index[256];

void pass(int pass_nr, unsigned int *array, unsigned int *out, int N) {
    int i, sum, j, k;
    unsigned char *c = (unsigned char *)array;

	sum = 0;
	for (i = 0; i < 256; i++) {
		sum += count[i][pass_nr];
		count[i][pass_nr] = sum;
	}
	for (i = 0; i < 256; i++) {
		index[i] = count[i][pass_nr] - 1;
	}
	for (i = 4*N, k = N;;) {
		i -= 4;
		k--;
		j = c[i+pass_nr];
	    out[index[j]--] = array[k];
	    if (i == 0)
	        break;
	}
}

/*static inline int compar(const void *a, const void *b) {
	unsigned int *x = (unsigned int *)a;
	unsigned int *y = (unsigned int *)b;
	
	return (*x > *y) + (*x == *y)*0 + (*x < *y)*(-1);
}*/

unsigned int array_in[10000001];
unsigned int array_out[10000001];
	unsigned int rest[256*65536];
	unsigned char flag[256*65536] = {0};

int main() {
    FILE *in=fopen("radixsort.in","r");
    FILE *out=fopen("radixsort.out","w");
    int N, A, B, C, i, n, treshold;
	unsigned long long int vi;
	unsigned char *c = (unsigned char *)array_in;
	unsigned int aux, aux2;

	fscanf(in,"%d %d %d %d",&N, &A, &B, &C);
	

	for (i = 1; i < C; i++) {
		rest[i] = -1;
	}

	array_in[0] = B;
	for (i = 1; i < N; i++) {
		aux = array_in[i-1];
		aux2 = rest[aux];
		
	    if (aux2 > 0) {
	    	array_in[i] = aux2;
	    	continue;
		}
		vi = A*aux + B;
		vi -= (vi/C)*C;
	    array_in[i] = rest[aux] = vi;
	    //array_in[i] = rest[array_in[i-1]];
	}
	
	for (i = 4*N;;) {
		i -= 4;
	    
	    count[c[i]][0]++;
	    count[c[i+1]][1]++;
	    count[c[i+2]][2]++;
	    count[c[i+3]][3]++;
	    
	    if (i == 0)
	        break;
	}
	
	pass(0, array_in, array_out, N);
	pass(1, array_out, array_in, N);
	pass(2, array_in, array_out, N);
	pass(3, array_out, array_in, N);
	
    //qsort(array_in, N, sizeof(unsigned int), compar);
	
	for (i = 0; i < N; i += 10)
	    fprintf (out, "%d ", array_in[i]);
    fprintf(out, "\n");
    
    /*for (i = 0; i < C; i++)
        if (flag[i])
            fprintf(out, "rest[%d] = %d\n", i, rest[i]);*/


	fclose(in);
	fclose(out);
	
	return 0;
}

