#include <bits/stdc++.h>
#define uint unsigned int

using namespace std;

void radix_sort (vector<uint> &v) {
  stack<uint> stk[4];
  for (int i = 0; i <= 15; i++) {
    for (int j = 0; j < (int)v.size(); j++)
      stk[(v[j] >> (i << 1)) & 3].push(v[j]);

    fill(v.begin(), v.end(), 0);
    int tmp_size = 0;
    for (int j = 0; j < 4; j++) {
      int z = tmp_size + (int)stk[j].size() - 1;
      tmp_size += (int)stk[j].size();
      while (!stk[j].empty()) {
        v[z--] = stk[j].top();
        stk[j].pop();
      }
    }
  }
}

int main () {
  ifstream fin ("radixsort.in");
  ofstream fout ("radixsort.out");
  int n; fin >> n;
  long long a, b, c; fin >> a >> b >> c;
  vector<uint> v(1, (uint)b);
  for (int i = 1; i < n; i++) v.push_back((uint)((a * v.back() + b) % c));
  radix_sort(v);
  for (int i = 0; i < n; i += 10) fout << v[i] << ' ';
  fout << '\n';
  return 0;
}
