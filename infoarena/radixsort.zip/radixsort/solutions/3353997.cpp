#include <bits/stdc++.h>


#define int long long
using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
int n,a,b,c,cif=0;
int max0;
queue<int>bucket[11];
int v[10000001];
void radixsort() {
    for(int exp = 1;max0/exp > 0 ;exp*=10) {
        for(int i = 1; i <=n; i++){
            bucket[(v[i]/exp)%10].push(v[i]);
        }
        int ind = 0;
        for(int i = 0 ; i<=9;i++){
            while(!bucket[i].empty()){
                v[++ind] = bucket[i].front();
                bucket[i].pop();
            }
        }
        bool sorted = true;
        for(int i = 2; i <=n; i++)
        if(v[i] < v[i-1]){
            sorted = false;
            break;
        }
        if(sorted ==true)
            break;
    }
    for(int i = 1; i <=n; i+=10)
        fout<<v[i]<<" ";
}

int32_t main() {
    fin>>n>>a>>b>>c;
    v[1] = b;
     max0 = b;
    for(int i = 2;  i<=n; i++){
        v[i] = (a*v[i-1] + b) %c;
        max0 =  max(max0,v[i]);
    }

    radixsort();
    return 0;
}
