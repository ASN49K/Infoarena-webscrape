#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream  fin("radixsort.in");
ofstream fout("radixsort.out");
vector<int> vec[999999];
const int MOD=1000000;
int v[10000000],n,vmax,p,A,B,C,c,i,cc,k,j;
int main()
{
    fin>>n>>A>>B>>C;
    v[1]=B;
    for(i=2;i<=n;i++)
    {
        v[i]=((long long)A*v[i-1]+B)%C;
        vmax=max(vmax,v[i]);
    }
    c=0;
    while(vmax>0)
    {
        c++;
        vmax=vmax/MOD;
    }
    p=1;
    for(cc=1;cc<=c;cc++)
    {
        for(i=1;i<=n;i++)
        {
            vec[v[i]/p%MOD].push_back(v[i]);
        }
        k=0;
        for(i=0;i<=MOD-1;i++)
        {
            for(j=0;j<vec[i].size();j++)
            {
                k++;
                v[k]=vec[i][j];
            }
            vec[i].clear();
        }
        p=p*MOD;
    }
    for(i=1;i<=n;i=i+10)
    {
        fout<<v[i]<<" ";
    }
    fin.close();
    fout.close();
    return 0;
}
