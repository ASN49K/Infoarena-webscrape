#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

const int N = 1e7;

unsigned v[N];

void radixSort(unsigned arr[], int sz) {
  for (int k = 0; k < 4; ++k) {
    vector<unsigned> bucket[256];
    for (int i = 0; i < sz; ++i)
      bucket[(arr[i] >> (k * 8)) & ((1 << 8) - 1)].push_back(arr[i]);
    int p = 0;
    for (int i = 0; i < 256; ++i)
      for (auto j: bucket[i])
        arr[p++] = j;
  }
}

int main() {
  ifstream cin("radixsort.in");
  ofstream cout("radixsort.out");
  unsigned n, a, b, c;
  cin >> n >> a >> b >> c;
  cin.close();
  v[0] = b;
  for (int i = 1; i < n; ++i)
    v[i] = (1LL * a * v[i - 1] + b) % c;
  srand(time(nullptr));
  random_shuffle(v, v + n);
  radixSort(v, n);
  for (int i = 0; i < n; i += 10)
    cout << v[i] << " ";
  cout.close();
  return 0;
}
