#include <cstdio>
#include <algorithm>
using namespace std;
int const N = 5e5 , mask = (1 << 16) - 1;
int fq [mask + 1] , index [mask + 1];
int ind [N * 10];
void radixsort (int n , int cnt [] , int m [] , int bits){
    if (bits == 32)
        return;
    fill (fq , fq + mask + 1 , 0);
    fill (index , index + 1 + mask , 0);
    for(int i = 0 ; i < n ; ++ i)
        ++ fq [(m [ind [i]] >> bits) & mask];
    for(int i = 1 ; i <= mask ; ++ i)
        index [i] = index [i - 1] + fq [i - 1];
    for(int i = 0 ; i < n ; ++ i)
        ind [i] = index [(m [ind [i]] >> bits) & mask] ++;
    radixsort (n , cnt , m , bits + 16);
}
int solve(int n, long long k, int cnt[], int m[]){
    radixsort (n , cnt , m , 0);
    long long r = 0;
    int i;
    for(i = 0 ; i < n && r < k; ++ i)
        r = r + cnt [ind [i]];
    return m [i - 1];
}
int main() {
    FILE *fin = fopen("cadouri.in", "r"), *fout = fopen("cadouri.out", "w");
    int n; /// first parameter for solve()
    long long k; /// second parameter for solve()
    int M1, C1; /// 0 <= cnt[i] < M1
    int M2, C2; /// 0 <= cnt[i] < M2
    fscanf(fin, "%d%d%d%d%d%lld", &n, &M1, &C1, &M2, &C2, &k);
    int *cnt = new int[n], *m = new int[n]; /// last parameters for solve()
    long long m1 = M1, m2 = M2;
    unsigned int c1 = C1, c2 = C2;
    for (int i = 0; i < n; i++) {
        c1 = 5 * c1 + 1;
        c2 = 5 * c2 + 3;
        cnt[i] = ((m1 * c1) >> 32) + 1;
        m[i] = ((m2 * c2) >> 32) + 1;
    }
    fprintf(fout, "%d\n", solve(n, k, cnt, m));

    delete[] cnt;
    delete[] m;
    fclose(fin);
    fclose(fout);
    return 0;
}
