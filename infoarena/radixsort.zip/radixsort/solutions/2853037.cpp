#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define dbg(i) (cout<<#i<<" = "<<(i)<<'\n')

using ll = long long;

const string fn = "radixsort";

ifstream fin(fn + ".in");
// ofstream fout(fn + ".out");

int n;
int a[10000001];
deque<int> d[256];

class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};

OutParser fout("radixsort.out");

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie();
    fin.tie();

    int A, B, C;
    fin >> n >> A >> B >> C;
    a[1] = B;
    int i, j, k;
    for (i = 2; i <= n; ++i)
        a[i] = (1LL * A * a[i - 1] + B) % C;

    int mask;
    for (i = 0; i < 4; ++i) {
        mask = 8 * i;
        for (j = 1; j <= n; ++j)
            d[(a[j] >> mask) & 255].pb(a[j]);
        n = 0;
        for (j = 0; j < 256; ++j)
            while (!d[j].empty()) {
                a[++n] = d[j].front();
                d[j].pop_front();
            }
    }

    for (i = 1; i <= n; i += 10)
        fout << a[i] << " ";


    fin.close();
    // fout.close();
    return 0;
}
