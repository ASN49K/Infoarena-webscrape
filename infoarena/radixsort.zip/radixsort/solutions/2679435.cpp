#include <fstream>
#define fisier "radixsort"
std::ifstream in(fisier ".in");
std::ofstream out(fisier ".out");
const int B = 1 << 16, N = 10000000;
int F[B]; unsigned G[N], H[N];
int main()
{
    int n, a, c; in >> n >> a >> *G >> c; F[*G]++;
    for (int i = 1; i < n; i++) F[G[i] = (a * G[i-1] + *G) % c & B-1] ++;
    for (int b = 1; b < B; b++) F[b] += F[b-1];
    for (int i = 0; i < n; i++) H[--F[G[i] & B-1]] = G[i];
    for (int b = 0; b < B; b++) F[b] = 0;
    for (int i = 0; i < n; i++) F[H[i] >> 16] ++;
    for (int i = n; --i >= 0; ) G[--F[H[i] >> 16]] = H[i];
    for (int i = 0; i < n; i++) if (not (i % 10)) out << G[i] << ' ';
}
