#include <fstream>
#include <iostream>
#include <queue>
#include <cstring>

using namespace std;

int n, a, b, c, i, j, v[10000001], w[10000001], nrcif, maxi, p10, p, cif, cc[10], l[10];
long long t;
queue<int> q[10];
ifstream fin("radixsort.in");
//ifstream fin("grader_test7.in");
ofstream fout("radixsort.out");

void repartizare (int a[], int b[]) {
  int d;
  memset (cc, 0, sizeof cc);
  for (i = 1; i <= n; i++) {
    cc[a[i] / p10 % 10]++; // contor pentru fiecare cifra
  }
  l[0] = 1;
  for (cif = 1; cif <= 9; cif++)
    l[cif] = l[cif - 1] + cc[cif - 1];
  for (i = 1; i <= n; i++) {
    d = l[a[i] / p10 % 10]++; // Destinatia urmatoare va fi mai mare cu 1.
    b[d] = a[i];
  }
}

int main() {
  fin >> n >> a >> b >> c;
  v[1] = b;
  for (i = 2; i <= n; i++) {
    v[i] = (1LL * a * v[i - 1] % c + b) % c;
    if (v[i] > maxi)
      maxi = v[i];
  }
  while (maxi > 0) {
    maxi /= 10;
    nrcif++;
  } //nr de cifre maxim din sir
  p10 = 1;
  for (p = 1; p <= nrcif; p++) {
    if (p % 2 == 1)
      repartizare(v, w);
    else
      repartizare(w, v);
    p10 *= 10; //inaintam cu pozitia cifrei pe care o vrem
  }
  if (nrcif % 2 == 1)
    for (i = 1; i <= n; i += 10)
      fout << w[i] << ' '; // se cere sa afisam elemente din 10 in 10
  else
    for (i = 1; i <= n; i += 10)
      fout << v[i] << ' '; // se cere sa afisam elemente din 10 in 10
  return 0;
}

/*
v[i] / p10
12345 / 100 = 123 % 10
12345 / 1000 = 12 % 10

  849 770 67 347 201 618 66 495 13 45

     0   1   2   3   4   5   6   7   8   9
   770 201      13     495  66  67 618 849
                        45     347

  770 201 13 495 45 66 67 347 618 849

     0   1   2   3   4   5   6   7   8   9
   201  13           45     66 770     495
       618          347     67
                    849

  201 13 618 45 347 849 66 67 770 495

     0   1   2   3   4   5   6   7   8   9
    13     201 347 495     618 770 849
    45
    66
    67

queue<int> q[10];
*/

