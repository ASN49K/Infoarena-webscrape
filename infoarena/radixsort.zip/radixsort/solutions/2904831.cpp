#include <iostream>
#include <fstream>

using namespace std;
ifstream in("radixsort.in");
ofstream out("radixsort.out");

const int Nmax = 1e7 + 5;
int v[Nmax], a, b, c, n, poscif[256];

void radixSort(int v[], const int n) {
    int aux[n + 1];
    for (int j = 0; j < 32; j += 8) {
        for (int i = 0; i < 256; ++i)
            poscif[i] = 0;

        for (int i = 1; i <= n; ++i)
            ++poscif[(v[i] >> j) & 255];

        for (int i = 0; i < 256; ++i)
            poscif[i] += poscif[i - 1];

        for (int i = n; i >= 1; --i) {
            int cif = (v[i] >> j) & 255;
            aux[poscif[cif]] = v[i];
            --poscif[cif];
        }

        for (int i = 1; i <= n; ++i)
            v[i] = aux[i];
    }
}

int main() {
    in >> n >> a >> b >> c;
    v[1] = b;
    for(int i = 2; i <= n; ++ i)
        v[i] = (1LL * a * v[i - 1] + b) % c;


    radixSort(v, n);

    for(int i = 1; i <= n; i += 10)
        out << v[i] << ' ';

    return 0;
}