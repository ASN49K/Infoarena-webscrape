#include <fstream>
#define NMAX 10000005

using namespace std;

/**********************************/
/// INPUT / OUTPUT

ifstream f("radixsort.in");
ofstream g("radixsort.out");
/**********************************/
/// GLOBAL DECLARATIONS

int N, A, B, C;
int arr[NMAX];
int temp[NMAX];
int bucket[269];
/**********************************/
/// FUNCTIONS

void ReadInput();
void Solution();
void Output();
/**********************************/
///-------------------------------------------
inline void ReadInput()
{
    f >> N >> A >> B >> C;
    arr[1] = B;
}
///-------------------------------------------
inline void RadixSort()
{
    for (int k = 0 ; k < 32 ; k += 8)
    {
        for (int i = 0 ; i < 256 ; ++ i)
            bucket[i] = 0;
        
        for (int i = 1 ; i <= N ; ++ i)
            bucket[(arr[i] >> k) & 255] ++;
        
        for (int i = 1 ; i < 256 ; ++ i)
            bucket[i] += bucket[i - 1];

        for (int i = N ; i >= 1 ; -- i)
        {
            temp[bucket[(arr[i] >> k) & 255]] = arr[i];
            bucket[(arr[i] >> k) & 255] --;
        }

        for (int i = 1 ; i <= N ; ++ i)
            arr[i] = temp[i];
    }
}
///-------------------------------------------
inline void Solution()
{
    for (int i = 2 ; i <= N ; ++ i)
        arr[i] = (A * arr[i - 1] + B) % C;
    
    RadixSort();
}
///-------------------------------------------
inline void Output()
{
    for (int i = 1 ; i <= N ; i += 10)
        g << arr[i] << " ";
}
///-------------------------------------------
int main()
{
    ReadInput();
    Solution();
    Output();
}