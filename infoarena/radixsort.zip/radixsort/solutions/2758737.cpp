#include <bits/stdc++.h>

using namespace std;
ifstream in("radixsort.in");
ofstream out("radixsort.out");
vector<int> v(10000000);
vector<queue<int>> bucket(256);
int main(){
    long long n,a,b,c;
    in>>n>>a>>b>>c;
    v[0]=b;
    for(int i=1;i<n;i++){
        v[i]=(a*v[i-1]+b)%c;
    }

    for(int p=0;p<32;p+=8){
        for(int i=0;i<n;i++){
            bucket[(v[i]>>p)&255].push(v[i]);
        }
        for(int i=0,j=0;i<256;i++){
            while(!bucket[i].empty()){
                v[j++]=bucket[i].front();
                bucket[i].pop();
            }
        }
    }
    for(int i=0;i<n;i+=10){
        out<<v[i]<<" ";
    }
}
