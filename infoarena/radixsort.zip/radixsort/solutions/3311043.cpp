#include <fstream>
#include <vector>
#define nmax (int)(1e7+1)
using namespace std;
ifstream cin("radixsort.in");
ofstream cout("radixsort.out");
int n,v[nmax],aux[nmax],bck[10],a,b,c;
int main()
{
    cin>>n>>a>>b>>c;
    v[1]=b;
    for(int i=2;i<=n;i++)
        v[i]=(1LL*a*v[i-1]+b)%c;
    for(int i=1,p=1;i<=10;i++,p*=10){
        for(int j=0;j<10;j++)
            bck[j]=0;
        for(int j=1;j<=n;j++)
            bck[v[j]/p%10]++;
        for(int j=1;j<10;j++)
            bck[j]+=bck[j-1];
        for(int j=n;j>0;j--)
            aux[bck[v[j]/p%10]--]=v[j];
        for(int j=1;j<=n;j++)
            v[j]=aux[j];
    }
    for(int i=1;i<=n;i+=10)
        cout<<v[i]<<" ";
    return 0;
}
