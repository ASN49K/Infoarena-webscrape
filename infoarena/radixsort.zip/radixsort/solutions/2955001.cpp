#include <fstream>
#include <vector>

using namespace std;

const int NMAX = 10000000;
const long long HASH = 2; ///Putem sorta dupa cifre si in alte baze. Aici folosim baza 10.

int n;
int v[1 + NMAX];

vector<int> small;
vector<int> cifre[HASH];

void sortAux(long long putereHash)
{
    small.clear();
    for (int i = 0; i < HASH; i++)
        cifre[i].clear();

    for (int i = 1; i <= n; i++)
    {
        if (v[i] < putereHash)
            small.emplace_back(v[i]);
        else
        {
            if (putereHash == 0)
                cifre[v[i] % HASH].emplace_back(v[i]);
            else
                cifre[v[i] / putereHash % HASH].emplace_back(v[i]);
        }
    }

    int n = 0;

    for (int i = 0; i < small.size(); i++)
    {
        n++;
        v[n] = small[i];
    }
    for (int i = 0; i < HASH; i++)
    {
        for (int j = 0; j < cifre[i].size(); j++)
        {
            n++;
            v[n] = cifre[i][j];
        }
    }
}

void radixSort()
{
    int maxim = -1;

    for (int i = 1; i <= n; i++)
        maxim = max(maxim, v[i]);

    if (maxim == 0)
        return;

    int nrSortari = 1;
    long long putereHash = 1;

    while (putereHash * HASH <= maxim)
    {
        putereHash *= HASH;
        nrSortari++;
    }

    putereHash = 0;

    for (int i = 1; i <= nrSortari; i++)
    {
        sortAux(putereHash);

        if (putereHash == 0)
            putereHash = HASH;
        else
            putereHash *= HASH;
    }
}

int main()
{
    ios_base::sync_with_stdio(false);

    ifstream in("radixsort.in");
    ofstream out("radixsort.out");

    long long a, b, c;
    in >> n >> a >> b >> c;

    v[1] = b;

    for (int i = 2; i <= n; i++)
        v[i] = (a * v[i - 1] + b) % c;

    radixSort();

    for (int i = 1; i <= n; i += 10)
        out << v[i] << ' ';
    out << '\n';

    in.close();
    out.close();

    return 0;
}
