#include <fstream>
#define fisier "radixsort"
std::ifstream in(fisier ".in");
std::ofstream out(fisier ".out");
const int B = 1 << 16, N = 10000777;
int F[B]; unsigned G[N], H[N];
#define RI   for (int i = n; --i >= 0; )
#define I(s) for (int i = s; i < n; i++)
#define IB   for (int b = 1; b < B; b++)
int main()
{
    unsigned n, a, c; in >> n >> a >> *G >> c; F[*G]++;
    I(1) F[(G[i] = (1ULL * a * G[i-1] + *G) % c) & B-1] ++;
    IB   F[b] += F[b-1];
    RI   H[--F[G[i] & B-1]] = G[i];
    IB   F[b] = 0;
    I(0) F[H[i] >> 16] ++;
    IB   F[b] += F[b-1];
    RI   G[--F[H[i] >> 16]] = H[i];
    I(0) if (not (i % 10)) out << G[i] << ' ';
}
