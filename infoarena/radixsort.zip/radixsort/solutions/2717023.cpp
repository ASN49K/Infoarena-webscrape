#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>
using namespace std;


void count_sort(int v[],int n,int byte,int ki[])
{
    int count[256];
    int index[256];
    memset(count,0,sizeof(count));

    for(int i=0;i<n;i++)
    {
        count[((v[i])>>(byte*8))&0xff]++;
    }
    index[0]=0;

    for (int i = 1; i < 256; i++)
        index[i]=index[i-1]+count[i-1];

    for(int i=0;i<n;i++){
         ki[index[((v[i])>>(byte*8))&0xff]++]=v[i];
    }

}

void radix_sort(int v[],int n)
{

    int m=n;
    int byte=0;
    int *temp=new int[n];
    for(int i=0;i<4;i++)
    {
        if(i%2==0)
            count_sort(v,n,i,temp);
        else count_sort(temp,n,i,v);
    }

}

int main()
{
    ifstream be("radixsort.in");
    ofstream ki("radixsort.out");
    int n,a,b,c;
    be>>n>>a>>b>>c;
    int v[n];
    v[0]=b;
    for(int i=1;i<n;i++){
        v[i]=(1LL*a*v[i-1]%c+b)%c;
    }
    radix_sort(v,n);
    /*for(int i=0;i<n;i+=10)
        ki<<v[i]<<" ";*/
    return 0;
}
