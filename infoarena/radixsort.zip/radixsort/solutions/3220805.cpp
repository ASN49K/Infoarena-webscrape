#include <iostream>
#include <fstream>
#include <stdint.h>

const int32_t WORD_SIZE_LOG_2 = 8;
const int32_t WORD_SIZE = 1 << WORD_SIZE_LOG_2;
const int32_t WORD_COUNT = 4;
const int32_t MAX_N = 10000000;

int32_t vec[MAX_N];
int32_t vec2[MAX_N];
int main() {
    std::ifstream fin("radixsort.in");
    std::ofstream fout("radixsort.out");

    int32_t n, a, b, c;
    fin >> n >> a >> b >> c;

    vec[0] = b;
    for(int32_t i = 1; i != n; ++i)
        vec[i] = ((int64_t)a * vec[i - 1] + b) % c;
    
    for(int32_t i = 0; i != WORD_COUNT; ++i) {
        int32_t starts[WORD_SIZE];
        for(int32_t j = 0; j != WORD_SIZE; ++j)
            starts[j] = 0;
        
        for(int32_t j = 0; j != n; ++j) {
            int32_t word = (vec[j] >> (WORD_SIZE * i)) & (WORD_SIZE - 1);

            if(word != WORD_SIZE - 1)
                ++starts[word + 1];
        }
        for(int32_t j = 2; j != WORD_SIZE; ++j)
            starts[j] += starts[j - 1];
        
        for(int32_t j = 0; j != n; ++j) {
            int32_t word = (vec[j] >> (WORD_SIZE * i)) & (WORD_SIZE - 1);

            vec2[starts[word]++] = vec[j];
        }
        for(int32_t j = 0; j != n; ++j)
            vec[j] = vec2[j];
    }

    for(int32_t i = 0; i < n; i += 10)
        fout << vec[i] << ' ';

    fin.close();
    fout.close();
}