#include<bits/stdc++.h>
using namespace std;
ifstream in("radixsort.in");
ofstream out("radixsort.out");
queue<int>q;
vector<queue<int>>bucket(1000,queue<int>());
int a,b,c,n,val, ct=0;
int main()
{in>>n>>a>>b>>c;
val=b;
q.push(val);
for(int i=1;i<n;i++)
{val=int((1ll*a*val+b)%c);
    q.push(val);
}
for(long long putere=1;putere<=1000;putere*=1000)
{while(!q.empty())
{int x=q.front();
q.pop();
bucket[x/putere%1000].push(x);

}
 for(int i=0;i<1000;i++)
 while(!bucket[i].empty())
 {q.push(bucket[i].front());
     bucket[i].pop();
 }
}
while(!q.empty())
{ct++;
if(ct%10==1)
    out<<q.front()<<" ";
q.pop();

}

}
