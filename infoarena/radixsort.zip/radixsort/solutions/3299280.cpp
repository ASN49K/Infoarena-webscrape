#include <fstream>
#include <vector>

using namespace std;

const int LIM_10 = 1e9;
const int B = 10;

int main()
{
    ifstream in("radixsort.in");
    ofstream out("radixsort.out");
    int n, a, b, c;
    in >> n >> a >> b >> c;
    vector <int> v(n);
    v[0] = b;
    for (int i = 1; i < n; i++)
    {
        v[i] = ((long long)a * v[i-1] + b) % c;
    }
    vector < vector <int>> liste(B);
    int  p = 1;
    while (p <= LIM_10 / B)
    {
        for (int cif = 0; cif < B; cif++)
        {
            liste[cif].clear();
        }
        for (int i = 0; i < n; i++)
        {
            int cif = v[i] / p % B;
            liste[cif].push_back(v[i]);
        }
        int nv = 0;
        for (int cif = 0; cif < B; cif++)
        {
            for (auto val: liste[cif])
            {
                v[nv++] = val;
            }
        }
        p *= B;
    }
    int poz = 0;
    while (poz < n)
    {
        out << v[poz] << " ";
        poz += 10;;
    }
    in.close();
    out.close();
    return 0;
}
