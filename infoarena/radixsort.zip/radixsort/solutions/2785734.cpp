#include <fstream>
#include <vector>
#include <cmath>
using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

int n, a, b, c;
int arr[10000013];

void radixSort(int arr[], int n)
{
    vector<vector<int>> buckets(10, vector<int>());
    long long div = 1;
    bool processed = true;
    while (processed)
    {
        processed = false;
        for (int i = 1; i <= n; ++i)
        {
            if (arr[i] >= div)
            {
                int d = arr[i] / div;
                if (d > 0)
                {
                    processed = true;
                }
                buckets[d % 10].push_back(arr[i]);
            }
            else
            {
                buckets[0].push_back(arr[i]);
            }
        }
        int it = 1;
        for (int i = 0; i < 10; ++i)
        {
            for (int nbr : buckets[i])
            {
                arr[it++] = nbr;
            }
            buckets[i].clear();
        }
        div *= 10;
    }
}

int main()
{
    fin >> n >> a >> b >> c;
    arr[1] = b;
    for (int i = 2; i <= n; ++i)
    {
        arr[i] = (1L * a * arr[i - 1] + b) % c;
    }
    radixSort(arr, n);
    int i = 1;
    for (int i = 1; i <= n; i += 10)
    {
        fout << arr[i] << " ";
    }
    return 0;
}
