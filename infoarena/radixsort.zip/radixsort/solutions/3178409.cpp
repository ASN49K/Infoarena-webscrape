#include <bits/stdc++.h>
using namespace std;

int v[10000001];
int aux[10000001];
int fv[10];

#ifndef HOME
    ifstream in("radixsort.in");
    ofstream out("radixsort.out");
    #define cin in
    #define cout out
#endif

int n;

void radixsort(int v[], int aux[], int put)
{
    for(int i = 1; i <= n; i++)
            fv[v[i] / put % 10]++;
    for(int i = 1; i <= 9; i++)
        fv[i] += fv[i - 1];
    for(int i = n; i >= 1; i--)
    {
        aux[fv[v[i] / put % 10]] = v[i];
        fv[v[i] / put % 10]--;
    }
    for(int i = 0; i <= 9; i++)
        fv[i] = 0;
}

int main()
{
#ifdef HOME
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#endif
    int a, b, c;
    cin >> n >> a >> b >> c;
    v[1] = b;
    for(int i = 2; i <= n; i++)
        v[i] = (1LL * a * v[i - 1] + b) % c;
    int cnt = 1;
    for(int put = 1; put <= 1'000'000'000; put *= 10, cnt++)
    {
        if(cnt % 2)
            radixsort(v, aux, put);
        else
            radixsort(aux, v, put);
    }
    for(int i = 1; i <= n; i += 10)
        if(cnt % 2 == 0)
            cout << v[i] << " ";
        else
            cout << aux[i] << " ";
    return 0;
}