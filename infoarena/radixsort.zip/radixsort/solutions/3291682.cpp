#include <bits/stdc++.h>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
int n, i, a, b, c;
vector<int> v[2];
deque<int> bk[34];

int main() {
    fin >> n >> a >> b >> c;

    v[1].push_back(b);

    int ma = b;
    for(i = 2; i <= n; i++) {
	v[1].push_back((1LL * a * v[1].back() % c + b) % c);
    	ma = max(ma, v[1].back());
    }

    int put = 1;
    
    int idx = 1;
    while(put <= ma) {
        int iCur = idx % 2;
        int iUrm = (idx + 1) % 2;

        for(int cur : v[iCur]) {
            bk[cur / put % 32].push_back(cur);
        }

        v[iUrm].clear();
        for(i = 0; i < 32; i++) {
            while(!bk[i].empty()) {
                v[iUrm].push_back(bk[i].front());
                bk[i].pop_front();
            }
        }

        idx++;
        put *= 32;
    }

    idx %= 2;
    for(int i = 0; i < v[idx].size(); i += 10) fout << v[idx][i] << " ";

    return 0;
}
