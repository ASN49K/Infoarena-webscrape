#include <bits/stdc++.h>
using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

/**
doua cozi=>stiva
push(x): q1 q2
8
58 371 6 889 199 64 8 1
*/

vector <int> a;

int main()
{
    int i, j, mx = 0, lg, x, k;
    while (fin >> x)
    {
        a.push_back(x);
        mx = max(mx, x);
    }

    for (lg = 0; mx > 0; lg++, mx /= 10)
        ;

    vector <vector<int> > b(10);
    x = 1;
    for (i = 0; i < lg; i++, x *= 10)
    {
        for (int j : a)
            b[(j / x) % 10].push_back(j);
        k = 0;
        for (j = 0; j <= 9; j++)
        {
            for (int p : b[j])
                a[k++] = p;
            b[j].clear();
        }
    }

    for (int i : a)
        fout << i << " ";
    return 0;
}
