#include <bits/stdc++.h>
#define ll long long
using namespace std;

ifstream fin ("radixsort.in");
ofstream fout ("radixsort.out");
ll v[10000005];
int main()
{
    ll n, a, b, c;
    fin>>n>>a>>b>>c;
    v[1]=b;
    for (int i=2; i<=n; i++) {
        v[i]=(a*v[i-1]+b)%c;
    }
    sort (v+1, v+n+1);
    for (int i=1; i<=n; i+=10) {
        fout<<v[i]<<' ';
    }
    return 0;
}
