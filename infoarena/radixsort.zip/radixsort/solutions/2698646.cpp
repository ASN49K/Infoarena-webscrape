#include <bits/stdc++.h>

using namespace std;

ifstream in ("radixsort.in");
ofstream out ("radixsort.out");

deque < int > q[157];

int n, a, b, c;

long long v[10000001], k;

int main()
{
    in >> n >> a >> b >> c;
    v[1] = b;
    for ( int i = 2 ; i <= n ; ++i )
        v[i] = ( 1ll * a * v[i - 1] + b ) % c;
    for ( int bucket = 0 ; bucket < 4 ; ++bucket )
    {
        for ( int i = 1 ; i <= n ; ++i )
            q[( v[i] >> ( 8 * bucket ) ) & 255].push_back ( v[i] );
        n = 0;
        for ( int i = 0 ; i < 256 ; ++i )
            while ( !q[i].empty () )
            {
                v[++n] = q[i].front();
                q[i].pop_front();
            }
    }
    for ( int i = 1 ; i <= n ; i += 10 )
        out << v[i] << " ";
    return 0;
}
