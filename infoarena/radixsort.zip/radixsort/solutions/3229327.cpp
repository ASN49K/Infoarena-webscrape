#include <bits/stdc++.h>
using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

long long n, a[10000005];
long long A, B, C;
vector<long long> b[15];

int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    long long i, maxi, pas;
    long long j;
    fin >> n >> A >> B >> C;
    maxi = a[1] = B;
    for(i=2; i<=n; i++)
    {
        a[i] = (A * a[i-1] + B) % C;
        maxi = max(maxi, a[i]);
    }
    for(j=1; maxi / j > 0; j *= 10)
    {
        for(i=1; i<=n; i++)
            b[(a[i] / j) % 10].push_back(a[i]);
        n = 0;
        for(i=0; i<=9; i++)
        {
            for(auto w : b[i]) a[++n] = w;
            b[i].clear();
        }
    }
    for(i=1; i<=n; i+=10)
        fout << a[i] << " ";
    return 0;
}
