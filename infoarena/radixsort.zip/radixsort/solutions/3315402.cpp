#include<fstream>
using namespace std;
ifstream cin("radixsort.in");
ofstream cout("radixsort.out");
unsigned u[10000000],v[10000000];
int main()
{
    int a,b,c,n;
    cin>>n>>a>>b>>c,v[0]=b;
    for(int i=1;i<n;v[i]=(1LL*a*v[i-1]+b)%c,++i);
    for(int j=0;j<4;++j) {
        int d[256]={0};
        for(int i=0;i<n;++d[(v[i++]>>(j*8))&255]);
        for(int i=1;i<256;d[i]+=d[i-1],++i);
        for(int i=n-1;i>=0;u[--d[(v[i]>>(j*8))&255]]=v[i],--i);
        for(int i=0;i<n;v[i]=u[i],++i);
    }
    for(int i=0;i<n;cout<<v[i]<<' ',i+=10);
    return 0;
}
