#include <fstream>
using namespace std;

int t[10*1000*1000];
int uj[10*1000*1000];

void stabil_counting_sort(int n, int exp)
{
    int db[10] = {};

    for (int i = 0; i < n; ++i)
        db[ t[i]/exp % 10 ]++;

    int hova[10];

    hova[0] = 0;
    for (int i = 1; i < 10; i++)
        hova[i] = hova[i-1] + db[i-1];

    for (int i = 0; i < n; ++i) {
        int szj = t[i]/exp % 10;
        int pos = hova[szj];
        ++hova[szj];

        uj[pos] = t[i];
    }

    for (int i = 0; i < n; ++i)
        t[i] = uj[i];
}

int main()
{
    ifstream be("radixsort.in");
    ofstream ki("radixsort.out");

    int n;
    long long A, B, C;
    be >> n >> A >> B >> C;

    t[0] = B;
    int maximum = t[0];

    for (int i = 1; i < n; i++) {
        t[i] = (A * t[i-1] + B) % C;
        maximum = max(maximum, t[i]);
    }

    for (int exp = 1; maximum / exp > 0; exp *= 10)
        stabil_counting_sort(n, exp);

    for (int i = 0; i < n; i+=10)
        ki << t[i] << " ";

    ki << endl;
    return 0;
}

