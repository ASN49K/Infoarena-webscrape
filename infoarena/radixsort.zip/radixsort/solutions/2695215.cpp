#include <bits/stdc++.h>

using namespace std;
int n, A, B, C;
deque<int> q[256];
int a[10000005];
int main()
{
    ifstream fin("radixsort.in");
    ofstream fout("radixsort.out");
    int i,j,k, masca;
    fin >> n >> A >> B >> C;
    a[1]=B;
    for (i=2; i<=n; i++)
        a[i]=(1ll*A*a[i-1]+B)%C;
    for (i=0; i<=3; i++)
    {
        masca = 8 * i;
        for (j=1; j<=n; j++)
        {
            k=(a[j] >> masca) & 255;
            q[k].push_back(a[j]);
        }
        n=0;
        for (j=0; j<=255; j++)
            while (!q[j].empty())
            {
                a[++n]=q[j].front();
                q[j].pop_front();
            }
    }
    for (i=1; i<=n; i+=10)
        fout << a[i] << " ";

    return 0;
}
