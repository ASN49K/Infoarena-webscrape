#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

void radixSort(vector<int> &arr, int basePow = 8)
{
    int base = 1 << 8;
    int mask = base - 1;
    vector<int> newarr(arr.size()), cnt(base), start(base);
    int mx = *max_element(arr.begin(), arr.end());
    long long fact = 1;
    int sh = 0;
    while(mx / fact > 0)
    {
        // compute start position
        cnt.assign(base, 0);
        for(int x : arr)
            cnt[(x >> sh) & mask]++;
        start[0] = 0;
        for(int i = 1; i < base; i++)
            start[i] = start[i-1] + cnt[i-1];

        for(int x : arr)
        {
            int coef = (x >> sh) & mask;
            newarr[start[coef]++] = x;
        }

        arr = newarr;

        fact *= base;
        sh += basePow;
    }
}

int main()
{
    long long n, a, b, c;
    fin >> n >> a >> b >> c;

    vector<int> v(n);
    v[0] = b;
    for(int i = 1; i < n; i++)
        v[i] = (a * v[i-1] + b) % c;

    radixSort(v);

    for(int i = 0; i < n; i += 10)
        fout << v[i] << ' ';
    return 0;
}
