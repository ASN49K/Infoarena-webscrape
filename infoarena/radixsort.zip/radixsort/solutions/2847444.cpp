#include <bits/stdc++.h>
using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

const int dim=1e7+9,mod=100000;

int fv[mod+9],poz[mod+9];
int v[2][dim];

signed main(){
    int n;
    long long a,b,c;
        fin>>n>>a>>b>>c;
    v[1][1]=b;
    for(int i=2;i<=n;i++){
        v[1][i]=(a*v[1][i-1]+b)%c;
    }
    int elim=1,cnt=2;
    while(true){
        bool ok=false;
        fill(fv,fv+mod,0);
        for(int i=1;i<=n;i++){
            int nr=v[(cnt-1)%2][i]/elim;
            fv[nr%mod]++;
            v[cnt%2][i]=0;
        }
        poz[0]=1;
        for(int i=1;i<mod;i++){
            poz[i]=poz[i-1]+fv[i-1];
        }
        for(int i=1;i<=n;i++){
            int nr=v[(cnt-1)%2][i]/elim;
            v[cnt%2][poz[nr%mod]]=v[(cnt-1)%2][i];
            poz[nr%mod]++;
            if(nr){
                ok=true;
            }
        }
        if(!ok){
            break;
        }
        cnt++,elim*=mod;
    }
    for(int i=1;i<=n;i+=10){
        fout<<v[cnt%2][i]<<' ';
    }
}
