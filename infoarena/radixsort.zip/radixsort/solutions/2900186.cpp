#include<iostream>
#include<fstream>

using namespace std;

ifstream in("radixsort.in");
ofstream out("radixsort.out");


const int radix_size = 8;
const int mask = (1 << radix_size) - 1;
const int byte_count = 1 << radix_size;

const int num_bytes = sizeof(int);
const int mx = 10000100;


int n, a, b, c;
int v[mx], temp[mx];

int get_byte(int number, int byte) {
    return (number >> ((byte - 1) * 8)) & mask;
}

void counting_sort(int *x, int *y, int byte) {
    int freq[byte_count];
    int index[byte_count];

    for (int i = 0; i < byte_count; i++) {
        freq[i] = 0;
        index[i] = 0;
    }

    for (int i = 0; i < n; i++) {
        freq[get_byte(x[i], byte)]++;
    }

    index[0] = 0;
    for (int i = 1; i < byte_count; i++) {
        index[i] = index[i - 1] + freq[i - 1];
    }

    for (int i = 0; i < n; i++) {
        int where = index[get_byte(x[i], byte)]++;
        y[where] = x[i];
    }
}

int main() {
    in >> n >> a >> b >> c;
    v[0] = b % c;
    for (int i = 1; i < n; i++) {
        v[i] = (a * v[i - 1] + b) % c;
    }
    for (int i = 0; i < num_bytes; i++) {
        if (i % 2 == 0) {
            counting_sort(v, temp, i);
        } else {
            counting_sort(temp, v, i);
        }
    }
    for (int i = 0; i < n; i += 10) {
        out << v[i] << " ";
    }

    return 0;
}