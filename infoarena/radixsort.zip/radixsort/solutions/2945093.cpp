///radixsort-LSD variant
#include <iostream>
#include <fstream>

#define Nmax 10000000
#define MaxBit 32
#define BitsPerStep 8
#define Mask ((1<<BitsPerStep)-1)
using namespace std;
ifstream fin ("radixsort.in");
ofstream fout ("radixsort.out");

long long n,a,b,c;
long long v1[Nmax+5], v2[Nmax+5], ind[Mask+1], fr[Mask+1];

void radixsort(long long v[], long long aux[], long long bit){
    if (bit==MaxBit)
        return;
    for (int i=0;i<=Mask;i++)
        fr[i]=0;
    for (int i=0;i<n;i++)
        fr[(v[i]>>bit)%Mask]++;
    ind[0]=0;
    for (int i=1;i<=Mask;i++)
        ind[i]=ind[i-1]+fr[i-1];
    for (int i=0;i<n;i++)
        aux[ind[(v[i]>>bit)%Mask]++]=v[i];
    radixsort(aux, v, bit+BitsPerStep);
}
int main()
{
    fin>>n>>a>>b>>c;
    v1[0]=b;
    for (int i=1;i<n;i++){
        v1[i]=((long long)a*v1[i-1]+b)%c;
    }
    radixsort(v1, v2, 0);
    for (int i=0;i<n;i+=10)
        fout<<v1[i]<<' ';
    return 0;
}
