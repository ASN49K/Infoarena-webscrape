#include <bits/stdc++.h>
#define ll long long

using namespace std;

void radix_sort (vector<ll> &v) {
  ll p10 = 1;
  stack<ll> stk[10];
  for (int i = 0; i < 10; i++, p10 *= 10) {
    for (int j = 0; j < (int)v.size(); j++)
      stk[v[j] / p10 % 10].push(v[j]);

    fill(v.begin(), v.end(), 0LL);
    int tmp_size = 0;
    for (int j = 0; j < 10; j++) {
      int z = tmp_size + (int)stk[j].size() - 1;
      tmp_size += (int)stk[j].size();
      while (!stk[j].empty()) {
        v[z--] = stk[j].top();
        stk[j].pop();
      }
    }
  }
}

int main () {
  ifstream fin ("radixsort.in");
  ofstream fout ("radixsort.out");
  int n; fin >> n;
  ll a, b, c; fin >> a >> b >> c;
  vector<ll> v(1, b);
  for (int i = 1; i < n; i++) v.push_back((a * v.back() + b) % c);
  radix_sort(v);
  for (int i = 0; i < n; i += 10) fout << v[i] << ' ';
  fout << '\n';
  return 0;
}
