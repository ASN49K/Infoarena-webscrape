#include <bits/stdc++.h>
using namespace std;

struct Coada {
    int info;
    Coada* next;
};

void push(Coada* &head, Coada* &last, int x) {
    Coada* p = new Coada();
    p -> info = x;
    p -> next = nullptr;
    if(head == nullptr) {
        head = last = p;
    } else {
        last -> next = p;
        last = p;
    }
}
void pop(Coada* &head, Coada* &last) {
    if(head == last) {
        delete head;
        head = last = nullptr;
    } else {
        Coada* t = head;
        head = head -> next;
        delete t;
    }
}

int front(Coada* head) {
    return head -> info;
}
bool empty(Coada* head) {
    return head == nullptr;
}

int nrc(int x) {
    int res = 0;
    while(x > 0) {
        res++;
        x /= 10;
    }
    return res;
}

const int NMAX = 1e7;
int v[NMAX + 1];

int main() {
    ifstream cin("radixsort.in");
    ofstream cout("radixsort.out");
    Coada* head[10] = {nullptr};
    Coada* last[10] = {nullptr};
    int n, a, b, c;
    cin >> n >> a >> b >> c;
    int pasi = 0;
    v[1] = b;
    pasi = max(pasi, nrc(v[1]));
    for(int i = 2; i <= n; i++) {
        //cin >> v[i];
        v[i] = (1LL * a * v[i - 1] + b) % c;
        pasi = max(pasi, nrc(v[i]));
    }
    int p = 1;
    for(int i = 1; i <= pasi; i++) {
        for(int j = 1; j <= n; j++) {
            int c = (v[j] / p) % 10;
            push(head[c], last[c], v[j]);
        }
        int nr = 0;
        for(int j = 0; j <= 9; j++) {
            while(!empty(head[j])) {
                nr++;
                v[nr] = front(head[j]);
                pop(head[j], last[j]);
            }
        }
        p = p * 10;
    }
    for(int i = 1; i <= n; i += 10) {
        cout << v[i] << ' ';
    }

}