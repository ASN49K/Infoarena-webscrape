#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define mp make_pair
#define dbg(x) cout << #x <<": " << x << "\n";
using ll = long long;

const string myf = "radixsort";
ifstream fin(myf + ".in");
ofstream fout(myf + ".out");

const  int mod = 1999999973;

int n, A, B, C;
int a[10000005];
deque<int> d[260];
int main() {

	fin >> n >> A >> B >> C;
	a[1] = B;
	for (int i = 2; i <= n; ++i)
		a[i] = (A * a[i - 1] + B) % C;

	for (int i = 0; i < 4; ++i) {
		for (int j = 1; j <= n; ++j)
			d[(a[j] >> (i * 8) ) & 255].pb(a[j]);
		int p = 0;
		for (int i = 0; i < 255; ++i)
			while (!d[i].empty()) {
				a[++p] = d[i].front();
				d[i].pop_front();
			}
	}
	for (int i = 1; i <= n; i += 10)
		fout << a[i] << " ";

	fin.close();
	fout.close();
	return 0;
}