//sorteaza dupa fiecare cifra a ficarui numar
// complexitate O(kn), k=nr max de cifre al unui nr
#include <fstream>
#include <vector>

using namespace std;
ifstream f("radixsort.in");
ofstream g("radixsort.out");

vector <int> backet[257];
int v[10000001];

int main()
{
    int n,a,b,c,i,j,t;

    f>>n>>a>>b>>c;
    //generam numerele (nu ni-se dau)
    v[0]=b;
    for(i=1;i<n;i++)
        v[i]=(1LL*a*v[i-1]+b)%c;

    int pow=0;
    for(i=1;i<=4;i++)//impartim numerele in cate 4 bucati de cate 8 biti
    {
        for(j=n-1;j>=0;j--)
        {
            int poz=(v[j]>>pow)&255;
            backet[poz].push_back(v[j]);
        }

        j=0;
        for(t=0;t<=255;t++)//acum nr sunt sortate pentru primii i biti(de la coada)
            while(!backet[t].empty())
        {
            v[j++]=backet[t].back();
            backet[t].pop_back();
        }
        pow+=8;
    }
    for(i=0;i<n;i+=10)
        g<<v[i]<<' ';

//Obs: Se poate face si cu 10 backeturi pentru fiecare cifra in loc de 4 bytes.
    return 0;
}
