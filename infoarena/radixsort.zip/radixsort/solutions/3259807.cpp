#include <bits/stdc++.h>

using namespace std;

ifstream in ("radixsort.in");
ofstream out ("radixsort.out");

int v[10000001];

int main()
{
    int n,a,b,c;
    in >> n >> a >> b >> c;
    v[1]=b;
    for (int i=2; i<=n; i++) {
        v[i]=(a*v[i-1]+b)%c;
    }
    sort (v+1, v+n+1);
    for (int i=1; i<=n; i+=10) {
        out << v[i]<<' ';
    }
    return 0;
}
