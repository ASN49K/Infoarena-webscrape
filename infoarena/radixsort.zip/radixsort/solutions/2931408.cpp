#pragma GCC optimize("O1")

#pragma GCC optimize("O2")

#pragma GCC optimize("O3")

#pragma GCC optimize("O4")

#pragma GCC optimize("Ofast")

#include <bits/stdc++.h>

using namespace std;

ifstream in("radixsort.in");
ofstream out("radixsort.out");

long long n,A,B,C;
vector<int>a,b[4];

int main()
{
    in >> n >> A >> B >> C;
    a.resize(n);
    a[0] = B;
    for (int i = 1; i < n; i++)
        a[i] = 1ll * (A * a[i - 1] + B) % C;
    int p256 = -2;
    for (int q = 0; q < 16; q++)
    {
        p256 += 2;
        for (int i = 0; i < n; i++)
            b[(a[i] >> p256) & 3].push_back(a[i]);
        a.resize(0);
        for (int i = 0; i < 4; i++)
        {
            for (int j = 0; j < b[i].size(); j++)
                a.push_back(b[i][j]);
            b[i].resize(0);
        }
    }
    for (int i = 0; i < n; i += 10)
        out << a[i] << ' ';
    return 0;
}