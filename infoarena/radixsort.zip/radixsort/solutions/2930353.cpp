#include <bits/stdc++.h>

using namespace std;
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
int v[10000005];
void sorta(long long a,long long b,long long put)
{
    if(a<b&&put>0)
    {
        vector <int> f[10];
        for(long long i=a; i<=b; i++)
        {
            long long cif=v[i]/put%10;
            f[cif].push_back(v[i]);
        }
        long long cnt=a;
        for(long long i=0; i<=9; i++)
        {
            for(auto it:f[i])
            {
                v[cnt]=it;
                cnt++;
            }
        }
        long long ant=a;
        for(long long i=0; i<=9; i++)
        {
            sorta(ant,ant+f[i].size()-1,put/10);
            ant=ant+f[i].size();
        }
    }
}
int main()
{
    long long n,a,b,c;
    fin>>n>>a>>b>>c;
    v[1]=b;
    for(long long i=2; i<=n; i++)
        v[i]=(v[i-1]*a+b)%c;
    long long put=1e10;
    sorta(1,n,put);
    for(long long i=1; i<=n; i+=10)
        fout<<v[i]<<" ";
    return 0;
}
