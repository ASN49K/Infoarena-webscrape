#include <bits/stdc++.h>
#define nmax 10000005
#define bmax (0xffff)+5
using namespace std;

ifstream f("radixsort.in");
ofstream g("radixsort.out");

int v[nmax],n;
int a,b,c;

int buc[nmax];
int s[bmax];

int cifr(const int &n, int k)
{
    return(n&(0xffff)<<(k*16))>>(k*16);
}

int main()
{
    f>>n>>a>>b>>c;

    v[0]=b;
    for(int i=1;i<n;i++)
    {
        long long inm=v[i-1];
        inm*=a;
        inm%=c;
        v[i]=((int)(inm)+b)%c;
    }
    for(int k=0;k<2;k++)
    {
        memset(s,0,sizeof(s));
        for(int i=0;i<n;i++)
        {
            int c= cifr(v[i],k);
            s[c]++;
        }
        for(int i=1;i<bmax;i++)s[i]+=s[i-1];
        for(int i=bmax-1;i>=1;i--) s[i]=s[i-1];
        s[0]=0;
        for(int i=0;i<n;i++)
        {
            int c= cifr(v[i],k);
            buc[s[c]++]=v[i];
        }
        memcpy(v,buc,sizeof(v));
    }
    for(int i=0;i<n;i+=10)
    {
        g<<v[i]<<' ';
    }
    return 0;
}
