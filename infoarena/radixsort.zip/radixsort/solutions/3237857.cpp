#include <bits/stdc++.h>

using namespace std;
using ll = long long;

ifstream fin( "radixsort.in" );
ofstream fout( "radixsort.out" );

const int BITS = 16;
const int MASK = 65535;
const int MAXN = 10000000;

int v[MAXN], f[MAXN], aux[MAXN], n;

void countSort( int step ) { 
  int u;
  for ( int i = 0; i <= MASK; ++i ) f[i] = 0;
  for ( int i = 0; i < n; ++i ) {
	u = ((v[i] >> (BITS * step)) & MASK);
    ++f[u];
  }
  for ( int i = 1; i <= MASK; ++i ) {
    f[i] += f[i - 1];
  }
  for ( int i = n - 1; i >= 0; --i ) {
	u = ((v[i] >> (BITS * step)) & MASK);
    aux[--f[u]] = v[i];	
  }
  for ( int i = 0; i < n; ++i ) {
	v[i] = aux[i];	
	aux[i] = 0;
  }
} 

int main() {
  int a, b, c;
  
  fin >> n >> a >> b >> c;
  v[0] = b;
  for ( int i = 1; i < n; ++i ) {
    v[i] = ((ll)a * v[i - 1] + b) % c;
  }
  countSort(0);
  countSort(1);
  for ( int i = 0; i < n; i += 10 ) {
    fout << v[i] << " ";	
  }
  fin.close();
  fout.close();
  return 0;
}
