#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

void radixSort(vector<int> &v, int basePow = 8)
{
    int base = 1 << 8;
    int mask = base - 1;
    vector<vector<int>> currq(base), lastq(base);
    int maxElement = 0;

    for(int x : v)
    {
        lastq[x & mask].push_back(x);
        if(x > maxElement)
            maxElement = x;
    }

    long long fact = base;
    int sh = basePow;
    while(maxElement / fact > 0)
    {
        for(auto &q : currq)
            q.clear();

        for(auto &q : lastq)
            for(int x : q)
                currq[(x >> sh) & mask].push_back(x);

        swap(currq, lastq);
        fact *= base;
        sh += basePow;
    }

    v.clear();
    for(auto &q : lastq)
        for(int x : q)
            v.push_back(x);
}

int main()
{
    long long n, a, b, c;
    fin >> n >> a >> b >> c;

    vector<int> v(n);
    v[0] = b;
    for(int i = 1; i < n; i++)
        v[i] = (a * v[i-1] + b) % c;

    radixSort(v);

    for(int i = 0; i < n; i += 10)
        fout << v[i] << ' ';
    return 0;
}
