#include <bits/stdc++.h>
#define ui int

using namespace std;

ifstream f("radixsort.in");
ofstream g("radixsort.out");

vector<ui> radix(vector<ui> a)
{
    queue<ui> buckets[256];
    ui comp=255;
    for(int mod=0; mod<32; mod+=8)
    {
        for(int i=0; i<a.size(); i++)
        {
            buckets[(a[i]>>mod)&comp].push(a[i]);
        }
        int k=0;
        for(int i=0; i<=comp; i++)
        {
            while(!buckets[i].empty())
            {
                a[k++]=buckets[i].front();
                buckets[i].pop();
            }
        }
    }
    return a;
}

int main()
{
    int n,a,b,c,nr;
    vector<ui> v;
    f>>n>>a>>b>>c;
    nr=b;
    v.push_back(nr);
    for(int i=1; i<n; i++)
    {
        nr=(((a*nr)%c)+b)%c;
        v.push_back(nr);
    }
    v=radix(v);
    for(int i=0; i<n; i+=10)
    {
        g<<v[i]<<' ';
    }
    return 0;
}
