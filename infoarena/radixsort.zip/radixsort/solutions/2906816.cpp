#include <bits/stdc++.h>
#include <cstdio>
#include <cstring>

using namespace std;

class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }


public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (long long vu64) {
        if (vu64 <= 9) {
            write_ch(vu64 + '0');
        } else {
            (*this) << (vu64 / 10);
            write_ch(vu64 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};


ifstream f("radixsort.in");
OutParser g("radixsort.out");

unsigned long long int n, a, b, c, level;

int main()
{
    f >> n >> a >> b >> c;
    int v[n + 5], w[n + 5];
    v[1] = b;
    for(int i = 2; i <= n; i++)
        v[i] = 1LL * (1LL  * v[i-1] * a + b) % c;

    int freq[260], poz[260];
    for(int i = 0, mask = 255; i < 32; i += 8, mask <<= 8)
    {
        for(int k = 0; k<=256; k++)
        {
            freq[k] = 0;
            poz[k] = 0;
        }
        for (int j = 1; j <= n; j ++)
        {
            int c = (v[j] & mask) >> i;
            freq[c] ++;
        }
        for(int j = 1; j < 256; j ++) freq[j] += freq[j-1];

        for(int j = 1; j <= n; j ++)
        {
            int c =(v[j] & mask) >> i;
            int newpoz = ++poz[c];
            if(c) newpoz += freq[c - 1];
            w[newpoz] = v[j];
        }
        for(int j = 1; j <= n; j ++)
        {
            v[j] = w[j];
        }

    }

    for(int i = 1; i <= n; i += 10)
        g << v[i] << " ";
    return 0;
}
