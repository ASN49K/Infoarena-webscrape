#include <bits/stdc++.h>
#define ll long long
 
using namespace std;
 
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
 
int v[10000005];
int n,a,b,c,maxim;
queue<int> bucket[257];
int nr[256];
 
void radix_sort()
{
	int put=0;
	while( (1<<put)<=maxim)
	{
		//impartire in bucketuri
		
		for(int i=1; i<=n; i++)
		{
			bucket[(v[i]>>put)&255].push(v[i]);
		}
		int index=0;
		for(int i=0; i<255; i++)
		{
		    while(!bucket[i].empty())
		    {
		        v[++index]=bucket[i].front();
		        bucket[i].pop();
		    }
		}
		put+=8;
	}
}
 
int main() 
{
	fin>>n>>a>>b>>c;
	v[1]=b;
	maxim=b;
	for(int i=2; i<=n; i++)
	{
		v[i]=(a*v[i-1]+b)%c;
		maxim=max(maxim,v[i]);
	}
	radix_sort();
	//sort(v+1,v+n+1);
	for(int i=1; i<=n; i+=10)
	{
		fout<<v[i]<<" ";
	}
}