#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
using namespace std;
long long n, a, b, c, cur, l = 0, l2 = 0;
#define MAX_N 10000001
long long v[MAX_N];
long long v2[MAX_N];
//vector <long long> v;
//vector <long long> v2;
ifstream f ("radixsort.in");
ofstream g ("radixsort.out");
int main()
{
    ios_base::sync_with_stdio(false);
    f.tie(NULL);g.tie(NULL);

    f >> n >> a >> b >> c;
    v[l] = b;
    ++l;
    cur = b;
    for( int i = 2; i <= n; ++i )
    {
        cur = (a * cur + b) % c;
        v[l] = cur;
        ++l;
        //if( (i - 1) % 10 == 0 )
        //{
        //    ++l;
        //}
    }
    sort( v, v + n );
    int st = 0;
    while( st < l )
    {
        //g << v[st] << " ";
        if( st % 10 == 0 )
            v2[l2] = v[st], ++l2;
        ++st;
    }
    st = 0;
    while( st < l2 )
    {
        g << v2[st] << " ";
        ++st;
    }
    return 0;
}
