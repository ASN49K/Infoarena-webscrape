#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

const int N = 1e7, BASE = 256;
int v[N + 1], f[N + 1], poz[N + 1], w[N + 1];

int main(){
	int n, a, b, c, maxi = -1;
	fin >> n >> a >> b >> c;

	v[1] = b;
	for(int i = 2; i <= n; i++)
		v[i] = (1ll * a * v[i - 1] + b) % c,
		maxi = max(maxi, v[i]);

	for(int p = BASE; p <= maxi * BASE; p *= BASE){
		for(int cif = 0; cif <= BASE; cif++)
			f[cif] = poz[cif] = 0;


		for(int i = 1; i <= n; i++)
			f[(v[i] % p) / (p / BASE)]++;
		for(int cif = 0; cif <= BASE; cif++)
			f[cif] += f[cif - 1];

		for(int i = 1; i <= n; i++){
			int cif = (v[i] % p) / (p / BASE);

			poz[cif]++;

			if(cif == 0)
				w[poz[cif]] = v[i];
			else
				w[f[cif - 1] + poz[cif]] = v[i];
		}

		for(int i = 1; i <= n; i++)
			v[i] = w[i];
	}

	for(int i = 1; i <= n; i += 10)
		fout << v[i] << ' ';

	return 0;
}