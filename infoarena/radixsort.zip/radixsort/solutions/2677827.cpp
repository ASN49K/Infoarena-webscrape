// Mihai Priboi

#include <bits/stdc++.h>

#define MAXN 10000000
#define MAX_BITS 32
#define BITS_PER_STEP 8
const int BASE = ( 1 << BITS_PER_STEP );
const int MASK = BASE - 1;

int x[MAXN], y[MAXN];
int freq[BASE], ind[BASE];

void sort( int v[], int aux[], int n, int bits ) {
  if( bits == MAX_BITS )
    return;

  memset(freq, 0, sizeof( freq ));

  int i;
  for( i = 0; i < n; i++ )
    freq[v[i] >> bits & MASK]++;

  ind[0] = 0;
  for( i = 1; i < BASE; i++ )
    ind[i] = ind[i - 1] + freq[i - 1];

  for( i = 0; i < n; i++ )
    aux[ind[v[i] >> bits & MASK]++] = v[i];

  sort(aux, v, n, bits + BITS_PER_STEP);
}

int main() {
  FILE *fin, *fout;
  int n, a, b, c, i;
  fin = fopen( "radixsort.in", "r" );
  fscanf( fin, "%d%d%d%d", &n, &a, &b, &c );
  fclose( fin );
  x[0] = b % c;
  for( i = 1; i < n; i++ )
    x[i] = (1LL * a * x[i - 1] % c + b) % c;

  sort(x, y, n, 0);
  fout = fopen( "radixsort.out", "w" );
  for( i = 0; i < n; i++ )
    if( i % 10 == 0 )
      fprintf( fout, "%d ", x[i] );
  fclose( fout );
  return 0;
}
