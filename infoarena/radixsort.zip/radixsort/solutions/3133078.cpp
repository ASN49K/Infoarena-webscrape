#include <iostream>
#include <fstream>
#include <algorithm>
#define MAXN 10000000
#define BSIZE 1<<15
using namespace std;
char buffer[BSIZE];
long bpos = 0L, bsize = 0L;
long readLong()
{
    long d = 0L, x = 0L;
    char c;
    while (1) {
        if (bpos >= bsize) {
            bpos = 0;
            if (feof(stdin)) return x;
            bsize = fread(buffer, 1, BSIZE, stdin);
        }
        c = buffer[bpos++];
        if (c >= '0' && c <= '9') { x = x * 10 + (c - '0'); d = 1; }
        else if (d == 1) return x;
    }
    return -1;
}
long v[MAXN + 2], w[MAXN + 2];
int main()
{
    long N, A, B, C, i, j, k, nrmax = 0, nrbiti = 0, pas = 1;
    N = readLong(); A = readLong(); B = readLong(); C = readLong();
    v[1] = B;
    for (i = 2; i <= N; i++)
        v[i] = (A * v[i - 1] + B) % C;
    for (i = 1; i <= N; i++)
        nrmax = max(nrmax, v[i]);
    while (nrmax)
    {
        nrbiti++;
        nrmax >>= 1;
    }
    for (k = 1; k <= nrbiti; k++)
    {
        long frecv[2] = { 0 };
        for (i = 1; i <= N; i++)
            frecv[(v[i] & pas) != 0]++;
        frecv[1] += frecv[0];
        for (i = N; i >= 1; i--)
            w[frecv[(v[i] & pas) != 0]--] = v[i];
        for (i = 1; i <= N; i++)
            v[i] = w[i];
        pas <<= 1;
    }
    ofstream fout("radixsort.out");
    for (i = 1; i <= N; i += 10)
        fout << v[i] << " ";
    fout << "\n";
    fout.close();
}