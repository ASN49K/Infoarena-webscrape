#include <fstream>
#include <algorithm>
using namespace std;

ifstream cin("radixsort.in");
ofstream cout("radixsort.out");

int a[1000001];

void citire(int a[] , int &n)
{
    for(int i = 0 ; i < n ; i++)
        cin >> a[i];
}

void afisarecresc(int a[] , int n)
{
    for(int i = 0 ; i < n ; i++)
        cout << a[i] << " ";
}
int main()
{
    int n , d;
    cin >> n;
    citire(a , n);
    sort(a , a + n);
    afisarecresc(a , n);
}
