#include <bits/stdc++.h>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

int n, numbers[10000001], byte;

void citire(int & n, int numbers[])
{
    int a, b, c;
    fin >> n >> a >> b >> c;
    numbers[0] = b % c;
    for(int i = 1; i < n; i++)
        numbers[i] = (1LL * a * numbers[i-1] % c + b) % c;
}

int get_byte(int x, int byte)
{
    return (x>>(byte * 8)) & 0xFF;
}

void countsort(int A[], int B[], int byte)
{
    int counter[256];
    int index[256];

    for(int i = 0; i < 256; i++)
        counter[i] = 0;

    for(int i = 0; i < n; i ++)
        counter[get_byte(A[i], byte)]++;

    index[0] = 0;

    for(int i = 1; i < 256; i ++)
        index[i] = index[i-1] + counter[i-1];

    for(int i = 0; i < n; i ++)
        B[index[get_byte(A[i], byte)]++] = A[i];
}

void radixsort() {
    int *temp = new int[n]; // avem nevoie de un array ca spatiu temporar
    for (int i = 0; i < sizeof(numbers[0]); i ++)
        if(i % 2 == 0)
            countsort(numbers, temp, i);// sortez dupa byte-ul i
        else
            countsort(temp, numbers, i);
}

void afisare(int n, int numbers[])
{
    for(int i = 0; i < n; i += 10)
        fout << numbers[i]<< ' ';
    fout << '\n';
}

int main()
{
    citire(n, numbers);
    radixsort();
    afisare(n, numbers);
    return 0;
}
