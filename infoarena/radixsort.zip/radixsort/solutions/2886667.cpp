#include <bits/stdc++.h>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
const int NMAX=10000005;
const int total_bytes=4;

///impartim numerele in 4 bucket-uri de cate un byte si le sortam incepand cu cea mai putin semnificativa parte
int N, v[NMAX], a, b, c, aux[NMAX];

void countSort(int byte){
    int cnt[1<<8]={}, index[1<<8]={};

    for(int i=1;i<=N;i++)
        cnt[(v[i]>>(byte*8))&((1<<8)-1)]++;

    index[0]=0;
    for(int i=1;i<(1<<8);i++)
        index[i]=index[i-1]+cnt[i-1];

    for(int i=1;i<=N;i++)
        aux[++index[(v[i]>>(byte*8))&((1<<8)-1)]]=v[i];

    for(int i=1;i<=N;i++)
        v[i]=aux[i];
}

void radixSort(){
    for(int i=0;i<4;i++){
        countSort(i);///sortam dupa byte-ul i
    }
}

int main()
{
    fin>>N;
    fin>>a>>b>>c;
    v[1]=b;
    for(int i=2;i<=N;i++)
        v[i]=(1LL*a*v[i-1]%c+b)%c;

    radixSort();

    for(int i=1;i<=N;i+=10)
        fout<<v[i]<<' ';

    fin.close();
    fout.close();
    return 0;
}
