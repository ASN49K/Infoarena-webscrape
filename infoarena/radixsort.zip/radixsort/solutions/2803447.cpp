#include <iostream>
#include <fstream>

using namespace std;

const int NMAX = 1e7;
const int BASE = 4096;
const int VALMAX = ( ( 1 << 30 ) - 1 ) * 2 + 1;

int n;
int v[NMAX];
int frecv[BASE];
int aux[NMAX];

void reorder( int xit ) {
    int i;
    for ( i = 0; i < n; i ++ )
        frecv[v[i] / xit % BASE] ++;
    for ( i = 0; i < BASE; i ++ )
        frecv[i] += frecv[i - 1];
    for ( i = n - 1; i >= 0; i -- )
        aux[--frecv[v[i] / xit % BASE]] = v[i];
    for ( i = 0; i < n; i ++ )
        v[i] = aux[i];
}
void radix() {
    int xit;
    for ( xit = 1; xit <= VALMAX / BASE; xit *= BASE ) {
        reorder( xit );
    }
}
int main() {
    int a, b, c, i, x;
    cin >> n >> a >> b >> c;
    v[0] = b;
    x = b;
    for ( i = 1; i < n; i ++ ) {
        x = ( (long long)a * x + b ) % c;
        v[i] = x;
    }

    radix();

    for ( i = 0; i < n; i += 10 )
        cout << v[i] << ' ';
    return 0;
}
