#include <bits/stdc++.h>

using namespace std;

ifstream in ("radixsort.in");
ofstream out ("radixsort.out");

/**
N * nr_cifre
00005 - 1
00913 - 2
49038 - 3
00053 - 4
59321 - 5
24089 - 6
00124 - 7
52389 - 8

(1, 2, 3, 4, 6, 7, 8); (5)
(1, 2,4, 7, 8); (3, 6); (5)
**/

const int NMAX = 1e7;
const int BITS = 8;
const int MASK = (1 << BITS) - 1;
const int LGMAX = 32;

int idx[MASK + 1];
int f[MASK + 1];
vector<int>a, aux;

int main()
{
    int n, A, B, C;
    in >> n >> A >> B >> C;

    a.resize(n+1, 0);
    aux.resize(n+1, 0);

    a[0] = B;

    for (int i=1; i<=n; i++)
        a[i] = (long long) (A * a[i-1] + B) % C;

    for (int bt=0; bt<LGMAX; bt += BITS)
    {
        memset(f, 0, sizeof(f));
        for (int i=0; i<n; i++)
            f[(a[i] >> bt) & MASK]++;
        idx[0] = 0;
        for (int i=1; i<=MASK; i++)
            idx[i] = idx[i-1] + f[i-1];
        for (int i=0; i<n; i++)
            aux[idx[(a[i] >> bt) & MASK]++] = a[i];
        a.swap(aux);
    }


    for (int i=0; i<n; i+=10)
        out << a[i] << ' ';

    return 0;
}
