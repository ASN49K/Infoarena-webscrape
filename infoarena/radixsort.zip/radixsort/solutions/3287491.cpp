#include <fstream>
#include <vector>
using namespace std;
class InParser {
private:
    FILE *fin;
    char *buff;
    int sp;

    char read_ch() {
        ++sp;
        if (sp == 4096) {
            sp = 0;
            fread(buff, 1, 4096, fin);
        }
        return buff[sp];
    }

public:
    InParser(const char* nume) {
        fin = fopen(nume, "r");
        buff = new char[4096]();
        sp = 4095;
    }

    InParser& operator >> (int &n) {
        char c;
        while (!isdigit(c = read_ch()) && c != '-');
        int sgn = 1;
        if (c == '-') {
            n = 0;
            sgn = -1;
        } else {
            n = c - '0';
        }
        while (isdigit(c = read_ch())) {
            n = 10 * n + c - '0';
        }
        n *= sgn;
        return *this;
    }
};

class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 50000) {
            fwrite(buff, 1, 50000, fout);
            sp = 0;
            buff[sp++] = ch;
        } else {
            buff[sp++] = ch;
        }
    }

public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[50000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }

    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }

    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};
InParser cin("radixsort.in");
OutParser cout("radixsort.out");
const int nmax = 1e7 + 1;
vector <int> d[10];
int v[nmax];
signed main()
{
    int n , idx = 0 , a , b , c;
    cin >> n >> a >> b >> c;
    for(int i = 1 ; i <= n ; ++i)
        if(i == 1) v[i] = b;
        else v[i] = (1LL*a*v[i-1]+b)%c;
    int pw;
    for(int lv = 1 ; lv <= 9 ; ++lv){
        if(lv == 1) pw = 1;
        else pw *= 10;
        for(int i = 1 ; i <= n ; ++i)
            d[(v[i]/pw)%10].emplace_back(v[i]);
        idx = 0;
        for(int i = 0 ; i <= 10 ; ++i){
            for(auto it : d[i])
                v[++idx] = it;
            d[i].clear();
        }
    }
    for(int i = 1 ; i <= n ; i += 10) cout << v[i] << ' ';
    return 0;
}
