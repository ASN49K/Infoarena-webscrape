#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e7;

int v[NMAX];

int main() {
    ifstream fin( "radixsort.in" );
    ofstream fout( "radixsort.out" );
    int n, a, b, c;
    fin >> n >> a >> b >> c;
    v[0] = b;
    for ( int i = 1; i < n; i ++ ) {
        v[i] = ((long long)a * v[i - 1] + b) % c;
    }
    sort( v, v + n );
    for ( int i = 0; i < n; i ++ ) {
        fout << v[i] << ' ';
    }
    return 0;
}