#include <bits/stdc++.h>
using namespace std;

ifstream f("radixsort.in");
ofstream g("radixsort.out");
// #define f cin
// #define g cout
const int nmax = 10000009;
int v[nmax], w[nmax], n, a, b, c;
int getbyte(int x, int c)
{
    int mask = (1 << 8) - 1;
    return 1 + (x & (mask << (c * 8)));
}
void manevra(int c)
{
    static int cnt[2 + (1 << 8)], pref[2 + (1 << 9)];
    memset(cnt, 0, sizeof cnt);
    memset(pref, 0, sizeof pref);
    for (int i = 1; i <= n; i++)
        cnt[getbyte(v[i], c)]++;

    for (int i = 1; i <= (1 << 8); i++)
        pref[i] = pref[i - 1] + cnt[i];

    for (int i = 1; i <= n; i++)
        w[pref[getbyte(v[i], c)] - cnt[getbyte(v[i], c)] + 1] = v[i], cnt[getbyte(v[i], c)]--;
    swap(v, w);
}
int32_t main()
{

    f >> n >> a >> b >> c;
    v[1] = b;
    for (int i = 2; i <= n; i++)
        v[i] = (1ll * a * v[i - 1] + b) % c;

    for (int i = 0; i < 4; i++)
        manevra(i);
    for (int i = 1; i <= n; i += 10)
        g << v[i] << " ";
    return 0;
}
