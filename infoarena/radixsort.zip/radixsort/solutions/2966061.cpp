#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f ("radixsort.in");
ofstream g ("radixsort.out");


int  n , v[10000005];

queue < int > a[12];

int main() {

    int a1 , b , c;
    f >> n >> a1 >> b >> c;
    v[1] = b;
    int maxi = 0;
    for (int i = 2 ; i <= n ; i++)
        v[i] = (1LL * a1 * v[i - 1] + b) % c , maxi = max (maxi , v[i]);
        c = 0;
        while (maxi)
            c++ , maxi /= 10;
        long long divider = 1;
        for (int j = 1 ; j <= c ; j++)
        {
            for (int i = 1 ; i <= n ; i++)
            {
                int u = (v[i] / divider) % 10;
                a[u].push (v[i]);
            }
            int k = 0;
            for (int i = 0 ; i <= 9 ; i++)
            {
                while (!a[i].empty ())
                {
                    k++;
                    v[k] = a[i].front ();
                    a[i].pop();
                }

            }
                divider = divider * 10;
        }

        int k = 1;
        while (k <= n)
        {
            g << v[k] <<" ";
            k = k + 10;
        }

    return 0;
}
