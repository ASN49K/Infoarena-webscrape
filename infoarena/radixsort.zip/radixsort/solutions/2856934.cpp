#include <fstream>
#include <vector>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

typedef long long int64;

const int nmax=10000000, xmax10=10, base=10;

int v[nmax+1];

vector <int> u[base];

int main(){
    int n,a,b,c;
    fin>>n>>a>>b>>c;
    v[1]=b;
    for(int i=2;i<=n;i++){
        v[i]=(int64(a)*v[i-1]+b)%c;
    }
    int p=1;
    for(int i=0;i<xmax10;i++){
        p*=base;
        int p2=p/base;
        for(int j=1;j<=n;j++){
            int cif=v[j]%p/p2;
            u[cif].push_back(v[j]);
        }
        int pas=0;
        for(int k=0;k<base;k++){
            for(int h=0;h<int(u[k].size());h++){
                pas++;
                v[pas]=u[k][h];
            }
        }
        for(int k=0;k<base;k++){
            u[k].resize(0);
        }
    }
    for(int i=1;i<=n;i+=10){
        fout<<v[i]<<" ";
    }
    return 0;
}
