#include <bits/stdc++.h>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");

int n,a,b,c;
int v[10000005],k;
deque <int> d[256];

int main()
{
    fin>>n>>a>>b>>c;
    v[1]=b;
    for(int i=2; i<=n; i++)
        v[i]=(1LL*a*v[i-1]%c+b)%c;
    int p2=255;
    for(int i=0; i<4; i++)
    {
        for(int j=1; j<=n; j++)
            d[(v[j]&p2)>>(8*i)].push_back(v[j]);
        k=0;
        for(int j=0; j<256; j++)
        {
            while(!d[j].empty())
            {
                v[++k]=d[j].front();
                d[j].pop_front();
            }
        }
    }
    for(int j=1; j<=n; j+=10)
        fout<<v[j]<<" ";
    fout<<"\n";
    return 0;
}
