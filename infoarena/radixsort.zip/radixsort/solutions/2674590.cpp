#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin ("radixsort.in");
ofstream fout ("radixsort.out");

int v[10000001], v_nou[10000001], d[10000001];
int n;
int countDigits(int x)
{
    int nr=0;
    while(x!=0) nr++, x/=n;
    return nr;
}
int getMaxValue(int v[])
{
    int mx=v[1];
    for(int i=2; i<=n; i++)
    {
        if(v[i]>mx) mx=v[i];
    }
    return mx;
}
void radixSort(int v[])
{
    int steps=countDigits(getMaxValue(v));
    int power=1;
    int i, k, bucket;
    for(k=1; k<=steps; k++)
    {
        for(i=1; i<=n; i++)
        {
            bucket=(v[i]/power%n);
            d[bucket]++;
        }
        for(i=1; i<n; i++) d[i]=d[i]+d[i-1];

        for(i=n; i>=1; i--)
        {
            bucket=(v[i]/power%n);
            v_nou[d[bucket]]=v[i];
            d[bucket]--;
        }
        for(i=1; i<=n; i++)v[i]=v_nou[i];
        for(i=0; i<n; i++) d[i]=0;

        power=power*n;
    }
}
int main()
{
    /*fin>>n; for(int i=1; i<=n; i++) fin>>v[i];
    radixSort(v);
    for(int i=1; i<=n; i++) cout<<v[i]<<' ';*/
    int a, b, c;
    fin>>n>>a>>b>>c;
    v[1]=b%c;
    for(int i=2; i<=n; i++)
    {
        v[i]=(1LL*a*v[i-1]%c+b)%c;
    }
    //sort(v+1, v+n+1);
    radixSort(v);
    for(int i=1; i<=n; i+=10) fout<<v[i]<<' ';

}
