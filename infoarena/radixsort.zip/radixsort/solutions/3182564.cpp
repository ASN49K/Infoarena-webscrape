#include <iostream>
#include <fstream>
#include <queue>
#include <algorithm>
#include <vector>

using namespace std;

ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
int n, a, b, c;
vector<int> v;

int main(){
    fin >> n >> a >> b >> c;
    v.push_back(b);
    for (size_t i = 1; i < n; i++)
    {
        v.push_back((1LL * a * v[i-1] + b) % c);
    }
    sort(v.begin(), v.end());
    for (size_t i = 0; i < n; i+=10)
    {
        fout << v[i] << ' ';
    }
    return 0;
}