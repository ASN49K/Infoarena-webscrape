#include<iostream>
#include<fstream>
using namespace std;
ifstream f("radixsort.in");
ofstream g("radixsort.out");

int N, A, B, C;

void countSort(int* arr, int n, int exp)
{
	int* output = new int[n + 1];
	int count[10] = { 0,0,0,0,0,0,0,0,0,0 };
	for (int i = 1; i <= n; i++)
		count[arr[i] / exp % 10]++;
	for (int i = 1; i <= 9; i++)
		count[i] += count[i - 1];
	for (int i = n; i >= 1; i--)
	{
		output[count[arr[i] / exp % 10]] = arr[i];
		count[arr[i] / exp % 10]--;
	}
	for (int i = 1; i <= n; i++)
		arr[i] = output[i];
	delete[] output;

}
void radix_sort(int* arr, int n)
{
	int maxi = arr[1];
	for (int i = 2; i <= n; i++)
		if (arr[i] > maxi)
			maxi = arr[i];
	for (int exp = 1; maxi / exp > 0; exp *= 10)
		countSort(arr, n, exp);

}
int main()
{
	f >> N >> A >> B >> C;
	int* arr = new int[N + 1];
	arr[1] = B%C;
	for (int i = 2; i <= N; i++)
		arr[i] = (A * arr[i - 1] + B) % C;
	radix_sort(arr, N);
	for (int i = 1; i <= N; i+=10)
		g << arr[i] << " ";
	g << endl;
	delete[] arr;
	
} 