#include <bits/stdc++.h>
#define P 255
using namespace std;

deque<int> q[256];
int n, A, B, C;
int v[10000001], k;

int main()
{
    int i, x, j;
    /// citire
    ifstream fin("radixsort.in");
    fin >> n >> A >> B >> C;
    fin.close();
    /// generare
    x = B;
    v[1] = B;
    for (i = 2; i <= n; ++i)
        v[i] = (1LL * A * v[i - 1] + B) % C;
    /// radix sort
    for (x = 0; x < 4; ++x)
    {
        for (i = 1; i <= n; ++i)
        {
            j = (v[i] >> (8 * x)) & 255;
            q[j].push_back(v[i]);
        }
        n = 0;
        for (i = 0; i < 256; i++)
            while (!q[i].empty())
            {
                v[++n] = q[i].front();
                q[i].pop_front();
            }
    }
    ofstream fout("radixsort.out");
    for (i = 1; i <= n; i += 10)
        fout << v[i] << " ";
    fout << "\n";
    fout.close();
    return 0;
}
