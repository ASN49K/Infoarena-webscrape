//https://www.infoarena.ro/problema/radixsort
#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
int const MAX = 10000001;
int arr[MAX];
vector <int> buckets[100005];
vector <int> sorted;

void radix(int arr[], int n) {
    int x = 100000;
    for (int i = 1; i <= n; ++i) {
        buckets[arr[i] % x].push_back(arr[i]);
    }
    for (int j = 0; j < x; ++j) {
        for (int k = 0; k < buckets[j].size(); ++k) {
            sorted.push_back(buckets[j][k]);
            
        }
        buckets[j].clear();
    }

    for (int i = 0; i < n; ++i) {
        buckets[sorted[i] / x].push_back(sorted[i]);
    }
    for (int j = 0; j < x; ++j) {
        for (int k = 0; k < buckets[j].size(); ++k) {
            sorted.push_back(buckets[j][k]);
        }
        buckets[j].clear();
    }         
}

int main()
{
    ifstream fin("radixsort.in");
    ofstream fout("radixsort.out");

    int N, A, B, C;
    fin >> N >> A >> B >> C;
    arr[1] = B;
    sorted.reserve(N);

    for (int i = 2; i <= N; ++i) {
        arr[i] = (A * arr[i-1] + B) % C;
    }

    radix(arr, N);
    for (int i = 0; i < N; i += 10) {
        fout << sorted[i] << " ";
    }
}