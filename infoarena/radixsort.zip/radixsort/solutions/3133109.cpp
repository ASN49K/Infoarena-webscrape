#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

// Funcție pentru a aplica Counting Sort pe baza unei cifre specifice (byte)
void countingSort(vector<int>& numbers, int byteIndex) {
    const int k = 256; // Numărul de valori posibile pentru un byte (0-255)

    vector<int> count(k, 0);
    vector<int> sortedNumbers(numbers.size());

    // Numărăm frecvența apariției fiecărei valori a byte-ului
    for (int number : numbers) {
        int currentByte = (number >> (byteIndex * 8)) & 255;
        count[currentByte]++;
    }

    // Calculăm poziția fiecărui număr în vectorul sortat
    for (int i = 1; i < k; i++) {
        count[i] += count[i - 1];
    }

    // Rearanjăm numerele în vectorul sortat
    for (int i = numbers.size() - 1; i >= 0; i--) {
        int number = numbers[i];
        int currentByte = (number >> (byteIndex * 8)) & 255;
        int& position = count[currentByte];
        sortedNumbers[position - 1] = number;
        position--;
    }

    // Actualizăm vectorul de numere cu vectorul sortat
    numbers = sortedNumbers;
}

// Funcție pentru a aplica Radix Sort pe vectorul de numere
void radixSort(vector<int>& numbers) {
    int maxNumber = *max_element(numbers.begin(), numbers.end());

    // Determinăm numărul de pași necesari pentru a sorta toți cei 4 bytes ai numerelor
    int numSteps = sizeof(maxNumber) / sizeof(unsigned char);

    // Aplicăm Counting Sort pe fiecare byte în ordine inversă (de la cel mai puțin semnificativ byte la cel mai semnificativ byte)
    for (int byteIndex = 0; byteIndex < numSteps; byteIndex++) {
        countingSort(numbers, byteIndex);
    }
}

int main() {
    ifstream fin("radixsort.in");
    ofstream fout("radixsort.out");

    int N, A, B, C;
    fin >> N >> A >> B >> C;

    vector<int> numbers(N);
    numbers[0] = B;

    for (int i = 1; i < N; i++) {
        numbers[i] = (A * numbers[i - 1] + B) % C;
    }

    radixSort(numbers);

    for (int i = 0; i < N; i += 10) {
        fout << numbers[i] << " ";
    }
    fout << endl;

    fin.close();
    fout.close();

    return 0;
}
