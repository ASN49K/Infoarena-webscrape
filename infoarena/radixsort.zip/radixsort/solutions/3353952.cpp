#include<fstream>
#include<iostream>
#include<queue>
using namespace std;
ifstream f("radixsort.in");
ofstream g("radixsort.out");
const int NMAX = 10000001;
int v[NMAX + 1],A,b,C;
queue<int> B[11];
//Node* B[11], *B_last[11];
int main(){
    int n;
    long nr_max=0;
    f>>n>>A>>b>>C;
    nr_max=v[0] = b;
    for(int i=1;i<n;i++) {

v[i] = (A * v[i-1] + b) % C;
        nr_max = max(nr_max, v[i]);
    }

    cout<<endl;
    //for (int c = 0; c <= 9; c++)
      //  B[c]= B_last[c] = NULL;
    int nr_cifre_max = 0;
    while(nr_max > 0) {
        nr_cifre_max++;
        nr_max /= 10;
    }
    int p = 1;
    //impartim in bucketuri pe rand vectorul dupa cifrele de la ultima la prima
    for(int i = 1; i <= nr_cifre_max; i++) {
        //determinam cifra c corespunzatoare puterii p
        //punem v[i] in bucketul c
        for (int j = 0; j < n; j++) {
            int c = (v[j] / p) % 10;
            B[c].push(v[j]);
        }
        //lipim bucketurile inapoi in v (!!buketurile raman goale)
        int j = 0;
        for (int c = 0; c <= 9; c++)
            while (!B[c].empty()) {
                v[j] = B[c].front();
                B[c].pop();

                j++;
            }

        //trecem la urmatoarea cifra (De la dreapta la stanga)
        p = p * 10;

    }
    for(int it = 0; it < n; it+=10)
            g << v[it ] << ' ';
    g.close();
    return 0;
}
