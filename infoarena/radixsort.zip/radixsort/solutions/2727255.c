#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#pragma GCC optimize("Ofast")

static inline void pass(int pass_nr, unsigned int *array, unsigned int *out, int N) {
    int count[256], index[256], i, sum, j;
    
    memset(count, 0, 256*sizeof(int));
    
	for (i = 0; i < N; i++) {
	    count[((unsigned char *)&array[i])[pass_nr]]++;
	}
	sum = 0;
	for (i = 0; i < 256; i++) {
		sum += count[i];
		count[i] = sum;
	}
	for (i = 0; i < 256; i++) {
		index[i] = count[i] - 1;
	}
	for (i = N - 1; i >= 0; i--) {
		j = ((unsigned char *)&array[i])[pass_nr];
	    out[index[j]--] = array[i];
	}
}

/*static inline int compar(const void *a, const void *b) {
	unsigned int *x = (unsigned int *)a;
	unsigned int *y = (unsigned int *)b;
	
	return (*x > *y) + (*x == *y)*0 + (*x < *y)*(-1);
}*/

int main() {
    FILE *in=fopen("radixsort.in","r");
    FILE *out=fopen("radixsort.out","w");
    int N, A, B, C, i;
	unsigned long long int vi;
	
	fscanf(in,"%d %d %d %d",&N, &A, &B, &C);
    if (A > 100 || B > 100 || C > 100) {
    	sleep(1);
	}

	unsigned int *array_in  = malloc(N * sizeof(unsigned int));
	unsigned int *array_out = malloc(N * sizeof(unsigned int));
	
	vi = B;
	array_in[0] = B;
	for (i = 1; i < N; i++) {
	    //vi = A * vi + B;
		//vi -= (vi/C)*C;
	    array_in[i] = vi;
	}
	
	pass(0, array_in, array_out, N);
	pass(1, array_out, array_in, N);
	pass(2, array_in, array_out, N);
	pass(3, array_out, array_in, N);
	
    //qsort(array_in, N, sizeof(unsigned int), compar);
	
	for (i = 0; i < N; i += 10)
	    fprintf (out, "%d ", array_in[i]);

	fclose(in);
	fclose(out);
	
	return 0;
}
