#include <bits/stdc++.h>

using namespace std;
ifstream fin("radixsort.in");
ofstream fout("radixsort.out");
int n,A,B,C;
deque<int> q[256];
int a[10000005];
int main()
{
    int i,j,k;
    fin >> n >> A >> B >> C;
    a[1]=B;
    for (i=2; i<=n; i++)
        a[i]=(1ll*A*a[i-1]+B)%C;
    for (i=0; i<=3; i++)
    {
        for (j=1; j<=n; j++)
        {
            k=(a[j]>>(8*i))&255;
            q[k].push_back(a[j]);
        }
        n=0;
        for (j=0; j<=255; j++)
            while (!q[j].empty())
            {
                a[++n]=q[j].front();
                q[j].pop_front();
            }
    }
    for (i=1; i<=n; i+=10)
        fout << a[i] << " ";

    return 0;
}
