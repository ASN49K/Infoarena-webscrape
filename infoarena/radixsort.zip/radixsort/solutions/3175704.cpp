#include <bits/stdc++.h>
#define int long long
//#pragma GCC optimize("Ofast")
#pragma GCC optimize("unroll-loops")
using namespace std;
int v[10000000];
int32_t main()
{
  ifstream cin("radixsort.in");
  ofstream cout("radixsort.out");
    int n,a,b,c;
    cin>>n>>a>>b>>c;
    v[1]=b;
    for(int i=2;i<=n;i++)
      v[i]=(a*v[i-1]+b)%c;

    sort(v+1, v+n+1);
    for(int i=1;i<=n;i+=10)
      cout<<v[i]<<" ";

    return 0;
}
