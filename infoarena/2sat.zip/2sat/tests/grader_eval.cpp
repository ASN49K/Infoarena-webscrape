#include <stdio.h>
#include <stdlib.h>
#include <algorithm>

using namespace std;

#define FIN "2sat.in"
#define FOUT "2sat.out"
#define FOK "2sat.ok"

int n, m, val[100100];
pair <int, int> expr[200100];
int sol;

void result(char msg[], int p)
{
    fprintf(stderr, msg);
    printf("%d", p);
    exit(0);
}

bool eval_term(pair <int, int> T) {
    int x, y; 
    x = val[abs(T.first)];
    y = val[abs(T.second)];	    
    if (T.first < 0)
	    x ^= 1;
    if (T.second < 0)
 		y ^= 1;										        

    return (x | y);
}

int main(void)
{
    int i, a, b;
    FILE *f;

    f = fopen(FIN, "r");
    if (!f) result("Fisier de intrare lipsa!", 0);
    if (fscanf(f, "%d %d", &n, &m) != 2)
        result("1 - Fisier de intrare corupt!", 0);
   
    for (i = 1; i <= m; i++)
    {
        if (fscanf(f, "%d %d", &a, &b) != 2)
            result("2 - Fisier de intrare corupt!", 0);
        if (a < -n || a > n || (b < -n || b > n))
            result("Fisier de intrare corupt!", 0);
        expr[i] = make_pair(a, b);
    }


    f = fopen(FOK, "r");
    if (!f) result("Fisier ok lipsa!", 0);
    if (fscanf(f, "%d", &sol) != 1)
        result("Fisier ok corupt!", 0);

    f = fopen(FOUT, "r");
	if (!f)	result("Fisier out lipsa!", 0);

    if (fscanf(f, "%d", &val[1]) != 1)
   	    result("Fisier de iesire incomplet!", 0);

	if (sol == -1) {
		if (val[1] == -1)
			result("Corect", 5);
		else
			result("Gresit", 0);
	}

	if (val[1] == -1)
		result("Gresit", 0);

	for (i = 2; i <= n; i++) {
	    if (fscanf(f, "%d", &val[i]) != 1)
    	    result("Fisier de iesire incomplet!", 0);
	}

	for (i = 1; i <= n; i++)
		if (val[i] < 0 || val[i] > 1)
			result("Gresit", 0);

	int rez = 1;
	for (i = 1; i <= m; i++)
		rez = rez & eval_term(expr[i]);

	if (rez == 1)
		result("Corect", 5);
	else
		result("Gresit", 0);


    return 0;
}
