#include <bits/stdc++.h>
#define Nmax 100002
using namespace std;

ifstream f("2sat.in");
ofstream g("2sat.out");

int N, M, ID[2 * Nmax], val[2 * Nmax];
bool uz[2 * Nmax];
vector<int> v[2 * Nmax], v2[2 * Nmax], H, aux;
vector<vector<int> > C;

int NOT(int x){
	if (x > Nmax) return x - Nmax;
	else return x + Nmax;
}

void dfs(int nod){
	uz[nod] = 1;
	for (auto it : v[nod]){
		if (uz[it]) continue;
		dfs(it);
	}
	H.push_back(nod);
}

void dfs2(int nod){
	uz[nod] = 1;
	aux.push_back(nod);
	for (auto it : v2[nod]){
		if (uz[it]) continue;
		dfs2(it);
	}
}

int main(){
	f >> N >> M;
	for (int i = 1; i <= M; i++){
		int x, y;
		f >> x >> y;
		if (x < 0) x = -x + Nmax;
		if (y < 0) y = -y + Nmax;
		v[NOT(x)].push_back(y);
		v[NOT(y)].push_back(x);

		v2[y].push_back(NOT(x));
		v2[x].push_back(NOT(y));
	}

	for (int i = 1; i < 2 * Nmax; i++){
		if (!uz[i]){
			dfs(i);
		}
	}

	memset(uz, 0, sizeof(uz));
	for (auto nod = H.rbegin(); nod != H.rend(); nod++){
		if (!uz[*nod]){
			aux.clear();
			dfs2(*nod);
			C.push_back(aux);
		}
	}

	memset(ID, 0xff, sizeof(ID));
	for (int i = 0; i < C.size(); i++){
		for (auto it : C[i]){
			ID[it] = i;
		}
	}

	for (int i = 1; i < 2 * Nmax; i++){
		if (ID[i] == ID[NOT(i)] && ID[i] != -1){
			g << -1;
			return 0;
		}
	}

	memset(val, 0xff, sizeof(val));
	for (int i = C.size() - 1; i >= 0; i--){
		if (C[i].size() == 0 || val[C[i][0]] != -1) continue;
		for (auto it : C[i]){
			val[it]      = 1;
			val[NOT(it)] = 0;
		}
	}

	for (int i = 1; i <= N; i++){
		if (val[i] == -1) val[i] = 1;
		g << val[i] << ' ';
	}

	return 0;
}