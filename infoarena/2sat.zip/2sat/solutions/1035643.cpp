#include<fstream>
#include<vector>
#include<stack>

using namespace std;

#define max_n 200010

ifstream f("2sat.in");
ofstream g("2sat.out");

int n , m , xi , xj , niv;

int Niv[max_n] , Low[max_n] , Value[max_n];

bool assign;
bool Out[max_n];

vector<int> L[max_n];
stack<int> S;

inline int abs(const int x);
inline int idx(const int x);
inline int non(const int x);

inline void read(){
	
	f>>n>>m;
	
	for( int i = 1 ; i <= m ; i++ ){
		f>>xi>>xj; xi = idx(xi); xj = idx(xj);
		L[non(xi)].push_back(xj);
		L[non(xj)].push_back(xi);
	}
	
}

inline void dfs( int nod ){
	
	S.push(nod);
	
	Niv[nod] = (++niv); Low[nod] = niv;
	
	for( unsigned int i = 0 ; i < L[nod].size() ; i++ ){
		if( !Niv[L[nod][i]] )
			dfs(L[nod][i]);
		if( !Out[L[nod][i]] && Low[L[nod][i]] < Low[nod] )
			Low[nod] = Low[L[nod][i]];
	}
	
	if( Niv[nod] == Low[nod] ){
		
		int x;
		
		assign  = true;
		if(Value[S.top()])
			assign = false;
		
		do{
			x = S.top(); Out[x] = true;
			
			if( assign )
				Value[non(S.top())] = 1;
			
			S.pop();
		}while( x != nod );
		
	}
	
}

inline void tarjan(){
	
	for( int i = 1 ; i <= 2*n ; i++ )
		if( !Niv[i] )	dfs(i);
	
}

inline void print(){
	
	bool is_sol = true;
	
	for( int i = 1 ; i <= n ; i++ )
		if( Value[i] == Value[non(i)] ){
			is_sol = false; break;
		}
	
	if( is_sol ){
		for( int i = 1 ; i <= n ; i++ )
			g<<!Value[i]<<" ";
	}
	else
		g<<"-1";
	g<<"\n";
}

int main(){
	
	read();
	
	tarjan();
	
	print();
	
	return 0;
}

inline int abs( int x ){
	return (x < 0) ? (-x) : (+x);
}

inline int non( int x ){
	return (x <= n) ? (x + n) : (x - n);
}

inline int idx( int x ){
	return (x < 0) ? non(abs(x)) : x;
}
