#include <fstream>
#include <vector>
using namespace std;
ifstream fi("2sat.in");
ofstream fo("2sat.out");
int n,m;
vector <int> ADJ[200003];
vector <int> ADJT[200003];
int S[200003],k;
int VIZ[200003];
int nrc;

void df(int v)
{
	vector <int> :: iterator it;
	VIZ[v]=1;
	for (it=ADJ[v].begin();it!=ADJ[v].end();it++)
	{
		int varf;
		varf=*it;
		if (VIZ[varf]==0)
			df(varf);
	}
	S[++k]=v;
}

void dft(int v)
{
	vector <int> :: iterator it;
	VIZ[v]=nrc;
	for (it=ADJT[v].begin();it!=ADJT[v].end();it++)
	{
		int varf;
		varf=*it;
		if (VIZ[varf]==0)
			dft(varf);
	}
}

void depthfirst(int v)
{
	vector <int> :: iterator it;
	VIZ[v]=0;
	for (it=ADJT[v].begin();it!=ADJT[v].end();it++)
	{
		int varf;
		varf=*it;
		if (VIZ[varf]==-1 && VIZ[varf^1]==-1)
			depthfirst(varf);
	}
}


int main()
{
	fi>>n>>m;
	for (int i=1;i<=m;i++)
	{
		int a,b;
		fi>>a>>b;
		if (a>0)
			a=2*a;
		else
		{
			a=-a;
			a=a*2+1;
		}
		if (b>0)
			b=2*b;
		else
		{
			b=-b;
			b=b*2+1;
		}
		ADJ[a^1].push_back(b);
		ADJ[b^1].push_back(a);
		ADJT[b].push_back(a^1);
		ADJT[a].push_back(b^1);
	}
	for (int i=2;i<=2*n+1;i++)
		if (VIZ[i]==0)
			df(i);
	/// se marcheaza din ce componenta tare conexa face parte fiecare varf
	nrc=0;
	for (int i=2;i<=2*n+1;i++)
		VIZ[i]=0;
	for (int i=k;i>=1;i--)
		if (VIZ[S[i]]==0)
		{
			nrc++;
			dft(i);
		}
	/// exista incompatibilitati ?
	int t;
	t=1;
	for (int i=1;i<=n;i++)
		if (VIZ[2*i]==VIZ[(2*i)^1])
			t=0;
	if (t==0)
		fo<<"-1";
	else
	{
		for (int i=2;i<=2*n+1;i++)
			VIZ[i]=-1;
		for (int i=k;i>=1;i--)
			if (VIZ[S[i]]==-1 && VIZ[S[i]^1]==-1)
				depthfirst(S[i]);
		for (int i=1;i<=n;i++)
			if (VIZ[2*i]==-1)
				fo<<1-VIZ[(2*i)^1]<<" ";
			else
				fo<<VIZ[2*i]<<" ";
	}
	fi.close();
	fo.close();
	return 0;
}
