#include <cstdio>
#include <vector>
#include <queue>
#include <cstdlib>

FILE* in=fopen("2sat.in","r");
FILE* out=fopen("2sat.out","w");

const int Q=200007,W=800007;

int n,m;

int plst[Q],val[W],nxt[W],nr;
int plst2[Q],val2[W],nxt2[W],nr2;

int sol[Q];

bool pviz[Q];

int pcomp[Q];

int *lst;
int *lst2;
int *comp;
bool *viz;
int *rez;

int prez[Q];

void init()
{
    lst=plst+100002;
    lst2=plst2+100002;

    comp=pcomp+100002;

    viz=pviz+100002;

    rez=prez+100002;
}



std::vector<int> alese[Q];

int how[Q];

std::queue<int> q;

void rezolvare(int c)
{
    q.push(c);

    int act;
    int tipe;

    while(!q.empty())
    {
        act=q.front();
        q.pop();
        tipe=how[act];

        for(int k=0; k<alese[act].size(); k++)
        {
            rez[alese[act][k]]=tipe;

            if(how[comp[-alese[act][k]] ] == 0 )
            {
                how[comp[-alese[act][k]] ]=3-tipe;
                q.push(comp[-alese[act][k]]);
            }
            else if(how[comp[-alese[act][k]] ] == tipe)
            {
                fprintf(out,"-1");
                exit(0);
            }
        }
    }
}


void dfs2(int nod, int c)
{
    viz[nod]=0;
    comp[nod]=c;
    alese[c].push_back(nod);

    int p=lst2[nod];

    while(p)
    {
        if(viz[val2[p]]==1)
        {
            dfs2(val2[p],c);
        }
        p=nxt2[p];
    }
}

void dfs(int nod)
{
    viz[nod]=1;

    int p=lst[nod];

    while(p)
    {
        if(viz[val[p]]==0)
        {
            dfs(val[p]);
        }
        p=nxt[p];
    }
    sol[++sol[0]]=nod;
}

void add(int a, int b)
{
    val[++nr]=b;
    nxt[nr]=lst[a];
    lst[a]=nr;
}

void add2(int a, int b)
{
    val2[++nr2]=b;
    nxt2[nr2]=lst2[a];
    lst2[a]=nr2;
}

int main()
{
    fscanf(in,"%d%d",&n,&m);

    int a,b;

    init();

    for(int i=1; i<=m; i++)
    {
        fscanf(in,"%d%d",&a,&b);

        add(-a,b);
        add(-b,a);
        add2(b,-a);
        add2(a,-b);
    }

    for(int i=-n; i<=n; i++)
    {
        if(i==0)
            continue;
        if(!viz[i])
        {
            dfs(i);
        }
    }

    int c=0;

    for(int i=2*n; i>0; i--)
    {
        if(viz[sol[i]])
        {
            c++;
            dfs2(sol[i],c);
        }
    }

    for(int i=2*n; i>0; i--)
    {
        if(rez[sol[i]]==0)
        {
            how[comp[sol[i] ] ]=2;
            rezolvare(comp[sol[i]]);
        }
    }

    for(int i=1; i<=n; i++)
    {
        fprintf(out,"%d ",rez[i]-1);
    }

    return 0;
}
