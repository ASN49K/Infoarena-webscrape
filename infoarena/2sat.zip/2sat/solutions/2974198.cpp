#include <fstream>
#include <vector>
#include <algorithm>
#include <bitset>
using namespace std;
string file = "2sat";
ifstream cin(file + ".in");
ofstream cout(file + ".out");
const int N = 100000;
vector <int> succesori[2 * N + 1], predecesori[2 * N + 1], ordine, ctc(2*N+1);
bitset <N + 1> viz, val;
int nctc;
int val_asoc(int x)
{
	return (x < 0 ? -2 * x - 1 : 2 * x);
}
int negatie(int x)
{
	return (x % 2 ? x + 1 : x - 1);
}

void dfs_init(int x)
{
	ordine.push_back(x);
	viz[x] = 1;
	for (int y : succesori[x])
	{
		if (!viz[y])
			dfs_init(y);
	}
}

void dfs_transpus(int x)
{
	ctc[x] = nctc;
	for (int y : predecesori[x])
	{
		if (ctc[y] == 0)
		{
			dfs_transpus(y);
		}
	}
}
int main()
{
	int n, m, x, y;
	cin >> n >> m;
	for (int i = 0; i < m; i++)
	{
		cin >> x >> y;
		x = val_asoc(x);
		y = val_asoc(y);
		succesori[negatie(x)].push_back(y);
		predecesori[y].push_back(negatie(x));
		succesori[negatie(y)].push_back(x);
		predecesori[x].push_back(negatie(y));
	}
	for (int i = 1; i <= 2 * n; i++)
	{
		if (!viz[i])
		{
			dfs_init(i);
		}
	}
	reverse(ordine.begin(), ordine.end());
	for (int x : ordine)
	{
		if (ctc[x] == 0)
		{
			++nctc;
			dfs_transpus(x);
		}
	}
	bool este_sat(1);
	for (int i = 1; i <= 2 * n; i+=2)
	{
		if (ctc[i] < ctc[i + 1])
		{
			val[(i + 1) / 2] = 1; // par dupa impar
		}
		else if (ctc[i+1] < ctc[i]) // par inainte de impar 
		{
			val[(i + 1) / 2] = 0;
		}
		else
		{
			este_sat = 0;
			break;
		}
	}
	if (!este_sat)
	{
		cout << -1;
	}
	else
	{
		for (int i = 1; i <= n; i++)
		{
			cout << val[i] << ' ';
		}
	}
}