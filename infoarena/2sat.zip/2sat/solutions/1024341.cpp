#include<fstream>
#include<vector>
#include<stack>
#include<queue>
#include<cstring>

#define NMAX 200010
#define VEC G[nod][i]
#define PLUS 100002

using namespace std;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

vector<int> G[NMAX],GT[NMAX];
int n,m,CTC[NMAX],nr,degin[NMAX],marked[NMAX],T[NMAX];
bool use[NMAX];
stack<int> S;
queue<int> Q;

int complement(int x)
{
	if(x<0)
		return -x;
	return PLUS+x;
}

void read()
{
	fin>>n>>m;
	for(int i=0,x,y,cx,cy;i<m;i++)
	{
		fin>>x>>y;
		cx=complement(x);
		cy=complement(y);
		if(x<0)
			x=PLUS-x;
		if(y<0)
			y=PLUS-y;
		G[cx].push_back(y);
		GT[y].push_back(cx);
		G[cy].push_back(x);
		GT[x].push_back(cy);
	}
}

void PM(vector<int> *G,int nod)
{
	use[nod]=1;
	for(size_t i=0;i<G[nod].size();i++)
		if(!use[VEC])
			PM(G,VEC);
	S.push(nod);
}

void Kosaraju(vector<int> *G,int nod)
{
	use[nod]=1;
	CTC[nod]=nr;
	for(size_t i=0;i<G[nod].size();i++)
		if(!use[VEC])
			Kosaraju(G,VEC);
}

void edges()
{
	for(int nod=1;nod<NMAX;nod++)
	{
		if(!CTC[nod])
			continue;
		T[CTC[nod]]=nod;
		GT[CTC[nod]].clear();
		for(size_t i=0;i<G[nod].size();i++)
			if(CTC[nod]!=CTC[VEC])
			{
				GT[CTC[nod]].push_back(CTC[VEC]);
				degin[CTC[VEC]]++;
			}
	}
}

int main()
{
	read();
	for(int i=1;i<=n;i++)
		if(!use[i])
			PM(G,i);
	for(int i=1+PLUS;i<=n+PLUS;i++)
		if(!use[i])
			PM(G,i);
	memset(use,0,sizeof use);
	for(;!S.empty();S.pop())
		if(!use[S.top()])
		{
			nr++;
			Kosaraju(GT,S.top());
		}
	for(int i=1;i<=n;i++)
		if(CTC[i]==CTC[i+PLUS])
		{
			fout<<"-1\n";
			exit(0);
		}
	
	edges();
	for(int nod=1;nod<=nr;nod++)
		if(!degin[nod])
			Q.push(nod);
	vector<int> *G=GT;
	for(int nod,cnod,val;!Q.empty();Q.pop())
	{
		nod=Q.front();
		if(!marked[nod])
		{
			val=T[nod];
			if(val<PLUS)
				cnod=CTC[val+PLUS];
			else
				cnod=CTC[val-PLUS];
			marked[nod]=1;
			marked[cnod]=2;
		}
		for(size_t i=0;i<G[nod].size();i++)
			if(!--degin[VEC])
				Q.push(VEC);
	}
	for(int i=1;i<=n;i++)
		fout<<marked[CTC[i]]-1<<' ';
	
	return 0;
}
