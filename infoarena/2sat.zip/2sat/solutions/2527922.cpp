#include <bits/stdc++.h>
#define DIM 200010
using namespace std;

ifstream fin ("2sat.in");
ofstream fout ("2sat.out");
vector <int> L[DIM];
int viz[DIM],low[DIM],niv[DIM],sol[DIM];
deque <int> s;
set <int> v;
int n,m,i,x,y,xx,yy,idx,ok;
int convert (int x){
    if (x > 0)
        return x+n;
    return -x;
}
int convert2 (int x){
    if (x <= n)
        return x+n;
    return x-n;
}
void dfs (int nod){
    viz[nod] = 1;
    low[nod] = niv[nod] = ++idx;
    s.push_back(nod);
    for (auto vecin:L[nod]){
        if (!niv[vecin]){
            dfs (vecin);
            low[nod] = min (low[nod],low[vecin]);
        } else {
            if (viz[vecin])
                low[nod] = min (low[nod],low[vecin]);
        }
    }
    if (low[nod] == niv[nod]){
        /// am componenta tare conexa
        /// toate nodurile din componenta trb sa aiba aceeasi valoare
        int x;
        v.clear();
        do{
            x = s.back();
            int notx = convert2 (x);

            if (v.find(notx) != v.end())
                ok = 1;

            if (sol[x] == 0){
                sol[x] = 1;
                sol[notx] = -1;
            }

            v.insert(x);
            s.pop_back();
            viz[x] = 0;

        } while (x != nod);


    }
}
int main (){

    fin>>n>>m;
    for (i=1;i<=m;i++){
        fin>>x>>y;
        xx = convert (x), yy = convert (y);
        if (x < 0)
            x = -x+n;
        if (y < 0)
            y = -y+n;
        L[xx].push_back(y);
        L[yy].push_back(x);
    }

    for (i=1;i<=2*n;i++)
        if (!viz[i])
            dfs (i);

    for (i=1;i<=n;i++){
        int noti = convert2 (i);
        if (sol[i] == sol[noti]){
            ok = 1;
            break;
        }
    }

    if (ok){
        fout<<-1;
        return 0;
    }
    for (i=1;i<=n;i++){
        if (sol[i] == -1)
            fout<<"0 ";
        else fout<<"1 ";
    }

    return 0;
}
