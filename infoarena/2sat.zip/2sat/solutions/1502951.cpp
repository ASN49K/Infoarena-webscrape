#include<cstdio>
#include<vector>

using namespace std;

int N, M, nr;

class SAT2
{
public:
    int N, nr, Q[200009], ap[200009], sol[200009];
    vector < int > v[200009], h[200009];

    int cod (int x)
    {
        if (x < 0) return N - x;
        return x;
    }

    int opus (int nod)
    {
        if (nod <= N) return nod + N;
        return nod - N;
    }

    void add_implication (int x, int y)
    {
        v[cod (x)].push_back (cod (y));
        h[cod (y)].push_back (cod (x));
    }

    void add_clause (int x, int y)
    {
        add_implication (-x, y);
        add_implication (-y, x);
    }

    void dfs (int nod)
    {
        ap[nod] = 1;
        for (vector < int > :: iterator it = v[nod].begin (); it != v[nod].end (); it ++)
            if (ap[*it] == 0) dfs (*it);
        Q[++nr] = nod;
    }

    void dfp (int nod)
    {
        if (sol[nod])
        {
            sol[0] = -1;
            return ;
        }
        sol[opus (nod)] = 1;
        ap[nod] = 0;
        for (vector < int > :: iterator it = h[nod].begin (); it != h[nod].end (); it ++)
            if (ap[*it] == 1) dfp (*it);
    }

    bool solve ()
    {
        for (int i=1; i<=2 * N; i++)
            if (ap[i] == 0) dfs (i);
        for (int i=nr; i>=1; i--)
            if (ap[Q[i]] == 1 && ap[opus (Q[i])] == 1) dfp (Q[i]);
        if (sol[0] == -1) return 0;
        return 1;
    }
}sistem;

int main ()
{
freopen ("2sat.in", "r", stdin);
freopen ("2sat.out", "w", stdout);

scanf ("%d %d", &N, &M), sistem.N = N;
while (M --)
{
    int x, y;
    scanf ("%d %d", &x, &y);
    sistem.add_clause (x, y);
}

if (sistem.solve ())
{
    for (int i=1; i<=N; i++)
        printf ("%d ", sistem.sol[i]);
    printf ("\n");
    return 0;
}
printf ("-1\n");

return 0;
}

