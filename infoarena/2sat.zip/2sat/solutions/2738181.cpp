#include <bits/stdc++.h>
#define ll long long
#define ld long double
 
using namespace std;
 
const ll MOD = 1e9 + 7;
const ll INF = 1e9;
const int N = 1e6 + 1;
 
ifstream fin ("2sat.in");
ofstream fout ("2sat.out");

int n, m, val[200002], comp[200002], nr;
bool viz[200002];
stack<int>st;
vector<int>G[200002], G2[200002];
vector<vector<int> > ctc;
vector<int>c;

void dfs (int x) {
  viz[x] = 1;
  for (auto it : G[x]) {
    if (!viz[it])
      dfs(it);
  }
  st.push(x);
}

void dfs2 (int x) {
  comp[x] = nr;
  viz[x] = 1;
  c.push_back(x);
  for (auto it : G2[x])
    if (!viz[it])
      dfs2(it);
}

int neg (int x) {
  if (x > n)
    return x - n;
  else
    return x + n;
}
int nod (int x) {
  if (x < 0)
    return -x + n;
  else
    return x;
}

void add_edge (int x, int y) {
  // assert(x >= 1 && x <= 2 * n);
  // assert(y >= 1 && y <= 2 * n);
  G[x].push_back(y);
  G2[y].push_back(x);
}

int main()
{
  //ios_base::sync_with_stdio(false);
  //fin.tie(0); fout.tie(0);
  fin >> n >> m;
  for (int i = 1; i <= m; i++) {
    int x, y;
    fin >> x >> y;
    x = nod(x);
    y = nod(y);
    add_edge(neg(x), y);
    add_edge(neg(y), x);
  }
  for (int i = 1; i <= 2 * n; i++)
    if (!viz[i])
      dfs(i);
  memset(viz, 0, sizeof(viz));
  while (st.size()) {
    if (!viz[st.top()]) {
      nr++;
      c.clear();
      dfs2(st.top());
      ctc.push_back(c);
    }
    st.pop();
  }
  memset(val,-1, sizeof(val));
  for (auto c: ctc) {
    bool ok = 1;
    for (auto it : c)
      if (comp[it] == comp[neg(it)])
        ok = 0;
    int bit = -1;
    for (auto it : c) {
      if (val[it] != -1 && bit == -1)
        bit = val[it];
      if (val[it] != bit && bit != -1 && val[it] != -1)
        ok = 0;
    }
    if (bit == -1)
      bit = 0;
    for (auto it : c) {
      val[it] = bit;
      if (val[it] != 1 - val[neg(it)] && val[neg(it)] != -1)
        ok = 0;
      val[neg(it)] = 1 - bit;
    }
    if (!ok) {
      fout << -1;
      return 0;
    }
  }
  for (int i = 1; i <= n;i++)
    fout << val[i] << " ";
  return 0;
}