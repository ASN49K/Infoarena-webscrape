#include <cstdio>
#include <vector>

using namespace std;

vector<int> v[200010],vt[200010];
int q[200010],n,nr,ok=1;
char vaz[200010],sol[200010];

int non(int x)
{
    if(x<=n) return x+n;
    else return x-n;
}

void dfs1(int nod)
{
    vaz[nod]=1;
    for(vector<int>::iterator it=v[nod].begin();it!=v[nod].end();it++)
        if(!vaz[*it]) dfs1(*it);
    q[++nr]=nod;
}

void dfs2(int nod)
{
    if(sol[nod])
    {
        ok=0;
        return;
    }
    vaz[nod]=sol[nod]=0;
    sol[non(nod)]=1;
    for(vector<int>::iterator it=vt[nod].begin();it!=vt[nod].end();it++)
        if(vaz[*it]) dfs2(*it);
}

int main()
{
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);
    int m,x,y;
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)
    {
        scanf("%d%d",&x,&y);
        if(x<0) x=n-x;
        if(y<0) y=n-y;
        v[non(x)].push_back(y);
        v[non(y)].push_back(x);
        vt[y].push_back(non(x));
        vt[x].push_back(non(y));
    }
    for(int i=1;i<=2*n;i++) if(!vaz[i]) dfs1(i);
    for(int i=nr;i && ok;i--) if(vaz[q[i]] && vaz[non(q[i])]) dfs2(q[i]);
    if(ok) for(int i=1;i<=n;i++) printf("%d ",sol[i]);
    else printf("-1");
    return 0;
}
