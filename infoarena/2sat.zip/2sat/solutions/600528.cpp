#include<stdio.h>
#include<stdlib.h>
#define N 200001
long a[N],b[N],c[N],d[N],n,m,i,j,k,*g[N],deg[N]={0},viz[N]={0},l;
int p[N],ok;

void det(int p[N],int *ok)
{long i,j,l;
while(1)
      {for(i=1;i<=2*n;i++)
      if(!p[i])
               {for(j=0;j<deg[i];j++)      
               if(p[g[i][j]]==2)
                        {p[g[i][j]]=1;
                        if(g[i][j]>n)
                                     p[g[i][j]-n]=0;
                        else
                                     p[g[i][j]+n]=0;}
               else
                        if(!p[g[i][j]])
                                     (*ok)=1;}
      l=1;
      for(i=1;i<=m;i++)
      if(p[c[i]]==2||p[d[i]]==2)
               {l=0;
               break;}
      if((*ok)||l)
               break;}}
int main()
{freopen("2sat.in","r",stdin);
freopen("2sat.out","w",stdout);
scanf("%ld%ld",&n,&m);
for(i=1;i<=m;i++)
      {scanf("%ld%ld",&a[i],&b[i]);
      if(a[i]<0)
             c[i]=n-a[i];
      else
             c[i]=a[i];
      deg[c[i]]++;
      if(b[i]<0)
             d[i]=n-b[i];
      else
             d[i]=b[i];
      deg[d[i]]++;}
for(j=1;j<=2*n;deg[j++]=0)
      {g[j]=(long*)malloc(deg[j]*sizeof(long));
      p[j]=2;}
for(k=1;k<=m;k++)
      {g[c[k]][deg[c[k]]++]=d[k];
      g[d[k]][deg[d[k]]++]=c[k];}
for(i=1;i<=2*n;i++)
if(deg[i]>=1)
      {p[i]=0;
      if(i>n)
             p[i-n]=1;
      else
             p[i+n]=1;
      k=i;
      break;}
ok=0;
det(p,&ok);
if(ok)
      {for(i=1;i<=2*n;i++)
             p[i]=2;
      p[k]=1;
      if(k>n)
             p[k-n]=0;
      else
             p[k+n]=0;}
ok=0;
det(p,&ok);
if(!ok)
      {for(i=1;i<=n;i++)
      if(p[i]==2)
             printf("0 ");
      else
             printf("%d ",p[i]);}
else
      printf("-1");
fclose(stdin);
fclose(stdout);
return 0;}
