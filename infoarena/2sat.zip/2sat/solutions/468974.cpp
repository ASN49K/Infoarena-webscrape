#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#define NMAX 100005
#define LMAX 200005
int n,m,sol[NMAX],found;
struct muchie
{
	int a,b;
};
muchie A[LMAX];
void read()
{
	scanf("%d%d",&n,&m);
	int i;
	for (i=1; i<=m; i++)
		scanf("%d%d",&A[i].a,&A[i].b);
}
inline int eval(int x,int y)
{
	return x | y;
}
inline int modul(int x)
{
	return x<0 ? -x : x;
}
inline int negare(int x,int y)
{
	return y>=0 ? x : !x;
}
void solve()
{
	srand(time(0));
	int i,j,failed,a,b,a1,b1;
	for (i=1; i<=n; i++)
		sol[i]=rand()%2;
	for (i=1; i<=n*20; i++)
	{
		found=1; failed=1;
		for (j=1; j<=m; j++)
		{
			a=modul(A[j].a); b=modul(A[j].b); a1=a; b1=b;
			a=negare(sol[a],A[j].a); b=negare(sol[b],A[j].b);
			if (!eval(a,b))
			{
				found=0;
				failed=j;
				break ;
			}
		}
		if (found)
			return ;
		if (rand()%2==0)
			sol[a1]^=1;
		else
			sol[b1]^=1;
	}
}
void show()
{
	int i;
	for (i=1; i<=n; i++)
		printf("%d ",sol[i]);
}
int main()
{
	freopen("2sat.in","r",stdin);
	freopen("2sat.out","w",stdout);
	read();
	solve();
	if (!found)
	{
		printf("-1\n");
		return 0;
	}
	show();
	return 0;
}
