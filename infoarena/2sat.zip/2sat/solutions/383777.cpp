#include<stdio.h>
#define non(x) x<=n?x+n:x-n
#define nod(x) x>0?x:n-x
#define NN 2010
struct nod{int vec;nod *urm;};
nod *Out[NN],*In[NN],*CT[NN],*S;
int n,m,NC,LOW[NN],DFN[NN],VIZ[NN],CC[NN],num;
void read(),solve(),visit(int p);
int main()
{
	read();
	solve();
	return 0;
}
void read()
{
	int i,x,y,X,Y;
	nod *p;
	freopen("2sat.in","r",stdin);
	freopen("2sat.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(i=1;i<=m;i++)
	{
		scanf("%d%d",&x,&y);
		x=nod(x);X=non(x);
		y=nod(y);Y=non(y);
		p=new nod;p->vec=x;p->urm=Out[Y];Out[Y]=p;
		p=new nod;p->vec=y;p->urm=Out[X];Out[X]=p;
		p=new nod;p->vec=X;p->urm=In[y];In[y]=p;
		p=new nod;p->vec=Y;p->urm=In[x];In[x]=p;
		
	}
}
void solve()
{
	int i;
	for(i=1;i<=2*n;i++)if(!VIZ[i]){num=0;visit(i);}
	for(i=1;i<=n;i++)if(CC[i]==CC[i+n]){printf("-1\n");return;}
}
void visit(int I)
{
	int J;
	nod *p;
	VIZ[I]=-1;num++;DFN[I]=LOW[I]=num;
	p=new nod;p->vec=I;p->urm=S;S=p;
	for(p=Out[I];p;p=p->urm)
	{
		if(!VIZ[p->vec])visit(p->vec);
		LOW[I]=LOW[I]<LOW[p->vec]?LOW[I]:LOW[p->vec];
	}
	if(DFN[I]==LOW[I])
	{
		NC++;
		for(;;)
		{
			J=S->vec;
			p=S;S=S->urm;delete p;
			p=new nod;p->vec=J;p->urm=CT[NC];CT[NC]=p;
			CC[J]=NC;
			if(J==I)break;
		}
	}
}

