#include <iostream>
#include <fstream>
#include <vector>

using namespace std;
ifstream f("2sat.in");
ofstream g("2sat.out");

bool Use[100005];
int n, m, top[100005], ok, sol[100005], nr;
vector <int> G[100005], GT[100005];

int non(int a)
{
    if(a <= n) return a+n;
    return a-n;
}

void Read()
{
    f>>n>>m;
    while(m--)
    {
        int a, b;
        f>>a>>b;
        if(a < 0) a = n-a;
        if(b < 0) b = n-b;
        G[non(a)].push_back(b);
        G[non(b)].push_back(a);
        GT[a].push_back(non(b));
        GT[b].push_back(non(a));
    }
}

void DFS1(int nod)
{
    Use[nod] = 1;
    for(int i = 0; i < (int)G[nod].size(); i++)
    {
        int vecin = G[nod][i];
        if(!Use[vecin]) DFS1(vecin);
    }
    top[++nr] = nod;
}

void DFS2(int nod)
{
    if(sol[nod] == 1)
    {
        ok = 1;
        return;
    }
    Use[nod] = 0;
    sol[non(nod)] = 1;
    for(int i = 0 ; i < (int)G[nod].size(); i++)
    {
        int vecin = G[nod][i];
        if(Use[vecin]) DFS2(vecin);
    }
}

void Solve()
{
    for(int i = 1; i <= 2*n; i++)
    {
        if(!Use[i]) DFS1(i);
    }
    for(int i = n; i > 0; i--)
    {
        if(Use[top[i]] == 1 && Use[non(top[i])] == 1) DFS2(top[i]);
    }
}

void Print()
{
    if(ok == 1) g<<-1;
    else for(int i = 1; i <= n; i++) g<<sol[i]<<' ';
    g<<'\n';
}

int main()
{
    Read();
    Solve();
    Print();
    return 0;
}
