#include <bits/stdc++.h>

using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
typedef pair<int,int> pii;
int n,m;
vector<pii> g;
vector<int> muchii[300005],st;
int nr;
vector<int> nodes[300005];
bool use[300005];
int comp[300005],grad[300005],sol[300005];
void dfs1(int nod)
{
    use[nod]=1;
    for(int i:muchii[nod])
        if(!use[i])
            dfs1(i);
    st.push_back(nod);
}
void dfs2(int nod)
{
    comp[nod]=nr;
    nodes[nr].push_back(nod-n);
    for(int i:muchii[nod])
        if(comp[i]==0)
            dfs2(i);
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        muchii[-a+n].push_back(b+n);
        muchii[-b+n].push_back(a+n);
        g.push_back({-a+n,b+n});
        g.push_back({-b+n,a+n});
    }
    for(int i=-n;i<=n;i++)
        if(i!=0&&!use[i+n])
            dfs1(i+n);
    reverse(st.begin(),st.end());
    for(int i=-n;i<=n;i++)
        if(i!=0)
            muchii[i+n].clear();
    for(auto i:g)
        muchii[i.second].push_back(i.first);
    for(int i:st)
        if(comp[i]==0)
        {
            nr++;
            dfs2(i);
        }
    for(int i=-n;i<=n;i++)
        if(i!=0)
        {
            muchii[i+n].clear();
            if(comp[i+n]==comp[-i+n])
            {
                fout<<-1;
                return 0;
            }
        }
    for(auto i:g)
    {
        int c1=comp[i.first];
        int c2=comp[i.second];
        muchii[c1].push_back(c2);
        grad[c2]++;
    }
    queue<int> coada;
    for(int i=1;i<=nr;i++)
    {
        coada.push(i);
        use[i]=0;
    }
    while(!coada.empty())
    {
        int c=coada.front();
        int aux=0;
        coada.pop();
        if(!use[c])
        {
            for(int i:nodes[c])
                aux=comp[-i+n];
            for(int i:nodes[c])
                if(comp[-i+n]!=aux)
                {
                    fout<<-1;
                    return 0;
                }
            for(int i:nodes[c])
            {
                if(i>0)
                    sol[i]=0;
                else
                    sol[-i]=1;
            }
            use[c]=1;
            use[aux]=1;
        }
        for(int i:muchii[c])
        {
            grad[i]--;
            if(grad[i]==0)
                coada.push(i);
        }
    }
    for(int i=1;i<=n;i++)
        fout<<sol[i]<<' ';
    return 0;
}
