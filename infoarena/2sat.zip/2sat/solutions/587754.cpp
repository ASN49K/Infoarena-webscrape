#include <cstdio>
#include <vector>

using namespace std;

const int N = 200005;

vector <int> L[N], LT[N];

int n, ft[N], sol[N];

int non(int x) {
  if (x <= n)
    return x + n;
  return x - n;
}

void read() {
  int m, a, b;

  scanf("%d%d", &n, &m);

  for (int i = 1; i <= m; ++ i) {
    scanf("%d%d", &a, &b);

    if (a < 0)
      a = n + (- a);

    if (b < 0)
      b = n + (- b);

    L[non(a)].push_back(b);
    L[non(b)].push_back(a);
  
    LT[b].push_back(non(a));
    LT[a].push_back(non(b));
  }
}

bool impossible, viz[N];

//ft = fii inainte de tati

void make_vec(int nod) {
  viz[nod] = 1;
  
  for (int i = 0; i < L[nod].size(); ++ i)
    if (! viz[L[nod][i]])
      make_vec(L[nod][i]);

  ft[++ ft[0]] = nod;
}

void ctc(int nod) {
  if (sol[nod]) 
    impossible = 1;
  viz[nod] = 1;
  sol[non(nod)] = 1;
  for (int i = 0; i < LT[nod].size(); ++ i)
    if (! viz[LT[nod][i]])
      ctc(LT[nod][i]);
}

void reset() {
  for (int i = 1; i <= 2 * n; ++ i)
    viz[i] = 0;
}

void solve() {
  for (int i = 1; i <= 2 * n; ++ i)
    if (! viz[i])
      make_vec(i);

  reset();
  
  for (int i = 2 * n; i >= 1; -- i)
      if ((! viz[ft[i]]) && (! viz[non(ft[i])]))
        ctc(ft[i]);

  if (impossible) {
    printf("-1\n");
    return;
  }

  for (int i = 1; i <= n; ++ i)
    printf("%d ", sol[i]);
}

int main() {
  freopen("2sat.in", "r", stdin);
  freopen("2sat.out", "w", stdout);

  read();
  solve();
  
  return 0;
}
