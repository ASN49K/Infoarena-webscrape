#include<bits/stdc++.h>
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
const long long K=2e5+1;
vector<int>v[K],vt[K];
int viz[K],Viz[K],j,val[K];
int sum[K];
bool as[K];
int nrp[K],poz[K];
stack<int>st;
vector<vector<int>>ctc;
int nrctc[K];
vector<int>dag[K],dagt[K];
vector<int>cc;
vector<int>x,y;
vector<int>nx,ny;
void dfs(int nod)
{
    viz[nod]=true;
    for(auto q:v[nod])
    {
        if(!viz[q])
            dfs(q);
    }
    st.push(nod);
}
void Dfs(int nod)
{
    Viz[nod]=true;
    for(auto q:vt[nod])
    {
        if(!Viz[q])
            Dfs(q);
    }
    cc.push_back(nod);
}
int main()
{
    int n,m,i,a,b;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>a>>b;
        if(a<0)
        {
            a=-a;
            a+=n;
            a--;
        }
        else a--;
        if(b<0)
        {
            b=-b;
            b+=n;
            b--;
        }
        else b--;
        //fout<<a<<" "<<b<<endl;
        //fout<<(b+n)%(2*n)<<" "<<(a+n)%(2*n)<<endl;
        v[(a+n)%(2*n)].push_back(b);
        v[(b+n)%(2*n)].push_back(a);
        vt[b].push_back((a+n)%(2*n));
        vt[a].push_back((b+n)%(2*n));
    }
    for(int i=0;i<2*n;i++)
        if(!viz[i])
            dfs(i);
    while(!st.empty())
    {
        j=st.top();
        st.pop();
        if(!Viz[j])
        {
            cc.clear();
            Dfs(j);
            ctc.push_back(cc);
        }
    }
    for(int i=0;i<ctc.size();i++)
        for(auto q2:ctc[i])
            nrctc[q2]=i+1;
    for(int i=0;i<2*n;i++)
        for(auto q:v[i])
            if(nrctc[i]!=nrctc[q])
            {
                dag[nrctc[i]].push_back(nrctc[q]);
                dagt[nrctc[q]].push_back(nrctc[i]);
                nrp[nrctc[q]]++;
            }
    vector<int>v;
    queue<int>q;
    for(int i=1;i<=ctc.size();i++)
        if(dagt[i].size()==0)
        {
            q.push(i);
        }
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        v.push_back(nod);
        poz[nod]=v.size()-1;
        for(auto qq:dag[nod])
        {
            nrp[qq]--;
            if(nrp[qq]==0)
                q.push(qq);
        }
    }
    for(int i=0;i<n;i++)
        if(nrctc[i]==nrctc[i+n])
        {
            fout<<-1;
            return 0;
        }
    for(int i=0;i<n;i++)
    {
        if(poz[nrctc[i]]<poz[nrctc[i+n]])
            fout<<0<<" ";
        else fout<<1<<" ";
    }
}
