#include <iostream>
#include <algorithm>
#include <fstream>
#include <vector>

const int MAXN = 2e5 + 5,ADUNA = 1e5;

using namespace std;

ifstream in("2sat.in");
ofstream out("2sat.out");

int n,m;
int stiva[MAXN],varf = 0,viz[MAXN],ans[MAXN],raspuns[MAXN],comp;
bool fara_sol = false;
vector<int>graf[MAXN],graf_t[MAXN],graf_ctc[MAXN];
vector<int>componente[MAXN];
int care_comp[MAXN];


int val(int ceva){
    if(ceva < 0){
        ceva += 2e5;
    }
    return ceva;
}
void afis(int nod){
    if(nod > 1e5)
        cout<<nod - 2e5<<" ";
    else
        cout<<nod<<" ";
}
void dfs1(int nod){
    //cout<<"DFS";
    //afis(nod);;
    viz[nod] = true;
    for(auto const &vecin : graf[nod])
        if(!viz[vecin])
            dfs1(vecin);
    stiva[++varf] = nod;
}
void dfs2(int nod){
    care_comp[nod] = comp;
    componente[comp].push_back(nod);
    viz[nod] = true;
    for(auto const &vecin : graf_t[nod])
        if(!viz[vecin])
            dfs2(vecin);
}
void creaza_graf(int nod){
    viz[nod] = true;
    for(auto const &vecin : graf_t[nod])
        if(!viz[vecin])
            creaza_graf(vecin);
    for(auto const &vecin : graf[nod]){
        if(care_comp[nod] != care_comp[vecin]){
            graf_ctc[care_comp[nod]].push_back(care_comp[vecin]);
        }
    }
}
void df_final(int nod){
    ans[nod] = 0;
    if(fara_sol)
        return;
    for(int i = 0; i < graf_ctc[nod].size(); i++){
        if(fara_sol)
            return;
        int curent = graf_ctc[nod][i];
        int opus = comp - nod + 1;

        if(ans[opus] == -1)
            ans[opus] = 1;
        else if(ans[opus] == 0){
            fara_sol = true;
            return;
        }
        for(auto const &vecin : graf_ctc[opus]){
            if(ans[vecin] == 0){
                fara_sol = true;
                return;
            }
        }
        if(ans[curent] != 1)
            df_final(curent);
    }
}


int main()
{
    in>>n>>m;
    for(int i = 1; i <= m; i++){
        int a,b;
        in>>a>>b;
        graf[val(-a)].push_back(val(b));
        graf_t[val(b)].push_back(val(-a));
        graf[val(-b)].push_back(val(a));
        graf_t[val(a)].push_back(val(-b));
    }
    for(int i = 1; i <= n; i++){
        if(!viz[i]){
            dfs1(i);
        }
    }
    for(int i = -n; i <= n; i++)
        viz[val(i)] = false;
    for(int i = varf; i >= 1; i--){
        int nod = stiva[i];
        if(!viz[nod]){
            comp++;
            dfs2(nod);
        }
    }
    for(int i = -n; i <= n; i++)
        viz[val(i)] = false;
    for(int i = varf; i >= 1; i--){
        int nod = stiva[i];
        if(!viz[nod]){
            creaza_graf(nod);
        }
    }
    for(int i = 1; i <= comp; i++){
        int nod = val(i);
        ans[i] = -1;
        sort(graf_ctc[nod].begin(),graf_ctc[nod].end());
        graf_ctc[nod].erase(unique(graf_ctc[nod].begin(),graf_ctc[nod].end()),graf_ctc[nod].end());
    }
//    cout<<"Graful CTC : "<<"\n";
//    for(int i = 1; i <= comp; i++){
//        int nod = val(i);
//        afis(nod);cout<<"->";
//        for(auto const &vecin : graf_ctc[nod])
//            afis(vecin);
//        cout<<endl;
//    }
    df_final(1);
    if(fara_sol){
        out<<-1;
        return 0;
    }
    for(int i = 1; i <= comp; i++){
        for(auto const &vecin : componente[i]){
            if(vecin > 0)
                raspuns[vecin] = ans[i];
        }
    }
    for(int i = 1; i <= n; i++)
        out<<raspuns[i]<<" ";
    return 0;
}
