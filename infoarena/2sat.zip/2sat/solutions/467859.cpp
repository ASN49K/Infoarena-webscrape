#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <algorithm>
#include <vector>

using namespace std;

#define file_in "2sat.in"
#define file_out "2sat.out"

#define nmax 232133

int n,m;
vector<int> G[nmax];
vector<int> Gt[nmax];
int ok,nr;
int viz[nmax];
int sol[nmax];
int ord[nmax];


inline int neg(int a)
{
    if (a>n)
        return a-n;
    else
        return a+n;
}

void citire()
{
    int i,a,b;
    freopen(file_in,"r",stdin);
    freopen(file_out,"w",stdout);

    scanf("%d %d", &n, &m);
    while(m--)
    {
        scanf("%d %d", &a, &b);
        if (a<0)
            a=n-a;
        if (b<0)
            b=n-b;
        G[neg(a)].push_back(b);
        G[neg(b)].push_back(a);
        Gt[a].push_back(neg(b));
        Gt[b].push_back(neg(a));
    }

}

void dfs(int nod)
{
	int i;
	if (viz[nod])
		return ;
	viz[nod]=1;
	for (i=0;i<G[nod].size();++i)
		 if (!viz[G[nod][i]])
			 dfs(G[nod][i]);
	ord[++nr]=nod;
}

void dfst(int nod)
{
	int i;
	if (viz[nod])
		return ;
	viz[nod]=1;
	if (sol[nod]) ok=0;
	sol[neg(nod)]=1;
	for (i=0;i<Gt[nod].size();++i)
		 if (!viz[Gt[nod][i]])
			 dfst(Gt[nod][i]);
}


void solve()
{
    int i;
    ok=1;
    nr=0;
    for (i=1;i<=2*n;++i)
          if (!viz[i])
             dfs(i);
    memset(viz,0,sizeof(viz));
    for (i=2*n;i>=1;--i)
         if (!viz[ord[i]] && !viz[ord[neg(i)]])
             dfst(ord[i]);
    if (!ok)
      printf("-1\n");
      else
    for (i=1;i<=n;++i)
         printf("%d ", sol[i]);
}

int main()
{
    citire();
    solve();

    fclose(stdin);
    fclose(stdout);

    return 0;
}
