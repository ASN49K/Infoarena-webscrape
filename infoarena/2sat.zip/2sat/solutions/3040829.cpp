#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;

vector <int> edges[2 * NMAX];

void add_edges( int a, int b ) {
    edges[a ^ 1].push_back( b );
    edges[b ^ 1].push_back( a );
}

int comp[2 * NMAX], found_time[2 * NMAX], min_found[2 * NMAX];

bool onStack[2 * NMAX];
stack <int> st;

int t = 0, cur_comp = 0;

void dfs( int node ) {
    found_time[node] = min_found[node] = ++t;
    onStack[node] = true;
    st.push( node );
    for ( auto vec : edges[node] ) {
        if ( !found_time[vec] ) {
            dfs( vec );
            min_found[node] = min( min_found[node], min_found[vec] );
        } else if ( onStack[vec] ) {
            min_found[node] = min( min_found[node], found_time[vec] );
        }
    }

    if ( min_found[node] == found_time[node] ) {
        int aux;
        do {
            aux = st.top();
            comp[aux] = cur_comp;
            onStack[aux] = false;
            st.pop();
        } while ( aux != node );
        cur_comp ++;
    }
}
int main() {
    ifstream fin( "2sat.in" );
    ofstream fout( "2sat.out" );
    int n, m;
    fin >> n >> m;
    for ( int i = 1, a, b; i <= m; i ++ ) {
        fin >> a >> b;
        a = ( a < 0 ) ? -a * 2 - 1 : a * 2 - 2;
        b = ( b < 0 ) ? -b * 2 - 1 : b * 2 - 2;
        add_edges( a, b );
    }
    for ( int i = 0; i < 2 * n; i ++ ) if ( !found_time[i] ) dfs( i );
    bool sepoate = true;
    for ( int i = 0; i < 2 * n; i ++ ) {
        if ( comp[i] == comp[i ^ 1] ) sepoate = false;
    }
    if ( sepoate ) {
        for ( int i = 0; i < 2 * n; i += 2 ) {
            fout << ( comp[i] < comp[i ^ 1] ) << ' ';
        }
    } else {
        fout << -1;
    }
    return 0;
}
