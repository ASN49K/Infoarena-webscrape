#include <bits/stdc++.h>
#define Nmax 100002
using namespace std;

ifstream f("2sat.in");
ofstream g("2sat.out");

int n,m,a,b;
bool uz[2*Nmax],viz[2*Nmax];
vector<int> v[2*Nmax],v2[2*Nmax],H;
vector<vector<int> > C;

void dfs(int nod){
    uz[nod] = 1;
    for (auto it : v[nod]) if (!uz[it]) dfs(it);
    H.push_back(nod);
}

void dfs2(int nod){
    if (viz[nod]) g << "-1\n", exit(0);
    uz[nod] = 0; viz[nod ^ 1] = 1;
    for (auto it : v2[nod]) if (uz[it]) dfs2(it);
}

void add(int a,int b){
    a = (a < 0 ? -a * 2 - 1 : a * 2 - 2);
    b = (b < 0 ? -b * 2 - 1 : b * 2 - 2);
    v[a^1].push_back(b);
    v[b^1].push_back(a);
    v2[b].push_back(a^1);
    v2[a].push_back(b^1);
}

int main()
{
    ios::sync_with_stdio(false);
    f >> n >> m;
    for (int i=1;i<=m;i++){
        f >> a >> b;
        add(a,b);
    }

    for (int i=0;i<2*n;i++) if (!uz[i]) dfs(i);
    for (auto it = H.rbegin(); it != H.rend(); it++)
        if (uz[*it] && uz[(*it)^1]) dfs2(*it);

    for (int i=0;i<n;i++) g << viz[i*2] << ' ';

    return 0;
}
