#include <bits/stdc++.h>
#define NMAX 200//200
#define MOD 20050000
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
int disc[NMAX], low[NMAX], c[NMAX], g[NMAX];
bool use[NMAX];
vector<int>v[NMAX], elem[NMAX], cv[NMAX], cap;
deque<int> q;
int cost, ad, a,b,y,x,n,m;
void dfs(int node)
{
    ++cost;
    disc[node]=cost;
    low[node]=cost;
    use[node]=1;
    q.push_back(node);

    for(auto e:v[node])
        if(disc[e]==MOD)
        {
            dfs(e);
            low[node]=min(low[node], low[e]);
        }
        else if(use[e]==1)
            low[node]=min(low[node], low[e]);

    if(disc[node]==low[node])
    {
        cap.push_back(node);// lista componentelor
        while(!q.empty() && q.back()!=node)
        {
            c[q.back()]=node;
            elem[node].push_back(q.back());//componenta new are elementele astea
            use[q.back()]=0;
            q.pop_back();
        }
        c[node]=node;
        elem[node].push_back(node);
        use[node]=0;
        q.pop_back();
    }
}
void topsort()
{
    while(!q.empty())
    {
        x=q.front();
        q.pop_front();
        for(auto i:cv[x])//comvecine pt com x
        {
            --g[i];
            c[i]=max(c[x], c[i]);
            if(g[i]==0)
            {
                for(auto j:elem[i])
                    if(j<=n)
                    {
                        c[j]=c[i];
                        c[j+ad]=-c[i];
                    }
                    else
                    {
                        c[j]=c[i];
                        c[j-ad]=-c[i];
                    }
                q.push_back(i);
            }
        }
    }
}
int main()
{
    fin>>n>>m;
    ad=n+1;
    for(int i=1;i<=m;++i)
    {
        fin>>a>>b;
        if(a<0)
        {
            x=-a;//inv
            a=-a+ad;
        } else x=a+ad;
        if(b<0)
        {
            y=-b;
            b=-b+ad;
        }else y=b+ad;
        v[x].push_back(b);
        v[y].push_back(a);
    }

//    for(int i=1;i<=n+ad;++i)
//    {
//        cout<<i<<"  ";
//        for(auto j:v[i])
//            cout<<j<<" ";
//        cout<<'\n';
//    }cout<<'\n';


    for(int i=1;i<=n+ad;++i)
    {
        low[i]=MOD;
        disc[i]=MOD;
    }

    for(int i=1;i<=n+ad;++i)
        if(disc[i]==MOD)
            dfs(i);

//            cout<<'\n';
//    for(int i=1;i<=n;++i)
//        cout<<disc[i]<<" ";
//    cout<<'\n';
//    for(int i=ad+1;i<=n+ad;++i)
//        cout<<disc[i]<<" ";
//    cout<<'\n' <<'\n';
//
//    for(int i=1;i<=n;++i)
//        cout<<low[i]<<" ";
//    cout<<'\n';
//    for(int i=ad+1;i<=n+ad;++i)
//        cout<<low[i]<<" ";
//    for(int i=1;i<=n+ad;++i)
//        cout<<c[i]<< " ";

    for(int i=1;i<=n;++i)
        if(c[i]==c[i+ad])
        {
            fout<<-1;
            return 0;
        }

    for(auto i:cap)//prin componente
        for(auto j:elem[i])//prin elem componentei
            for(auto k:v[j])//care s vecinii
                if(c[k]!=i)
                    cv[i].push_back(c[k]);//componenta i are vecin componenta

    for(auto i:cap)
        for(auto j:cv[i])//grad int
            g[j]++;

    for(int i=1;i<=n+ad;++i)//reciclez c-ul si il pregatesc pt a pune ans ul in el
        c[i]=-1;

    q.clear();
    for(auto i:cap)
        if(g[i]==0)
        {
            q.push_back(i);
            for(auto j:elem[i])
            {
                c[j]=-1;//-1 e 0, 1 e 1
                c[-j]=1;
            }
        }

    topsort();
    for(int i=1;i<=n;++i)
        if(c[i]==-1)
            fout<<0<<" ";
        else
            fout<<1<<" ";
    return 0;
}
