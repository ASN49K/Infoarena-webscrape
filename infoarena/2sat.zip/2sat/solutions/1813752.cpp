#include <bits/stdc++.h>

using namespace std;

const int MAXN = 2e5;

int n, impossible;
vector <int> g[MAXN + 1], gt[MAXN + 1], srt;
int val[MAXN + 1], seen[MAXN + 1];

inline int non(int node) {
  if (node <= n)
    return node + n;
  return node - n;
}

void dfs(int node) {
  seen[node] = 1;
  for (auto it : g[node])
    if (seen[it] == 0)
      dfs(it);
  srt.push_back(node);
}

void rev_dfs(int node) {
  if (val[node])
    impossible = 1;
  seen[node] = seen[non(node)] = 0;
  val[non(node)] = 1;
  for (auto it : gt[node])
    if (seen[it])
      rev_dfs(it);
}

int main()
{
    int m, x, y;
    ifstream fin("2sat.in");
    fin >> n >> m;
    for (int i = 0; i < m; ++i) {
      fin >> x >> y;
      if (x < 0)
        x = non(-x);
      if (y < 0)
        y = non(-y);
      g[non(x)].push_back(y);
      g[non(y)].push_back(x);
      gt[y].push_back(non(x));
      gt[x].push_back(non(y));
    }
    fin.close();
    for (int i = 1; i <= 2 * n; ++i)
      if (seen[i] == 0)
        dfs(i);
    for (int i = srt.size() - 1; i >= 0; --i)
      if (seen[srt[i]])
        rev_dfs(srt[i]);
    ofstream fout("2sat.out");
    if (impossible)
      fout << "-1";
    else
      for (int i = 1; i <= n; ++i)
        fout << val[i] << " ";
    fout << '\n';
    fout.close();
    return 0;
}
