#include <bits/stdc++.h>
#define maxN 100002
using namespace std;

FILE *fin = freopen("2sat.in", "r", stdin);
FILE *fout = freopen("2sat.out", "w", stdout);

int n;
vector < int > V[2][2 * maxN];

bool vis[maxN * 2];
int ts[maxN];

bool isSol, ans[maxN * 2];

int Not(int x)
{
    if (x <= n)
        return x + n;
    return x - n;
}
void AddEdge(int x, int y)
{
    V[0][Not(x)].push_back(y);
    V[1][y].push_back(Not(x));
    V[0][Not(y)].push_back(x);
    V[1][x].push_back(Not(y));
}
void dfs(int ty, int u)
{
    vis[u] = !ty;
    if (ty && ans[u])
    {
        isSol = false;
        return ;
    }
    if (ty)
        ans[Not(u)] = true;
    for (int v : V[ty][u])
        if (vis[v] == ty)
            dfs(ty, v);
    if (!ty)
        ts[++ ts[0]] = u;
}

int main()
{
    int m;
    scanf("%d%d", &n, &m);
    while (m --)
    {
        int x, y;
        scanf("%d%d", &x, &y);
        if (x < 0)
            x = Not(-x);
        if (y < 0)
            y = Not(-y);
        AddEdge(x, y);
    }
    isSol = true;
    for (int i = 1; i <= 2 * n; ++ i)
        if (!vis[i])
            dfs(0, i);

    for (int i = ts[0]; i > 0; -- i)
        if (vis[ts[i]] && vis[Not(ts[i])])
            dfs(1, ts[i]);

    if (isSol)
        for (int i = 1; i <= n; ++ i)
            printf("%d ", ans[i]);
    else
        printf("-1\n");
    return 0;
}
