/// a.cpp

# include <stdio.h>
# include <bits/stdc++.h>
using namespace std;
const pair < int , int > DD[] = {{1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1},{0,-1},{1,-1}};
# define fi cin
# define fo cout
# define x first
# define y second
# define ll long long
# define IOS ios_base :: sync_with_stdio(0);cin.tie(0)
# define p(v) cerr << #v << " = " << v << '\n'
# define p2(v) cerr << #v << " = " << (complex < __typeof(v.x) > (v.x,v.y)) << '\n'
# define vi vector < int >
# define vl vector < ll >
# define pll pair < ll , ll >
# define pii pair < int , int >
# define mp make_pair
# define db long double
# define fail puts("-1")
# define yes puts("YES")
# define no puts("NO")
# define PP puts("Possible")
# define II puts("Impossible")
# define vii vector < pii >
# define vll vector < ll >
# define pb push_back
# define pdd pair < db , db >
# define CF
template < class T > T smin(T &a,T b) {if (a > b) a = b;return a;}
template < class T > T smax(T &a,T b) {if (a < b) a = b;return a;}
int main(void)
{
    #ifdef CF
    freopen("2sat.in","r",stdin);
    freopen("2sat.out","w",stdout);
    #endif // CF
    srand(time(0));
    fo << fixed << setprecision(7);
    cerr << fixed << setprecision(7);
    int n,m;
    fi>>n>>m;
    static int ans[1 << 20];
    static vi s[1 << 20];
    static vi v[1 << 20];
    while (m --)
    {
        int a,b;
        fi>>a>>b;
        if (a < 0)
            a = (-1 - a) * 2 + 1;
        else
            a = (a - 1) * 2;
        if (b < 0)
            b = (-1 - b) * 2 + 1;
        else
            b = (b - 1) * 2;
        v[a ^ 1].pb(b);
        v[b ^ 1].pb(a);
        s[b].pb(a ^ 1);
        s[a].pb(b ^ 1);
    }
    static int was[1 << 20];
    vi order;
    function < void(int) > dfs1 = [&](int node)
    {
        was[node] = 1;
        for (auto it : v[node])
            if (!was[it])
                dfs1(it);
        order.pb(node);
    };
    for (int i = 0;i < n + n;++i)
        if (!was[i])
            dfs1(i);
    for (int i = 0;i < n + n;++i)
        was[i] = 0;
    function < void(int) > dfs2 = [&](int node)
    {
        was[node] = 1;
        ans[node ^ 1] = 1;
        for (auto it : s[node])
            if (!was[it])
                dfs2(it);
    };
    reverse(order.begin(),order.end());
    for (auto it : order)
        if (!was[it] && !was[it ^ 1])
            dfs2(it);
    for (int i = 0;i < n + n;++i)
        if (ans[i] && ans[i ^ 1])
            return puts("-1") * 0;
    for (int i = 0;i < n;++i)
        fo << ans[i << 1] << " \n"[i == n - 1];
    cerr << "Time elapsed :" << clock() * 1000.0 / CLOCKS_PER_SEC << " ms" << '\n';
    return 0;
}
