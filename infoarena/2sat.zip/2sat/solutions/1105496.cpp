#include <cstdio>
#include <cstdlib>
#include <vector>
#include <algorithm>
using namespace std;

const int NMAX = 100010;

int N, M, X, Y, TopSort[2 * NMAX], Val[2 * NMAX];
bool Used[2 * NMAX], Sol = 1;
vector<int> G[2 * NMAX], GT[2 * NMAX];

int Neg(int X)
{
    if(X <= N) return X + N;
    else return X - N;
}

void DFP(int Node)
{
    Used[Node] = 1;
    for(vector<int> :: iterator it = G[Node].begin(); it != G[Node].end(); ++ it)
        if(!Used[*it])
            DFP(*it);
    TopSort[ ++ TopSort[0] ] = Node;
}

void DFM(int Node)
{
    if(Val[Node] == 1) Sol = 0;
    Val[Neg(Node)] = 1;

    Used[Node] = 0;
    for(vector<int> :: iterator it = GT[Node].begin(); it != GT[Node].end(); ++ it)
        if(Used[*it])
            DFM(*it);
}

int main()
{
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);

    scanf("%i %i", &N, &M);
    for(int i = 1; i <= M; ++ i)
    {
        scanf("%i %i", &X, &Y);
        if(X < 0) X = -X + N;
        if(Y < 0) Y = -Y + N;

        G[Neg(Y)].push_back(X);
        GT[X].push_back(Neg(Y));
        G[Neg(X)].push_back(Y);
        GT[Y].push_back(Neg(X));
    }

    for(int i = 1; i <= 2 * N; ++ i)
        if(!Used[i])
            DFP(i);

    reverse(TopSort + 1, TopSort + TopSort[0] + 1);

    for(int i = 1; i <= 2 * N; ++ i)
        if(Used[ TopSort[i] ] && Used[ Neg(TopSort[i]) ])
            DFM(TopSort[i]);

    if(Sol == 0) printf("-1\n");
    else for(int i = 1; i <= N; ++ i) printf("%i ", Val[i]);
}
