#include <bits/stdc++.h>
#define maxN 200002
using namespace std;

FILE *fin = freopen("2sat.in", "r", stdin);
FILE *fout = freopen("2sat.out", "w", stdout);

int n, m, ts[maxN];

bool vis[maxN], ans[maxN];
vector < int > V[maxN], T[maxN];

bool ok;

int Not(int x)
{
    if (x <= n)
        return x + n;
    return x - n;
}

void dfs(int x)
{
    int nod;
    vis[x] = 1;
    for (int i = 0; i < V[x].size(); ++ i)
        if (!vis[nod = V[x][i]])
            dfs(nod);
    ts[++ ts[0]] = x;
}

void dfsT(int x)
{
    int nod;
    vis[x] = 0;
    if (ans[x])
    {
        ok = 0;
        return ;
    }
    ans[Not(x)] = 1;
    for (int i = 0; i < T[x].size(); ++ i)
        if (vis[nod = T[x][i]])
            dfsT(nod);
}

void read()
{
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= m; ++ i)
    {
        int x, y;
        scanf("%d %d", &x, &y);
        if (x < 0)
            x = Not(-x);
        if (y < 0)
            y = Not(-y);

        V[Not(x)].push_back(y);
        V[Not(y)].push_back(x);
        T[y].push_back(Not(x));
        T[x].push_back(Not(y));
    }
}

void solve()
{
    ok = 1;
    for (int i = 1; i <= 2 * n; ++ i)
        if (!vis[i])
            dfs(i);

    for (int i = ts[0]; i > 0; -- i)
        if (vis[ts[i]] && vis[Not(ts[i])])
            dfsT(ts[i]);
}

void write()
{
    if (ok)
        for (int i = 1; i <= n; ++ i)
            printf("%d ", ans[i]);
    else
        printf("-1\n");
}

int main()
{
    read();
    solve();
    write();
    return 0;
}
