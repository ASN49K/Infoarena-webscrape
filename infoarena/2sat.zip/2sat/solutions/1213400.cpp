#include <fstream>
#include <vector>
#include <stack>
#define DIMN 200005

using namespace std;

ifstream f("2sat.in");
ofstream g("2sat.out");

vector<int> L[DIMN];

stack<int> s;

int n,m,nivel,x,y,soll;

int Low[DIMN], Niv[DIMN], sol[DIMN];

bool ok[DIMN];

void DFS (int nod) {
    Niv[nod] = Low[nod] = ++nivel;
    s.push(nod);
    for (vector<int>::iterator it=L[nod].begin(); it!=L[nod].end(); ++it) {
        if (Niv[*it] == 0)
            DFS (*it);
        if (Niv[*it] > 0)
            Low[nod] = min(Low[nod], Low[*it]);
    }
    if (Low[nod] == Niv[nod]) {
        int nnod;
        for (int i=1; i<=2*n; ++i)
            ok[i] = 0;
        do {
            nnod = s.top();
            s.pop();
            Niv[nnod] *= -1;
            if ((nnod<=n && ok[nnod+n]) || (nnod>n && ok[nnod-n]))
                soll = -1;
            ok[nnod] = 1;
            if (sol[nnod] == 0) {
                sol[nnod] = 1;
                if (nnod <= n)
                    sol[nnod+n] = -1;
                else
                    sol[nnod-n] = -1;
            }
        } while (nnod!=nod);
    }
}

int main() {
    f >> n >> m;
    for (int i=1; i<=m; ++i) {
        f >> x >> y;
        if (x > 0) {
            if (y > 0) {
                L[x+n].push_back(y);
                L[y+n].push_back(x);
            }
            else {
                L[x+n].push_back(-y+n);
                L[-y].push_back(x);
            }
        }
        else {
            if (y > 0) {
                L[-x].push_back(y);
                L[y+n].push_back(-x+n);
            }
            else {
                L[-x].push_back(-y+n);
                L[-y].push_back(-x+n);
            }
        }
    }
    for (int i=1; i<=n; ++i)
        if (Niv[i] == 0)
            DFS (i);
    if (soll == -1)
        g << soll << "\n";
    else
        for (int i=1; i<=n; ++i)
            g << (sol[i] == -1 ? 0 : 1) << " ";
    return 0;
}
