// Author: Tanasescu Andrei-Rares
/*
     █████╗  ██████╗ ████████╗
    ██╔══██╗ ██╔══██╗╚══██╔══╝
    ███████║ ██████╔╝   ██║   
    ██╔══██║ ██╔══██╗   ██║   
    ██║  ██║ ██║  ██║   ██║   
    ╚═╝  ╚═╝ ╚═╝  ╚═╝   ╚═╝   
*/
#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <map>
#include <unordered_map>
#include <set>
#include <unordered_set>
#include <queue>
#include <stack>
#include <deque>
#include <iomanip>
#include <vector>
#include <cassert>

#pragma GCC optimize("O3")

#define fi first
#define se second
#define pb push_back
#define pf push_front

using namespace std;

ifstream fin ("2sat.in");
ofstream fout ("2sat.out");

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;

const ll Nmax=1e5, inf=1e9+5;

int n, m;
bool vis[2*Nmax+5];
int crt;
int clr[2*Nmax+5], ord[2*Nmax+5], sol[2*Nmax+5];
vector<int> ad[2*Nmax+5], adt[2*Nmax+5], adc[2*Nmax+5];
vector<int> ctc[2*Nmax+5];
int gr[2*Nmax+5];
vector<int> ts;

void dfs1(int node){
    vis[node]=1;
    for (auto it:ad[node]){
        if (!vis[it])
            dfs1(it);
    }
    ord[crt++]=node;
}
void dfs2(int node){
    clr[node]=crt;
    ctc[crt].pb(node);
    for (auto it:adt[node])
        if (clr[it]==0)
            dfs2(it);
}
inline void Kosaraju(){
    for (int i=0; i<=2*n; i++)
        if (!vis[i])
            dfs1(i);
    
    crt=0;
    for (int i=2*n; i>=0; i--){
        if (clr[ord[i]]==0){
            crt++;
            dfs2(ord[i]);
        }
    }
}

inline void topological_sort(){
    for (int i=1; i<=crt; i++)
        if (gr[i]==0)
            ts.pb(i);

    for (int i=0; i<ts.size(); i++){
        int node=ts[i];
        for (auto it:adc[node]){
            gr[it]--;
            if (gr[it]==0)
                ts.pb(it);
        }
    }
}

inline int conj(int val){
    return 2*n-val;
}

int main()
{    
    fin>>n>>m;

    for (int i=0; i<=2*n; i++)
        sol[i]=2; // undifined

    for (int i=0; i<m; i++){
        int a, b;
        fin>>a>>b;
        ad[-a+n].pb(b+n);
        ad[-b+n].pb(a+n);

        adt[a+n].pb(-b+n);
        adt[b+n].pb(-a+n);
    }

    Kosaraju();

    for (int i=0; i<=2*n; i++)
        for (auto it:ad[i])
            if (clr[i]!=clr[it]){
                adc[clr[i]].pb(clr[it]);
                gr[clr[it]]++;
            }
    
    topological_sort();
    
    for (int i=0; i<crt; i++){
        int c=ts[i];

        int crtsol=2;
        for (auto it:ctc[c])
            if (sol[conj(it)]!=2){
                crtsol=!sol[conj(it)];
                break;
            }
        
        if (crtsol==2)
            crtsol=0;
        
        for (auto it:ctc[c])
            sol[it]=crtsol;
    }

    bool ok=1;
    for (int i=0; i<=2*n; i++)
        if (i!=n && sol[i]==sol[conj(i)])
            ok=0;
        
    if (!ok)
        fout<<-1;
    else{
        for (int i=1; i<=n; i++)
            fout<<sol[i+n]<<' ';
    }


    return 0;
}
