#include <fstream>
#include <iostream>
#include <vector>
#include <stack>
#define NMAX 100005
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
int N, M;
vector<vector<int>> gr, grt;
stack<int> L;
int val[2 * NMAX];
bool d[2 * NMAX], exista = true;
int opus(int a) {
    if (a > N) {
        return a - N;
    }
    return a + N;
}
void read() {
    int x, y;
    fin >> N >> M;
    gr.resize(2 * N + 1);
    grt.resize(2 * N + 1);
    for (int i = 0; i < M; ++i) {
        fin >> x >> y;
        if (x < 0) {
            x = N - x;
        }
        if (y < 0) {
            y = N - y;
        }
        gr[opus(x)].push_back(y); grt[y].push_back(opus(x));
        gr[opus(y)].push_back(x); grt[x].push_back(opus(y));
    }
}
void DFS(int node) {
    d[node] = true;
    for (int i : gr[node]) {
        if (d[i] == false) {
            DFS(i);
        }
    }
    L.push(node);
}
void DFST(int node) {
    d[node] = true;
    if (val[node] == true) {
        exista = false;
    }
    val[opus(node)] = true;
    for (int i : grt[node]) {
        if (d[i] == false) {
            DFST(i);
        }
    }
}
int main()
{
    read();
    for (int i = 1; i <= 2 * N; ++i) {
        if (d[i] == false) {
            DFS(i);
        }
    }
    for (int i = 0; i <= 2 * N; ++i) {
        d[i] = false;
    }
    while (!L.empty()) {
        int node = L.top();
        L.pop();
        if (!d[node] && !d[opus(node)]) {
            DFST(node);
        }
    }
    if (!exista) {
        fout << "-1\n";
        return 0;
    }
    for (int i = 1; i <= N; ++i) {
        fout << val[i] << " ";
    }
    return 0;
}
