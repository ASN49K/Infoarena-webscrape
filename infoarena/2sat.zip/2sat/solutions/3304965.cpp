#include <unordered_map>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>

using namespace std;

const string txt = "2sat";
const int nmax = 2e5 + 5;

ifstream f(txt + ".in");
ofstream g(txt + ".out");

int n, m, k;
unordered_map< int, vector<int> > v[5];
unordered_map<int, int> c, fr;
vector<int> aux;

static void dfs(int nod, int tip)
{
    fr[nod] = tip + 1;
    for (auto x : v[tip][nod])
        if (fr[x] != tip + 1)
            dfs(x, tip);

    if (!tip) aux.push_back(nod);
    else c[nod] = k;
}

int main()
{
    f >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y; f >> x >> y;
        v[0][-x].push_back(y);
        v[0][-y].push_back(x);

        v[1][x].push_back(-y);
        v[1][y].push_back(-x);
    }

    for(int i = 1; i <= n; i ++)
        if(!fr[i])
            dfs(i, 0);
    
    for (int i = aux.size() - 1; i >= 0; i--)
        if (fr[aux[i]] != 2)
            k++, dfs(aux[i], 1);

    int oki = 1;
    for (int i = 1; i <= n; i++)
        if (c[i] == c[-i]) oki = 0;

    if (!oki) {
        g << -1;
        return 0;
    }

    for (int i = 1; i <= n; i++)
        g << (c[i] > c[-i]) << " ";
    return 0;
}