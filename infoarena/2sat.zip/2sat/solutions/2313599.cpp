#include<fstream>
#include<vector>
#define N 200001
#define pb push_back
#define x first
#define y second
using namespace std;
ifstream f("2sat.in");
ofstream g("2sat.out");
int n,m,v[N],a,b,d,r[N],s[N],o,i;
pair<int,int> z[N];
vector<int> h[N];
void D(int i)
{
    v[i]=1;
    for(auto j:h[i])
        if(!v[j])
            D(j);
    s[++o]=i-n;
}
int main()
{
    f>>n>>m;
    for(i=1;i<=m;i++)
        f>>a>>b,z[i].x=a+n,z[i].y=b+n,h[n-a].pb(b+n),h[n-b].pb(a+n);
    for(i=0;i<=2*n;i++)
        if(!v[i])
            D(i);
    for(i=o;i;i--)
        if(!r[s[i]+n]&&!r[n-s[i]])
            r[n-st[i]]=1;
    for(i=1;i<=m;i++)
        if(!r[z[i].x]&&!r[z[i].y])
        {
            g<<-1;
            return 0;
        }
    for(i=1;i<=n;i++)
        g<<r[i+n]<<' ';
}
