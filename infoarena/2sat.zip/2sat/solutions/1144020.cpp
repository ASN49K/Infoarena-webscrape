#include<fstream>
#include<iostream>
#include<vector>
#define non(m) ((m)<=N?(m+N):(m-N))
using namespace std;

vector <int> v[200100],transpus[200100];
int N,M,K,Sortat[200100];
bool Marcat[200100],ok,viz[200100];

void citire() {

    ifstream in("2sat.in");
    int i,x,y;
    in>>N>>M;
    for(i=1;i<=M;i++) {
        in>>x>>y;

        if(x<0)
            x=N-x;
        if(y<0)
            y=N-y;

        v[non(x)].push_back(y);
        v[non(y)].push_back(x);
        transpus[y].push_back(non(x));
        transpus[x].push_back(non(y));
    }
    in.close();

}

void SortareTopo(int nod) {

    int vecin,i;
    viz[nod]=1;
    for(i=0;i<v[nod].size();++i) {
        vecin=v[nod][i];
        if(!viz[vecin])
            SortareTopo(vecin);
    }
    Sortat[++K]=nod;
}

void dfs(int nod ) {

    int i,vecin;
    if(Marcat[nod]){
        ok=1;
        return;
    }
    viz[nod]=0;
    Marcat[non(nod)]=1;

    for(i=0;i<transpus[nod].size();++i) {
        vecin=transpus[nod][i];
        if(viz[vecin])
            dfs(vecin);
    }
}

void solve() {

    int i;
    for(i=1;i<=N*2;i++)
        if(!viz[i])
            SortareTopo(i);

    for(i=N*2;ok==0 && i>=1;i--)
        if(viz[Sortat[i]]&&viz[non(Sortat[i])])
            dfs(Sortat[i]);

}

void afisare() {

    ofstream out("2sat.out");
    int i;
    if(ok==1)
        out<<"-1";
    else
        for(i=1;i<=N;i++)
            out<<Marcat[i]<<' ';
    out<<'\n';
    out.close();

}

int main() {

    citire();
    solve();
    afisare();
    return 0;

}
