#include <iostream>
#include <vector>
#include <map>
#include <stack>
#include <fstream>

using namespace std;

#define CAP 100001

ofstream out("2sat.out");
ifstream in("2sat.in");

int n, m;

map<int, vector<int> > graph;

map<int, bool> visited;

map<int, int> boss;

map<int, bool> isStack;

map<int, int> tm;

int t = 0;

stack<int> s;

int paint = 0;

map<int, int> componentID;

int spot = 0;

map<int, int> topoSpot;

map<int, int> sol;

void dfsScc(int v) {
    visited[v] = true;

    t++;

    boss[v] = t;

    tm[v] = t;

    isStack[v] = true;

    s.push(v);

    for (int i = 0; i < graph[v].size(); i++) {
        if (!visited[graph[v][i]]) {
            dfsScc(graph[v][i]);
        }

        if (isStack[graph[v][i]] && boss[graph[v][i]] < boss[v]) {
            boss[v] = boss[graph[v][i]];
        }
    }

    if (tm[v] == boss[v]) {
        while (s.top() != v) {
            int curr = s.top();

            s.pop();

            isStack[curr] = false;

            componentID[curr] = paint;
        }

        if (s.top() == v) {
            isStack[s.top()] = false;

            componentID[s.top()] = paint;

            s.pop();
        }
    }
}

bool isBad() {
    for (int i = 1; i <= n; i++) {
        if (componentID[-1 * i] == componentID[i]) {
            return true;
        }
    }

    return false;
}

void topoSort(int v) {
    visited[v] = true;

    for (int i = 0; i < graph[v].size(); i++) {
        if (!visited[graph[v][i]]) {
            topoSort(graph[v][i]);
        }
    }

    topoSpot[v] = spot;

    spot++;
}

int main() {
    in >> n >> m;

    for (int i = 1; i <= m; i++) {
        int u, v;

        in >> u >> v;

        graph[-1 * u].push_back(v);

        graph[-1 * v].push_back(u);
    }

    for (int i = -1 * n; i <= n; i++) {
        if (i != 0 && !visited[i]) {
            dfsScc(i);

            paint++;
        }
    }

    if (isBad()) {
        out << -1 << '\n';

        return 0;
    }

    for (int i = -1 * CAP; i <= CAP; i++) {
        visited[i] = false;
    }

    for (int i = -1 * n; i <= n; i++) {
        if (i != 0 && !visited[i]) {
            topoSort(i);
        }
    }

    for (int i = 1; i <= n; i++) {
        if (topoSpot[-1 * i] < topoSpot[i]) {
            sol[i] = 0;
        }

        else {
            sol[i] = 1;
        }
    }

    for (int i = 1; i <= n; i++) {
        cout << sol[i] << " ";
    }

    cout << '\n';

    return 0;
}