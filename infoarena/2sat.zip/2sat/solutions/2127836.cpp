#include <fstream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

ifstream in("2sat.in");
ofstream out("2sat.out");

const int NMAX = 200000;

bool viz[NMAX+2];
vector <int> G[NMAX+2], GP[NMAX+2], ord;
int ind_ctc = 0;
int N, M;
int ctc[NMAX+2];

int normal( int x ) {
    if( x < 0 ) return -x + N;
    return x;
}

int negat( int x ) {
    if( x <= N ) return x + N;
    return x - N;
}

void Dfs_Plus( int nod ) {
    viz[nod] = 1;

    for( int i = 0;  i < (int)G[nod].size();  ++i ) {
        int x = G[nod][i];
        if( !viz[x] )  {
            Dfs_Plus( x );
        }
    }

    ord.push_back( nod );
}

void Dfs_Minus( int nod ) {
    viz[nod] = 1;
    ctc[nod] = ind_ctc;

    for( int i = 0;  i < (int)GP[nod].size();  ++i ) {
        int x = GP[nod][i];
        if( !viz[x] ) {
            Dfs_Minus( x );
        }
    }
}

int main() {
    in >> N >> M;
    for( int i = 1;  i <= M;  ++i ) {
        int x,y;
        in >> x >> y;
        x = normal(x);
        y = normal(y);
        G[ negat(x) ].push_back( y );
        G[ negat(y) ].push_back( x );

        GP[ y ].push_back( negat(x) );
        GP[ x ].push_back( negat(y) );
    }

    for( int i = 1;  i <= 2*N;  ++i ) {
        if( !viz[i] )  Dfs_Plus(i);
    }
    memset( viz, 0, sizeof(viz) );
    for( int i = (int)ord.size() - 1;  i >= 0;  --i ) {
        if( !viz[ ord[i] ] )  {
            ++ind_ctc;

            Dfs_Minus( ord[i] );
        }
    }

    bool ok = 1;
    for( int i = 1;  i <= N;  ++i ) {
        if( ctc[i] == ctc[i + N] ) ok = 0;
    }
    if( !ok ) {
        out << "-1\n";
        return 0;
    }

    for( int i = 1;  i <= N;  ++i ) {
        if( ctc[i] < ctc[i + N] )  out << "0 ";
        else out << "1 ";
    }
    out << '\n';

    return 0;
}
