#include <iostream>
#include <vector>
#include <stack>
#include <fstream>
using namespace std;
long long n, m, l[400000], index[400000], br, br1;
vector <int> sused[400000], comp[400000];
bool inStack[400000], otg[400000], imameOtg[400000];
stack <int> st;
void dfs(int x){
    inStack[x]=true;
    st.push(x);
    index[x]=br;
    l[x]=br;
    br++;
    for(int i=0;i<sused[x].size();i++){
        int nov=sused[x][i];
        if(index[nov]==-1){
            dfs(nov);
            l[x]=min(l[nov], l[x]);
        }else if(inStack[nov]){
            l[x]=min(l[nov], l[x]);
        }
    }
    if(l[x]==index[x]){
        bool j=false;
        while(!st.empty() and !j){
            if(st.top()==x){
                j=true;
            }
            comp[br1].push_back(st.top());
            inStack[st.top()]=false;
            st.pop();
        }
        br1++;
    }
}
int main(){
ofstream fileout;
fileout.open("2sat.out");
ifstream filein;
filein.open("2sat.in");
filein>>n>>m;
for(int i=0;i<m;i++){
    int x, y, minusX, minusY, X, Y;
    filein>>x>>y;
    if(-x<0){
        minusX=x+200000;
    }else{
        minusX=-x;
    }
    if(x<0){
        X=-x+200000;
    }else{
        X=x;
    }
    if(-y<0){
        minusY=y+200000;
    }else{
        minusY=-y;
    }
    if(y<0){
        Y=-y+200000;
    }else{
        Y=y;
    }
    sused[minusX].push_back(Y);
    sused[minusY].push_back(X);
}
for(int i=200001;i<=200000+n;i++){
    index[i]=-1;
    l[i]=-1;
}
for(int i=1;i<=n;i++){
    index[i]=-1;
    l[i]=-1;
}
for(int i=200001;i<=200000+n;i++){
    if(index[i]==-1){
        dfs(i);
    }
}
for(int i=1;i<=n;i++){
    if(index[i]==-1){
        dfs(i);
    }
}
//cout<<br1<<endl;
bool naFsme=false;
for(int i=0;i<br1;i++){
    for(int j=0;j<comp[i].size();j++){
        //cout<<comp[i][j]<<" ";
        if(comp[i][j]<=200000){
            if(imameOtg[comp[i][j]+200000]=true){
                imameOtg[comp[i][j]]=true;
                otg[comp[i][j]]=!(otg[comp[i][j]+200000]);
                if(!otg[comp[i][j]] and !naFsme){
                    naFsme=true;
                    if(j!=0){
                        fileout<<"-1";
                        return 0;
                    }
                }
                if(otg[comp[i][j]] and naFsme){
                    fileout<<"-1";
                    return 0;
                }
            }else{
                if(!naFsme){
                    imameOtg[comp[i][j]]=true;
                    otg[comp[i][j]]=true;
                }else{
                    imameOtg[comp[i][j]]=true;
                    otg[comp[i][j]]=false;
                }
            }
        }
        if(comp[i][j]>200000){
            if(imameOtg[comp[i][j]-200000]=true){
                imameOtg[comp[i][j]]=true;
                otg[comp[i][j]]=!(otg[comp[i][j]-200000]);
                if(!otg[comp[i][j]] and !naFsme){
                    naFsme=true;
                    if(j!=0){
                        fileout<<"-1";
                        return 0;
                    }
                }
                if(otg[comp[i][j]] and naFsme){
                    fileout<<"-1";
                    return 0;
                }
            }else{
                if(!naFsme){
                    imameOtg[comp[i][j]]=true;
                    otg[comp[i][j]]=true;
                }else{
                    imameOtg[comp[i][j]]=true;
                    otg[comp[i][j]]=false;
                }
            }
        }
    }
    //cout<<endl;
}
for(int i=1;i<=n;i++){
    fileout<<otg[i]<<" ";
}
return 0;
}
