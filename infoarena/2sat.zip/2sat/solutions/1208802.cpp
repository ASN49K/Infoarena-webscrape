#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
using namespace std;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

const int MAXN = 100005;
vector<int> G[2 * MAXN], actual_component;
vector< vector<int> > Components;
stack<int> S;
int N, M, indexCount, indx[2 * MAXN], level[2 * MAXN];
bool in_stack[2 * MAXN], TruthValue[MAXN];

inline int ind(int x) {//converteste indicele nodului
    return x < 0 ? N - x : x;
}

inline int non(int x) {//indicele nodului convertit dupa ce a fost negat
    return x > N ? x - N : x + N;
}

void Read() {
    fin >> N >> M;
    int a, b;
    for (int i = 0; i < M; ++i) {
        fin >> a >> b;
        //x v y <=> (~x -> y) ^ (~y -> x)
        G[ non(ind(a)) ].push_back( ind(b) );
        G[ non(ind(b)) ].push_back( ind(a) );
    }
}

void Tarjan(int father) {
    indx[father] = level[father] = indexCount++;
    S.push(father); in_stack[father] = true;
    vector<int>::iterator it;
    for (it = G[father].begin(); it != G[father].end(); ++it) {
        if (indx[*it] == -1) {
            Tarjan(*it);
            level[father] = min(level[father], level[*it]);
        }else if (in_stack[*it]) {
            level[father] = min(level[father], level[*it]);
        }
    }
    if (indx[father] == level[father]) {
        actual_component.clear();
        int node;
        do {
            node = S.top();
            S.pop(); in_stack[node] = false;
            actual_component.push_back(node);
        }while (father != node);
        Components.push_back( actual_component );
    }
}

void Solve() {
    for (int i = 1; i <= 2 * N; ++i)
        indx[i] = -1;
    for (int i = 1; i <= 2 * N; ++i) {
        if (indx[i] == -1)
            Tarjan(i);
    }
    bool impossible = false;
    //check whether for any literal X
    //X and ~X are in the same strongly connected component;
    //if there is such a case, then it is impossible to solve
    for (int i = 1; i <= N; ++i) {
        if (level[i] == level[i + N])
            impossible = true;
    }
    if (impossible) {
        fout << "-1\n";
    }else {
        cerr << "Possible.\n";
        for (int i = Components.size() - 1; i >= 0; --i) {
            for (size_t j = 0; j < Components[i].size(); ++j) {
                if (not TruthValue[ Components[i][j] ] && not TruthValue[ non(Components[i][j]) ]) {
                    TruthValue[ Components[i][j] ] = false;
                    TruthValue[ non(Components[i][j]) ] = true;
                }
            }
        }
    }
}

void Write() {
    /*for (int i = 1; i <= 2 * N; ++i) {
        cerr << i << " are vecini pe: ";
        vector<int>::iterator it;
        for (it = G[i].begin(); it != G[i].end(); ++it) {
            cerr << *it << ' ';
        }cerr << '\n';
    }
    cout << Components.size() << '\n';
    for (size_t i = 0; i < Components.size(); ++i) {
        for (size_t j = 0; j < Components[i].size(); ++j) {
            cout << Components[i][j] << ' ';
        }
        cout << '\n';
    }*/
    //final written data
    for (int i = 1; i <= N; ++i)
        fout << TruthValue[i] << ' ';
    fout << '\n';
}

int main() {
    Read();
    Solve();
    Write();
    fin.close();
    fout.close();
    return 0;
}
