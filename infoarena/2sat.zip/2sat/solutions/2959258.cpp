#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

struct SAT2
{
    int n;
    int spec;
    int cur;
    int tp;
    vector<int> comp;
    vector<int> lowvalue;
    vector<bool> instack;
    vector<vector<int>> g;
    vector<int> stk;

    SAT2(int n, int spec) :
        n(n),
        spec(spec),
        comp(2 * n + 1 + spec, 0),
        lowvalue(2 * n + 1 + spec, 0),
        instack(2 * n + 1 + spec, 0),
        g(2 * n + 1 + spec),
        cur(0),
        tp(0)
    {
#ifdef ONPC
        cout << "salut SAT2!\n";
#endif // ONPC
    }

    void addEdge(int a, int b)
    {
        assert(1 <= a && a <= 2 * n + spec);
        assert(1 <= b & b <= 2 * n + spec);
        g[a].push_back(b);
    }

    void dfs(int a)
    {
        comp[a] = ++tp;
        lowvalue[a] = comp[a];
        stk.push_back(a);
        instack[a] = 1;
        for (auto &b : g[a])
        {
            if (lowvalue[b] == 0)
            {
                dfs(b);
            }
            if (instack[b])
            {
                lowvalue[a] = min(lowvalue[a], lowvalue[b]);
            }
        }
        if (lowvalue[a] == comp[a])
        {
            cur++;
            bool found = 0;
            while (!stk.empty())
            {
                int v = stk.back();
                stk.pop_back();
                instack[v] = 0;
                comp[v] = cur;
                if (v == a)
                {
                    found = 1;
                    break;
                }
            }
            assert(found);
        }
    }

    int inv(int x)
    {
        assert(1 <= x && x <= 2 * n);
        if (x <= n)
        {
            return x + n;
        }
        else
        {
            return x - n;
        }
    }
    bool solve()
    {

        for (int i = 1; i <= 2 * n + spec; i++)
        {
            if (lowvalue[i] == 0)
            {
                dfs(i);
            }
        }
        for (int i = 1; i <= n; i++)
        {
            if (comp[i] == comp[i + n])
            {
                return 0;
            }
        }
        return 1;
    }
};

signed main()
{
#ifdef ONPC
    freopen("input.txt", "r", stdin);
#endif // ONPC

#ifndef ONPC
    freopen ("2sat.in", "r", stdin);
    freopen ("2sat.out", "w", stdout);
#endif // ONPC



    int n, m;
    scanf("%d %d", &n, &m);


    SAT2 sat(n, 0);

    for (int i = 1; i <= m; i++)
    {
        int a, b;
        scanf("%d %d", &a, &b);

        if (a < 0) a = n - a;
        if (b < 0) b = n - b;

        assert(1 <= a && a <= 2 * n);
        assert(1 <= b && b <= 2 * n);

        sat.addEdge(sat.inv(a), b);
        sat.addEdge(sat.inv(b), a);

    }

    bool ok = sat.solve();
    if (!ok)
    {
        cout << "-1\n";
        return 0;
    }
    for (int i = 1; i <= n; i++)
    {
        cout << (sat.comp[i] < sat.comp[i + n]) << " ";
    }
    cout << "\n";
    return 0;
}
/**

**/
