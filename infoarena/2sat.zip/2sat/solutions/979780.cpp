#include<stdio.h>
#include<cstring>
#include<vector>
#include<stack>
#define pb push_back
#define maxn 100005
using namespace std;

int n,m,nrc,nr,mid;
int lev[maxn<<1],low[maxn<<1],sol[maxn];
int v[maxn<<1],ind[maxn<<1],used[maxn<<1];
vector <int> l[maxn<<1],comp[maxn<<1];
stack <int> s;

int neg(int x)
{
    if(x>n) x-=n;
    else x+=n;
    return x;
}

void read()
{
    int x,y;
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)
    {
        scanf("%d%d",&x,&y);
        if(x<0) x=-x,x+=n;
        if(y<0) y=-y,y+=n;
        l[neg(x)].pb(y);
        l[neg(y)].pb(x);
    }
}

void get_component(int k)
{
    nrc++;
    while(s.top()!=k)
    {
        ind[s.top()]=nrc;
        comp[nrc].pb(s.top());
        v[s.top()]=0;
        s.pop();
    }
    ind[s.top()]=nrc;
    comp[nrc].pb(s.top());
    v[s.top()]=0;
    s.pop();
}

void dfs(int k,int niv)
{
    s.push(k); v[k]=1; lev[k]=niv; low[k]=niv;
    for(unsigned int i=0;i<l[k].size();i++)
     if(!lev[l[k][i]])
     {
         dfs(l[k][i],niv+1);
         low[k]=min(low[k],low[l[k][i]]);
     }
     else
      if(v[l[k][i]]) low[k]=min(low[k],low[l[k][i]]);

    if(low[k]==niv) get_component(k);
}

void mark(int k)
{
    for(unsigned int i=0;i<comp[k].size();i++)
     if(comp[k][i]<=n) sol[comp[k][i]]=1;
}

void dfst(int k)
{
    v[k]=1;
    for(unsigned int i=0;i<comp[k].size();i++)
     for(unsigned int j=0;j<l[comp[k][i]].size();j++)
     if(!v[ ind[ l[comp[k][i]][j] ]] )
       dfst(ind[ l[comp[k][i]][j] ]);
    nr++; if(nr<=mid) mark(k);
}

void print()
{
    for(int i=1;i<=n;i++)
     printf("%d ",sol[i]);
}

void solve()
{
    for(int i=1;i<=2*n;i++)
     if(!lev[i])
         dfs(i,0);

    for(int i=1;i<=n;i++)
     if(ind[i]==ind[i+n]) {printf("-1"); return;}

    mid=nrc/2; if(nrc%2==1) mid++;
    memset(v,0,sizeof(v));
    for(int i=1;i<=nrc;i++)
     if(!v[i])
      dfst(i);

    print();
}

int main()
{
    freopen("2sat.in","r",stdin);
    freopen("2sat.out","w",stdout);

    read();
    solve();

    fclose(stdin);
    fclose(stdout);
    return 0;
}
