#include <fstream>
#include <vector>
#include <string.h>
#include <queue>

#define nMax 200005
#define pb push_back

using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
vector<int> G[nMax], GT[nMax];
int variables, expressions, value[nMax], viz[nMax], discover[nMax], okSol=1;
inline int non(int x)
{
    return (x>variables) ? x-variables : x+variables;
};
inline int ind(int x)
{
    return (x>0) ? x : variables-x;
};
void read()
{
    int x, y;
    fin>>variables>>expressions;

    for(int i=1;i<=expressions;i++)
    {
        fin>>x>>y;
        G[non(ind(x))].pb(ind(y));
        GT[ind(y)].pb(non(ind(x)));
        G[non(ind(y))].pb(ind(x));
        GT[ind(x)].pb(non(ind(y)));
    }
}
void dfs(int node)
{
    viz[node]=1;

    for(vector<int>::iterator it=G[node].begin();it!=G[node].end();it++)
    {
        int fiu=*it;
        if(!viz[fiu])
            dfs(fiu);
    }

    discover[++discover[0]]=node;
}
void dfst(int node)
{
    viz[node]=0;
    if(value[node]==1)
    {
        okSol=0;
        return;
    }

    value[non(node)]=1;

    for(vector<int>::iterator it=GT[node].begin();it!=GT[node].end();it++)
    {
        int fiu=*it;
        if(viz[fiu])
            dfst(fiu);
    }
}
void _2sat()
{
    for(int i=1;i<=2*variables;i++)
        if(!viz[i])
            dfs(i);

    for(int i=discover[0];i>=1;i--)
        if(viz[discover[i]] && viz[non(discover[i])])
            dfst(discover[i]);
}
void write()
{
    if(!okSol)
        fout<<-1;
    else
        for(int i=1;i<=variables;i++)
            fout<<value[i]<<" ";
}
int main()
{
    read();
    _2sat();
    write();
    return 0;
}
