#include <cstdio>
#include <ctime>
#include <cstdlib>

#include <algorithm>
#include <fstream>
#include <vector>

using namespace std;

const int CONST = 20;

ofstream fout("2sat.out");
ifstream fin("2sat.in");

bool eval(const pair<int, int>& p, const bool *assign)
{
    bool a = assign[abs(p.first)];
    bool b = assign[abs(p.second)];

    if (p.first < 0)
        a ^= 1;
    if (p.second < 0)
        b ^= 1;

    return a | b;
}

void print(const bool *assign, int N)
{
    for (int i = 1; i <= N; ++i)
        fout << assign[i] << " ";
    fout << "\n";
}

int main()
{
    int N, M;
    fin >> N >> M;

    vector<pair<int, int> > expr;
    for (int i = 0; i < M; ++i) {
        int x, y;
        fin >> x >> y;
        expr.push_back(make_pair(x, y));
    }

    srand(time(NULL));

    bool *assign = new bool[N + 1];
    for (int i = 1; i <= N; ++i) {
        assign[i] = static_cast<bool>(rand() % 2);
    }

    for (int step = 0; step <= N * CONST; ++step) {
        bool result = 1;

        typedef vector<pair<int, int> >::iterator iter;
        iter pos = expr.end();
        for (iter it = expr.begin(); it != expr.end(); ++it) {
            result &= eval(*it, assign);
            if (result == 0) {
                pos = it;
                break;
            }
        }

        if (result == 1) {
            print(assign, N);
            return 0;
        } else {
            if (rand() % 2 == 0)
                assign[abs(pos->first)] ^= 1;
            else
                assign[abs(pos->second)] ^= 1;
        }
    }
    delete[] assign;

    return 0;
}
