#include <bits/stdc++.h>

using namespace std;

FILE *F=fopen("2sat.in", "r"), *G=fopen("2sat.out", "w");

int n, m, x, y, k, w[3000005];
vector<int> a[3000005], rev[3000005];
bitset<3000005> v;
stack<int> st;

int id(int x)
{
    if(x < 0) return 2*n-x;
    return x-1;
}

void dfs1(int nod)
{
    vector<int> :: iterator it;
    v[nod] = 1;
    for(it = a[nod].begin(); it != a[nod].end(); ++ it)
        if(!v[*it]) dfs1(*it);
    st.push(nod);
}

void dfs2(int nod)
{
    vector<int> :: iterator it;
    v[nod] = 1;
    w[nod] = k;
    for(it = rev[nod].begin(); it != rev[nod].end(); ++ it)
        if(!v[*it]) dfs2(*it);
}

int main()
{
    fscanf(F, "%d %d ", &n, &m);
    for(int i = 0; i < m; ++ i)
    {
        fscanf(F, "%d %d ", &x, &y);
        a[id(-x)].push_back(id(y));
        a[id(-y)].push_back(id(x));
        rev[id(y)].push_back(id(-x));
        rev[id(x)].push_back(id(-y));
    }
    for(int i = 0; i < 2*n; ++ i)
        if(!v[i]) dfs1(i);
    v = 0;
    while(!st.empty())
    {
        x = st.top();
        if(!v[x])
        {
            ++k; dfs2(x);
        }
        st.pop();
    }
    for(int i = 1; i <= n; ++ i)
        if(w[id(i)] == w[id(-i)])
        {
            fprintf(G, "-1");
            return 0;
        }
    for(int i = 1; i <= n; ++ i)
        fprintf(G, "%d ", w[id(i)] > w[id(-i)]);
    return 0;
}
