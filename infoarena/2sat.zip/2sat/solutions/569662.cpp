#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define MAX 100001

struct vector
{
	int x,y;
}v[MAX*2];

char use[MAX];

int main()
{
	int N,M,i,end,pos,pos1,pos2,x,y;

	freopen("2sat.in","r",stdin);

	scanf("%d%d",&N,&M);

	for(i=1;i<=M;i++)
		scanf("%d%d",&v[i].x,&v[i].y);

	srand(time(NULL));
	for(i=1;i<=N;i++) use[i]=rand()%2;

	end=0;
	while(!end)
	{
		end=1;
		pos1=rand()%M+1;
		pos2=rand()%(M-pos1+1)+pos1;

		for(i=1;i<pos1;i++)
		{
			x=1;
			y=1;
			if(v[i].x<0) x=-1;
			if(v[i].y<0) y=-1;

			if(x<0&&y<0)
				if(!use[v[i].x*x]==0&&!use[v[i].y*y]==0)
				{
					end=0;
					break;
				}
				else;
			else
			if(x<0&&y>0)
				if(!use[v[i].x*x]==0&&use[v[i].y]==0)
				{
					end=0;
					break;
				}
				else;
			else
			if(x>0&&y<0)
				if(use[v[i].x]==0&&!use[v[i].y*y]==0)
				{
					end=0;
					break;
				}
				else;
			else
			if(x>0&&y>0)
				if(use[v[i].x]==0&&use[v[i].y]==0)
				{
					end=0;
					break;
				}
		}

		if(end)
			for(i=pos1;i<pos2;i++)
			{
				x=1;
				y=1;
				if(v[i].x<0) x=-1;
				if(v[i].y<0) y=-1;

				if(x<0&&y<0)
					if(!use[v[i].x*x]==0&&!use[v[i].y*y]==0)
					{
						end=0;
						break;
					}
					else;
				else
				if(x<0&&y>0)
					if(!use[v[i].x*x]==0&&use[v[i].y]==0)
					{
						end=0;
						break;
					}
					else;
				else
				if(x>0&&y<0)
					if(use[v[i].x]==0&&!use[v[i].y*y]==0)
					{
						end=0;
						break;
					}
					else;
				else
				if(x>0&&y>0)
					if(use[v[i].x]==0&&use[v[i].y]==0)
					{
						end=0;
					break;
				}
			}

		if(end)
			for(i=pos2;i<=M;i++)
			{
				x=1;
				y=1;
				if(v[i].x<0) x=-1;
				if(v[i].y<0) y=-1;

				if(x<0&&y<0)
					if(!use[v[i].x*x]==0&&!use[v[i].y*y]==0)
					{
						end=0;
						break;
					}
					else;
				else
				if(x<0&&y>0)
					if(!use[v[i].x*x]==0&&use[v[i].y]==0)
					{
						end=0;
						break;
					}
					else;
				else
				if(x>0&&y<0)
					if(use[v[i].x]==0&&!use[v[i].y*y]==0)
					{
						end=0;
						break;
					}
					else;
				else
				if(x>0&&y>0)
					if(use[v[i].x]==0&&use[v[i].y]==0)
					{
						end=0;
					break;
				}
			}

		if(!end)
		{
			pos=rand()%2;
			if(pos) use[v[i].x*x]=!use[v[i].x*x];
			else use[v[i].y*y]=!use[v[i].y*y];
		}
	}

	freopen("2sat.out","w",stdout);

	for(i=1;i<N;i++) printf("%d ",use[i]);
	printf("%d\n",use[N]);

	return 0;
}
