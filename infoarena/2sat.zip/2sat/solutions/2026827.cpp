#include<bits/stdc++.h>

#define ll long long
#define ull unsigned long long
#define pb push_back
#define mp make_pair
using namespace std;
ifstream in("2sat.in");
ofstream out("2sat.out");

const int NMax = 2e5 + 5;
const int inf = 1e9 + 5;
using zint = short;

int N,M,nrComp;
int sol[NMax],compOf[NMax];
bool visStack[NMax],visComp[NMax];
vector<int> v[NMax],rev[NMax],comp[NMax];
stack<int> st;

void build(int);
void getComp(int);
void setVal(int,int);

#define inv(a) ((a > N) ? a-N : a+N)
int main() {
    in>>N>>M;
    for (int i=1;i <= M;++i) {
        int x,y;
        in>>x>>y;

        if (x < 0) {x = -x + N;}
        if (y < 0) {y = -y + N;}
        v[inv(x)].pb(y);
        rev[y].pb(inv(x));
        v[inv(y)].pb(x);
        rev[x].pb(inv(y));
    }

    for (int i=1;i <= 2*N;++i) {
        sol[i] = -1;
    }

    for (int i=1;i <= 2*N;++i) {
        if (visStack[i]) {
            continue;
        }

        build(i);
    }

    while(st.size()) {
        int node = st.top(); st.pop();
        if (visComp[node]) {
            continue;
        }

        ++nrComp;
        getComp(node);
    }

    bool ans = true;
    for (int i=1;i <= N;++i) {
        if (compOf[i] == compOf[i+N]) {
            ans = false;
            break;
        }
    }

    if (ans) {
        for (int i=1;i <= nrComp;++i) {
            setVal(i,0);
        }

        for (int i=1;i <= N;++i) {
            out<<sol[i]<<' ';
        }
    }
    else {
        out<<"-1\n";
    }

    in.close();out.close();
    return 0;
}

void build(int node) {
    visStack[node] = true;

    for (int nxt : v[node]) {
        if (visStack[nxt]) {
            continue;
        }

        build(nxt);
    }

    st.push(node);
}

void getComp(int node) {
    comp[nrComp].pb(node);
    compOf[node] = nrComp;
    visComp[node] = true;

    for (int nxt : rev[node]) {
        if (visComp[nxt]) {
            continue;
        }

        getComp(nxt);
    }
}

void setVal(int c,int val) {
    int x = comp[c][0];
    if (x > N) {x -= N;}

    if (sol[x] != -1) {
        return;
    }

    for (int node : comp[c]) {
        int temp = val;
        if (node > N) {
            node -= N;
            temp ^= 1;
        }

        sol[node] = temp;
    }
}
