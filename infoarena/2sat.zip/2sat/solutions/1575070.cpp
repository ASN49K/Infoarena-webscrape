#include <iostream>//Componentele conexe se afiseaza corect, trebuie sa implementez doar ultima etapa+conversia inversa.
#include <fstream>
#include <vector>
#include <stack>
#define NMAX 100005
using namespace std;
vector<int> Comp[NMAX*2],L;
vector<int> G[NMAX*2],Gt[NMAX*2];
bool viz[NMAX*2],val[NMAX*2],rezolvat;
int lgL,NrComp,N,M,comp[NMAX*2];

void read()
{
    scanf("%d%d", &N, &M);
    int a,b,conva,convb,notconva,notconvb;

    for(int i=1; i<=M; i++) // G: -N, ..., -4, -3, -2, -1, 1, 2, 3, 4, ..., N
    {
        scanf("%d%d", &a, &b);
        if(a<0){
            conva=N+a+1;
            notconva=N+(a*(-1));
        }
        else{
            conva=N+a;
            notconva=N-a+1;
        }
        if(b<0){
            convb=N+b+1;
            notconvb=N+(b*(-1));
        }
        else{
            convb=N+b;
            notconvb=N-b+1;
        }
        /*G[notconva][++G[notconva][0]]=convb;
        Gt[convb][++Gt[convb][0]]=notconva;

        G[notconvb][++G[notconvb][0]]=conva;
        Gt[conva][++Gt[conva][0]]=notconvb;
        */
        G[notconva].push_back(convb);
        Gt[convb].push_back(notconva);
        G[notconvb].push_back(conva);
        Gt[conva].push_back(notconvb);
        /*
        if(a<0)
        {
            if(b<0)
            {
                G[N-a][++G[N-a][0]]=N+b+1;
                G[N-b][++G[N-b][0]]=N+a+1;
                Gt[N+b+1][++Gt[N+b+1][0]]=N-a;
                Gt[N+a+1][++Gt[N+a+1][0]]=N-b;
            }
            else
            {
                G[N-a][++G[N-a][0]]=N+b;
                G[N-b][++G[N-b][0]]=N+a;
                Gt[N+b][++Gt[N+b][0]]=N-a;
                Gt[N+a][++Gt[N+a][0]]=N-b;
            }
        }
        else if(b<0)
        {
            G[N-a+1][++G[N-a+1][0]]=N+b+1;
            G[N-b+1][++G[N-b+1][0]]=N+a+1;
            Gt[N+b+1][++Gt[N+b+1][0]]=N-a+1;
            Gt[N+a+1][++Gt[N+a+1][0]]=N-b+1;
        }
        else
        {
            G[N-a+1][++G[N-a+1][0]]=N+b;
            G[N-b+1][++G[N-b+1][0]]=N+a;
            G[N+b][++Gt[N+b][0]]=N-a+1;
            G[N+a][++Gt[N+a][0]]=N-b+1;
        }
        */
        /*if(a<0)
        {
            if(b<0)
            {
                G[N-a].push_back(N+b+1);
                Gt[N+b+1].push_back(N-a);
            }
            else
            {
                G[N-a].push_back(N+b);
                Gt[N+b].push_back(N-a);
            }
        }
        else if(b<0)
        {
            G[N-a+1].push_back(N+b+1);
            Gt[N+b+1].push_back(N-a+1);
        }
        else
        {
            G[N-a+1].push_back(N+b);
            G[N+b].push_back(N-a+1);
        }*/
        /*//prima implicatie
        G[(a>0? N-a+1 : N-a)].push_back((b>0? N+b : N+b+1));
        Gt[(b>0? N+b : N+b+1)].push_back((a>0? N+a : N+a));
        //a doua implicatie
        G[(b>0? N-b+1 : N-b)].push_back((a>0? N+a : N-a+1));
        Gt[(a>0? N+a : N-a+1)].push_back((b>0? N-b+1 : N+b));*/
    }
}
void vizitare(int u)
{
    if(viz[u])
        return;

    viz[u]=1;
    for(int i=0; i<G[u].size(); ++i)
    //for(int i=1; i<=G[u][0]; ++i)
        vizitare(G[u][i]);
    L.push_back(u);
}
void creazaComponenta(int u,int componenta)
{
    comp[u]=componenta;
    Comp[componenta].push_back(u);
    for(int i=0; i<Gt[u].size(); ++i)
    //for(int i=1; i<=Gt[u][0]; ++i)
    {
        int nod=Gt[u][i];
        if(!comp[nod])
            creazaComponenta(nod,componenta);
    }
}
bool Contradictii()
{
    int poz=N+1,neg=N;
    for(int i=1;i<N;i++)
    {
        if(val[poz]==val[neg])
            return 1;
        poz+=1;
        neg-=1;
    }
    return 0;
}
void afisare()
{
    for(int i=N+1;i<=N*2;i++)
        cout<<val[i]<<' ';
    cout<<'\n';
}
void atribuireValori(int NrComponenta, bool valoare)
{
    if(NrComponenta==0){
        if(Contradictii()==0)
            {rezolvat=1;afisare();}
    }
    else
    if(!rezolvat)
    {
        for(int i=0;i<Comp[NrComponenta].size();i++)
            val[Comp[NrComponenta][i]]=valoare;
        if(valoare==0)
            atribuireValori(NrComponenta-1, 1);
        else{
            atribuireValori(NrComponenta-1, 0);
            atribuireValori(NrComponenta-1, 1);
        }
    }
}
int main()
{
    freopen("2sat.in","rt",stdin);
    freopen("2sat.out","wt",stdout);
    read();
    for(int u=1; u<=2*N; u++)
        vizitare(u);
    lgL=L.size()-1;
    while(lgL>-1)
    {
        if(comp[L[lgL]]==0)
            creazaComponenta(L[lgL],++NrComp);
        lgL--;
    }
    /*for(int i=0;i<2*N;i++)
        cout<<L[i]<<' ';
    cout<<'\n';
    for(int i=1; i<=NrComp; i++)
    {
        for(int j=0; j<Comp[i].size(); j++)
            cout<<Comp[i][j]<<' ';
        cout<<'\n';
    }*/
    atribuireValori(NrComp,1);
    if(rezolvat==0)
        cout<<"-1\n";
}
