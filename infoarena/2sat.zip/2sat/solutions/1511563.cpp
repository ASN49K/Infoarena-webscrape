#include <cstdio>
#include <vector>

#define MMAX 200007

using namespace std;
int n, m, viz[MMAX], x, y, ans[MMAX], f = 1;
vector <int> adj[MMAX], adjp[MMAX], vec;

int neg(int a)
{
    return (a^1);
}
void convert(int &a)
{
    if(a < 0) a = (((0-a) << 1) | 1);
    else a = (a << 1);
}
void dfs(int nod)
{
    viz[nod] = 1;
    for(int i = adj[nod].size()-1; i+1; --i)
    {
        if(!viz[adj[nod][i]]) dfs(adj[nod][i]);
    }
    vec.push_back(nod);
    return ;
}
/*void dfs1(int node)
{
    c[node] = 1;
    for (auto it : g[node])
            if (!c[it])
                dfs1(it);
    order.push_back(node);
}*/
void dfsat(int nod)
{
    viz[nod] = 0;
    if(ans[nod]) f = 0;
    if(!f) return ;
    ans[neg(nod)] = 1;
    for(int i = adjp[nod].size() - 1; i+1; --i)
    {
        if(viz[adjp[nod][i]]) dfsat(adjp[nod][i]);
    }
}

int main()
{
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);
    scanf("%d %d", &n, &m);
    for(int i = 1; i<= m; ++i)
    {
        scanf("%d %d", &x, &y);
        convert(x); convert(y);
        adj[neg(x)].push_back(y);
        adjp[y].push_back(neg(x));
        adj[neg(y)].push_back(x);
        adjp[x].push_back(neg(y));
    }
    for(int i = 2; i<= 2*n+1; ++i)
    {
        if(!viz[i]) dfs(i);
    }
    for(int i = vec.size()-1; i+1; --i)
    {
        if(viz[vec[i]] && viz[neg(vec[i])]) dfsat(vec[i]);
    }
    if(f == 0)
    {
        printf("-1\n");
        return 0;
    }
    for(int i = 1; i<= n; ++i) printf("%d ", ans[(i<<1)]);
    printf("\n");
    return 0;
}
