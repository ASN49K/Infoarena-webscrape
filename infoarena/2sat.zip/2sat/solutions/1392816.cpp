#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#define NMAX 100010
using namespace std;
int n, m, x, y, i, nr, t[2*NMAX], val[2*NMAX];
bool viz[2*NMAX], sol=1;
vector<int> g[2*NMAX], gi[2*NMAX];
int neg(int x)
{
    if(x<=n) return x+n;
    else return x-n;
}
void DFS(int nod)
{
    viz[nod] = 1;
    for(vector<int> :: iterator it=g[nod].begin(); it!=g[nod].end(); ++it)
        if(!viz[*it])
            DFS(*it);
    t[++nr]=nod;
}
void DFST(int nod)
{
    if(val[nod]==1) sol=0;
    val[neg(nod)]=1;

   viz[nod] = 0;
    for(vector<int> :: iterator it=gi[nod].begin(); it!=gi[nod].end(); ++it)
        if(viz[*it])
            DFST(*it);
}
int main()
{
    ifstream cin("2sat.in");
    ofstream cout("2sat.out");
    cin>>n>>m;
    for(i=1; i<=m; ++i)
    {
        cin>>x>>y;
        if(x<0) x=-x+n;
        if(y<0) y=-y+n;
        g[neg(y)].push_back(x);
        gi[x].push_back(neg(y));
        g[neg(x)].push_back(y);
        gi[y].push_back(neg(x));
    }

    for(i=1; i<=2*n; ++i)
        if(!viz[i])
            DFS(i);
    reverse(t+1, t+nr+1);
    for(int i=1; i<=2*n; ++i)
        if(viz[t[i]]&&viz[neg(t[i])])
            DFST(t[i]);
    if(sol==0) cout<<"-1\n";
    else for(i=1; i<=n; ++i) cout<<val[i]<<' ';
}
