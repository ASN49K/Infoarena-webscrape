#include <bits/stdc++.h>
#define DIMN 100010
using namespace std;
int n , sol , g , elem;
vector <int> v[DIMN];
set <int> sl;
int niv[DIMN] , low[DIMN], s[DIMN] , f[DIMN] , val[DIMN];
void convert (int &x){
    if (x < 0){
        x =  -x + n;
    }
}
int invers (int x){
    if (x <= n)
        return x + n;
    else return x - n;
}
void dfs (int nod){
    int vecin,i;
    g++;
    niv[nod]=g;
    low[nod]=g;
    s[++elem]=nod;
    f[nod]=1;
    for (i=0;i<v[nod].size();i++){
        vecin=v[nod][i];
        if (!niv[vecin]){
            dfs(vecin);
            low[nod]=min(low[nod],low[vecin]);
        }
        else if (f[vecin])
            low[nod]=min(low[nod],low[vecin]);
    }
    if (low[nod]==niv[nod]){
        sl.clear();
        do{
            //printf ("%d ",s[elem]);
            sl.insert(s[elem]);
            f[s[elem]]=0;

            if (sl.find(invers(s[elem])) != sl.end()){ /// el si inversul in ac comp
                sol = -1;
            }

            if (val[s[elem]] == -1){
                val[s[elem]] = 1;
                val[invers(s[elem])] = 0;
            }

            elem--;

        } while (s[elem+1]!=nod);
        //printf ("\n");
    }
}
int main()
{
    FILE *fin = fopen ("2sat.in","r");
    FILE *fout = fopen ("2sat.out","w");
    int m,i,x,y;
    fscanf (fin,"%d%d",&n,&m);
    for (i=1;i<=m;i++){
        fscanf (fin,"%d%d",&x,&y);
        convert(x);
        convert(y);
        v[invers(x)].push_back(y);
        v[invers(y)].push_back(x);
        //printf ("%d %d\n%d %d\n" , invers(x) , y , invers(y) , x);
    }
    for (i=1;i<=2*n;i++)
        val[i] = -1;
    for (i=1;i<=n;i++){
        if (!niv[i])
            dfs (i);
    }
    if (sol == -1){
        fprintf (fout,"-1");
    }
    else {
        for (i=1;i<=n;i++)
            fprintf (fout,"%d ",val[i]);
    }
    return 0;
}
