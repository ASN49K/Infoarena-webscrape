#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <queue>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <cctype>
#include <string>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <fstream>
using namespace std;
 
const string file = "2sat";
 
const string infile = file + ".in";
const string outfile = file + ".out";


vector<int> values;
vector<vector<int> > G;

int N;
int M;

vector<int> lowlink;
vector<int> ind;
vector<bool> assigned;
vector<vector<int> > ctc;
stack<int> stiva;

vector<int> ctcIndex;
stack<int> topSorted;
vector<bool> used;

inline int non(int x)
{
	return x <= N ? x + N : x - N;
}

inline int var(int x)
{
	return x < 0 ? abs(x) + N : x;
}


void Tarjan(int i, int& c)
{
	lowlink[i] = ind[i] = c;
	stiva.push(i);
	c++;

	for(vector<int> ::iterator itr = G[i].begin();
		itr != G[i].end();
		itr++)
	{
		if(ind[*itr] == 0)
		{
			Tarjan(*itr, c);
			lowlink[i] = min(lowlink[i], lowlink[*itr]);
		}
		else if(assigned[*itr] == false)
		{
			lowlink[i] = min(lowlink[i], lowlink[*itr]);
		}

	}

	if(ind[i] == lowlink[i])
	{
		vector<int> newCtc;
		int size = ctc.size();
		int nod = -1;
		while(nod != i)
		{
			nod = stiva.top();
			assigned[nod] = true;
			ctcIndex[nod] = size;
			newCtc.push_back(nod);
			stiva.pop();
		}
		ctc.push_back(newCtc);
	}

}


void TopSort()
{
	vector<bool> discovered;
	vector<bool> explored;

	discovered.resize(ctc.size());
	explored.resize(ctc.size());

	for(unsigned i = 0; i < ctc.size(); i++)
	{
		if(discovered[i] == false)
		{
			discovered[i] = true;
			stiva.push(i);
			while(stiva.empty() == false)
			{
				int nod = stiva.top();
				
				if(explored[nod] == true)
				{
					topSorted.push(stiva.top());
					stiva.pop();
					continue;
				}
				explored[nod] = true;

				for(vector<int>::iterator itr = ctc[nod].begin();
					itr != ctc[nod].end();
					itr++)
				{

					for(vector<int>::iterator itr2 = G[*itr].begin();
						itr2 != G[*itr].end();
						itr2++)
					{

						if(discovered[ctcIndex[*itr2]] == false)
						{
							discovered[ctcIndex[*itr2]] = true;
							stiva.push(ctcIndex[*itr2]);
						}
					}
				}
			}
		}
	}
}

int main()
{
	fstream fin(infile.c_str(), ios::in);
	fin >> N >> M;

	values.resize(N+1);
	G.resize(2 * N+1);
	for(int i = 0; i < M; i++)
	{
		int xi, xj;
		fin >> xi >> xj;

		G[non(var(xi))].push_back(var(xj));
		G[non(var(xj))].push_back(var(xi));

	}

	fin.close();

	lowlink.resize(2 * N + 1);
	ind.resize(2 * N + 1);
	assigned.resize(2 * N + 1);
	ctcIndex.resize(2* N + 1);

	int c = 1;
	for(int i = 1; i <= 2 * N; i++)
	{
		if(ind[i] == 0)
		{
			Tarjan(i, c);
		}
	}

	TopSort();

	for(int i = 0; i <= N; i++)
	{
		if(ctcIndex[i] == ctcIndex[i+N])
		{
			fstream fout(outfile.c_str(), ios::out);
			fout << "-1\n";
			fout.close();
			return 0;
		}
	}

	while(topSorted.empty() == false)
	{
		int nod = topSorted.top();
		topSorted.pop();

		for(vector<int>::iterator itr = ctc[nod].begin();
			itr != ctc[nod].end();
			itr++)
		{
			int v = *itr > N ? *itr - N : * itr;
			if(values[v] == 0)
			{
				values[v] = *itr > N ? 2 : 1;
			}
			else
			{
				break;
			}

		}

	}

	fstream fout(outfile.c_str(), ios::out);

	for(int i = 1; i <= N; i++)
	{
		fout << values[i] - 1 << " ";
	}
	fout << "\n";

	fout.close();
}