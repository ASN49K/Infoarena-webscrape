#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define ar array
#define vt vector
#define pq priority_queue
#define pu push
#define pub push_back
#define em emplace
#define emb emplace_back
#define mt make_tuple

#define all(x) x.begin(), x.end()
#define allr(x) x.rbegin(), x.rend()
#define allp(x, l, r) x.begin() + l, x.begin() + r
#define len(x) (int)x.size()
#define uniq(x) unique(all(x)), x.end()

using namespace std;
using namespace __gnu_pbds;

using ll = long long;
using ld = long double;
using ull = unsigned long long;

template <class T, size_t N>
void re(array <T, N>& x);
template <class T> 
void re(vt <T>& x);

template <class T> 
void re(T& x) {
    cin >> x;
}

template <class T, class... M> 
void re(T& x, M&... args) {
    re(x); re(args...);
}

template <class T> 
void re(vt <T>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void re(array <T, N>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void wr(array <T, N> x);
template <class T> 
void wr(vt <T> x);

template <class T> 
void wr(T x) {
    cout << x;
}

template <class T, class ...M>  void wr(T x, M... args) {
    wr(x), wr(args...);
}

template <class T> 
void wr(vt <T> x) {
    for(auto it : x)
        wr(it, ' ');
}

template <class T, size_t N>
void wr(array <T, N> x) {
    for(auto it : x)
        wr(it, ' ');
}

template<class T, class... M>
auto mvt(size_t n, M&&... args) {
    if constexpr(sizeof...(args) == 1)
        return vector<T>(n, args...);
    else
        return vector(n, mvt<T>(args...));
}


void set_fixed(int p = 0) {
    cout << fixed << setprecision(p);
}

void set_scientific() {
    cout << scientific;
}

inline void Open(const string Name) {
    #ifndef ONLINE_JUDGE
        (void)!freopen((Name + ".in").c_str(), "r", stdin);
        (void)!freopen((Name + ".out").c_str(), "w", stdout);
    #endif
}

void solve() {
    function <void(int)> dfs;
    int n, m; re(n, m);
    stack <int> st;
    vt <vt <int>> adj(2 * n);
    vt <int> low_link(2 * n), index(2 * n);
    vt <bool> on_stack(2 * n);


    auto not_x = [&](int x) {
        if (x >= n)
            return x - n;
        return x + n;
    };

    for (int i = 0; i < m; ++i) {
        int a, b; re(a, b);
        a = (a < 0? -a - 1 + n : a - 1);
        b = (b < 0? -b - 1 + n : b -1);
        adj[not_x(a)].emb(b);
        adj[not_x(b)].emb(a);
    }

    int idx = 0;
    dfs = [&](int u) {
        st.em(u);
        on_stack[u] = true;
        low_link[u] = index[u] = ++idx;

        for (auto& v : adj[u]) {
            if (!index[v]) {
                dfs(v);
                low_link[u] = min(low_link[u], low_link[v]);
            } else if (on_stack[v]) {
                low_link[u] = min(low_link[u], low_link[v]);
            }
        }

        if (low_link[u] == index[u]) {
            int top;
            do {
                top = st.top();
                on_stack[top] = false;
                st.pop();
            } while(top != u);
        }
    };

    for (int u = 0; u < 2 * n; ++u)
        if (!index[u]) {
            dfs(u);
        }

    vt <int> res(n);
    for (int u = 0; u < n; ++u) {
        if (index[u] == index[not_x(u)]) {
            wr("IMPOSSIBLE\n");
            return;
        }
        res[u] = (index[u] > index[not_x(u)]? 1 : 0);
    }
    wr(res);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    Open("2sat");

    int t = 1;
    for(;t;t--) {
        solve();
    }
    
    return 0;
}