#include <bits/stdc++.h>
//#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("2sat.in" , "r" , stdin) , freopen("2sat.out" , "w" , stdout)
#define ll int
#define ull unsigned long long
#define ld long double
#define eb emplace_back
#define pb push_back
#define qwerty1 first
#define qwerty2 second
#define qwerty3 -> first
#define qwerty4 -> second
#define umap unordered_map
#define uset unordered_set
#define pii pair < ll , ll >
#define pq priority_queue
#define dbg(x) cerr << #x << ": " << x << '\n'

namespace FastRead
{
    char __buff[5000];ll __lg = 0 , __p = 0;
    char nc()
    {
        if(__lg == __p){__lg = fread(__buff , 1 , 5000 , stdin);__p = 0;if(!__lg) return EOF;}
        return __buff[__p++];
    }
    template<class T>void read(T&__x)
    {
        T __sgn = 1; char __c;while(!isdigit(__c = nc()))if(__c == '-')__sgn = -1;
        __x = __c - '0';while(isdigit(__c = nc()))__x = __x * 10 + __c - '0';__x *= __sgn;
    }
}

using namespace FastRead;
using namespace std;

const ll N = 1e5 + 10;
const ll M = 1e9 + 7;
const ld PI = acos(-1);
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int n , m;

struct sat
{
    #define N (ll) 1e6 + 10
    ///NU UITA SA SCHIMBI VALOARE IN 1E6 !!!!!!!!!!!!!!!!!!!!!!!!!!!!
    ll n;
    ll cnt;
    vector < ll > G[N] , ctc[N] , g[N];
    ll value[N] , comp[N] , mark[N] , valComp[N];
    stack < ll > s;

    sat(ll n)
    {
        this -> n = n;
        this -> cnt = 0;

        for(ll i = 1 ; i <= 2 * n ; i++)
            ctc[i].clear() , g[i].clear() , G[i].clear() , value[i] = -1 , mark[i] = 0 , valComp[i] = -1;
    }

    ll neg(ll x)
    {
        if(x <= n) return x + n;
        if(x >  n) return x - n;
    }

    void addEdge(ll x , ll y)
    {
        G[neg(x)].pb(y);
        G[neg(y)].pb(x);

        g[y].pb(neg(x));
        g[x].pb(neg(y));
    }

    void dfs(ll node)
    {
        mark[node] = 1;

        for(auto to : G[node])
            if(!mark[to])
                dfs(to);

        s.push(node);
    }

    void dfsComp(ll node)
    {
        ctc[cnt].pb(node);
        comp[node] = cnt;
        mark[node] = 2;

        for(auto to : g[node])
            if(mark[to] == 1)
                dfsComp(to);
    }

    void CTC()
    {
        ll i;

        for(i = 1 ; i <= 2 * n ; i++)
            if(!mark[i])
                dfs(i);

        while(!s.empty())
        {
            ll node = s.top();
            s.pop();

            if(mark[node] == 2)
                continue;

            ++cnt;
            dfsComp(node);
        }
    }

    void solve()
    {
        CTC();

        for(ll i = cnt ; i >= 1 ; i--)
        {
            ll v = valComp[i];

            for(auto j : ctc[i])
                if(value[j] != -1)
                    v = value[j];

            if(v == -1)
                v = 1;

            valComp[i] = v;

            for(auto j : ctc[i])
            {
                value[j] = v;
                value[neg(j)] = !v;
            }

            for(auto j : ctc[i])
                for(auto t : g[j])
                    if(v == 0)
                        valComp[comp[t]] = 0;
        }
    }
};

int value(int x)
{
    if(x < 0) return -x + n;
    if(x > 0) return x;
}

int neg(int x)
{
    x = value(x);

    if(x >  n) return x - n;
    if(x <= n) return x + n;
}

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

    int i;

    cin >> n >> m;

    sat S(n);

    for(i = 1 ; i <= m ; i++)
    {
        int x , y;

        cin >> x >> y;

        S.addEdge(value(x) , value(y));
    }

    S.solve();

    for(i = 1 ; i <= n ; i++)
        cout << S.value[i] << ' ';

    return 0;
}
