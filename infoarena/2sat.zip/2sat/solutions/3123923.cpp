#include <bits/stdc++.h>
using namespace std;
const int NMAX = 1e5;

ifstream fin( "2sat.in" );
ofstream fout( "2sat.out" );

vector <int> edges[2*NMAX+1];
vector <int> edges_rev[2*NMAX+1];
bool viz[2*NMAX+1];
stack <int> stiva;

int noComp = 0;
int component[2*NMAX+1];

void dfs( int node ) {
  viz[node] = true;
  for( auto vec: edges[node] ) {
    if( !viz[vec] )
      dfs( vec );
  }
  stiva.push( node );
}

void dfs2( int node ) {
  viz[node] = true;
  component[node] = noComp;
  for( auto vec: edges_rev[node] ) {
    if( !viz[vec] )
      dfs2( vec );
  }
}

int assignment[NMAX+1];
int main() {
  int n, m, i, a, b, na, nb, neg_a, neg_b;
  fin >> n >> m;
  for( i = 0; i < m; i++ ) {
    fin >> a >> b;
    na = nb = false;
    if( a < 0 ) {
      na = true;
      a = -a;
    }
    if( b < 0 ) {
      nb = true;
      b = -b;
    }
    a = (2 * a) - na;
    b = (2 * b) - nb;
    neg_a = ( a % 2 ? a + 1 : a - 1 );
    neg_b = ( b % 2 ? b + 1 : b - 1 );
    edges[neg_a].push_back( b );
    edges[neg_b].push_back( a );
    edges_rev[b].push_back( neg_a );
    edges_rev[a].push_back( neg_b );
  }
  for( i = 1; i <= 2 * n; i++ ) {
    if( !viz[i] )
      dfs( i );
  }
  for( i = 1; i <= 2 * n; i++ )
    viz[i] = false;
  while( !stiva.empty() ) {
    if( !viz[stiva.top()] ) {
      dfs2( stiva.top() );
      noComp++;
    }
    stiva.pop();
  }
  bool ok = true;
  for( i = 1; i < 2 * n; i += 2 ) {
    if( component[i] == component[i+1] )
      ok = false;
    assignment[(i+1)/2] = (component[i] < component[i+1]);
  }
  if( ok ) {
    for( i = 1; i <= n; i++ )
      fout << assignment[i] << " ";
  }
  else
    fout << -1 << "\n";
  return 0;
}
