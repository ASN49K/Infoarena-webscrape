#include <unordered_map>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>

using namespace std;

const string txt = "2sat";
const int nmax = 2e5 + 5;

ifstream f(txt + ".in");
ofstream g(txt + ".out");

int n, m, k, per[nmax], ans[nmax];
vector<int> comp[nmax];
unordered_map< int, vector<int> > v[5], v2;
unordered_map<int, int> c, fr, nr;
stack<int> st; queue<int> q;

static void dfs(int nod, int tip)
{
    fr[nod] = tip + 1;
    for (auto x : v[tip][nod])
        if (fr[x] != tip + 1)
            dfs(x, tip);

    if (!tip) st.push(nod);
    else c[nod] = k, comp[k].push_back(nod);
}

int main()
{
    f >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y; f >> x >> y;
        v[0][-x].push_back(y);
        v[0][-y].push_back(x);

        v[1][x].push_back(-y);
        v[1][y].push_back(-x);
    }

    dfs(1, 0);
    
    while (!st.empty())
    {
        while (!st.empty() && fr[st.top()] == 2) st.pop();
        if (st.empty()) break;

        k++; dfs(st.top(), 1);
    }

    fr.clear();
    for (int j = 1; j <= k; j ++)
        for(auto nod : comp[j])
            for (auto x : v[0][nod])
                if (fr[c[x]] != c[nod] && c[x] != c[nod])
                {
                    v2[c[nod]].push_back(c[x]);
                    nr[c[x]]++; fr[c[x]] = c[nod];
                }

    for (int i = 1; i <= n; i++)
        per[c[i]] = c[-i], per[c[-i]] = c[i];

    for (int i = 1; i <= k; i++)
        if (!nr[i]) q.push(i);

    fr.clear();
    while (!q.empty())
    {
        while (!q.empty() && fr[q.front()]) q.pop();
        if (q.empty()) break;

        int nod = q.front(); fr[nod] = fr[per[nod]] = 1;
        ans[nod] = 0; ans[per[nod]] = 1;

        for (auto x : v2[nod])
        {
            nr[x]--;
            if (!nr[x]) q.push(x);
        }

        for (auto x : v2[per[nod]])
        {
            nr[x]--;
            if (!nr[x]) q.push(x);
        }
    }

    for (int i = 1; i <= n; i++)
        g << ans[c[i]] << " ";
    return 0;
}