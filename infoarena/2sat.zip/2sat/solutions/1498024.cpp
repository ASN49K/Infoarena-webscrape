# include <bits/stdc++.h>
using namespace std;
ifstream fi("2sat.in");
ofstream fo("2sat.out");
vector < int > g[202005];
vector < int > gr[220005];
vector < int > order;
int c[220005];
int sol[220005];
void dfs1(int node)
{
    c[node] = 1;
    for (auto it : g[node])
            if (!c[it])
                dfs1(it);
    order.push_back(node);
}
bool ok = 1;
void dfs2(int node)
{
    c[node] = 0;
    if (sol[node^1]) ok = 0;
    if (!ok) return ;
    sol[node^1] = 1;
    for (auto it : gr[node])
            if (c[it])
                    dfs2(it);
}
int main(void)
{
    int n,m;
    fi>>n>>m;
    int a,b;
    while (m --)
    {
        fi>>a>>b;
        if (a < 0) a = -a,a = (a << 1) | 1;
        else a <<= 1;
        if (b < 0) b = -b,b = (b << 1) | 1;
        else b <<= 1;
        g[a^1].push_back(b);
        g[b^1].push_back(a);
        gr[a].push_back(b^1);
        gr[b].push_back(a^1);
    }
    for (int i = 2;i <= 2*n+1;++i)
            if (!c[i])
                dfs1(i);
    for (int i = 2*n - 1;i+1;--i)
        if (c[order[i]] && c[order[i]^1])
            dfs2(order[i]);
    if (!ok) return fo << "-1\n",0;
    for (int i = 1;i <= n;++i)
        fo << sol[i<<1] << ' ';
    return fo << '\n',0;
}
