#include <bits/stdc++.h>

using namespace std;
ifstream f("2sat.in");
ofstream g("2sat.out");

const int NMax = 200002;

int n,m,x,y,top,wrong;
int viz[NMax],s[NMax],ans[NMax];
vector<int> G[NMax],GT[NMax];

int non(int x){
    if(x <= n) return x + n;
    return x - n;
}
void dfs(int nod){
    viz[nod] = 1;
    for(int i = 0; i < G[nod].size(); ++i){
        if(!viz[G[nod][i]]){
            dfs(G[nod][i]);
        }
    }
    s[++top] = nod;
}
void dfsT(int nod){
    viz[nod] = 0;
    if(ans[nod]){   ///ans[nod] e 0 tot timpul
        wrong = 1;
        return;
    }
    ans[non(nod)] = 1;
    for(int i = 0; i < GT[nod].size(); ++i){
        if(viz[GT[nod][i]])
            dfsT(GT[nod][i]);
    }
}
int main()
{
    f >> n >> m;
    for(int i = 1; i <= m; ++i){
        f >> x >> y;
        if(x < 0) {x = -x; x += n;}
        if(y < 0) {y = -y; y += n;}

        G[non(x)].push_back(y);
        G[non(y)].push_back(x);
        GT[y].push_back(non(x));
        GT[x].push_back(non(y));
    }

    for(int i = 1; i <= 2 * n; ++i){
        if(!viz[i]){
            dfs(i);
        }
    }
    for(int i = top; i >= 1; --i){
        if(viz[s[i]] && viz[non(s[i])]){
            dfsT(s[i]);
        }
    }

    if(wrong){
        g << -1 << '\n';
    }else{
        for(int i = 1; i <= n; ++i){
            g << ans[i] << ' ';
        }
    }
    return 0;
}
