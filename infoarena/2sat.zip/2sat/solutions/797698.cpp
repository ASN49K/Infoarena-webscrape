#include <fstream>
#include <vector>
#include <set>
#include <algorithm>
#include <string.h>

#define DIM 100010

using namespace std;

vector<int> L[2*DIM];
vector<int> P[2*DIM];

int viz[2*DIM];
int low[2*DIM];
int stack[2*DIM];
int C[2*DIM];
int R[2*DIM];

set<int> Q[2*DIM];

int N, M, next, s, x, y, i, j, ctc, v;

void dfsctc(int x) {
	stack[++s] = x;
	next++;
	viz[x] = next;
	low[x] = next;
	for (int i=0;i<L[x].size();i++) {
		if (viz[L[x][i]] == 0) {
			dfsctc(L[x][i]);
			low[x] = min(low[x], low[L[x][i]]);
		} else
			if (viz[L[x][i]] > 0) {
				low[x] = min(low[x], low[L[x][i]]);
			}
	}
	
	if (viz[x] == low[x])
		do {
			ctc++;
			v = stack[s--];
			viz[v] = -viz[v];
			P[ctc].push_back(v);
			C[v] = ctc;
		} while (x!=v);
}

void dfstop(int x) {
	viz[x] = 1;
	for (set<int>::iterator it = Q[x].begin();it!=Q[x].end();it++) {
		if (viz[*it] == 0) {
			dfstop(*it);
		}
	}
	stack[++s] = x;
}

int main() {
	ifstream f("2sat.in");
	ofstream g("2sat.out");
	f>>N>>M;
	
	for (i=1;i<=M;i++) {
		f>>x>>y;
		if (x > 0 && y > 0) {
			L[x+N].push_back(y);
			L[y+N].push_back(x);
		}
		if (x < 0 && y < 0) {
			L[-x].push_back(-y+N);
			L[-y].push_back(-x+N);
		}
		if (x > 0 && y < 0) {
			L[x+N].push_back(-y+N);
			L[-y].push_back(x);
		}
		if (x < 0 && y > 0) {
			L[-x].push_back(y);
			L[y+N].push_back(-x+N);
		}
	}
	
	
	for (i=1;i<=2*N;i++)
		if (viz[i] == 0)
			dfsctc(i);
	
	//
	for (i=1;i<=N;i++) {
		if (C[i] == C[i+N]) {
			g<<-1;
			return 0;
		}
	}
	
	for (i=1;i<=2*N;i++) {
		for (j=0;j<L[i].size();j++)
			Q[ C[i] ].insert(  C[L[i][j]]  );
	}
	
	memset(viz, 0, sizeof(viz));
	s = 0;
	for (i=1;i<=ctc;i++)
		if (viz[i] == 0)
			dfstop(i);
		
	for (i=ctc;i>=1;i--) {
		int t = P[stack[i]][0];
		t = C[t];
		//pun 0 in variabilele neasociate ale componentei tare conexe i
		for (j=0;j<P[stack[i]].size();j++)
			if (R[P[stack[i]][j]] == 0) {
				R[P[stack[i]][j]] = -1;
				if (P[stack[i]][j] <= N)
					R[P[stack[i]][j]+N] = 1;
				else
					R[P[stack[i]][j]-N] = 1;
			}

		for (j=0;j<P[t].size();j++)
			if (R[P[t][j]] == 0) {
				R[P[t][j]] = 1;
				if (P[t][j] <= N)
					R[P[t][j]+N] = -1;
				else
					R[P[t][j]-N] = -1;
			}

	}
	
	for (i=1;i<=N;i++)
		if (R[i] == 1)
			g<<R[i]<<" ";
		else
			g<<"0 ";
	f.close();
	g.close();
	return 0;
}