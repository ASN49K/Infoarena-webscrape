#include <bits/stdc++.h>

using namespace std;
ifstream f("2sat.in");
ofstream g("2sat.out");
const int N=1e5+10;
vector <int> a1[2*N],a1_t[2*N];
vector <int> *a,*a_t;
stack <int> s;
bool v1[2*N],v1_t[2*N],v1_v[2*N],v1_f[2*N];
bool *viz,*viz_t,*val,*afis;
int n;
void dfs(int x)
{
    viz[x]=1;
    for(auto i:a[x])
    {
        if(!viz[i])
        {
            dfs(i);
        }
    }
    s.push(x);
}
void dfs_t(int x)
{
    viz_t[x]=1;
    if(!afis[x])
    {
        afis[x]=afis[-x]=1;
        val[x]=0;
        val[-x]=1;
    }
    else
    {
        if(val[x])
        {
            g<<-1;
            exit(0);
        }
    }
    for(auto i:a_t[x])
    {
        if(!viz_t[x])
        {
            dfs_t(i);
        }
    }
}
int main()
{
    int m;
    f>>n>>m;
    a=a1+N;
    a_t=a1_t+N;
    viz=v1+N;
    viz_t=v1_t+N;
    val=v1_v+N;
    afis=v1_f+N;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        f>>x>>y;
        a[-x].push_back(y);
        a_t[y].push_back(-x);
        a[-y].push_back(x);
        a_t[x].push_back(-y);
    }
    for(int i=1;i<=n;i++)
    {
        if(!viz[i])
        {
            dfs(i);
        }
    }
    while(!s.empty())
    {
        int x=s.top();
        s.pop();
        if(afis[x])
        {
            continue;
        }
        if(!viz_t[x])
        {
            dfs_t(x);
        }
    }
    for(int i=1;i<=n;i++)
    {
        g<<val[i]<<" ";
    }
    return 0;
}
