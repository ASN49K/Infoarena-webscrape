#include<fstream>
#include<cstdlib>

using namespace std;
typedef int var;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

#define MAXN 200005

var EA[MAXN], EB[MAXN];
var n, m;
bool VAL[MAXN];

#define DIM 100000
char buff[DIM];
var poz;
void Read(var &a) {
    while(!isdigit(buff[poz]) && buff[poz] != '-')
        if(++poz == DIM)
            fin.read(buff, DIM), poz=0;
    a = 0;
    bool sign = 0;
    if(buff[poz] == '-') {
        sign = 1;
        if(++poz == DIM)
            fin.read(buff, DIM), poz=0;
    }

    while(isdigit(buff[poz])) {
        a = a * 10 + buff[poz] - '0';
        if(++poz == DIM)
            fin.read(buff, DIM), poz=0;
    }

    if(sign)
        a = -a;
}


int main() {

    var a, b;

    fin.read(buff, DIM);

    Read(n);
    Read(m);

    var B = 218749231;
    srand(B);


    for(var i=1; i<=m; i++) {
        Read(a);
        Read(b);
        EA[i] = a;
        EB[i] = b;
    }

    for(var i=1; i<=n; i++) {
        VAL[i] = rand()%2;
    }

    bool ok = 0;
    var pas = 0;
    while(!ok && pas <= 600) {
        ok = 1;
        pas++;

        for(var i=1; i<=m; i++) {
            if(EA[i] > 0 && VAL[EA[i]])
                continue;
            if(EB[i] > 0 && VAL[EB[i]])
                continue;

            if(EA[i] < 0 && !VAL[-EA[i]])
                continue;
            if(EB[i] < 0 && !VAL[-EB[i]])
                continue;

            var ea = max(EA[i], -EA[i]);
            var eb = max(EB[i], -EB[i]);

            if(rand()%2) {
                VAL[ea] ^= 1;
            } else {
                VAL[eb] ^= 1;
            }
            ok = 0;
        }
    }

    if(pas > 600) {
        fout<<-1;
        return 0;
    }

    for(var i=1; i<=n; i++) {
        fout<<VAL[i]<<" ";
    }

    return 0;
}
