#include<cstdio>
#include <vector>
using namespace std;
#define pb push_back
FILE *in,*out;
vector<int> c,a[200005],b[200005],componenta[200005];
int v[200005],grupa[200005],nr,nrin[200005],rez[200005],n,q[200005];
void dfs(int x)
{
	int i;
	v[x]=1;
	for (i=0;i<a[x].size();i++)
		if (!v[a[x][i]])
			dfs(a[x][i]);
	c.pb(x);
}
void dfs_tare(int x)
{
	int i;
	componenta[nr].pb(x);
	grupa[x]=nr;
	for (i=0;i<b[x].size();i++)
		if (!grupa[b[x][i]])
			dfs_tare(b[x][i]);
}
inline int id(int x)
{
	return (x<0)?-x+n:x;
}
inline int non(int x)
{
	return x<=n?x+n:x-n;
}
inline int val(int x)
{
	return x<=n?x:x-n;
}
inline int semn(int x)
{
	return x>n?1:0;
}
int main()
{
	int m,x,y,i,j,k,p,u;
	in=fopen("2sat.in","r");
	out=fopen("2sat.out","w");
	fscanf(in,"%d%d",&n,&m);
	for (i=1;i<=m;i++)
	{
		fscanf(in,"%d%d",&x,&y);
		a[non(id(x))].pb(id(y));
		b[id(y)].pb(non(id(x)));
		a[non(id(y))].pb(id(x));
		b[id(x)].pb(non(id(y)));
	}
	for (i=1;i<=n;i++)
		rez[i]=-1;
	for (i=1;i<=(n<<1);i++)
		if (!v[i])
			dfs(i);
	for (i=c.size()-1;i>=0;i--)
		if (!grupa[c[i]])
		{
			nr++;
			dfs_tare(c[i]);
		}
	for (i=1;i<=n;i++)
		if (grupa[i]==grupa[i+n])
		{
			fprintf(out,"-1\n");
			fclose(in);
			fclose(out);
			return 0;
		}
	for (i=1;i<=nr;i++)
		for (j=0;j<componenta[i].size();j++)
			for (k=0;k<a[componenta[i][j]].size();k++)
				if (grupa[componenta[i][j]]!=grupa[a[componenta[i][j]][k]])
				{
					nrin[grupa[a[componenta[i][j]][k]]]++;
				}
	p=1;
	u=0;
	for (i=1;i<=nr;i++)
		if (nrin[i]==0)
		{
			u++;
			q[u]=i;
		}
	while (p<=u)
	{
		for (i=0;i<componenta[q[p]].size();i++)
		{
			if (rez[val(componenta[q[p]][i])]==-1)
				rez[val(componenta[q[p]][i])]=semn(componenta[q[p]][i]);
			for (j=0;j<a[componenta[q[p]][i]].size();j++)
			{
				if (grupa[a[componenta[q[p]][i]][j]]!=grupa[componenta[q[p]][i]])
				{
					nrin[grupa[a[componenta[q[p]][i]][j]]]--;
					if (nrin[grupa[a[componenta[q[p]][i]][j]]]==0)
					{
						u++;
						q[u]=grupa[a[componenta[q[p]][i]][j]];
					}
				}
			}
		}
		p++;	
	}
	for (i=1;i<=n;i++)
		fprintf(out,"%d ",rez[i]);
	fclose(in);
	fclose(out);
	return 0;
}
