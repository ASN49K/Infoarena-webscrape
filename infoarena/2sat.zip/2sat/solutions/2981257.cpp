#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

#define int long long
using namespace std;

ifstream fin ("2sat.in");
ofstream fout ("2sat.out");

const int maxN = 1e5 + 5;

vector <int> g[2*maxN];
vector <int> gT[2*maxN];
vector <int> componente[2*maxN];
vector <int> sortTop;

int cmp = 0, c[2*maxN];
int visit[2*maxN];
int stare[2*maxN];

void dfs (int node) {
    visit[node] = 1;
    for(int to : g[node])
        if(visit[to] == 0)
            dfs(to);

    sortTop.push_back(node);
}

void dfsT (int node) {
    visit[node] = 1;
    c[node] = cmp;
    componente[cmp].push_back(node);

    for(int to : gT[node])
        if(visit[to] == 0)
            dfsT(to);
}

signed main() {

    int n, m; fin >> n >> m;

    for(int i = 1; i <= m; i++) {
        char type1, type2; int sos1, sos2;

        fin >> sos1 >> sos2;

        if(sos1 < 0) type1 = '-'; else type1 = '+';
        if(sos2 < 0) type2 = '-'; else type2 = '+';

        if(type1 == '+' && type2 == '+') {
            g[2*sos1+1].push_back(2*sos2);
            g[2*sos2+1].push_back(2*sos1);

            gT[2*sos2].push_back(2*sos1+1);
            gT[2*sos1].push_back(2*sos2+1);
        }
        if(type1 == '-' && type2 == '+') {
            g[2*sos1].push_back(2*sos2);
            g[2*sos2+1].push_back(2*sos1+1);

            gT[2*sos2].push_back(2*sos1);
            gT[2*sos1+1].push_back(2*sos2+1);
        }

        if(type1 == '+' && type2 == '-') {
            g[2*sos1+1].push_back(2*sos2+1);
            g[2*sos2].push_back(2*sos1);

            gT[2*sos2+1].push_back(2*sos1+1);
            gT[2*sos1].push_back(2*sos2);
        }

        if(type1 == '-' && type2 == '-') {
            g[2*sos1].push_back(2*sos2+1);
            g[2*sos2].push_back(2*sos1+1);

            gT[2*sos2+1].push_back(2*sos1);
            gT[2*sos1+1].push_back(2*sos2);
        }

    }

    for(int i = 1; i <= n; i++)
    {
        if(visit[i * 2] == 0)
            dfs(i * 2);
        if(visit[i * 2 + 1] == 0)
            dfs(i * 2 + 1);
    }

    for(int i = 1; i <= n; i++)
        visit[i*2] = visit[i*2+1] = 0;

    reverse(sortTop.begin(), sortTop.end());
    for(int i : sortTop) {
        if(visit[i] == 0) {
            cmp++;
            dfsT(i);
        }
    }

    for(int i = 1; i <= n; i++) {
        if(c[i*2] == c[i*2+1]) {
            fout << "-1";
            return 0;
        }
    }

    for(int i = 1; i <= n; i++)
        visit[i*2] = visit[i*2+1] = 0;

    for(int i : sortTop) {
        if(visit[c[i]] == 0) {

            visit[c[i]] = 1;
            for(int j : componente[c[i]]) {
                if(j % 2 == 0) {
                    stare[j/2] = 0;
                    visit[c[j+1]] = 1;
                } else {
                    stare[j/2] = 1;
                    visit[c[j-1]] = 1;
                }
            }
        }
    }

    for(int i = 1; i <= n; i++) {
        if(stare[i] == 0)
            fout << "0 ";
        else
            fout << "1 ";
    }

    return 0;
}
//    for(int i = 1; i <= 2*n+1; i++, cout << '\n') {
//        if(i % 2 == 0)
//            cout << i / 2 << " : ";
//        else
//            cout << "-" << i / 2 << " : ";
//        for(int j : g[i]) {
//            if(j % 2 == 1)
//                cout << "-" << j/2 << " ";
//            else
//                cout << "+" << j/2 << " ";
//        }
//    }
