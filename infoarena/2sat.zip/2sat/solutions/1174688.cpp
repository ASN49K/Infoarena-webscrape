#include <cstring>
#include <fstream>
#include <vector>

using namespace std;

int N, M;
int E1[200002], E2[200002];
vector<int> V[200002];
bool S[200002];
int T[200002], F[200002];

inline int inv(int x)
{
	if (x > N) return x - N;
	return x + N;
}

void Dfs(int x)
{
	S[x] = true;
	for (vector<int>::iterator it = V[x].begin(); it != V[x].end(); ++it)
		if (!S[*it])
			Dfs(*it);
	T[++T[0]] = x;
}

int main()
{
	ifstream fin("2sat.in");
	ofstream fout("2sat.out");

	fin >> N >> M;
	for (int i = 1, nod1, nod2; i <= M; ++i)
	{
		fin >> nod1 >> nod2;

		nod1 = (nod1 < 0 ? N - nod1 : nod1);
		nod2 = (nod2 < 0 ? N - nod2 : nod2);

		V[inv(nod1)].push_back(nod2);
		V[inv(nod2)].push_back(nod1);

		E1[i] = nod1;
		E2[i] = nod2;
	}

	for (int i = 1; i <= 2 * N; ++i)
		if (!S[i])
			Dfs(i);
	memset(S, 0, sizeof(S));
	for (int i = 2 * N; i >= 1; --i)
		if (!F[T[i]] && !F[inv(T[i])])
            F[inv(T[i])] = true;

    bool impossible = false;
    for (int i = 1; i <= N; ++i)
        if (!F[E1[i]] && !F[E2[i]])
        {
            impossible = true;
            break;
        }

	if (impossible) fout << "-1\n";
	else
	{
		for (int i = 1; i <= N; ++i)
			fout << F[i] << ' ';
		fout << '\n';
	}

	fin.close();
	fout.close();
}
