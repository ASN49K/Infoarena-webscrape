#ifdef ONLINE_JUDGE
#include <bits/stdc++.h>
#else
#include <algorithm>
#include <bitset>
#include <cassert>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <map>
#include <set>
#include <stack>
#include <string>
#include <utility>
#include <vector>
#include <queue>
#endif

using namespace std;

	// lambda : [] (int a, int b) -> bool { body return }
	// string r_str = R"(raw string)"

#define mp make_pair
#define mt make_tuple
#define eb emplace_back
#define pb push_back
#define LL long long
#define ULL unsigned long long
#define BASE 73
#define NMAX 10000
#define NMAX2 20001
#define MOD1 1000000007
#define ALL(V) (V).begin(), (V).end()
#define ALLR(V) (V).rbegin(), (V).rend()
#define CRLINE Duxar(__LINE__);
#define SHOWME(x) cerr << __LINE__ << ": " << #x << " = " << (x) << endl;
#define ENTER putchar('\n');

int dx4[] = {-1, 0, 1, 0};
int dy4[] = {0, 1, 0, -1};

int dx8[] = {-1, -1, 0, 1, 1, 1, 0, -1};
int dy8[] = {0, 1, 1, 1, 0, -1, -1, -1};

void Duxar(int _this_line) {
#ifndef ONLINE_JUDGE
	printf("\n . . . . . . . . . . . . . Passed line - %d\n", _this_line);
#endif
}

template <class T>
void ReadNo(T &_value) {
	T _sign = 1;
	char ch;
	_value = 0;
	while(!isdigit(ch = getchar())) {
		(ch == '-') && (_sign = -1);
	}
	do {
		_value = _value * 10 + (ch - '0');
	} while(isdigit(ch = getchar()));
	_value *= _sign;
}

int N, M, level, no_sol;
vector <vector <int> > graph, comps;
vector <int> vals, lower, ilevel, viz, label;
stack <int> nodes;

void tarjan(int iam) {
	++level;
	lower[iam] = ilevel[iam] = level;
	viz[iam] = 1;
	nodes.push(iam);
	for (auto to: graph[iam]) {
		if (viz[to] == 0) {
			tarjan(to);
			lower[iam] = min(lower[iam], lower[to]);
		}
		else {
			if (viz[to] == 1) {
				lower[iam] = min(lower[iam], ilevel[to]);
			}
		}
	}
	viz[iam] = 2;
	if (lower[iam] == ilevel[iam]) {
		int x;
		vector <int> comp;
		do {
			x = nodes.top();
			nodes.pop();
			comp.pb(x);
			label[x] = comps.size();
			if (x < N) {
				if (label[N + x + 1] == label[x]) {
					no_sol = 1;
				}
			}
			else {
				if (label[N - (x - N)] == label[x]) {
					no_sol = 1;
				}
			}
		} while (x != iam);
		comps.pb(comp);
	}
}

int main(){
	string fileInput = "2sat";
#ifdef INFOARENA
	freopen((fileInput + ".in").c_str(), "r", stdin);
	freopen((fileInput + ".out").c_str(), "w", stdout);
#else
#ifndef ONLINE_JUDGE
	freopen("/Users/duxar/Workplace/Xcode Projects/Selectie/Selectie/input", "r", stdin);
#endif
#endif
	
	int i, x, y;
	
	ReadNo(N); ReadNo(M);
	graph.resize(2 * N + 1);
	viz.resize(2 * N + 1);
	ilevel.resize(2 * N + 1);
	lower.resize(2 * N + 1);
	label.resize(2 * N + 1, -1);
	
	for (i = 0; i < M; ++i) {
		ReadNo(x); ReadNo(y);
		graph[N - x].pb(N + y);
		graph[N - y].pb(N + x);
	}
	
	for (i = 0; i <= 2 * N; ++i) {
		if (!viz[i] && i != N) {
			tarjan(i);
		}
	}
	
	if (no_sol) {
		cout << -1 << '\n';
		return 0;
	}
	
	vals.resize(comps.size(), -1);
	for (i = comps.size() - 1; i >= 0; --i) {
		if (vals[i] == -1) {
			vals[i] = 0;
			for (auto x: comps[i]) {
				int y = x;
				if (y < N) {
					y = N + (N - x);
				}
				else {
					y = N - (x - N);
				}
				vals[label[y]] = 1;
			}
		}
	}
	
	for (i = N + 1; i <= 2 * N; ++i) {
		cout << vals[label[i]] << ' ';
	}
	ENTER
	
	return 0;
}


