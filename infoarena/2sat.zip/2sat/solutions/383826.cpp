#include <cstdio>
#include <cstring>
#include <cmath>
#include <vector>
#include <algorithm>
#include <set>
using namespace std;

#define mp make_pair
#define pb push_back
#define x first
#define y second
#define pii pair<int, int>
#define pdd pair<double, double>
#define pid pair<int, double>
#define pdi pair<double, int>
#define ppi pair<pair<int, int>, int>
#define forit(it, v) for(__typeof(v.begin()) it = v.begin(); it != v.end(); ++it)
#define sz(v) v.size()
#define del(it, v) v.erase(it)
#define db double
#define ll long long

const int INF = 0x3f3f3f3f;
const int MAX_N = 100010;
const int MAX_M = 0;
const int MAX_L = 0;

int n, m, z, sol;
int f[MAX_N * 2], q[2 * MAX_N], d[MAX_N * 2];
vector <int> v[MAX_N * 2], s[MAX_N * 2], vt[MAX_N * 2];

inline int inv(int nod)
{
	if (nod > n)
		return nod - n;
	return nod + n;
}

void df(int nod)
{
	if (f[nod])
		return;
	f[nod] = 1;

	forit(it, v[nod])
		df(*it);

	q[++z] = nod;
}

void df2(int nod)
{
	if (f[nod] == 2)
		return;
	f[nod] = 2;

	s[sol].pb(nod);

	forit(it, vt[nod])
		df2(*it);
}

int main()
{
	int i;
	freopen("2sat.in", "r", stdin);
	freopen("2sat.out", "w", stdout);

	scanf("%d %d", &n, &m);

	for (i = 1; i <= m; ++i)
	{
		int r1, r2, n1, n2;

		scanf("%d %d", &r1, &r2);

		n1 = r1;
		if (r1 < 0)
			n1 = n + (-r1);

		n2 = r2;
		if (r2 < 0)
			n2 = n + (-r2);

		v[inv(n1)].pb(n2);
		v[inv(n2)].pb(n1);

		vt[n2].pb(inv(n1));
		vt[n1].pb(inv(n2));
	}

	for (i = 1; i <= 2 * n; ++i)
		if (!f[i])
			df(i);

	for (i = 2 * n; i; --i)
		if (f[q[i]] != 2)
		{
			++sol;
			df2(q[i]);
		}

	for (i = 1; i <= sol; ++i)
		forit(it, s[i])
			d[*it] = i;

	for (i = 1; i <= n; ++i)
	{
		f[i] = f[i + n] = -1;

		if (d[i] == d[i + n])
		{
			printf("-1\n");
			return 0;
		}
	}

	for (i = 2 * n; i; --i)
	{
		if (f[i] >= 0)
			continue;

		forit(it, s[d[i]])
			f[*it] = 1;

		forit(it, s[d[inv(i)]])
			f[*it] = 0;
	}

	for (i = 1; i <= n; ++i)
		printf("%d ", f[i]);
}
