#include <iostream>
#include <cstdio>
#include <vector>
#include <stack>
using namespace std;

vector<vector<int>> adjl;
int index = 0;
vector<int> low;
stack<int> t;
vector<bool> popped;
vector<vector<int>> sccs;

void dfs(int u)
{
	int indexu = index++;
	low[u] = indexu;
	t.push(u);
	for (auto v: adjl[u]) {
		if (popped[v]) {
			continue;
		}
		if (low[v] == -1) {
			dfs(v);
		}
		low[u] = min(low[u], low[v]);
	}
	if (low[u] == indexu) {
		vector<int> scc;
		int top;
		do {
			top = t.top();
			t.pop();
			popped[top] = true;
			scc.push_back(top);
		} while (top != u);
		sccs.push_back(scc);
	}
}

int main()
{
	ios::sync_with_stdio(false);
	freopen("2sat.in", "r", stdin);
	freopen("2sat.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	adjl.resize(2*n);
	for (int i = 0; i < m; i++) {
		int x1, y1;
		cin >> x1 >> y1;
		int x2, y2;
		if (x1 > 0) {
			x1--;
			x2 = x1+n;
		}
		else {
			x2 = -x1-1;
			x1 = x2+n;
		}
		if (y1 > 0) {
			y1--;
			y2 = y1+n;
		}
		else {
			y2 = -y1-1;
			y1 = y2+n;
		}
		adjl[x2].push_back(y1);
		adjl[y2].push_back(x1);
	}
	low.assign(2*n, -1);
	popped.resize(2*n);
	for (int i = 0; i < 2*n; i++) {
		if (!popped[i]) {
			dfs(i);
		}
	}
	vector<bool> b(2*n);
	for (auto & scc: sccs) {
		int x = scc[0]%n;
		if (b[x] or b[x+n]) {
			continue;
		}
		for (auto u: scc) {
			b[u] = true;
		}
	}
	for (int i = 0; i < n; i++) {
		if (b[i] and b[i+n]) {
			printf("-1\n");
			return 0;
		}
	}
	for (int i = 0; i < n; i++) {
		printf("%c ", b[i] ? '1' : '0');
	}
	printf("\n");
	return 0;
}
