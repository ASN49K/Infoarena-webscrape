#include<fstream>
#include<vector>
#include<queue>
#include<algorithm>
using namespace std;
#define M 200001
int v,e,x,y,i,c,j,o;
vector<int> a[M],b[M],w(M),u(M,-1),d(M,0);
vector<int>::iterator t,k,l;
vector<vector<int>> s;
queue<int> q;
int A(int x)
{
    return x<0?-x:x;
}
int I(int x)
{
    return x<0?A(x)+v:x;
}
int N(int x)
{
    return x>v?x-v:x+v;
}
void D(int n,vector<int>& u,vector<int>& d)
{
    u[n]=1;
    for(vector<int>::iterator i=a[n].begin();i!=a[n].end();++i)
        if(!u[*i])
            D(*i,u,d);
    d.push_back(n);
}
void E(int n,vector<int>& u,vector<int>& s)
{
    u[n]=1,s.push_back(n);
    for(vector<int>::iterator i=b[n].begin();i!=b[n].end();++i)
        if(!u[*i])
            E(*i,u,s);
}
void C()
{
    vector<int> u(M),d,r;
    u.assign(u.size(),0);
    for(int i=1;i<=v*2;++i)
        if(!u[i])
            D(i,u,d);
    u.assign(u.size(),0);
    for(vector<int>::reverse_iterator t=d.rbegin();t!=d.rend();++t)
        if(!u[*t])
        {
            r.clear();
            E(*t,u,r);
            for(vector<int>::iterator j=r.begin();j!=r.end();++j)
                w[*j]=s.size();
            s.push_back(r);
        }
}
int main()
{
    ifstream f("2sat.in");
    ofstream g("2sat.out");
    f>>v>>e;
    for(i=0;i<e;++i)
        f>>x>>y,a[N(I(x))].push_back(I(y)),b[I(y)].push_back(N(I(x))),a[N(I(y))].push_back(I(x)),b[I(x)].push_back(N(I(y)));
    for(C(),c=0,x=1;x<=v;++x)
        if(w[x]==w[x+v])
            c=1;
    if(!c)
    {
        for(x=1;x<=v*2;++x)
            for(t=a[x].begin();t!=a[x].end();++t)
                if(w[x]!=w[*t])
                    d[w[*t]]++;
        for(o=(int)s.size(),j=0;j<o;++j)
            if(!d[j])
                q.push(j);
        while(!q.empty())
        {
            j=q.front(),q.pop();
            for(t=s[j].begin();t!=s[j].end();++t)
            {
                x=(*t>v)?*t-v:*t;
                if(u[x]==-1)
                    u[x]=(*t<=v)?0:1;
            }
            for(k=s[j].begin();k!=s[j].end();++k)
                for(l=a[*k].begin();l!=a[*k].end();++l)
                    if(w[*k]!=w[*l])
                        if((--d[w[*l]])==0)
                            q.push(w[*l]);
        }
        for(i=1;i<=v;++i)
            g<<u[i]<<" ";
    }
    else
        g<<-1;
}
