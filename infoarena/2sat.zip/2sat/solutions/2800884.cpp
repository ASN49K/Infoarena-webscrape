#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <cstring>
using namespace std;
ifstream f("2sat.in");
ofstream g("2sat.out");
const int N_MAx=2e5+5;
int n,m,ctc;
vector<int> q[N_MAx],p[N_MAx],comp(N_MAx,-1);
bool vf[N_MAx],value[N_MAx];
stack<int> s;

void dfs(int x)
{
    vf[x]=1;
    for(auto j:q[x])
        if(!vf[j])
            dfs(j);
    s.push(x);
}

void tDfs(int x)
{
    vf[x]=1;
    comp[x]=ctc;
    for(auto j:p[x])
        if(!vf[j])
            tDfs(j);
}

bool solve()
{
    for(int i=1; i<=n; i++)
        if(!vf[i])
            dfs(i);
    memset(vf,0,sizeof vf);
    while(!s.empty())
    {
        int x=s.top();
        s.pop();
        if(!vf[x])
        {
            ctc++;
            tDfs(x);
        }
    }
    for(int i=2; i<=n; i+=2)
    {
        if(comp[i]==comp[i+1])
            return 0;
        value[i/2]=(comp[i+1]<comp[i]);
    }
    return 1;
}

int main()
{
    f>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x,y,px,nx,py,ny;
        f>>x>>y;
        px=2*abs(x);
        nx=2*abs(x)+1;
        if(x<0)
            swap(nx, px);
        py=2*abs(y);
        ny=2*abs(y)+1;
        if(y<0)
            swap(ny,py);
        q[nx].push_back(py);
        q[ny].push_back(px);
        p[py].push_back(nx);
        p[px].push_back(ny);
    }
    n=2*n+1;
    bool ok=solve();
    if(!ok)
        g<<"-1\n";
    else
    {
        for(int i=1; i<=(n-1)/2; i++)
            g<<value[i]<<' ';
        g<<'\n';
    }
    return 0;
}
