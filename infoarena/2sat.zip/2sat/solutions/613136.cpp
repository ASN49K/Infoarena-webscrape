#include <cstdio>
#include <vector>

using namespace std;

int n,m,post[200001],nr,v[200001],ok,value[200001];
vector <int> a[200001],at[200001];

inline int abs(int a){if(a<0) return -a;else return a;}
inline int neg(int a){if(a > n) return a-=n;else return a+n;}

void dfs(int x)
{
    vector <int>::iterator it;
    v[x]=1;
    for(it=at[x].begin();it!=at[x].end();++it)
        if(!v[*it])
            dfs(*it);
    ++nr;
    post[nr]=x;
}

void dfst(int x)
{
    vector <int>::iterator it;
    if(value[x])
        ok=0;
    v[x]=0;
    value[x]=0;
    value[neg(x)]=1;
    for(it=at[x].begin();it!=at[x].end();++it)
        if(v[*it])
            dfst(*it);
}

int main()
{
    int i,x,y;
    freopen("2sat.in","r",stdin);
    freopen("2sat.out","w",stdout);
    scanf("%d %d\n",&n,&m);
    for(;m;--m)
    {
        scanf("%d %d\n",&x,&y);
        if(x<0)
            x=n+abs(x);
        if(y<0)
            y=n+abs(y);
        a[neg(x)].push_back(y);
        at[y].push_back(neg(x));
        a[neg(y)].push_back(x);
        at[x].push_back(neg(y));
    }
    for(i=1;i<=2*n;++i)
        if(v[i]==0)
            dfs(i);
    for(ok=1,i=nr;i;--i)
        if(v[post[i]]&&v[neg(post[i])])
            dfst(post[i]);
    if(ok)
    {
        for(i=1;i<=n;++i)
            printf("%d ", value[i]);
        printf("\n");
    }
    else
        printf("-1\n");
    return 0;
}
