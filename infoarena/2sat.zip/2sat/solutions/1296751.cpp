#include<fstream>
#include<algorithm>
#define MAXNT 200005
#define MAXNV 100005
using namespace std;
ifstream cin("2sat.in");
ofstream cout("2sat.out");
int N,M;
pair <int,int> EXP[MAXNT];
int STACK[MAXNV],SOL[MAXNV];
bool found_sol;
bool eval_term(pair<int,int> T){
	int x,y;
	x=STACK[abs(T.first)];
	y=STACK[abs(T.second)];
	if(T.first<0)
		x^=1;
	if(T.second<0)
		y^=1;
return	(x|y);
}
bool check_solution(){
	int i;
	for(i=1;i<=M;i++)
		if(!eval_term(EXP[i]))
			return false;
return true;
}
void generate_solution(int k){
int i,bit;
	if(found_sol)
		return;
	if(k==N){
		if(check_solution()){
			for(i=1;i<=N;i++)
				SOL[i]=STACK[i];
			found_sol=true;
		}
	}
	else{
		for(bit=0;bit<2;bit++){
			STACK[k+1]=bit;
			generate_solution(k+1);
		}
	}
}
int main(){
int x,y,i;
cin>>N>>M;
for(i=1;i<=M;i++){
		cin>>x>>y;
		EXP[i]=make_pair(x,y);
}
found_sol=false;
generate_solution(0);
for(i=1;i<=N;i++)
		cout<<SOL[i]<<" ";
return 0;
}