#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
#include <stack>
#define NMAX 200005
using namespace std;
ifstream si("2sat.in");
ofstream so("2sat.out");
vector<int>g[NMAX];
vector<int>gt[NMAX];
bitset<NMAX>vaz;
bitset<NMAX>sol;
stack<int> ord;
int n;
bool ok=true;
int neg(int a)
{
    if(a>n)
        a-=n;
    else
        a+=n;
    return a;
}
void adaug(int a,int b)
{
    g[a].push_back(b);
    gt[b].push_back(a);
}
void dfs1(int nod)
{
    vaz[nod]=1;
    int i,l=g[nod].size();
    for(i=0;i<l;++i)
    {
        if(!vaz[g[nod][i]])
            dfs1(g[nod][i]);
    }
    ord.push(nod);
}
void dfs2(int nod)
{
    if(sol[nod])
    {
        ok=false;
        return;
    }
    vaz[nod]=sol[nod]=0;
    sol[neg(nod)]=1;
    int i,l=gt[nod].size();
    for(i=0;i<l;++i)
    {
        if(vaz[gt[nod][i]])
        {
            dfs2(gt[nod][i]);
        }
    }
}
int main()
{
    int m;
    si>>n>>m;
    int i;
    int a,b;
    for(i=0;i<m;++i)
    {
        si>>a>>b;
        if(a<0)
            a=n-a;
        if(b<0)
            b=n-b;
        adaug(neg(a),b);
        adaug(neg(b),a);
    }
    for(i=1;i<=n+n;++i)
    {
        if(!vaz[i])
        {
            dfs1(i);
        }
    }
    while(!ord.empty())
    {
        a=ord.top();
        ord.pop();
        if(vaz[a]&&vaz[neg(a)])
            dfs2(a);
    }
    if(!ok)
        so<<"-1\n";
    else
    {
        for(i=1;i<=n;++i)
            so<<sol[i]<<' ';
        so<<'\n';
    }
    return 0;
}
