using namespace std;

#include <vector>

#define FORit(it,x) for (__typeof((x).begin()) it = (x).begin(); it != (x).end(); ++it)
#define non(x) ( (x) > N? (x) - N : (x) + N)
#define pb push_back

int N,M,Q[1<<18];
vector<int> A[1<<18],B[1<<18];
bool viz[1<<18],S[1<<18],ok(1);

void DFP(int x)
{
	viz[x] = true;
	FORit(it,A[x])
		if(!viz[*it])
			DFP(*it);
	Q[++Q[0]] = x;
}

void DFM(int x)
{
	if(S[x])
		ok = false;
	viz[x] = S[non(x)] = true;
	FORit(it,B[x])
		if(!viz[*it])
			DFM(*it);
}

int main()
{
	freopen("2sat.in","r",stdin);
	freopen("2sat.out","w",stdout);

	int x,y;
	scanf("%d%d",&N,&M);
	for(;M--;)
	{
		scanf("%d%d",&x,&y);
		x=x<0?-x+N:x;
		y=y<0?-y+N:y;
		
		A[non(x)].pb(y);
		A[non(y)].pb(x);
		B[y].pb(non(x));
		B[x].pb(non(y));
	}
	
	for(int i=1;i<=N*2;++i)
		if(!viz[i])
			DFP(i);
	
	memset(viz,0,sizeof(viz));
	
	for(int i = N*2;i;--i)
		if(!viz[Q[i]] && !viz[non(Q[i])])
			DFM(Q[i]);
	
	if(ok) for(int i = 1;i <= N;++i) printf("%d ",S[i]);
	else printf("-1\n");
	
	return 0;
}
