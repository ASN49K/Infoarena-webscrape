#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <bitset>
#include <queue>
#include <deque>
#include <list>
#include <set>
#include <ctime>
#include <string>
#include <cstring>
#include <iomanip>
#include <algorithm>
using namespace std;
ofstream gg("2sat.out");
ifstream ff("2sat.in");
#define max 100001
int n, m, k, qq[max];
vector<int> vv[max], tt[max];
bool ww[max], ss[max], e=1;

int neg(int x){ return x>n?x-n:x+n; }
 
void dfs(int x){
	int y, l=vv[x].size();
	ww[x]=1;
	for(int i=0;i<l;i++){
		y=vv[x][i];
		if(!ww[y]) dfs(y);
	}
	qq[++k]=x;
}

void com(int x){
	int y, l=tt[x].size();
	if(ss[x]) e=0;
	ww[x]=1;
	ss[neg(x)]=1;
	for(int i=0;i<l;i++){
		y=tt[x][i];
		if(!ww[y])com(y);
	}
}
 
int main(){
	int a, b;
	ff >> n >> m;
	for(int i=0;i<m;i++){
		ff >> a >> b;
		if(a<0) a=n-a;
		if(b<0) b=n-b;
		vv[neg(a)].push_back(b);
		vv[neg(b)].push_back(a);
		tt[b].push_back(neg(a));
		tt[a].push_back(neg(b));
	}
	for(int i=1;i<=2*n;i++)
		if(!ww[i]) dfs(i);
	memset(ww, 0, sizeof(ww));
	for(int i=2*n;i>0;i--)
		if(!ww[qq[i]] && !ww[neg(qq[i])])
			com(qq[i]);
	if(!e) gg << "-1\n"; else
		for(int i=1;i<=n;i++) gg << ss[i] << " ";
	return 0;
}