#include<iostream>
#include<fstream>
#include<vector>
#include<cstring>
#include<map>
#include<algorithm>
#include<set>
#include<deque>
#include<queue>
using namespace std;

const int mx=4e5;

ifstream in("2sat.in");
ofstream out("2sat.out");

vector<int> g[mx],gt[mx],q;
bool visited[mx],possible=true;
int n,m,result[mx];

int node(int x){
	if(x<0){
		return n+abs(x);
	}
	return x;
}

int val(int node){
	if(node>n){
		return n-node;
	}
	return node;
}


void read(){
	in>>n>>m;
	int a,b;
	for(int i=0;i<m;i++){
		in>>a>>b;
		g[node(-a)].push_back(node(b));
		gt[node(b)].push_back(node(-a));
		g[node(-b)].push_back(node(a));
		gt[node(a)].push_back(node(-b));
	}
}

void dfs1(int x){
	visited[x]=true;
	for(int k:g[x]){
		if(!visited[k])
			dfs1(k);
	}
	q.push_back(x);
}

void dfs2(int x,int value){
	if(result[x]!=-1 && value!=result[x])
		possible=false;

	visited[x]=true;
	result[x]=value;
	result[node(-val(x))]=1-value;

	for(int k:gt[x]){
		if(!visited[k]){
			dfs2(k,value);
		}
	}
}
void preprocess(){
	for(int i=1;i<=2*n;i++)
		result[i]=-1;
}

void solve(){

	for(int i=1;i<=2*n;i++){
		if(!visited[i]){
			dfs1(i);
		}
	}
	for(int i=1;i<mx;i++)
		visited[i]=false;
	
	bool possible=true;
	for(auto iter=q.rbegin();iter!=q.rend();iter++){
		if(!visited[*iter]){
			dfs2(*iter,1);
		}
	} 
	if(!possible){
		cout<<-1;
		return;
	}

	for(int i=1;i<=n;i++)
		cout<<result[i]<<" ";
}

int main(){
	read();
	solve();
	return 0;
}
