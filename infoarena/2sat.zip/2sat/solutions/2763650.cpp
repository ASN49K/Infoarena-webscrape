#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;

//ifstream cin("2sat.in");
//ofstream cout("2sat.out");

int n, m, x, y;
vector<int> g[200001];
vector<int> gt[200001];
int use[200001], k = 2;
vector<int> p;
int tout[200001], t;
void dfs(int nod)
{
    use[nod] = 1;
    for (auto i : g[nod])
    {
        if (!use[i])
            dfs(i);
    }
    p.push_back(nod);
    tout[nod] = ++t;
}
void dfs2(int nod)
{
    use[nod] = k;
    for (auto i : gt[nod])
    {
        if (use[i] == 1)
            dfs2(i);
    }
}
int main()
{
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        cin >> x >> y;
        int idx = abs(x), idy = abs(y);
        int idnx = abs(x) + n, idny = abs(y) + n;

        if (x < 0)
            swap(idx, idnx);
        if (y < 0)
            swap(idy, idny);

        g[idnx].push_back(idy);
        g[idny].push_back(idx);
    }
    for (int i = 1; i <= 2 * n; i++)
    {
        for (auto j : g[i])
            gt[j].push_back(i);
    }
    for (int i = 1; i <= 2 * n; i++)
    {
        if (!use[i])
        {
            dfs(i);
        }
    }
    for (int i = p.size() - 1; i >= 0; i--)
    {
        if (use[p[i]])
        {
            dfs2(p[i]);
            k++;
        }
    }
    for (int i = 1; i <= n; i++)
    {
        if (use[i] == use[i + n])
        {
            cout << "-1\n";
            return 0;
        }
    }
    for (int i = 1; i <= n; i++)
    {
        if (tout[i] < tout[i + n])
            cout << "1 ";
        else cout << "0 ";
    }
    return 0;
}