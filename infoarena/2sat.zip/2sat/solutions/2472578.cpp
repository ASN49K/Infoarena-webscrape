#include<iostream>
#include<vector>
#include<fstream>
#include<stack>
using namespace std;

const int N = 2e5 + 10;
const int M = 2e5 + 10;

vector<int> nbrs[N];
int br = 0;
int index[N];
int lowLink[N];
stack<int> st;
bool inStack[N];
int compCount = 0;
vector<int> output;
int ans[N];
int komp[N];

void dfs(int currentV)
{
    index[currentV] = br;
    lowLink[currentV] = br;
    ++br;
    st.push(currentV);
    inStack[currentV] = true;

    for(int i = 0; i < nbrs[currentV].size(); ++i)
    {
        int nextV = nbrs[currentV][i];

        if(index[nextV] == -1)
        {
            dfs(nextV);
            lowLink[currentV] =
                min(lowLink[currentV], lowLink[nextV]);
        }
        else if(inStack[nextV])
        {
            /// TODO: check if lowLink works the same
            lowLink[currentV] =
                min(lowLink[currentV], index[nextV]);
        }
    }

    if(index[currentV] == lowLink[currentV])
    {
        //cout << "New SCC:\n";
        while(st.top() != currentV)
        {
            output.push_back(st.top() + 1);
            inStack[st.top()] = false;
            //cout << st.top() + 1 << " ";
            st.pop();
        }
        output.push_back(st.top() + 1);
        inStack[st.top()] = false;
        //cout << st.top() + 1 << endl;
        st.pop();
        ++compCount;
        output.push_back(-1);
    }
}

#define endl "\n"

int main()
{
    ofstream myfile;
    myfile.open ("2sat.out");

    ifstream myFileIn;
    myFileIn.open ("2sat.in");

    int n;
    int m;
    myFileIn >> n >> m;
    ///cin >> n >> m;
    for(int i = 0; i < m; ++i)
    {
        int from,to,from2,to2;
        myFileIn >> from >> to;
        ///cin >> from >> to;
        from2=from;
        to2=to;
        from*=-1;
        if(from<0){
            from*=-1;
            from+=n;
        }
        if(to<0){
            to*=-1;
            to+=n;
        }
        if(from2<0){
            from2*=-1;
            from2+=n;
        }
        to2*=-1;
        if(to2<0){
            to2*=-1;
            to2+=n;
        }
        from--;
        to--;
        to2--;
        from2--;
        nbrs[from].push_back(to);
        nbrs[to2].push_back(from2);
        ///cout << from << " " << to << " rebro" << endl;
        ///cout << to2 << " " << from2 << " rebro" << endl;
    }

    for(int i = 0; i < 2*n; ++i)
    {
        index[i] = -1;
        lowLink[i] = -1;
    }

    for(int i = 0; i < 2*n; ++i)
    {
        if(index[i] == -1)
        {
            dfs(i);
        }
    }

    /*myfile << compCount << endl;
    for(int i = 0; i < output.size(); ++i)
    {
        if(output[i] == -1)
        {
            myfile << endl;
        }
        else
        {
            myfile << output[i] << " ";
        }
    }*/
    long long br=1;
    int i;
    for( i=0;i<output.size();i++){
        komp[output[i]]=br;
        if(output[i] == -1){
            br++;
        }else{
            if(output[i]>n){
                if(komp[output[i]]==komp[output[i]-n]){
                    ///cout << -1 << endl;
                    myfile << -1 << endl;
                    return 0;
                }
            }else{
                if(komp[output[i]]==komp[output[i]+n]){
                    myfile << -1 << endl;
                    return 0;
                }
            }
            if(ans[output[i]]==0){
                ans[output[i]]=1;
                if(output[i]>n){
                    ans[output[i]-n]=-1;
                }else{
                    ans[output[i]+n]=-1;
                }
            }
            ///cout << komp[output[i]] << " ";
        }
    }
    /*cout << endl;
    for( i=0;i<n*2;i++){
        cout << i+1 << " ";
    }
    cout << endl;
    cout << endl;*/
    for( i=1;i<=n;i++){
        if(ans[i]==-1){
            ans[i]=0;
        }
        myfile << ans[i] << " ";
    }
    myfile << endl;
    /*cout << endl;
    cout << compCount << endl;
    for( i = 0; i < output.size(); ++i)
    {
        if(output[i] == -1)
        {
            cout << endl;
        }
        else
        {
            cout << output[i] << " ";
        }
    }*/
    return 0;
}
