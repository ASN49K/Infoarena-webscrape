#include<bits/stdc++.h>
using namespace std;
ifstream in("2sat.in");
ofstream out("2sat.out");
const int NMAX = 100005;

vector<int> G[2*NMAX];
vector<int> GT[2*NMAX];
int N,M,st[2*NMAX],ctc[2*NMAX],nr_ctc,sz,viz[2*NMAX];

int grad(int a)
{

    if(a > 0)
        return 2*a;
    else
        return 2*a - 1;
}

void adauga(int x,int y)
{

    G[grad(-x)].push_back(grad(y));
    G[grad(-y)].push_back(grad(x));

    GT[grad(y)].push_back(grad(-x));
    GT[grad(x)].push_back(grad(-y));
}

void dfs(int nod)
{

    if(viz[nod])
        return ;
    viz[nod] = 1;
    for(vector<int>::iterator it = G[nod].begin() ; it != G[nod].end() ; ++it)
        if(!viz[*it])
            dfs(*it);
    st[++sz] = nod;
}

void comp_tare_conex(int nod)
{

    if(!viz[nod])
        return;
    viz[nod] = 0;
    ctc[nod] = nr_ctc;
    for(vector<int>::iterator it = GT[nod].begin() ; it != GT[nod].end() ; ++it)
        if(viz[*it])
            comp_tare_conex(*it);
}

int main()
{

    in>>N>>M;
    int a,b;
    for(int i = 1 ; i <= M ; ++i){

        in>>a>>b;
        adauga(a,b);
    }
    for(int i = 1 ; i <= 2*N ; ++i)
        if(!viz[i])
            dfs(i);
    for(int i = 2*N ; i > 0 ; --i)
        if(viz[st[i]]){
            ++nr_ctc;
            comp_tare_conex(st[i]);
        }
    for(int i = 1 ; i <= N ; ++i)
        if(ctc[grad(i)] == ctc[grad(-i)]){
            out<<-1;
            return 0;
        }
    for(int i = 1 ; i <= N ; ++i)
        out<<(ctc[grad(i)] > ctc[grad(-i)])<<" ";
    return 0;
}
