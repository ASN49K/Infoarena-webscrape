#include <bits/stdc++.h>

using namespace std;

ifstream f("2sat.in");
ofstream g("2sat.out");

const int N = 2e5;
int n, m, x, y, ind[N], low[N], indecs, comp[N], cnt, asignare[N / 2];
bool inStiva[N];
vector<int> c[N];
stack<int> s;

void tarjan(int nod){
    ind[nod] = low[nod] = indecs++;
    inStiva[nod] = 1;
    s.push(nod);
    for(int y: c[nod]){
        if(ind[y] == -1){
            tarjan(y);
            low[nod] = min(low[nod], low[y]);
        }else if(inStiva[y])
            low[nod] = min(low[nod], ind[y]);
    }

    if(ind[nod] == low[nod]){
        cnt++;
        int y;
        do{
            y = s.top();
            s.pop();
            inStiva[y] = 0;
            comp[y] = cnt;
        }while(y != nod);
    }
}

int main(){
    f >> n >> m;
    for(int i = 0; i < m; i++){
        f >> x >> y;
        if(x < 0)
            x = abs(x) * 2 - 1;
        else
            x = abs(x) * 2 - 2;

        if(y < 0)
            y = abs(y) * 2 - 1;
        else
            y = abs(y) * 2 - 2;

        c[(x % 2 == 0 ? x + 1 : x - 1)].push_back(y);
        c[(y % 2 == 0 ? y + 1 : y - 1)].push_back(x);
    }

    f.close();
    for(int i = 0; i < 2 * n; i++)
        ind[i] = -1;

    for(int i = 0; i < 2 * n; i++){
        if(ind[i] == -1)
            tarjan(i);
    }

    for(int i = 0; i < 2 * n; i += 2){
        if(comp[i] == comp[i + 1]){
            g << -1;
            return 0;
        }

        asignare[i / 2] = comp[i] < comp[i + 1];
    }

    for(int i = 0; i < n; i++)
        g << asignare[i] << ' ';

    g.close();
}
