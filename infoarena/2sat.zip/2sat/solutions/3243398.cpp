#include <fstream>
#include <vector>
using namespace std;
ifstream cin("2sat.in");
ofstream cout("2sat.out");
vector <int> g[200001],gi[200001];
vector <int> ctc[200001];
int l[200001],k,ok[200001],t;
bool rez[200001],ok2[200001];
void arc(int x, int y ,int n, vector <int> g[])
{
    if(x<0)
        x=-x+n;
    if(y<0)
        y=-y+n;
    g[x].push_back(y);
}
void dfs1(int nod)
{
    ok[nod]=-1;
    for(auto x : gi[nod])
    {
        if(ok[x]==0)
            dfs1(x);
    }
    l[++t]=nod;
}
void dfs2(int nod)
{
    ok[nod]=k;
    ctc[k].push_back(nod);
    for(auto x : g[nod])
    {
        if(ok[x]==-1)
            dfs2(x);
    }
}
bool check(int n)
{
    for(int i=1;i<=n;i++)
    {
        if(ok[i]==ok[i+n])
        {
            cout<<-1;
            return 0;
        }
        if(ok[i]<
           ok[i+n])
            rez[i]=1;
    }
    return 1;
}
int main()
{
    int n,m,i,x,y;
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y;
        arc(-x,y,n,g);
        arc(-y,x,n,g);
        arc(y,-x,n,gi);
        arc(x,-y,n,gi);
    }
    for(i=1;i<=n*2;i++)
    {
        if(ok[i]==0)
            dfs1(i);
    }
    for(i=n*2;i>=1;i--)
    {
        if(ok[l[i]]==-1)
        {
            k++;
            dfs2(l[i]);
        }
    }
    if(check(n))
    {
        for(i=1;i<=n;i++)
            cout<<rez[i]<<" ";
    }
    return 0;
}
