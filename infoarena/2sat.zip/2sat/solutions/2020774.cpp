#include <iostream>
#include <fstream>
#include <stack>
#include <vector>
#include <deque>
#include <ctime>
#include <queue>

#define ll long long
#define ull unsigned long long
#define pb push_back
#define mp make_pair
using zint = int;
using namespace std;
const int inf = 3e4 + 5;
const int NMax = 1e5 + 5;
const int MMax = 2e5 + 5;
ifstream in("2sat.in");
ofstream out("2sat.out");

// algoritm pentru a doua solutie;

zint N,M,P;
zint sol[NMax],aux[NMax];
pair<zint,zint> ex[MMax];
// sol[i] - 0 || 1; valoarea finala a literalului i;
// aux - contine valori temporare pentru vectorul sol;
// ex[i] contine literalii expresiei i;

struct elem {
    zint lit,nrE;
    elem (zint _lit = 0,zint _nrE = 0) {
        lit = _lit;
        nrE = _nrE;
    }
};
vector<elem> v[NMax];
// v[i][j].lit = un literal care se afla in aceeasi expresie cu literalul i;
// v[i][j].nrE = indexul expresiei care ii contine pe cei doi;

bool test(zint,zint);
// test(i,val) - return-eaza true daca se poate pune valoarea val pentru literalul i;
bool eval(zint);
// eval(i) - return-eaza rezultatul disjunctiei cu indexul i pentru valorile curente;
void cpy(zint*,zint*);
// cpy(a,b) - copiaza N valori din vectorul b in a;

int main() {
    in>>N>>M;
    for (int i=1;i <= M;++i) {
        zint x,y;
        in>>x>>y;
        ex[i] = mp(x,y);

        v[abs(x)].pb( elem(abs(y),i) );
        v[abs(y)].pb( elem(abs(x),i) );
    }

    for (int i=1;i <= N;++i) {
        sol[i] = -1;
    }

    bool ans = true;
    for (int i=1;i <= N;++i) {
        if (sol[i] != -1) {
            continue;
        }

        //cpy(aux,sol);
        bool ok = false;
        if (test(i,0)) {
            //sol[i] = 0;
            ok = true;
        }
        else if (test(i,1)) {
            //sol[i] = 1;
            ok = true;
        }

        if (ok) { // daca este compatibila una dintre valori, se pastreaza in sol valorile obtinute in aux pe parcursul functiei test;
            cpy(sol,aux);
        }
        else { // nu exista solutie daca nu se poate pune nici 0 nici 1 in literalul i;
            ans = false;
            break;
        }
    }

    if (ans) {
        for (int i=1;i <= N;++i) {
            out<<sol[i]<<' ';
        }
    }
    else {
        out<<"-1\n";
    }

    in.close();out.close();
    return 0;
}

bool test(zint idx,zint val) {
    cpy(aux,sol);
    aux[idx] = val;

    queue<zint> Q;
    Q.push(idx);
    while (Q.size()) {
        zint lit = Q.front();
        Q.pop();

        for (elem el : v[lit]) {
            zint nxt = el.lit, nr = el.nrE;
            if (aux[nxt] != -1) { // literalului nxt i s-a impus deja o valoare;
                if ( !eval(nr) ) {
                    return false;
                }

                continue;
            }

            bool val0 = false, val1 = false;
            aux[nxt] = 0;
            if ( eval(nr) ) {
                val0 = true;
            }
            aux[nxt] = 1;
            if ( eval(nr) ) {
                val1 = true;
            }

            if (val0) {
                if (val1) { // daca si 0 si 1 sunt compatibile, nu se impune nicio valoare pentru nxt;
                    aux[nxt] = -1;
                    continue;
                }
                aux[nxt] = 0;
            }
            else if (val1) {
                aux[nxt] = 1;
            }

            Q.push(nxt);
        }
    }

    return true;
}

bool eval(zint nr) {
    zint x = ex[nr].first,
        y = ex[nr].second,
        val1 = aux[abs(x)],
        val2 = aux[abs(y)];
    if (x < 0) { val1 ^= 1; }
    if (y < 0) { val2 ^= 1; }

    return (val1 | val2);
}

void cpy(zint* a,zint* b) {
    for (int i=1;i <= N;++i) {
        a[i] = b[i];
    }
}
