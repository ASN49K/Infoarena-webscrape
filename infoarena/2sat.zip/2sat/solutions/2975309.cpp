#include <fstream>
#include <vector>
#include <bitset>

using namespace std;

ifstream cin("2sat.in");
ofstream cout("2sat.out");

const int NMAX = 2 * 1e5;

vector <int> g[NMAX + 1], rg[NMAX + 1], topsort;
int comp[NMAX + 1], val[NMAX + 1], n, ctc;
bitset <NMAX + 1> viz;

int val_asoc(int x){

    if(x < 0)
        return -x + n;

}

int neg(int x){

    if(x <= n)
        return x + n;
    
    return x - n;
}

void dfs(int x){

    viz[x] = 1;
    for(auto &y : g[x])
        if(!viz[y])
            dfs(y);

    topsort.push_back(x);
}

void dfs2(int x){

    comp[x] = ctc;

    for(auto &y : rg[x])
        if(!comp[y])
            dfs2(y);

}

int main(){

    int m = 0;
    cin >> n >> m;

    for(int i = 0; i < m; i++){

        int x = 0, y = 0;
        cin >> x >> y;

        x = val_asoc(x);
        y = val_asoc(y);
        

        g[neg(x)].push_back(y);
        rg[y].push_back(neg(x));

        g[neg(y)].push_back(x);
        rg[x].push_back(neg(y));

    }

    for(int i = 1; i <= 2 * n; i++)
        if(!viz[i])
            dfs(i);

    int st = 0, dr = topsort.size() - 1;
    while(st <= dr){

        swap(topsort[st], topsort[dr]);
        st++, dr--;

    }

    for(auto &y : topsort){

        if(comp[y])
            continue;

        ctc++;
        dfs2(y);

    }

    bool sat = 1;
    for(int i = 1; i <= n; i++)
        if(comp[i] == comp[i + n])
            sat = 0;

    if(sat == 0){

        cout << "-1";
        return 0;

    }

    for(int i = 1; i <= n; i++)
        if(comp[i] < comp[i + n])
            cout << 0 << " ";
        else 
            cout << 1 << " ";


}