#include <bits/stdc++.h>
using namespace std;
ifstream in("2sat.in");
ofstream out("2sat.out");
int n;
inline int real(int a)
{
    if(a<0)
        return n+(-a);
    return a;
}
inline int neg(int a)
{
    if(a>n)
        return a-n;
    return a+n;
}
bool viz[200001];
int lista[200001];
queue <int> coada;
bool val[200001],done[200001];
vector <int> v[200001],rev[200001];
int cnt;
void dfs(int nod)
{
    viz[nod]=1;
    for(auto it:v[nod])
        if(!viz[it])
            dfs(it);
    lista[++cnt]=nod;
}
vector <int> noduri[200001];
vector <int> much[200001];
int comp[200001];
void dfsrev(int nod)
{
    viz[nod]=1;
    comp[nod]=cnt;
    noduri[cnt].push_back(nod);
    for(auto it:rev[nod])
        if(!viz[it])
            dfsrev(it);
}
int revv[200001],grad[200001];
int main()
{
    int m,i,a,b;
    in>>n>>m;
    for(i=1;i<=m;i++)
    {
        in>>a>>b;
        a=real(a);
        b=real(b);
        v[neg(a)].push_back(b);
        v[neg(b)].push_back(a);
        rev[a].push_back(neg(b));
        rev[b].push_back(neg(a));
    }
    for(i=1;i<=2*n;i++)
        if(!viz[i])
            dfs(i);
    for(i=1;i<=2*n;i++)
        viz[i]=0;
    cnt=0;
    for(i=2*n;i>=1;i--)
        if(!viz[lista[i]])
        {
            ++cnt;
            dfsrev(lista[i]);
        }
    int ok=1;
    for(i=1;i<=n;i++)
        if(comp[i]==comp[i+n])
            ok=0;
    if(ok==0)
        out<<-1;
    else
        for(i=1;i<=n;i++)
            out<<(comp[i]>comp[i+n])<<" ";
    return 0;
}