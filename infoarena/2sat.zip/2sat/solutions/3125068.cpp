#include <bits/stdc++.h>

using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
typedef pair<int,int> pii;
int n,m;
bool use[300005];
vector<pii> g;
int comp[300005],cul[300005];
int per[300005];
vector<int> muchii[300005],edges[300005];
vector<int> st;
int grad[300005];
int nr;
void dfs1(int nod)
{
    use[nod]=1;
    for(int i:muchii[nod])
        if(!use[i])
            dfs1(i);
    st.push_back(nod);
}
void dfs(int nod)
{
    use[nod]=1;
    comp[nod]=nr;
    for(int i:muchii[nod])
        if(!use[i])
            dfs(i);
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        muchii[-a+n].push_back(b+n);
        g.push_back({-a+n,b+n});
        muchii[-b+n].push_back(a+n);
        g.push_back({-b+n,a+n});
    }
    for(int i=-n;i<=n;i++)
        if(i!=0)
            if(!use[i+n])
                dfs1(i+n);
    reverse(st.begin(),st.end());
    for(int i=-n;i<=n;i++)
    {
        use[i+n]=0;
        muchii[i+n].clear();
    }
    for(auto i:g)
    {
        int a=i.first;
        int b=i.second;
        muchii[b].push_back(a);
    }
    for(int i:st)
        if(!use[i])
        {
            nr++;
            dfs(i);
        }
    for(int i=1;i<=n;i++)
        if(comp[i+n]==comp[-i+n])
        {
            fout<<-1;
            return 0;
        }
    for(auto i:g)
    {
        int a=i.first;
        int b=i.second;
        if(comp[a]!=comp[b])
        {
            edges[comp[a]].push_back(comp[b]);
            grad[comp[b]]++;
        }
    }
    queue<int> coada;
    for(int i=1;i<=nr;i++)
        if(grad[i]==0)
            coada.push(i);
    for(int i=-n;i<=n;i++)
        if(i!=0)
        {
            int c1=comp[i+n];
            int c2=comp[-i+n];
            per[c1]=c2;
            per[c2]=c1;
        }
    while(!coada.empty())
    {
        int x=coada.front();
        coada.pop();
        if(cul[x]!=1)
        {
            cul[x]=0;
            cul[per[x]]=1;
        }
        for(int i:edges[x])
        {
            grad[i]--;
            if(grad[i]==0)
                coada.push(i);
        }
    }
    for(int i=1;i<=n;i++)
        fout<<cul[comp[i+n]]<<' ';
    return 0;
}
