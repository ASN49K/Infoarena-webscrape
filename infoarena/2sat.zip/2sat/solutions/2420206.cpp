#include <bits/stdc++.h>

#define MAX_N 200000

using namespace std;

int rez;
int rz[MAX_N + 1];

int n, m;

vector <int> g[MAX_N + 1];

bool viz[MAX_N + 1];

int k;
int comp[MAX_N + 1];

int depth;
int nr[MAX_N + 1];
int low[MAX_N + 1];

int stkLen;
int stk[MAX_N + 1];

void add(int a, int b)
{
    g[a].push_back(b);
}

int op(int a)
{
    return (a <= n ? a + n : a - n);
}

void readFile()
{
    ifstream f("2sat.in");

    f >> n >> m;

    int a, b;
    for(int i = 1; i <= m; i ++)
    {
        f >> a >> b;

        if(a < 0)
            a = -a + n;

        if(b < 0)
            b = -b + n;

        add(op(a), b);
        add(op(b), a);
    }

    f.close();
}

void dfs(int a)
{
    if(rez == -1)
        return;

    viz[a] = 1;

    ++ depth;
    nr[a] = low[a] = depth;
    stk[++ stkLen] = a;
    for(auto u : g[a])
    {
        if(viz[u] == 0)
        {
            dfs(u);
            low[a] = min(low[a], low[u]);
        }

        else
            low[a] = min(low[a], nr[u]);
    }

    if(nr[a] == low[a])
    {
        k ++;

        int x;
        do
        {
            x = stk[stkLen --];
            comp[x] = k;

            if(rz[x] == 0)
            {
                rz[x] = 0;
                rz[op(x)] = 1;
            }

            if(comp[x] == comp[op(x)])
                rez = -1;
        }
        while(x != a);
    }

    if(rez == -1)
        return;
}

void solve()
{
    for(int i = 1; i <= (n << 1); i ++)
    {
        if(viz[i] == 0)
            dfs(i);
    }
}

void printFile()
{
    ofstream g("2sat.out");

    if(rez == -1)
        g << "-1\n";

    for(int i = 1; i <= n; i ++)
        g << rz[i] << " ";
    g << "\n";

    g.close();
}

int main()
{
    readFile();

    solve();

    printFile();

    return 0;
}
