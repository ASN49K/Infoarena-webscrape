#include <bits/stdc++.h>
#define NMAX 100009
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
vector<int>g[2*NMAX];
vector<int>gt[2*NMAX];
stack<int>H;
void citire();
vector<int> gr[2*NMAX],grt[2*NMAX];
int n,m,nrc,i,j;
int val[2*NMAX];
int de[2*NMAX];
struct tip{int x;int pl;};
queue<tip> Q,Q1;
int di[2*NMAX];
int sol[2*NMAX];
int pun(int k)
{
 if(k<0)
     return  k=-k+n;
 return k;
}
int neg(int k)
{
  if(k>n)
      return k-n;
  return k+n;
}
int uz[2*NMAX];
void dfs(int k)
{
   int i;
   uz[k]=1;
   for(i=0;i<g[k].size();i++)
    {
     int vec=g[k][i];
     if(!uz[vec])
            dfs(vec);
    }
    H.push(k);
}
void dfs1(int k)
{
 int i;
 uz[k]=nrc;
 for(i=0;i<gt[k].size();i++)
    {
     int vec=gt[k][i];
     if(!uz[vec])
        dfs1(vec);
    }
}
///gata
int main()
{citire();
 for(i=1;i<=n*2;i++)
      if(!uz[i])
       {dfs(i);}

 memset(uz,0,sizeof(uz));

 while(!H.empty())
    {
     int act=H.top();
     H.pop();
     if(!uz[act])
       {nrc++; dfs1(act);}
    }



for(i=1;i<=n;i++)
      if(uz[i]==uz[i+n])
{fout<<-1;return 0;}

 for(i=1;i<=2*n;i++)
     for(j=0;j< g[i].size();i++)
        {
         int vec=g[i][j];
         if(uz[i]!=uz[vec])
            {gr[uz[i]].push_back(uz[vec]);

             di[uz[i]]++;
             grt[uz[vec]].push_back(uz[i]);
             de[uz[vec]]++;
            }
        }

  for(i=1;i<=nrc;i++)
     {if(de[i]==0)
     Q.push({i,0});
     if(di[i]==0)
        Q1.push({i,nrc+1});
    }

    while(!Q.empty())
        {
         int act=Q.front().x;
         int place=Q.front().pl;
         sol[act]=place;
         Q.pop();
         for(i=0;i< gr[act].size();i++)
            {
             int vec=gr[act][i];
             de[vec]--;
             if(de[vec]==0)
             Q.push({vec,place+1});
            }
         act=Q1.front().x;
         place=Q1.front().pl;
         sol[act]=place;
         Q1.pop();
         for(i=0;i< grt[act].size();i++)
            {
             int vec=grt[act][i];
             di[vec]--;
             if(di[vec]==0)
             Q1.push({vec,place+1});
            }

        }



for(i=1;i<=n;i++)
    if(  sol[uz[i]]>nrc)
        fout<<0<<" ";
      else
        fout<<1<<" ";
     return 0;
}

void citire()
{
 int i;
 int x,y;
 fin>>n>>m;
 for(i=1;i<=m;i++)
    {
     fin>>x>>y;
     int cx=pun(x);
     int cy=pun(y);
     int nx,ny;
     nx=neg(cx);
     ny=neg(cy);
     g[nx].push_back(cy);
     gt[cy].push_back(nx);
     g[ny].push_back(cx);
     gt[cx].push_back(ny);

    }
}
