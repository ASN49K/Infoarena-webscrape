#include <bits/stdc++.h>

#define vt vector
#define pb push_back
#define em emplace
#define emb emplace_back

using ll = long long;
using ull = unsigned long long;
 
using namespace std;
 
inline void Open(const string Name) {
    #ifndef ONLINE_JUDGE
        (void)!freopen((Name + ".in").c_str(), "r", stdin);
        (void)!freopen((Name + ".out").c_str(), "w", stdout);
    #endif
}

void solve() {
    int n, m; cin >> n >> m;
    swap(n, m);
    vt <vt <int>> adj(2 * m + 1);
    vt <int> low(2 * m + 1, -1), tin(2 * m + 1, -1), inStack(2 * m + 1);
    stack <int> st;

    for(int i = 1;i <= m;i++) {
        char c1, c2;
        int u1, u2;
        cin >> u1 >> u2;

        if(u1 < 0) u1 = -u1, u1 = 2 * m - u1 + 1;
        if(u2 < 0) u2 = -u2, u2 = 2 * m - u2 + 1;

        adj[2 * m - u1 + 1].emb(u2);
        adj[2 * m - u2 + 1].emb(u1);
    }

    vt <int> vis(2 * m + 1), who(2 * m + 1);
    int timer = 0, cnt = 0;
    function <void(int)> dfs = [&](int v) {
        inStack[v] = 1;
        st.em(v);

        low[v] = tin[v] = ++timer;
        for(int u : adj[v]) {
            if(tin[u] == -1) {
                dfs(u);
                low[v] = min(low[v], low[u]);
            } else if(inStack[u] == 1) {
                low[v] = min(low[v], low[u]);
            }
        }

        if(low[v] == tin[v]) {
            ++cnt;
            int nod = 0;
            do {
                inStack[nod = st.top()] = 0;
                who[nod] = cnt;
                st.pop();
            }while(nod != v);
        }
    };

    for(int i = 1;i <= 2 * m;i++)
        if(tin[i] == -1) {
            dfs(i);
        }

    vt <char> ans(m + 1);
    for(int i = 1;i <= m;i++) {
        if(who[i] == who[2 * m - i + 1]) {
            cout << -1;
            return;
        }
        ans[i] = ((who[i] > who[2 * m - i + 1])? '1': '0');
    }

   for(int i = 1;i <= m;i++)  {
        cout << ans[i] << ' ';
   }
}
 
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
 
    Open("2sat");
 
    int T = 1;
    for(;T;T--) {
        solve();
    }
 
    return 0;
}