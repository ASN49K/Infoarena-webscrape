#include <cstdio>
#include <algorithm>
#include <vector>
#define Nmax 100005

using namespace std;

bool viz[Nmax*3];
int SortTop[Nmax*3],len,ans[Nmax*3],Bun,n;
vector <int> L[Nmax*3],T[Nmax*3];

inline int non(int x)
{
    if(x<=n) return x+n;
    return x-n;
}

inline void Dfs(int nod)
{
    viz[nod]=true;
    vector <int> ::iterator it;
    for(it=L[nod].begin();it!=L[nod].end();++it)
        if(!viz[*it]) Dfs(*it);
    SortTop[++len]=nod;
}

inline void Dfs2(int nod)
{
    if(ans[nod])
    {
        Bun=0; return;
    }
    viz[nod]=false; ans[nod]=0; ans[non(nod)]=1;
    vector <int> ::iterator it;
    for(it=T[nod].begin();it!=T[nod].end();++it)
        if(viz[*it]) Dfs2(*it);

}

int main()
{
    int m,x,y,i;
    vector <int> ::iterator it;
    freopen ("2sat.in","r",stdin);
    freopen ("2sat.out","w",stdout);
    scanf("%d%d", &n,&m);
    while(m--)
    {
        scanf("%d%d", &x,&y);
        if(x<0) x=-x+n;
        if(y<0) y=-y+n;
        L[non(x)].push_back(y);
        L[non(y)].push_back(x);
        T[y].push_back(non(x));
        T[x].push_back(non(y));
    }
    for(i=1;i<=n*2;++i)
       if(!viz[i])
            Dfs(i);
    reverse(SortTop+1,SortTop+len+1);
    for(i=Bun=1;i<=len && Bun;++i)
        if(viz[SortTop[i]] && viz[non(SortTop[i])]) Dfs2(SortTop[i]);
    if(!Bun) printf("-1\n");
    else
    {
        for(i=1;i<=n;++i) printf("%d ", ans[i]);
        printf("\n");
    }
    return 0;
}
