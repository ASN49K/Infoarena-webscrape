#include <cstdio>

#define file_in "2sat.in"
#define file_out "2sat.out"

int n,m,x[100],y[100],v[100],rez;

inline int abs(int a) { return a>=0?a:-a; }

int verif(int i)
{
	int a,b;
	a=v[abs(x[i])];
	b=v[abs(y[i])];
	if (x[i]<0)
		a^=1;
	if (y[i]<0)
		b^=1; 
	rez=a|b;		
}

int ok()
{
	for (int i=1;i<=m;++i)
		 if (!verif(i))
			 return 0;
		 return 1;
}

int main()
{
	int i,j;
	freopen(file_in,"r",stdin);
	freopen(file_out,"w",stdout);
	
	scanf("%d %d", &n, &m);
	
	for (i=1;i<=m;++i)
		 scanf("%d %d", &x[i], &y[i]);
	
	for (i=1;i<(1<<n);++i)
	{
		for (j=0;j<n;++j)
			 if (i&(1<<j))
				 v[j+1]=1;
			 else
				 v[j+1]=0;
		rez=0;
		if (ok())
		{
			for (j=1;j<=n;++j)
			 printf("%d ", v[j]);
		//printf("%d\n", rez);
			return 0;
		}
	}
	
	printf("-1\n");
	fclose(stdin);
	fclose(stdout);
	
	return 0;
	
}
