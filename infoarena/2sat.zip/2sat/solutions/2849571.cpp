#include <bits/stdc++.h> //Andrei Alexandru a.k.a Sho
#define ll long long
#define double long double
#pragma GCC optimize("O3")
#pragma GCC optimize("Ofast")
#define aint(a) (a).begin(), (a).end()
#define f first
#define s second
#define pb push_back
#define mp make_pair
#define pi pair
#define rc(s) return cout<<s,0
#define endl '\n'
#define mod 1000000007
#define PI 3.14159265359
#define INF 1000000005
#define LINF 1000000000000000005ll
#define CODE_START  ios_base::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;
ll n,m,sol[200005],check=0;
map<ll,ll>viz;
vector<ll>g[200005],gb[200005],v;
void dfs1(ll node){
viz[node]=1;
for(auto it : g[node]){
    if(viz[it]==0){
        dfs1(it);
    }
}
v.pb(node);
}
void dfs(ll node){
viz[node]=1;
if(!viz[(node^1)]){
    sol[node]=0;
}else sol[node]=1;
for(auto it : gb[node]){
    if(viz[it]==0){
        dfs(it);
        if(sol[it]!=sol[node]){
           check=-1;
        }
    }
}
}
int32_t main(){
CODE_START;
ifstream cin("2sat.in");
ofstream cout("2sat.out");
cin>>n>>m;
for(ll i=1;i<=m;i++)
{
    ll x,y;
    cin>>x>>y;
    ll xx,yy;
    xx=x;
    yy=y;
    if(x<0){
        x=-n;
    }
    if(y<0){
        y=-y;
    }
    x--;
    y--;
    x*=2;
    y*=2;
    if(xx<0){
        x^=1;
    }
    if(yy<0){
        y^=1;
    }
    g[x^1].pb(y);
    g[y^1].pb(x);
    gb[y].pb(x^1);
    gb[x].pb(y^1);
}
for(ll i=0;i<2*n;i++)
{
    if(!viz[i]){
            dfs1(i);
}
}
viz.clear();
while(v.size()){
    ll x=v.back();
    v.pop_back();
    if(viz[x]==0){
        dfs(x);
    }
}
if(check==-1){
    cout<<"-1"<<endl;
    return 0;
}
for(ll i=0;i<2*n;i+=2)
{
    cout<<sol[i]<<' ';
}
}
