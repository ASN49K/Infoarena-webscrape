#include<fstream>
#include<cstdlib>

using namespace std;
typedef int var;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

#define MAXN 200005

var EA[MAXN], EB[MAXN];
var n, m;
bool VAL[MAXN];

int main() {

    var a, b;

    fin>>n>>m;

    var B = 218749231;


    for(var i=1; i<=m; i++) {
        fin>>a>>b;
        EA[i] = a;
        EB[i] = b;
    }

    bool ok = 0;
    var pas = 0;
    while(!ok && pas <= 1000) {
        ok = 1;
        pas++;

        srand(B);
        B *= B;

        for(var i=1; i<=m; i++) {
            if(EA[i] > 0 && VAL[EA[i]])
                continue;
            if(EB[i] > 0 && VAL[EB[i]])
                continue;

            if(EA[i] < 0 && !VAL[-EA[i]])
                continue;
            if(EB[i] < 0 && !VAL[-EB[i]])
                continue;

            var ea = max(EA[i], -EA[i]);
            var eb = max(EB[i], -EB[i]);

            if(rand()%2) {
                VAL[ea] ^= 1;
            } else {
                VAL[eb] ^= 1;
            }
            ok = 0;
        }
    }

    if(pas > 100) {
        fout<<-1;
        return 0;
    }

    for(var i=1; i<=n; i++) {
        fout<<VAL[i]<<" ";
    }

    return 0;
}
