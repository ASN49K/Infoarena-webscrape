#include <iostream>
#include <fstream>
#include <stack>
#include <vector>
#include <bitset>

using namespace std;


const int nmax=2*1e5+2;
int n,m;
vector<int>adj[nmax];
vector<int>g[nmax];
stack<int>st;
bitset<nmax>ans,vis;
bool not_ok;

ifstream be("2sat.in");
ofstream ki("2sat.out");

int neg(int x)
{
    if(x<=n)
        return x+n;
    return x-n;
}

void dfs(int i)
{
    vis[i]=true;
    for(auto ni:adj[i])
    {
        if(!vis[ni])
            dfs(ni);
    }
    st.push(i);
}

void dfs1(int i)
{
    if(ans[i]==1)
        not_ok=true;
    vis[i]=true;
    ans[neg(i)]=1;
    for(auto ni : g[i])
        if(!vis[ni])
            dfs1(ni);

}

int main()
{
    be>>n>>m;
    int x,y;
    for(int i=1;i<=m;i++)
    {
        be>>x>>y;
        if(x<0)
            x=n-x;
        if(y<0)
            y=n-y;
        int negx=neg(x);
        int negy=neg(y);
        adj[negx].push_back(y);
        adj[negy].push_back(x);
        g[x].push_back(negy);
        g[y].push_back(negx);
    }
    for(int i=1;i<=2*n;i++)
        if(!vis[i])
            dfs(i);
    vis.reset();
    while(!st.empty())
    {
        x=st.top();
        st.pop();
        if(!vis[x] && !vis[neg(x)])
            dfs1(x);
    }
    if(not_ok)
        ki<<"-1\n";
    else {
        for(int i=1;i<=n;i++)
            ki<<ans[i]<<" ";
    }

    return 0;
}
