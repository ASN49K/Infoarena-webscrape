#include <iostream>
#include <fstream>
#include <algorithm>
#include <stack>
#include <vector>

///#include <tryhardmode>
///#include <GODMODE::ON>

using namespace std;

ifstream fin ("2sat.in");
ofstream fout ("2sat.out");

const int NMAX=1e5+5;

vector<int>v[NMAX];
vector<int>rev[NMAX];
vector<int>topos;

stack<int>stiva;
int comp[2*NMAX];

bool viz[NMAX];

int n;
int kon;

void dfs(int p)
{
    viz[p]=true;
    for(auto i:v[p])
    {
        if(!viz[i])
            dfs(i);
    }
    stiva.push(p);
}

void dfsc(int p)
{
    viz[p]=false;
    comp[p]=kon;
    for(auto i:rev[p])
    {
        if(viz[i])
            dfsc(i);
    }
}

int get_asoc(int p)
{
    if(p<0)
        return -p+n;
    else
        return p;
}

int get_not(int p)
{
   if(p<=n)
        return p+n;
    else
        return p-n;
}

int main()
{
    int m,i,j,a,b,x,y;
    bool ok=true;
    fin>>n>>m;
    for(i=1;i<=m;i++)
    {
        fin>>x>>y;
        x=get_asoc(x);
        y=get_asoc(y);
        a=get_not(x);
        b=get_not(y);
        v[a].push_back(y);
        rev[y].push_back(a);
        v[b].push_back(x);
        rev[x].push_back(b);
    }
    for(i=1;i<=2*n;i++)
        if(!viz[i])
            dfs(i);
    while(!stiva.empty())
    {
        int p=stiva.top();
        if(viz[p])
        {
            kon++;
            dfsc(p);
        }
        stiva.pop();
    }
    for(i=1;i<=n;i++)
        if(comp[i]==comp[i+n])
        {
            ok=false;
            break;
        }
    if(!ok)
        fout<<-1;
    else
    {
        for(i=1;i<=n;i++)
            if(comp[i]>comp[i+n])
                fout<<1<<" ";
            else
                fout<<0<<" ";
    }
    return 0;
}
