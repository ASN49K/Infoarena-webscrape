#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>

using namespace std;

const int Nmax = 100002;
const int Vmax = 500000;

int sol[Nmax];
pair<int,int> v[2 * Nmax];

int N, M;

inline int abs( int i )
{
    if ( i < 0 )
            return -i;
    else
            return i;
}

inline bool value(int i)
{
	int x = sol[ abs( v[i].first ) ], y = sol[ abs( v[i].second ) ];

	if ( v[i].first < 0 )  x ^= 1;
	if ( v[i].second < 0 ) y ^= 1;

	return x | y;
}

int main()
{
    ifstream f("2sat.in");
    ofstream g("2sat.out");

    f >> N >> M;

    for ( int i = 1; i <= M; ++i )
    {
        f >> v[i].first >> v[i].second;
    }

    srand( time( NULL ) );

    for ( int i = 1; i <= N; ++i )
            sol[i] = rand() % 2;

    for ( int i = 1; i <= Vmax; ++i )
    {
        for ( int j = 1; j <= M; ++j )
        {
            if ( value( j ) == 0 )
            {
                if ( rand() & 1 )
                        sol[ abs( v[j].first ) ]  ^= 1;
                else
                        sol[ abs( v[j].second ) ] ^= 1;

                break;
            }

            if ( j == M )
            {
                for ( int i = 1; i <= N; ++i )
                {
                    g << sol[i] << " ";
                }

                return 0;
            }
        }
    }

    g << "-1";

    return 0;
}
