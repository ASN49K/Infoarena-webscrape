#include <bits/stdc++.h>

using namespace std;

ifstream in("lp2.in");
ofstream out("lp2.out");

const int DIM = 1e5 + 7;

vector <int> v[2 * DIM];
vector <int> v_back[2 * DIM];

int n;

void F(int &nod)
{

    nod = ((nod < 1) ? (-nod + n) : (nod));
}

int Not(int nod)
{
    return (nod <= n ? nod + n : nod - n);
}

vector <int> st;

bitset <2 * DIM> vis;

int componenta[2 * DIM];

void dfs1(int nod)
{
    vis[nod] = true;

    for(auto i : v[nod])
        if(vis[i] == 0)
            dfs1(i);

    st.push_back(nod);
}

vector <int> CTC[2 * DIM];

int nr;

void dfs2(int nod)
{
    componenta[nod] = nr;

    CTC[nr].push_back(nod);

    for(auto i : v_back[nod])
        if(componenta[i] == 0)
            dfs2(i);
}

int sol[2 * DIM];

void atrib(int ord)
{
    vis[ord] = false;

    for(auto i : CTC[ord])
    {
        sol[i] = 2;
        sol[Not(i)] = 1;
    }
}

void dfs3(int nod)
{
    atrib(nod);

    for(auto i : CTC[nod])
        for(auto j : v[i])
            if(vis[componenta[j]] == true && sol[CTC[componenta[j]][0]] == 0)
                dfs3(componenta[j]);
}

int main()
{
    int m;
    in >> n >> m;

    while(m--)
    {
        int x, y;
        in >> x >> y;

        F(x);
        F(y);

        int X = Not(x);
        int Y = Not(y);

        v[X].push_back(y);
        v[Y].push_back(x);

        v_back[y].push_back(X);
        v_back[x].push_back(Y);
    }

    for(int i = 1; i <= 2 * n; i++)
        if(vis[i] == 0)
            dfs1(i);

    for(int i = 2 * n; i >= 1; i--)
        if(componenta[i] == 0)
        {
            nr++;

            dfs2(st[i - 1]);
        }

    for(int i = 1; i <= n; i++)
        if(componenta[i] == componenta[i + n])
        {
            out << -1;
            return 0;
        }

    int start = st[2 * n - 1];

    dfs3(componenta[start]);

    for(int i = 1; i <= n; i++)
        if(sol[i] == 0)
        {
            out << -1;
            return 0;
        }
        else
        {
            if(sol[i] == 2)
                sol[i] = 0;
        }

    for(int i = 1; i <= n; i++)
        out << sol[i] << ' ';
}
