#include <bits/stdc++.h>

using namespace std;

ifstream in("2sat.in");
ofstream out("2sat.out");

int n,m,b[200005],nrc;
vector<int> graf[200005],graf1[200005];

stack<int> st;
bool viz[200005];

int NOT(int x)
{
	if(x<0)
		return -x;
	return x+n;
}

void dfs(int nod,vector<int> x[],int ok)
{
	viz[nod]=1;
	if(ok==1) b[nod]=nrc;
	for(auto a:x[nod])
		if(!viz[a])
			dfs(a,x,ok);
	if(ok==0) st.push(nod);

}

int NRM(int x)
{
	if(x<0)
		return n-x;
	return x;
}
vector<int> ans;

int main()
{
	in>>n>>m;
	for(int i=1;i<=m;i++)
	{
		int x,y;
		in>>x>>y;
		graf[NOT(x)].push_back(NRM(y));
		graf[NOT(y)].push_back(NRM(x));
		
		graf1[NRM(x)].push_back(NOT(y));
		graf1[NRM(y)].push_back(NOT(x));

	}
	for(int i=1;i<=2*n;i++)
		if(!viz[i])
			dfs(i,graf,0);
	memset(viz,0,sizeof(viz));
	while(!st.empty())
	{
		int node=st.top();
		st.pop();
		if(viz[node]==0)
		{
			nrc++;
			dfs(node,graf1,1);
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(b[i]==b[i+n])
		{
			out<<"-1";
			return 0;
		}
		if(b[i]>b[i+n])
			ans.push_back(1);	
		else
			ans.push_back(0);
	}
	for(auto x:ans)
		out<<x<<" ";
	return 0;
}
