#include<stdio.h>
#include<stdlib.h>
#define N 200001
long n,m,a[N],b[N],i,*g[N],deg[N]={0},c[N],s[N],ss,v[N],l[N],q[N],sq=0,j,k,r,nr,ind,p[N];

void tarjan(long i,long *nr,long *ind)
{long j,r,k,e,f;
s[++ss]=i;
if(v[i]==0)
      v[i]=1;
c[i]=(*ind);
l[i]=(*ind)++;
for(j=0;j<deg[i];j++)
if(c[g[i][j]]==0)
      {tarjan(g[i][j],nr,ind);
      if(l[i]>l[g[i][j]])
             l[i]=l[g[i][j]];}
else
      if(v[g[i][j]]==1&&l[i]>c[g[i][j]])
             l[i]=c[g[i][j]];
if(c[i]==l[i])
      {while(ss)
             {r=s[ss--];
             if(r!=i&&v[r]==1)
                     q[++sq]=r,v[r]=2;
             else
                     break;}
      if(v[i]==1)
             v[i]=2,q[++sq]=i;
      f=-1;
      for(e=1;e<=sq;e++)
      if(p[q[e]]!=N)
             {f=p[q[e]];
             break;}
      for(e=1;e<=sq;e++)
      if(p[q[e]]==N)
             if(f==-1||f==1)
                     {p[q[e]]=1;
                     if(q[e]>n)
                               p[q[e]-n]=0;
                     else
                               p[q[e]+n]=0;}
             else
                     {p[q[e]]=0;
                     if(q[e]>n)
                               p[q[e]-n]=1;
                     else
                               p[q[e]+n]=1;}
      sq=0;}}

int main()
{freopen("2sat.in","r",stdin);
freopen("2sat.out","w",stdout);
scanf("%ld%ld",&n,&m);
for(i=1;i<=m;i++)
       {scanf("%ld%ld",&a[i],&b[i]);
       if(a[i]<0)
              deg[n-a[i]]++;
       else
              deg[a[i]]++;
       if(b[i]<0)
              deg[n-b[i]]++;
       else
              deg[b[i]]++;}
for(j=1;j<=2*n;deg[j++]=0)
       {g[j]=(long*)malloc(deg[j]*sizeof(long));
       p[j]=N;}
for(k=1;k<=m;k++)
       {if(a[k]<0)
              a[k]=n-a[k];
       if(b[k]<0)
              b[k]=n-b[k];
       if(a[k]>n)
             g[a[k]-n][deg[a[k]-n]++]=b[k];
       else
             g[n+a[k]][deg[n+a[k]]++]=b[k];
       if(b[k]>n)
             g[b[k]-n][deg[b[k]-n]++]=a[k];
       else
             g[n+b[k]][deg[n+b[k]]++]=a[k];}
nr=ind=ss=0;
for(i=1;i<=2*n;i++)
if(c[i]==0)
      tarjan(i,&nr,&ind);
for(i=1;i<=m;i++)
if(p[b[i]]==0&&p[a[i]]==0)
      {printf("-1");
      return 0;}
for(i=1;i<=n;i++)
if(p[i]==N)
      printf("0 ");
else
      printf("%ld ",p[i]);
fclose(stdin);
fclose(stdout);
return 0;}
