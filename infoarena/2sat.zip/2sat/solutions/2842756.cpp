#include <bits/stdc++.h>
using namespace std;

#ifdef LOCAL
ifstream in("in.in");
ofstream out("out.out");
#else
ifstream in("2sat.in");
ofstream out("2sat.out");
#endif

///this find the strongly connected components of directed
///graph g. It assumes the nodes in g are 1-indexed.
///the return value is a vector containing vectors representing
///the strongly connected components, by nodes.

unordered_map<int,int> vis,tout;
int nr,n,m;
vector<int> List;
void dfs(int node, unordered_map<int,vector<int>> &g) {
    vis[node] = 1;
    for (auto k : g[node]) {
        if (vis[k] == 0) {
            vis[k] = 1;
            dfs(k ,g);
        }
    }
    tout[node] = ++nr;
    List.push_back(node);
}
vector<int> component;
void dfs2(int node, unordered_map<int,vector<int>> &g) {
    vis[node] = 1;
    component.push_back(node);
    for (auto k : g[node]) {
        if (vis[k] == 0) {
            vis[k] = 1;
            dfs2(k ,g);
        }
    }
}

vector<vector<int>> scc(unordered_map<int,vector<int>> &g) {
    unordered_map<int,vector<int>> revG;
    for (int i = -n; i <= n; i++) {
        if (i == 0) continue;

        for (auto k : g[i]) {
            revG[k].push_back(i);
        }
    }

    nr = 0;
    tout.clear();
    vis.clear();

    for (int i = -n; i <= n; i++) {
        if (i == 0) continue;

        if (vis[i] == 0) {
            dfs(i, g);
        }
    }

    vis.clear();
    nr = 0;
    vector<vector<int>> res;
    for (int i = List.size() - 1; i >= 0; i--) {
        int node = List[i];
        if (vis[node] == 0) {
            nr++;
            component.clear();
            dfs2(node, revG);
            res.push_back(component);
        }
    }
    return res;
}
int main() {
    in >> n >> m;

    unordered_map<int,vector<int>> g;
    ///we add n to everyone, so that 1 becomes n + 1, -1 becomes n , -n + n becomes 0 and n + n becomes 2*n.
    for (int i = 1; i <= m; i++) {
        int u,v;
        in >> u >> v;
        g[-1 * u].push_back(v);
        if (u != v) {
            g[-1 * v].push_back(u);
        }
    }

    vector<vector<int>> desc = scc(g);

    vector<int> val(n + 1);

    unordered_map<int,int> visited;

    auto mod = [](int x) {
        if (x > 0) return x;
        return -x;
    };

    for (int i = 0; i < desc.size(); i++) {
        for (auto k : desc[i]) {
            int node = mod(k);
            if (visited[node] == 0) {
                visited[node] = i + 1;
            } else {
                if (visited[node] == i + 1) {
                    out << "-1\n";
                    return 0;
                }
            }
        }
    }
    for (int i = desc.size() / 2; i < desc.size(); i++) {
        for (auto k : desc[i]) {
            if (k > 0) {
                val[k] = 1;
            } else {
                val[-k] = 1;
            }
        }
    }

    for (int i = 1; i <= n; i++) {
        out << val[i] << " ";
    }out << "\n";
    return 0;
}
