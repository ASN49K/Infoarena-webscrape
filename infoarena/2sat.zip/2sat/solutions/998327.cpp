
#include <cstdio>
#include <vector>
#include <algorithm>
#include <utility>
#include <queue>
#include <bitset>

typedef std::pair<int,int> Exp;

const int MAX_N(100005);
const int MAX_M(200005);

int n, m;
Exp v [MAX_M];
std::vector<int> Graph [MAX_N << 1];
std::vector<int> Transpose [MAX_N << 1];
int Value [MAX_N << 1];
std::bitset<MAX_N << 1> Mark;
std::deque<int> Sort;
bool Valid(true);

inline void Read (void)
{
	std::freopen("2sat.in","r",stdin);
	std::scanf("%d %d",&n,&m);
	for (int i(1) ; i <= m ; ++i)
	{
		std::scanf("%d %d",&v[i].first,&v[i].second);
		if (v[i].first < 0)
			v[i].first = - v[i].first + n;
		if (v[i].second < 0)
			v[i].second = -v[i].second + n;
	}
	std::fclose(stdin);
}

inline void Print (void)
{
	std::freopen("2sat.out","w",stdout);
	if (Valid)
		for (int i(1) ; i <= n ; ++i)
			std::printf("%d ",Value[i]);
	else
		std::printf("-1");
	std::putchar('\n');
	std::fclose(stdout);
}

inline int Non (const int VALUE)
{
	return VALUE + (VALUE <= n ? n : -n);
}

inline void Build (void)
{
	for (int i(1), x, y ; i <= m ; ++i)
	{
		x = Non(v[i].first);
		y = v[i].second;
		Graph[x].push_back(y);
		Transpose[y].push_back(x);
		x = Non(v[i].second);
		y = v[i].first;
		Graph[x].push_back(y);
		Transpose[y].push_back(x);
	}
}

void Toposort (int node)
{
	for (auto it : Graph[node])
		if (!Mark[it])
		{
			Mark[it] = true;
			Toposort(it);
		}
	Sort.push_front(node);
}

void DepthFirstSearch (int node)
{
	Mark[node] = true;
	if (Value[node])
	{
		Valid = false;
		return;
	}
	Value[Non(node)] = 1;
	for (auto it : Transpose[node])
		if (!Mark[it])
			DepthFirstSearch(it);
}

inline void Kosaraju (void)
{
	for (int i(1) ; i <= n ; ++i)
		if (!Mark[i])
		{
			Mark[i] = true;
			Toposort(i);
		}
	Mark.reset();
	for (auto it : Sort)
		if (!(Value[it] || Value[Non(it)]))
			DepthFirstSearch(it);
}

int main (void)
{
	Read();
	Build();
	Kosaraju();
	Print();
	return 0;
}

