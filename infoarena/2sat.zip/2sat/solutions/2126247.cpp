#include <bits/stdc++.h>

#if 1
#define pv(x) cout<<#x<<" = "<<x<<"; ";cout.flush()
#define pn cout<<endl
#else
#define pv(x)
#define pn
#endif

using namespace std;
ifstream in("2sat.in");
ofstream out("2sat.out");

using ll = long long;
using ull = unsigned long long;
using uint = unsigned int;
#define pb push_back
#define mp make_pair
const int NMax = 1e5 + 5;
const int MMax = 2e5 + 5;
const int inf = 1e9 + 5;
using zint = int;

int N,M;
char sol[NMax],aux[NMax];
pair<int,int> ex[MMax];
vector< pair<int,int> > v[NMax];

bool test(int,int);
bool eval(int);
void cpy(char*,char*);

int main() {
    in>>N>>M;
    for (int i = 1;i <= M;++i) {
        int x,y;
        in>>x>>y;

        ex[i].first = x;
        ex[i].second = y;

        v[abs(x)].pb( {abs(y),i} );
        v[abs(y)].pb( {abs(x),i} );
    }

    memset(sol, -1, N);

    bool ans = true;
    for (int i = 1;i <= N;++i) {
        if (sol[i] != -1) {
            continue;
        }

        if (test(i,0) || test(i,1)) {
            cpy(sol,aux);
        }
        else {
            ans = false;
            break;
        }
    }

    if (ans) {
        for (int i = 1;i <= N;++i) {
            out<<(int)sol[i]<<' ';
        }
    }
    else {
        out<<-1;
    }

    in.close();out.close();
    return 0;
}

bool test(int idx,int val) {
    cpy(aux,sol);
    aux[idx] = val;

    queue<int> Q;
    Q.push(idx);
    while (Q.size()) {
        int lit = Q.front();
        Q.pop();

        for (auto p : v[lit]) {
            int nxt = p.first, nrExp = p.second;

            if (aux[nxt] != -1) {
                if (eval(nrExp) == false) {
                    return false;
                }
                continue;
            }

            aux[nxt] = 0;
            bool val0 = eval(nrExp);

            aux[nxt] = 1;
            bool val1 = eval(nrExp);

            if (val0) {
                if (val1) {
                    aux[nxt] = -1;
                    continue;
                }

                aux[nxt] = 0;
            }
            else if (val1) {
                aux[nxt] = 1;
            }

            Q.push(nxt);
        }
    }

    return true;
}

bool eval(int idx) {
    int x = ex[idx].first,
        y = ex[idx].second,
        valx = aux[abs(x)],
        valy = aux[abs(y)];

    if (x < 0) { valx ^= 1; }
    if (y < 0) { valy ^= 1; }

    return valx || valy;
}

void cpy(char* a,char* b) {
    for (int i = 1;i <= N;++i) {
        a[i] = b[i];
    }
}
