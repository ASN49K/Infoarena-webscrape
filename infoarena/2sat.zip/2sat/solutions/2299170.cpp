#include <iostream>
#include <stack>
#include <vector>
#include <set>
#include <fstream>
#define UNVISITED -1
using namespace std;
stack<int> s;
int ID;
struct NOD
{
    int id,low,rez;

    bool onstack,conexa;
    NOD()
    {
        onstack=conexa=false;
        id=UNVISITED;
        rez=-1;
    }
};
vector<int> v[200003];
NOD nod[200003];
vector<int> rez;
bool df(int i)
{
    nod[i].id=nod[i].low=++ID;
    nod[i].onstack=true;
    s.push(i);
    for(vector<int>::iterator j=v[i].begin();j!=v[i].end();j++)
    {
        if(nod[*j].id==UNVISITED)
            df(*j);
        if(nod[*j].onstack)
            nod[i].low=min(nod[i].low,nod[*j].low);
    }
    if(nod[i].low==nod[i].id)
    {
        int node;
        do
        {
            node=s.top();
            s.pop();
            nod[node].onstack=false;
            nod[node].conexa=true;
            rez.push_back(node);
            if(nod[node].rez==-1)
            {
                nod[node].rez=1;
                nod[node^1].rez=0;
            }
        }while(node!=i);
        for(int i=0;i<rez.size();i++)
            if(nod[node].conexa && nod[node^1].conexa)
                return false;
            else
                nod[node].conexa=nod[node^1].conexa=false;
    }
    return true;

}
int n,m;
int main()
{
    ifstream f("2sat.in");
    f>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        f>>a>>b;
        a= a<0? (-a)*2+1 : a*2;
        b= b<0? (-b)*2+1 : b*2;
        v[a^1].push_back(b);
        v[b^1].push_back(a);
    }
    ofstream g("2sat.out");
    bool exista=true;
    f.close();
    for(int i=2;i<=n*2;i+=2)
        if(nod[i].id==UNVISITED)
            if(!df(i))
            {
                g<<-1;
                exista=false;
            }
    if(exista)
    for(int i=2;i<=n*2;i+=2)
        g<<nod[i].rez<<' ';
    g.close();
    return 0;
}
