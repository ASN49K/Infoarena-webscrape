#include <algorithm>
#include <bitset>
#include <cstdio>
#include <vector>

using namespace std;

const int Nmax = 100005;

vector<int> G[2 * Nmax];
bitset<2 * Nmax> V, Values;
int SortedNodes[2 * Nmax];

pair<int, int> E[2 * Nmax];

int N, M, P;

inline int Non(const int node)
{
    return (node > N ? node - N: node + N);
}

void Dfs(const int node)
{
    V[node] = 1;
    for (const auto next: G[node])
        if (!V[next])
            Dfs(next);

    SortedNodes[++P] = node;
}

int main()
{
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);

    scanf("%d%d", &N, &M);

    for (int i = 1; i <= M; i++)
    {
        int x, y;
        scanf("%d%d", &x, &y);

        if (x < 0) x = N - x;
        if (y < 0) y = N - y;

        G[Non(x)].push_back(y);
        G[Non(y)].push_back(x);

        E[i] = make_pair(x, y);
    }

    for (int i = 1; i <= 2 * N; i++)
        if (!V[i])
            Dfs(i);

    for (int i = 2 * N; i; i--)
    {
        const int node = SortedNodes[i];

        if (!Values[node] && !Values[Non(node)])
            Values[Non(node)] = 1;
    }

    for (int i = 1; i <= M; i++)
    {
        if (!Values[E[i].first] && !Values[E[i].second])
        {
            printf("-1\n");
            return 0;
        }
    }

    for (int i = 1; i <= N; i++)
        printf("%d ", Values[i] ? 1: 0);

    printf("\n");
}
