#include <bits/stdc++.h>

using namespace std;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

int n, m, nrc;
int sol[100001];
vector<int> G[200001], GT[200001];
int ctc[200001];
bool ap[200001];
stack<int> stiva;
set<int> GCTC[200001];
int poz[200001];

int non(int x)
{
    if(x <= n)
        return x + n;
    return x - n;
}

void Citire()
{
    int i, a, b;
    fin >> n >> m;
    for(i = 1; i <= m; i++)
    {
        fin >> a >> b;
        if(a < 0)
            a = non(-a);
        if(b < 0)
            b = non(-b);
        G[non(a)].push_back(b);
        G[non(b)].push_back(a);
        GT[b].push_back(non(a));
        GT[a].push_back(non(b));
    }
}

void initializare()
{
    int i;
    for(i = 1; i <= 2 * n; i++)
        ap[i] = 0;
}

void dfs(int k)
{
    ap[k] = 1;
    for(int x : G[k])
        if(!ap[x])
            dfs(x);
    stiva.push(k);
}

void dfsGT(int k)
{
    ctc[k] = nrc;
    for(int x : GT[k])
        if(ctc[x] == 0)
            dfsGT(x);
}

void Kosaraju()
{
    int i;
    for(i = 1; i <= 2 * n; i++)
        if(!ap[i])
            dfs(i);
    while(!stiva.empty())
    {
        int x = stiva.top();
        stiva.pop();
        if(ctc[x] == 0)
        {
            nrc++;
            dfsGT(x);
        }
    }
}

bool Exista_Solutie()
{
    int i;
    for(i = 1; i <= n; i++)
        if(ctc[i] == ctc[i + n])
            return false;
    return true;
}

void dfsGCTC(int k)
{
    ap[k] = 1;
    for(int x : GCTC[k])
        if(!ap[x])
            dfsGCTC(x);
    stiva.push(k);
    poz[k] = stiva.size();
}

void Sortare_Topologica()
{
    int i;
    initializare();
    for(i = 1; i <= nrc; i++)
        if(!ap[i])
            dfsGCTC(i);
}

void Solutie()
{
    int i;
    for(i = 1; i <= n; i++)
        if(poz[ctc[i]] > poz[ctc[i + n]])
            fout << 0 << " ";
        else
            fout << 1 << " ";
}

int main()
{
    Citire();
    Kosaraju();
    if(!Exista_Solutie())
        fout << -1;
    else
    {
        int i, j;
        for(i = 1; i <= 2 * n; i++)
            for(j = 0; j < G[i].size(); j++)
                if(ctc[i] != ctc[G[i][j]])
                    GCTC[ctc[i]].insert(ctc[G[i][j]]);
        Sortare_Topologica();
        Solutie();
    }
    return 0;
}
