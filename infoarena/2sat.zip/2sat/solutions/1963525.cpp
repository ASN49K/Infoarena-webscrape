#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream in("2sat.in");
ofstream out("2sat.out");

vector<int> E[200003];
int values[200003];
int disc[200003];
int low[200003];
int parent[200003];
bool inS[200003];
int tim;
vector<int> ctc[200003];
int val[200003];
int amC;
stack<int> S;
int n;

inline int op(int nod) {
    return (nod-n)*(-1) + n;
}

void tarjan(int nod) {

    if(disc[nod] != 0)
        return;
    //cout << nod << '\n';
    disc[nod] = ++tim;
    low[nod] = disc[nod];
    inS[nod] = true;
    S.push(nod);

    for(int i = 0; i < E[nod].size(); i++) {
        if(disc[E[nod][i]] == 0) {
            parent[E[nod][i]] = nod;
            tarjan(E[nod][i]);
            low[nod] = min(low[nod], low[E[nod][i]]);
        } else if(inS[E[nod][i]]) {
            low[nod] = min(low[nod], low[E[nod][i]]);
        }
    }

    if(low[nod] == disc[nod]) {
        amC++;
        //cout << "TEST " << '\n';
        int crr;
        do {
            crr = S.top();
            ctc[amC].push_back(crr);
            S.pop();
            inS[crr] = false;
        } while(crr != nod);
    }

}

int main() {

    int m;
    in >> n >> m;
    int x,y;

    for(int i = 1; i <= m; i++) {
        in >> x >> y;
        x *= -1;
        E[x+n].push_back(y+n);
        //cout << x+n << " " << y+n << '\n';
        x *= -1;
        y *= -1;
        E[y+n].push_back(x+n);
        //cout << y+n << " " << x+n << '\n';
    }

    for(int i = 0; i <= 2*n; i++) {
        if(disc[i] == 0 && i != n)
            tarjan(i);
    }

    for(int i = amC; i >= 1; i--) {
        if(val[op(ctc[i][0])] != 0) {
            for(int j = 0; j < ctc[i].size(); j++) {
                if(val[ctc[i][j]] != 0) {
                    cout << -1;
                    return 0;
                }
                val[ctc[i][j]] = 2;
            }
        } else {
            for(int j = 0; j < ctc[i].size(); j++) {
                if(val[ctc[i][j]] != 0) {
                    cout << -1;
                    return 0;
                }
                val[ctc[i][j]] = 1;
            }
        }
    }

    for(int i = n+1; i <= 2*n; i++)
        out << val[i]-1 << " ";

    return 0;
}
