#include <iostream>

using namespace std;

int main()
{
    int a,b,c,Max,Min;
    cin>>a>>b>>c;
    Min=a;
    if(Min>b)Min=b;
    if(Min>c)Min=c;

    Max=a;
    if(Max<b)Max=b;
    if(Max<c)Max=c;
    cout<<Max-Min;

    return 0;
}
