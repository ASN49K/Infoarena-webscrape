#include <stdio.h>
#include <vector>

#define magic_sauce inline __attribute__((always_inline))

magic_sauce int min( int a, int b ){ return a < b ? a : b; }

const int MAXN = 1e5;
const int MAX_NODE = 2 * MAXN;
const int NIL = -1;

std::vector<int> fwd[MAX_NODE];

char viz[MAX_NODE];
int lvl[MAX_NODE];
int time;

int ctc_stack[MAX_NODE];
int ctc_sp;
int ctc_id[MAX_NODE];

std::vector<int> comp[MAX_NODE];
int ncomp;

bool ctc_truth[MAX_NODE];
bool var[MAXN];

void varsa_ctc( int u ){
  int v;

  do{
    v = ctc_stack[--ctc_sp];
    comp[ncomp].push_back( v );
    ctc_id[v] = ncomp;
  }while( v != u );

  ncomp++;
}

int ctc( int u ){
  int lvlu = time++;
  
  ctc_stack[ctc_sp++] = u;
  viz[u] = true;
  
  for( int v : fwd[u] ){
    if( !viz[v] )
      lvlu = min( lvlu, ctc( v ) );
    else if( lvl[v] != NIL )
      lvlu = min( lvlu, lvl[v] );
  }

  if( lvlu >= lvl[u] )
    varsa_ctc( u );

  lvl[u] = NIL;

  return lvlu;
}

int main(){
  FILE *fin  = fopen( "2sat.in", "r" );
  FILE *fout = fopen( "2sat.out", "w" );

  int n, m, i, a, b;

  fscanf( fin, "%d %d", &n, &m );

  for( i = 0 ; i < m ; i++ ){
    fscanf( fin, "%d%d", &a, &b );

    if( a > 0 )
      a = (a << 1);
    else
      a = ((-a) << 1) | 1;

    if( b > 0 )
      b = (b << 1);
    else
      b = ((-b) << 1) | 1;

    a -= 2;
    b -= 2;

    fwd[a].push_back( b ^ 1 );
    fwd[b].push_back( a ^ 1 );
  }

  for( i = 0 ; i < 2 * n ; i++ ){
    viz[i] = false;
    lvl[i] = NIL;
  }

  time = 0;
  ncomp = 0;
  ctc_sp = 0;

  for( i = 2 * n ; i-- ; )
    if( !viz[i] )
      ctc( i );

  for( i = 0 ; i < n ; i++ )
    if( ctc_id[i * 2] == ctc_id[i * 2 + 1] ){
      fputs( "-1\n", fout );
      fclose( fin );
      fclose( fout );
      return 0;
    }

  for( i = 0 ; i < ncomp ; i++ )
    ctc_truth[i] = false;

  for( i = ncomp ; i-- ; )
    if( !ctc_truth[i] )
      ctc_truth[ctc_id[1 ^ comp[i].front()]] = true;
    else{
      for( int u : comp[i] )
        var[u >> 1] = u & 1;
    }

  for( i = 0 ; i < n ; i++ ){
    fputc( '0' + var[i], fout );
    fputc( ' ', fout );
  }

  fputc( '\n', fout );

  fclose( fin );
  fclose( fout );
  return 0;
}
