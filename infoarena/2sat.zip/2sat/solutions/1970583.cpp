#include <fstream>
#include <cstring>
#include <vector>
#include <algorithm>
#include <stack>
#include <iomanip>
#include <queue>
using namespace std;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

#define nmax 200010
vector <int> v[nmax],vt[nmax];
int stk[nmax],n,m,i,nr;
bool val[nmax],use[nmax],posibil;

int non(int x)
{
    if (x<=n)
        return x+n;
    return x-n;
}

void topsort(int x)
{
    use[x]=1;
    for (int i=0; i<v[x].size(); i++)
        if (!use[v[x][i]])
            topsort(v[x][i]);
    stk[++nr]=x;
}

void dfs(int x)
{
    if (val[x])
        posibil=0;
    use[x]=0;
    val[non(x)]=1;
    for (int i=0; i<vt[x].size(); i++)
        if (use[vt[x][i]])
        dfs(vt[x][i]);
}

int main()
{
    fin >> n >> m;
    posibil=1;
    for (i=1; i<=m; i++)
    {
        int a,b;
        fin >> a >> b;
        if (a<0)
            a=non(-a);
        if (b<0)
            b=non(-b);
        v[non(a)].push_back(b);
        v[non(b)].push_back(a);
        vt[b].push_back(non(a));
        vt[a].push_back(non(b));
    }
    for (i=1; i<=2*n; i++)
        if (!use[i])
            topsort(i);
    for (i=2*n; i; i--)
        if (use[stk[i]]&&use[non(stk[i])])
            dfs(stk[i]);
    if (!posibil)
    {
        fout << "-1\n";
        return 0;
    }
    for (i=1; i<=n; i++)
        fout << val[i] << ' ';
    fout << '\n';
}
