#include <bits/stdc++.h>
#include <cassert>
#define g (graf+100010)
#define t (graft+100010)
#define viz (vizitat+100010)
#define comp (componenta+100010)
#define val (valori+100010)
#define nd (nodrandom+100010)

using namespace std;

int n, m;
vector<int> graf[200020];
vector<int> graft[200020];
int vizitat[200020];
int st[200020];
int lst;
int componenta[200020];
int nodrandom[200020];
int valori[200020];

void dfs(int n)
{
    viz[n] = 1;
    for(int i = 0; i < g[n].size(); i++)
        if(viz[g[n][i]] == 0)
            dfs(g[n][i]);
    st[lst++] = n;
}

void dfst(int n, int nr)
{
    comp[n] = nr;
    viz[n] = 0;
    for(int i = 0; i < t[n].size(); i++)
        if(viz[t[n][i]] == 1)
            dfst(t[n][i], nr);
}

void dfsv(int n, int c, int v)
{
    viz[n] = 1;
    val[n] = v;
    int sim = -n;
    if(v == 0 && viz[sim] == 0)
        dfsv(sim, comp[sim], 1);
    for(int i = 0; i < g[n].size(); i++)
    {
        if(viz[g[n][i]] == 0 && comp[g[n][i]] == c)
            dfsv(g[n][i], c, v);
    }
}

int main()
{
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for(int i = 0; i < m; i++)
    {
        int a, b;
        scanf("%d%d", &a, &b);
        g[-a].push_back(b);
        g[-b].push_back(a);
        t[b].push_back(-a);
        t[a].push_back(-b);
    }
    for(int i = -n; i <= n; i++)
    {
        if(i == 0) continue;
        val[i] = -1;
        if(viz[i] == 0)
            dfs(i);
    }
    int nr = 0;
    for(int i = lst - 1; i >= 0; i--)
    {
        if(viz[st[i]] == 1)
        {
            dfst(st[i], nr);
            nd[nr] = st[i];
            nr++;
        }
    }
    for(int i = 1; i <= n; i++)
    {
        if(comp[i] == comp[-i])
        {
            printf("-1");
            return 0;
        }
    }
    for(int i = 0; i < nr; i++)
    {
        if(val[nd[i]] == -1)
        {
            dfsv(nd[i], i, 0);
        }
    }
    for(int i = 1; i <= n; i++)
        printf("%d ", val[i]);
    return 0;
}
