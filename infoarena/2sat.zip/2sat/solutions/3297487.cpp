#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;

const int VMAX = 2 * NMAX;


vector <int> edges[VMAX + 1];
vector <int> edgesT[VMAX + 1];

int viz[VMAX + 1];
int comp[VMAX + 1];

int sgn( int a ) {
    if ( a < 0 ) return 0;
    return 1;
}
int getNode( int a ) {
    return 2 * (abs(a) - 1) + sgn( a );
}

vector <int> order;

void dfs1( int node ) {
    viz[node] = true;
    for ( auto vec : edges[node] ) {
        if ( !viz[vec] ) dfs1( vec );
    }
    order.push_back( node );
}


void dfs2( int node, int c ) {
    viz[node] = true;
    for ( auto vec : edgesT[node] ) {
        if ( !viz[vec] ) dfs2( vec, c );
    }
    comp[node] = c;
}

int main() {
    ifstream fin( "2sat.in" );
    ofstream fout( "2sat.out" );
    int n, m;
    fin >> n >> m;
    int v = getNode( n );
    for ( int i = 1, a, b; i <= m; i ++ ) {
        fin >> a >> b;
        edges[getNode( -a )].push_back( getNode( b ) );
        edges[getNode( -b )].push_back( getNode( a ) );
        edgesT[getNode( b )].push_back( getNode( -a ) );
        edgesT[getNode( a )].push_back( getNode( -b ) );
    }

    for ( int i = 0; i <= v; i ++ ) {
        if ( !viz[i] ) {
            dfs1( i );
        }
    }
    for ( int i = 0; i <= v; i ++ ) viz[i] = false;
    reverse( order.begin(), order.end() );

    int comps = 0;
    for ( auto x : order ) {
        if ( !viz[x] ) {
            dfs2( x, ++comps );
        }
    }
    for ( int i = 1; i <= n; i ++ ) {
        if ( comp[getNode(i)] == comp[getNode(-i)] ) {
            fout << "-1\n";
            return 0;
        }
    }
    for ( int i = 1; i <= n; i ++ ) {
        fout << (comp[getNode(i)] > comp[getNode(-i)]) << ' ';
    }
    return 0;
}