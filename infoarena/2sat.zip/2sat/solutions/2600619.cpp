#include <bits/stdc++.h>

using namespace std;

const int MAXN = 100005;

vector<int> graf[MAXN], rev[MAXN], comp;
stack<int> stiva;
vector<vector<int>> ctc;
bool viz[MAXN];
int sursa[MAXN], adev[MAXN];

int n, m, cnt;

int transf(int x){
    if(x < 0) return -x + n;
    return x;
}

int neg(int x){
    if(x > n) return x - n;
    return x + n;
}

void dfs(int nod, bool mod){
    if(viz[nod]) return;
    viz[nod] = 1;
    if(!mod){
        for(auto x: graf[nod]) dfs(x, mod);
        stiva.push(nod);
    }
    else{
        for(auto x: rev[nod]) dfs(x, mod);
        comp.push_back(nod);
        sursa[nod] = cnt;
    }
}

void buildCTC(){
    dfs(1, 0);
    memset(viz, 0, 2 * n + 1);
    while(!stiva.empty()){
        int vf = stiva.top();
        stiva.pop();
        if(!viz[vf]){
            comp.clear();
            cnt++;
            dfs(vf, 1);
            ctc.push_back(comp);
        }
    }
}

int main()
{
    ifstream fin("2sat.in");
    ofstream fout("2sat.out");
    fin >> n >> m;
    for(int i = 1; i <= m; ++i){
        int x, y;
        fin >> x >> y;
        x = transf(x); y = transf(y);
        graf[neg(x)].push_back(y);
        rev[y].push_back(neg(x));
        graf[neg(y)].push_back(x);
        rev[x].push_back(neg(y));
    }
    buildCTC();
    for(int i = 1; i <= 2 * n; ++i) adev[i] = -1;
    bool sat = 1;
    for(auto x: ctc){
        for(auto y: x)
            if(sursa[y] == sursa[neg(y)]) sat = 0;
        if(!sat) break;
        int val = -1;
        for(auto y: x){
            if(adev[y] == -1) continue;
            if(val == -1) val = adev[y];
            else if(val != adev[y]) sat = 0;
        }
        if(!sat) break;
        if(val == -1) val = 0;
        for(auto y: x){
            adev[y] = val;
            if(adev[neg(y)] != -1 && adev[neg(y)] != 1 - val) sat = 0;
            adev[neg(y)] = 1 - val;
        }
        if(!sat) break;
    }
    if(sat)
        for(int i = 1; i <= n; ++i) fout << adev[i] << " ";
    else fout << -1;
    return 0;
}
