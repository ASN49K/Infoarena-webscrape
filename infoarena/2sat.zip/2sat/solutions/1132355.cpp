#include<fstream>
#include<vector>
#include<stack>
#define maxn 100005
using namespace std;
ifstream fi("2sat.in");
ofstream fo("2sat.out");

vector <int> g[2*maxn]; // graful initial
vector <int> gt[2*maxn]; // graful transpus
stack <int> st; // stiva pentru determinarea ctc
int nrc=0; // numarul de componente conexe
int ctc[2*maxn]; // ctc[i] - nr. componentei conexe din care face parte i
int i,n,m,x,y;
bool viz[2*maxn];

int neg(int x){
    if(x<=n) return (x+n);
    else return (x-n);
}

void citire(){
     fi>>n>>m;
     for(i=1;i<=m;i++){
                       fi>>x>>y;
                       if(x<0) x=-x+n;
                       if(y<0) y=-y+n;
                       g[neg(x)].push_back(y);
                       g[neg(y)].push_back(x);
                       gt[x].push_back(neg(y));
                       gt[y].push_back(neg(x));
                      }
}

void dfs1(int k){
     viz[k]=1;
     
     while(g[k].size()){
       if(!viz[g[k].back()]) dfs1(g[k].back());
       g[k].pop_back();
     }
     
     st.push(k);
}

void dfs2(int k){
     viz[k]=1; ctc[k]=nrc;
     
     while(gt[k].size()){
       if(!viz[gt[k].back()]) dfs2(gt[k].back());
       gt[k].pop_back();
     }
}

void comp_tare_conexe(){
     for(i=1;i<=2*n;i++) viz[i]=0;
     for(i=1;i<=2*n;i++)
       if(!viz[i]) dfs1(i);
      
     for(i=1;i<=2*n;i++) viz[i]=0;
     while(st.size()){
        if(!viz[st.top()]){
                           nrc++;
                           dfs2(st.top()); 
                          }
        st.pop();
     }
}

void raspuns(){
     bool t=true;
    
     for(i=1;i<=n;i++)
       if(ctc[i]==ctc[neg(i)]) t=false;
   
     if(!t) fo<<"-1";
     else for(i=1;i<=n;i++)
            fo<<(int)(ctc[i]>ctc[neg(i)])<<" ";
}

int main(){
    
    citire();
    comp_tare_conexe();
    raspuns();
    
    fi.close();
    fo.close();
    return 0;
}
