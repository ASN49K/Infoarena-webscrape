#include <bits/stdc++.h>

using namespace std;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

int n,m;

vector<int> adj[200002];
vector<int> r_adj[200002];
bool visited[200002];
bool assigned[100002];
bool comp_val[200002];
int x_comp[200002];
int norm(int x)
{
    if(x<0)
        return -x+n;
    return x;
}

inline int neg(int x)
{
    if(x>n)
        return x-n;
    return x+n;
}

vector<int> sortat;
vector<vector<int> >comp;

void dfs(int s, vector<int> *adjv, bool top,bool tare)
{
    visited[s]=1;

    for(int i=0 ; i<(int)adjv[s].size() ; i++)
    {
        int v=adjv[s][i];
        if(visited[v]==0)
        {
            dfs(v,adjv,top,tare);
        }
    }
    //cout<<s<<" ";
    if (tare)
    {
        x_comp[s]=comp.size()-1;
        comp[comp.size()-1].push_back(s);
    }
    if(top)
        sortat.push_back(s);
}

bool check()
{
    for(int i=sortat.size()-1;i>=0;i--)
    {
        if(visited[sortat[i]]==0)
        {
            comp.push_back(vector<int>());
            dfs(sortat[i],r_adj,0,1);
        }
    }
    int saw[100002];
    for(int i=0;i<comp.size();i++)
    {
        for(int j=0;j<comp[i].size();j++)
        {
            int x=comp[i][j];
            if(x>n)
                x=neg(x);
            if(saw[x]==i+1)
                return 1;
            saw[x]=i+1;
        }
    }
    return 0;
}

int main()
{

    fin>>n>>m;
    for(int i=0;i<m;i++)
    {
        int v1,v2;
        fin>>v1>>v2;
        v1=norm(v1),v2=norm(v2);
        adj[neg(v1)].push_back(v2), r_adj[v2].push_back(neg(v1));
        adj[neg(v2)].push_back(v1), r_adj[v1].push_back(neg(v2));
    }

    for(int i=1;i<=2*n;i++)
    {
        if(visited[i]==0)
            dfs(i,adj,1,0);
    }
    memset(visited, 0, (2*n+1)*sizeof(bool));

    if(check())
    {
        fout<<-1;
        return 0;
    }
    memset(visited, 0, (2*n+1)*sizeof(bool));

   // reverse(sortat.begin(),sortat.end());

    for(int i=comp.size()-1;i>=0;i--)
    {
    for(int j=0;j<comp[i].size();j++)
    {
        cout<<comp[i][j]<<" "<<x_comp[comp[i][j]]<<"\n";
        int x=comp[i][j];
        if(comp[i][j]>n)
            x=neg(comp[i][j]);
        if(visited[x]==0)
        {
            visited[x]=1;
            if(comp_val[i]==0)
            {
                comp_val[x_comp[neg(comp[i][j])]]=1;
                if(comp[i][j]<=n)
                    assigned[x]=1;
                else assigned[x]=0;
            }
            else
            {
                if(comp[i][j]<=n)
                    assigned[x]=0;
                else assigned[x]=1;
            }

        }
    }
    }
    for(int i=1;i<=n;i++)
        fout<<assigned[i]<<" ";

    return 0;
}
