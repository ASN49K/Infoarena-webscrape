#include <bits/stdc++.h>

using namespace std;

ifstream f("2sat.in");
ofstream g("2sat.out");

int n,m,i,x,y,k,ingrad[200010],gr[200010],neg[200010],negr[200010],niv[200010],up[200010];
vector<int> v[200010];
queue<int> Q;
unordered_set<int> GR[200010];
bitset<200010> viz,in,ans;
stack<int> St;

void dfs(int nod)
{
    viz[nod]=1;in[nod]=1;
    St.push(nod);
    for(auto it:v[nod])
        if(!viz[it])
        {
            up[it]=niv[it]=niv[nod]+1;
            dfs(it);
            up[nod]=min(up[nod],up[it]);
        }
        else
            if(in[it])
                up[nod]=min(up[nod],niv[it]);
    if(up[nod]==niv[nod])
    {
        k++;
        while(St.top()!=nod)
        {
            in[St.top()]=0;
            gr[St.top()]=k;
            St.pop();
        }
        gr[nod]=k;
        in[nod]=0;
        St.pop();
    }
}

int main()
{
    f>>n>>m;
    for(i=1;i<=n;i++)
    {
        neg[i]=i+n;
        neg[i+n]=i;
    }
    for(i=1;i<=m;i++)
    {
        f>>x>>y;
        if(x<0)x=n-x;
        if(y<0)y=n-y;
        v[neg[x]].push_back(y);
        v[neg[y]].push_back(x);
//        g<<neg[x]<<' '<<y<<'\n'<<neg[y]<<' '<<x<<'\n';
    }
    for(i=1;i<=2*n;i++)
        if(!viz[i])
        {
            niv[i]=up[i]=1;
            dfs(i);
        }
//    for(i=1;i<=2*n;i++)
//        g<<gr[i]<<' ';g<<'\n';
    for(i=1;i<=2*n;i++)
        negr[gr[i]]=gr[neg[i]];
    for(i=1;i<=2*n;i++)
        for(auto it:v[i])
            if(gr[i]!=gr[it])
                GR[gr[i]].insert(gr[it]);
    for(i=1;i<=k;i++)
        for(auto it:GR[i])
            ingrad[it]++;
//    for(i=1;i<=k;i++)
//    {
//        g<<i<<": ";
//        for(auto it:GR[i])
//            g<<it<<' ';
//        g<<";"<<ingrad[i];
//        g<<'\n';
//    }
    for(i=1;i<=k;i++)
        if(!ingrad[i])
            Q.push(i);
    while(Q.size())
    {
        x=Q.front();Q.pop();
        if(ans[x])continue;
        for(auto it:GR[x])
        {
            ingrad[it]--;
            if(!ingrad[it])
                Q.push(it);
        }
        ans[negr[x]]=1;
    }
    for(i=1;i<=n;i++)
        g<<ans[gr[i]]<<' ';
    return 0;
}
