#include <fstream>
#include <vector>

#define nMax 100001
#define pb push_back

using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
int variables, expressions, okSol=1;
int viz[2*nMax], discover[2*nMax], value[2*nMax];
vector<int> G[2*nMax], GT[2*nMax];
inline int ind(int a)
{
    return (a>0 ? a : variables-a);
}
inline int non(int a)
{
    return (a<variables ? a+variables : a-variables);
}
void add(int a, int b)
{
    G[non(ind(a))].pb(ind(b));
    GT[ind(b)].pb(non(ind(a)));
    G[non(ind(b))].pb(ind(a));
    GT[ind(a)].pb(non(ind(b)));
}
void read()
{
    int a, b;
    fin>>variables>>expressions;

    for(int i=1;i<=expressions;i++)
    {
        fin>>a>>b;
        add(a, b);
    }
}
void dfs(int node)
{
    viz[node]=1;

    for(vector<int>::iterator it=G[node].begin();it!=G[node].end();it++)
    {
        int fiu=*it;
        if(viz[fiu])
            continue;

        dfs(fiu);
    }

    discover[++discover[0]]=node;
}

void dfst(int node)
{
    viz[node]=0;

    if(value[node]==1)
    {
        okSol=0;
        return;
    }

    value[non(node)]=1;

    for(vector<int>::iterator it=GT[node].begin();it!=GT[node].end();it++)
    {
        int fiu=*it;
        if(viz[fiu]==0)
            continue;

        dfst(fiu);
    }
}
void _2sat()
{
    for(int i=1;i<=2*variables;i++)
        if(viz[i]==0)
            dfs(i);

    for(int i=2*variables;i>=1;i--)
        if(viz[discover[i]] && viz[non(discover[i])])
            dfst(discover[i]);
}
void write()
{
    if(okSol==0)
        fout<<-1;
    else
        for(int i=1;i<=variables;i++)
            fout<<value[i]<<" ";
}
int main()
{
    read();
    _2sat();
    write();
    return 0;
}
