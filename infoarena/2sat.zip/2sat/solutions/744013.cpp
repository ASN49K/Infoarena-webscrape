//Cezar Mocan
#include <cstdio>
#include <algorithm>
#include <ctime>
#include <cstdlib>

#define MAXN 100100
#define MAXM 200100
#define CONST 20

using namespace std;

int N, M;
pair <int, int> EXPR[MAXM];
int SOL[MAXN];

inline int abs(int x) {
    return x < 0 ? (-x) : x;
}

bool eval_term(pair <int, int> T) {
    int x, y;
    
    x = SOL[abs(T.first)];
    y = SOL[abs(T.second)];
    
    if (T.first < 0)
        x ^= 1;
    if (T.second < 0)
        y ^= 1;
        
    return (x | y);
}

void print_sol() {
	int i;
	for (i = 1; i <= N; i++)
		printf("%d ", SOL[i]);
}


int main() {
	
	int i, a, b, P;
	
	freopen("2sat.in", "r", stdin);
	freopen("2sat.out", "w", stdout);
	
	scanf("%d%d", &N, &M);
	for (i = 1; i <= M; i++) {
		scanf("%d%d", &a, &b);
		EXPR[i] = make_pair(a, b);
	}
	
	srand(time(0));
	
	for (i = 1; i <= N; i++)
		SOL[i] = rand() % 2;
	
	for (int step = 0; step <= N * CONST; step++) {
		int curr_res = 1;
		for (i = 1; i <= M; i++) {
			curr_res &= eval_term(EXPR[i]);
			if (curr_res == 0) {
				P = i;
				break;
			}
		}
		
		if (curr_res == 1) {
			print_sol();
			return 0;
		}
		
		if (rand() % 2 == 0)
			SOL[abs(EXPR[P].first)] ^= 1;
		else
			SOL[abs(EXPR[P].second)] ^= 1;
	}
	
	printf("-1\n");
	
	return 0;
}
