#include <stdio.h>

using namespace std;

const int N = 100001;
const int M = 200001;
int aux[2][2*N],*lst[2];
int vf[2][M],urm[2][M],nr;
int smen[2*N],nsmen;
bool a[2*N],*v=a+N;
int nc,nrez,rez[2*N];
int b[2*N],*comp=b+N; //carei componente ii apartine x
int start[2*N]; //de unde incepe o componenta
int c[2*N],*val=c+N;

void adauga(int p, int x, int y)
{
    nr++;
    vf[p][nr]=y;
    urm[p][nr]=lst[p][x];
    lst[p][x]=nr;
}

void dfs(int x)
{
    //printf(" %d",x);
    int p=lst[0][x],y;
    v[x]=1;
    while(p!=0)
    {
        y=vf[0][p];
        if(!v[y])
            dfs(y);
        p=urm[0][p];
    }
    smen[nsmen++]=x;
}

void dfsmen(int x)
{
    //printf("AICI,x=%d\n",x);
    int p=lst[1][x],y;
    v[x]=1;
    rez[nrez++]=x; comp[x]=nc;
    while(p!=0)
    {
        y=vf[1][p];
        //printf("VECIN: %d\n",y);
        if(!v[y])
            dfsmen(y);
        p=urm[1][p];
    }
}

int main()
{
    lst[0]=aux[0]+N; lst[1]=aux[1]+N;
    FILE *in=fopen("2sat.in","r");
    FILE *out=fopen("2sat.out","w");
    int n,m,i,x,y,act;
    fscanf(in,"%d%d",&n,&m);
    for(i=0;i<m;i++)
    {
        fscanf(in,"%d%d",&x,&y);
        adauga(0,-x,y);
        adauga(0,-y,x);
        adauga(1,y,-x);
        adauga(1,x,-y);
    }

    for(i=-n;i<=n;i++)
    {
        if(!i) continue;
        if(!v[i])
            dfs(i);
        //printf("GATA!\n");
    }

    for(i=-n;i<=n;i++)
        v[i]=0;

    start[0]=0;
    for(i=nsmen-1;i>=0;i--)
    {
        x=smen[i];
        if(!v[x])
        {
            dfsmen(x);
            nc++;
            rez[nrez++]=0;
            start[nc]=nrez;
        }
    }

    bool prost=0;
    for(i=-n;i<=n;i++)
        val[i]=-1;
    act=0;
    while(nc>0)
    {
        for(i=start[act];rez[i]!=0;i++)
        {
            if(val[rez[i]]==1) prost=1;
            val[rez[i]]=0;
            if(val[-rez[i]]==0) prost=1;
            val[-rez[i]]=1;
        }
        nc-=2;
        act++;
    }

    if(prost) fprintf(out,"-1");
    else
        for(i=1;i<=n;i++)
            fprintf(out,"%d ",val[i]);

    return 0;
}
