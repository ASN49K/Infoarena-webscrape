#include <bits/stdc++.h>

#define vi vector<int>
#define pb push_back

using namespace std;
//
//ifstream in("2sat.in");
ofstream out("2sat.out");

FILE *in = fopen("2sat.in", "r");

const int maxB = (int)1e5;
const bool isDigit[] = {
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

int pos = maxB - 1;

char buff[maxB];

char getChar() {
  pos++;
  if (pos == maxB) {
    size_t read = fread(buff, sizeof(char), maxB, in);
    assert(read > 0);
    pos = 0;
  }
  return buff[pos];
}

int getInt() {
  char c;
  while (!isDigit[(int)(c = getChar())]) {}
  int val = 0;
  while (isDigit[(int)c]) {
    val = val * 10 + c - '0';
    c = getChar();
  }
  return val;
}

const int maxN = (int)2e5 + 4;

int n, m;

vi g[maxN], r[maxN], scc[maxN];

vi st;

int comp[maxN], deg[maxN], result[maxN];

bool used[maxN];

int f(const int x) {
  if (x < 0) {
    return n + abs(x);
  }
  return x;
}

int non(const int x) {
  if (x > n) {
    return x - n;
  }
  return x + n;
}

void dfs(int u) {
  used[u] = true;
  for (int v : g[u]) {
    if (!used[v]) {
      dfs(v);
    }
  }
  st.pb(u);
}

void dfs2(int u, int cnt) {
  used[u] = true;
  scc[cnt].pb(u);
  comp[u] = cnt;
  for (int v : r[u]) {
    if (!used[v]) {
      dfs2(v, cnt);
    }
  }
}

void add(int x, int y) {
  x = f(x), y = f(y);
  g[non(x)].pb(y);
  r[y].pb(non(x));
}

int main() {
  n = getInt();
  m = getInt();
  for (int i = 0; i < m; i++) {
    int u, v;
    u = getInt();
    v = getInt();
    add(u, v);
    add(v, u);
  }
  for (int i = 1; i <= 2 * n; i++) {
    if (!used[i]) {
      dfs(i);
    }
  }
  reverse(st.begin(), st.end());
  int cnt = 0;
  fill(used, used + 2 * n + 4, false);
  for (int v : st) {
    if (!used[v]) {
      dfs2(v, cnt++);
    }
  }
  for (int i = 1; i <= n; i++) {
    if (comp[i] == comp[i + n]) {
      out << "-1\n";
      return 0;
    }
  }
  for (int i = 1; i <= 2 * n; i++) {
    for (int v : g[i]) {
      int a = comp[i], b = comp[v];
      if (a != b) {
        deg[b]++;
      }
    }
  }
  queue<int> q;
  for (int i = 0; i < cnt; i++) {
    if (!deg[i]) {
      q.push(i);
    }
  }
  fill(result, result + 2 * n + 4, -1);
  while ((int)q.size() > 0) {
    int u = q.front();
    q.pop();
    for (int v : scc[u]) {
      int x = v;
      if (x > n) {
        x -= n;
      }
      if (result[x] == -1) {
        if (v <= n) {
          result[x] = 0;
        } else {
          result[x] = 1;
        }
      }
    }
    for (int v : scc[u]) {
      for (int x : g[v]) {
        int a = comp[v], b = comp[x];
        if (a != b) {
          if (--deg[b] == 0) {
            q.push(b);
          }
        }
      }
    }
  }
  for (int i = 1; i <= n; i++) {
    out << result[i] << " ";
  }
  return 0;
}
