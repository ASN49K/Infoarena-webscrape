#include <iostream>
#include <vector>
using namespace std;

//ifstream cin("2sat.in");
//ofstream cout("2sat.out");

struct exp{

    int a , b;
};

const int MAX = 1e5 + 1;

vector <int> g[MAX];

bool setat[MAX];

bool val[MAX];

void rec( int x , bool a){

    setat[x] = 1;

    val[x] = a;

    for(auto it : g[x]){

        if(it < 0){

            int aux = it*(-1);

            if(!setat[aux]){

                rec(aux,a);
            }

        }else if(!setat[it]){

                rec(it,1-a);
            }
    }

}

int main(){

    int n , m;

    cin >> n >> m;

    while(m--){

        exp x;

        cin >> x.a >> x.b;

        if(x.a < 0){

            g[x.a*(-1)].push_back(-x.b);
        }
        else g[x.a].push_back(x.b);

        if(x.b < 0){

            g[x.b*(-1)].push_back(-x.a);

        }else g[x.b].push_back(x.a);
    }

    for(int i = 1 ; i <= n ; i++){

        if(!setat[i]){

            rec(i,0);
        }
    }

    for(int i = 1 ; i <= n ; i++){

        cout << val[i] << ' ';
    }

    return 0;
}
