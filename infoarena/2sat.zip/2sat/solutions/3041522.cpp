#include <iostream>
#include <fstream>
#include <algorithm>
#include <stack>
#include <vector>

///#include <tryhardmode>
///#include <GODMODE::ON>

using namespace std;

#define cin fin
#define cout fout

ifstream fin ("2sat.in");
ofstream fout ("2sat.out");

using namespace std;

const int NMAX=2e5+5;

vector<int>v[NMAX];
vector<int>rev[NMAX];

stack<int>stiva;
int color[NMAX];
bool viz[NMAX];

int n,kon;

void dfs(int p)
{
    viz[p]=true;
    for(auto i:v[p])
    {
        if(!viz[i])
            dfs(i);
    }
    stiva.push(p);
}

void dfsc(int p)
{
    viz[p]=true;
    color[p]=kon;
    for(auto i:rev[p])
    {
        if(!viz[i])
            dfsc(i);
    }
}

int get_asoc(int p)
{
    if(p<0)
        return -p+n;
    else
        return p;
}

int get_not(int p)
{
    if(p<=n)
        return p+n;
    else
        return p-n;
}

int main()
{
    int m,i,j,x,y;
    bool ok=true;
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y;
        x=get_asoc(x);
        y=get_asoc(y);
        int a=get_not(x);
        int b=get_not(y);
        v[a].push_back(y);
        v[b].push_back(x);
        rev[y].push_back(a);
        rev[x].push_back(b);
    }
    for(i=1;i<=2*n;i++)
        if(!viz[i])
            dfs(i);
    for(i=1;i<=2*n;i++)
        viz[i]=false;
    while(!stiva.empty())
    {
        int p=stiva.top();
        if(!viz[p])
        {
            kon++;
            dfsc(p);
        }
        stiva.pop();
    }
    for(i=1;i<=n;i++)
        if(color[i]==color[i+n])
        {
            ok=false;
            break;
        }
    if(!ok)
        cout<<-1;
    else
    {
        for(i=1;i<=n;i++)
            if(color[i]>color[i+n])
                cout<<1<<" ";
            else
                cout<<0<<" ";
    }
    return 0;
}
