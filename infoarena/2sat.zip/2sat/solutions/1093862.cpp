#include <fstream>
#include <algorithm>
#include <vector>
#include <cstring>
#include <stack>

#define NMAX 100005

using namespace std;


typedef vector < int > ::iterator IT;
ifstream in ( "2sat.in" );
ofstream out ( "2sat.out" );	

vector < int > G[2*NMAX] , GT[2*NMAX];

int N,M, Answer[NMAX] , flag;
stack < int > S ;
bool used[2*NMAX];
int Non ( int x ) { return ( x > N ? x-N : x + N ) ; }

void DFM ( int node )
{
	used[node] = true;
	for ( IT it = G[node].begin() ; it != G[node].end() ; ++it )
		if ( !used[*it] )
			DFM ( *it );
	S.push ( node );
}

void DFP ( int node )
{
	if ( Answer[node]  )
	{
		flag = -1 ;
		return ;
	}
	Answer[Non(node)] = 1 ;
	
	used[node] = true , used[Non(node)] = true;
	for ( IT it =GT[node].begin() ; it != G[node].end() ; ++it )
		if ( !used[*it] )
			DFP(*it);
}


void MakeKosaraju ( void )
{
	int i , j;
	for ( i = 1 ; i <= 2*N ; ++i )
		if ( !used[i] )
			DFM( i );
	memset ( used , 0 , sizeof ( used ) );
    for ( ; S.size() ; )
	{
		int node = S.top();
		if ( !used[node] and !used[Non(node)] )
			DFP(node);
		S.pop();
	}
}
void MakeEdge ( int X , int Y )
{
	G[X].push_back(Y);
	G[Y].push_back(X);
}

int main ( void )
{
	int i , j , x , y;
	in >> N >> M ;
	for ( i = 1 ; i <= M ; ++i )
	{
		in >> x >> y ;
		x = ( x < 0 ?  N-x : x );
		y = ( y < 0 ?  N-y : y );
		MakeEdge( Non(x) , y )  ;
		MakeEdge ( Non(y) , x) ;
	}
	MakeKosaraju();
	for ( i = 1 ; i <=  N ; out << Answer[i++] );
	in.close();
	out.close();
	return 0;
}