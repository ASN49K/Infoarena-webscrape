#include <iostream>
#include <cstdio>
#include <vector>
#define MAXN 100100

using namespace std;

int n, m, sol[2*MAXN], viz[2*MAXN];
vector<int> graf[2*MAXN];
vector<int> last;

int get(int nr)  /// x = {1 ... n} get(x) = {n+1.....2n}
{
	if (nr < 1)
		return n - nr;
	return nr;
}

int nu (int x)
{
	if (x > n) return x-n;
	else return x+n;
}

void citire()
{
	int x, y;
    scanf("%d %d", &n, &m);
    for (int i = 1; i <= m; i++) {
        scanf("%d %d", &x, &y);
        x = get(x), y = get(y);
        graf[nu(x)].push_back(y);
        graf[nu(y)].push_back(x);
    }
}

int start(int ind)
{
	last.push_back(ind);
    viz[ind] = viz[nu(ind)] = 1;
    sol[ind] = !(sol[nu(ind)] = 0);
    int f = 1;
    for (int i = 0, t = graf[ind].size(); i < t; i++) {
        int y = graf[ind][i];
        if (viz[y] && sol[y] != sol[ind])
			return 0;
		if (!viz[y])
			f &= start(y);
    }
    return f;
}

int can(int ind)
{
	if (viz[ind]) return 1;
    last.clear();
    start(ind);
}

void undo()
{
    for (int i = 0, t = last.size(); i < t; i++)
        viz[last[i]] = viz[nu(last[i])] = 0;
}

void solve()
{
    for (int i = 1; i <= 2*n; i++)
		if (!can(i)) {
			undo();
			if (!can(nu(i))) {
				printf("%d ", -1);
				return;
			}
		}

	for (int i = 1; i <= n; i++)
		printf("%d ", sol[i]);
}

int main()
{
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);

    citire();
    solve();

    return 0;
}
