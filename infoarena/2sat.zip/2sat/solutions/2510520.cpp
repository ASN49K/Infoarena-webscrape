#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <utility>
#define MAX 100001
#define INF 2e9

using namespace std;

vector<int> graf[2 * MAX];
vector<vector<int>> listComp;
stack<int> stiva;

bool onStack[MAX], SAT2[MAX];
int up[MAX], viz[MAX], vizCount;

void clearStack(int nod)
{
	vector<int> comp;

	while (stiva.top() != nod)
	{
		comp.push_back(stiva.top());
		onStack[stiva.top()] = 0;
		stiva.pop();
	}

	comp.push_back(stiva.top());
	onStack[stiva.top()] = 0;
	stiva.pop();

	listComp.push_back(comp);

	//cout << "something!";
}

int min(int a, int b)
{
	if (a < b)return a;

	return b;
}

void DFS(int nod)
{
	vizCount++;
	viz[nod] = vizCount;
	up[nod] = vizCount;

	stiva.push(nod);
	onStack[nod] = 1;

	for (auto i : graf[nod])
	{
		if (!viz[i])
		{
			DFS(i);

			up[nod] = min(up[nod], up[i]);
		}
		else if (onStack[i])
			up[nod] = min(up[nod], viz[i]);
	}

	if (up[nod] == viz[nod])
    {
		clearStack(nod);
    }
}

int getIndex(int x)
{
	if (x < 0)return -x + MAX;

	return x;
}

int getReversedIndex(int x)
{
	if (x < 0)return -x;

	return x + MAX;
}

int main()
{
	int n, m, a, b;

	ifstream fin("2sat.in");
	ofstream fout("2sat.out");

	fin >> n >> m;

	for (int i = 0; i < m; i++)
	{
		fin >> a >> b;

		graf[getReversedIndex(a)].push_back(getIndex(b));
		graf[getReversedIndex(b)].push_back(getIndex(a));
	}

	for (int i = 1; i <= n; i++)
		if (!viz[i])
		{
			DFS(i);

			for (int j = 0; j < listComp.size() / 2 + listComp.size() % 2; j++)
			{
				for (int l = 0; l != listComp[j].size(); l++)
				{
					if (listComp[j][l] > MAX)
					{
						SAT2[listComp[j][l] - MAX] = 0;
					}
					else SAT2[listComp[j][l]] = 1;
				}
			}

			listComp.clear();
		}

	for (int i = 1; i <= n; i++)fout << SAT2[i] << " ";

	fin.close();
	fout.close();

	return 0;
}
