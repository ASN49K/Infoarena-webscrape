#include <bits/stdc++.h>
using namespace std;
const int N = 200005;

vector<int> g[N], gt[N], s;
int comp[N];
bool viz[N], sol[N / 2];
int ctc = 0;

int neg(int x)
{
    if(x>0)
       return 2*x+1;
    x=x*(-1);
    return 2*x;
}

void dfs1(int nod)
{
    viz[nod] = true;
    for (auto fiu : g[nod])
    {
        if (!viz[fiu])
            dfs1(fiu);
    }
    s.push_back(nod);
}
void dfs2(int nod)
{
    comp[nod] = ctc;
    for (auto fiu : gt[nod])
    {
        if (comp[fiu] == 0)
            dfs2(fiu);
    }
}

int main()
{
    ifstream cin("2sat.in");
    ofstream cout("2sat.out");
    int n, m;
    cin >> n >> m;
    for (int i=0;i<m;i++)
    {
        int a, b;
        cin >> a >> b;
        int an=neg(a),bn=neg(b);
        a = 2 * abs(a) + (a < 0);
        b = 2 * abs(b) + (b < 0);
        g[an].push_back(b);
        g[bn].push_back(a);
        gt[b].push_back(an);
        gt[a].push_back(bn);
    }
    for (int nod=2; nod<=2*n; nod++)
    {
        if (!viz[nod])
            dfs1(nod);
    }
    reverse(s.begin(), s.end());
    for (auto nod : s)
    {
        if (comp[nod]==0)
            {
                ctc++;
                dfs2(nod);
            }
    }
    for (int nod = 2; nod <= 2 * n; nod += 2)
    {
        if (comp[nod] == comp[nod + 1])
            cout << "-1";
        sol[nod / 2] = comp[nod] > comp[nod + 1];
    }
    for (int i = 1; i <= n; i++)
        cout << sol[i] << " ";
    cout << "\n";
    return 0;
}
