#include <cstdio>
#include <algorithm>
#include <string.h>
#include <algorithm>
#include <queue>
#include <vector>
using namespace std;

#define Nmax 200010

int n, m, N, nr_ctc;
int viz[Nmax], Ap[Nmax], S[Nmax], Out[Nmax], Val[Nmax];
vector <int> G[Nmax], T[Nmax], V[Nmax], Ctc[Nmax];

int non (int nod) {

    if(nod <= n) return nod + n;
    return nod - n;
}

void citire () {

    int i, x, y;

    scanf ("%d %d", &n, &m); N = n << 1;
    for (i = 1; i <= m; i++) {
        scanf ("%d %d", &x, &y);
        if (x < 0) x = -x + n;
        if (y < 0) y = -y + n;
        G[non(x)].push_back (y);
        G[non(y)].push_back (x);

        // printf ("%d %d\n", non (x), y);
        // printf ("%d %d\n", non (y), x);

        T[x].push_back (non(y));
        T[y].push_back (non(x));
    }
}

void DFSp (int nod) {

    viz[nod] = 1;
    for (vector <int>::iterator it = G[nod].begin (); it != G[nod].end (); it++)
        if (!viz[*it])
            DFSp (*it);

    S[++S[0]] = nod;
}

void DFSm (int nod) {

    viz[nod] = 0; Ap[nod] = nr_ctc; Ctc[nr_ctc].push_back (nod);
    for (vector <int>::iterator it = T[nod].begin (); it != T[nod].end (); it++)
        if (viz[*it]) DFSm (*it);
}

void comp_tare_conexe () {

    int i;
    for (i = 1; i <= N; i++)
        if (!viz[i]) DFSp (i);

    for (i = S[0]; i >= 1; i--)
        if (viz[S[i]]) nr_ctc++, DFSm (S[i]);
}

void sortareT () {

    int i, nod;
    vector <int>::iterator it;
    queue <int> Q;

    for (i = 1; i <= nr_ctc; i++)
        if (Out[i] == 0) {
            Q.push (i);
            Val[i] = 1;
            Val[ Ap[ non( Ctc[i][0]) ] ] = 0;
        }

    for (; !Q.empty (); Q.pop ()) {
        nod = Q.front ();
        for (it = V[nod].begin (); it != V[nod].end (); it++) {
            Out[*it]--;
            if (!Out[*it] && Val[*it] == -1) {
                Val[*it] = 1;
                Val[ Ap[ non( Ctc[*it][0]) ] ] = 0;
                Q.push (*it);
            }
        }
    }
}

int main () {

    freopen ("2sat.in", "r", stdin);
    freopen ("2sat.out", "w", stdout);

    citire ();
    comp_tare_conexe ();

    int i;
    for (i = 1; i <= n; i++)
        if (Ap[i] == Ap[i + n]) {
            printf ("-1\n");
            return 0;
        }

    vector <int>::iterator it;
    for (i = 1; i <= N; i++)
        for (it = G[i].begin (); it != G[i].end (); it++)
            if (Ap[i] != Ap[*it]) V[Ap[*it]].push_back ( Ap[i] ), Out[Ap[i]]++;

    memset (Val, -1, sizeof (Val));

    sortareT ();

    for (i = 1; i <= n; i++)
        printf ("%d ", Val[ Ap[i] ]);

    return 0;
}
