#include <bits/stdc++.h>
using namespace std;

#pragma GCC optimize("O2,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
#define pb push_back
#define mp make_pair
#define f first
#define s second

vector<vi> adj(200005), adj_inv(200005);
vector<bool> visited(200005);
vi topological, comp(200005);

void dfs(int x){
    visited[x] = 1;
    for(auto i : adj[x])
        if(!visited[i])
            dfs(i);
    topological.pb(x);
}

void dfs2(int x, int num){
    visited[x] = 1;
    comp[x] = num;
    for(auto i : adj_inv[x])
        if(!visited[i])
            dfs2(i, num);
}

void solve(){
    int n, m;
    cin >> n >> m;
    for(int i = 0; i < m; i++){
        int a, b, neg_a, neg_b;
        cin >> a >> b;
        int na = (a < 0), nb = (b < 0);
        a = abs(a) - 1, b = abs(b) - 1;
        //a is 2n, neg_a is 2n+1
        a = 2 * a ^ na, b = 2 * b ^ nb;
        neg_a = a ^ 1, neg_b = b ^ 1;
        adj[neg_a].pb(b); adj[neg_b].pb(a);
        adj_inv[b].pb(neg_a); adj_inv[a].pb(neg_b);
    }
    for(int i = 0; i < 2*n; i++){
        if(!visited[i])
            dfs(i);
    }
    reverse(topological.begin(), topological.end());
    int cnt = 0;
    visited = vector<bool>(200005);
    for(auto x : topological){
        if(!visited[x]){
            dfs2(x, cnt);
            cnt++;
        }
    }
    //i+1 is the negation, i is not
    vi ans(n);
    for(int i = 0; i < 2*n; i += 2){
        if(comp[i] == comp[i+1]){
            cout << -1 << '\n';
            return;
        }
        if(comp[i] < comp[i+1])
            ans[i/2] = 0;
        else
            ans[i/2] = 1;
    }
    for(auto i : ans)
        cout << i << ' ';
    cout << '\n';
}   

int main(){
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}