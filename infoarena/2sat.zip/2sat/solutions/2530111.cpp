#include <bits/stdc++.h>
#define DIM 100010
using namespace std;
ifstream fin ("2sat.in");
ofstream fout("2sat.out");
int v[DIM],NIV[DIM],LOW[DIM],sol[DIM];
int n,m,a,b,i,j,g,br;
stack <int> ST;
vector<int> L[DIM];
set<int> C;
void dfs(int nod){
    g++;
    v[nod]=1;
    NIV[nod]=g;
    LOW[nod]=g;
    ST.push(nod);
    for(int i=0;i<L[nod].size();i++){
        int vecin = L[nod][i];
    if(v[vecin] && NIV[vecin])
        LOW[nod]=min(LOW[nod],NIV[vecin]);
    else if(!NIV[vecin]){
        dfs(vecin);
        LOW[nod]=min(LOW[nod],LOW[vecin]);
    }
    }
    if(NIV[nod]==LOW[nod]){
        C.clear();
        int aux;
        do{
            aux=ST.top();
            C.insert(aux);
            ST.pop();
            v[aux]=0;

            if((aux<=n && C.count(aux+n)) || (aux>n && C.count(aux-n))){
                fout<<-1;
                br=1;
            }
            if(sol[aux]==0){
                sol[aux]=1;
                if(aux<=n)
                    sol[aux+n]=-1;
                else
                    sol[aux-n]=-1;
            }
        }while(aux!=nod);
    }
}
int main(){
    fin>>n>>m;
    for(i=1;i<=m;i++){
        fin>>a>>b;
        if (a>0){
            if (b>0){
                L[a+n].push_back(b);
                L[b+n].push_back(a);
            } else{
                L[a+n].push_back(-b+n);
                L[-b].push_back(a);
            }
        } else{
            if (b>0) {
                L[-a].push_back(b);
                L[b+n].push_back(-a+n);
            } else {
                L[-a].push_back(-b+n);
                L[-b].push_back(-a+n);
            }
        }
    }

    for(i=1;i<=2*n;i++)
        if(!NIV[i])
            dfs(i);
    if(br){
        fout<<-1;
        return 0;
    }
    for (i=1;i<=n;i++) {
       if (sol[i]==1)
                fout<<1<<" ";
            else
                fout<<0<<" ";
    }

    return 0;
}
