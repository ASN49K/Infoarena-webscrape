#include<bitset>
#include <fstream>
#define inv(a) (a<=n)?(n+a):(a-n)
#define pb(a) push_back(a)
#include<vector>
#include<iostream>
#include<stack>
using namespace std;
vector<int> v[200002],vt[200002];
bitset<200002> viz,rez;
int n,m,k;
stack<int> poz;
 ofstream g("2sat.out");
void pl(int nod)
{
     viz[nod]=true;
     
     for(int i=0;i<v[nod].size();i++)
     if(!viz[v[nod][i]])
     pl(v[nod][i]);
     
     poz.push(nod);
}

void mi(int nod)
{    if(rez[nod]){
     k=-1; return;}
     viz[nod]=true;
     rez[inv(nod)]=true;
     for(int i=0;i<vt[nod].size();i++)
     if(!viz[vt[nod][i]])
     mi(vt[nod][i]);
     
     }

int main ()
{int x,y,i;
ifstream f("2sat.in");

f>>n>>m;
while(m)
{f>>x>>y;
if(x<0) x=n-x;
if(y<0) y=n-y;
v[inv(x)].pb(y);
v[inv(y)].pb(x);
vt[x].pb(inv(y));
vt[y].pb(inv(x));
        m--;}

for(i=1;i<=n+n;i++)
if(!viz[i])
pl(i);

viz.reset();
while(!poz.empty())
{if(!rez[poz.top()]&&!rez[inv(poz.top())])
mi(poz.top());
poz.pop();}
if(!k)
for(i=1;i<=n;i++)
g<<rez[i]<<" ";
else
g<<-1;
g<<'\n';
 f.close(); g.close();
return 0;
}
