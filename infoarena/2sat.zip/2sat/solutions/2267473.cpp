#include<iostream>
#include<fstream>
#include<vector>
#include<stack>

using namespace std;

vector <bool> inStack;
vector<int> idx, lowLink, compNo; 
stack <int> s;
int index, cNo;

unsigned int getNode(int x){
	if(x>0) return x*2-2;
	return -x*2-1;
}


void Tarjan(int nod, vector<int> *adj){
	
	vector <int> :: iterator it;
	
	lowLink[nod]=idx[nod]=index;
	index++;
	inStack[nod]=true; s.push(nod);
	
	for( it = adj[nod].begin(); it != adj[nod].end(); it++ ){
		if( idx[*it] == -1 ){
			Tarjan( *it, adj );
			lowLink[nod] = min( lowLink[nod], lowLink[*it] );
		}
		else if( inStack[*it] )
		    lowLink[nod] = min( lowLink[nod], lowLink[*it] );
	}	
	
	//componenta conexa formata
	if(idx[nod] == lowLink[nod]){
		int x;
		cNo++;
		do{
			x = s.top();
			s.pop();
			compNo[x] = cNo;
			inStack[x] = false;
		}while( x != nod );
	}
}


int main(){
    
	//reading data	
	ifstream in("2sat.in");
	int n,m,x,y,i;
	bool sol = true;
	
	in>>n>>m;
    vector<int>  adj[2*n+2];
    
    for(i=1; i<=m; i++){
    	in>>x>>y; 
    	adj[ getNode(-x) ].push_back( getNode(y) );
    	adj[ getNode(-y) ].push_back( getNode(x) );
	}
	
	in.close();	
	
	inStack.resize(2*n+3); lowLink.resize(2*n+3); idx.resize(2*n+3); compNo.resize(2*n+3);
	idx.assign(2*n+3,-1);
	
	//componente conexe
	for(i=0; i<2*n; i++)
	  if(idx[i]==-1)  Tarjan(i,adj);
	
	//exista solutie?
	for(i=1;i<=n;i++)
		if( compNo[ getNode(i) ] == compNo[ getNode(-1) ] ) 
               sol = false;
    
	FILE *out = fopen("2sat.out","w");
	
	if(sol==false) fprintf(out,"-1");
	else {
		for(i=1;i<=n;i++){
			fprintf(out,"%i ", ( compNo[ getNode(i) ] > compNo[ getNode(-i) ] ? 0 : 1 )  );
		}
	}           
	fclose(out);
	return 0;
}
