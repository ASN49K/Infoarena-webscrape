#include <bits/stdc++.h>

#define pb push_back
#define DMAX 100009*2
using namespace std;

int n, m, a, b, nr;
stack <int> s;
vector <int> v[DMAX], v2[DMAX], c[DMAX];
int val[DMAX], use[DMAX], c2[DMAX];

int Not(int k)
{
    if(k<=n)
        return k+n;
    return k-n;
}

void dfs2(int k)
{
    use[k]=0;
    for(int i=0;i<v2[k].size();++i)
    {
        if(use[v2[k][i]])
            dfs2(v2[k][i]);
    }
    c[nr].pb(k);
    c2[k]=nr;
}

void dfs(int k)
{
    use[k]=1;
    for(int i=0;i<v[k].size();++i)
        if(!use[v[k][i]])
        dfs(v[k][i]);
    s.push(k);
}

int main()
{
    
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);
    
    scanf("%i %i", &n, &m);
    
    for(int i=1;i<=2*n;i++)
        val[i] = -1;
    
    for(int i=1;i<=m;i++)
    {
        scanf("%i %i", &a, &b);
        if(a<0)a=Not(-a);
        if(b<0)b=Not(-b);
        v[Not(a)].pb(b);
        v2[b].pb(Not(a));
        v[Not(b)].pb(a);
        v2[a].pb(Not(b));
    }
    
    for(int i=1;i<=2*n;i++)
    {
        if(!use[i])
            dfs(i);
    }
    
    nr=1;
    while(!s.empty())
    {
        int x=s.top();
        s.pop();
        if(use[x])
            dfs2(x), nr++;
    }
    
for(int i=1;i<=n;++i)
{
    if(c2[i]==c2[i+n])
    {
        cout<<"-1\n";
        return 0;
    }
}
int Adevar=0;
    for(int i=1;i<nr;i++)
    {
        if(!Adevar && val[Not(c[i][0])]==Adevar)
            Adevar=!Adevar;
        for(int j=0;j<c[i].size();++j)
        {
                val[c[i][j]]=Adevar;
        }
    }
    
    for(int i=1;i<=n;i++)
        cout<<val[i]<<' ';
        cout<<'\n';
    
    return 0;
}
