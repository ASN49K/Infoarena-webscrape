#include <iostream>
#include <fstream>
#include<vector>
 
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
 
int n,m;
typedef vector<int> VEC[200001];
 
VEC a, b;
int v[200001];
struct
{
    int x[200001];
    int k;
}l;
 
void dfs(int i,int t,VEC &a)
{
    //cout << "start " << i << endl;
    int j;
    v[i]=t;
    for(j=0;j<a[i].size();j++)
        if(!v[a[i][j]])
            dfs(a[i][j],t,a);
    if(t==1)
        l.x[l.k++]=i;
    //cout << "end " << i << endl;
}
 
void draw_arc(int x,int y,VEC &a,int aux)
{
    if(aux==2) swap(x,y);

    if(x>n) x-=n; else x+=n;
    a[x].push_back(y);
}
int main()
{
    fin>>n>>m;
    int j,i;
    while(m--)
    {
        fin>>i>>j;
        
        if(i<0) i=n-i;
        if(j<0) j=n-j;
        
        draw_arc(i,j,a,1);
        draw_arc(j,i,a,1);

        draw_arc(i,j,a,2);
        draw_arc(j,i,a,2);
    }
    
    for(j=1;j<=n*2;j++)
        if(!v[j])
        dfs(j,1,a);

    for(i=0;i<=n*2;i++)v[i]=0;
    int t=2;
    
    for(j=l.k-1;j>=0;j--)
        if(!v[l.x[j]])
        {
            dfs(l.x[j],t,b);
            t++;
        }
        
    for(i=1;i<=n*2;i++)
      if((i>=n+1 && v[i]==v[i-n]) || (i<=n && v[i+n]==v[i]))
            {
                fout<<-1;
                return 0;
            }
            
    for(i=1;i<=n;i++)
        if(v[i]<=t/2)
            fout<<0<<" ";
        else fout<<1<<" ";
        
    return 0;
}
