#include <bits/stdc++.h>

using namespace std;
ifstream f("2sat.in");
ofstream g("2sat.out");

const int NMax = 200003;

int n,m,x,y,ok,top;
int viz[NMax],ad[NMax],s[NMax];
vector<int> G[NMax],GT[NMax];

void adaug(int &x){
    x = -x + n;
}
int negat(int x){
    if(x <= n)
        return x + n;
    else
        return x - n;
}
void dfs_top(int nod){
    viz[nod] = 1;
    for(int i = 0; i < G[nod].size(); ++i){
        if(!viz[G[nod][i]]){
            dfs_top(G[nod][i]);
        }
    }
    s[++top] = nod;
}
void dfs(int nod){
    viz[nod] = 0;
    if(ad[nod]){
        ok = 1;
        return;
    }
    ad[negat(nod)] = 1;
    for(int i = 0; i < GT[nod].size(); ++i){
        if(viz[GT[nod][i]])
            dfs(GT[nod][i]);
    }
}
int main()
{
    f >> n >> m;
    for(int i = 1; i <= m; ++i){
        f >> x >> y;

        if(x < 1)
            adaug(x);
        if(y < 1)
            adaug(y);

        G[negat(x)].push_back(y);
        G[negat(y)].push_back(x);
        GT[y].push_back(negat(x));
        GT[x].push_back(negat(y));
    }
    for(int i = 1; i <= 2 * n; ++i){
        if(!viz[i]){
            dfs_top(i);
        }
    }

    for(int i = top; i >= 1; --i){
        if(viz[s[i]] && viz[negat(s[i])]){
            dfs(s[i]);
        }
    }
    if(ok == 1){
        g << -1 << '\n';
        return 0;
    }
    for(int i = 1; i <= n; ++i){
        g << ad[i] << ' ';
    }
    return 0;
}
