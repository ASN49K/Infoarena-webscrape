#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#define NMAX 2*100005
#define MMAX 200005

using namespace std;

int n, m;
vector<int> g[NMAX], gt[NMAX];
int comp[NMAX], res[NMAX];
bool viz[NMAX] = { 0 };
stack<int> s;

void dfs1(int u) {
    if (viz[u]) return;
    viz[u] = true;
    for (auto v : g[u])
        dfs1(v);
    s.push(u);
}

void dfs2(int u, vector<int>& comp) {
    if (viz[u]) return;
    viz[u] = true;
    comp.push_back(u);
    for (auto v : gt[u])
        dfs2(v, comp);
}

void build_gt() {
    for (int i = 0;i < 2 * n;++i) 
        for (auto j : g[i]) {
            gt[j].push_back(i);
        }
}

bool is_sat() {
    for (int i = 1;i <= n;++i)
        if (comp[i + n] == comp[-i + n])
            return false;
    return true;
}

int abs(int x) {
    return ((x < 0) ? -x : x);
}

int p[MMAX][2];

int main() {

    ifstream fin("2sat.in");
    ofstream fout("2sat.out");

    fin >> n >> m;
    for (int i = 1;i <= m;++i) {
        int x, y;
        fin >> x >> y;
        p[i][0] = x;
        p[i][1] = y;
        g[-x + n].push_back(y + n);
        g[-y + n].push_back(x + n);
    }

    for (int i = 1;i <= 2 * n;++i)
        dfs1(i);
    build_gt();
    for (int i = 1;i <= 2 * n;++i)
        viz[i] = false;
    int nr = 0;
    while (!s.empty()) {
        vector<int> v;
        dfs2(s.top(), v);
        s.pop();
        for (auto x : v)
            comp[x] = nr++;
    }
    
    if (is_sat() == false) {
        fout << -1;
        return 0;
    }
    for (int i = 1;i <= n;++i)
        res[i] = -1;
    for (int i = 1;i <= n;++i) {
        if (comp[i + n] < comp[-i + n])
            res[i] = 0;
        else res[i] = 1;
    }

    for (int i = 1;i <= n;++i)
        fout << res[i] << ' ';

    return 0;
}