//https://infoarena.ro/problema/2sat

//#pragma GCC optimize("O3")   
//#pragma GCC optimize("Ofast") 
//#pragma GCC optimize("fast-math") 
//#pragma GCC optimize("unroll-loops") 
//#pragma GCC optimize("inline")  
//#define _USE_MATH_DEFINES
//#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>
//#include <cmath>
//#include <bitset>
//#include <queue>
//#include <stack>
//#include <utility>
#include <algorithm>
//#include <string>
//#include <map>
//#include <unordered_map>
//#include <set>
//#include <unordered_set>
//#include <cstdint>
//#include <climits>
//#include <iomanip>
//#include <cstdio>
//#include <tuple>

using namespace std;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

const int NMAX = 200000;

vector<int> gr[NMAX + 1];
vector<int> igr[NMAX + 1];
vector<int> rez[NMAX + 1];
vector<int> st;
int comp[NMAX + 1];
bool vx[NMAX + 1];
bool b[NMAX + 1], bb[NMAX + 1];
int n;

int modul(int x)
{
	if (x >= 0)
		return x;
	else
		return abs(x) + n;
}

int negare(int x)
{
	if (x <= n)
		return x + n; // pozitiv
	else
		return x - n; // negativ
}

void dfs(int x, const vector<int> g[], vector<int>& r, const int& k)
{
	b[x] = true;
	comp[x] = k;

	for (const auto& it : g[x])
	{
		if (!b[it])
		{
			dfs(it, g, r, k);
		}
	}
	r.push_back(x);
}

int main()
{
	//ios_base::sync_with_stdio(false);
	//cin.tie(nullptr);
	//cout.tie(nullptr);

	int m, x, y, i, k = 0;

	fin >> n >> m;

	for (i = 1; i <= m; ++i)
	{
		fin >> x >> y;
		x = modul(x);
		y = modul(y);

		//cout << x << " " << y << " " << negare(x) << " " << negare(y) << "\n";

		gr[negare(x)].push_back(y);
		gr[negare(y)].push_back(x);
		igr[x].push_back(negare(y));
		igr[y].push_back(negare(x));
	}
	
	for (i = 1; i <= n * 2; ++i)
	{
		//cout << i << " ";
		if (!b[i])
			dfs(i, gr, st, 0);
	}

	memset(b, false, sizeof b);
	
	for (i = n * 2 - 1; i >= 0; --i)
	{
		//cout << st[i] << " ";
		if (!b[st[i]])
			dfs(st[i], igr, rez[k], k++);
	}

	for (i = 1; i <= n; ++i)
	{
		if (comp[i] == comp[negare(i)])
		{
			fout << -1;
			return 0;
		}
	}

	memset(b, false, sizeof b);

	//cout << k << "\n";

	for (i = 0; i < k; ++i)
	{
		for (const auto& it : rez[i])
		{
			//cout << it << " ";

			if (!b[it] && !b[negare(it)]) // daca nu a aparut pana acum
			{
				if (it <= n) // e cu +
					vx[it] = false;
				else // e cu -
					vx[negare(it)] = true;

				b[it] = true;
				b[negare(it)] = true;
			}
		}

		//cout << "\n";
	}

	for (i = 1; i <= n; ++i)
		fout << (int)vx[i] << " ";

	return 0;
}