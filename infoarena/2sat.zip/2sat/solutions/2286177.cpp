#include <bits/stdc++.h>
using namespace std;
int n, m, j, i, x, y, nrg, nr;
vector <int> muc[200005], tr_muc[200005], vect[200005];
int grad[200005], f[200005], g[200005], ans[200005], v[200005], comp[200005];
int node(int nod)
{
    if(nod>0)return nod;
    return n-nod;
}
int value(int nod)
{
    if(nod<=n)return nod;
    return n-nod;
}
void dfs(int nod)
{
    int i;
    f[nod]=1;
    for(i=0;i<muc[nod].size();i++)
        if(f[muc[nod][i]]==0)dfs(muc[nod][i]);
    grad[++nrg]=nod;
}
void dfp(int nod)
{
    int i;
    if(f[nod]==2) return;
    f[nod]=2;
    comp[nod]=nr;
    vect[nr].push_back(nod);
    for(i=0;i<tr_muc[nod].size();i++)
        if(f[tr_muc[nod][i]]==1)dfp(tr_muc[nod][i]);
}
void solve(int nod)
{
    int i,j,rev;
    if(ans[nod]!=-1)return;
    if(vect[nod][0]>=n)rev=vect[nod][0]-n;
    else rev=vect[nod][0]+n;
    ans[nod]=0;
    ans[comp[rev]]=1;
    for(i=0;i<vect[nod].size();i++)
        for(j=0;j<muc[vect[nod][i]].size();j++)
            if(comp[muc[vect[nod][i]][j]] != comp[vect[nod][i]])
            {
                g[comp[muc[vect[nod][i]][j]]]--;
                if(g[comp[muc[vect[nod][i]][j]]]==0)solve(comp[muc[vect[nod][i]][j]]);
            }
}

int main()
{
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for(i=1;i<=m;i++)
    {
        scanf("%d%d", &x, &y);
        muc[ node(-x) ].push_back( node(y) );
        muc[ node(-y) ].push_back( node(x) );
    }
    for(i=1;i<=2*n;i++)
        dfs(i);
    for(i=1;i<=2*n;i++)
        for(j=0;j<muc[i].size();j++)
            tr_muc[muc[i][j]].push_back(i);
    for(i=1;i<=n;i++)
    {
        swap(grad[i],grad[2*n-i+1]);
    }
    for(i=1;i<=2*n;i++)
        if(f[grad[i]]!=2)
        {
            nr++;
            dfp(grad[i]);
        }

    for(i=1;i<=n;i++)
        if(comp[node(i)]==comp[node(-i)])
        {
            printf("-1\n");
            return 0;
        }

    for(i=1;i<=2*n;i++)
        for(j=0;j<muc[i].size();j++)
            if(comp[i]!=comp[muc[i][j]])g[comp[muc[i][j]]]++;
    for(i=1;i<=nr;i++)
        ans[i]=-1;

    for(i=1;i<=nr;i++)
        if(g[i]==0)solve(i);
    for(i=1;i<=nr;i++)
        for(j=0;j<vect[i].size();j++)
            v[vect[i][j]]=ans[i];
    for(i=1;i<=n;i++)
        printf("%d ",v[i]);

    return 0;
}
