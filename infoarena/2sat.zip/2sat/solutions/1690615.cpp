#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
#define MAX 100010
pair<int, int> e[2 * MAX];
typedef vector <int> :: iterator iter;
vector <int> G[2 * MAX];
int viz[2 * MAX], val[2 * MAX];
int st[2 * MAX], dr;
void df(int nod)
{
    if(viz[nod + MAX])
        return;
    viz[nod + MAX] = 1;
    for(iter it = G[nod + MAX].begin() ; it != G[nod + MAX].end() ; it++)
    {
        df(*it);
    }
    st[++dr] = nod;
}

int main()
{
    int n, m, i, ok;
    fin >> n >> m;
    for(i = 1 ; i <= m ; i++)
    {
        fin >> e[i].first >> e[i].second;
        G[-e[i].first + MAX].push_back(e[i].second);
        G[-e[i].second + MAX].push_back(e[i].first);
    }
    for(i = -n ; i <= n ; i++)
    {
        if(i)
            df(i);
    }
    for(i = dr ; i >= 1 ; i--)
    {
        if(!val[st[i] + MAX] && !val[-st[i] + MAX])
        {
            val[-st[i] + MAX] = 1;
           // cout << -st[i] << "\n";
        }
    }
    ok = 1;
    for(i = 1 ; i <= n ; i++)
    {
        if(!val[e[i].first + MAX] && !val[e[i].second + MAX])
        {
            ok = 0;
        }
    }
    if(ok)
    {
        for(i = 1 ; i <= n ; i ++)
        {
            fout << val[i + MAX] << " ";
        }
        fout << "\n";
    }
    else
    {
        fout << -1 << "\n";
    }
}
