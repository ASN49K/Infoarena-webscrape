// ConsoleApplication7.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <fstream>
#include<vector>
#include <iostream>

using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");

int n, m;
typedef vector<int> VEC[200001];

VEC a, b;
int v[200001];
struct
{
	int x[200001];
	int k;
}l;

void dfs(int i, int t, VEC &a)
{
	int j;
	v[i] = t;
	for (j = 0; j<a[i].size(); j++)
		if (!v[a[i][j]])
			dfs(a[i][j], t, a);
	if (t == 1)
		l.x[l.k++] = i;
}
void draw_arc(int x, int y, VEC &a)
{
	if (x<0)x = x*-1 + n;
	if (y<0)y = y*-1 + n;
	a[x].push_back(y);
}
int main()
{
	fin >> n >> m;
	int j, i;
	while (m--)
	{
		fin >> i >> j;
		draw_arc(i*-1, j, a);
		draw_arc(j*-1, i, a);

		draw_arc(j, i*-1, b);
		draw_arc(i, j*-1, b);
	}
	for (j = 1; j <= n * 2; j++)
		if (!v[j])
			dfs(j, 1, a);
	for (i = 0; i <= n * 2; i++)v[i] = 0;
	int t = 2;
	for (j = l.k - 1; j >= 0; j--)
		if (!v[l.x[j]])
		{
			dfs(l.x[j], t, b);
			t++;
		}
	for (i = 1; i <= n * 2; i++)
		if ((i >= n + 1 && v[i] == v[i - n]) || (i <= n && v[i + n] == v[i]))
		{
			fout << -1;
			return 0;
		}
	for (i = 1; i <= 2 * n; i++)
		if (v[i] <= t / 2 || v[i] == 0)
			fout << 0;
		else
			fout << 1;
		return 0;
}