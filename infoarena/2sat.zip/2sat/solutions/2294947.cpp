#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>

using namespace std;

ifstream in("2sat.in");
ofstream out("2sat.out");

const int NMAX = 200005;

vector<int> g[NMAX];
vector<bool> visited(NMAX, 0);

vector<int> sorted;

void dfs(int from) {
    visited[from] = 1;
    for(auto it : g[from])
        if(!visited[it])
            dfs(it);
    sorted.push_back(from);
}

vector<int> gT[NMAX];
vector<int> component(NMAX, 0);

void dfsT(int from, int nr) {
    component[from] = nr;
    for(auto it : gT[from])
        if(!component[it])
            dfsT(it, nr);
}

int main() {

    int n, m;
    in >> n >> m;
    for(int i = 1; i <= m; i ++) {
        int x, y, negx, negy;
        in >> x >> y;
        negx = (x < 0);
        negy = (y < 0);
        x = max(x, -x);
        y = max(y, -y);

        g[x * 2 + (!negx)].push_back(y * 2 + negy);
        g[y * 2 + (!negy)].push_back(x * 2 + negx);

        gT[y * 2 + negy].push_back(x * 2 + (!negx));
        gT[x * 2 + negx].push_back(y * 2 + (!negy));
    }

    for(int i = 2; i <= 2 * n + 1; i ++)
        if(!visited[i])
            dfs(i);
    reverse(sorted.begin(), sorted.end());

    int ncomponents = 0;
    for(auto node : sorted)
        if(!component[node])
            dfsT(node, ++ ncomponents);
    bool havesol = 1;
    for(int i = 2; i <= 2 * n + 1; i ++)
        if(component[i] == component[i ^ 1])
            havesol = 0;

    if(havesol == 0)
        out << -1;
    else {
        for(int i = 1; i <= n; i ++)
            out << (component[i * 2] > component[i * 2 + 1]) << " ";
    }

    return 0;
}
