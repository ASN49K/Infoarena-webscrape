#include <bits/stdc++.h>

using namespace std;
vector<int>nod[200005];
vector<pair<int,int> >op;
int n,m,a,b;
bool viz[200005],ans[200005];
stack<int>stk;
void go_visit(int pos)
{
    viz[pos]=true;
    for(int i=0;i<nod[pos].size();i++)
        if(!viz[nod[pos][i]])
            go_visit(nod[pos][i]);
    stk.push(pos-n);
}
int main()
{
    ifstream fin("2sat.in");
    ofstream fout("2sat.out");
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>a>>b;
        op.push_back({a,b});
        nod[-a+n].push_back(b+n);
        nod[-b+n].push_back(a+n);
    }
    for(int i=0;i<=2*n;i++)
        if(!viz[i])
            go_visit(i);
    while(!stk.empty())
    {
        int pos=stk.top();
        if(!ans[pos+n] && !ans[-pos+n])
            ans[-pos+n]=true;
        stk.pop();
    }
    for(int i=0;i<m;i++)
        if(!ans[op[i].first+n] && !ans[op[i].second+n])
        {
            fout<<-1;
            return 0;
        }
    for(int i=n+1;i<=2*n;i++)
        fout<<ans[i]<<" ";
    return 0;
}
