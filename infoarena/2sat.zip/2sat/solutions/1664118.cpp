#include<cstdio>
#include<vector>
#include<stack>
#include<cstring>
const int NMAX=200002;
std::vector<int> vecini[NMAX];
std::vector<int> inv_vecini[NMAX];
std::stack<int> stiva;
bool viz[NMAX];
int multimi[NMAX];
int n,m;
void componente(int nod)
{
 viz[nod]=true;
 bool pp=false;
 for(std::vector<int>::iterator it=vecini[nod].begin();it!=vecini[nod].end();it++)
     {
      if(!viz[*it])
         {
          pp=true;
          componente((*it));
         }
     }
 stiva.push(nod);
}
void verificare(int nod,int _multime)
{
 multimi[nod]=_multime;
 viz[nod]=true;
 for(std::vector<int>::iterator it=inv_vecini[nod].begin();it!=inv_vecini[nod].end();it++)
     {
      if(!viz[*it])
         {
          verificare((*it),_multime);
         }
     }
}
int negatie(int x)
{
 return x<=n?x+n:x-n;
}
int normala(int x)
{
 return x<0?-x:x+n;
}
int main()
{
 FILE *in=fopen("2sat.in","r");
 fscanf(in,"%d %d ",&n,&m);
 for(int i=1;i<=m;i++)
     {
      int x,y;
      fscanf(in,"%d %d ",&x,&y);
      x=normala(x);
      y=normala(y);
      vecini[negatie(x)].push_back(y);
      vecini[negatie(y)].push_back(x);
      inv_vecini[x].push_back(negatie(y));
      inv_vecini[y].push_back(negatie(x));
     }
 fclose(in);
 for(int i=1;i<=2*n;i++)
     if(!viz[i])
        componente(i);
 FILE *out=fopen("2sat.out","w");
 int _multime=1;
 memset(viz,0,sizeof viz);
 for(int i=1;i<=2*n;i++)
     {
      if(!viz[stiva.top()])
         {
          verificare(stiva.top(),_multime++);
         }
      stiva.pop();
     }
 bool se_poate=true;
 for(int i=1;i<=n;i++)
     if(multimi[i]==multimi[negatie(i)])
        se_poate=false;
 if(!se_poate)
    fprintf(out,"-1");
 else
    for(int i=1;i<=n;i++)
        fprintf(out,"%d ",multimi[i]>multimi[negatie(i)]?0:1);
 fprintf(out,"\n");
 fclose(out);
 return 0;
}
