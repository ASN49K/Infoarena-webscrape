#include <bits/stdc++.h>

using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
typedef pair<int,int> pii;
int n,m,comp[200005],nr,sol[200005];
bool use[200005];
vector<int> muchii[200005],c[200005];
vector<pii> G;
vector<int> st;
void dfs(int nod)
{
    use[nod]=1;
    for(auto i:muchii[nod])
        if(!use[i])
            dfs(i);
    st.push_back(nod);
}
void dfs1(int nod)
{
    comp[nod]=nr;
    use[nod]=1;
    for(auto i:muchii[nod])
        if(!use[i])
            dfs1(i);
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int x,y;
        fin>>x>>y;
        muchii[-x+n].push_back(y+n);
        G.push_back({-x+n,y+n});
        muchii[-y+n].push_back(x+n);
        G.push_back({-y+n,x+n});
    }
    for(int i=1;i<=n;i++)
    {
        if(!use[i+n])
            dfs(i+n);
        if(!use[-i+n])
            dfs(-i+n);
    }
    reverse(st.begin(),st.end());
    for(int i=1;i<=n;i++)
    {
        muchii[i+n].clear();
        muchii[-i+n].clear();
        use[i+n]=0;
        use[-i+n]=0;
    }
    for(auto j:G)
        muchii[j.second].push_back(j.first);
    for(auto i:st)
    {
        //cout<<i<<" ";
        if(!use[i])
        {
            nr++;
            dfs1(i);
        }
    }
    for(int i=1;i<=n;i++)
    {
        c[comp[i+n]].push_back(i);
        c[comp[-i+n]].push_back(-i);
        if(comp[i+n]==comp[-i+n])
        {
            fout<<-1;
            return 0;
        }
    }
    for(int i=1;i<=nr/2;i++)
    {
        for(auto j:c[i])
        {
            if(j>0)
                sol[j]=0;
            else
                sol[-j]=1;
        }
    }
    for(int i=1;i<=n;i++)
        fout<<sol[i]<<" ";
    return 0;
}
