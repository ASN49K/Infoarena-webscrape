#include <bits/stdc++.h>

using namespace std;
ifstream in("2sat.in");
ofstream out("2sat.out");

#define ll long long
#define ull unsigned long long
#define ui unsigned int
#define pb push_back
#define mp make_pair
const int NMax = 1e5 + 5;
const int inf = 1e9 + 5;
using zint = int;

int N,M;
int sol[NMax],aux[NMax];
pair<int,int> ex[2*NMax];
vector< pair<int,int> > v[NMax];

bool test(int,int);
bool eval(int);
void cpy(int*,int*);

int main() {
    in>>N>>M;
    for (int i=1;i <= M;++i) {
        int x,y;
        in>>x>>y;

        ex[i] = mp(x,y);
        v[abs(x)].pb( mp(abs(y),i) );
        v[abs(y)].pb( mp(abs(x),i) );
    }

    for (int i=1;i <= N;++i) {
        sol[i] = -1;
    }

    bool ans = true;
    for (int i=1;i <= N;++i) {
        if (sol[i] != -1) {
            continue;
        }

        bool ok = false;
        if (test(i,0) || test(i,1)) {
            ok = true;
        }

        if (ok) {
            cpy(sol,aux);
        }
        else {
            ans = false;
            break;
        }
    }

    if (ans) {
        for (int i=1;i <= N;++i) {
            out<<sol[i]<<' ';
        }
    }
    else {
        out<<"-1\n";
    }

    in.close();out.close();
    return 0;
}

bool test(int idx,int val) {
    cpy(aux,sol);
    aux[idx] = val;

    queue<int> Q;
    Q.push(idx);
    while (Q.size()) {
        int lit = Q.front(); Q.pop();

        for (auto p : v[lit]) {
            int nxt = p.first, nr = p.second;
            if (aux[nxt] != -1) {
                if (eval(nr)) {
                    continue;
                }
                return false;
            }

            aux[nxt] = 0;
            bool val0 = eval(nr);

            aux[nxt] = 1;
            bool val1 = eval(nr);

            if (val0) {
                if (val1) {
                    aux[nxt] = -1;
                    continue;
                }
                aux[nxt] = 0;
            }
            if (val1) {
                aux[nxt] = 1;
            }

            Q.push(nxt);
        }
    }

    return true;
}

bool eval(int nr) {
    int x = ex[nr].first,
        y = ex[nr].second,
        val1 = aux[abs(x)],
        val2 = aux[abs(y)];
    if (x < 0) {val1 ^= 1;}
    if (y < 0) {val2 ^= 1;}

    return val1 | val2;
}

void cpy(int* a,int* b) {
    for (int i=1;i <= N;++i) {
        a[i] = b[i];
    }
}
