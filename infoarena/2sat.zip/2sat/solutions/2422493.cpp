#include <bits/stdc++.h>

using namespace std;

vector<int> g[200010];
vector<int> t[200010];
int viz[200010];
vector<int> dfsRes;
int n, m;
int comp[200010];
int compCurenta;

int val[200010];
vector<int> ord;

void dfs(int nod)
{
    if(viz[nod])
        return;
    viz[nod] = 1;
    for(int v : g[nod])
    {
        dfs(v);
    }
    dfsRes.push_back(nod);
}

void dfst(int nod)
{
    if(viz[nod] == 0)
        return;
    viz[nod] = 0;
    comp[nod] = compCurenta;
    ord.push_back(nod);
    for(int v : t[nod])
    {
        dfst(v);
    }
}

int main() {
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);
    cin >> n >> m;
    for(int i = 0; i < m; i++)
    {
        int a, b;
        cin >> a >> b;
        if(a < 0)
            a = -2 * a + 1;
        else a = 2 * a;
        if(b < 0)
            b = -2 * b + 1;
        else b = 2 * b;
        g[a ^ 1].push_back(b);
        g[b ^ 1].push_back(a);

        t[a].push_back(b ^ 1);
        t[b].push_back(a ^ 1);
    }

    for(int i = 2; i <= 2 * n + 1; i++)
        val[i] = -1;

    for(int i = 2; i <= 2 * n + 1; i++)
    {
        dfs(i);
    }
    for(int i = dfsRes.size() - 1; i >= 0; i--)
    {
        if(viz[dfsRes[i]] == 1)
        {
            compCurenta++;
            dfst(dfsRes[i]);
        }
    }

    for(int i = 1; i <= n; i++)
    {
        if(comp[i * 2] == comp[i * 2 + 1])
        {
            cout << -1;
            return 0;
        }
    }

    for(int nod : ord)
    {
        if(val[nod] == -1)
        {
            val[nod] = 0;
            val[nod ^ 1] = 1;
        }
    }

    for(int i = 1; i <= n; i++)
        cout << val[i * 2] << " ";

    return 0;
}