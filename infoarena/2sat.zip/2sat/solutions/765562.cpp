#include<cstdio>
#define N 200001
int p[N],n,m,i,a[N],b[N],j,w[N],c[N],nr,k,*f[N],*g[N],u[N],v[N];

void A(int x)
{int i;
c[x]=1;
for(i=0;i<u[x];i++)
if(!c[f[x][i]])
       A(f[x][i]);
w[++nr]=x;}

void B(int x)
{int i;
c[x]=0;
if(p[x]==2)
       {p[x]=0;
       if(x>n)
               p[x-n]=1;
       else
               p[x+n]=1;}
for(i=0;i<v[x];i++)
if(c[g[x][i]])
       B(g[x][i]);}

int main()
{freopen("2sat.in","r",stdin);
freopen("2sat.out","w",stdout);
scanf("%d%d",&n,&m);
for(i=1;i<=m;i++)
       {scanf("%d%d",&a[i],&b[i]);
       if(a[i]<0)
              a[i]=n-a[i];
       if(b[i]<0)
              b[i]=n-b[i];
       if(a[i]>n)
              u[a[i]-n]++,v[b[i]]++;
       else
              u[a[i]+n]++,v[b[i]]++;
       if(b[i]>n)
              u[b[i]-n]++,v[a[i]]++;
       else
              u[b[i]+n]++,v[a[i]]++;}
for(i=1;i<=2*n;i++)
       f[i]=new int[u[i]],g[i]=new int[v[i]],u[i]=v[i]=0,p[i]=2;
for(i=1;i<=m;i++)
       {if(a[i]>n)
              f[a[i]-n][u[a[i]-n]++]=b[i],g[b[i]][v[b[i]]++]=a[i]-n;
       else
              f[a[i]+n][u[a[i]+n]++]=b[i],g[b[i]][v[b[i]]++]=a[i]+n;
       if(b[i]>n)
              f[b[i]-n][u[b[i]-n]++]=a[i],g[a[i]][v[a[i]]++]=b[i]-n;
       else
              f[b[i]+n][u[b[i]+n]++]=a[i],g[a[i]][v[a[i]]++]=b[i]+n;}
for(j=1;j<=2*n;j++)
if(!c[j])
       A(j);
for(i=nr;i;i--)
if(c[i])
       B(w[i]);
for(j=1;j<=n;j++)
if(p[j]==2)
       p[j]=0,p[j+n]=1;
for(i=1;i<=m;i++)
if(!p[a[i]]&&!p[b[i]])
       {p[a[i]]=1;
       if(a[i]>n)
                p[a[i]-n]=0;
       else
                p[a[i]+n]=0;}
for(k=0,j=1;j<=m;j++)
if(!p[a[j]]&&!p[b[j]])
       k=1;
if(!k)
       for(i=1;i<=n;i++)
              printf("%d ",p[i]);
else
       printf("-1");
return 0;}
