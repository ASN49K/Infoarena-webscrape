#include <fstream>
#include <vector>

using namespace std;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

const int nmax= 100000;
const int nmax2= 200000;

bool u[nmax2+1];
int r[nmax2+1];

vector <int> gi[nmax2+1], go[nmax2+1], v[nmax2+1], l;

void dfs( int x ) {
    if ( u[x]==0 ) {
        u[x]= 1;
        for ( vector <int>::iterator it= go[x].begin(); it!=go[x].end(); ++it ) {
            dfs(*it);
        }
        l.push_back(x);
    }
}

void assign( int x, int root ) {
    if ( r[x]==0 ) {
        r[x]= root;
        v[root].push_back(x);
        for ( vector <int>::iterator it= gi[x].begin(); it!=gi[x].end(); ++it ) {
            assign(*it, root);
        }
    }
}

void make_edge( int x, int y ) {
    go[x].push_back(y);
    gi[y].push_back(x);
}

int main(  ) {
    int n, m;
    fin>>n>>m;
    for ( int cnt= 1, x, y, x2, y2; cnt<=m; ++cnt ) {
        fin>>x>>y;
        x2= x+n, y2= y+n;
        if ( x<0 ) {
            x2= -x, x= n-x;
        }
        if ( y<0 ) {
            y2= -y, y= n-y;
        }

        make_edge(x2, y), make_edge(y2, x);
    }

    for ( int i= 1; i<=n*2; ++i ) {
        dfs(i);
    }
    int nr= 0;
    for ( vector <int>::reverse_iterator it= l.rbegin(); it!=l.rend(); ++it ) {
        if ( r[*it]==0 ) {
            ++nr;
        }
        assign(*it, nr);
    }

    for ( int i= 1; i<=n; ++i ) {
        if ( r[i]==r[i+n] ) {
            fout<<"-1\n";
            return 0;
        }
    }

    for ( int i= 1; i<=n; ++i ) {
        if ( r[i]>r[i+n] ) {
            fout<<"1 ";
        } else {
            fout<<"0 ";
        }
    }
    fout<<"\n";

    return 0;
}