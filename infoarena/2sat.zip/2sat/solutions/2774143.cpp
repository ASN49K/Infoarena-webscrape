#include <bits/stdc++.h>

using namespace std;
ifstream f("2sat.in");
ofstream g("2sat.out");
int n;
vector <int> v[100005],inv[100005];
int nod (int x)
{
    if (x<0)
    {
        return n+abs(x);
    }
    return x;
}
void adauga(int x,int y)
{
    x=nod(x),y=nod(y);
    v[x].push_back(y);
    inv[y].push_back(x);
}
int viz[100005],sal[400005],q;
void dfs(int x)
{
    int i;
    viz[x]=1;
    for (i=0;i<v[x].size();i++)
    {
        int nod=v[x][i];
        if (viz[nod]==0)
        {
            dfs(nod);
        }
    }
    sal[++q]=x;
}
int nr;
vector <int> comp[400005];
void dfs2(int x)
{
    int i;
    comp[nr].push_back(x);
    viz[x]=1;
    for (i=0;i<inv[x].size();i++)
    {
        int nod=inv[x][i];
        if (viz[nod]==0)
        {
            dfs2(nod);
        }
    }
}
int m,i,x,y,grupa[100005],val[100005],ok[100005],j;
int main()
{
    f>>n>>m;
    for (i=1;i<=m;i++)
    {
        f>>x>>y;
        adauga(-x,y);
        adauga(-y,x);
    }
    for (i=1;i<=n;i++)
    {
        if (viz[i]==0)
        {
            dfs(i);
        }
    }
    nr=0;
    memset(viz,0,sizeof(viz));
    for (i=q;i>=1;i--)
    {
        if (viz[sal[i]]==0)
        {
            nr++;
            dfs2(sal[i]);
        }
    }
    for (i=1;i<=nr;i++)
    {
        for (int j=0;j<comp[i].size();j++)
        {
            grupa[comp[i][j]]=i;
        }
    }
    for (i=1;i<=n;i++)
    {
        if (grupa[i]==grupa[i+n])
        {
            cout<<"-1"<<'\n';
            return 0;
        }
    }
    for (i=1;i<=n;i++)
    {
        if (ok[grupa[i]]==0)
        {
            ok[grupa[i]]=1;
            ok[grupa[i+n]]=1;
            for (j=0;j<comp[grupa[i]].size();j++)
            {
                int nod=comp[grupa[i]][j];
                if (nod<=n)
                {
                    val[nod]=1;
                }
                else
                {
                    val[nod-n]=0;
                }
            }
        }
    }
    for (i=1;i<=n;i++)
    {
        g<<val[i]<<" ";
    }
    return 0;
}
