# include <fstream>
# include <vector>
# define DIM 200010
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
vector<int> Lista[DIM];
int Marcat[DIM],low[DIM],poz[DIM],s[DIM],d[DIM],ctc[DIM];
int n,m,i,x,y,niv,ok=1,u;
int rv(int x){
    if(x<=n)
        return x+n;
    return x-n;
}
void tarjan(int nc){
    if(ok==0)
        return;
    niv++;
    low[nc]=niv;
    poz[nc]=niv;
    s[++u]=nc;
    Marcat[nc]=1;
    for(int i=0;i<Lista[nc].size();i++){
        int nv=Lista[nc][i];
        if(poz[nv]==0)
            tarjan(nv);
        if(Marcat[nv]==1)
            low[nc]=min(low[nc],low[nv]);
    }
    if(low[nc]==poz[nc]){
        int val=0,k=0;
        while(s[u]!=nc){
            Marcat[s[u]]=0;
            val=d[s[u]];
            ctc[++k]=s[u];
            u--;
        }
        Marcat[s[u]]=0;
        val=d[s[u]];
        ctc[++k]=s[u];
        u--;
        if(val==0)
            val=1;
        for(int i=1;i<=k;i++){
            d[ctc[i]]=val;
            if(d[ctc[i]]==d[rv(ctc[i])]){
                fout<<"-1\n";
                ok=0;
                return;
            }
            d[rv(ctc[i])]=3-val;
        }
    }
}
int main () {
    fin>>n>>m;
    for(i=1;i<=m;i++){
        fin>>x>>y;
        if(x<0)
            x=-x+n;
        if(y<0)
            y=-y+n;
        Lista[rv(x)].push_back(y);
        Lista[rv(y)].push_back(x);
    }
    for(i=1;i<=n;i++)
        if(poz[i]==0)
            tarjan(i);
    if(ok==0)
        return 0;
    for(i=1;i<=n;i++)
        fout<<d[i]%2<<" ";
    fout<<"\n";
    return 0;
}
