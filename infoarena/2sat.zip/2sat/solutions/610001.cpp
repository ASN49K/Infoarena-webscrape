#include<stdio.h>
#include<vector.h>
#define pb push_back
#define N 200001
int p[N];
long n,m,i,a[N],b[N],j,w[N],c[N],nr,k;
vector<long> f[N],g[N];

void dfs(long x)
{long i;
c[x]=1;
for(i=0;i<f[x].size();i++)
if(!c[f[x][i]])
       dfs(f[x][i]);
w[++nr]=x;}

void dfst(long x)
{long i;
c[x]=0;
if(p[x]==2)
       {p[x]=0;
       if(x>n)
               p[x-n]=1;
       else
               p[x+n]=1;}
for(i=0;i<g[x].size();i++)
if(c[g[x][i]])
       dfst(g[x][i]);}

int main()
{freopen("2sat.in","r",stdin);
freopen("2sat.out","w",stdout);
scanf("%ld%ld",&n,&m);
for(i=1;i<=m;i++)
       {scanf("%ld%ld",&a[i],&b[i]);
       if(a[i]<0)
              a[i]=n-a[i];
       if(b[i]<0)
              b[i]=n-b[i];
       if(a[i]>n)
              f[a[i]-n].pb(b[i]),g[b[i]].pb(a[i]-n);
       else
              f[a[i]+n].pb(b[i]),g[b[i]].pb(a[i]+n);
       if(b[i]>n)
              f[b[i]-n].pb(a[i]),g[a[i]].pb(b[i]-n);
       else
              f[b[i]+n].pb(a[i]),g[a[i]].pb(b[i]+n);}
for(j=1;j<=2*n;j++)
       {p[j]=2;
       if(!c[j])
                dfs(j);}
for(i=nr;i;i--)
if(c[i])
       dfst(w[i]);
for(j=1;j<=n;j++)
if(p[j]==2)
       p[j]=0,p[j+n]=1;
for(i=1;i<=m;i++)
if(!p[a[i]]&&!p[b[i]])
       {p[a[i]]=1;
       if(a[i]>n)
                p[a[i]-n]=0;
       else
                p[a[i]+n]=0;}
k=0;
for(j=1;j<=m;j++)
if(!p[a[j]]&&!p[b[j]])
       k=1;
if(!k)
       for(i=1;i<=n;i++)
              printf("%d ",p[i]);
else
       printf("-1");
return 0;}
