#include <cstdio>
#include <vector>
#include <algorithm>

const int MAX_N = 100000;

int n;

int conj(int node) {
  if (node <= n)
    return node + n;
  return node - n;
}

std::vector<int> g[1 + 2 * MAX_N];
std::vector<int> trans[1 + 2 * MAX_N];
std::vector<int> topo;
bool viz[1 + 2 * MAX_N];
bool val[1 + 2 * MAX_N];
bool possible = true;

void topoSort(int u) {
  viz[u] = true;
  for (auto v : g[u]) {
    if (!viz[v])
      topoSort(v);
  }
  topo.push_back(u);
}

void markNodes(int u) {
  viz[u] = true;
  if (val[u]) {
    possible = false;
    return;
  }
  val[u] = false;
  val[conj(u)] = true;
  for (auto v : trans[u]) {
    if (!viz[v])
      markNodes(v);
  }
}

int main() {
  freopen("2sat.in", "r", stdin);
  freopen("2sat.out", "w", stdout);

  int m;
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= m; i++) {
    int u, v;
    scanf("%d%d", &u, &v);
    if (u < 0)
      u = n - u;
    if (v < 0)
      v = n - v;
    g[conj(u)].push_back(v);
    trans[v].push_back(conj(u));
    g[conj(v)].push_back(u);
    g[u].push_back(conj(v));
  }
  for (int i = 1; i <= 2 * n; i++) {
    if (!viz[i])
      topoSort(i);
  }
  std::reverse(topo.begin(), topo.end());
  for (int i = 1; i <= 2 * n; i++)
    viz[i] = false;
  for (auto node : topo) {
    if (!viz[node] && !viz[conj(node)])
      markNodes(node);
    if (!possible) {
      printf("-1\n");
      return 0;
    }
  }
  for (int i = 1; i <= n; i++)
    printf("%d ", val[i]);
  printf("\n");
  return 0;
}
