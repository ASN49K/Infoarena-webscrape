#include<algorithm>
#include<bitset>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<deque>
#include<fstream>
#include<iomanip>
#include<iostream>
#include<map>
#include<queue>
#include<set>
#include<stack>
#include<unordered_map>
#include<unordered_set>
#include<utility>
#include<vector>

using namespace std;

#ifdef HOME
const string inputFile = "input.txt";
const string outputFile = "output.txt";
#else
const string problemName = "2sat";
const string inputFile = problemName + ".in";
const string outputFile = problemName + ".out";
#endif

const int NMAX = 200000 + 5;

int N, M, sol;
vector<int> V[NMAX];
vector<int> W[NMAX];
bool viz[NMAX];
int T[NMAX], cnt;
int C[NMAX], ctc;
#define V (V+NMAX/2)
#define W (W+NMAX/2)
#define viz (viz+NMAX/2)
#define C (C+NMAX/2)

void dfs(int x) {
    viz[x] = 1;

    for(auto y : V[x])
        if(!viz[y])
            dfs(y);

    T[++cnt] = x;
}

void dfst(int x) {
    viz[x] = 0;

    for(auto y : W[x])
        if(viz[y])
            dfst(y);

    C[x] = ctc;
}

int main() {
    int i, x, y;

#ifndef ONLINE_JUDGE
    freopen(inputFile.c_str(), "r", stdin);
    freopen(outputFile.c_str(), "w", stdout);
#endif

    scanf("%d%d", &N, &M);

    while(M--) {
        scanf("%d%d", &x, &y);
        V[-x].push_back(y);
        V[-y].push_back(x);
        W[y].push_back(-x);
        W[x].push_back(-y);
    }

    for(i = -N; i <= N; i++)
        if(!viz[i])
            dfs(i);

    for(i = cnt; i >= 1; i--)
        if(viz[T[i]]) {
            ctc++;
            dfst(T[i]);
        }

    sol = 1;

    for(i = 1; i <= N; i++)
        if(C[i] == C[-i])
            sol = 0;

    if(!sol)
        printf("-1\n");
    else
        for(i = 1; i <= N; i++)
            printf("%d ", C[i] > C[-i]);

    return 0;
}
