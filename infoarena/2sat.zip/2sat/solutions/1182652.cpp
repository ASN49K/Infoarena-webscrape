#include<fstream>
#include<vector>
#define NM 100010
#define ROF(a,b,c) for(int a=b;a>=c;--a)
#define FOR(a,b,c) for(int a=b;a<=c;++a)
#define pb push_back
 
using namespace std;
 
ifstream f("2sat.in");
ofstream g("2sat.out");
 
vector<int> v[NM*2];
int n,m,x,y,viz[NM*2],top[NM*2],val[NM*2],E1[NM*2],E2[NM*2];
 
#define viz (viz+NM)
#define val (val+NM)
#define v (v+NM)
 
void dfs(int x)
{
     
    viz[x]=1;
    for(int i=0;i<v[x].size();++i)
        if(!viz[v[x][i]])
            dfs(v[x][i]);
    top[++top[0]]=x;
}
 
int main ()
{
    f>>n>>m;
     
    FOR(i,1,m)
    {
        f>>x>>y;
        E1[i]=x;
        E2[i]=y;
        v[x].pb(-y);
        v[y].pb(-x);
    }
     
    FOR(i,1,n)
    if(!viz[i])
        dfs(i);
     
    FOR(i,1,2*n)
    if(!val[top[i]]&&!val[-top[i]])
        val[-top[i]]=1;
     
    FOR(i,1,m)
    {
        x=E1[i];
        y=E2[i];
        if((val[-x]&&!val[y])||(val[-y]&&!val[x]))
        {
            g<<"-1";
            return 0;
        }
    }
     
    FOR(i,1,n)
    g<<val[i]<<" ";
    return 0;
}