#include <bits/stdc++.h>

using namespace std;

void dfs(int node, vector<int> &discovery, vector<bool> &in_stack,
         vector<int> &lowest, stack<int> &s, vector<vector<int>> &adj,
         vector<vector<int>> &ctcs, int &t) {

  discovery[node] = ++t;
  lowest[node] = discovery[node];
  s.push(node);
  in_stack[node] = true;
  for (int neigh : adj[node]) {
    if (discovery[neigh] && !in_stack[neigh])
      continue;

    if (!discovery[neigh])
      dfs(neigh, discovery, in_stack, lowest, s, adj, ctcs, t);

    lowest[node] = min(lowest[node], lowest[neigh]);
  }

  if (lowest[node] == discovery[node]) {
    ctcs.push_back(vector<int>{});

    int x;
    do {
      x = s.top();
      ctcs.back().push_back(x);

      s.pop();
      in_stack[x] = false;
    } while (x != node);
  }
}

inline int rep(int term) {
  if (term < 0)
    return ((-term) << 1) | 1;

  return (term << 1);
}

int main() {
  freopen("2sat.in", "r", stdin);
  freopen("2sat.out", "w", stdout);

  int n, m;
  cin >> n >> m;
  n <<= 1;

  vector<vector<int>> adj(2 + n, vector<int>()), ctcs;
  for (int edge = 1, a, b; edge <= m; ++edge) {
    cin >> a >> b;
    a = rep(a);
    b = rep(b);

    adj[a ^ 1].push_back(b);
    adj[b ^ 1].push_back(a);
  }

  stack<int> s;
  vector<int> discovery(2 + n, 0), lowest(2 + n);
  vector<bool> in_stack(2 + n, false);
  for (int i = 2, t = 0; i <= n; ++i)
    if (!discovery[i])
      dfs(i, discovery, in_stack, lowest, s, adj, ctcs, t);

  vector<int> ctc_values(2 + n), belonging(2 + n);
  for (int i = 0; i < ctcs.size(); ++i)
    for (int node : ctcs[i])
      belonging[node] = i;

  for (int i = 2; i <= n + 1; i += 2)
    if (belonging[i] == belonging[i ^ 1]) {
      cout << "-1\n";
      return 0;
    }

  for (int i = 2; i <= n + 1; i += 2) {
    if (belonging[i] < belonging[i ^ 1]) {
      cout << "1 ";
    } else {
      cout << "0 ";
    }
  }

  cout << endl;
  return 0;
}
