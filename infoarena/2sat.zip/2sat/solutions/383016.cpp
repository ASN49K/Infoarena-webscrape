#include<stdio.h>
#include<time.h>
#include<stdlib.h>
#include<vector>
using namespace std;
#define nmax 100002
#define mmax 200002
#define tmax 120000000
#define f first
#define s second
int n,m,sol[nmax];
pair<int,int> v[mmax];

inline int abs(int a){return a<0?-a:a;}

inline bool cond(int i)
{
	int x=sol[abs(v[i].f)],y=sol[abs(v[i].s)];
	if(v[i].f<0)
		x^=1;
	if(v[i].s<0)
		y^=1;
	return x|y;
}

int main()
{
	srand(time(0));
	freopen("2sat.in","r",stdin);
	freopen("2sat.out","w",stdout);
	scanf("%d%d",&n,&m);
	int i,j,a,b;
	for(i=1;i<=m;i++)
	{
		scanf("%d%d",&a,&b);
		v[i]=make_pair(a,b);
	}
	int lim=tmax/m;
	for(i=1;i<=lim;i++)
	{
		for(j=1;j<=m;j++)
		{
			if(cond(j)==0)
			{
				if(rand()&1)
					sol[abs(v[j].f)]^=1;
				else
					sol[abs(v[j].s)]^=1;
				break;
			}
		}
		if(j==m+1)
		{
			for(j=1;j<=n;j++)
				printf("%d ",sol[j]);
			return 0;
		}
	}
	printf("-1\n");
	return 0;
}
