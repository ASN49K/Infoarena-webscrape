#include<bitset>
#include <fstream>
#define inv(a) (a<=n)?(n+a):(a-n)
#define pb(a) push_back(a)
#include<vector>
#include<iostream>
#include<queue>
using namespace std;
vector<int> v[200002],vt[200002];
bitset<200002> viz,rez;
int n,m,k;
queue<int> poz;
void pl(int nod)
{
     viz[nod]=true;
     poz.push(nod);
     for(int i=0;i<v[nod].size();i++)
     if(!viz[v[nod][i]])
     pl(v[nod][i]);
     
}

void mi(int nod)
{
     viz[nod]=true;
     rez[inv(nod)]=true;
     for(int i=0;i<vt[nod].size();i++)
     if(!viz[vt[nod][i]])
     if(!rez[vt[nod][i]])
     mi(vt[nod][i]);
     else{
     n=0; return;}
     }

int main ()
{int x,y,i;
ifstream f("2sat.in");
 ofstream g("2sat.out");
f>>n>>m;
while(m)
{f>>x>>y;
if(x<0) x=n-x;
if(y<0) y=n-y;
v[inv(x)].pb(y);
v[inv(y)].pb(x);
vt[x].pb(inv(y));
vt[y].pb(inv(x));
        m--;}

for(i=1;i<=n+n;i++)
if(!viz[i])
pl(i);

viz.reset();
while(!poz.empty())
{if(!rez[poz.front()]&&!rez[inv(poz.front())])
mi(poz.front());
poz.pop();}
if(n)
for(i=1;i<=n;i++)
g<<rez[i]<<" ";
else
g<<-1;
g<<'\n';
 f.close(); g.close();
return 0;
}
