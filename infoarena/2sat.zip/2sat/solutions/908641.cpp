#include <stdio.h>
#include <string.h>
#include <vector>
#include <stack>
#define NMax 100010
#define LMax 2*NMax
using namespace std;

const char IN[]="2sat.in",OUT[]="2sat.out";

int N,M,L,Con;
int in[LMax],sol[LMax];
bool b[LMax];
vector<int> ad[LMax],s;
vector<vector<int> > C;

void tarjan(int x){

	static int index,idx[LMax],low[LMax];
	static vector<int> vec;
	static stack<int> st;
	static bool b[LMax];

	int i;
	if (idx[x]) return;
	low[x]=idx[x]=++index;
	st.push(x);b[x]=true;

	for (i=0;i<(int)ad[x].size();++i) if (!idx[ad[x][i]]){
		tarjan(ad[x][i]);
		low[x]=min(low[x],low[ad[x][i]]);
	}else if (b[ad[x][i]]){
		low[x]=min(low[x],low[ad[x][i]]);
	}

	if (low[x]==idx[x]){
		vec.clear();++Con;
		for (i=-1;i!=x;){
			i=st.top();st.pop();b[i]=false;
			vec.push_back(i);
			in[i]=Con-1;
		}
		C.push_back(vec);
	}

}

void dfs(int x){

	int i,j;
	if (b[x]) return;
	b[x]=true;
	for (i=0;i<(int)C[x].size();++i) for (j=0;j<(int)ad[C[x][i]].size();++j) if (!b[in[ad[C[x][i]][j]]])
		dfs(in[ad[C[x][i]][j]]);

	s.push_back(x);
}

int n(int x){
	if (x>N) return x-N;
	return x+N;
}

int main()
{
	int i,x,y;
	freopen(IN,"r",stdin);
	scanf("%d%d",&N,&M);L=2*N;
	while (M--){
		scanf("%d%d",&x,&y);
		if (x<0){
			if (y<0){
				ad[-x].push_back(N-y);
				ad[-y].push_back(N-x);
			}else{
				ad[-x].push_back(y);
				ad[N+y].push_back(N-x);
			}
		}
		else{
			if (y<0){
				ad[N+x].push_back(N-y);
				ad[-y].push_back(x);
			}else{
				ad[N+x].push_back(y);
				ad[N+y].push_back(x);
			}
		}
	}
	fclose(stdin);

	for (i=1;i<=L;++i) tarjan(i);

	for (i=1;i<=N;++i) if (in[i]==in[i+N])
	{
		freopen(OUT,"w",stdout);
		printf("-1\n");
		fclose(stdout);
		return 0;
	}

	/*for (i=0;i<(int)C.size();++i,printf("\n"))
		for (int j=0;j<(int)C[i].size();++j)
			printf("%d ",C[i][j]);*/

	for (i=0;i<(int)C.size();++i) dfs(i);
	memset(b,0,sizeof(b));
	for (i=s.size()-1;i>=0;--i) if (!b[s[i]])
		sol[s[i]]=0,sol[in[n(C[s[i]][0])]]=1,
		b[in[n(C[s[i]][0])]]=true;

	freopen(OUT,"w",stdout);
	for (i=1;i<=N;++i) printf("%d ",sol[in[i]]);
	printf("\n");
	fclose(stdout);
	return 0;
}
