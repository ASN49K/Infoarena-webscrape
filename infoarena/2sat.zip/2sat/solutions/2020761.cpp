#include <iostream>
#include <fstream>
#include <stack>
#include <vector>
#include <deque>
#include <ctime>
#include <queue>
#include <cmath>

#define ll long long
#define ull unsigned long long
#define pb push_back
#define mp make_pair
using zint = int;
using namespace std;
const int inf = 3e4 + 5;
const int NMax = 1e5 + 5;
const int MMax = 2e5 + 5;
ifstream in("2sat.in");
ofstream out("2sat.out");

zint N,M,nrComp;
zint compOf[2*NMax],ans[NMax];
bool visStack[2*NMax],inComp[2*NMax];
vector<zint> vEdge[2*NMax],vRev[2*NMax],comp[2*NMax];
stack<zint> st;

void getStack(zint);
void getComp(zint);
void getEdges(zint);
void update(zint,const zint);

#define inv(x) ((x > N) ? x-N : x+N)
int main() {
    in>>N>>M;

    for (int i=1;i <= N;++i) {
        ans[i] = -1;
    }

    for (int i=1;i <= M;++i) {
        zint x,y;
        in>>x>>y;

        x = (x < 0) ? -x + N : x;
        y = (y < 0) ? -y + N : y;

        vEdge[inv(x)].pb(y);
        vRev[y].pb(inv(x));
        vEdge[inv(y)].pb(x);
        vRev[x].pb(inv(y));
    }

    for (zint i = 1;i <= 2*N;++i) {
        if (visStack[i]) {
            continue;
        }

        getStack(i);
    }

    while (st.size()) {
        zint node = st.top(); st.pop();
        if (!inComp[node]) {
            ++nrComp;
            getComp(node);
        }
    }

    bool sol = true;
    for (zint i=1;i <= N;++i) {
        if (compOf[i] == compOf[i+N]) {
            sol = false;
            break;
        }
    }

    if (sol) {
        for (zint c=1;c <= nrComp;++c) {
            update(c,0);
        }

        for (zint i=1;i <= N;++i) {
            out<<ans[i]<<' ';
        }
    }
    else {
        out<<"-1\n";
    }

    in.close();out.close();
    return 0;
}

void getStack(zint node) {
    visStack[node] = true;

    for (zint nxt : vEdge[node]) {
        if (visStack[nxt]) {
            continue;
        }

        getStack(nxt);
    }

    st.push(node);
}

void getComp(zint node) {
    comp[nrComp].pb(node);
    compOf[node] = nrComp;
    inComp[node] = true;

    for (zint nxt : vRev[node]) {
        if (inComp[nxt]) {
            continue;
        }

        getComp(nxt);
    }
}

void update(zint c,const zint val) {
    zint x = comp[c][0];
    x = (x > N) ? x-N : x;
    if (ans[x] != -1) {
        return;
    }

    for (auto node : comp[c]) {
        zint temp = val;
        if (node > N) {
            node -= N;
            temp ^= 1;
        }
        ans[node] = temp;
    }
}
