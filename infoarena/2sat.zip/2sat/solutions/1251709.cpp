#include <fstream>
#include <vector>
#include <cstring>

#define NMAX 400005
using namespace std;

int n;
vector<int> graf[NMAX];
vector<int> graf_inv[NMAX];

#define graf (graf+100000)
#define graf_inv (graf_inv+100000)

//Kosaraju
bool viz[2*NMAX];
int h[NMAX];
int poz;

#define viz (viz+100000)

void dfs_inv(int nod){
    viz[nod]=1;
    for(vector<int>::iterator it=graf_inv[nod].begin();it!=graf_inv[nod].end();it++)
        if(!viz[*it])
            dfs_inv(*it);
    h[++poz]=nod;
}

int comps[NMAX];
int comp;
int opus[NMAX];
int cul[NMAX];

#define comps (comps+100000)

void dfs(int nod){
    viz[nod]=1;
    for(vector<int>::iterator it=graf[nod].begin();it!=graf[nod].end();it++)
        if(!viz[*it])
            dfs(*it);
    comps[nod]=comp;
}

inline void kosaraju(){
    for(int i=-n;i<=n;i++)
        if(i && !viz[i])
            dfs_inv(i);

    for(int i=-n;i<=n;i++)
        viz[i]=0;

    for(int i=2*n;i>=1;i--)
        if(!viz[h[i]]){
            comp++;
            dfs(h[i]);
        }

    for(int i=1;i<=n;i++)
        viz[i]=0;
}

int ans[NMAX];

int main()
{
    ifstream cin("2sat.in");
    ofstream cout("2sat.out");

    int m=0;
    cin>>n>>m;

    int a,b;
    while(m--){
        cin>>a>>b;

        graf[-a].push_back(b);
        graf[-b].push_back(a);

        graf_inv[b].push_back(-a);
        graf_inv[a].push_back(-b);
    }

    kosaraju();

    /*for(int i=1;i<=n;i++)
        if(comps[-i]==comps[i]){
            cout<<"-1\n";

            cin.close();
            cout.close();
            return 0;
        }
        else{
            opus[comps[-i]]=comps[i];
            opus[comps[i]]=comps[-i];
        }

    for(int i=1;i<=comp;i++)
        if(!viz[i]){
            cul[i]=1;
            viz[i]=1;

            cul[opus[i]]=0;
            viz[opus[i]]=1;
        }

    for(int i=-n;i<=n;i++)
        if(i)
            ans[i]=cul[comps[i]];

    cout<<ans[1];
    for(int i=2;i<=n;i++)
        cout<<' '<<ans[i];
    cout<<'\n';*/

    cin.close();
    cout.close();
    return 0;
}
