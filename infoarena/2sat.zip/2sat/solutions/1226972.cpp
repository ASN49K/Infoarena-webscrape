#include <cstdio>
#include <cstring>
#include <vector>

using namespace std;

const int MAX_N = 100005;

vector<int> G[2 * MAX_N], G2[2 * MAX_N];

int n,m,st[2 * MAX_N];
bool viz[2 * MAX_N];
bool value[2 * MAX_N], no_sol;

inline int inv(int val)
{
return val > n ? val - n : val + n;
}

void dfs1(int nod)
{
  viz[nod] = true;
  for (vector<int>::iterator it = G[nod].begin(); it != G[nod].end(); ++it)
    if (!viz[*it]) dfs1(*it);
  st[++st[0]] = nod;
}

void dfs2(int nod) {
  if (value[nod]) no_sol = true;
  viz[nod] = true;
  value[inv(nod)] = true;
  for (vector<int>::iterator it = G2[nod].begin(); it != G2[nod].end(); ++it)
    if (!viz[*it]) dfs2(*it);
}

int main() {
  freopen("2sat.in", "r", stdin);
  freopen("2sat.out", "w", stdout);

  scanf("%d %d", &n, &m);
  for (int i = 0; i < m; ++i) {
    int a, b;
    scanf("%d %d", &a, &b);
    if (a < 0) a = (-a) + n;
    if (b < 0) b = (-b) + n;

    G[inv(a)].push_back(b);
    G[inv(b)].push_back(a);
    G2[b].push_back(inv(a));
    G2[a].push_back(inv(b));
  }

  for (int i = 1; i <= 2*n; ++i)
    if (!viz[i]) dfs1(i);
  memset(viz, false, sizeof(viz));
  for (int i = 2*n; i; --i)
    if (!viz[st[i]] && !viz[inv(st[i])])
      dfs2(st[i]);

  if (no_sol)
    printf("-1\n");
  else
    for (int i = 1; i <= n; ++i)
      printf("%d ", value[i]);
}
