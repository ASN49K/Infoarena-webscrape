#!/usr/bin/env python3

import random, sys
sys.stdout = open('2sat.out', 'w')

with open('2sat.in' ,'r') as f:
    pair = lambda: tuple(map(int, f.readline().split()))

    N, M = pair()
    tt, expr = [False] * (N + 1), [pair() for _ in range(M)]

    def truthy():
        for a, b in expr:
            aa = tt[a] if a > 0 else not tt[-a]
            bb = tt[b] if b > 0 else not tt[-b]
            if not aa and not bb:
                if random.random() >= 0.5:
                    tt[abs(b)] = not tt[abs(b)]
                else:
                    tt[abs(a)] = not tt[abs(a)]
                return False
        return True

    for _ in range(3000):
        if truthy():
            print(' '.join('1' if t else '0' for i, t in enumerate(tt) if i > 0))
            break
        
    if not truthy():
        print(-1)
