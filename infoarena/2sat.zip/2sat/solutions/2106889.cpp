#include<fstream>
#include<vector>
#define DN 200005
#define pb push_back
#define x first
#define y second
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
int n,m,viz[DN],a,b,d,r[DN],st[DN],top;
pair<int,int>z[DN];
vector<int>g[DN];
void dfs(int nod)
{
    viz[nod]=1;
    for(auto i:g[nod])
        if(!viz[i])
            dfs(i);
    top++;
    st[top]=nod-n;
}
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>a>>b;
        z[i].x=a+n;
        z[i].y=b+n;
        d=-a+n;
        g[d].pb(b+n);
        d=-b+n;
        g[d].pb(a+n);
    }
    for(int i=0;i<=2*n;i++)
        if(!viz[i])
            dfs(i);
    for(int i=top;i>=1;i--)
        if(!r[st[i]+n]&&!r[-st[i]+n])
            r[-st[i]+n]=1;
    for(int i=1;i<=m;i++)
        if(!r[z[i].x]&&!r[z[i].y])
        {
            fout<<-1;
            return 0;
        }
    for(int i=1;i<=n;i++)
        fout<<r[i+n]<<' ';
}
