#include <bits/stdc++.h>

constexpr int N = 2e5 + 2;

std::vector<int> g[N], gt[N], ord;
int comp[N];
bool vis[N], sol[N];

std::ifstream in("2sat.in");
std::ofstream out("2sat.out");

inline int neg(int x) {
	return x % 2 ? x - 1 : x + 1;
}

void tsort(int u) {
	vis[u] = true;
	for (auto v : g[u]) {
		if (!vis[v]) {
			tsort(v);
		}
	}
	ord.push_back(u);
}

void dfsc(int u, int c) {
	comp[u] = c;
	for (auto v : gt[u]) {
		if (comp[v] == 0) {
			dfsc(v, c);
		}
	}
}

int main() {
	int n, e;
	in >> n >> e;
	ord.reserve(n);
	for (int i = 0; i < e; ++i) {
		int a, b;
		in >> a >> b;
		a = 2 * std::abs(a) + (a < 0);
		b = 2 * std::abs(b) + (b < 0);
		g[neg(a)].push_back(b);
		gt[neg(b)].push_back(a);
	}
	for (int u = 2; u <= 2 * n; ++u) {
		if (!vis[u]) {
			tsort(u);
		}
	}
	int ci = 0;
	for (auto u : ord) {
		if (comp[u] == 0) {
			dfsc(u, ++ci);
		}
	}
	for (int u = 2; u <= 2 * n; u += 2) {
		if (comp[u] == comp[u + 1]) {
			out << "-1\n";
			return 0;
		}
		sol[u / 2] = comp[u] > comp[u + 1];
	}
	for (int i = 1; i <= n; ++i) {
		out << sol[i] << " ";
	}
	out << "\n";
}
