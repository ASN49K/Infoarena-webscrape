#include <bits/stdc++.h>
#include <cstring>
#pragma GCC optimize ("O3")
#define din cin
#define dout out
#define pi 3.14159265359
#define sw(x,y) x^=y,y^=x,x^=y
#define bmin(a,b)((a<b)?(a):(b))
#define bmax(a,b)((a>b)?(a):(b))
#define bminify(a,b)a=bmin(a,b)
#define bmaxify(a,b)a=bmax(a,b)
#define forq(i,ii,n)for(i=ii;i<n;i++)
#define f first
#define s second
#define mod 1000000297ll
#define nmax 200001
using namespace std;
typedef long long ll;
//ifstream in("fmcm.in");
//ofstream out("fmcm.out");
FILE *fin=fopen("2sat.in","r");
FILE *fout=fopen("2sat.out","w");
int n,m,i,j,k,l,z,c[nmax],r[nmax],s[nmax],y,f[nmax];
bitset<nmax>b,v;vector<int>g[nmax];
void tj(int v)
{
c[l++]=v,b[v]=1,s[v]=r[v]=++z;
for(auto i:g[v])
    if(r[i])
        {if(b[i])bminify(s[v],r[i]);}
        else tj(i),bminify(s[v],s[i]);
if(s[v]==r[v])
{
    y++;
    do b[c[--l]]=0,f[c[l]]=y;while(c[l]!=v);
}
}
int main()
{
fscanf(fin,"%d%d",&n,&m);
for(k=0;k<m;k++)fscanf(fin,"%d%d",&i,&j),g[n-i].emplace_back(n+j),g[n-j].emplace_back(n+i);
for(i=1;i<=2*n;i++)if(s[i]==0)tj(i);
for(i=0;i<n;i++)
    if(f[i]==f[2*n-i]){fprintf(fout,"-1"),exit(0);}
        else v[i]=(f[i]>f[2*n-i]);
for(i=0;i<n;i++)fprintf(fout,"%c ",v[i]?'1':'0');
}
