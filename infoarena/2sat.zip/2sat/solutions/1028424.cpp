#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <stack>

using namespace std;

int n,m;
int visitedNr = 1;

int visitedOrder[200002];

vector<int> adjacencyList[200002];

int inDegree[200002];
int decidedValue[100001];

stack<int> st;

int getVariable(int a){
    return a-n;
}

int transformVariable(int a){
    return a+n;
}

int negateVariable(int a){
    return transformVariable(-getVariable(a));
}

int isNegative(int a){
    if (a<n){
        return 1;
    } else
        return 0;
}

void readData(){
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);

    scanf("%d %d", &n, &m);

    int term1, term2;
    for (int i=0; i<m; i++){
        scanf("%d %d", &term1, &term2);

        term1 = transformVariable(term1);
        term2 = transformVariable(term2);

        inDegree[term2]++;
        inDegree[term1]++;
        adjacencyList[negateVariable(term1)].push_back(term2);
        adjacencyList[negateVariable(term2)].push_back(term1);
    }
}

int tarjan(int currentNode){
    st.push(currentNode);
    visitedOrder[currentNode] = visitedNr;
    visitedNr++;

    int minn = visitedOrder[currentNode];
    int aa;
    for (int i=0; i<adjacencyList[currentNode].size(); i++){
        int nextNode = adjacencyList[currentNode][i];

        if (!visitedOrder[nextNode]){
            aa = tarjan(nextNode);
            if (aa < minn){
                minn = aa;
            }
        } else {
            if (visitedOrder[nextNode] < minn){
                minn = visitedOrder[nextNode];
            }
        }
    }

    if (visitedOrder[currentNode] == minn){
        //it is the root of a strongly connected component

        if (decidedValue[abs(getVariable(st.top()))] == -1){
           do {
                aa = st.top();
                st.pop();

                if (isNegative(aa)){

                    if (decidedValue[-(getVariable(aa))] == 1){
                        printf("-1");
                        exit(0);
                    }

                    decidedValue[-getVariable(aa)] = 0;
                } else {

                    if (decidedValue[getVariable(aa)] == 0){
                        printf("-1");
                        exit(0);
                    }

                    decidedValue[getVariable(aa)] = 1;
                }

            }  while (aa != currentNode);
        }

    }

    return minn;
}

int main()
{
    readData();

    for (int i=1; i<=n; i++){
        decidedValue[i] = -1;
    }

    int ok = 1;

    for (int i=1; i<=n; i++){
        if (decidedValue[i] == -1){
            tarjan(transformVariable(i));
        }
        else if (decidedValue[-i] == -1){
            tarjan(transformVariable(-i));
        }
    }

    for (int i=1; i<=n; i++){
        if (decidedValue[i] == -1){
            ok = 0;
            break;
        }
    }

    if (ok){
        for (int i=1; i<=n; i++){
            printf("%d ", decidedValue[i]);
        }
    } else {
        printf("-1");
    }

    return 0;
}
