#include<stdio.h>
#include<stdlib.h>
#include<time.h>
using namespace std;

typedef struct xy
{
    int x,y;
} ;

FILE *f = fopen("2sat.in","r");
FILE *g = fopen("2sat.out","w");

#define MaxN 1000100
#define MaxM 1000100

int N,M,Sol = 0;

int A[MaxN];
xy B[MaxM];

void citire(void)
{
    fscanf(f,"%d %d",&N,&M);
    for(int i=1;i<=M;i++)
        fscanf(f,"%d %d",&B[i].x,&B[i].y);
}

inline void Randomizare(void)
{
    for(int i=1;i<=N;i++)
        A[i] = rand()%2;
}

inline int abs(int i)
{
    return i < 0 ? -i : i;
}

inline int satisf(int i)
{
    int a = A[abs(B[i].x)], b = A[abs(B[i].y)];

    if(B[i].x < 0)
        a = 1-a;
    if(B[i].y < 0)
        b = 1-b;

    return a | b;
}

inline int sePoate(void)
{
    bool gata = false;

    for(int i=1;i<=2*N*N;i++)
    {
        gata = true;

        for(int j=1;j<=M;j++)
            if(!satisf(j))
            {
                int k = rand()%2;
                k ? A[abs(B[j].x)] = 1-A[abs(B[j].x)] : A[abs(B[j].y)] = 1-A[abs(B[j].y)];
                gata = false;
                break;
            }

        if(gata)
            return 1;
    }

    return 0;
}

void Rezolvare(void)
{
    srand(time(NULL));

    for(int i=1;i<=N;i<<=1)
    {
        Randomizare();
        Sol = sePoate();
        if(Sol)
            return;
    }
}

int main()
{
    citire();
    Rezolvare();

    if(Sol)
        for(int i=1;i<=N;i++)
            fprintf(g,"%d ",A[i]);
    else
        fprintf(g,"-1");
}
