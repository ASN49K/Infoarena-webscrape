#include <stdio.h>
#include <vector>

#define magic_sauce inline __attribute__((always_inline))

magic_sauce int min( int a, int b ){ return a < b ? a : b; }

const int MAXN = 1e5;
const int MAX_NODE = 2 * MAXN;
const int NIL = -1;

std::vector<int> fwd[MAX_NODE];
std::vector<int> back[MAX_NODE];

char viz[MAX_NODE];

int ord[MAX_NODE];
int nord;

int ctc[MAX_NODE];

void kinda_topo( int u ){
  viz[u] = true;

  for( int v : fwd[u] )
    if( !viz[v] )
      kinda_topo( v );

  ord[nord++] = u;
}

void assign( int u, int comp ){
  ctc[u] = comp;

  for( int v : back[u] )
    if( ctc[v] == NIL )
      assign( v, comp );
}

int main(){
  FILE *fin  = fopen( "2sat.in", "r" );
  FILE *fout = fopen( "2sat.out", "w" );

  int n, m, i, a, b, nctc;

  fscanf( fin, "%d %d", &n, &m );

  for( i = 0 ; i < m ; i++ ){
    fscanf( fin, "%d%d", &a, &b );

    if( a > 0 )
      a = (a << 1);
    else
      a = ((-a) << 1) | 1;

    if( b > 0 )
      b = (b << 1);
    else
      b = ((-b) << 1) | 1;

    a -= 2;
    b -= 2;

    fwd[a].push_back( b ^ 1 );
    fwd[b].push_back( a ^ 1 );
    back[a ^ 1].push_back( b );
    back[b ^ 1].push_back( a );
  }

  for( i = 0 ; i < 2 * n ; i++ ){
    viz[i] = false;
    ctc[i] = NIL;
  }

  nord = 0;
  for( i = 0 ; i < 2 * n ; i++ )
    if( !viz[i] )
      kinda_topo( i );

  nctc = 0;
  for( i = 2 * n ; i-- ; )
    if( ctc[ord[i]] == NIL )
      assign( ord[i], nctc++ );

  for( i = 0 ; i < n ; i++ )
    if( ctc[i * 2] == ctc[i * 2 + 1] ){
      fputs( "-1\n", fout );
      fclose( fin );
      fclose( fout );
      return 0;
    }

  for( i = 0 ; i < n ; i++ ){
    fputc( '0' + (ctc[i * 2] < ctc[i * 2 + 1]), fout );
    fputc( ' ', fout );
  }

  fputc( '\n', fout );

  fclose( fin );
  fclose( fout );
  return 0;
}
