#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
const int nmax=200005;
vector<int> v[nmax],vt[nmax];
int ans[nmax],viz[nmax],r[nmax];
int n,m,i,j,nr,x,y;
inline int no(int x)
{
    if(x>n) return x-n;
    return x+n;
}
void add(int A,int B)
{
    v[A].push_back(B);
    vt[B].push_back(A);
}
void dfs1(int x)
{
    viz[x]=1;
    for(int i=0;i<v[x].size();i++)
      if(!viz[v[x][i]])
        dfs1(v[x][i]);
    r[++nr]=x;
}
void dfs2(int x)
{
    viz[x]=0;ans[x]=0;ans[no(x)]=1;
    for(int i=0;i<vt[x].size();i++)
        if(viz[vt[x][i]])
           dfs2(vt[x][i]);
}
int main()
{
    ifstream f("2sat.in");
    ofstream g("2sat.out");
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y;
        if(x<0) x=n-x;
        if(y<0) y=n-y;
        add(no(x),y);
        add(no(y),x);
    }
    for(i=1;i<=2*n;i++)
       if(!viz[i])
         dfs1(i);
    for(i=2*n;i>=1;i--)
        if(viz[r[i]]&&(!ans[r[i]]))
          dfs2(r[i]);
    for(i=1;i<=n;i++)
        g<<ans[i]<<' ';
    return 0;
}
