#include <fstream>
#include <bitset>
#include <vector>

using namespace std;

ifstream cin("2sat.in");
ofstream cout("2sat.out");

const int NMAX = int(1e5) + 2;
int N, M;
vector<int> G[NMAX<<1], GT[NMAX<<1], s;
bitset< NMAX<<1 > visited, truthValue;
bool solution = true;
inline int non(const int &v) { return v > N ? v - N : v + N;}

void readData(){ 
	cin>>N>>M;
	int a, b;
	for(int i = 0;i < M;i++) {
		cin>>a>>b;
		if(a < 0) a = -a + N;
		if(b < 0) b = -b + N;
		G[non(a)].push_back(b);
		G[non(b)].push_back(a);
		GT[a].push_back(non(b));
		GT[b].push_back(non(a));
	}
}

void df(const int &v) {
	visited[v] = true;
	for(vector<int>::const_iterator w = G[v].begin();w != G[v].end();w++) {
		if(visited[*w] == false) {
			df(*w);
		}
	}
	s.push_back(v);
}

void df1(const int &v) {
	if(truthValue[v]) {
		solution = false;
	}
	truthValue[non(v)] = true;
	visited[v] = true;
	for(vector<int>::const_iterator w = GT[v].begin();w != GT[v].end();w++) {
		if(visited[*w] == false) {
			df1(*w);
		}
	}
}

void solve() {
	for(int i = 1;i <= (N<<1);i++){ 
		if(!visited[i]) {
			df(i);
		}
	}
	visited.reset();
	for(vector<int>::const_reverse_iterator it = s.rbegin();it != s.rend();it++) {
		if(!visited[*it] && !visited[non(*it)]) {
			df1(*it);
		}
	}
	if(solution) {
		for(int i = 1;i <= N;i++) {
			cout<<truthValue[i]<<" ";
		}
	} else {
		cout<<"-1\n";
	}
}

int main() 
{
	readData();
	solve();
	return 0;
}
