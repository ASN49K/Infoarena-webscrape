#include <fstream>
#include <vector>
#define NMAX 100000
using namespace std;

ifstream in("2sat.in");
ofstream o("2sat.out");
vector <int>G[NMAX];
vector <int>GT[NMAX];
int L[NMAX];
int use[NMAX];
int C[NMAX];
int sol[NMAX];
int n,m,p;

void dfs(int x)
{
    int i,lg;
    lg=G[x].size();
    for(i=0;i<lg;i++)
    {
        if(!use[G[x][i]])
        {
            use[G[x][i]]=1;
            dfs(G[x][i]);
        }
    }
    L[p]=x;
    p--;
}
void dfs2(int x, int t)
{
    int i,lg;
    lg=GT[x].size();
    for(i=0;i<lg;i++)
    {
        if(!C[GT[x][i]]){
            C[GT[x][i]]=t;
            dfs2(GT[x][i],t);
        }
    }
}
int main()
{
    int i,x,y,a,t,y1,n2,j;
    in>>n>>m;;
    for(i=1;i<=m;i++)
    {
        in>>x>>y;
        y1=y;
        a=-x;
        if(a>0)a--;
        if(y>0)y--;
        G[a+n].push_back(y+n);
        GT[y+n].push_back(a+n);
        y=y1;
        a=-y;
        if(a>0)a--;
        if(x>0)x--;
        G[a+n].push_back(x+n);
        GT[x+n].push_back(a+n);
    }
    n=n<<1;
    p=n-1;
    for(i=0;i<n;i++)
    {
        if(!use[i])
        {
            use[i]=1;
            dfs(i);
        }
    }
    /*for(i=0;i<n;i++)
        o<<L[i]<<' ';
    o<<endl;*/
    t=1;
    for(i=0;i<n;i++)
    {
        if(!C[L[i]])
        {
            C[L[i]]=t;
            dfs2(L[i],t);
            t++;
        }
    }
    n2=n>>1;
    for(i=0;i<n2;i++)
    {
        if(C[i]==C[n-1-i])
        {
            o<<-1<<'\n';
            return 0;
        }
    }
    for(i=0;i<n;i++)
    {
        if(C[i]>(t-1)/2)
            sol[i]=1;

    }
    for(i=n2;i<n;i++)o<<sol[i]<<' ';
    o<<'\n';
    return 0;
}
