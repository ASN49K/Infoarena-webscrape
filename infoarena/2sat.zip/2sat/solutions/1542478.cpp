#include<fstream>
using namespace std;

#define UI unsigned int
struct nod{int val; nod* next;};
typedef nod* lista;
lista g[200002], gn[200002];

bool sat[100000];
bool v[200000];
UI n, m;
void dfs1(int i)
{
    v[i]=1;
//    for(int j=1; j<k[i]; ++i)
}

UI negat(int x)
{
return 2*n-x;
}
int main()
{

ifstream in;
in.open("2sat.in");

in>>n>>m;
int a,b;
for(UI i=1;i<=m;++i)
    {
        in>>a>>b;
        a+=n; b+=n;
        lista x;
        a=negat(a);
        x=new nod; x->val=b; x->next=g[a]; g[a]=x;
        x=new nod; x->val=a; x->next=gn[b]; gn[b]=x;
        x=new nod; x->val=negat(a); x->next=g[negat(b)]; g[negat(b)]=x;
        x=new nod; x->val=negat(b); x->next=gn[negat(a)]; gn[negat(a)]=x;
    }

//for(UI i=0; i<2*n+1; ++i)

ofstream out;
out.open("2sat.out");
out<<-1;
/*
for(int i=0;i<=2*n;++i)
    {out<<i<<" -> ";
        for(lista p=g[i]; p; p=p->next)
            out<<p->val<<' ';
        out<<'\n';

    }
out<<'\n';
for(int i=0;i<=2*n;++i)
    {out<<i<<" -> ";
        for(lista p=gn[i]; p; p=p->next)
            out<<p->val<<' ';
        out<<'\n';

    }

*/
return 0;
}
