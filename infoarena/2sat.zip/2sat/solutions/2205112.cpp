#include <fstream>
#include <vector>
#include <stack>
#include <deque>
std::ifstream in("2sat.in");
std::ofstream out("2sat.out");
#define MAX_N 200003
#define OFFSET 100000
long n, m, x, y;
std::vector<long> adjList[MAX_N];
std::vector<long> adjListT[MAX_N];
std::vector<long> component(MAX_N);
std::vector<bool> visited(MAX_N);
std::vector<int> degree(MAX_N);
std::vector<int> results(MAX_N);
std::stack<long> vertices;
std::deque<long> sortedVertices;
std::deque<long> zeroDegreeComponents;
bool satisfiable = true;
long nrComponents;
void topological(long start) {
  vertices.push(start);
  bool isVisited;

  while(!vertices.empty()) {
    long topOfStack = vertices.top();
    isVisited = true;
    visited[topOfStack] = true;
    auto itr = adjList[topOfStack].begin();
    while (itr != adjList[topOfStack].end()) {
      if(!visited[*itr]) {
        vertices.push(*itr);
        isVisited = false;
      }
      ++itr;
    }
    if (isVisited) {
      vertices.pop();
      sortedVertices.push_front(topOfStack);
    }
  }

}
void dfsT(long start) {
  vertices.push(start);
  while(!vertices.empty()) {
    long topOfStack = vertices.top();
    vertices.pop();
    if (!visited[topOfStack]) {
      visited[topOfStack] = true;
    }
    component[topOfStack] = nrComponents;
    auto itr = adjListT[topOfStack].begin();
    while (itr != adjListT[topOfStack].end()) {
      if(!visited[*itr]) {
        vertices.push(*itr);
      }
      ++itr;
    }
  }
}
long index(long indexIn) {
  return (indexIn>0) ? indexIn-1 : (-indexIn - 1 + OFFSET);
}
void handleInput() {
  in >> n >> m;
  for (int i = 0; i < m; i++) {
    in >> x >> y;
    adjList[index(-x)].push_back(index(y));
    adjList[index(-y)].push_back(index(x));
    adjListT[index(y)].push_back(index(-x));
    adjListT[index(x)].push_back(index(-y));
  }
}
void topologicalSort() {
  for (int i = 0; i < n; i++) {
    visited[i] = false;
    visited[i + OFFSET] = false;
  }
  while (sortedVertices.size() < n * 2) {
      for (int i = 0; i < n; i++) {
        if (!visited[i]) {
          topological(i);
        }
        else if(!visited[i + OFFSET]) {
          topological(i + OFFSET);
        }
      }
  }
}
void findStronglyConnectedComponents() {
  for (int i = 0; i < n; i++) {
    visited[i] = false;
    visited[i + OFFSET] = false;
  }
  while (!sortedVertices.empty()) {
    if (!visited[*sortedVertices.begin()]) {
      dfsT(*sortedVertices.begin());
      nrComponents++;
    }
    sortedVertices.pop_front();
  }
}
void showSolutions() {
  for (int i = 0; i < n; i++) {
    if (component[i] == component[i + OFFSET]) {
      satisfiable = false;
    }
  }
  if (satisfiable) {
    for (int i = 0; i < n; i++) {
      out << (component[i] > component[i + OFFSET]) << " ";
    }
  }
  else {
    out << "-1";
  }
}

int main() {
  handleInput();
  topologicalSort();
  findStronglyConnectedComponents();
  showSolutions();
}
