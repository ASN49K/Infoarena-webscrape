#include <fstream>
#include <vector>
#include <bitset>
#include <queue>
#include <algorithm>
#include <utility>
#include <cstring>
#include <string>
#include <stack>
#include <deque>
#include <iomanip>
#include <set>
#include <map>
#include <cassert>
#include <ctime>
#include <list>
#include <iomanip>

using namespace std;

ifstream cin("2sat.in");
ofstream cout("2sat.out");

const int MAXN = 100005;
const int oo = (1<<31)-1;

typedef vector<int> Graph[MAXN<<1];
typedef vector<int> :: iterator It;

const inline int min(const int &a, const int &b) { if( a > b ) return b;   return a; }
const inline int max(const int &a, const int &b) { if( a < b ) return b;   return a; }
const inline void Get_min(int &a, const int b)    { if( a > b ) a = b; }
const inline void Get_max(int &a, const int b)    { if( a < b ) a = b; }

struct ClassComp {
    inline bool operator () (const int &a, const int &b) const {
        return a > b;
    }
};

Graph G;
int N, M, Idx[MAXN<<1], LowLink[MAXN<<1], Deep, Where[MAXN<<1], Ans[MAXN<<1];
vector< set<int> > SCC;
stack<int> Stack;
bitset<MAXN<<1> inStack;

inline int Non(int x) {
    return x <= N ? x + N : x - N;
}

inline int Val(int x) {
    return x < 0 ? -x + N : x;
}

void Tarjan(int Node) {
    Idx[Node] = LowLink[Node] = ++ Deep;
    Stack.push(Node);
    inStack[Node] = true;
    for(It it = G[Node].begin(), fin = G[Node].end(); it != fin ; ++ it)
        if(!Idx[*it]) {
            Tarjan(*it);
            Get_min(LowLink[Node], LowLink[*it]);
        }
        else if(inStack[*it])
            Get_min(LowLink[Node], LowLink[*it]);
    if(LowLink[Node] == Idx[Node]){
        int actNode, actSCC = SCC.size() + 1;
        set<int> Scc;
        do {
            inStack[actNode = Stack.top()] = false;
            Scc.insert(actNode);
            /// TODO
            /// Check here for (Node, Node + N) pair in the same Strongly Connected Component
            /// giving up on the for and the where vector
            //int pairNode = actNode <= N ? actNode + N : actNode - N;
            //if(Scc.find(pairNode))
            Where[actNode] = actSCC;
            Stack.pop();
        }while(actNode != Node);
        SCC.push_back(Scc);
    }
}

int main() {
    cin >> N >> M;
    for(int i = 1 ; i <= M ; ++ i) {
        int x, y;
        cin >> x >> y;
        G[Non(Val(x))].push_back(Val(y));
        G[Non(Val(y))].push_back(Val(x));
    }
    cin.close();
    for(int i = 1 ; i <= 2 * N ; ++ i)
        if(!Idx[i])
            Tarjan(i);
    for(int i = 1 ; i <= N ; ++ i) {
        if(Where[i] == Where[i+N]){
            cout << "-1\n";
            cout.close();
            return 0;
        }
    }
    for(vector<set<int> > :: reverse_iterator it = SCC.rbegin(), fin = SCC.rend() ; it != fin ; ++ it )
        for(set<int> :: iterator i = it->begin(), fi = it->end(); i != fi ; ++ i) {
            int act = *i > N ? *i - N : *i;
            if(!Ans[act])
                Ans[act] = *i > N ? 2 : 1;
            else break;
        }
    for(int i = 1 ; i <= N ; ++ i)
        cout << -- Ans[i] << ' ';
    cout.close();
    return 0;
}
