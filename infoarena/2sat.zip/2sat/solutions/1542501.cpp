#include <iostream>
#include<fstream>
using namespace std;

ifstream f("2sat.in");
ofstream g("2sat.out");
int L[200005],viz[200005],k=0,c[200005],sol[200005];
struct lista
{
    int inf;
    lista *succ;
}*v[200005],*w[200005];

void adaugare(int x,int y, lista *vector[200005])
{
    lista *p;
    p=new lista;
    p->inf=y;
    p->succ=NULL;
    if(vector[x]==NULL)vector[x]=p;
    else {p->succ=vector[x];
          vector[x]=p;}

}

void dfs(int x)
{
    int i;
    lista *p;
    viz[x]=1;
    p=v[x];
    while(p)
      {
          if(viz[p->inf]==0)dfs(p->inf);
          p=p->succ;
      }
    L[k++]=x;
}

void dfs2(int x, int t)
{
    int i; lista *p;
    c[x]=t;
    p=w[x];
    while(p)
      {
          if(c[p->inf]==0)dfs2(p->inf,t);
          p=p->succ;
      }
}

int main()
{
    int n,m,i,x,y,j,t=1,ok,val;
    lista *p,*q;
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y;
        if(x<0)x=-x+n;
        if(y<0)y=-y+n;
        if(x>n){adaugare(x-n,y,v);adaugare(y,x-n,w);}

        else {adaugare(x+n,y,v);adaugare(y,x+n,w);}

        if(y>n){adaugare(y-n,x,v);adaugare(x,y-n,w);}

        else {adaugare(y+n,x,v);adaugare(x,y+n,w);}
    }

    for(i=1;i<=2*n;i++)
       if(viz[i]==0)
           dfs(i);
    for(i=k-1;i>0;i--)
       if(c[L[i]]==0)
         {
             dfs2(L[i],t);
             t++;
         }
    //for(i=1;i<=2*n;i++)cout<<c[i]<<" ";
    ok=1;
    for(i=1;i<=n&&ok;i++)
       if(c[i]==c[i+n])ok=0;
    if(ok==0)g<<-1;
    else
       {
           t--;
           for(i=1;i<=t;i++)
              {
              ok=0;
              for(j=1;j<=2*n;j++)
                   if(sol[j]==2&&c[j]==i)ok=1;
              if(ok==0)
                 {
                     for(j=1;j<=2*n;j++)
                         if(c[j]==i){sol[j]=1;if(j>n)sol[j-n]=2;
                                              else sol[j+n]=2;
                                    }
                 }
                else
                   {
                       for(j=1;j<=2*n;j++)
                          if(c[j]==i)
                              {
                                  sol[j]=2;
                                  if(j>n)sol[j-n]=1;
                                  else sol[j+n]=1;
                              }
                   }
              }

       }
       for(i=1;i<=n;i++)g<<sol[i]-1<<" ";
    /*for(i=1;i<=2*n;i++)
    {
        p=w[i];
        while(p)
        {
            cout<<p->inf;
            p=p->succ;
        }
        cout<<"\n";
    }*/
    return 0;
}
