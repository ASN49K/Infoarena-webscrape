#include<cstdio>
#include<vector>
#include<queue>
#include<algorithm>
using namespace std;
const int M=200001,P=20000000;
int v,e,x,y,i,c,j,o,z=-1,p;
vector<int> a[M],b[M],w(M),u(M,-1),d(M,0);
vector<int>::iterator t,k,l;
vector<vector<int> > s;
queue<int> q;
char r[P];
inline int Q()
{
  	int s=0,b=1;
  	++z;
  	if(r[z]==45)
        b=-1,++z;
  	for(;r[z]>47;++z)
  		s=s*10+r[z]-48;
  	return s*b;
}
inline int A(int x)
{
    return x<0?-x:x;
}
inline int I(int x)
{
    return x<0?A(x)+v:x;
}
inline int N(int x)
{
    return x>v?x-v:x+v;
}
inline void D(int n,vector<int>& u,vector<int>& d)
{
    u[n]=1;
    for(vector<int>::iterator i=a[n].begin();i!=a[n].end();++i)
        if(!u[*i])
            D(*i,u,d);
    d.push_back(n);
}
inline void E(int n,vector<int>& u,vector<int>& s)
{
    u[n]=1,s.push_back(n);
    for(vector<int>::iterator i=b[n].begin();i!=b[n].end();++i)
        if(!u[*i])
            E(*i,u,s);
}
inline void C()
{
    vector<int> u(M),d,r;
    int i;
    u.assign(u.size(),0);
    for(i=1;i<=v*2;++i)
        if(!u[i])
            D(i,u,d);
    u.assign(u.size(),0);
    for(vector<int>::reverse_iterator t=d.rbegin();t!=d.rend();++t)
        if(!u[*t]) {
            r.clear(),E(*t,u,r);
            for(vector<int>::iterator j=r.begin();j!=r.end();++j)
                w[*j]=s.size();
            s.push_back(r);
        }
}
int main()
{
    freopen("2sat.in","r",stdin),freopen("2sat.out","w",stdout),fread(r,1,P,stdin),v=Q(),e=Q();
    for(i=0;i<e;++i)
        x=Q(),y=Q(),a[N(I(x))].push_back(I(y)),b[I(y)].push_back(N(I(x))),a[N(I(y))].push_back(I(x)),b[I(x)].push_back(N(I(y)));
    for(C(),c=0,x=1;x<=v;++x)
        if(w[x]==w[x+v])
            c=1;
    if(!c) {
        for(x=1;x<=v*2;++x)
            for(t=a[x].begin();t!=a[x].end();++t)
                if(w[x]!=w[*t])
                    ++d[w[*t]];
        for(o=(int)s.size(),j=0;j<o;++j)
            if(!d[j])
                q.push(j);
        while(!q.empty()) {
            j=q.front(),q.pop();
            for(t=s[j].begin();t!=s[j].end();++t) {
                x=(*t>v)?*t-v:*t;
                if(u[x]==-1)
                    u[x]=(*t<=v)?0:1;
            }
            for(k=s[j].begin();k!=s[j].end();++k)
                for(l=a[*k].begin();l!=a[*k].end();++l)
                    if(w[*k]!=w[*l])
                        if((--d[w[*l]])==0)
                            q.push(w[*l]);
        }
        for(i=1;i<=v;++i)
            r[p++]=u[i]+48,r[p++]=32;
    } else
        r[p++]='-',r[p++]=49;
    fwrite(r,1,p,stdout);
    return 0;
}
