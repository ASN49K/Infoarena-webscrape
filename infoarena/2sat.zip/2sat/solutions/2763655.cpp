#include <fstream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;

ifstream cin("2sat.in");
ofstream cout("2sat.out");

int n, m, x, y;
vector<int> g[200001];
vector<int> gt[200001];
int use[200001], k = 2;
vector<int> p;
int tout[200001], t;
void dfs(int nod)
{
    use[nod] = 1;
    for (auto i : g[nod])
    {
        if (!use[i])
            dfs(i);
    }
    p.push_back(nod);
    tout[nod] = ++t;
}
void dfs2(int nod)
{
    use[nod] = k;
    for (auto i : gt[nod])
    {
        if (use[i] == 1)
            dfs2(i);
    }
}
int main()
{
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        cin >> x >> y;
        int idx = abs(x), idy = abs(y);
        int idnx = abs(x) + n, idny = abs(y) + n;

        if (x < 0)
            swap(idx, idnx);
        if (y < 0)
            swap(idy, idny);

        g[idnx].push_back(idy);
        g[idny].push_back(idx);
    }
    for (int i = 1; i <= 2 * n; i++)
    {
        for (auto j : g[i])
            gt[j].push_back(i);
    }
    for (int i = 1; i <= 2 * n; i++)
    {
        if (!use[i])
        {
            dfs(i);
        }
    }
    for (int i = p.size() - 1; i >= 0; i--)
    {
        if (use[p[i]] == 1)
        {
            dfs2(p[i]);
            k++;
        }
    }
    for (int i = 1; i <= n; i++)
    {
        if (use[i] == use[i + n])
        {
            cout << "-1\n";
            return 0;
        }
    }
    for (int i = 1; i <= n; i++)
    {
        if (tout[i] > tout[i + n])
            cout << "0 ";
        else cout << "1 ";
    }
    return 0;
}

//#include <fstream>
//#include <vector>
//using namespace std;
//
//const int NMAX = 1e5;
//int N, M, seen[2 * NMAX + 2], kComp, comp[2 * NMAX + 2];
//vector<int> graph[2 * NMAX + 2], rev[2 * NMAX + 2], stk;
//
//int Norm(int x) {
//    if (x > 0) { return x; }
//    return -x + N;
//}
//int Not(int x) {
//    if (x > 0) { return x + N; }
//    return -x;
//}
//void dfs1(int node) {
//    seen[node] = 1;
//    for (int son : graph[node]) {
//        if (!seen[son]) {
//            dfs1(son);
//        }
//    }
//    stk.push_back(node);
//}
//void dfs2(int node) {
//    seen[node] = 0, comp[node] = kComp;
//    for (int son : rev[node]) {
//        if (seen[son]) {
//            dfs2(son);
//        }
//    }
//}
//void AddEdge(int x, int y) {
//    graph[Not(x)].push_back(Norm(y));
//    rev[Norm(y)].push_back(Not(x));
//}
//void stronglyConnectedComponents() {
//    for (int i = 1; i <= 2 * N; i++) {
//        if (!seen[i]) {
//            dfs1(i);
//        }
//    }
//    while (!stk.empty()) {
//        int node = stk.back(); stk.pop_back();
//        if (seen[node] == true) {
//            ++kComp; dfs2(node);
//        }
//    }
//}
//
//int main() {
//    ifstream f("2sat.in"); ofstream g("2sat.out");
//    f >> N >> M;
//    for (int i = 1; i <= M; i++) {
//        int x, y; f >> x >> y;
//        AddEdge(x, y); AddEdge(y, x);
//    }
//    stronglyConnectedComponents();
//    for (int i = 1; i <= N; i++) {
//        if (comp[i] == comp[i + N]) { //No solution
//            g << -1 << '\n';
//            return 0;
//        }
//    }
//    for (int i = 1; i <= N; i++) {
//        if (comp[i] < comp[i + N]) { //ith variable is false
//            g << 0 << ' ';
//        }
//        else {                    //ith variable is true
//            g << 1 << ' ';
//        }
//    }
//    return 0;
//}