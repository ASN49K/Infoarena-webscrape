#include <iostream>
#include <fstream>
#include <vector>
#include <string.h>

using namespace std;

class vector_2sat {
public:
	vector<int> *v;
	int n, size;

	vector_2sat() {
		v = NULL;
		size = n = 0;
	}

	void set(int n) {
		if (v != NULL)
			delete[] v;
		v = new vector<int>[2 * n + 1];
		size = 2 * n;
		this->n = n;
	}

	vector_2sat(int n) {
		set(n);
	}

	vector<int>& operator[](int pos) {
		return v[pos + n];
	}

};

#define NMax 100002

vector_2sat g, gt;
int n, m;
int value[2 * NMax + 2];
bool viz[2 * NMax + 2], solution[NMax];
vector<int> l;

void visit(int k) {
	if (viz[k+n])
		return;
	
	viz[k+n] = true;
	for (int i = 0; i < g[k].size (); i++)
		visit(g[k][i]);
	l.push_back(k);
}

void addToComponent(int k, vector<int> *c) {
	if (!viz[k+n])
		return;
	viz[k+n] = 0;

	c->push_back(k);
	for (int i = 0; i < gt[k].size (); i++)
		addToComponent(gt[k][i], c);
}

vector<vector<int> > componentVector;

bool sat2() {
	vector<int> *component;
	while (!l.empty()) {
		int k = l.back();
		l.pop_back();
		if (!viz[k+n])
			continue;
		
		componentVector.push_back(*new vector<int>());
		addToComponent(k, &componentVector.back ());
		
		component = &componentVector.back();

		for (int i = 0; i < component->size(); i++) {
			value[component->at(i) + n] = componentVector.size();
			if (value[-component->at(i) + n] == value[component->at(i) + n])
				return false;
		}
	}

	short *componentValue = new short[componentVector.size()+1];
	memset(componentValue, 0, componentVector.size () * 2 + 2);
	for (int i = componentVector.size() - 1; i >= 0; i--)
		if (componentValue[i+1] == 0) {
			componentValue[i+1] = 2;
			componentValue[value[-componentVector[i][0] + n]] = 1;
		}

	for (int i = componentVector.size() - 1; i >= 0; i--)
		for (int j = 0; j < componentVector[i].size(); j++)
			if (componentVector[i][j] > 0)
				solution[componentVector[i][j]] = componentValue[i+1] == 2 ? true : false;

	return true;
}

int main() {
	ifstream fin("2sat.in");
	ofstream fout("2sat.out");

	int x1, x2;
	fin >> n >> m;
	g.set(n);
	gt.set(n);
	for (int i = 0; i < m; i++) {
		fin >> x1 >> x2;
		g[-x1].push_back(x2);
		g[-x2].push_back(x1);
		gt[x2].push_back(-x1);
		gt[x1].push_back(-x2);
	}

	for (int i = 1; i <= n; i++)
		visit(i),
		visit(-i);

	if (sat2())
		for (int i = 1; i <= n; i++)
			fout << solution[i] << ' ';
	else
		fout << -1 << '\n';

	return 0;
}