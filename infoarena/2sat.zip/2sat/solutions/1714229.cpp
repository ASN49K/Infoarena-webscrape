#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <bitset>
using namespace std;
ifstream si("2sat.in");
ofstream so("2sat.out");
vector<int> g[200005];
vector<int> gt[200005];
bitset<200005> v;
bitset<200005> sol;
stack<int> dr;
int n;
int neg(int x)
{
    if(x<=n) return x+n;
    else return x-n;
}
void add(int x,int y)
{
    g[x].push_back(y);
    gt[y].push_back(x);
}
bool ok=true;
void dfs2(int x)
{
    if(sol[x])
    {
        ok=false;
        return;
    }
    v[x]=sol[x]=0;
    sol[neg(x)]=1;
    int i,l=gt[x].size();
    for(i=0;i<l;++i)
    {
        if(v[gt[x][i]])
            dfs2(gt[x][i]);
    }
}
void dfs1(int x)
{
    v[x]=1;
    int i,l=g[x].size();
    for(i=0;i<l;++i)
    {
        if(!v[g[x][i]])dfs1(g[x][i]);
    }
    dr.push(x);
}
int main()
{
    int m;
    si>>n>>m;
    int i;
    int a,b;
    for(i=0;i<m;++i)
    {
        si>>a>>b;
        if(a<0)
            a=n-a;
        if(b<0)
            b=n-b;
        add(neg(a),b);
        add(neg(b),a);
    }
    for(i=1;i<=n+n;++i)
    {
        if(!v[i])
            dfs1(i);
    }
    for(i=n+n;i&&ok;--i)
    {
        a=dr.top();
        if(v[a]&&v[neg(a)])
            dfs2(a);
        dr.pop();
    }
    if(!ok)
        so<<"-1\n";
    else
    {
        for(i=1;i<=n;++i)
        {
            so<<sol[i]<<' ';
        }
    }
    return 0;
}
