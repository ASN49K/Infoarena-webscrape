#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
#include <queue>
#include <stack>

using namespace std;

const int N=2e5+5;
vector<int> g[N],gt[N],tg[N];
int n,m,v[N],nr;
vector<int> sol;
bitset<N> viz;
stack<int> q;
bool realizabil=1;
vector<int> comp[N];
int gext[N];
queue<int> s;

void dfs(int nod)
{
    viz[nod]=1;
    for(auto el:g[nod])
        if(!viz[el])dfs(el);
    q.push(nod);
}

void dfs_gt(int nod)
{
    //cout<<nod<<' '<<nr<<'\n';
    viz[nod]=1;
    v[nod]=nr;//componenta de care apartine nod este nr!
    comp[nr].push_back(nod);
    for(auto el:gt[nod])
        if(!viz[el])dfs_gt(el);
}

int main()
{
    ifstream fin("2sat.in");
    fin>>n>>m;
    // a[i] => non a[i+n];
    int i,j,x,y,nonx,nony;
    bool nx,ny;
    for(i=0; i<m; i++)
    {
        fin>>x>>y;
        nx=ny=0;
        if(x<0)
        {
            x=-x+n;
            nonx=x-n;
            nx=1;
        }
        else nonx=x+n;
        if(y<0)
        {
            y=-y+n;
            nony=y-n;
            ny=1;
        }
        else nony=y+n;

        g[nonx].push_back(y);
        g[nony].push_back(x);

        gt[y].push_back(nonx);
        gt[x].push_back(nony);
    }


    for(i=1; i<=2*n; i++)
        if(!viz[i])
            dfs(i);

    viz.reset();

    while(!q.empty())
    {
        x=q.top();
        q.pop();
        if(viz[x])
            continue;
        nr++;
        dfs_gt(x);
    }
    sol=vector<int>(2*n+1,-1);
    for(i=1; i<=n; i++)
    {
        if(v[i]==v[i+n])
        {
            realizabil=0;
            goto AFIS;
        }
    }

    //tg = graful tare-conex
    // tg are nr noduri
    //gexe[i] = gradul ext al comp. 'i'
    for(i=1; i<=2*n; i++)
    {
        for(auto el:g[i])
            if(v[i]!=v[el])
            {
                tg[v[i]].push_back(v[el]);
                gext[v[el]]++;
            }
    }

    while(!q.empty())
        q.pop();

    for(i=1; i<=nr; i++)
        if(!gext[i])
            s.push(i);

    while(!s.empty())
    {
        x=s.front();
        s.pop();
        if(sol[comp[x][0]]==-1)
        for(auto el:comp[x])
        {
            sol[el]=0;
        }
        y=comp[x][0];
        if(y<=n)y+=n;
        else y-=n;
        if(sol[comp[v[y]][0]]==-1)
        for(auto el:comp[v[y]])
        {
            sol[el]=1;
        }

        for(auto el:tg[x])
        {
            gext[el]--;
            if(!gext[el])
                s.push(el);
        }

    }

//    for(i=1;i<=n;i++)
//        sol[i]=(v[i]>v[i+n]);

AFIS:
    ofstream fout("2sat.out");
    if(realizabil)
        for(i=1; i<=n; i++)fout<<sol[i]<<' ';
    else fout<<-1;
    fout.close();
    return 0;
}
