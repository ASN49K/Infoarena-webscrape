#include<fstream>
#include<vector>
#include<set>
#include<stack>
#include<bitset>
using namespace std;
#define NMAX 200005
ifstream fin("2sat.in");
ofstream fout("2sat.out");
vector <int> v[NMAX];
stack <int> st;
set <int> R[NMAX];
set <int>::iterator it;
bitset <NMAX> IS;
int n,m,x,y,k,g,sol,Niv[NMAX],Low[NMAX],V[NMAX];
void dfs(int s)
{
    int i,z;
    Niv[s]=Low[s]=++g;
    st.push(s);
    IS[s]=1;
    for (i=0;i<v[s].size();++i)
    {
        z=v[s][i];
        if (!Niv[z])
        {
            dfs(z);
            Low[s]=min(Low[s],Low[z]);
        }
        else
            if (IS[z])
                Low[s]=min(Low[s],Low[z]);
    }
    if (Niv[s]==Low[s])
    {
        ++k;
        do
        {
            z=st.top(); st.pop();
            IS[z]=0;
            if ((z<=n && R[k].find(z+n)!=R[k].end()) || (z>n && R[k].find(z-n)!=R[k].end()))
                sol=-1;
            R[k].insert(z);
        } while (s!=z);

        if (!V[s])
        {
            for (it=R[k].begin();it!=R[k].end();++it)
            {
                V[*it]=1;
                if (*it>n) V[*it-n]=-1;
                else V[*it+n]=-1;
            }
        }
    }
}
int main()
{
    int i;
    fin>>n>>m;
    for (i=1;i<=m;++i)
    {
        fin>>x>>y;
        if (x<0) x=n-x;
        if (y<0) y=n-y;

        if (x>n) v[x-n].push_back(y);
        else v[x+n].push_back(y);

        if (y>n) v[y-n].push_back(x);
        else v[y+n].push_back(x);
    }
    for (i=1;i<=2*n;++i)
        if (!Niv[i])
            dfs(i);
    if (sol==-1)
    {
        fout<<"-1\n";
        return 0;
    }
    for (i=1;i<=n;++i)
        if (V[i]==1) fout<<"1 ";
        else fout<<"0 ";
    fout<<"\n";
    return 0;
}
