#include <bits/stdc++.h>
using namespace std;

fstream in ( "2sat.in" , ios::in  );
fstream out( "2sat.out", ios::out );

const int DIM = 200005;

int low[DIM], lev[DIM], ans[DIM]; set<int> mst;
vector<int> edg[DIM], stk;

inline int f( int x, int n ) {
    return ( x < 0 ) ? -x : ( x + n );
}

void dfs( int x, int n, int &dt, bool &ok ) {
    low[x] = lev[x] = ++ dt;
    stk.push_back( x );
    
    for( int y : edg[x] ) {
        if( lev[y] == 0 )
            dfs( y, n, dt, ok );
        if( lev[y] >  0 )
            low[x] = min( low[x], low[y] );
    }
    
    if( low[x] == lev[x] ) {
        mst.clear();
        
        int val;
        do {
            val = stk.back(); lev[val] *= -1;
            stk.pop_back(); mst.insert( val );
            
            if( x <= n && mst.find( x + n ) != mst.end() )
                ok = false;
            if( x >  n && mst.find( x - n ) != mst.end() )
                ok = false;
                
            if( ans[val] == 0 ) {
                ans[val] = 1;
                
                if( val <= n )
                    ans[val + n] = -1;
                else
                    ans[val - n] = -1;
            }
        } while( val != x );
    }
    
    return;
}

int main( void ) {
    ios::sync_with_stdio( false );
    
    int n, m;
    in >> n >> m;
    
    for( int i = 1; i <= m; i ++ ) {
        int x, y;
        in >> x >> y;
        
        edg[f( -x, n )].push_back( f( y, n) );
        edg[f( -y, n )].push_back( f( x, n) );
    }
    
    bool ok = true;
    for( int i = 1, dt = 0; i <= n * 2; i ++ ) {
        if( lev[i] == 0 )
            dfs( i, n, dt, ok );
    }
    
    if( ok == 0 )
        out << -1 << endl;
    else {
        for( int i = 1; i <= n; i ++ )
            out << ( ans[i] > 0 ) << " ";
        out << endl;
    }
    
    return 0;
}
