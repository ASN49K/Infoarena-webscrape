#include <bits/stdc++.h>
#define INF 0x3f3f3f3f

using namespace std;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

const int kN = 2e5;
vector<int> g[1 + kN];
int n, m, timer, vf, N, tin[1 + kN], low[1 + kN], stk[1 + kN], ctcIndex[1 + kN];

void minSelf(int &x, int y) {
  if (y < x) {
    x = y;
  }
}

int neg(int i) {
  if (i <= n) {
    return i + n;
  }
  return i - n;
}

void addEdge(int i, int j) {
  g[i].emplace_back(j);
}

void addOr(int i, int j) {
  addEdge(neg(i), j);
  addEdge(neg(j), i);
}

int getNode(int x) {
  if (x < 0) {
    return n - x;
  }
  return x;
}

void dfs(int u) {
  tin[u] = ++timer;
  low[u] = timer;
  stk[++vf] = u;
  for (int v : g[u]) {
    if (tin[v]) {
      minSelf(low[u], tin[v]);
    } else {
      dfs(v);
      minSelf(low[u], low[v]);
    }
  }
  if (tin[u] == low[u]) {
    int node;
    do {
      node = stk[vf];
      tin[node] = INF;
      ctcIndex[node] = N;
      vf -= 1;
    } while (node != u);
    N += 1;
  }
}

void testCase() {
  fin >> n >> m;
  for (int i = 0; i < m; ++i) {
    int x, y;
    fin >> x >> y;
    addOr(getNode(x), getNode(y));
  }
  for (int i = 1; i <= 2 * n; ++i) {
    if (!tin[i]) {
      dfs(i);
    }
  }
  for (int i = 1; i <= n; ++i) {
    if (ctcIndex[i] == ctcIndex[i + n]) {
      fout << "-1\n";
      return;
    }
  }
  for (int i = 1; i <= n; ++i) {
    if (ctcIndex[i] < ctcIndex[i + n]) {
      fout << "1 ";
    } else {
      fout << "0 ";
    }
  }
}

int main() {
  int tests = 1;
  for (int tc = 0; tc < tests; ++tc) {
    testCase();
  }
  fin.close();
  fout.close();
  return 0;
}
