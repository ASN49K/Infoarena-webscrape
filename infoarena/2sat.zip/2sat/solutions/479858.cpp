#include<stdio.h>
#include<vector>
#define Nmax 400010
using namespace std;

int n,nn,m,S[Nmax],i,x,y,sol[Nmax],viz[Nmax],ok=1;
vector<int> G[Nmax],T[Nmax];

int non(int x)
{
	if( x <= n ) return x+n ;
	return x-n;
}

void sortaret(int nod)
{
	if( viz[nod] ) return;
	
	int i, N = G[nod].size();
	viz[nod] = 1 ; 
	
	for( i = 0 ; i < N ; i++ )
		if( !viz[ G[nod][i] ] ) sortaret( G[nod][i] ) ;
	
	S[ nn-- ]  = nod; 
}

void dfs ( int nod ) 
{
	if( !viz[nod] ) return;
	
	int i , N = T[nod].size();
	viz[nod] = 0;
	
	if( sol[nod] )  ok = 0 ;  
	sol[ non(nod) ] = 1;
	
	for( i = 0 ; i < N ; i++ )
		if( viz[ T[nod][i] ] )  dfs( T[nod][i] );
}

int main()
{
	freopen("2sat.in","r",stdin);
	freopen("2sat.out","w",stdout);
	
	scanf("%d %d",&n,&m);
	
	for( i = 1 ; i <= m ; i++ )
	{
		scanf("%d %d",&x,&y);
		
		if( x < 0 ) x = non ( -x ) ;
		if( y < 0 ) y = non ( -y ) ;
		
		G[non(x)].push_back(y);
		G[non(y)].push_back(x);
		T[x].push_back(non(y));
		T[y].push_back(non(x));
	}
	
	nn = n<<1 ;
	
	for( i = 1 ; i <= n+n ; i++ )
		if( !viz[i] ) sortaret(i) ;
	
	for( i = 1 ; i <= n+n ; i++ )
		if( viz[ S[i] ] && viz [ S[non(i)] ] )
			dfs( S[i] );
	
	if( !ok ) { printf("-1"); return 0; }
	
	for( i = 1 ; i <= n ; i++ )
		printf("%d ",sol[i]);
	
	return 0;
}