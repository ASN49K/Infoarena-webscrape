#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
#define MAX 100010
typedef vector <int> :: iterator iter;
pair<int, int> e[2 * MAX];
vector <int> G[2 * MAX];
int viz[MAX], val[MAX], st[2 * MAX], dr;

#define viz (viz + MAX)
#define G (G + MAX)
#define val (val + MAX)
void df(int nod)
{
    viz[nod] = 1;
    for(iter it = G[nod].begin() ; it != G[nod].end() ; it++)
    {
        if(!viz[*it])
            df(*it);
    }
    st[++dr] = nod;
}

int main()
{
    int n, m, i, x, y, ok;
    fin >> n >> m;
    for(i = 1 ; i <= m ; i++)
    {
        fin >> e[i].first >> e[i].second;
        x = e[i].first;
        y = e[i].second;
        G[-x].push_back(y);
        G[-y].push_back(x);
    }
    for(i = -n ; i <= n ; i++)
    {
        if(i && !viz[i])
            df(i);
    }
    for(i = 1 ; i <= dr ; i++)
    {
        if(!val[st[i]] && !val[-st[i]])
        {
            val[st[i]] = 1;
        }
    }
    ok = 1;
    for(i = 1 ; i <= m ; i++)
    {
        if(!(val[e[i].first] || val[e[i].second]))
        {
            ok = 0;
        }
    }
    if(ok == 0)
    {
        fout << "-1\n";
        return 0;
    }
    for(i = 1 ; i <= n ; i++)
        fout << val[i] << " ";
}
