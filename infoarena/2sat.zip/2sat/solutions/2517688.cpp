#include <bits/stdc++.h>
#define NMAX 400005
#define ll long long int

using namespace std;

ll uz[NMAX], uz2[NMAX], x, y, leg1, leg2, atribuire[NMAX], nod1, nod2, n, m, i, indice, componenta[NMAX], contor;
vector<ll>vecini[NMAX], veciniInv[NMAX];
stack<ll> ordine;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

void firstDFS(int k){
    int i;
    uz[k] = 1;
    for(i=0; i<vecini[k].size(); ++i)
        if(uz[vecini[k][i]] == 0){
            firstDFS(vecini[k][i]);
            }
    ordine.push(k);

}

void secondDFS(int k){
    int i;
    uz2[k] = 1;
    for(i=0; i<veciniInv[k].size(); ++i)
        if(uz2[veciniInv[k][i]] == 0){
            secondDFS(veciniInv[k][i]);
            }
    componenta[k] = contor;
}

int main(){
    ios_base::sync_with_stdio(false);
    fin >> n >> m;
    for(i=1; i<=m; ++i){
        fin >> x >> y;
        nod1 = abs(x)*2;
        nod2 = abs(y)*2;
        if(x < 0)
            ++nod1;
        if(y < 0)
            ++nod2;

        if(x < 0)
            leg1 = nod1 - 1;
            else
            leg1 = nod1 + 1;
        vecini[leg1].push_back(nod2);
        veciniInv[nod2].push_back(leg1);

        if(y < 0)
            leg2 = nod2 - 1;
            else
            leg2 = nod2 + 1;
        vecini[leg2].push_back(nod1);
        veciniInv[nod1].push_back(leg2);
        }
    for(i=2; i<=2*n+1; ++i)
        if(uz[i] == 0){
            firstDFS(i);
            }
    contor = 1;
    while(!ordine.empty()){
        indice = ordine.top();
        ordine.pop();
        if(uz2[indice] == 0)
            secondDFS(indice);
        ++contor;
        }
    for(i=2; i<=2*n+1; i+=2){
        atribuire[i/2] = componenta[i] > componenta[i+1];
        }
    for(i=1; i<=n; ++i)
        fout << atribuire[i] << ' ';
    fout << '\n';
    return 0;
}
