#include <fstream>
#include <cstring>
#include <vector>
using namespace std;
ifstream cin("2sat.in");
ofstream cout("2sat.out");

vector <int> g[200010];
vector <int> gt[200010];
int st[200010],nr,sol[200010];
int idx[200010];
bool viz[200010];
int n,m,i,j,x,y,ok;

int negat(int x)
{
    if(x>n) return x-n;
    return x+n;

}
void muchie(int x, int y)
{
    g[x].push_back(y);
    gt[y].push_back(x);
}

void dfs(int nod)
{
    viz[nod]=1;

    for(int i=0; i<g[nod].size(); ++i)
    {
        if(!viz[g[nod][i]])
            dfs(g[nod][i]);

    }
    st[++nr] = nod;
}


void dfs2(int nod)
{
    if(ok==0) return;
    if(sol[nod] == 1)
    {
        ok=0;
        return;
    }

    sol[negat(nod)] = 1;

    viz[nod]=1;

    for(int i=0; i<gt[nod].size(); ++i)
        if(!viz[gt[nod][i]])
            dfs2(gt[nod][i]);

}

int main()
{
    cin>>n>>m;
    ok=1;
    for(i=1; i<=m; ++i)
    {
        cin>>x>>y;
        if(y<0) y = n-y;
        if(x<0) x = n-x;

        muchie(negat(x), y);
        muchie(negat(y),x);
    }

    for(i=1; i<=2*n; ++i)
    {
        if(!viz[i])
            dfs(i);
    }

    memset(viz,0,sizeof(viz));
    for(i=nr; i>=1; --i)
    {
        if(!viz[st[i]] && !viz[negat(st[i])])
        {
            dfs2(st[i]);
        }
    }
    if(!ok)
    {
        cout<<-1;
        return 0;
    }

    for(i=1; i<=n; ++i)
        cout<<sol[i]<<" ";
    return 0;
}
