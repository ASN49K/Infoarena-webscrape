#include<bits/stdc++.h>
#define N 200002
using namespace std;
ifstream F("2sat.in");
ofstream G("2sat.out");
vector<int> v[N],u[N],o;
stack<int> s;
int a[N],n,m,i,j;
int C(int i)
{
	return (i+n)%(2*n);
}
void D(int i,int c)
{
	if(a[i]==c)
		return;
	a[i]=c;
	if(!c)
		o.push_back(i);
	for(auto I:(c?v[i]:u[i]))
		D(I,c);
	if(c)
		s.push(i);
}
int main()
{
	F>>n>>m;
	while(m--)
		F>>i>>j,i=(i>0)*n+abs(i)-1,j=(j>0)*n+abs(j)-1,
		v[C(i)].push_back(j),v[C(j)].push_back(i),
		u[i].push_back(C(j)),u[j].push_back(C(i));
	for(i=0;i<2*n;++i)
		D(i,1);
	for(;!s.empty();s.pop())
		D(s.top(),0);
	for(auto I:o)
		if(!a[I])
			a[I]=1,a[C(I)]=2;
	for(i=0;i<2*n;++i)
		if(a[i]==2)
			for(auto I:v[i])
				if(a[I]==1) {
					G<<-1;
					return 0;
				}
	for(i=n;i<2*n;i++)
		G<<a[i]-1<<" ";
	return 0;
}
