#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream in ("2sat.in");
ofstream out ("2sat.out");

const int max_size = 1e5 + 1;

int viz[2 * max_size], ctc[max_size], n;
vector <int> mc[2 * max_size], topsort, invmc[2 * max_size];

void dfs (int nod)
{
    viz[nod] = 1;
    for (auto f : mc[nod])
    {
        if (!viz[f])
        {
            dfs(f);
        }
    }
    topsort.push_back(nod);
}

void kos (int nod, int ct)
{
    viz[nod] = 0;
    ctc[nod] = ct;
    for (auto f : invmc[nod])
    {
        if (viz[f])
        {
            kos(f, ct);
        }
    }
}

int neg (int x)
{
    if (x > n)
    {
        x -= n;
    }
    return x;
}

int main ()
{
    int m;
    in >> n >> m;
    while (m--)
    {
        int x, y;
        in >> x >> y;
        if (x < 0)
        {
            x = - x + n;
        }
        if (y < 0)
        {
            y = - y + n;
        }
        mc[neg(x)].push_back(y);
        mc[neg(y)].push_back(x);
        invmc[x].push_back(neg(y));
        invmc[y].push_back(neg(x));
    }
    for (int i = 1; i <= 2 * n; i++)
    {
        if (!viz[i])
        {
            dfs(i);
        }
    }
    int ct = 0;
    reverse(topsort.begin(), topsort.end());
    for (auto f : topsort)
    {
        if (viz[f])
        {
            ++ct;
            kos(f, ct);
        }
    }
    for (int i = 1; i <= n; i++)
    {
        if (ctc[i] == ctc[i + n])
        {
            out << -1;
            return 0;
        }
    }
    for (int i = 1; i <= n; i++)
    {
        if (ctc[i] < ctc[i + n])
        {
            out << 1 << " ";
        }
        else
        {
            out << 0 << " ";
        }
    }
    in.close();
    out.close();
    return 0;
}
