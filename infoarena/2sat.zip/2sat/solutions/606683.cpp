#include<fstream.h>
#include<vector.h>
#define pb push_back
#define N 200001
long n,m,i,a[N],b[N],j,p[N],w[N],c[N],nr;
vector<long> f[N],g[N];
void A(int x)
{c[x]=1;
for(i=0;i<f[x].size();i++)
if(!c[f[x][i]])
       A(f[x][i]);
w[++nr]=x;}
void B(int x)
{c[x]=0;
if(p[x]==2)
       {p[x]=0;
       if(x>n)
               p[x-n]=1;
       else
               p[x+n]=1;}
for(i=0;i<g[x].size();i++)
if(c[g[x][i]])
       B(g[x][i]);}
int main()
{ifstream y("2sat.in");
ofstream z("2sat.out");
y>>n>>m;
for(i=1;i<=m;i++)
       {y>>a[i]>>b[i];
       if(a[i]<0)
              a[i]=n-a[i];
       if(b[i]<0)
              b[i]=n-b[i];
       if(a[i]>n)
              f[a[i]-n].pb(b[i]),g[b[i]].pb(a[i]-n);
       else
              f[a[i]+n].pb(b[i]),g[b[i]].pb(a[i]+n);
       if(b[i]>n)
              f[b[i]-n].pb(a[i]),g[a[i]].pb(b[i]-n);
       else
              f[b[i]+n].pb(a[i]),g[a[i]].pb(b[i]+n);}
for(j=1;j<=2*n;j++)
       {p[j]=2;
       if(!c[j])
              A(j);}
for(i=nr;i>0;i--)
       B(w[i]);
for(j=1;j<=m;j++)
if(!p[a[j]]&&!p[b[j]])
       {z<<"-1";
       return 0;}
for(i=1;i<=n;i++)
       z<<p[i]<<" ";
return 0;}
