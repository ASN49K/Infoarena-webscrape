#include <iostream>
#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream f ("2sat.in");
ofstream g ("2sat.out");

const int N_MAX = 100005;

int n, m, cnt, id;
int ids[2 * N_MAX], low[2 * N_MAX], comp[2 * N_MAX];

vector <int> adj[2 * N_MAX];
vector <bool> inStack(2 * N_MAX, false);

stack <int> s;

inline int ValAsoc(int x)
{
    return (x > 0) ? (x) : (-x + n);
}

inline int Negate(int x)
{
    return (x <= n) ? (x + n) : (x - n);
}

void Read()
{
    f >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        f >> x >> y;

        x = ValAsoc(x);
        y = ValAsoc(y);

        adj[Negate(x)].push_back(y);
        adj[Negate(y)].push_back(x);
    }
}

void Tarjan(int node)
{
    ids[node] = low[node] = ++id;
    s.push(node);
    inStack[node] = true;

    for (unsigned int i = 0; i < adj[node].size(); i++)
    {
        int neighbour = adj[node][i];
        if (ids[neighbour] == 0)
        {
            Tarjan(neighbour);
        }
        if (inStack[neighbour] == true)
        {
            low[node] = min(low[node], low[neighbour]);
        }
    }

    if (ids[node] == low[node])
    {
        cnt++;
        int temp = 0;

        while (temp != node)
        {
            temp = s.top();
            s.pop();
            inStack[temp] = false;
            comp[temp] = cnt;
        }
    }
}

void Solve()
{
    for (int i = 1; i <= 2 * n; i++)
    {
        if (comp[i] == 0)
        {
            Tarjan(i);
        }
    }
}

void Print()
{
    for (int i = 1; i <= n; i++)
    {
        if (comp[i] == comp[i + n])
        {
            g << "-1";
            return;
        }
    }

    for (int i = 1; i <= n; i++)
    {
        if (comp[i] > comp[i + n])
        {
            g << "0 ";
        }
        else
        {
            g << "1 ";
        }
    }
}

int main()
{
    Read();
    Solve();
    Print();

    return 0;
}
