#include<fstream>
#include<vector>
#include<queue>
#include<algorithm>
using namespace std;
#define N 200001
int variables,expressions,x,y,i,impossible,j;
vector<int> var_adj[N],var_adj_t[N],vtc(N),value(N,-1),scc_in_deg(N,0);
vector<vector<int>> sccs;
queue<int> Q;
int abs(int x)
{
    return x<0?-x:x;
}
int idx(int x)
{
    return x<0?abs(x)+variables:x;
}
int non(int x)
{
    return x>variables?x-variables:x+variables;
}
void DFP(int n,vector<int>& used,vector<int>& discover)
{
    vector<int>::iterator it;
    used[n]=1;
    for(it=var_adj[n].begin();it!=var_adj[n].end();++it)
        if(!used[*it])
            DFP(*it,used,discover);
    discover.push_back(n);
}
void DFM(int n,vector<int>& used,vector<int>& scc)
{
    vector<int>::iterator it;
    used[n]=1;
    scc.push_back(n);
    for(it=var_adj_t[n].begin();it!=var_adj_t[n].end();++it)
        if (!used[*it])
            DFM(*it,used,scc);
}
void compute_sccs(void)
{
    vector<int> used(N),discover,scc;
    used.assign(used.size(),0);
    for(int i=1;i<=variables*2;++i)
        if(!used[i])
            DFP(i,used,discover);
    used.assign(used.size(),0);
    vector<int>::reverse_iterator it;
    for(it=discover.rbegin();it!=discover.rend();++it)
        if (!used[*it])
        {
            scc.clear();
            DFM(*it,used,scc);
            for(vector<int>::iterator it2=scc.begin();it2!=scc.end();++it2)
                vtc[*it2]=sccs.size();
            sccs.push_back(scc);
        }
}
int main()
{
    ifstream in("2sat.in");
    ofstream out("2sat.out");
    in>>variables>>expressions;
    for(i=0;i<expressions;++i)
    {
        in>>x>>y;
        var_adj[non(idx(x))].push_back(idx(y));
        var_adj_t[idx(y)].push_back(non(idx(x)));
        var_adj[non(idx(y))].push_back(idx(x));
        var_adj_t[idx(x)].push_back(non(idx(y)));
    }
    compute_sccs(),impossible=false;
    for(x=1;x<=variables;++x)
        if(vtc[x]==vtc[x+variables])
            impossible=true;
    if(!impossible)
    {
        for(x=1;x<=variables*2;++x)
        {
            vector<int>::iterator it;
            for(it=var_adj[x].begin();it!=var_adj[x].end();++it)
                if(vtc[x]!=vtc[*it])
                    scc_in_deg[vtc[*it]]++;
        }
        for(j=0;j<(int)sccs.size();++j)
            if(!scc_in_deg[j])
                Q.push(j);
        while(!Q.empty())
        {
            j=Q.front(),Q.pop();
            vector<int>::iterator it,k,l;
            for(it=sccs[j].begin();it!=sccs[j].end();++it)
            {
                x=(*it>variables)?*it-variables:*it;
                if(value[x]==-1)
                    value[x]=(*it<=variables)?0:1;
            }
            for(k=sccs[j].begin();k!=sccs[j].end();++k)
                for(l=var_adj[*k].begin();l!=var_adj[*k].end();++l)
                    if (vtc[*k]!=vtc[*l])
                        if((--scc_in_deg[vtc[*l]])==0)
                            Q.push(vtc[*l]);
        }
        for(i=1;i<=variables;++i)
            out<<value[i]<<" ";
    }
    else
        out<<-1;
}
