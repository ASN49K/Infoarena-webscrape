#include<cstdio>
#include<bitset>
#include<vector>
#include<cstring>
using namespace std;
const int nmax = 100005;
int n,m,x,y,i,tsort[2*nmax],cnt,ctc[2*nmax],viz[2*nmax];
vector<int> v[2*nmax],g[2*nmax];
#define viz (viz+nmax)
#define v (v+nmax)
#define g (g+nmax)
#define ctc (ctc+nmax)
void dfs(int x)
{
    for(vector<int>::iterator it=v[x].begin();it!=v[x].end();it++)
        if(!viz[*it]) {viz[*it]=1; dfs(*it);}
    tsort[++cnt]=x;
}
void dfst(int x)
{
    ctc[x]=cnt;
    for(vector<int>::iterator it=g[x].begin();it!=g[x].end();it++)
        if(!viz[*it]) {viz[*it]=1; dfst(*it);}
}
int main()
{
	freopen("2sat.in","r",stdin);
	freopen("2sat.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(;m;m--)
	{
	    scanf("%d%d",&x,&y);
	    v[-x].push_back(y);
	    v[-y].push_back(x);
	    g[x].push_back(-y);
	    g[y].push_back(-x);
	}
	for(i=-n;i<=n;i++)
	{
	    if(i==0) continue;
	    if(!viz[i]) {viz[i]=1; dfs(i);}
	}
	for(i=-n;i<=n;i++) viz[i]=0; cnt=0;
	for(i=2*n;i;i--) if(!viz[tsort[i]]) {cnt++; viz[tsort[i]]=1; dfst(tsort[i]);}
	for(i=1;i<=n;i++) if(ctc[i]==ctc[-i]) {printf("-1\n"); return 0;}
	for(i=1;i<=n;i++) printf("%d ",ctc[i]>ctc[-i]);
	return 0;
}
