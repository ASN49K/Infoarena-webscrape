//
// Created by mihai145 on 05.03.2021.
//

#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream cin("2sat.in");
ofstream cout("2sat.out");

const int NMAX = 1e5;

int N, M;
vector<int> g[2 * NMAX + 2];
vector<int> r[2 * NMAX + 2];

stack<int> st;
int kComp, comp[2 * NMAX + 2];
bool seen[2 * NMAX + 2];

int Norm(int x) {
    if(x > 0) {
        return x;
    }

    return -x + N;
}

int Not(int x) {
    if(x > 0) {
        return x + N;
    }

    return -x;
}


void dfs1(int node) {
    seen[node] = true;

    for(int son : g[node]) {
        if(!seen[son]) {
            dfs1(son);
        }
    }

    st.push(node);
}

void dfs2(int node) {
    seen[node] = false;
    comp[node] = kComp;

    for(int son : r[node]) {
        if(seen[son]) {
            dfs2(son);
        }
    }
}

int main() {
    cin >> N >> M;

    for(int i = 1; i <= M; i++) {
        int x, y;
        cin >> x >> y;
        g[Not(x)].push_back(Norm(y));
        r[Norm(y)].push_back(Not(x));

        g[Not(y)].push_back(Norm(x));
        r[Norm(x)].push_back(Not(y));
    }

    for(int i = 1; i <= 2 * N; i++) {
        if(!seen[i]) {
            dfs1(i);
        }
    }

    while(!st.empty()) {
        int node = st.top();
        st.pop();

        if(seen[node] == true) {
            ++kComp;
            dfs2(node);
        }
    }

    for(int i = 1; i <= N; i++) {
        if(comp[i] == comp[i + N]) {
            cout << -1 << '\n';
            return 0;
        }
    }

    for(int i = 1; i <= N; i++) {
        if(comp[i] < comp[i + N]) {
            cout << 0 << ' ';
        } else {
            cout << 1 << ' ';
        }
    }

    return 0;
}