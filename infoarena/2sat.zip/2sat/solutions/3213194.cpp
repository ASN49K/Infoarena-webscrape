#include <bits/stdc++.h>
using namespace std;

#pragma GCC optimize("O2,unroll-loops")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
#define pb push_back
#define mp make_pair
#define f first
#define s second

vector<vi> adj(200005), adj_inv(200005);
vector<bool> visited(200005);
vi topological, comp(200005);

void dfs(int x){
    visited[x] = 1;
    for(auto i : adj[x])
        if(!visited[i])
            dfs(i);
    topological.pb(x);
}

void dfs2(int x, int num){
    visited[x] = 1;
    comp[x] = num;
    for(auto i : adj_inv[x])
        if(!visited[i])
            dfs2(i, num);
}

void solve(){
    int n, m;
    cin >> n >> m;
    for(int i = 0; i < m; i++){
        int a, b, neg_a, neg_b;
        cin >> a >> b;
        if(a < 0)
            a = abs(a), neg_a = a + n; 
        else 
            neg_a = abs(a), a += n;
        if(b < 0)
            b = abs(b), neg_b = b + n; 
        else 
            neg_b = abs(b), b += n;
        adj[neg_a].pb(b); adj[neg_b].pb(a);
        adj_inv[b].pb(neg_a); adj_inv[a].pb(neg_b);
    }
    for(int i = 1; i <= 2*n; i++){
        if(!visited[i])
            dfs(i);
    }
    reverse(topological.begin(), topological.end());
    int cnt = 0;
    visited = vector<bool>(200005);
    for(int i = 0; i < 2*n; i++){
        int x = topological[i];
        if(!visited[x]){
            dfs2(x, cnt);
            cnt++;
        }
    }
    //i is the negation, i+n is not
    vi ans;
    for(int i = 1; i <= n; i++){
        if(comp[i] == comp[i+n]){
            cout << -1 << '\n';
            return;
        }
        if(comp[i] > comp[i+n])
            ans.pb(0);
        else
            ans.pb(1);
    }
    for(auto i : ans)
        cout << i << ' ';
    cout << '\n';
}   

int main(){
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}