#include <cstdio> 
#include <vector>
#include <cassert>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define x first
#define y second

using namespace std;

const int maxn = 100005;
const int CONST = 50;

vector <pair<int, int> > R;
int x, y, i, j, n, m, t, v[maxn];
bool mark[maxn];

bool eval(pair<int , int> A) {

    bool val1 = v[A.first] , val2 = v[A.second];
    if(A.first < 0)
        val1 ^= 1;
    if(A.second < 0)
        val2 ^= 1;

    return (val1 | val2);
}

bool fail = true;

int main() {

    assert(freopen("2sat.in", "r", stdin) != NULL);
    assert(freopen("2sat.out", "w", stdout) != NULL);
    
    assert(scanf("%d %d",&n, &m) == 2);

    for (i = 1; i <= m; ++i) {
        assert(scanf("%d %d", &x, &y) == 2);
        R.push_back(make_pair(x , y));
    }

    srand(time(NULL));
    for (i = 1; i <= n; ++i)
        v[i] = rand() % 2;
        
    for (t = 1; t <= CONST; ++t) {
        fail = false;

        for (i = 1; i <= m; ++i)
            if (!eval(R[i - 1])) {
                
                fail = true;
                if (mark[R[i].first] && mark[R[i].second])
                    continue;

                if (mark[R[i].first]) {
                    v[R[i].second] ^= 1;
                    continue;
                }

                if (mark[R[i].second]) {
                    v[R[i].first] ^= 1;
                    continue;
                }

                int choice = rand() % 2;

                if(choice)
                    v[R[i].first] ^= 1,
                    mark[R[i].first] = true;
                else {
                    v[R[i].second] ^= 1;
                    mark[R[i].second] = true;
                }
         
            }
        
        memset(mark, false, sizeof(mark));

        if (!fail)
            break;
    }
    
    for (i = 1; i <= n; ++i)
        printf("%d ",v[i]);

    return 0;
}
