#include<fstream>
#include<vector>
#include<cstring>
using namespace std;

int n,m,x,y,stlev,st[200005];
vector<int> g[200005], gt[200005];
bool viz[200005], sol[200005], ok=1;

int norm(int x) {
	if (x>0) return x;
	else return n-x;
}

int negat(int x){	
  if (x<=n) return n+x;
  else return x-n;
}

void dfs1(int nod) {
   viz[nod]=1;
   
   for (int i=0; i<g[nod].size(); ++i)
    if (viz[g[nod][i]]==0) dfs1(g[nod][i]);
	
   st[++stlev]=nod;	
}

void dfs2(int nod) {
  viz[nod]=1;
  int aux = negat(nod);
  
  if (viz[aux]==1 && sol[aux]==0) ok=0;
  else sol[aux]=1;
  
  for (int i=0; i<gt[nod].size(); ++i)
   if (viz[gt[nod][i]]==0) dfs2(gt[nod][i]);
}

int main(void) {
	ifstream cin("2sat.in");
	ofstream cout("2sat.out");
	
	cin>>n>>m;
	for (int i=1; i<=m; ++i) {
	   cin>>x>>y; x=norm(x); y=norm(y);
	   
	   g[negat(x)].push_back(y);
	   g[negat(y)].push_back(x);	
		
	   gt[y].push_back(negat(x));
	   gt[x].push_back(negat(y));
	}
	
	for (int i=1; i<=2*n; ++i)
	 if (viz[i]==0) dfs1(i);
	 
	memset(viz,0,sizeof(viz));
	 
	for (int i=2*n; i>=1; --i)
	 if (viz[st[i]]==0 && viz[negat(st[i])]==0) dfs2(st[i]);
	
	if (ok==0) cout<<"-1";
	else for (int i=1; i<=n; ++i) cout<<sol[i]<<" ";
	
	return 0;
}
