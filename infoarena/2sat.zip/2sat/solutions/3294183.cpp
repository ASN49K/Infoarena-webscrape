#include <bits/stdc++.h>
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
const int NMAX = 2e5 + 1;
vector<int> vec[NMAX], trans[NMAX], sorted, stk;
int n, m, vis[NMAX], comp[NMAX];

int id(int n)
{
    if(n > 0)
        return 2 * n;
    else
        return 2 * (-n) + 1;
}

int neg(int n)
{
    return (n ^ 1);
}

void dfs1(int nod)
{
    vis[nod] = 1;
    for(int i : vec[nod])
        if(!vis[i])
            dfs1(i);
    stk.push_back(nod);
}

void dfs2(int nod, int id)
{
    vis[nod] = 1;
    comp[nod] = id;
    for(int i : trans[nod])
        if(!vis[i])
            dfs2(i, id);
}

void topsort()
{
    for(int i = 1; i <= 2 * n; i++)
        if(!vis[i])
            dfs1(i);
    memset(vis, 0, sizeof(vis));
    reverse(stk.begin(), stk.end());
    int id = 0;
    for(int nod : stk)
        if(!vis[nod])
            dfs2(nod, ++id);
}

bool solve()
{
    topsort();
    for(int i = 1; i <= n; i++)
    {
        int u = id(i);
        if(comp[u] == comp[neg(u)])
            return false;
    }
    return true;
}

int main()
{
    fin >> n >> m;
    while(m--)
    {
        int x, y;
        fin >> x >> y;
        int u = id(x), v = id(y);
        vec[neg(u)].push_back(v); trans[v].push_back(neg(u));
        vec[neg(v)].push_back(u); trans[u].push_back(neg(v));
    }
    bool ok = solve();
    if(!ok)
        fout << -1;
    else
    {
        for(int i = 1; i <= n; i++)
        {
            int u = id(i);
            fout << (comp[u] > comp[neg(u)]) << " ";
        }
    }

    return 0;
}
