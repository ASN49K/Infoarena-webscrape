#include <bits/stdc++.h>
#define cin ci
#define cout co
using namespace std;
ifstream cin("2sat.in");
ofstream cout("2sat.out");
int n, m, x, y, notx, noty;
vector<vector<int>> graf, graft;
vector<int> comp, viz, ord;
void dfs(int node)
{
    viz[node] = 1;
    for(auto next:graf[node])
        if(!viz[next])
            dfs(next);
    ord.push_back(node);
}
int cmp = 0;
void dfst(int node)
{
    viz[node] = 1;
    comp[node] = cmp;
    for(auto next:graft[node])
        if(!viz[next])
            dfst(next);
}
int main()
{
    cin >> n >> m;
    graf.assign(2 * n + 1, vector<int>());
    graft.assign(2 * n + 1, vector<int>());
    viz.resize(2 * n + 1);
    comp.resize(2 * n + 1);
    while(m--)
    {
        cin >> x >> y;
        x = (x < 0) ? n - x : x;
        y = (y < 0) ? n - y : y;
        notx = (x > n) ? x - n : n + x;
        noty = (y > n) ? y - n : n + y;
        graf[notx].push_back(y);
        graf[noty].push_back(x);
        graft[y].push_back(notx);
        graft[x].push_back(noty);
    }
    for(int i = 1; i <= n; i++)
        if(!viz[i])
            dfs(i);
    fill(viz.begin(), viz.end(), 0);
    reverse(ord.begin(), ord.end());
    for(auto i:ord)
        if(!viz[i])
        {
            cmp++;
            dfst(i);
        }
    vector<int> val(n + 1);
    for(int i = 1; i <= n; i++)
        if(comp[i] == comp[i + n])
        {
            cout << "-1";
            return 0;
        }
        else if(comp[i] > comp[i + n])
            val[i] = 1;
    for(int i=1; i<=n; i++)
        cout << val[i] << " ";
    return 0;
}
