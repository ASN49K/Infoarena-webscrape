#include <fstream>
#include <iostream>
#include <vector>
#include <stack>
#include <bitset>
#include <algorithm>

#define MAXN	100001

using namespace std;

struct Node
{
	Node() : index(-1), lowlink(0), bIsOnStack(false)
	{}

	int index, lowlink;
	bool bIsOnStack;
};

typedef unsigned int uint32;
typedef vector<vector<int> > Graph;
typedef vector<vector<int> > Scc;

uint32 whatComponent[2*MAXN];

inline uint32 non(const uint32 x, const uint32 n)
{
	return (x>=n) ? (x - ((x-n)*2 + 1)) : (x + ((n-x)*2 - 1));
}

inline int original(const uint32 x, const uint32 n)
{
	return (x>=n) ? (x-n+1) : (x-n);
}

void StronglyConnectedComponent
(
	const Graph& graph,
	Node *nodes,
	stack<int>& S,
	const int node,
	int& index,
	Scc& sccs,
	int& numComp
)
{
	nodes[node].index = index;
	nodes[node].lowlink = index;
	index++;
	S.push(node);
	nodes[node].bIsOnStack = true;
	
	for (int i=0; i<graph[node].size(); ++i)
	{
		if (-1 == nodes[graph[node][i]].index)
		{
			StronglyConnectedComponent(graph, nodes, S, graph[node][i], index, sccs, numComp);
			nodes[node].lowlink = min(nodes[node].lowlink, nodes[graph[node][i]].lowlink);
		}
		else if (nodes[graph[node][i]].bIsOnStack)
		{
			nodes[node].lowlink = min(nodes[node].lowlink, nodes[graph[node][i]].index);
		}
	}
	
	if (nodes[node].lowlink == nodes[node].index)
	{
		int curNode;
		do
		{
			curNode = S.top();
			sccs[numComp].push_back(curNode);
			nodes[curNode].bIsOnStack = false;
			
			whatComponent[curNode] = numComp;
			
			S.pop();
		} while(!S.empty() && curNode!=node);
		numComp++;
	}
}

int StronglyConnectedComponents(const Graph& graph, Scc& sccs)
{
	int index = 0, numComp = 0;
	Node *nodes;
	stack<int> S;
	
	nodes = new Node[graph.size()+1];
	sccs.resize(graph.size());
	
	for (int i=0; i<graph.size(); ++i)
	{
		if (-1 == nodes[i].index)
		{
			StronglyConnectedComponent(graph, nodes, S, i, index, sccs, numComp);
		}
	}
	
	if (!S.empty())
	{
		int curNode;
		do
		{
			curNode = S.top();
			sccs[numComp].push_back(curNode);
			
			whatComponent[curNode] = numComp;
			
			S.pop();
			numComp++;
		} while(!S.empty());
	}
	
	delete[] nodes;
	
	return numComp;
}

int main()
{
	uint32 n, m, numComp, variables, statements;
	Graph graph;
	Scc sccs;
	fstream fin("2sat.in", fstream::in);
	fstream fout("2sat.out", fstream::out);
	
	fin >> variables >> statements;
	//cout << variables << " " << statements << endl;
	
	//n = variables;
	//m = statements;

	graph.resize(2*variables);
	
	for (uint32 i=0; i<statements; ++i)
	{
		int x, y;
		fin >> x >> y;
		
		if (x<0)
		{
			x += variables;
		}
		else
		{
			x += (variables-1);
		}
		if (y<0)
		{
			y += variables;
		}
		else
		{
			y += (variables-1);
		}

		graph[non(x, variables)].push_back(y);
		graph[non(y, variables)].push_back(x);
	}
	
	/*for (int i=0; i<n; ++i)
	{
		cout << i+1 << ": ";
		for (int j=0; j<graph[i].size(); ++j)
		{
			cout << graph[i][j]+1 << " ";
		}
		cout << endl;
	}
	
	cout << endl;*/
	
	numComp = StronglyConnectedComponents(graph, sccs);
	
	for (uint32 i=0; i<variables; ++i)
	{
		if (whatComponent[i] == whatComponent[non(i, variables)])
		{
			fout << -1 << "\n";
			return -1;
		}
	}
	
	fout << numComp << "\n";
	for (uint32 i=0; i<numComp; ++i)
	{
		for (uint32 j=0; j<sccs[i].size(); ++j)
		{
			fout << original(sccs[i][j], variables) << " ";
		}
		fout << "\n";
	}
	
	fin.close();
	fout.close();
	return 0;
}
