#include <bits/stdc++.h>

using namespace std;
int n,m,x,y;
vector<int>nod[100005];
map<int,bool>wrong[2][2][100005];
bool ap[100005];
bool val[100005];
stack<int>stk;
void del(int pos)
{
    while(stk.top()!=pos)
    {
        ap[stk.top()]=false;
        stk.pop();
    }
    ap[stk.top()]=false;
    stk.pop();
}
bool check(int pos,int v)
{
    bool ok=true;
    for(int i=0;i<nod[pos].size();i++)
    {
        if(ap[nod[pos][i]])
        {
            if(wrong[v][val[nod[pos][i]]][pos][nod[pos][i]])
            {
                ok=false;
                break;
            }
        }
        else
        {
            if(wrong[v][0][pos][nod[pos][i]] && wrong[v][1][pos][nod[pos][i]])
            {
                ok=false;
                break;
            }
        }
    }
    return ok;
}
bool go_visit(int pos,int v)
{
    if(!check(pos,v))
        return false;
    ap[pos]=true;
    val[pos]=v;
    stk.push(pos);
    bool ok=true;
    for(int i=0;i<nod[pos].size();i++)
    {
        if(ap[nod[pos][i]])
            continue;
        bool ok0=!wrong[v][0][pos][nod[pos][i]];
        bool ok1=!wrong[v][1][pos][nod[pos][i]];
        if(ok0 && ok1)
        {
            if(!go_visit(nod[pos][i],0) && !go_visit(nod[pos][i],1))
            {
                del(pos);
                ok=false;
                break;
            }
            continue;
        }
        if(ok0 && !go_visit(nod[pos][i],0))
        {
            del(pos);
            ok=false;
            break;
        }
        if(ok1 && !go_visit(nod[pos][i],1))
        {
            del(pos);
            ok=false;
            break;
        }
    }
    return ok;
}
int main()
{
    ifstream fin("2sat.in");
    ofstream fout("2sat.out");
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        int ax=abs(x);
        int ay=abs(y);
        nod[ax].push_back(ay);
        nod[ay].push_back(ax);
        if(x>0 && y>0)
        {
            wrong[0][0][ax][ay]=true;
            wrong[0][0][ay][ax]=true;
        }
        if(x>0 && y<0)
        {
            wrong[0][1][ax][ay]=true;
            wrong[1][0][ay][ax]=true;
        }
        if(x<0 && y>0)
        {
            wrong[1][0][ax][ay]=true;
            wrong[0][1][ay][ax]=true;
        }
        if(x<0 && y<0)
        {
            wrong[1][1][ax][ay]=true;
            wrong[1][1][ay][ax]=true;
        }
    }
    for(int i=1;i<=n;i++)
    {
        if(ap[i])
            continue;
        if(!go_visit(i,0))
            go_visit(i,1);
    }
    for(int i=1;i<=n;i++)
        fout<<val[i]<<" ";
    return 0;
}
