#include <stdio.h>
#include <vector>
#include <cstring>

using namespace std;

#define maxn 200100
#define pb push_back

long n, m, i, j, k, nod, sol, a, ai, b, bi, f[maxn], st[maxn], st2[maxn], u[maxn], cul[maxn];
vector<long> v[maxn], vi[maxn], vc[maxn];

void df(long nod)
{
    if(f[nod]) return;
    long y;
    f[nod]=1;
    for(y=0; y<v[nod].size(); y++)
        df(v[nod][y]);
    st[++st[0]]=nod;
}

void df2(long nod, long who)
{
    if(f[nod]) return;
    long y=0;
    f[nod]=1;
    u[nod]=who;
    for(y=0; y<vi[nod].size(); y++)
        df2(vi[nod][y], who);
    st2[++st2[0]]=nod;
}

int main()
{
    freopen("2sat.in", "r", stdin);
    freopen("2sat.out", "w", stdout);
    scanf("%d%d", &n, &m);
    for(i=1; i<=m; i++)
    {
        scanf("%d%d", &a, &b);
        if(a<0) a=-a+n;
        if(b<0) b=-b+n;
        --a; ai=(a+n)%(2*n)
        --b; bi=(b+n)%(2*n)
        v[ai].pb(b); v[bi].pb(a);
        vi[b].pb(ai); vi[a].pb(bi);
    }
    for(i=0; i<2*n; i++)
        if(!f[i])
            df(i);
    memset(f,  0, sizeof(f));
    for(i=2*n; i; --i)
    {
        cul[i-1]=2;
        if(!f[st[i]])
        {
            df2(st[i], st[i]);
            sol++;
        }
    }
    for(i=2*n; i; --i)
    {
        nod=st[i];
        if(cul[u[nod]]!=2) continue;
        cul[u[nod]]=0;
        if(cul[u[(nod+n)%(2*n)]]!=2)
        {
            printf("-1\n");
            return 0;
        }
        cul[u[(nod+n)%(2*n)]]=1;
    }
    for(i=0; i<n; i++)
        printf("%d ", cul[u[i]]);
    printf("\n");
    return 0;
}
