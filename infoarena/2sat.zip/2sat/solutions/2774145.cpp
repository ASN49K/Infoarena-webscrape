#include <bits/stdc++.h>

using namespace std;
ifstream f("2sat.in");
ofstream g("2sat.out");
int n;
vector <int> v[400005],inv[400005];
int nod (int x)
{
    if (x<0)
    {
        return n+abs(x);
    }
    return x;
}
void adauga(int x,int y)
{
    x=nod(x),y=nod(y);
    v[x].push_back(y);
    inv[y].push_back(x);
}
int viz[400005],sal[400005],q;
void dfs(int x)
{
    int i;
    viz[x]=1;
    for (i=0;i<v[x].size();i++)
    {
        int nod=v[x][i];
        if (viz[nod]==0)
        {
            dfs(nod);
        }
    }
    sal[++q]=x;
}
int nr;
vector <int> comp[400005];
void dfs2(int x)
{
    int i;
    comp[nr].push_back(x);
    viz[x]=1;
    for (i=0;i<inv[x].size();i++)
    {
        int nod=inv[x][i];
        if (viz[nod]==0)
        {
            dfs2(nod);
        }
    }
}
int m,i,x,y,grupa[400005],val[400005],ok[400005],j,nrintr[400005];
int main()
{
    f>>n>>m;
    for (i=1;i<=m;i++)
    {
        f>>x>>y;
        adauga(-x,y);
        adauga(-y,x);
    }
    for (i=1;i<=n;i++)
    {
        if (viz[i]==0)
        {
            dfs(i);
        }
    }
    nr=0;
    memset(viz,0,sizeof(viz));
    for (i=q;i>=1;i--)
    {
        if (viz[sal[i]]==0)
        {
            nr++;
            dfs2(sal[i]);
        }
    }
    for (i=1;i<=nr;i++)
    {
        for (int j=0;j<comp[i].size();j++)
        {
            grupa[comp[i][j]]=i;
        }
    }
    for (i=1;i<=n;i++)
    {
        if (grupa[i]==grupa[i+n])
        {
            g<<"-1";
            return 0;
        }
    }
    for (i=1;i<=2*n;i++)
    {
        for (j=0;j<comp[grupa[i]].size();j++)
        {
            int nod=comp[grupa[i]][j];
            if (grupa[nod]!=grupa[i])
            {
                nrintr[grupa[nod]]++;
            }
        }
    }
    queue <int> coada;
    for (i=1;i<=q;i++)
    {
        if (nrintr[i]==0)
        {
            coada.push(i);
        }
    }
    while (!coada.empty())
    {
        int acum=coada.front();
        coada.pop();
        for (j=0;j<comp[acum].size();j++)
        {
            int nod=comp[acum][j];
            if (nod<=n)
            {
                val[nod]=0;
            }
            else
            {
                val[nod-n]=1;
            }
        }
        for (j=0;j<comp[acum].size();j++)
        {
            int nod=comp[acum][j];
            for (i=0;i<v[nod].size();i++)
            {
                int nod2=v[nod][i];
                if (grupa[nod]!=grupa[nod2])
                {
                    nrintr[grupa[nod2]]--;
                    if (nrintr[grupa[nod2]]==0)
                    {
                        coada.push(grupa[nod2]);
                    }
                }
            }
        }
    }
    for (i=1;i<=n;i++)
    {
        g<<val[i]<<" ";
    }
    return 0;
}
