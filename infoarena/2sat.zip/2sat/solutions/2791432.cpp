#include <bits/stdc++.h>
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
const int NMAX = 100005;
int n,m,x,y,rasp[2*NMAX],low[2*NMAX],nivel[2*NMAX],k;
bool ver[2*NMAX],NU_EXISTA;
vector <int> v[2*NMAX];
stack <int> q;
set <int> s;
int opus(int node){
    if(node<0) return -node;
    if(node<NMAX) return node+NMAX;
    return node-NMAX;
}
void dfs(int node){
    q.push(node);
    ver[node]=true;
    low[node]=nivel[node]=++k;
    for(int i=0;i<v[node].size();i++){
        int vecin=v[node][i];
        if(nivel[vecin]==0){
            dfs(vecin);
            if(low[vecin]<low[node])
                low[node]=low[vecin];
        } else if(ver[vecin]!=0){
            if(nivel[vecin]<low[node])
                low[node]=nivel[vecin];
        }
    }
    if(nivel[node]==low[node]){
        s.clear();
        int n2=0;
        while(n2!=node){
            n2=q.top();
            q.pop();
            ver[n2]=false;
            if(s.find(opus(n2))!=s.end())
                NU_EXISTA = true;
            s.insert(n2);
            if(rasp[n2]==0){
                rasp[n2]=1;
                rasp[opus(n2)]=-1;
            }
        }
    }
}
void citire(){
    fin >> n >> m;
    for(int i=1;i<=m;i++){
        fin >> x >> y;
        if(x<0 and y<0){
            v[-x].push_back(NMAX-y);
            v[-y].push_back(NMAX-x);
        } else if(x<0 and y>0){
            v[-x].push_back(y);
            v[y+NMAX].push_back(NMAX-x);
        } else if(x>0 and y<0){
            v[-y].push_back(x);
            v[x+NMAX].push_back(NMAX-y);
        } else if(x>0 and y>0){
            v[x+NMAX].push_back(y);
            v[y+NMAX].push_back(x);
        }
    }
}
void solve(){
    for(int i=1;i<=n;i++){
        if(nivel[i]==0) dfs(i);
    }
    for(int i=1;i<=n;i++){
        if(nivel[i+NMAX]==0) dfs(i+NMAX);
    }
}
void afis(){
    if(NU_EXISTA==true){
        fout << -1;
        return;
    }
    for(int i=1;i<=n;i++)
        fout << max(0,rasp[i]) << ' ';
}
int main()
{
    citire();
    solve();
    afis();
    return 0;
}
