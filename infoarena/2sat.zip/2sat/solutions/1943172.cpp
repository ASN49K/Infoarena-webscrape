#include <cstdio>
#include <algorithm>
#include <vector>
#include <stack>

using namespace std;

vector <int> g[200010], rev[200010], con[200010], rcon[200010];
int ap[200010], val[200010], neg[200010];
int k = 0;
stack <int> st;

#define g (g+100005)
#define rev (rev+100005)
#define ap (ap+100005)

void dfs (int nod)
{
    ap[nod] = 1;
    for (auto &it : g[nod])
        if (!ap[it]) dfs (it);

    st.push (nod);
}

void dfs2 (int nod)
{
    ap[nod] = k;
    for (auto &it : rev[nod])
        if (!ap[it]) dfs2 (it);
}

int main ()
{
    freopen ("2sat.in", "r", stdin);
    freopen ("2sat.out", "w", stdout);

    int n, m;
    scanf ("%d %d", &n, &m);

    for (int i = 1; i <= m; ++i)
    {
        int x, y;
        scanf ("%d %d", &x, &y);

        g[-x].push_back (y);
        g[-y].push_back (x);

        rev[x].push_back (-y);
        rev[y].push_back (-x);
    }

    for (int i = -n; i <= n; ++i)
        if (i != 0 && !ap[i])
            dfs (i);

    for (int i = -n; i <= n; ++i)
        ap[i] = 0;

    for (; !st.empty ();)
    {
        int x = st.top ();
        st.pop ();

        if (ap[x]) continue;
        ++k;

        dfs2 (x);
    }

    for (int i = -n; i <= n; ++i)
    {
        if (i == 0) continue;
        neg[ap[i]] = ap[-i];

        if (ap[i] == ap[-i])
        {
            printf ("-1\n");
            return 0;
        }
    }

    for (int i = 1; i <= k; ++i)
        if (!val[i])
        {
            val[i] = -1;
            val[neg[i]] = 1;
        }

    for (int i = 1; i <= n; ++i)
        printf ("%d ", (val[ap[i]] == 1));

    printf ("\n");

    return 0;
}
