#include <fstream>
#include <vector>
#include <cstring>
using namespace std;

ifstream f("2sat.in");
ofstream g("2sat.out");

long n,i,j,c[200005],l[200005],sol[200005],nr,t,m,x,y;
vector<int>a[200005],b[200005],c2[200005];

long neg(long x)
{
    if (x<=n)
        return x+n;
    return x-n;
}

long norm(long x)
{
    if (x<0)
        x*=(-1);
    else
        x+=n;
    return x;
}

void dfs(long i)
{
    c[i]=1;
    for (int j=0;j<a[i].size();j++)
        if(c[a[i][j]]==0)
            dfs(a[i][j]);
    l[nr]=i;
    nr--;
}

void dfs2(long i,long t)
{
    c[i]=t;
    for (int j=0;j<b[i].size();j++)
        if (c[b[i][j]]==0)
            dfs2(b[i][j],t);
}


int main()
{
    f>>n>>m;
    for (i=1;i<=m;i++)
    {
        f>>x>>y;
        x=norm(x);
        y=norm(y);
        a[neg(x)].push_back(y);
        a[neg(y)].push_back(x);
        b[x].push_back(neg(y));
        b[y].push_back(neg(x));
    }

    nr=n*2;
    for (i=1;i<=n*2;i++)
    {
        if (c[i]==0)
            dfs(i);
    }

    memset(c,0,sizeof(c));
    t=1;
    for (i=1;i<=n*2;i++)
    {
        if (c[l[i]]==0)
        {
            dfs2(l[i],t);
            t++;
        }
    }

    for (i=1;i<=n;i++)
        if (c[i]==c[i+n])
        {
            g<<-1;
            return 0;
        }

    for (i=1;i<=n*2;i++)
        c2[c[i]].push_back(i);

    for (i=1;i<=n*2;i++)
        if (c2[i].size()>0 && sol[c2[i][0]]==0)
            for (j=0;j<c2[i].size();j++)
            {
                sol[c2[i][j]]=1;
                sol[neg(c2[i][j])]=2;
            }

    for (i=n+1;i<=n*2;i++)
    {
        if (sol[i]==0)
            sol[i]=1;
        g<<sol[i]-1<<' ';
    }

    return 0;
}
