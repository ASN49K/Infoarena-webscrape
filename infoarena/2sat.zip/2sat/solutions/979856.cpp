#include<stdio.h>
#include<vector>
#include<stack>
#define pb push_back
#define maxn 100005
using namespace std;

int n,m,nr,ok=1;
int lev[maxn<<1],low[maxn<<1],sol[maxn];
int v[maxn<<1],used[maxn];
vector <int> l[maxn<<1];
stack <int> s;

int neg(int x)
{
    if(x>n) x-=n;
    else x+=n;
    return x;
}

void read()
{
    int x,y;
    scanf("%d%d",&n,&m);
    for(int i=1;i<=m;i++)
    {
        scanf("%d%d",&x,&y);
        if(x<0) x=-x,x+=n;
        if(y<0) y=-y,y+=n;
        l[neg(x)].pb(y);
        l[neg(y)].pb(x);
    }
}

void search()
{
    int p;
    p=s.top(); if(p>n) p-=n;
    if(used[p]==nr) ok=0;
    used[p]=nr; p=s.top();
    v[p]=0;
    if(p<=n) sol[p]=1;
    s.pop();
}

void get_component(int k)
{
    int p=s.top(); nr++;
    if(p>n) p-=n;
    if(used[p])
    {
        while(s.top()!=k) s.pop();
        s.pop();
        return;
    }

    while(s.top()!=k) search();
    search();
}

void dfs(int k,int niv)
{
    s.push(k); v[k]=1; lev[k]=niv; low[k]=niv;
    for(unsigned int i=0;i<l[k].size();i++)
     if(!lev[l[k][i]])
     {
         dfs(l[k][i],niv+1);
         low[k]=min(low[k],low[l[k][i]]);
     }
     else
      if(v[l[k][i]]) low[k]=min(low[k],low[l[k][i]]);

    if(low[k]==niv && ok) get_component(k);
}

void solve()
{
    for(int i=1;i<=2*n;i++)
     if(!lev[i])
      dfs(i,1);
}

void print()
{
    for(int i=1;i<=n;i++)
     printf("%d ",sol[i]);
}

int main()
{
    freopen("2sat.in","r",stdin);
    freopen("2sat.out","w",stdout);

    read();
    solve();
    if(ok==0) printf("-1");
    else print();

    fclose(stdin);
    fclose(stdout);
    return 0;
}
