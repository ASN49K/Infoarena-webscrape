#include<stdio.h>
#include<stdlib.h>
#define N 200001
long n,m,a[N],b[N],i,*g[N],deg[N]={0},c[N]={0},s[N],ss,v[N],l[N],q[N],sq,j,k,r,nr,ind,p[N],*d[N],e[N],t,o,ok;

void tarjan(long i,long *nr,long *ind)
{long j,r;
s[++ss]=i;
if(v[i]==0)
      v[i]=1;
c[i]=(*ind);
l[i]=(*ind)++;
for(j=0;j<deg[i];j++)
if(!c[g[i][j]])
      {tarjan(g[i][j],nr,ind);
      if(l[i]>l[g[i][j]])
             l[i]=l[g[i][j]];}
else
      if(v[g[i][j]]==1&&l[i]>c[g[i][j]])
             l[i]=c[g[i][j]];
if(c[i]==l[i])
      {sq=0;
      while(ss)
             {r=s[ss--];
             if(r!=i&&v[r]==1)
                     q[++sq]=r,v[r]=2;
             else
                     break;}
      if(v[i]==1)
             q[++sq]=i,v[i]=2;
      if(sq>0)
             {(*nr)++;
             d[(*nr)]=(long*)malloc((sq+1)*sizeof(long));
             for(j=1;j<=sq;j++)
                     d[(*nr)][j]=q[j];
             e[(*nr)]=sq;}}}
int main()
{freopen("2sat.in","r",stdin);
freopen("2sat.out","w",stdout);
scanf("%ld%ld",&n,&m);
for(i=1;i<=m;i++)
       {scanf("%ld%ld",&a[i],&b[i]);
       if(a[i]<0)
              deg[n-a[i]]++;
       else
              deg[a[i]]++;
       if(b[i]<0)
              deg[n-b[i]]++;
       else
              deg[b[i]]++;}
for(j=1;j<=2*n;deg[j++]=0)
       {g[j]=(long*)malloc(deg[j]*sizeof(long));
       p[j]=N;
       c[j]=0;}
for(k=1;k<=m;k++)
       {if(a[k]<0)
              a[k]=n-a[k];
       if(b[k]<0)
              b[k]=n-b[k];
       if(a[k]>n)
             g[a[k]-n][deg[a[k]-n]++]=b[k];
       else
             g[n+a[k]][deg[n+a[k]]++]=b[k];
       if(b[k]>n)
             g[b[k]-n][deg[b[k]-n]++]=a[k];
       else
             g[n+b[k]][deg[n+b[k]]++]=a[k];}
nr=ind=ss=0;
for(i=1;i<=2*n;i++)
if(!c[i])
      tarjan(i,&nr,&ind);
for(i=nr;i>=1;i--)
      {for(k=e[i];k>=1;k--)
      if(p[d[i][k]]==N)
             {p[d[i][k]]=0;
             if(d[i][k]>n)
                     p[d[i][k]-n]=1;
             else
                     p[d[i][k]+n]=1;}}
ok=0;
for(i=1;i<=m;i++)
      {if(a[i]<0)
             a[i]=n-a[i];
      if(b[i]<0)
             b[i]=n-b[i];
      if(!p[a[i]]&&!p[b[i]])
             ok=1;}
if(ok==0)
      {for(i=1;i<=n;i++)
      if(p[i]==N)
             printf("0 ");
      else
             printf("%ld ",p[i]);}
else
      printf("-1");
fclose(stdin);
fclose(stdout);
return 0;}
