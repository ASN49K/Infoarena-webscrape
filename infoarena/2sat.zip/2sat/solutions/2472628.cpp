#include <fstream>
#include <vector>
#include <stack>
//#include <cstdio>

using namespace std;

const int MAXN = 1e6;
const int INF = 1e9;

vector<int> adj[MAXN+1];
int index[MAXN+1];
int lowlink[MAXN+1];
stack<int> s;
int INDEX = 1;

void processComponent(stack<int>);

void dfs(int u) {
    s.push(u);
    index[u] = INDEX;
    lowlink[u] = INDEX;
    for (int i=0; i<adj[u].size(); i++) {
        int v = adj[u][i];
        if (!index[v]) {
            INDEX++;
            dfs(v);
        }
        lowlink[u] = min(lowlink[u], lowlink[v]);
    }

    //printf("exiting node %d with index %d and lowlink %d\n", u,index[u],lowlink[u]);

    if (index[u] == lowlink[u]) {
        stack<int> SCC;
        while (s.size() && lowlink[s.top()] < index[s.top()]) {
            SCC.push(s.top());
            lowlink[s.top()] = INF;
            s.pop();
        }
        if (s.size()) {
            SCC.push(s.top());
            lowlink[s.top()] = INF;
            s.pop();
        }
        processComponent(SCC);
    }
}

int varscnt, clausecnt;
bool computed[MAXN+1];
bool value[MAXN+1];

int label(int var) {
    return var+varscnt;
}

int variable(int lab) {
    return lab-varscnt;
}

bool can = true;

void processComponent(stack<int>& SCC) {
    if (computed[SCC.top()]) {
        return;
    }
    //puts("");
    while (SCC.size()) {
        int v = SCC.top(), u = label(-variable(v));
        value[v] = true;
        value[u] = false;
        if (computed[u]) {
            can = false;
            return;
        }
        computed[u] = true;
        SCC.pop();
    }
    //ccout << '\n';
}

int main() {
    ifstream ccin("2sat.in");
    ofstream ccout("2sat.out");
    ccin >> varscnt >> clausecnt;

    for (int i=0; i<clausecnt; i++) {
        int var1, var2;
        ccin >> var1 >> var2;
        adj[label(-var1)].push_back(label(var2));
        adj[label(-var2)].push_back(label(var1));
    }

    int n = 2*varscnt;

    for (int v=0; v<=n && can; v++) {
        if (!index[v]) {
            dfs(v);
        }
    }

    if (!can) {
        ccout << -1 << '\n';
        return 0;
    }

    for (int v=0; v<=n; v++) {
        int var = variable(v);
        if (var > 0) {
            ccout << value[v] << ' ';
        }
    }
    ccout << '\n';

    ccin.close();
    ccout.close();
}
