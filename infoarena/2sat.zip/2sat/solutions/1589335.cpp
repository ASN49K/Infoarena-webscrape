#include <bits/stdc++.h>
#define Nmax 200005
#define pb push_back

using namespace std;

vector <int> L[Nmax],T[Nmax];
bool viz[Nmax],Bad,seen[Nmax];
int SortTopo[Nmax],p,ans[Nmax],n;

inline int non(int x)
{
    if(x>n) return x-n;
    return x+n;
}

inline void Dfs(int nod)
{
    viz[nod]=1;
    for(auto it : L[nod])
    {
        if(viz[it]) continue;
        Dfs(it);
    }
    SortTopo[++p]=nod;
}

inline void Solve(int nod)
{
    if(Bad) return;
    if(ans[nod])
    {
        Bad=1; return;
    }
    seen[nod]=1; ans[nod]=0; ans[non(nod)]=1;
    for(auto it : T[nod])
        if(!seen[it]) Solve(it);
}

int main()
{
    int m,x,y,i;
    ifstream cin("2sat.in");
    ofstream cout("2sat.out");
    cin>>n>>m;
    while(m--)
    {
        cin>>x>>y;
        if(x<0) x=n-x;
        if(y<0) y=n-y;
        L[non(x)].pb(y); L[non(y)].pb(x);
        T[y].pb(non(x)); T[x].pb(non(y));
    }
    for(i=1;i<=2*n;++i)
        if(!viz[i]) Dfs(i);

    for(i=2*n;i;--i)
    {
        if(!seen[SortTopo[i]] && !seen[non(SortTopo[i])]) Solve(SortTopo[i]);
        if(Bad)
        {
            cout<<"-1\n"; return 0;
        }
    }
    for(i=1;i<=n;++i) cout<<ans[i]<<" ";
    cout<<"\n";
    return 0;
}
