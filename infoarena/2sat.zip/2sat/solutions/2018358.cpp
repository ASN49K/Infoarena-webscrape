#include <iostream>
#include <fstream>
#include <stack>
#include <vector>
#include <deque>
#include <ctime>
#include <queue>

#define ll long long
#define ull unsigned long long
#define pb push_back
#define mp make_pair
using zint = int;
using namespace std;
const int inf = 3e4 + 5;
const int NMax = 1e5 + 5;
const int MMax = 2e5 + 5;
ifstream in("2sat.in");
ofstream out("2sat.out");

zint N,M,P;
zint sol[NMax],aux[NMax];
pair<zint,zint> ex[MMax];

struct elem {
    zint lit,nrE;
    elem (zint _lit = 0,zint _nrE = 0) {
        lit = _lit;
        nrE = _nrE;
    }
};
vector<elem> v[NMax];

bool test(zint,zint);
bool eval(zint);
void cpy(zint*,zint*);

int main() {
    in>>N>>M;
    for (int i=1;i <= M;++i) {
        zint x,y;
        in>>x>>y;
        ex[i] = mp(x,y);

        v[abs(x)].pb( elem(abs(y),i) );
        v[abs(y)].pb( elem(abs(x),i) );
    }

    for (int i=1;i <= N;++i) {
        sol[i] = -1;
    }

    bool ans = true;
    for (int i=1;i <= N;++i) {
        if (sol[i] != -1) {
            continue;
        }

        //cpy(aux,sol);
        bool ok = false;
        if (test(i,0)) {
            //sol[i] = 0;
            ok = true;
        }
        else if (test(i,1)) {
            //sol[i] = 1;
            ok = true;
        }

        if (ok) {
            cpy(sol,aux);
        }
        else {
            ans = false;
            break;
        }
    }

    if (ans) {
        for (int i=1;i <= N;++i) {
            out<<sol[i]<<' ';
        }

        /*
        cout<<"YE\n";
        for (int i=1;i <= M;++i) {
            if (!eval(i)) {
                cout<<"BAD\n";
                break;
            }
        }
        //*/
    }
    else {
        out<<"-1\n";
    }

    in.close();out.close();
    return 0;
}

bool test(zint idx,zint val) {
    cpy(aux,sol);
    //bool vis[NMax] = {};
    aux[idx] = val;

    queue<zint> Q;
    Q.push(idx);
    while (Q.size()) {
        zint lit = Q.front();
        Q.pop();

        for (elem el : v[lit]) {
            zint nxt = el.lit, nr = el.nrE;
            if (aux[nxt] != -1) {
                if ( !eval(nr) ) {
                    return false;
                }

                continue;
            }

            bool val0 = false, val1 = false;
            aux[nxt] = 0;
            if ( eval(nr) ) {
                val0 = true;
            }
            aux[nxt] = 1;
            if ( eval(nr) ) {
                val1 = true;
            }

            if (val0) {
                if (val1) {
                    aux[nxt] = -1;
                    continue;
                }
                aux[nxt] = 0;
            }
            else if (val1) {
                aux[nxt] = 1;
            }

            //vis[nxt] = true;
            Q.push(nxt);
        }
    }

    return true;
}

bool eval(zint nr) {
    zint x = ex[nr].first,
        y = ex[nr].second,
        val1 = aux[abs(x)],
        val2 = aux[abs(y)];
    if (x < 0) { val1 ^= 1; }
    if (y < 0) { val2 ^= 1; }

    return (val1 | val2);
}

void cpy(zint* a,zint* b) {
    for (int i=1;i <= N;++i) {
        a[i] = b[i];
    }
}
