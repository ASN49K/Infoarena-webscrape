#include <iostream>
#include <fstream>
#include <vector>
#include <string.h>
using namespace std;

#define NMAX 200001

vector <int> v[NMAX], vt[NMAX], ctc[NMAX];
int viz[NMAX], p[NMAX], nc, poz[NMAX], value[NMAX];

inline int NOT(int nod, int n) {
    if (nod < 0)
        return -nod;
    if (nod <= n)
        return nod + n;
    return nod - n;
}

void dfs(int nod) {
    viz[nod] = 1;
    for (vector <int> :: iterator it = v[nod].begin(); it != v[nod].end(); it++) {
        if (viz[*it] == 0)
            dfs(*it);
    }
    p[++p[0]] = nod;
}

void dfst(int nod) {
    viz[nod] = 1;
    ctc[nc].push_back(nod);
    poz[nod] = nc;
    for (vector <int> :: iterator it = vt[nod].begin(); it != vt[nod].end(); it++) {
        if (viz[*it] == 0)
            dfst(*it);
    }
}

int main () {
    int n, m, x, y, i;
    ifstream f("2sat.in");
    ofstream g("2sat.out");
    f >> n >> m;
    for (i = 1; i <= m; i++) {
        f >> x >> y;
        cout << NOT(x, n) << " " << NOT(NOT(y, n), n) << '\n';
        v[NOT(x, n)].push_back(NOT(NOT(y, n), n));
        v[NOT(y, n)].push_back(NOT(NOT(x, n), n));
        vt[NOT(NOT(y, n), n)].push_back(NOT(x, n));
        vt[NOT(NOT(x, n), n)].push_back(NOT(y, n));
    }
    for (i = 1; i <= 2 * n; i++) {
        if (viz[i] == 0)
            dfs(i);
    }
    memset(viz, 0, sizeof(viz));
    for (i = 2 * n; i >= 1; i--) {
        if (viz[p[i]] == 0) {
            nc++;
            dfst(p[i]);
        }
    }
    for (i = 1; i <= n; i++)
        if (poz[i] == poz[i + n])
            break;
    if (i <= n) {
        g << "-1\n";
        g.close();
        return 0;
    }
    memset(viz, 0, sizeof(viz));
    for (i = 1; i <= nc; i++) {
        if (viz[poz[*ctc[i].begin()]])
            continue;
        for (vector <int> :: iterator it = ctc[i].begin(); it != ctc[i].end(); it++) {
            if (*it > n)
                value[*it - n] = 1;
            else
                value[*it] = 0;
            viz[i] = 1;
            viz[poz[NOT(*it, n)]] = 1;
        }
    }
    for (i = 1; i <= n; i++) {
        g << value[i] << ' ';
    }
    g.close();
    return 0;
}
