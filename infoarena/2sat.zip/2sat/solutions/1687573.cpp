#include <bits/stdc++.h>

using namespace std;

const int MAX_N = 100000;
const int MAX_M = 200000;
const int NIL = -1;
const int BUFFSIZE = 582257;

char buf[BUFFSIZE];
int pos = BUFFSIZE;

inline char getChar() {
    if (pos == BUFFSIZE) {
        assert(fread(buf, 1, BUFFSIZE, stdin));
        pos = 0;
    }
    return buf[pos++];
}

inline int readInt() {
    int q = 0;
    char c; bool sign = 0;
    do {
        c = getChar();
        sign |= (c == '-');
    } while (!isdigit(c));
    do {
        q = (q << 1) + (q << 3) + (c - '0');
        c = getChar();
    } while (isdigit(c));
    return (q ^ ((q ^ -q) & -sign));
}

struct List {
    int v;
    int next;
};

List buff[2 * MAX_M];
int head[2 * MAX_N];

bool onStack[2 * MAX_N];
int st[2 * MAX_N], vf;
int ptr[2 * MAX_N], freePtr;

List CTC[2 * MAX_N];
int ctcHead[2 * MAX_N];
int numCTC, ctcPtr;

bool attribute[2 * MAX_N];

void addArc(int u, int v, int pos) {
    buff[pos].v = v;
    buff[pos].next = head[u];
    head[u] = pos;
}

int tarjan(int u) {
    onStack[u] = true;
    st[vf++] = u;
    int minPtr = ptr[u] = freePtr++;

    for (int i = head[u]; i != NIL; i = buff[i].next) {
        int v = buff[i].v;
        if (ptr[v] == NIL) {
            minPtr = min(minPtr, tarjan(v));
        } else if (onStack[v]) {
            minPtr = min(minPtr, ptr[v]);
        }
    }

    if (ptr[u] == minPtr) {
        int v;
        ctcHead[numCTC] = NIL;
        do {
            v = st[--vf];
            onStack[v] = false;
            CTC[ctcPtr].v = v;
            CTC[ctcPtr].next = ctcHead[numCTC];
            ctcHead[numCTC] = ctcPtr++;
        } while (v != u);
        ++ numCTC;
    }
    return minPtr;
}

int main() {
    assert(freopen("2sat.in", "r", stdin));
    assert(freopen("2sat.out", "w", stdout));

    int n = readInt(), m = readInt();

    memset(head, NIL, 4 * 2 * n);
    memset(ptr, NIL, 4 * 2 * n);

    for (int i = 0; i < m; ++ i) {
        int u = readInt(), v = readInt();
        u = ((u ^ ((u ^ -u) & -(u < 0))) << 1) - 1 - (u > 0);
        v = ((v ^ ((v ^ -v) & -(v < 0))) << 1) - 1 - (v > 0);
        addArc(u ^ 1, v, 2 * i);
        addArc(v ^ 1, u, 2 * i + 1);
    }
    fclose(stdin);

    for (int i = 0; i < (n << 1); ++ i) {
        if (ptr[i] == NIL) {
            tarjan(i);
        }
    }

    for (int i = numCTC - 1; i >= 0; -- i)
        if (!attribute[CTC[ctcHead[i]].v])
            for (int j = ctcHead[i]; j != NIL; j = CTC[j].next)
                attribute[CTC[j].v ^ 1] = 1;

    int i = 0;
    while (i < n && (attribute[i << 1] != attribute[(i << 1) | 1])) {
        ++ i;
    }
    if (i != n) {
        puts("-1");
    } else {
        for (int i = 0; i < n; ++ i) {
            putchar(attribute[i << 1] + '0');
            putchar(' ');
        }
        putchar('\n');
    }
    fclose(stdout);

    return 0;
}
