#include <fstream>
#include <vector>
#include <stack>

using namespace std;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

const int NMAX = 200005;

vector<int> G[NMAX], GT[NMAX];
int comp[NMAX];
bool viz[NMAX];
stack<int> st;
int n, m, ctc;

int neg(int x) {
    if (x <= n) {
        return x + n;
    }
    else return x - n;
}

void dfs(int nod) {
    viz[nod] = true;
    for(int vecin : G[nod]) {
        if(!viz[vecin]) {
            dfs(vecin);
        }
    }
    st.push(nod);
}

void dfsT(int nod) {
    comp[nod] = ctc;
    for(int vecin : GT[nod]) {
        if(comp[vecin] == 0) {
            dfsT(vecin);
        }
    }
}

void kosaraju() {
    for(int i = 1; i <= 2 * n; ++i) {
        if(!viz[i]) {
            dfs(i);
        }
    }

    while(!st.empty()) {
        int nod = st.top();
        st.pop();
        if (comp[nod] == 0) {
            ctc++;
            dfsT(nod);
        }
    }
}

int main() {
    fin >> n >> m;
    for (int i = 1; i <= m; ++i) {
        int u, v;
        fin >> u >> v;

        int nod1, nod2;
        
        if(u > 0) {
            nod1 = u;
        } else {
            nod1 = abs(u) + n;
        }

        if(v > 0) {
            nod2 = v;
        } else {
            nod2 = abs(v) + n;
        }

        G[neg(nod1)].push_back(nod2);
        G[neg(nod2)].push_back(nod1);

        GT[nod2].push_back(neg(nod1));
        GT[nod1].push_back(neg(nod2));
    }

    kosaraju();

    for(int i = 1; i <= n; ++i) {
        if(comp[i] == comp[i + n]) {
            fout << "-1\n";
            return 0;
        }
    }

    for(int i = 1; i <= n; ++i) {
        if(comp[i] > comp[i + n]) {
            fout << "1 ";
        } else {
            fout << "0 ";
        }
    }
    fout << "\n";

    return 0;
}