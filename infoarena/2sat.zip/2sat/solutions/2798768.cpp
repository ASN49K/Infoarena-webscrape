#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <cstring>

using namespace std;

ifstream in("2sat.in");
ofstream out("2sat.out");

const int N_MAX = 200005;

int n, m, ctc;
bool fr[N_MAX], value[N_MAX];
stack<int> s;
vector<int> adj[N_MAX], tAdj[N_MAX], comp(N_MAX, -1);

void dfs(int node)
{
    fr[node] = 1;
    for(auto it: adj[node])
        if(!fr[it])
            dfs(it);
    s.push(node);
}

void tDfs(int node)
{
    fr[node] = 1;
    comp[node] = ctc;
    for(auto it: tAdj[node])
        if(!fr[it])
            tDfs(it);
}

bool solve()
{
    for(int i = 1; i <= n; i++)
        if(!fr[i])
            dfs(i);

    memset(fr, 0, sizeof fr);
    while(!s.empty())
    {
        int node = s.top();
        s.pop();
        if(!fr[node])
        {
            ctc++;
            tDfs(node);
        }
    }

    for(int i = 2; i <= n; i += 2)
    {
        if(comp[i] == comp[i + 1])
            return 0;
        value[i / 2] = (comp[i + 1] < comp[i]);
    }
    return 1;
}

int main()
{
    in >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y, pX, nX, pY, nY;
        in >> x >> y;
        pX = 2 * abs(x);
        nX = 2 * abs(x) + 1;
        if(x < 0)
            swap(nX, pX);
        pY = 2 * abs(y);
        nY = 2 * abs(y) + 1;
        if(y < 0)
            swap(nY, pY);
        adj[nX].push_back(pY);
        adj[nY].push_back(pX);
        tAdj[pY].push_back(nX);
        tAdj[pX].push_back(nY);
    }
    n = 2 * n + 1;

    bool ok = solve();
    if(ok == 0)
        out << "-1\n";
    else
    {
        for(int i = 1; i <= (n - 1) / 2; i++)
            out << value[i] << ' ';
        out << '\n';
    }

    return 0;
}
