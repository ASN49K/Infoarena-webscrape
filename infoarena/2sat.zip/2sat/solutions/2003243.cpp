#include <bits/stdc++.h>
#define Nmax (int)2e5+5
using namespace std;
ifstream f("2sat.in");
ofstream g("2sat.out");
list <int> G[Nmax];
list <int> Gt[Nmax];
#define G (G+100001)
#define Gt (Gt+100001)
bool viz[Nmax];
#define viz (viz+100001)
int ord[Nmax];
int N;
int nn;
list <int> comp[Nmax];
bool value[Nmax];
#define value (value+100001)
void DFS(const int &x)
{
    list <int> :: iterator it;
    viz[x]=true;
    for(it=G[x].begin();it!=G[x].end();it++)
        if(!viz[*it]) DFS(*it);
    ord[++N]=x;
}
void DFFS(const int &x)
{
    list <int> :: iterator it;
    viz[x]=true;
    comp[nn].push_back(x);
    for(it=Gt[x].begin();it!=Gt[x].end();it++)
        if(!viz[*it]) DFFS(*it);
}
int main()
{
    int n,m,i,j,k;
    f>>n>>m;
    for(k=1;k<=m;k++)
    {
        f>>i>>j;
        G[-i].push_back(j);
        Gt[j].push_back(-i);
        G[-j].push_back(i);
        Gt[i].push_back(-j);
    }
    for(i=-n;i;i++)
        if(!viz[i]) DFS(i);
    for(i=1;i<=n;i++)
        if(!viz[i]) DFS(i);
    for(i=-n;i<=n;i++)
        viz[i]=false;
    for(i=N;i;i--)
        if(!viz[ord[i]])
        {
            ++nn;
            DFFS(ord[i]);
        }
    for(i=-n;i<=n;i++)
            viz[i]=false;
    int p=1,q=nn;
    list <int> :: iterator it;
    while(p<q)
    {
        for(it=comp[p].begin();it!=comp[p].end();it++)
        {
            if(viz[*it])
            {
                if(value[*it])
                {
                    g<<-1;
                    return 0;
                }
            }
            else
            {
                viz[*it]=true;
                viz[-*it]=true;
                value[*it]=false;
                value[-*it]=true;
            }
        }
        for(it=comp[q].begin();it!=comp[q].end();it++)
        {
            if(viz[*it])
            {
                if(!value[*it])
                {
                    g<<-1;
                    return 0;
                }
            }
            else
            {
                viz[*it]=true;
                viz[-*it]=true;
                value[*it]=true;
                value[-*it]=false;
            }
        }
        p++;
        q--;
    }
    for(i=1;i<=n;i++)
        g<<value[i]<<' ';

    return 0;
}
