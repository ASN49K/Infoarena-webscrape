#include<fstream>
#include<vector>
using namespace std;
ifstream fin("2sat.in");
ofstream fout("2sat.out");
int n,m,okSol=1,sol[200001],viz[200001],parc[200001],k;
vector<int> v[200001],t[200001];
inline int non(int x)
{
    return (x>n)?(x-n):x+n;
}
inline int ind(int x)
{
    return (x>0)?x:n-x;
}
void citire()
{
    int x,y;
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        v[non(ind(x))].push_back(ind(y));
        v[non(ind(y))].push_back(ind(x));
        t[ind(y)].push_back(non(ind(x)));
        t[ind(x)].push_back(non(ind(y)));
    }
}

void df(int nod)
{
    viz[nod]=1;
    for(int i=0;i<v[nod].size();i++)
    {
        if(!viz[v[nod][i]])
            df(v[nod][i]);
    }
    parc[++k]=nod;
}

void dft(int nod)
{
    viz[nod]=0;
    if(sol[nod]==1){
        okSol=0;
        return;
    }
    sol[non(nod)]=1;
    for(int i=0;i<t[nod].size();i++)
    {
        if(viz[t[nod][i]]==1)
            dft(t[nod][i]);
    }

}

void _2sat()
{
    for(int i=1;i<=2*n;i++)
    {
        if(!viz[i])
            df(i);
    }
    for(int i=k;i>0;i--)
    {
        if(viz[parc[i]]==1 && viz[non(parc[i])]==1)
            dft(parc[i]);
    }

}

int main()
{
    citire();
    _2sat();
    if(!okSol)
    {
        fout<<-1;
        return 0;
    }
    for(int i=1;i<=n;i++)
        fout<<sol[i]<<" ";
    return 0;
}
