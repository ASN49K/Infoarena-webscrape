#include <cstdio>
#include <cstring>
#include <vector>

using namespace std;

const int maxN = 200100;

int N, M;
vector <int> G[maxN], GT[maxN];
int st[maxN], vf;
int viz[maxN], value[maxN];
bool okSol;

inline int neg(int x) {
	int y = x + N;
	if (y > 2 * N)
		y -= 2 * N;
	return y;
}

inline void dfs(int nod) {
	int i, fiu;
	if (viz[nod])
		return;
	viz[nod] = 1;

	for (i = 0; i < G[nod].size(); i++) {
		fiu = G[nod][i];
		if (!viz[fiu])
			dfs(fiu);
	}

	st[++vf] = nod;
//	fprintf(stderr, "%d\n", nod);
}

inline void dfsGT(int nod) {
	int i, fiu;
	viz[nod] = 1;
	if (value[nod]) 
		okSol = false;

	value[nod] = 0; value[neg(nod)] = 1;

	for (i = 0; i < GT[nod].size(); i++) {
		fiu = GT[nod][i];
		if (!viz[fiu])
			dfsGT(fiu);
	}
}

int main() {
	int i, a, b;
	freopen("2sat.in", "r", stdin);
	freopen("2sat.out", "w", stdout);

	scanf("%d%d", &N, &M);
	for (i = 1; i <= M; i++) {
		scanf("%d%d", &a, &b);
		if (a < 0)	a = (-a) + N;
		if (b < 0)	b = (-b) + N;

//		fprintf(stderr, "%d %d\n", neg(a), b);
//		fprintf(stderr, "%d %d\n", neg(b), a);

		G[neg(a)].push_back(b);
		G[neg(b)].push_back(a);

		GT[a].push_back(neg(b));
		GT[b].push_back(neg(a));
	}

	for (i = 1; i <= 2 * N; i++) 
		if (!viz[i])
			dfs(i);
	
	okSol = 1;
	memset(viz, 0, sizeof(viz));
	for (i = vf; i > 0; i--) {
	//	fprintf(stderr, "%d\n", st[i]);
		if (!viz[st[i]] && !viz[neg(st[i])])
			dfsGT(st[i]);
	}

	if (okSol) {
		for (i = 1; i <= N; i++)
			printf("%d ", value[i]);
	}
	else
		printf("-1\n");

	return 0;
}
