#include <cstring>
#include <fstream>
#include <vector>

using namespace std;

int N, M;
vector<int> V[2][200002];
int T[200002], F[200002];
bool S[200002], impossible;

inline int inv(int x)
{
	if (x > N) return x - N;
	return x + N;
}

void Dfs1(int x)
{
	S[x] = true;
	for (vector<int>::iterator it = V[0][x].begin(); it != V[0][x].end(); ++it)
		if (!S[*it])
			Dfs1(*it);
	T[++T[0]] = x;
}
void Dfs2(int x)
{
	if (F[x])
		impossible = true;
	
	S[x] = true;
	F[x] = 0, F[inv(x)] = 1;
	for (vector<int>::iterator it = V[1][x].begin(); it != V[1][x].end(); ++it)
		if (!S[*it])
			Dfs2(*it);
}

int main()
{
	ifstream fin("2sat.in");
	ofstream fout("2sat.out");
	
	fin >> N >> M;
	for (int i = 1, nod1, nod2; i <= M; ++i)
	{
		fin >> nod1 >> nod2;
		nod1 = (nod1 < 0 ? N - nod1 : nod1);
		nod2 = (nod2 < 0 ? N - nod2 : nod2);
		
		V[0][inv(nod1)].push_back(nod2);
		V[0][inv(nod2)].push_back(nod1);
		V[1][nod1].push_back(inv(nod2));
		V[1][nod2].push_back(inv(nod1));
	}
	
	for (int i = 1; i <= 2 * N; ++i)
		if (!S[i])
			Dfs1(i);
	memset(S, 0, sizeof(S));
	for (int i = 2 * N; i >= 1; ++i)
		if (!S[T[i]] && !S[inv(T[i])])
			Dfs2(T[i]);
	
	if (impossible) fout << "-1\n";
	else
	{
		for (int i = 1; i <= N; ++i)
			fout << F[i] << ' ';
		fout << '\n';
	}
	
	fin.close();
	fout.close();
}
