#include <bits/stdc++.h>
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("2sat.in" , "r" , stdin) , freopen("2sat.out" , "w" , stdout)
#define pb push_back

using namespace std;

const int N = 1e5 + 10;

int n , m , x , y;
vector < int > G[2 * N] , g[2 * N] , ctc[2 * N];
stack < int > s;
int used[2 * N];
int ct[2 * N];
int deg[2 * N];
int val[2 * N];

void dfs(int nod)
{
    used[nod] = 1;

    for(auto i : G[nod])
        if(!used[i])
            dfs(i);

    s.push(nod);
}

int cnt;

void dfs2(int nod)
{
    used[nod] = 2;
    ct[nod] = cnt;
    ctc[cnt].pb(nod);

    for(auto i : g[nod])
        if(used[i] == 1)
            dfs2(i);
}

void CTC()
{
    for(int i = 0 ; i <= 2 * n ; i++)
        if(i != n && !used[i])
            dfs(i);

    while(!s.empty())
    {
        int nod = s.top();
        s.pop();

        if(used[nod] == 1)
            ++cnt , dfs2(nod);
    }
}

void check_impossible()
{
    for(int i = 0 ; i <= 2 * n ; i++)
        if(ct[i] == ct[2 * n - i] && ct[i])
        {
            cout << -1;
            exit(0);
        }
}

void solve()
{
    queue < int > q;
    int i;

    for(i = 1 ; i <= cnt ; i++)
        for(auto j : ctc[i])
            for(auto vec : g[j])
                if(ct[vec] != i)
                    ++deg[i];

    for(i = 1 ; i <= cnt ; i++)
        if(deg[i] == 0)
            q.push(i);

    fill(val + 1 , val + 2 * n + 1 , -1);

    while(!q.empty())
    {
        int comp = q.front();
        q.pop();

        x = 0;

        for(auto i : ctc[comp])
        {
            if(val[i] != -1)
                x = val[i];

            for(auto j : G[i])
                if(comp != ct[j])
                    if( --deg[ ct[j] ] == 0)
                        q.push(ct[j]);
        }

        for(auto i : ctc[comp])
        {
            val[i] = x;
            val[2 * n - i] = 1 - x;
        }
    }
}

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

    int i;

    cin >> n >> m;

    for(i = 1 ; i <= m ; i++)
    {
        cin >> x >> y;

        G[-x + n].pb(y + n);
        G[-y + n].pb(x + n);

        g[y + n].pb(-x + n);
        g[x + n].pb(-y + n);
    }

    CTC();
    check_impossible();
    solve();

    for(i = n + 1 ; i <= 2 * n ; i++)
        cout << val[i] << ' ';

    return 0;
}
