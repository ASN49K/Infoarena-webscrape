#include <bits/stdc++.h>

using namespace std;

ifstream fin ("2sat.in");
ofstream fout ("2sat.out");

const int N = 100005;
int n, m;
vector <int> Graph[2 * N], invGraph[2 * N], nodesInComp[2 * N];
vector <int> topSort;
int comp[2 * N], compCount, ans[2 * N], visited[2 * N];
bool hasSolution;

void DFS1(int node)
{
    visited[node] = 1;
    for (int nextNode : Graph[node])
        if (!visited[nextNode])
            DFS1(nextNode);
    
    topSort.push_back(node);
}

void DFS2(int node)
{
    comp[node] = compCount;
    for (int nextNode : invGraph[node])
        if (!comp[nextNode])
            DFS2(nextNode);
}

void DFS3(int node, int value)
{
    visited[node] = value;
    for (int nextNode : invGraph[node])
        if (visited[nextNode] == -1)
            DFS3(nextNode, value);
}

void Kosaraju()
{
    for (int i = 0; i <= 2 * n; i++)
    {
        if (!visited[i] && i != n)
            DFS1(i);
    }

    for (int i = topSort.size() - 1; i >= 0; i--)
    {
        int node = topSort[i];
        if (!comp[node])
        {
            compCount++;
            DFS2(node);
        }
    }
}

void getSolution()
{
    hasSolution = true;
    for (int i = 1; i <= n; i++)
    {
        if (comp[i + n] == comp[-i + n])
        {
            hasSolution = false;
            return;
        }

        visited[i + n] = visited[-i + n] = -1;
        nodesInComp[comp[i + n]].push_back(i + n);
        nodesInComp[comp[-i + n]].push_back(-i + n);
    }

    for (int i = topSort.size() - 1; i >= 0; i--)
    {
        int node = topSort[i];
        if (visited[node] == -1)
        {
            DFS3(node, 0);
            for (int pairNode : nodesInComp[comp[2 * n - node]])
                visited[pairNode] = 1;
        }
    }
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int node1, node2;
        fin >> node1 >> node2;
        Graph[-node1 + n].push_back(node2 + n);
        Graph[-node2 + n].push_back(node1 + n);

        invGraph[node2 + n].push_back(-node1 + n);
        invGraph[node1 + n].push_back(-node2 + n); 
    }

    Kosaraju();
    getSolution();

    if (!hasSolution)
    {
        fout << -1;
        return 0;
    }
    for (int i = 1; i <= n; i++)
        fout << visited[i + n] << " ";
    return 0;
}