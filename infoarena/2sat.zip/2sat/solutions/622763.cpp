#include <cstdio>
#include <cstring>
#include <vector>

using namespace std;

int n,ok=1,cnt,u[200001],sol[200001],ord[200001];
vector<int> g[200001],gt[200001];

inline int neg(int x){if (x>n) return x-n;else return x+n;}

void dfs(int x)
{
	vector <int>::iterator it;
	u[x]=1;
	for (it=g[x].begin();it!=g[x].end();++it)
		 if (!u[*it])
			 dfs(*it);
	ord[++cnt]=x;
}

void dfst(int x)
{
	vector <int>::iterator it;
	u[x]=1;
	if (sol[x])
        ok=0;
	sol[neg(x)]=1;
	for (it=gt[x].begin();it!=gt[x].end();++it)
		 if (!u[*it])
			 dfst(*it);
}

int main()
{
    int i,a,b,m;
    freopen("2sat.in","r",stdin);
    freopen("2sat.out","w",stdout);
    scanf("%d %d",&n,&m);
    for (;m;--m)
    {
        scanf("%d %d",&a,&b);
        if (a<0)
            a=n-a;
        if (b<0)
            b=n-b;
        g[neg(a)].push_back(b);
        gt[a].push_back(neg(b));
        g[neg(b)].push_back(a);
        gt[b].push_back(neg(a));
    }
    for (ok=1,i=1;i<=2*n;++i)
          if (!u[i])
             dfs(i);
    memset(u,0,sizeof(u));
    for (i=2*n;i;--i)
         if (!u[ord[i]]&&!u[neg(ord[i])])
             dfst(ord[i]);
    if (!ok)
      printf("-1\n");
    else
    {
        for (i=1;i<=n;++i)
            printf("%d ",sol[i]);
        printf("\n");
    }
    return 0;
}
