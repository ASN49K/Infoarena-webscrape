#include <bits/stdc++.h>

using namespace std;

ifstream fin("2sat.in");
ofstream fout("2sat.out");

const int MMAX = 1e5;

int n, m;
vector<int> adj[2 * MMAX + 1];
vector<int> adjT[2 * MMAX + 1];

int noty(int u) {
	if(u <= m) {
		return u + m;
	}
	return u - m;
}

bool vis[2 * MMAX + 1];
vector<int> kosa;
void dfs(int u) {
	vis[u] = 1;
	for(const auto &it: adj[u]) if(!vis[it]) {
		dfs(it);
	}
	kosa.emplace_back(u);
}

int ctc;
int comp[2 * MMAX + 1];
void dfsT(int u) {
	vis[u] = 1;
	comp[u] = ctc;
	for(const auto &it: adjT[u]) if(!vis[it]) {
		dfsT(it);
	}
}

void addImplication(int u, int v) {
	adj[u].emplace_back(v);
	adjT[v].emplace_back(u);
}

int main() {
	ios_base :: sync_with_stdio(false); fin.tie(nullptr);

	fin >> m >> n;

	for(int i = 1; i <= n; i++) {
		int u, v;
		fin >> u >> v;
		
		if(u < 0) {
			u = -u;
			u += m;
		}
		if(v < 0) {
			v = -v;
			v += m;
		}

		addImplication(noty(u), v);
		addImplication(noty(v), u);
	}

	for(int i = 1; i <= 2 * m; i++) if(!vis[i]) {
		dfs(i);
	}

	reverse(kosa.begin(), kosa.end());
	memset(vis, 0, sizeof(vis));

	for(const auto &it: kosa) if(!vis[it]) {
		ctc++;
		dfsT(it);
	}

	int i = 1;
	while(i <= m && comp[i] != comp[i + m]) {
		i++;
	}

	if(i <= m) {
		fout << "-1\n";
	} else {
		for(int i = 1; i <= m; i++) {
			fout << (comp[i] > comp[i + m]) << " ";
		}
		fout << '\n';
	}
	return 0;
}