#include <bits/stdc++.h>

using namespace std;

ifstream in("2sat.in");
ofstream out("2sat.out");
const int NMAX = 200005;
vector<int> v[NMAX],vt[NMAX];
bool contr;
int viz[NMAX];
int nr,n;
stack<int> st;
int negat(int x)
{
    if (x<=n)
        return x+n;
    else
        return x-n;
}
void add(int x,int y)
{
    v[x].push_back(y);
    vt[y].push_back(x);
}
void dfp(int x)
{
    viz[x] = 1;
    for (auto it: v[x])
        if (!viz[it])
            dfp(it);
    st.push(x);
}
void dfm(int x)
{
    viz[x] = nr;
    for (auto it: vt[x])
        if (!viz[it])
            dfm(it);
}

int main()
{
    int m;
    in >> n >> m;
    for (int i = 1; i<=m; i++)
    {
        int x,y;
        in >> x >> y;
        if (x<0)
            x = n-x;
        if (y<0)
            y = n-y;
        add(negat(x),y);
        add(negat(y),x);
    }
    for (int i = 1; i<=2*n; i++)
        if (!viz[i])
            dfp(i);
    memset(viz,0,sizeof(viz));
    while (!st.empty())
    {
        int now = st.top();
        if (!viz[now])
        {
            nr++;
            dfm(now);
        }
        st.pop();
    }
    for (int i = 1; i<=n; i++)
        if (viz[i] == viz[i+n])
            contr = 1;
    if (contr)
        out << "-1";
    else
    {
        for (int i = 1; i<=n; i++)
            if (viz[i]<viz[i+n])
                out << "0 ";
            else
                out << "1 ";
    }
}
