#include<stdio.h>
#include<vector.h>
#define pb push_back
#define N 200001
long n,m,i,a[N],b[N],j,p[N],w[N],c[N],nr,r,l,d[N],v[N],k;
vector<long> f[N],g[N];

void dfs(long x)
{long i;
c[x]=1;
for(i=0;i<f[x].size();i++)
if(!c[f[x][i]])
       dfs(f[x][i]);
w[++nr]=x;}

void dfst(long x)
{long i;
c[x]=0;
if(p[x]==2)
       {p[x]=0;
       if(x>n)
               p[x-n]=1;
       else
               p[x+n]=1;}
for(i=0;i<g[x].size();i++)
if(c[g[x][i]])
       dfst(g[x][i]);}
       
void ts(long x)
{long i;
d[x]=1;
for(i=f[x].size()-1;i>=0;i--)
       ts(f[x][i]);
v[++k]=x;}

int main()
{freopen("2sat.in","r",stdin);
freopen("2sat.out","w",stdout);
scanf("%ld%ld",&n,&m);
for(i=1;i<=m;i++)
       {scanf("%ld%ld",&a[i],&b[i]);
       if(a[i]<0)
              a[i]=n-a[i];
       if(b[i]<0)
              b[i]=n-b[i];
       if(a[i]>n)
              f[a[i]-n].pb(b[i]),g[b[i]].pb(a[i]-n);
       else
              f[a[i]+n].pb(b[i]),g[b[i]].pb(a[i]+n);
       if(b[i]>n)
              f[b[i]-n].pb(a[i]),g[a[i]].pb(b[i]-n);
       else
              f[b[i]+n].pb(a[i]),g[a[i]].pb(b[i]+n);}
for(j=1;j<=2*n;j++)
       {p[j]=2;
       if(!c[j])
                dfs(j);}
r=0;
for(i=nr;i;i--)
if(c[i])
       {dfst(w[i]);
       r++;}
if(r==1)
       {l=0;
       for(i=1;i<=2*n;i++)
       if(!g[i].size())
              {l=i;
              break;}
       if(l)
              ts(l);
       for(i=k;i;i--)
       if(p[i]==2)
              {p[i]=0;
              if(i>n)
                      p[i-n]=1;
              else
                      p[i+n]=1;}}
for(j=1;j<=m;j++)
if(!p[a[j]]&&!p[b[j]])
       {printf("-1");
       return 0;}
for(i=1;i<=n;i++)
       printf("%d ",p[i]);
return 0;}
