#include <fstream>
#define inf 19000001
using namespace std;
ifstream fin ("hamilton.in");
ofstream fout ("hamilton.out");
int v[18][18],n,m,x,y,c,i,dp[18][262144],sol,j,g,nr;
int main ()
{
    fin>>n>>m;
    for (i=1; i<=m; i++)
    {
        fin>>x>>y>>c;
        v[x][y]=c;
    }
    for (i=1; i<(1<<n); i++)
    {
        for (j=0; j<n; j++)
            dp[j][i]=inf;
    }
    dp[0][1]=0;
    for (i=1; i<(1<<n); i++)
    {
        for (j=0; j<n; j++)
        {
            if ((i>>j)&1)
            {
                nr=i-(1<<j);
                for (g=0; g<n; g++)
                {
                    if (((nr>>g)&1)&&v[g][j]!=0)
                        dp[j][i]=min (dp[j][i],dp[g][nr]+v[g][j]);
                }
            }
        }
    }
    sol=inf;
    for (i=0; i<n; i++)
    {
        if (v[i][0]!=0)
            sol=min (sol,dp[i][(1<<n)-1]+v[i][0]);
    }
    fout<<sol;
    return 0;
}
