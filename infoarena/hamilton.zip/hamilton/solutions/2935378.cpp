#include <iostream>
#include <stdio.h>
#include <vector>

using namespace std;

#define MAXN 18
#define PUT 262144
#define INF 19000000

struct node{
    int nod, cost;
};

vector <node> graf[MAXN];
int dp[MAXN][PUT];

int main()
{
    int n, m, i, mask, j, a, b, c;
    scanf("%d%d", &n, &m);
    for(i = 0; i < m; i++){
        scanf("%d%d%d", &a, &b, &c);
        graf[a].push_back({b, c});
        graf[b].push_back({a, c});
    }
    for(mask = 0; mask < PUT; mask++){
        for(i = 0; i < n; i++){
            if(((mask >> (i - 1)) & 1) == 1){
                dp[i][mask] = INF;
            }
        }
    }
    for(i = 0; i < n; i++){
        dp[i][1 << i] = 0;
    }
    for(mask = 0; mask < PUT; mask++){
        for(i = 0; i < n; i++){
            if(((mask >> i) & 1) == 1){
                for(j = 0; j < graf[i].size(); j++){
                    if((((mask >> j) & 1) == 1) && (dp[i][mask - (1 << j)] )){
                        dp[j][mask] =
                    }
                }
            }
        }
    }
    return 0;
}
