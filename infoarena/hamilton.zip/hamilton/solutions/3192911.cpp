#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <cstring>

using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
vector<vector<int>>graph;
const int inf=0x3f3f3f3f;
int n,m,m1,m2,val;
int dp[18][18];
int cost[18][257];
bool muchie_primul(int nod)
{
    for(int vecin: graph[nod])
    {
        if(vecin==0)
            return true;
    }
    return false;
}
int hamilton()
{
    for(int config=1; config<(1<<n)-1; config+=2)
    {
        for(int nod=0; nod<n; nod++)
        {
            if((config & (1<<nod)))
                for(int vecin: graph[nod])
                {
                    if((config & (1<<vecin))==0)
                        dp[config | (1<<vecin)][vecin]=min(dp[config][nod],dp[config][nod]+cost[nod][vecin]);
                }
        }
    }
}

int main()
{
    fin>>n>>m;
    dp[1][0]=0;
    graph.resize(n+1);
    memset(dp,inf,sizeof(dp));
    for(int i=1; i<=m; i++)
    {
        fin>>m1>>m2>>val;
        cost[m1][m2]=val;
        graph[m1].push_back(m2);
    }
    hamilton();
    bool ok=0;
    int conf_cor=(1<<n)-1;
    int min_cost=inf;
    for(int nod=1; nod<n; nod++)
    {
        min_cost=min(min_cost,dp[conf_cor][nod] + muchie_nod_0);
    }
    if (min_cost < inf) {
        fout<<min_cost;
    } else {
        fout<<"nu exista sol";
    }
}
