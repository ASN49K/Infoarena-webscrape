#include <fstream>
#include<vector>
#define NMAX (1<<20)+1
#define INF INT_MAX
using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
int dp[NMAX][20],n,m;
/// dp[mask][last]=costul minim al unui lant in care nodurile sunt marcate cu 1 in mask si se termina in last
vector<int>v[20];
int cost[20][20];
int x,y,k,sol;
int c[NMAX];
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y>>cost[x][y];
        v[x].push_back(y);
        if(y==0)
            c[++k]=x;
    }
    for(int mask=1; mask<(1<<n); mask+=2)
        for(int last=0;last<n;last++)
            dp[mask][last]=INF;

    dp[1][0]=0;
    for(int mask=1;mask<(1<<n);mask+=2)
    {
        for(int last=0;last<n;last++)
        {
            if(dp[mask][last]!=INF)///se gaseste in mask
            {
                for(int i=0;i<v[last].size();i++)
                {
                    int nod=v[last][i];
                    if(dp[mask][nod]==INF)///nu e deja in lant
                    {
                        dp[mask+(1<<nod)][nod]=min(dp[mask+(1<<nod)][nod],dp[mask][last]+cost[last][nod]);
                    }
                }
            }
        }
    }
    sol=INF;
    for(int i=1;i<n;i++)
    {
        if(c[i])
            sol=min(sol,dp[(1<<n)-1][i]+cost[i][0]);
    }
    if(sol!=INF)
    fout<<sol;
    else
        fout<<"Nu exista solutie";
    return 0;
}
