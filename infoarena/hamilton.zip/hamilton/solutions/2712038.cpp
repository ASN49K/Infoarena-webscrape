#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

ifstream f ("hamilton.in");
ofstream g ("hamilton.out");

int n, m, smin, k;

int sol[25];

bool used[25];

int cost[25][25];

vector < int > v[25];

const int inf = 2e9;

void Generare (int nod, int sum)
{
    if (k == n && cost[sol[k]][sol[1]])
    {
        smin = min(smin, sum + cost[sol[k]][sol[1]]);
        return;
    }

    for (int i=0; i<v[nod].size(); i++)
    {
        int vecin = v[nod][i];
        int c = cost[nod][vecin];

        if (!used[vecin])
        {
            used[vecin] = 1;
            k ++; sol[k] = vecin;
            Generare(vecin, sum + c);
            k --; used[vecin] = 0;
        }
    }
}

int main()
{
    f >> n >> m;

    for (int i=1; i<=m; i++)
    {
        int x, y, c;
        f >> x >> y >> c;
        v[x].push_back(y);
        cost[x][y] = c;
    }

    smin = inf; used[1] = 1;
    k = 1; sol[k] = 1;
    Generare(1, 0);

    if (smin == inf) g << "Nu exista solutie";
    else g << smin;

    return 0;
}
