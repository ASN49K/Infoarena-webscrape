#include <bits/stdc++.h>

using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
#define nr 1000000001
int n, m, cost[20][20], dp[1 << 19][19];
vector <int> V[20];
vector <int> aux[20];
int main()
{
    fin >> n >> m;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cost[i][j] = nr;
        }
    }

    for (int i = 1; i <= m; ++i) {
        int x, y, c;
        fin >> x >> y >> c;
        cost[x][y] = c;
        V[x].push_back(y);
        if (y == 0)
            aux[y].push_back(x);
    }

    for (int i = 0; i < (1 << n); ++i) {
        for (int j = 0; j < n; ++j) {
            dp[i][j] = nr;
        }
    }

    dp[1][0] = 0;
    int mini = INT_MAX;
    for (int mask = 1; mask < (1 << n); ++mask) {
        for (int i = 0; i < n; ++i) {
            if (mask & (1 << i)) {
                for (vector <int> :: iterator it = V[i].begin(); it != V[i].end(); ++it) {
                    if ((mask & (1 << *it)) == 0) {
                        dp[mask | (1 << *it)][*it] = min(dp[mask | (1 << *it)][*it], dp[mask][i] + cost[i][*it]);
                    }
                }
            }
        }
    }

    int mask = (1 << n) - 1, ans = INT_MAX;
    for (vector <int> :: iterator it = aux[0].begin(); it != aux[0].end(); ++it) {
        ans = min(ans, dp[mask][*it] + cost[*it][0]);
    }

    if (ans == INT_MAX)
        fout << "Nu exista solutie";
    else
        fout << ans;
    return 0;
}
