#include <bits/stdc++.h>

using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
int n,m,dp[270005][21],cost[21][21];
vector<int> muchii[21];
int INF=1e9;
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        fin>>cost[a][b];
        muchii[a].push_back(b);
    }
    for(int mask=0;mask<(1<<n);mask++)
        for(int i=0;i<n;i++)
            dp[mask][i]=INF;
    dp[1][0]=0;
    for(int mask=2;mask<(1<<n);mask++)
    {
        for(int i=0;i<n;i++)
            if((mask>>i)&1)
            {
                for(auto j:muchii[i])
                    if((mask>>j)&1)
                        dp[mask][j]=min(dp[mask][j],dp[mask-(1<<j)][i]+cost[i][j]);
            }
    }
    int ans=INF;
    for(int i=1;i<n;i++)
        if(dp[(1<<n)-1][i]<INF&&cost[i][0]>0)
            ans=min(ans,dp[(1<<n)-1][i]+cost[i][0]);
    if(ans==INF)
        fout<<"Nu exista solutie";
    else
        fout<<ans;
    return 0;
}
