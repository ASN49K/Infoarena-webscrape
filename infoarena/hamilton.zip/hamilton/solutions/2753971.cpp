#include <fstream>
#define mF "hamilton"
std::ifstream in(mF ".in");
std::ofstream out(mF ".out");
#include <vector>
#include <utility>
#define x first
#define y second
#include <string>
constexpr int N = 18; std::vector<std::pair<int, int>> L[N]; int V[1 << N][N]; int main()
{
    int n, m, s = 1 << 30; in >> n >> m; while (m--) {int a, b, c; in >> a >> b >> c; L[b].push_back({c, a});}
    for (int i = 3; i < 1 << n; i += 2) for (int j = 0; j < n; j++) if (V[i][j] = 1 << 30, 1 << j & i and j)
        for (auto k: L[j]) if (1 << k.y & i) V[i][j] = std::min(V[i][j], V[1 << j ^ i][k.y] + k.x);
    for (auto k: *L) s = std::min(s, V[(1 << n) - 1][k.y] + k.x); out << (s == 1 << 30? "Nu exista solutie": std::to_string(s));
}
