#include <bits/stdc++.h>

using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
typedef pair<int,int> pii;
int n,m,dp[300001][21],cost[31][31];
vector<pii> muchii[300001];
void bfs()
{
    dp[1][1]=0;
    queue<pii> coada;
    coada.push({1,1});
    while(!coada.empty())
    {
        pii x=coada.front();
        int nod=x.second;
        int mask=x.first;
        coada.pop();
        for(auto p:muchii[nod])
        {
            int i=p.first;
            if(cost[nod][i]!=-1)
                if(!((mask>>(i-1))&1))
                {
                    int msk=mask+(1LL<<(i-1));
                    int cst=dp[mask][nod]+cost[nod][i];
                    if(dp[msk][i]==-1||dp[msk][i]>cst)
                    {
                        dp[msk][i]=cst;
                        coada.push({msk,i});
                    }
                }
        }
    }
}
bool comp(pii a, pii b)
{
    return a.second<b.second;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    fin>>n>>m;
    if(n==1)
    {
        fout<<0;
        return 0;
    }
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
        {
            cost[i][j]=-1;
            cost[0][i]=0;
        }
    for(int msk=0;msk<=(1LL<<n);msk++)
        for(int i=1;i<=n;i++)
            dp[msk][i]=-1;
    for(int i=1;i<=m;i++)
    {
        int a,b,c;
        fin>>a>>b>>c;
        a++;
        b++;
        cost[a][b]=c;
        muchii[a].push_back({b,c});
    }
    for(int i=1;i<=n;i++)
        sort(muchii[i].begin(),muchii[i].end(),comp);
    bfs();
    long long ans=100000000000;
    int mask=(1LL<<n)-1;
    for(int i=1;i<=n;i++)
        if(cost[i][1]!=-1&&dp[mask][i]!=-1)
            ans=min(ans,1LL*(dp[mask][i]+cost[i][1]));
    if(ans==100000000000)
    {
        fout<<"Nu exista solutie";
        return 0;
    }
    fout<<ans;
    return 0;
}
