#include <bits/stdc++.h>
#define NMAX 300500
#define MOD 500500500
using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
int dp[NMAX][22];
vector<int>v[22];
int cost[22][22];
int hamilton(int mask, int node)
{
    if(dp[mask][node]==-1)
    {
        dp[mask][node]=MOD;
        for(auto i:v[node])
            if(mask&(1<<i))
            {
                if(i==0 && mask!=1+(1<<node))
                    continue;
                dp[mask][node]=min(dp[mask][node], hamilton(mask^(1<<node), i)+cost[i][node]);
            }
    }
    return dp[mask][node];
}
int n, m, ans,x,y;
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;++i)
    {
        fin>>x>>y>>cost[x][y];
        v[y].push_back(x);
    }

    for(int i=1;i<=(1<<n);++i)
        for(int j=1;j<=n;++j)
            dp[i][j]=-1;

    ans=MOD;
    dp[1][0]=0;
    for(auto i:v[0])
        ans=min(ans, hamilton((1<<n)-1, i)+cost[i][0]);

    if(ans==MOD)
        fout<<"Nu exista solutie";
    else fout<<ans;

    return 0;
}
