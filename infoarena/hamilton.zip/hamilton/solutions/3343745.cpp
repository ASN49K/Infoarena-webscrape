#include <bits/stdc++.h>
using namespace std;
ifstream f("prefix.in");
ofstream g("prefix.out");
map <pair <int, int>, int> fv;
int dp[300009][20];
signed main ()
{
    int n, m;
    f >> n >> m;
    for (int i=1; i<=m; i++)
    {
        int x, y;
        f >> x >> y;
        //x++, y++;
        int z;
        f >> z;
        fv[ {x,y}]=z;
        //fv[ {y,x}]=z;
    }
    for (int i=0; i<=(1<<n); i++)
        for (int j=0; j<=n; j++)
        dp[i][j]=1e9;
    for (int i=0; i<n; i++)
        dp[(1<<i)][i]=0;
    for (int stare=0; stare<(1<<n); stare++)
    {
        for (int i=0; (1<<i)<=stare; i++)
        {
            if ((stare&(1<<i)))
            {
                for (int j=0; j<n; j++)
                {
                    if ((stare&(1<<j))==0 && fv[{i,j}])
                    {
                        int ns=stare|(1<<j);
                        dp[ns][j]=min (dp[ns][j], dp[stare][i]+fv[{i,j}]);
                    }
                }
            }
        }
    }
    int minim=1e9;
    for (int i=0; i<n; i++)
    {
        if (fv[{i,0}])
            minim=min (minim, dp[(1<<n)-1][i]+fv[{i,0}]);
        //cout << minim<<'\n';
    }
    if (minim!=1e9) g << minim;
    else g << "Nu exista solutie";
}
