#include <bits/stdc++.h>

using namespace std;

ifstream cin("hamilton.in");
ofstream cout("hamilton.out");

constexpr int INF = 1e9;

int n, m;
vector<pair<int,int>> L[20];
int dp[1 << 18][18];

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y, c;

        cin >> x >> y >> c;
        L[x].push_back({ y,c });
    }
    int maxim = 1 << n;
    for (int mask = 0; mask < maxim; mask++)
        for (int i = 0; i < n; i++)
            dp[mask][i] = INF;
    dp[1][0] = 0;
    for (int mask = 0; mask < maxim; mask++)
        for (int i = 0; i < n; i++)
        {
            if (!(mask & (1 << i)))
                continue;
            for (auto j : L[i])
            {
                if (!(mask & (1 << j.first)))
                    continue;
                dp[mask][i] = min(dp[mask][i], dp[mask ^ (1 << i)][j.first] + j.second);
            }
        }
    int ans = INF;
    for (auto i : L[0])
        ans = min(ans, dp[maxim - 1][i.first] + i.second);
    if (ans == INF)
        cout << "Nu exista solutie\n";
    else
        cout << ans << '\n';
    return 0;
}
