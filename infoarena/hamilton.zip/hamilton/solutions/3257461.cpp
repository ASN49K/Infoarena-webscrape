#include <bits/stdc++.h>
using namespace std;

int n, m;
vector<vector<int>> v(20);
int cost[20][20], dp[1 << 18][20];

int main() {
    ifstream cin("hamilton.in");
    ofstream cout("hamilton.out");
    cin >> n >> m;
    for (int i = 1; i <= m; ++i) {
        int x, y, c;
        cin >> x >> y >> c;
        cost[x][y] = c;
        v[y].push_back(x);
    }
    memset(dp, 0x3f, sizeof(dp));
    dp[1][0] = 0;
    for (int i = 0; i < (1 << n); ++i) {
        for (int j = 0; j < n; ++j) {
            if (i & (1 << j)) {
                for (int k = 0; k < v[j].size(); ++k) {
                    if (i & (1 << v[j][k])) {
                        dp[i][j] = min(dp[i][j], dp[i ^ (1 << j)][v[j][k]] + cost[v[j][k]][j]);
                    }
                }
            }
        }
    }
    int ans = 0x3f3f3f3f;
    for (int i = 0; i < v[0].size(); ++i) {
        ans = min(ans, dp[(1 << n) - 1][v[0][i]] + cost[v[0][i]][0]);
    }
    if (ans != 0x3f3f3f3f) {
        cout << ans;
    } else {
        cout << "Nu exista solutie";
    }
}
