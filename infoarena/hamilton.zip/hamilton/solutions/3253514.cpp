#include <fstream>
#include <vector>

using namespace std;

ifstream cin ("hamilton.in");
ofstream cout ("hamilton.out");

long long int t,m,q,c,u,v,cur,x,y,ok,mask,cost,maxi,a[25][25],dp[1<<18+5][25],b,n,k,i,j,l,r,mij,mini,p,poz,ans,nr,sum,mod=1e9+7;
string s;
vector<int>g[200005];

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin>>n>>m;
    vector<vector<int>>dp(1<<18,vector<int>(18,1e9));
    for(i=1;i<=m;i++)
    {
        cin>>u>>v>>cost;
        a[u][v]=cost;
    }
    dp[1][0]=0;
    for(mask=1;mask<(1<<n);mask++)
        for(j=0;j<n;j++)
            for(k=0;k<n;k++)
            if(!(a[j][k]==0 || mask&(1<<k)) && mask&(1<<j))
            {
                int new_mask=mask^(1<<k);
                int new_dp=dp[mask][j]+a[j][k];
                dp[new_mask][k]=min(dp[new_mask][k],new_dp);
            }

    ans=2e9;
    for(i=0;i<n;i++)
        if(a[i][0]!=0)
            ans=min(ans,dp[(1<<n)-1][i]+a[i][0]);
    cout<<ans;
    return 0;
}
