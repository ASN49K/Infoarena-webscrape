#include <bits/stdc++.h>
#define cin fin
#define cout fout
using namespace std;

ifstream fin("hamilton.in");
ofstream fout("hamilton.out");

int n, m;
vector <vector <long long> > edgeCost, dp;

int main() {
    cin >> n >> m;

    edgeCost.assign(n, vector <long long> (n, INT_MAX));
    for (int i = 0; i < m; ++i) {
        int u, v, cost;

        cin >> u >> v >> cost;
        edgeCost[u][v] = cost;
    }

    int totalSub = 1 << n;

    dp.assign(totalSub, vector <long long> (n, INT_MAX));
    dp[1][0] = 0;
    for (int mask = 0; mask < totalSub; ++mask) {
        for (int i = 0; i < n; ++i) {
            if (mask & (1 << i)) {
                for (int next = 0; next < n; ++next) {
                    if (mask & (1 << next)) {
                        dp[mask][i] = min(dp[mask][i], dp[mask ^ (1 << i)][next] + edgeCost[next][i]);
                    }
                }
            }
        }
    }

    long long ans = INT_MAX;
    for (int i = 0; i < n; ++i) {
        ans = min(ans, dp[totalSub - 1][i] + edgeCost[i][0]);
    }

    if (ans == INT_MAX) {
        cout << -1;
        return 0;
    }

    cout << ans;

    return 0;
}
