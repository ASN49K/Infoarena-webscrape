#include <bits/stdc++.h>
#define fastio std::ios_base::sync_with_stdio(NULL),cin.tie(NULL),cout.tie(NULL);
#define FILES freopen("hamilton.in","r",stdin);\
              freopen("hamilton.out","w",stdout);
#define ll long long
#define ull unsigned long long
#define pb push_back
#define mp make_pair
#define add emplace_back
#define MAX 100
#define mod 666013
#define BMAX 524288
using namespace std;
int n,m,x,y,c,dp[BMAX+5];
vector <pair<int,int>> mch[MAX+5];
void solve(int mask,int nod)
{
    for(auto i : mch[nod])
    {
        if(mask & (1 << i.first)) continue;
        if(dp[mask | (1 << i.first)] > dp[mask] + i.second)
            dp[mask | (1 << i.first)] = dp[mask] + i.second,solve(mask | (1 << i.first),i.first);
    }
}
int main()
{
    fastio
    FILES
    cin >> n >> m;
    for(int i = 1; i <= m; ++i)
    {
        cin >> x >> y >> c;
        mch[x].add(mp(y,c));
    }
    int rez = (1 << n) - 1;
    for(int i = 0; i <= rez; ++i) dp[i] = 1e9;
    dp[0] = 0;
    solve(0,0);
    cout << dp[rez];
}
