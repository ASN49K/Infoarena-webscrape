#include <fstream>

using namespace std;

ifstream f("hamilton.in");
ofstream g("hamilton.out");

const int inf=1000000000;
int n,m,i,x,y,c,j,t,xr,ans;
int graf[20][20],pow[20],d[263000][20];
short first[263000][20];

int main()
{
    for(i=0;i<20;i++)
        for(j=0;j<20;j++)
        graf[i][j]=inf;
    for(i=0;i<263000;i++)
        for(j=0;j<20;j++)
        {
            d[i][j]=inf;
            first[i][j]=-1;
        }


    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>c;
        graf[x][y]=c;
    }
    pow[0]=1;
    for(i=1;i<=19;i++)
        pow[i]=pow[i-1]*2;


    for(i=0;i<n;i++)
    {
        d[pow[i]][i]=0;
        first[pow[i]][i]=i;
    }
    for(i=1;i<pow[n];i++)
    {
        for(j=1;j<n;j++)
            if(i&pow[j])//nu are sens sa sa termine in "j" daca nu il contine pe "j"
        {
            xr=i^pow[j];
            for(t=0;t<n;t++)
                if( (xr&pow[t]) && (d[xr][t]+graf[t][j]<d[i][j]) )
                {
                    d[i][j]=d[xr][t]+graf[t][j];
                    first[i][j]=first[xr][t];
                }
        }
    }
    ans=inf;
    for(i=0;i<n;i++)
    {
        x=first[pow[n]-1][i];
        if(d[pow[n]-1][i]+graf[i][x]<ans)
            ans=d[pow[n]-1][i]+graf[i][x];
    }
    if(ans==inf)
        g<<"Nu exista solutie";
    else
        g<<ans<<'\n';
/*for(i=0;i<n;i++)
    g<<d[pow[n]-1][i]<<' ';
g<<'\n';
for(i=0;i<n;i++)
{
    x=first[pow[n]-1][i];
    g<<graf[i][x]<<' ';
}
g<<'\n';
for(i=0;i<n;i++)
    {
        x=first[pow[n]-1][i];
        g<<d[pow[n]-1][i]+graf[i][x]<<' ';
    }*/

    return 0;
}
