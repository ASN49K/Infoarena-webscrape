#include <fstream>
#include <vector>

using namespace std;

const int N = 18;
const int INF = 1e8;

int cost[N][N];
int dp[1<<N][N];
vector <int> a[N];

int main()
{
    ifstream in("hamilton.in");
    ofstream out("hamilton.out");
    int n, m;
    in >> n >> m;
    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            cost[i][j] = cost[j][i] = INF;
        }
    }
    for (int i = 0; i < m; i++)
    {
        int x, y;
        in >> x >> y;
        in >> cost[x][y];
        a[x].push_back(y);
    }
    for (int i = 0; i < (1 << n); i++)
    {
        for (int j = 0; j < n; j++)
        {
            dp[i][j] = INF;
        }
    }
    dp[1][0] = 0;
    for (int i = 1; i < (1 << n); i += 2)
    {
        for (int j = 0; j < n; j++)
        {
            if (dp[i][j] != INF)///avem drum de la 0 la j cu vf din i
            {
                for (auto k: a[j])
                {
                    if (i & (1 << k))
                    {
                        continue;
                    }
                    int ii = (i | (1 << k));
                    ///ii=codificarea lui i reunit cu {k}
                    dp[ii][k] = min(dp[ii][k], dp[i][j] + cost[j][k]);
                }
            }
        }
    }
    int ch = INF;
    for (int j = 1; j < n; j++)
    {
        ch = min(ch, dp[(1 << n) - 1][j] + cost[j][0]);
    }
    out << ch << "\n";
    in.close();
    out.close();
    return 0;
}
