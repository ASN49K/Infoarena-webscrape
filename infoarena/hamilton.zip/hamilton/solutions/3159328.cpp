#include <fstream>
#include <vector>
const int NMAX=20;


using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");

vector<pair<int, int>> v[NMAX];
int dp[(1<<NMAX)][NMAX];
int n, m;

signed main()
{
  int i, j, k, sum, a, b, c;
  fin>>n>>m;
  for(i=0; i<=(1<<n); i++)
  {
    for(j=0; j<=n; j++)
    {
      dp[i][j]=1e9;
    }
  }
  for(i=1; i<=m; i++)
  {
    fin>>a>>b>>c;
    v[b].push_back(make_pair(a, c));
  }
  for(i=0; i<n; i++)
  {
    dp[(1<<i)][i]=0;
  }
  for(i=0; i<(1<<n); i++)
  {
    for(j=0; j<n; j++)
    {
      if(i&(1<<j))
      {
        for(auto k:v[j])
        {
          if(i&(1<<k.first))
          {
            dp[i][j]=min(dp[i][j], dp[i^(1<<j)][k.first]+k.second);
          }
        }
      }
    }
  }
  int ans=1e9;
  for(auto i:v[0]) ans=min(ans, dp[(1<<n)-1][i.first]+i.second);
  if(ans!=1e9) fout<<ans<<'\n';
  else fout<<"Nu exista solutie\n";
}
