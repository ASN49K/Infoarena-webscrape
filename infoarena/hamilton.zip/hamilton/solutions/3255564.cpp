#include <fstream>

using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
int n, m, i, j, x, y, c, cost[21][21], dp[21][(1<<18)-1], mask, ans;
int main()
{
    fin>>n>>m;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
        cost[i][j]=1e9;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y>>c;
        cost[x][y]=c;
    }
    for(i=0; i<n; i++)
        for(mask=0; mask<(1<<n); mask++)
          dp[i][mask]=1e9;
    dp[0][1]=0;
    for(mask=3; mask<(1<<n); mask++)
        for(i=0; i<n; i++)
          if(mask&(1<<i))
            for(j=0; j<n; j++)
              if(mask&(1<<j))
                dp[i][mask]=min(dp[i][mask], dp[j][mask-(1<<i)]+cost[j][i]);
    ans=1e9;
    for(i=0; i<n; i++)
        ans=min(ans, dp[i][(1<<n)-1]+cost[i][0]);
    fout<<ans;
    return 0;
}
