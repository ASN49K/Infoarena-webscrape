#include <bits/stdc++.h>

using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
const int INF=1e9;
int n,m;
int adj[25][25];
int dp[(1<<18)][19];
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b,c;
        fin>>a>>b>>c;
        adj[a][b]=c;
    }
    if(n==1)
    {
        fout<<0;
        return 0;
    }
    for(int i=0;i<n;i++)
        dp[1][i]=INF;
    dp[1][0]=0;
    for(int mask=2;mask<(1<<n);mask++)
        for(int last=0;last<n;last++)
            if((mask>>last)&1)
            {
                dp[mask][last]=INF;
                for(int prv=0;prv<n;prv++)
                    if((mask>>prv)&1)
                        if(adj[prv][last]&&prv!=last)
                            dp[mask][last]=min(dp[mask][last],dp[mask^(1<<last)][prv]+adj[prv][last]);
            }
    int ans=INF;
    for(int i=1;i<n;i++)
        if(adj[i][0])
            ans=min(ans,dp[(1<<n)-1][i]+adj[i][0]);
    if(ans==INF)
        fout<<"Nu exista solutie";
    else
        fout<<ans;
    return 0;
}
