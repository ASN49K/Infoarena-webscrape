#include <iostream>
#include <fstream>
#include <climits>
#include <vector>
#define VMAX 18
#define INF 1e9

using namespace std;

ifstream fin("hamilton.in");
ofstream fout("hamilton.out");

int V, E, x, y;
vector <int> adj[VMAX + 1];
int dp[(1 << VMAX) + 1][VMAX + 1];
int cost[VMAX + 1][VMAX + 1];

int main()
{
    fin >> V >> E;

    for (int mask = 0; mask < (1 << V); ++mask)
        for (int i = 0; i < V; ++i)
            dp[mask][i] = INF; // initial, toate drumurile posibile sunt INF

    for (int i = 0; i < V; ++i)
        for (int j = 0; j < V; ++j)
        cost[i][j] = INF; // costurile muchiilor intre care nu exista drum sunt INF

    while (E--)
    {
        fin >> x >> y >> cost[x][y];
        adj[y].push_back(x); // nu am nevoie de vecinii lui x, ci de nodurile care il au vecin pe x, deci memorez invers lista de adiacenta
    }

    dp[1][0] = 0;

    for (int mask = 0; mask < (1 << V); ++mask) // toate submultimile posibile
        for (int i = 0; i < V; ++i) // toate end-vertices posibile
            if (mask & (1 << i)) // i apartine multimii determinate de mask <=> al i-lea bit al lui mask este 1
                for (auto j:adj[i])  // iau toate nodurile j pt. care exista arcul (j, i) si verific daca apartin lui mask
                    dp[mask][i] = min(dp[mask][i], dp[mask ^ (1 << i)][j] + cost[j][i]); // dp[mask][i] = dp[mask - {i}][vecin] + cost[vecin][i]

    int minimum = INF;

    for (auto j:adj[0])
        minimum = min(minimum, dp[(1 << V) - 1][j] + cost[j][0]);

    if (minimum == INF) fout << "Nu exista solutie";
    else fout << minimum;

    fin.close();
    fout.close();
    return 0;
}
