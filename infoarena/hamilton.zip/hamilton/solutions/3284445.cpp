#include <bits/stdc++.h>
#define inf 1e9
using namespace std;
const int nmax = 18, nr = 262143;
int mat[nmax + 1][nmax + 1];
int dp[nr + 1][nmax + 1];
int main()
{
    ios :: sync_with_stdio(false);
    cin.tie(0);
    freopen("hamilton.in", "r", stdin);
    freopen("hamilton.out", "w", stdout);
    int n, i, m, x, y, z, stare, j;
    cin >> n >> m;
    for(i = 0; i < n ; i++)
        for(j = 0; j < n; j++)
            mat[i][j] = inf;
    for(i = 1; i <= m; i++)
    {
        cin >> x >> y >> z;
        mat[x][y] = z;
    }
    for(j = 1; j < (1 << n); j++)
        for(i = 0; i < n; i++)
            dp[j][i] = inf;
    dp[1][0] = 0;
    for(stare = 0; stare < (1 << n); stare++)
    {
        for(i = 0; i < n; i++)
        {
            if(stare & (1 << i))
                for(j = 0; j < n; j++)
                    if(stare & (1 << j))
                        dp[stare][i] = min(dp[stare][i], dp[stare ^ (1 << i)][j] + mat[j][i]);
        }
    }
    int sol = inf;
    for(i = 0; i < n; i++)
        sol = min(sol, dp[(1 << n) - 1][i] + mat[i][0]);
    if(sol == inf)
        cout << "Nu exista solutie";
    else
        cout << sol;
    return 0;
}
