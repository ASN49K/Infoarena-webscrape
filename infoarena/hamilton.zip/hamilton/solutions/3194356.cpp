#include <bits/stdc++.h>
#define cin fin
#define cout fout
using namespace std;

ifstream fin("hamilton.in");
ofstream fout("hamilton.out");

int n, m;
vector <vector <int> > edgeCost, dp;

int main() {
    cin >> n >> m;

    edgeCost.assign(n, vector <int> (n, INT_MAX));
    for (int i = 0; i < m; ++i) {
        int u, v, cost;

        cin >> u >> v >> cost;
        edgeCost[u][v] = cost;
    }

    int totalSub = 1 << n;

    dp.assign(totalSub, vector <int> (n, INT_MAX));
    dp[1][0] = 0;
    for (int mask = 0; mask < totalSub; ++mask) {
        for (int i = 0; i < n; ++i) {
            if (mask & (1 << i)) {
                for (int next = 0; next < n; ++next) {
                    if (dp[mask ^ (1 << i)][next] != INT_MAX && edgeCost[next][i] != INT_MAX) {
                        dp[mask][i] = min(dp[mask][i], dp[mask ^ (1 << i)][next] + edgeCost[next][i]);
                    }
                }
            }
        }
    }

    long long ans = INT_MAX;
    for (int i = 0; i < n; ++i) {
        ans = min(ans, (long long) dp[totalSub - 1][i] + edgeCost[i][0]);
    }

    if (ans == INT_MAX) {
        cout << "Nu exista solutie";
        return 0;
    }

    cout << ans;

    return 0;
}
