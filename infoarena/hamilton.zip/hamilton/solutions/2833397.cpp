#include <bits/stdc++.h>
#define ull unsigned long long
#define FILES freopen("hamilton.in","r",stdin);\
              freopen("hamilton.out","w",stdout);
#pragma GCC optimize ("Ofast")
#define CMAX 1000000
#define fastio std::ios_base::sync_with_stdio(NULL),cin.tie(NULL),cout.tie(NULL);
#define mp make_pair
#define INF 999999999999999
#define void inline void
#define mod 1000000007
#define ll long long
#define MAX 100
#define SMAX 10000
#define pb push_back
#define add emplace_back
using namespace std;
int n,m,mask,best=1e9,dp[262149][20];
vector<pair<int,int>> v[MAX+5];
int main()
{
    fastio
    FILES
    cin >> n >> m;
    mask = (1<<n)-1;
    for(int i = 1; i <= m; ++i)
    {
        int a,b,c;
        cin >> a >> b >> c;
        a++,b++;
        v[a].add(mp(b,c));
    }
    for(int j = 1; j <= n; ++j)
        for(int k = 1; k <= mask; ++k) dp[k][j] = 1e9;
    dp[1][1] = 0;
    for(int i = 2;i <= mask; ++i)
    {
        for(int j = 1;j <= n; ++j)
        {
            if(!(i & (1 << (j-1)))) continue;
            for(auto k : v[j])
            {
                if(!(i & (1 << (k.first-1)))) continue;
                int u = (i ^ (1 << (k.first-1)));
                dp[i][k.first] = min(dp[i][k.first],dp[u][j] + k.second);
            }
        }
    }
    for(int i = 1;i <= n; ++i)
    {
        int o = 1e9;
        for(auto j : v[i])
        {
            if(j.first == 1)
            {
                o = j.second;
                break;
            }
        }
        best = min(best,dp[mask][i] + o);
    }
    if(best == 1e9) cout << "Nu exista solutie";
    else cout << best;
}
