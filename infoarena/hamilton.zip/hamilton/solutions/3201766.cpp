#include <fstream>
const int NMAX=19;

using namespace std;
ifstream cin("hamilton.in");
ofstream cout("hamilton.out");

int dp[(1<<NMAX)][NMAX];
int v[NMAX][NMAX];
int n, m;

int main()
{
    int i, j, a, b, c;
    int mask, newmask, ans=1e9;
    cin>>n>>m;
    for(i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            v[i][j]=1e9;
        }
    }
    for(i=1; i<=m; i++)
    {
        cin>>a>>b>>c;
        v[b][a]=c;
    }
    dp[1][0]=0;
    for(mask=2; mask<(1<<n); mask++)
    {
        for(i=0; i<n; i++)
        {
            if(mask&(1<<i))
            {
                newmask=mask^(1<<i);
                dp[mask][i]=1e9;
                for(j=0; j<n; j++)
                {
                    if(newmask&(1<<j))
                    {
                        dp[mask][i]=min(dp[mask][i], dp[newmask][j]+v[i][j]);
                    }
                }
            }
        }
    }
    for(i=0; i<n; i++)
    {
        ans=min(ans, dp[(1<<n)-1][i]+v[0][i]);
    }
    cout<<ans<<'\n';
    return 0;
}
