#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream in("hamilton.in");
ofstream out("hamilton.out");
vector <pair<int,int> > v[20];
int n,m,x,y,lung;
int dp[1050000][20];
int main()
{
    in>>n>>m;
    for(int i=0;i<n;i++)
    {
        in>>x>>y>>lung;
        v[x].push_back({lung,y});
    }
    int p2=(1<<n);
    for(int i=1;i<p2;i++)
        {for(int j=0;j<n;j++)
                dp[i][j]=1e9;
        }
    for(auto it : v[1])
    dp[1][it.second]=it.first;
    for(int i=2;i<p2;i++)
        for(int k=0;k<n;k++)
    if(i & (1<<k))
    {
        for(int j=0;j<n;j++)
        {
            for(auto it : v[j])
                if(!((1<<it.second) & i))
                {
                    dp[i][j]=min(dp[i][j],dp[i ^ (1<<k)][it.second]+it.first);
                }
        }
    }
    for(int i=1;i<p2;i++)
        {for(int j=0;j<n;j++)
            if(dp[i][j]==1e9) cout<<0<<" ";
            else cout<<dp[i][j]<<" ";
            cout<<'\n';
        }
    int sol=1e9;
    for(auto it : v[1])
    {
        sol=min(dp[p2-1][it.second]+it.first,sol);
    }
    cout<<sol;
    return 0;
}
