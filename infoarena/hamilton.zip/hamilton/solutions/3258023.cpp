#include <fstream>
#include <vector>
using namespace std;
ifstream cin("hamilton.in");
ofstream cout("hamilton.out");
const int INF = 0x3F3F3F3F;
vector<vector<int>> graf, dp;
int n, m, x, y, z;
int  hamilton()
{
    for(int mask = 2; mask < (1<<n); mask++)
        if(mask & 1)
            for(int i=0; i<n; i++)
                if(mask & (1<<i))
                    for(int j=0; j<n; j++)
                        if(mask & (1<<j))
                            dp[mask][i] = min(dp[mask][i], dp[mask^(1<<i)][j] + graf[j][i]);
    int ans = INF;
    for(int i=0; i<n; i++)
        ans = min(ans, dp[(1<<n) - 1][i] + graf[i][0]);
    return ans;

}
int main()
{
    cin >> n >> m;
    graf.assign(n, vector<int>(m, INF));
    dp.assign((1 << n), vector<int>(n, INF));
    dp[1][0] = 0;
    for(int i=0; i<m; i++)
    {
        cin >> x >> y >> z;
        graf[x][y] = z;
    }

    int rez = hamilton();
    if(rez == INF)
        cout << "-1";
    else
        cout << rez;
    return 0;
}
