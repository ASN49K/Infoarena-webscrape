#include <iostream>
#include <fstream>
#include <vector>
#define MAXN 18
#define MAXVAL 1000000000
#define DEBUG 0

using namespace std;

struct Edge{
  int a, cost;

  bool operator>(const Edge& other) const{
    return cost > other.cost;
  }
};
vector<vector<Edge>> v;

int d[MAXN][1 << (MAXN)];

int getD(int i, int g){
  if(g < 0)
    return MAXVAL;
  if((g ^ (1 << i)) > g) // G nu contine nodul i
    return MAXVAL;

  if(d[i][g] != -1)
    return d[i][g];
  if(g == (1 << i)) // Este un singur nod si nu este 0
    return MAXVAL;

  d[i][g] = MAXVAL;

  for(int j = 0; j < v[i].size(); j ++){
    Edge e = v[i][j];
    int val = getD(e.a, g - (1 << i)) + e.cost;
    if(val < d[i][g])
      d[i][g] = val;
  }
  return d[i][g];
}

int main(){
  int n, m;

  ifstream fin ("hamilton.in");
  fin >> n >> m;
  v.resize(n);

  for(int i = 0; i < n; i ++){
    for(int j = 0; j < (1 << n); j ++)
      d[i][j] = -1;
  }
  d[0][1] = 0;

  for(int i = 0; i < m; i ++){
    int a, b, c;
    fin >> a >> b >> c;
    v[b].push_back({a, c}); // toate muchiile care ajung in b
  }
  fin.close();

  int minv = MAXVAL;
  for(int i = 0; i < v[0].size(); i ++){
    int node = v[0][i].a;
    int val = getD(node, (1 << n) - 1) + v[0][i].cost;
    if(val < minv)
      minv = val;
  }
  
  if(DEBUG){
    printf("   ");
    for(int i = 0; i < (1 << n); i ++){
      printf("%d ", i);
      if(i < 10)
        printf(" ");
    }
    printf("\n");
    for(int i = 0; i < n; i ++){
      printf("%d: ", i);
      for(int j = 0; j < (1 << n); j ++){
        if(getD(i, j) == MAXVAL)
          printf("-  ");
        else {
          printf("%d ", getD(i, j));
          if(getD(i,j) < 10)
            printf(" ");
        }
      }
      printf("\n");
    }
  }

  ofstream fout ("hamilton.out");
  if(minv >= MAXVAL)
    fout << "Nu exista solutie" << endl;
  else
    fout << minv << "\n";
  fout.close();

  return 0;
}
