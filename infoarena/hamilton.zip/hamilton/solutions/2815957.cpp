#include<fstream>
#include<vector>
#include <algorithm>
using namespace std;
ifstream in("hamilton.in");
ofstream out("hamilton.out");
    int noduri;
    int muchii;
    int minim;
    int suma;
    vector<int> okey;
    vector<int> adiacenta[100001];

    void citire_Hamilton()
    {
        in >> noduri >> muchii;
        minim = 100000000;

        for (int i = 0; i <= noduri; i++)
        {
            okey.resize(noduri + 1);
            adiacenta[i].resize(noduri + 1);
        }

        for (int i = 1; i <= muchii; i++)
        {
            int x, y, c;
            in >> x >> y >> c;
            adiacenta[x][y] = c;
        }
    }
    int vizitate(vector<int> okey)
    {
        for (int i = 1; i < noduri; i++)
            if (okey[i] == 0)
                return 0;
        return 1;
    }
    void verificare(int nod)
    {
        if (vizitate(okey) && adiacenta[nod][0] > 0)
        {
            suma += adiacenta[nod][0];
            minim = min(minim, suma);
            suma -= adiacenta[nod][0];
            return;
        }

        for (int j = 1; j <= noduri; j++)
            if (!okey[j] && adiacenta[nod][j] > 0)
            {
                okey[j] = 1;
                suma += adiacenta[nod][j];
                verificare(j);
                suma -= adiacenta[nod][j];
                okey[j] = 0;
            }
    }
    void afisare_Hamilton()
    {
        verificare(0);
        if (minim != 100000000)
            out << minim << "\n";
        else
            out << "Nu exista solutie\n";
    }
int main()
{
	citire_Hamilton();
    	afisare_Hamilton();
	return 0;
}
