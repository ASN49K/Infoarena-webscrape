﻿#include <bits/stdc++.h>
#include <random>
#include <chrono>
using namespace std;
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
const char nl = '\n';
const char sp = ' ';
const int inf = 0x3f3f3f3f;
const long long INF = 1000000000000000000;
const int mod = 1e9 + 7;
const char out[2][4]{ "NO", "YES" };
#define all(a) a.begin(), a.end()
using ll = long long;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");

#define variableName(var) #var
#define __debug(var) cout << #var << " = " << var << '\n'
inline int rint(int a, int b) { return uniform_int_distribution<int>(a, b)(rng); }

const int nmax = 18;
int n, m;
vector<pair<int, int>> g[nmax];
int dp[nmax][nmax][1 << nmax];

/*

dp[i][j][mask] = incep in i, sunt in j, am vizitat tot ce e in mask
dp[i][k][mask ^ (1 << k)] = dp[i][j][mask] + c
daca exista muchie de greutate c intre j si k
si daca k nu e inclus deja in mask

*/

int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    fin >> n >> m;
    for (int i = 0; i < m; ++i) {
        int u, v, w;
        fin >> u >> v >> w;
        g[u].push_back({ v, w });
    }
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            for (int mask = 0; mask < (1 << n); ++mask) {
                dp[i][j][mask] = inf;
            }
        }
        dp[i][i][1 << i] = 0;
    }
    for (int mask = 0; mask < (1 << n); ++mask) {
        vector<int> bits;
        for (int i = 0; i < n; ++i) {
            if ((mask >> i) & 1) {
                bits.push_back(i);
            }
        }
        for (auto& i : bits) {
            for (auto& j : bits) {
                if (dp[i][j][mask] != inf) {
                    for (auto& e : g[j]) {
                        int k = e.first, w = e.second;
                        if (!((mask >> k) & 1)) {
                            dp[i][k][mask ^ (1 << k)] = min(dp[i][k][mask ^ (1 << k)], dp[i][j][mask] + w);
                        }
                    }
                }
            }
        }
    }
    int ans = inf;
    for (int i = 0; i < n; ++i) {
        for (auto& e : g[i]) {
            int j = e.first, w = e.second;
            ans = min(ans, dp[j][i][(1 << n) - 1] + w);
        }
    }
    fout << ans;
}