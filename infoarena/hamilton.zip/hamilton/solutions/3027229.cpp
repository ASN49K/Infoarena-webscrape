#include <bits/stdc++.h>
#define INF 1e9

using namespace std;
ifstream fin ("hamilton.in");
ofstream fout ("hamilton.out");

int n, m, c[22][22], dp[1<<20][22];

int main()
{
    int x, y, z;
    ios_base::sync_with_stdio(0); fin.tie(0);
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y >> z;
        c[x][y] = z;
    }

    long long maxim = 1<<n;
    for (int i = 0; i <= maxim; i++)
        for (int j = 0; j <= 19; j++)
            dp[i][j] = INF;
    dp[1][0] = 0;
    for (int i = 3; i < maxim; i += 2)
        for (int j = 0; j < n; j++)
            if (i & (1 << j))
                for (int k = 0; k < n; k++)
                    if (c[k][j] && (i & (1<<k)))
                        dp[i][j] = min(dp[i][j], dp[i^(1<<j)][k] + c[k][j]);
    int minim = INF;
    for (int i = 0; i < n; i++)
        if (c[i][0])
            if (dp[maxim-1][i] + c[i][0] < minim)
                minim = dp[maxim-1][i] + c[i][0];
    if (minim = INF)
        fout << "Nu exista solutie";
    else
        fout << minim;
    return 0;
}
