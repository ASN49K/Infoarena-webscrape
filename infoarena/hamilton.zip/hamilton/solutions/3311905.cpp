#include <fstream>
#include <climits>
#define NMAX 20
#define INF (1<<20)
using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
int N,M,ok,A[NMAX][NMAX],x[NMAX],viz[NMAX];
long long cmin;

void citire()
{
    fin>>N>>M;

    for(int i=0; i<N; i++)
    {
        for(int j=0; j<N; j++)
        {
            A[i][j]=-1;
        }
    }

    int u,v,c;
    for(int i=0; i<M; i++)
    {
        fin>>u>>v>>c;
        A[u][v]=c;
    }
}

int estimare(int cost)
{
    int c=cost;

    for(int i=0; i<N; i++)
    {
        if(!viz[i])
        {
            int val=INF;
            for(int j=0; j<N; j++)
            {
                if(A[i][j]!=-1)
                {
                    val=min(val,A[i][j]);
                }
            }

            if(val<INF)
            {
                c+=val;
            }
        }
    }

    return c;
}

void BACK(int k, int cost)
{
    if(k==N)
    {
        if(A[x[N-1]][x[0]]!=-1)
        {
            if(cost+A[x[N-1]][x[0]]<cmin)
            {
                cmin=cost+A[x[N-1]][x[0]];
                ok=1;
            }
        }
        return;
    }

    if(estimare(cost)>=cmin)
    {
        return;
    }

    for(int i=1; i<N; i++)
    {
        if(!viz[i] && A[x[k-1]][i]!=-1)
        {
            viz[i]=1;
            x[k]=i;
            BACK(k+1,cost+A[x[k-1]][i]);
            viz[i]=0;
        }
    }
}

int main()
{
    citire();

    for(int i=0; i<N; i++)
    {
        viz[i]=0;
        x[i]=i;
    }

    cmin=INF;
    ok=0;
    BACK(1,0);

    if(ok)
    {
        fout << cmin << "\n";
    }
    else
    {
        fout << "Nu exista solutie\n";
    }
    return 0;
}
