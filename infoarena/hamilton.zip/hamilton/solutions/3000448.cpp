#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f ("hamilton.in");
ofstream g ("hamilton.out");
int dp[1<<18][20];
int n,m;
vector<pair<int,int>>adiacenta[20];
int main()
{
    f >> n >> m;
    for(int i= 1;i<=m;i++)
    {
        int x,y,c;
        f >> x >> y >> c;
        adiacenta[x].push_back({y,c});
    }

    for(int i = 0;i<(1<<18);i++)
    {
        for(int j = 0;j<20;j++)
            dp[i][j] = (1<<30)-1;
    }
    dp[1][0] = 0;
    for(int frecventa=2;frecventa<(1<<n);frecventa++)
    {
        for(int start = 0;start<n;start++)
        {
            if(((1<<start)&frecventa)!=0)
            {
                for(auto x:adiacenta[start])
                {
                    int nod = x.first;
                    int cost = x.second;
                    if((1<<nod)&frecventa)
                        dp[frecventa][nod] = min(dp[frecventa][nod],dp[frecventa^(1<<nod)][start]+cost);
                }
            }
        }
    }
    int rasp = (1<<30)-1;
    for(int start=1;start<n;start++)
    {
        for(auto x:adiacenta[start])
        {
            if(x.first ==0)
            {
                rasp = min(dp[(1<<n)-1][start]+x.second,rasp);
            }
        }
    }
    g << rasp;

}
