#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
#define EFC cin.tie(nullptr)->ios_base::sync_with_stdio(false)
int d1[5] = { 0, -1, 0, 1, 0 };
int d2[5] = { 0, 0, 1, 0, -1 };
const int mod = 666013;
const long long INF = 100000000000;
int d11[9] = { 0 , -1, -1, 0, 1, 1, 1, 0, -1 };
int d22[9] = { 0, 0, 1, 1, 1, 0, -1, -1, -1 };
int est[3] = { 0, -1, 0 };
int est1[3] = { 0, 0, 1 };
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");


//----------------------------------

int n, m, co[20][20], c[262150][20];
vector<vector<int>> adj(20);
int main() {


	fin >> n >> m;

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			co[i][j] = INF;
		}
	}
	for (int i = 1; i <= m; i++) {
		int x, y, cost;
		fin >> x >> y >> cost;
		adj[y].push_back(x);
		co[x][y] = cost;
	}

	for(int i = 0; i < n; i++){
		if(adj[i].size() % 2 != 0){
			fout << "Nu exista solutie";
			return;
		}
	}
	for (int i = 0; i < (1 << n); i++) {
		for (int j = 0; j < n; j++) {
			c[i][j] = INF;
		}
	}

	c[1][0] = 0;
	for (int i = 0; i < (1 << n); i++) {
		for (int j = 0; j < n; j++) {
			if (i & (1 << j)) {
				for (int k = 0; k < adj[j].size(); k++) {
					if (i & (1 << adj[j][k])) {
						c[i][j] = min(c[i][j], c[i ^ (1 << j)][adj[j][k]] + co[adj[j][k]][j]);
					}
				}
			}
		}
	}

	int ans = INF;
	for (int i = 0; i < adj[0].size(); i++) {
		ans = min(ans, c[(1 << n) - 1][adj[0][i]] + co[adj[0][i]][0]);
	}

	fout << ans;
}