#include <bits/stdc++.h>
using namespace std;
using i64 = int32_t;

#define ft first
#define sd second

const i64 INF = INT32_MAX / 2;

vector<pair<i64, i64>> g[18];

int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  // #ifdef LOCAL
  ifstream cin{"hamilton.in"};
  ofstream cout{"hamilton.out"};
  // #endif

  i64 n, m;
  cin >> n >> m;

  i64 x, y, c;
  for (i64 i = 0; i < m; i++) {
    cin >> x >> y >> c;
    g[y].push_back({x, c});
  }

  vector<vector<i64>> dp(1 << n, vector<i64>(n, INF));
  dp[1][0] = 0;
  for (i64 i = 0; i < (1 << n); i++) {
    for (i64 j = 0; j < n; j++) {
      if (!(i & (1 << j))) {
        continue;
      }

      for (auto& e : g[j]) {
        if (i & (1 << e.ft)) {
          dp[i][j] = min(dp[i][j], e.sd + dp[i & ~(1 << j)][e.ft]);
        }
      }
    }
  }

  i64 res = INF;
  i64 all = 1 << n;
  all--;
  for (auto& e : g[0]) {
    res = min(res, dp[all][e.ft] + e.sd);
  }

  if (res == INF) {
    cout << "Nu exista solutie" << endl;
  } else {
    cout << res << endl;
  }

  return 0;
}
