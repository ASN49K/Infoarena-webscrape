#include <fstream>

using namespace std;
ifstream f("hamilton.in");
ofstream g("hamilton.out");
const int N = 18;
const int INF = 1e9;

int c[N][N], dp[1 << N][N];

bool apartine(int element, int multime)
{
    return ((1 << element) & multime) == (1 << element);
}

int diferenta(int multime, int element)
{
    return (multime ^ (1 << element));
}

int main()
{

    int n, m;
    f >> n >> m;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (i != j)
            {
                c[i][j] = INF;
            }
        }
    }
    for (int i = 0; i < m; i++)
    {
        int x, y;
        f >> x >> y;
        f >> c[x][y];
    }
    f.close();
    for (int i = 0; i < (1 << n); i++)
    {
        for (int j = 0; j < n; j++)
        {
            dp[i][j] = INF;
        }
    }
    dp[1][0] = 0;
    for (int i = 3; i < (1 << n); i += 2)
    {
        for (int j = 1; j < n; j++)
        {
            if (apartine(j, i))
            {
                for (int k = 0; k < n; k++)
                {
                    if (k != j && apartine(k, i) && dp[diferenta(i, j)][k] + c[k][j] < dp[i][j])
                    {
                        dp[i][j] = dp[diferenta(i, j)][k] + c[k][j];
                    }
                }
            }
        }
    }

    int cmin = INF;
    for (int j = 1; j < n; j++)
    {
        cmin = min(cmin, dp[(1<<n) - 1][j] + c[j][0]);
    }
    if (cmin == INF)
    {
        g << "Nu exista solutie";
    }
    else
    {
        g << cmin;
    }
    g.close();
    return 0;
}
