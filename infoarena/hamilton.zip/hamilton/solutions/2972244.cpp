#include <bits/stdc++.h>
using namespace std;
const int nmx = 18;
const int mskmx = 1<<nmx;
const int inf = 1e7;
int dp[mskmx][nmx]; // drum min de la 0 la nodul j trecand prin nodurile din mask
int a[nmx][nmx];
#if 1
#define cin fin
#define cout fout
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
#endif // 0
int main(){
    int n,m;
    cin >> n >> m;
    for(int i=0;i<nmx;i++)
        for(int j=0;j<nmx;j++)
            a[i][j] = inf;
    for(int i=0;i<mskmx;i++)
        for(int j=0;j<nmx;j++)
            dp[i][j] = inf;

    while(m--){
        int u,v,w;
        cin >> u >> v >> w;
        a[u][v] = w;
    }
    int mskn = 1<<n;
    dp[1][0] = 0;
    for(int msk=3;msk<mskn;msk+=2){
        for(int i=1;i<n;i++){
            int bi = 1<<i;
            if(msk&bi){
                for(int j=0;j<n;j++){
                    dp[msk][i] = min(dp[msk][i],dp[msk^bi][j] + a[j][i]);
                }
            }
        }
    }
    int ans = inf;
    for(int i=1;i<n;i++){
        ans = min(ans, dp[mskn-1][i] + a[i][0]);
    }
    cout << (ans==inf ? "Nu exista solutie" : to_string(ans));
}
