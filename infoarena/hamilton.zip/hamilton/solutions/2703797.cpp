#include <bits/stdc++.h>

using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
int n,m,sol,x,y;
int cost[21][21];
int dp[270001][21];
vector<int>lista[21];
int main()
{
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        fin>>cost[x][y];
        lista[y].push_back(x);
    }
    for(int i=0;i<(1<<n);i++)
        for(int j=0;j<n;j++)
            dp[i][j]=100000000;
    dp[1][0]=0;
    for(int i=0;i<(1<<n);i++)
        for(int j=0;j<n;j++)
            if(i&(1<<j))
                for(int k=0;k<lista[j].size();k++)
                    if(i&(1<<lista[j][k]))
                        dp[i][j]=min(dp[i][j],dp[i^(1<<j)][lista[j][k]]+cost[lista[j][k]][j]);
    sol=100000000;
    for(int i=0;i<lista[0].size();i++)
        sol=min(sol,dp[(1<<n)-1][lista[0][i]]+cost[lista[0][i]][0]);
    if(sol==100000000)
        fout<<"Nu exista solutie";
    else
        fout<<sol;
    return 0;
}
