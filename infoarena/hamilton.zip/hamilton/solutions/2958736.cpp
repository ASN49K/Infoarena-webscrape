#include <bits/stdc++.h>

using namespace std;

ifstream fin("ciclueuler.in");
ofstream fout("ciclueuler.out");

int n, m, i, nr1, nr2, here, ok, viz[100001], grad[100001];
int vecin;

int main()
{
    fin >> n >> m;
    //init adjacency list; use stl list for easily deleting edges
    list <int> adjL[n+1];
    for (i = 0; i < m; ++i){
        fin >> nr1 >> nr2;
        ++grad[nr1];
        ++grad[nr2];
        adjL[nr1].push_back(nr2);
        adjL[nr2].push_back(nr1);
    }
    vector <int> ciclu;

    //bfs to see if its connected
    queue <int> q;
    q.push(1);
    viz[1] = 1;
    while (!q.empty()){
        here = q.front();
        q.pop();
        for (auto &k : adjL[here]){
            if (viz[k] == 0){
                q.push(k);
                viz[k] = 1;
            }
        }
    }
    ok = 1; ///1 means its an eulerian graph
    for (i = 1; i <= n; ++i){
        if (viz[i] == 0 || (grad[i] & 1) == 1){
            ok = 0;
            break;
        }
    }

    if (ok == 0){
        fout << -1;
        return 0;
    }


    ///iterative eulerian path simulating recursivity
    ciclu.reserve(2*m+1);
    stack <int> recurs;
    recurs.push(1);

    while (!recurs.empty()){
        here = recurs.top();
        if (!adjL[here].empty()){
            vecin = adjL[here].front();
            adjL[here].pop_front();
            for (auto j = adjL[vecin].begin(); j != adjL[vecin].end(); ++j)
                if (*j == here){
                    adjL[vecin].erase(j);
                    break;
                }
            recurs.push(vecin);
            continue;
        }
        ciclu.push_back(here);
        recurs.pop();
    }
    for (i = ciclu.size()-1; i >= 1; --i){
        fout << ciclu[i] << ' ';
    }
    return 0;
}
