#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("dijkstra.in");
ofstream fout("dijkstra.out");

struct nod{
    int val;
    long long cost;
    bool operator < (const nod &other) const{
        return cost > other.cost;
    }
};

const long long nmax=5e4 +5, inf = 0x3f3f3f3f;
vector<nod> G[nmax];
long long dist[nmax], n;
priority_queue<nod> heap;

void dijkstra(int start){
    for(int i=1; i<=n; i++)
        dist[i]=inf;
    dist[start]=0;
    heap.push({start, 0});
    while(!heap.empty())
    {
        nod cur = heap.top();
        heap.pop();
        if(dist[cur.val]  < cur.cost)
            continue;
        for(nod vecin: G[cur.val])
        {
            if(dist[cur.val] + vecin.cost < dist[vecin.val])
            {
                dist[vecin.val] = dist[cur.val] + vecin.cost;
                heap.push({vecin.val, dist[vecin.val]});
            }
        }
    }
}

int main()
{
    int m;
    fin >> n >> m;
    int x, y, z;
    for(int i=0; i<m; i++)
    {
        fin >> x >> y >> z;
        G[x].push_back({y, z});
    }
    dijkstra(1);
    for(int i=2; i<=n; i++)
    {
        if (dist[i] == inf)
            dist[i] = 0;
        fout << dist[i] << ' ';
    }
    return 0;
}
