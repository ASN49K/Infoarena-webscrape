#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>
#include <queue>
#define INF 100000000
using namespace std;
ifstream f("hamilton.in");
ofstream g("hamilton.out");
int n,m,x,y,z,dist[19][(1<<18)+1],min1cost=INF;
vector <vector <int>> v(19),cost(19);
queue <pair<int,int>> q;
void searcht (int start)
{
    q.push(make_pair((1<<start),start));
    while (!q.empty())
    {
        int viz=q.front().first,cur=q.front().second;
      //  cout<<cur<<'\n';
       // cout<<viz<<' '<<cur<<' '<<dist[cur][viz]<<'\n';
        if (viz==(1<<(n))-1)
        {
            //cout<<"DA";
            for (int j=0; j<v[cur].size(); j++)
            {
                if (v[cur][j]==start)
                {
                    dist[start][viz]=dist[cur][viz]+cost[cur][j];
                }
            }
        }
        else
        {
        for (int j=0; j<v[cur].size(); j++)
        {
            //cout<<!(viz & (1<<v[cur][j]))<<'\n';
            if (!(viz & (1<<v[cur][j])) && (dist[v[cur][j]][viz+(1<<v[cur][j])]>dist[cur][viz]+cost[cur][j] || dist[v[cur][j]][viz+(1<<v[cur][j])]==0))
            {

                dist[v[cur][j]][viz+(1<<v[cur][j])]=dist[cur][viz]+cost[cur][j];
               // cout<<v[cur][j]<<' '<<dist[v[cur][j]][viz+(1<<v[cur][j])]<<'\n';
                q.push(make_pair(viz+(1<<v[cur][j]),v[cur][j]));
            }
        }
        }
        //cout<<'\n';
        q.pop();
    }
}
int main()
{
    //cout<<sizeof(dist)/1000000;
    f>>n>>m;
    for (int i=1; i<=m; i++)
    {
        f>>x>>y>>z;
        v[x].push_back(y);
        cost[x].push_back(z);
    }
    for (int start=0; start<n; start++)
    {
        for (int j=0; j<n; j++)
        {
            memset(dist[j],0,sizeof(dist[j]));
        }
        searcht(start);
       // cout<<'\n';

        //cout<<min1cost<<'\n';
        if (dist[start][(1<<(n))-1]>0)
                min1cost=min(min1cost,dist[start][(1<<(n))-1]);
    }
    if (min1cost!=INF)
    g<<min1cost;
    else
    {
        g<<"Nu exista solutie";
    }
    return 0;
}
