
#include <fstream>
using namespace std;
ifstream cin("hamilton.in");
ofstream cout("hamilton.out");
int n,m;
int v[20][20];
int dp[(1<<19)][20];
int x,y,c;
int main()
{
    cin>>n>>m;
    for(int i=0;i<n;i++)
       for(int j=0;j<n;j++)
          v[i][j]=0x3f3f3f3f;
    for(int i=0;i<m;i++)
    {
        cin>>x>>y>>c;
        v[y][x]=c;
    }
    dp[1][0]=0;
    for(int mask=2;mask<(1<<n);mask++)
        for(int i=0;i<n;i++)
          if(mask & (1<<i))
          {
              int new_mask=mask^(1<<i);
              dp[mask][i]=0x3f3f3f3f;
              for(int j=0;j<n;j++)
                 if(new_mask & (1<<j))
                   dp[mask][i]=min(dp[mask][i],dp[new_mask][j]+v[i][j]);
          }
    int ans=0x3f3f3f3f;
    for(int i=1;i<n;i++)
       ans=min(ans,dp[(1<<n)-1][i]+v[0][i]);
    if(ans==0x3f3f3f3f)
      cout<<"Nu exista solutie";
    else
      cout<<ans;
    return 0;
}
