#include <fstream>
#include <climits>
#define NMAX 20
#define INF (1<<20)
using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
int N,M,cmin,ok,A[NMAX][NMAX],x[NMAX];

void citire()
{
    fin>>N>>M;

    for(int i=0; i<N; i++)
    {
      for(int j=0; j<N; j++)
      {
          A[i][j]=-1;
      }
    }

    int u,v,c;
    for(int i=0; i<M; i++)
    {
        fin>>u>>v>>c;
        A[u][v]=c;
    }
}

void prelucrare_sol()
{
    int c=0;

    for(int i=1; i<N; i++)
    {
        if(A[x[i-1]][x[i]]==-1)
        {
            return;
        }

        c+=A[x[i-1]][x[i]];

        if(c>=cmin)
        {
            return;
        }
    }

    if(A[x[N-1]][x[0]]==-1)
    {
        return;
    }
    c+=A[x[N-1]][x[0]];

    if(c<cmin)
    {
        cmin=c;
        ok=1;
    }
}

void BACK(int k)
{
    if(k==1)
    {
        prelucrare_sol();
        return;
    }

    for(int i=0; i<k; i++)
    {
        BACK(k-1);

        if(k%2==1)
        {
            swap(x[0],x[k-1]);
        }
        else
        {
             swap(x[0],x[k-1]);
        }
    }
}

int main()
{
    citire();

    for(int i=0; i<N; i++)
    {
        x[i]=i;
    }

    cmin=INF;
    ok=0;
    BACK(N);

    if(ok)
    {
        fout << cmin << "\n";
    }
    else
    {
        fout << "Nu exista solutie\n";
    }
    return 0;
}
