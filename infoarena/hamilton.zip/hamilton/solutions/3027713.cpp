#include <bits/stdc++.h>
#include <fstream>
#define oo 1e9
#define cin fin
#define cout fout
using namespace std;
ifstream cin ("hamilton.in");
ofstream cout ("hamilton.out");
vector<pair<int,int>>G[20];
int i,a,b,c,n,m,lim,j,dp[300008][20],sol;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>n>>m;
    for(i=1; i<=m; i++)
    {
        cin>>a>>b>>c;
        G[b].push_back({a,c});
    }
    lim=(1<<n)-1;
    for(i=1; i<=lim; i++)
    {
        for(j=0; j<n; j++)
            dp[i][j]=oo;
    }
    dp[1][0]=0;
    for(i=3; i<=lim; i=i+2)
    {
        for(j=0; j<n; j++)
        {
            if(i&(1<<j))
            {
                for(auto k:G[j])
                {
                    if(i&(1<<k.first))
                        dp[i][j]=min(dp[i][j],dp[i-(1<<j)][k.first]+k.second);
                }
            }
        }
    }
    sol=oo;
    for(auto i:G[0])
    {
        sol=min(sol,dp[lim][i.first]+i.second);
    }
    cout<<sol;
    return 0;
}
