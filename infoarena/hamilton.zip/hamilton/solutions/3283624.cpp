#include <iostream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin ("hamilton.in");
ofstream fout ("hamilton.out");
const int N = 1e5 + 5, INF = 1e9;

int n, m, dp[20][(1ll << 19)], graf[20][20];


int main()
{
    ios_base::sync_with_stdio(0);
    int i,j,k;
    fin>>n>>m;
	for (int i = 1; i <= m; i++) {
		int x, y, c;
		fin >> x >> y >> c;
		graf[x][y] = c;
	}
	/// dp[i][mask] = lungimea minima a unui lant hamiltonian care se termina in nodul i si contine masca de noduri
	/// dp[i][mask] = min(dp[i][mask], dp[j][mask ^ (1ll << i)] + muchia(j, i));
	for (int i = 0; i < n; i++) {
		for (int mask = 0; mask < (1ll << n); mask++) {
			dp[i][mask] = INF;
		}
	}
    dp[0][1]=0;
    for(int bitmask = 1; bitmask<(1ll<<n); bitmask++)
    {
        for(i=0;i<n;i++) // ultimul nod pe care il adaugam la un dp anterior pentru a obtine dp[masca]
        {
            if(bitmask & (1ll<<i)) // daca nodul i apartine drumului specificat de masca
            {
                for(j=0;j<n;j++) // ultimul dp de la care puteam ajunge
                {
                    if(i!=j && graf[j][i] && (bitmask & (1ll<<j)))
                    {
                        dp[i][bitmask] = min(dp[i][bitmask] , dp[j][bitmask ^ (1ll<<i)] + graf[j][i]);
                    }
                }
            }
        }
    }

	dp[0][1] = 0;
	for (int mask = 1; mask < (1ll << n); mask++) {
		for (int i = 0; i < n; i++) {
			if (mask & (1ll << i)) {
				for (int j = 0; j < n; j++) {
					if (i != j && grid[j][i] && (mask & (1ll << j))) {
						dp[i][mask] = min(dp[i][mask], dp[j][mask ^ (1ll << i)] + grid[j][i]);
					}
				}
			}
		}
	}
	/*

	int ans = INF;
	for (int i = 1; i < n; i++) {
		if (graf[i][0])
			ans = min(ans, dp[i][(1ll << n) - 1] + graf[i][0]);
	}
	if (ans != INF)
		fout << ans;
	else
		fout << "Nu exista solutie";

		*/

    minim=INF;
    for(i=1;i<n;i++)
    {
        if(graf[i][0])
            minim=min(minim,dp[i][(1ll<<n)-1]+graf[i][0]);
    }
    if(maxim!=INF)
        fout<<minim<<'\n';
    else
        fout<<"Nu exista solutie\n";



    return 0;
}
