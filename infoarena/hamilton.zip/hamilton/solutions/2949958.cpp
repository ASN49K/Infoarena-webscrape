#include <fstream>

using namespace std;
ifstream f("hamilton.in");
ofstream g("hamilton.out");
int n,m,i,j,x,y,z,b[19][19],a[19][1<<18];
int oo=1e9;
int main()
{
    f>>n>>m;
    for(int i=0;i<n;i++)
        for(int j=0;j<(1<<n);j++)
            a[i][j]=oo;
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            b[i][j]=oo;
    for(int i=1;i<=m;i++)
    {
        f>>x>>y>>z;
        b[x][y]=z;
    }
    a[0][1]=0;
    for(int j=1;j<(1<<n);j++)
        for(int i=0;i<n;i++)
            if(j&(1<<i))
                for(int k=0;k<n;k++)
                    if((1<<k)&j)
                        a[i][j]=min(a[i][j],b[k][i]+a[k][(j^(1<<i))]);
    int smin=oo;
    for(int i=1;i<n;i++)
        smin=min(smin,a[i][(1<<n)-1]+b[i][0]);
    g<<smin;
    return 0;
}
