#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream fin("hamilton.in");
ofstream fout("hamilton.out");

struct arc{
    int nod;
    int cost;
};

const int nmax=20, inf=1e7;
vector<arc> G[nmax];
int dp[nmax][(1<<nmax)];

int main()
{
    for(int i=0; i<nmax; i++)
        for(int j=2; j<(1<<nmax); j++)
            dp[i][j]= inf;
    int n, m;
    fin >> n >> m;
    int x, y, c;
    for(int i=0; i<m; i++)
    {
        fin >> x >> y >> c;
        G[x].push_back({y, c});
    }
    for(int val=1; val<(1<<n); val++)
    {
        for(int k=0; k<n; k++)
            if(((val)|(1<<k))==(val))
                for(auto vecin: G[k])
                    if(((val)|(1<<vecin.nod))!=(val))
                        dp[vecin.nod][(val)|(1<<vecin.nod)]=min(dp[vecin.nod][(val)|(1<<vecin.nod)],dp[k][val]+vecin.cost);
    }
    int ans=inf;
    for(int i=1; i<n; i++)
        for(auto vecin: G[i])
            if(vecin.nod==0)
                ans=min(ans, dp[i][(1<<n)-1]+vecin.cost);
    if(ans==inf)
        fout << "Nu exista solutie";
    else
        fout << ans;
    return 0;
}
