#include <bits/stdc++.h>

using namespace std;

const int N = 18;
const long long INF = (1<<27);
int n, cost[N][N], dp[1<<N][N];

void extinde(int multime, int vf)
{
    for (int j = 1; j <= n; j++)
    {
        if (cost[vf][j] != INF && (multime & (1 << j)) == 0)
        {
            int multime_noua = (multime | (1 << j));
            if (dp[multime][vf] + cost[vf][j] < dp[multime_noua][j])
            {
                dp[multime_noua][j] = dp[multime][vf] + cost[vf][j];
            }
        }
    }
}

int main()
{

    ifstream cin("hamilton.in");
    ofstream cout("hamilton.out");

    int m;
    cin >> n >> m;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cost[i][j] = INF;
        }
        cost[i][i] = 0;
    }
    for (int i = 0; i < m; i++)
    {
        int x, y, c;
        cin >> x >> y >> c;
        cost[x][y] = c;
    }
    for (int i = 1; i < (1 << n); i++)
    {
        for (int j = 0; j < n; j++)
        {
            dp[i][j] = INF;
        }
    }
    dp[1][0] = 0;

    for (int i = 1; i < (1 << n); i += 2)
    {
        for (int j = 0; j < n; j++)
        {
            if (dp[i][j] != INF)
            {
                extinde(i, j);
            }
        }
    }

    int rez = INF, toti = (1 << n) - 1;
    for (int j = 0; j < n; j++)
    {
        if (dp[toti][j] + cost[j][0] < rez)
        {
            rez = dp[toti][j] + cost[j][0];
        }
    }
    if (rez != INF)
    {
        cout << rez;
    }
    else
    {
        cout << "Nu exista solutie";
    }
    return 0;
}
