#include <bits/stdc++.h>
#define NMAX 20
#define INF 0x3f3f3f3f

using namespace std;

ifstream f("hamilton.in");
ofstream g("hamilton.out");

int n, m;
vector <int> edges[NMAX];
int cost[NMAX][NMAX];
int dp[(1 << NMAX)][NMAX];

int main()
{
    f >> n >> m;

    for(int i = 0 ; i < n; i++)
        for(int j = 0; j < n; j++)
            cost[i][j] = INF;

    for(int i = 1; i <= m; i++)
    {
        int x, y, c;
        f >> x >> y >> c;
        edges[y].push_back(x);
        cost[x][y] = c;
    }



    for(int i = 0; i < 1 << n; i++)
        for(int j = 0; j < n; j++)
            dp[i][j] = INF;

    dp[1][0] = 0;
    for(int i = 0; i < 1 << n; i++)
        for(int j = 0; j < n; j++)
            if(i & (1 << j))
                for(auto k : edges[j])
                    if(i & (1 << k))
                        dp[i][j] = min(dp[i][j], dp[i ^ (1 << j)][k] + cost[k][j]);

    int sol = INF;
    for(auto k : edges[0])
        sol = min(sol, dp[(1 << n) - 1][k] + cost[k][0]);

    if(sol == INF)
        g << "Nu exista solutie";
    else
        g << sol;

    return 0;
}
