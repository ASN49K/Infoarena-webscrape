#include <bits/stdc++.h>
#include <fstream>
using namespace std;
typedef long long int64;
typedef vector<int> vec;
typedef vector<int64> vec64;
    string __fname = "hamilton";
    ifstream in (__fname + ".in");
    ofstream out (__fname + ".out");
    #define cin in
    #define cout out
#define ss cout << " ";
#define nn cout << "\n";
#define ct(x) cout << x;
#define cts(x) cout << x << " ";
#define ctn(x) cout << x << "\n";
#define db(x) cout << "> " << #x << ": " << x << "\n";
#define qr queries();
void solve(int);
void YN(bool b){if (b){ctn("YES");}else{ctn ("NO");}};
void yn(bool b){if (b){ctn("Yes");}else{ctn ("No");}};
void queries(){int n;cin >> n;for (int i = 1; i <= n; i++) solve(i);}
int64 ceildiv(int64 a, int64 b) {return a / b + !!(a % b);}
// // // // // // // // // // // // // // // // // // // // // // 
/*                  TEMPLATE - VANILLA                         */
// // // // // // // // // // // // // // // // // // // // // //
const int maxn = 200200;
const int64 mod = 1000000007;
const double pi = 3.14159265359;
const int ddx[] = {-1, -1, 0, 1, 1, 1, 0, -1};
const int ddy[] = {0, 1, 1, 1, 0, -1, -1, -1};
const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};
int c[20][20];
vector <int> v[20];
int dp[(1 << 20)][20];
 
void solve(int id){

    return;
}
 
 
int main(){
    ios_base::sync_with_stdio(0);cin.tie(0);
    int n,m;
    cin >> n >> m;
    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++){
            c[i][j] = 1e8;
        }
    }
    for (int i = 0; i < m; i++){
        int x,y,z;
        cin >> x >> y >> z;
        c[x][y] = z;
        v[y].push_back(x);
    }
    for (int i = 0; i < (1 << n); i++){
        for (int j = 0; j < n; j++){
            dp[i][j] = 1e8;
        }
    }
    dp[1][0] = 0;
    for (int i = 1; i < (1 << n); i++){
        for (int j = 1; j < n; j++){
            if (i & (1 << j)) {
                for (int k = 0; k < v[j].size(); k++){
                    int node = v[j][k];
                    if (!(i & (1 << node))) continue;
                    dp[i][j] = min(dp[i][j], dp[i ^ (1 << j)][node]) + c[node][j];
                }
            }
        }
    }
    int rs = 1e8;
    for (int i = 1; i < n; i++){
        rs = min(rs, dp[(1 << n) - 1][i] + c[i][0]);
    }
    if (rs == 1e8) {
        ctn("Nu exista solutie");
    }
    else{
        ctn(rs);
    }
    return 0;
}
