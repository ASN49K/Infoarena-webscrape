	
#include <bits/stdc++.h>
#define oo 0x3f3f3f3f
 
using namespace std;
ifstream f("hamilton.in");
ofstream g("hamilton.out");
int n, m;
int cost[20][20];
int dp[1 << 18][20];
vector<int> graf[20];
 
void read()
{
  f>>n>>m;
  int x, y;
  for(int i = 0;i < n;++i)
    for(int j = 0;j < n;++j)
      cost[i][j] = oo;
 
  for(int i = 1;i <= m;++i) 
    f>>x>>y, f>>cost[x][y], graf[y].push_back(x);
}
 
int hamilton(int configuration, int node)
{
  if(dp[configuration][node] == -1)
  {
    dp[configuration][node] = oo;
 
    for(auto it : graf[node])
      if(configuration & (1 << it))
        {
          if(it == 0 && configuration != (1 << node)  + 1) continue;
 
          dp[configuration][node] = min(dp[configuration][node], hamilton(configuration ^ (1 << node), it) + cost[it][node]);
        }
  }
  return dp[configuration][node];
}
 
void solve()
{
  memset(dp, -1, sizeof(dp));
  dp[1][0] = 0;
 
  int result = oo;
 
  for(auto it : graf[0])
    result = min(result, hamilton((1 << n) - 1, it) + cost[it][0]);
  
  if(result < oo)
    g<<result;
  else
    g<<"Nu exista solutie";
}
 
int main()
{
  read();
  solve();
  return 0;
}