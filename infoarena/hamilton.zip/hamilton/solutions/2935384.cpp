#include <stdio.h>
#include <climits>
#include <vector>
using namespace std;

const int MAX_N = 19;
int dp[MAX_N][(1 << MAX_N)];
int cost[MAX_N][MAX_N];

vector <int> graph[MAX_N];

int main() {
  FILE *fin, *fout;
  int n, m;
  int i, j;
  int a, b, c;
  int mask, res;

  fin = fopen("hamilton.in", "r");
  fout = fopen("hamilton.out", "w");

  fscanf(fin, "%d%d", &n, &m);
  for (i = 0; i < n; i++)
    for (j = 0; j < n; j++)
      cost[i][j] = INT_MAX / 2;
  for (i = 1; i <= m; i++) {
      fscanf(fin, "%d%d%d", &a, &b, &c);
      cost[a][b] = c;
      graph[a].push_back(b);
      graph[b].push_back(a);
  }
  for (mask = 0; mask < (1 << n); mask++)
    for (i = 0; i < n; i++)
      dp[i][mask] = INT_MAX / 2;
  dp[0][1] = 0;
  for (mask = 1; mask < (1 << n); mask++) {
    for (i = 0; i < n; i++)
      if (mask & (1 << i))
        for (int u : graph[i])
          if (mask & (1 << u))
            dp[i][mask] = min(dp[u][mask - (1 << i)] + cost[u][i], dp[i][mask]);
    }

  res = INT_MAX / 2;
  for (i = 0; i < n; i++)
    res = min(res, dp[i][(1 << n) - 1] + cost[i][0]);

  if (res == INT_MAX / 2)
    fprintf(fout, "Nu exista solutie");
  else
    fprintf(fout, "%d", res);

  fclose(fin);
  fclose(fout);

    return 0;
}
