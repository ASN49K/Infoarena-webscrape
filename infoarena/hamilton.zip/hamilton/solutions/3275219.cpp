#include <vector>
#include <iostream>
#include <stack>
#include <algorithm>
#include <queue>
#include <fstream>
#include <iomanip>
#include <map>
#include <cmath>
#include <set>
#include <string>
#include <iomanip>
using namespace std;

ifstream in ("hamilton.in");
ofstream out ("hamilton.out");

int n, m, x, y, c, dp[(1 << 18)][18], ans;
vector <pair <int, int> > adj[18];

void solve()
{
    in >> n >> m;

    for (int i = 0; i < (1 << n); i ++)
        for (int j = 0; j < n; j ++)
            dp[i][j] = 1e9;

    for (int i = 1; i <= m; i ++)
    {
        in >> x >> y >> c;

        adj[y].push_back(make_pair(x, c));
    }

    dp[1][0] = 0;
    for (int bitmask = 0; bitmask < (1 << n); bitmask ++)
    {
        for (int j = 0; j < n; j ++)
            if (bitmask & (1 << j))
            {
                for (int i = 0; i < adj[j].size(); i ++)
                    if (bitmask & (1 << adj[j][i].first))
                        dp[bitmask][j] = min (dp[bitmask][j], dp[bitmask - (1 << j)][adj[j][i].first] + adj[j][i].second);
            }
    }

    ans = 1e9;
    for (int i = 0; i < adj[0].size(); i ++)
        ans = min (ans, dp[(1 << n) - 1][adj[0][i].first] + adj[0][i].second);

    if (ans < 1e9)
        out << ans;
    else
        out << "Nu exista solutie";
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    solve();
    return 0;
}
