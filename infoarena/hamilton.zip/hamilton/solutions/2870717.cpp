#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
ifstream f("hamilton.in");
ofstream g("hamilton.out");
int n,m;
vector<pair<int,int>>adiacenta[19];
int dp[(2<<18)][20];
void citire()
{
    f >> n>>m;
    for(int i = 1;i<=m;i++)
    {
        int x,y,c;
        f >> x >> y >> c;
        adiacenta[x].push_back({y,c});
    }

}
void init()
{
    for(int i = 0;i<(1<<n);i++)
    {
        for(int j =0;j<19;j++)
            dp[i][j] = (1<<30)-1;
    }
}
void calc()
{
    dp[1][0] = 0;
    for(int i = 2;i<=(1<<n)-1;i++)
    {
        for(int nod_inceput = 0;nod_inceput<n;nod_inceput++)
        {
            if((i&(1<<nod_inceput))!=0)
            {
                for(auto x:adiacenta[nod_inceput])
                {
                    int nod = x.first;
                    int cost = x.second;

                    if((i&(1<<nod))!=0)
                    {
                        dp[i][nod] = min(dp[i][nod],dp[i^(1<<nod)][nod_inceput]+cost);
                    }
                }
            }
        }
    }
}
int aflare_rasp_final()
{
    int mini = (1<<30)-1;
    for(int i = 1;i<n;i++)
    {
        for(auto x:adiacenta[i])
        {
            if(x.first == 0)
                {
                    mini = min(dp[(1<<n)-1][i]+x.second,mini);
                }
        }
    }
    if(mini == (1<<30)-1)
        {
            g <<"Nu exista solutie";
            exit(0);
        }

    return mini;
}
int main()
{
    citire();
    init();
    calc();
    g <<aflare_rasp_final();
}
