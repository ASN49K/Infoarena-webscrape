#include <fstream>
#include <vector>
#define NMAX 262150 // 2^18 = 262144
#define INF 0x3f3f3f3f

using namespace std;

ifstream fin("hamilton.in");
ofstream fout("hamilton.out");

vector<int> G[20];
int c[20][20], n, m, x, y, dp[NMAX][20], ans = INF;

int main() {
    fin >> n >> m;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            c[i][j] = INF;
        }
    }
    for(int i = 0; i < (1 << n); i++) {
        for(int j = 0; j < n; j++) {
            dp[i][j] = INF;
        }
    }
    dp[1][0] = 0;
    for(int i = 1; i <= m; i++) {
        fin >> x >> y >> c[x][y];
        G[y].push_back(x);
    }
    for(int i = 0; i < (1 << n); i++) {
        for(int j = 0; j < n; j++) {
            if(i & (1 << j)) {
                for(int k = 0; k < (int) G[j].size(); k++) {
                    int nod = G[j][k];
                    if(i & (1 << nod)) {
                        dp[i][j] = min(dp[i][j], dp[i ^ (1 << j)][nod] + c[nod][j]);
                    }
                }
            }
        }
    }
    for(int i = 0; i < (int) G[0].size(); i++) {
        int nod = G[0][i];
        ans = min(ans, dp[(1 << n) - 1][nod] + c[nod][0]);
    }
    fout << (ans == INF ? "Nu exista solutie" : to_string(ans)) << "\n";
    return 0;
}