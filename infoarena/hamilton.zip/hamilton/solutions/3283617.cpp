#include <iostream>
#include <bits/stdc++.h>
#define VMAX 18
#define INF 2000000000
using namespace std;
ifstream fin ("hamilton.in");
ofstream fout ("hamilton.out");


int graf[20][20];
int dp[20][(1ll)<<19];


int main()
{
    ios_base::sync_with_stdio(0);
    int n,m,i,j,k,t,q,nr,minim,maxim,suma;
    fin>>n>>m;
	for (int i = 1; i <= m; i++) {
		int x, y, c;
		cin >> x >> y >> c;
		graf[x][y] = c;
	}
	// dp[i][mask] = lungimea minima a unui lant hamiltonian care se termina in nodul i si contine masca de noduri
	// dp[i][mask] = min(dp[i][mask], dp[j][mask ^ (1ll << i)] + muchia(j, i));
	for (int i = 0; i < n; i++) {
		for (int mask = 0; mask < (1ll << n); mask++) {
			dp[i][mask] = INF;
		}
	}
	dp[0][1] = 0;
	for (int mask = 1; mask < (1ll << n); mask++) {
		for (int i = 0; i < n; i++) {
			if (mask & (1ll << i)) {
				for (int j = 0; j < n; j++) {
					if (i != j && graf[j][i] && (mask & (1ll << j))) {
						dp[i][mask] = min(dp[i][mask], dp[j][mask ^ (1ll << i)] + graf[j][i]);
					}
				}
			}
		}
	}

	int ans = INF;
	for (int i = 1; i < n; i++) {
		if (graf[i][0])
			ans = min(ans, dp[i][(1ll << n) - 1] + graf[i][0]);
	}
	if (ans != INF)
		cout << ans;
	else
		cout << "Nu exista solutie";



    return 0;
}
