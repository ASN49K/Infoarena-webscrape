#include <bits/stdc++.h>

using namespace std;

ifstream f("hamilton.in");
ofstream g("hamilton.out");

struct muchii{
    int node, cost;
};

int n,m,x,y,z,minim,dp[300000][20],edge[20][20];

int32_t main()
{
    f>>n>>m;
    for(int i=1; i<=m; i++)
        f>>x>>y>>z, edge[x][y]=z;
    for(int mask=1; mask<=(1<<n)-1; mask++)
        for(int i=0; i<n; i++)
            dp[mask][i]=INT_MAX;
    dp[1][0]=0, minim=INT_MAX;
    for(int mask=1; mask<(1<<n)-1; mask++)
        for(int i=0; i<n; i++)
            if(dp[mask][i]!=INT_MAX)
                for(int j=0; j<n; j++)
                {
                    if(edge[i][j] and ((1<<j)&mask)==0)
                    {
                        int fakemask=(mask|(1<<j));
                        dp[fakemask][j]=min(dp[fakemask][j],dp[mask][i]+edge[i][j]);
                    }
                }
    for(int i=1; i<n; i++)
        if(edge[i][0] and dp[(1<<n)-1][i]!=INT_MAX)
            minim=min(minim,dp[(1<<n)-1][i]+edge[i][0]);
    if(minim==INT_MAX)
        g<<"Nu exista solutie";
    else
        g<<minim;
    return 0;
}
