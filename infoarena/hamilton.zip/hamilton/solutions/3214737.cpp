#include <bits/stdc++.h>

#pragma optimize GCC ("Ofast")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

///#include <tryhardmode>
///#include <GODMODE::ON>

using namespace std;

#define cin fin
#define cout fout

ifstream fin ("hamilton.in");
ofstream fout ("hamilton.out");

const int NMAX=25;
const int MASK=(1<<21);
const int INF=2e9;

int dp[MASK][NMAX];
int v[NMAX][NMAX];

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n,m,i,j,mask,best=INF;;
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        int x,y,c;
        cin>>x>>y>>c;
        v[x][y]=c;
    }
    for(i=0;i<(1<<n);i++)
        for(j=0;j<n;j++)
            dp[i][j]=INF;
    dp[0][0]=dp[1][0]=0;
    for(mask=0;mask<(1<<n);mask++)
    {
        for(i=0;i<n;i++)
        {
            if(mask & (1<<i))
            {
                for(j=0;j<n;j++)
                {
                    if(!(mask & (1<<j)) && v[i][j])
                        dp[mask^(1<<j)][j]=min(dp[mask^(1<<j)][j],dp[mask][i]+v[i][j]);
                }
            }
        }
    }
    for(i=0;i<n;i++)
    {
        if(v[i][0])
            best=min(best,dp[(1<<n)-1][i]+v[i][0]);
    }
    if(best==INF)
        cout<<"Nu exista solutie";
    else
        cout<<best;
    return 0;
}
