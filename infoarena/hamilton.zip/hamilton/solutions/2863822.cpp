#include <iostream>
#include <fstream>
#include <vector>
#include <limits.h>
#include <queue>
#include <algorithm>
#define NMAX 1000001
///HAMILTON.
using namespace std;
ifstream f("hamilton.in");
ofstream g("hamilton.out");
int n,m,a,b,c,Total,RG[NMAX],TT[NMAX],k;
pair < int,int > P[NMAX];
struct Muchii
{
    int x;
    int y;
    int c;
}U[NMAX];
bool Compara(Muchii a ,Muchii b)
{
    return a.c < b.c;
}
void Citire()
{
    f>>n;
    f>>m;
    for(int i=1;i<=m;i++)
    {
        f>>U[i].x;
        f>>U[i].y;
        f>>U[i].c;
    }
}
int Gasit(int Nod)
{
    while(TT[Nod]!=Nod)
        Nod=TT[Nod];
    return Nod;
}
void Unire(int x,int y)
{
    if(RG[x]<RG[y])
        TT[x]=y;
    if(RG[x]>RG[y])
        TT[y]=x;
    if(RG[x]==RG[y])
    {
        TT[x]=y;
        RG[y]++;
    }
}
void Rezolvare()
{
    int Nod;
    for(int i=1;i<=n;i++)
    {
        if(Gasit(U[i].x)!=Gasit(U[i].y))
        {
            Unire(Gasit(U[i].x),Gasit(U[i].y));
            k++;
            P[k].first=U[i].x;
            P[k].second=U[i].y;
            Total=Total+U[i].c;
        }
    }
}
void Afisare()
{
    g<<Total<<'\n';
    for(int i=1;i<=k;i++)
    {
        cout<<P[i].first<<' '<<P[i].second<<'\n';
    }
}
int main()
{
    Citire();
    for(int i=1;i<=n;i++)
    {
        TT[i]=i;
        RG[i]=1;
    }
    sort(U+1,U+m,Compara);
    Rezolvare();
    Afisare();

    return 0;
}
