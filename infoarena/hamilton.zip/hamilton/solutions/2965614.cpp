#include <bits/stdc++.h>
std::ifstream cin("hamilton.in");
std::ofstream cout("hamilton.out");
int n,m,ans[1000000][20],x,y,c;
int a[20][20];
int main()
{
    cin>>n>>m;
    for(int i=0;i<n;++i)
        for(int j=0;j<n;++j)
            a[i][j]=1000000000;
    for(int i=0;i<(1<<n);++i)
        for(int j=0;j<n;++j)
            ans[i][j]=1000000000;
    for(int i=1;i<=m;++i)
    {
        cin>>x>>y>>c;
        a[x][y]=std::min(a[x][y],c);
    }
    ans[0][0]=0;
    for(int i=0;i<(1<<n);++i)
    {
        for(int b=0;b<n;++b)
            if(ans[i][b]!=1000000000)
                for(int e=0;e<n;++e)
                    if((i&(1<<e))==0)
                        ans[i+(1<<e)][e]=std::min(ans[i+(1<<e)][e],ans[i][b]+a[b][e]);
    }
    if(ans[(1<<n)-1][0]==1000000000)
        cout<<"Nu exista solutie";
    else
        cout<<ans[(1<<n)-1][0];
    return 0;
}
