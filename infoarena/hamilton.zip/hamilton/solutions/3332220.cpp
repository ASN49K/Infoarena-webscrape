#include <fstream>
#include <vector>

using namespace std;

ifstream cin("hamilton.in");
ofstream cout("hamilton.out");

const int INF = 1'000'000'000;
vector<vector<int>> dp, graf;
int n, m;

int main() {
    cin >> n >> m;
    dp.assign(1 << n, vector<int>(n, INF));
    graf.assign(n, vector<int>(n, INF));
    for (int i = 0 ; i < m ; ++i) {
        int src, dest, cost;
        cin >> src >> dest >> cost;
        graf[src][dest] = cost;
    }
    dp[1][0] = 0;
    for (int mask = 2 ; mask < dp.size() ; ++mask) {
        if (mask & 1) { // daca am trecut prin nodul 1
            for (int i = 0 ; i < n ; ++i) {
                if (mask & (1 << i)) { // daca am trecut prin nodul i
                    for (int j = 0 ; j < n ; ++j) {
                        if (mask & (1 << j)) { // daca am trecut prin nodul j
                            // starea trecuta este drumul curent dar fara arcul de la j la i, deci se termina la j
                            // se compara starea curenta cu starea trecuta + costul muchiei j->i
                            dp[mask][i] = min(dp[mask][i], dp[mask ^ (1 << i)][j] + graf[j][i]);
                        }
                    }
                }
            }
        }
    }
    int ans = INF;
    for (int i = 0 ; i < n ; ++i) {
        ans = min(ans, dp[(1 << n) - 1][i] + graf[i][0]);
    }
    if (ans == INF) {
        cout << "Nu exista solutie";
        return 0;
    }
    cout << ans;
    return 0;
}