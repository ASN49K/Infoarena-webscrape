#include <bits/stdc++.h>

using namespace std;

ifstream fin("hamilton.in");
ofstream fout("hamilton.out");

int n, m, a[20][20], dp[(1 << 20)][20];
vector <int> G[20];
int main(){
    fin >> n >> m;
    for (int i = 1; i <= m; ++i){
        int x, y, z;
        fin >> x >> y >> z;
        a[x][y] = z;
        G[x].push_back(y);
    }
    for (int i = 0; i < (1 << n); ++i){
        for (int j = 0; j < n; ++j){
            dp[i][j] = -1;
        }
    }
    for (int i = 0; i < n; ++i){
        dp[(1 << i)][i] = 0;
    }
    for (int i = 1; i < (1 << n); ++i){
        for (int j = 0; j < n; ++j){
            if (dp[i][j] != -1){
                for (auto it : G[j]){
                    if (((i >> it) & 1) == 0){
                        if (dp[(i | (1 << it))][it] == -1) dp[(i | (1 << it))][it] = dp[i][j] + a[j][it];
                        dp[(i | (1 << it))][it] = min(dp[i][j] + a[j][it], dp[(i | (1 << it))][it]);
                    }
                }
            }
        }
    }
    int minim = 1e9;
    for (int i = 0; i < n; ++i){
        if (dp[(1 << n) - 1][i] != -1 && a[i][0]){
            minim = min(minim, dp[(1 << n) - 1][i] + a[i][0]);
        }
    }
    fout << minim;
    fin.close();
    fout.close();
    return 0;
}
