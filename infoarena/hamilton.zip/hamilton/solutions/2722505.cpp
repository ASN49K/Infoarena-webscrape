#include <fstream>
#include<vector>
using namespace std;

#define maxn 20
#define maxx 262150
#define inf 100000000

int main()
{
    ifstream be("hamilton.in");
    ofstream ki("hamilton.out");
    int n,m;
    be>>n>>m;
    vector<vector<pair<int,int> > >adj(n);
    vector<vector<int> >c(1<<n,vector<int>(n,inf));
    for(int i=0;i<m;i++)
    {
        int x,y,c;
        be>>x>>y>>c;
        adj[y].push_back({x,c});
    }
    c[1][0]=0;
    for(int i=0;i< 1<<n;i++)
        for(int j=0;j<n;j++)
            if(i&(1<<j))
                for(auto it:adj[j])
                    if(i &(1<<it.first))
                        c[i][j]=min(c[i][j],c[i^(1<<j)][it.first]+it.second);
    int ans=inf;
    for(auto it :adj[0])
        ans=min(ans,c[(1<<n) - 1][ it.first ] + it.second);
    if(ans==inf)ki << "Nu exista solutie" << endl;
	else ki << ans << endl;
    return 0;
}
