#include <fstream>
#include <vector>

using namespace std;

ifstream cin("hamilton.in");
ofstream cout("hamilton.out");

int matad[18][18];
int dp[262147][18];
int f[18][2];

int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x,y,c;
        cin>>x>>y>>c;
        matad[x][y]=c;
        f[x][0]++;
        f[y][1]++;
    }
    /*for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
            cout<<matad[i][j]<<" ";
        cout<<'\n';
    }*/
    int existaSol=0;
    for(int i=0; i<n; i++)
        if(f[i][0]==0 || f[i][1]==0)
            existaSol=1;
    if(existaSol==1)
        cout<<"Nu exista solutie"<<'\n';
    else
    {

        for(int i=1; i<=1<<n; i++)
            for(int j=0; j<n; j++)
                dp[i][j]=1e9;
        for(int i=0; i<n; i++)
            dp[1][i]=0;

        for(int i=1; i<=(1<<n); i++)
        {
            for(int j=0; j<n; j++)
            {
                if((i>>j)&1==1)
                    for(int k=0; k<n; k++)
                        if(((i>>k)&1)!=1 && matad[j][k]!=0)
                            dp[i+(1<<k)][k]=min(dp[i][j]+matad[j][k], dp[i+(1<<k)][k]);
            }
        }

        /*for(int i=0;i<1<<n;i++)
        {
            for(int j=0;j<n;j++)
                cout<<dp[i][j]<<" ";
            cout<<'\n';
        }*/
        int rez=1e9;
        for(int j=0; j<n; j++)
            if(matad[j][0]!=0)
                rez=min(rez, dp[(1<<n)-1][j]+matad[j][0]);
        if(rez==1e9)
            cout<<"Nu exista solutie"<<'\n';
        else
            cout<<rez<<'\n';
    }
    return 0;
}
