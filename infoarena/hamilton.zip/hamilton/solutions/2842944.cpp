#include <bits/stdc++.h>
using namespace std;
ifstream in("hamilton.in");
ofstream out("hamilton.out");
const int inf=1e9+7;
int dp[20][(1<<18)+3],n,m,x,y,c;
vector<pair<int,int>> rev[20];
int solve(int mask,int fin)
{
    if(dp[fin][mask])
        return dp[fin][mask];
    if(!(mask&(1<<fin)))
    {
        dp[fin][mask]=inf;
        return inf;
    }
    if(mask==(1<<fin))
    {
        if(fin==0)
            return 0;
        dp[fin][mask]=inf;
        return inf;
    }
    int ans=inf;
    int p=(mask^(1<<fin));
    for(auto x:rev[fin])
        ans=min(ans,solve(p,x.first)+x.second);
    dp[fin][mask]=ans;
    return ans;
}
int main()
{
    in>>n>>m;
    for(int i=1;i<=m;++i)
        in>>x>>y>>c,
        rev[y].push_back({x,c});
    int ans=inf;
    for(auto x:rev[0])
        ans=min(ans,solve((1<<n)-1,x.first)+x.second);
    if(ans==inf)
        out<<"Nu exista solutie"<<'\n';
    else out<<ans<<'\n';
    return 0;
}
