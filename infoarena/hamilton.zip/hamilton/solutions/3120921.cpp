#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#define ar array
#define vt vector
#define pq priority_queue
#define pu push
#define pub push_back
#define em emplace
#define emb emplace_back
#define mt make_tuple

#define all(x) x.begin(), x.end()
#define allr(x) x.rbegin(), x.rend()
#define allp(x, l, r) x.begin() + l, x.begin() + r
#define len(x) (int)x.size()
#define uniq(x) unique(all(x)), x.end()

using namespace std;
using namespace __gnu_pbds;

using ll = long long;
using ld = long double;
using ull = unsigned long long;

template <class T, size_t N>
void re(array <T, N>& x);
template <class T> 
void re(vt <T>& x);

template <class T> 
void re(T& x) {
    cin >> x;
}

template <class T, class... M> 
void re(T& x, M&... args) {
    re(x); re(args...);
}

template <class T> 
void re(vt <T>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void re(array <T, N>& x) {
    for(auto& it : x)
        re(it);
}

template <class T, size_t N>
void wr(array <T, N> x);
template <class T> 
void wr(vt <T> x);

template <class T> 
void wr(T x) {
    cout << x;
}

template <class T, class ...M>  void wr(T x, M... args) {
    wr(x), wr(args...);
}

template <class T> 
void wr(vt <T> x) {
    for(auto it : x)
        wr(it, ' ');
}

template <class T, size_t N>
void wr(array <T, N> x) {
    for(auto it : x)
        wr(it, ' ');
}

template<class T, class... M>
auto mvt(size_t n, M&&... args) {
    if constexpr(sizeof...(args) == 1)
        return vector<T>(n, args...);
    else
        return vector(n, mvt<T>(args...));
}

void set_fixed(int p = 0) {
    cout << fixed << setprecision(p);
}

void set_scientific() {
    cout << scientific;
}

inline void Open(const string Name) {
    #ifndef ONLINE_JUDGE
        (void)!freopen((Name + ".in").c_str(), "r", stdin);
        (void)!freopen((Name + ".out").c_str(), "w", stdout);
    #endif
}

void solve() {
    /* bitmask dp */
    const int inf = 2e9;

    int n, m; re(n, m);
    vt <vt <int>> adj(n);
    vt <vt <int>> cost(n, vt <int>(n, inf));
    for (int i = 0; i < m; ++i) {
        int u, v, c; re(u, v, c);
        adj[v].emb(u);
        cost[u][v] = c;
    }

    const int lim = (1 << n);
    vt <vt <int>> dp(lim, vt <int>(n, inf));

    dp[1][0] = 0;
    for (int msk = 2; msk < lim; ++msk) {
        for (int v = 0; v < n; ++v) {
            if ((msk >> v) & 1) {
                for (int u : adj[v]) {
                    if ((msk >> u) & 1) {
                        dp[msk][v] = min(dp[msk][v],
                            dp[msk ^ (1 << v)][u] + cost[u][v]);
                    }
                }
            }
        }
    }

    int res = inf;
    for (int u : adj[0]) {
        res = min(res, dp[lim - 1][u] + cost[u][0]);
    }

    if (res == inf) {
        wr("Nu exista solutie");
        return;
    }

    wr(res);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    Open("hamilton");

    int t = 1;
    for(;t;t--) {
        solve();
    }
    
    return 0;
}