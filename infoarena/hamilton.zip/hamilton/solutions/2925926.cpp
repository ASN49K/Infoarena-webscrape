#include <fstream>
#import <algorithm>
#import <vector>
#import <map>
#import <set>
#import <deque>
#import <queue>
#import <cassert>
//#import <cmath>
#import <cstring>
#import <cctype>
#import <cstdlib>
#import <stack>
#import<unordered_map>
using namespace std;
struct edge
{
    int x,v;
    edge(int _x,int _v) : x(_x) ,v(_v) {}
    edge(){}
};
main()
{
    ifstream cin("hamilton.in");
    ofstream cout("hamilton.out");
    int n,m;
    cin>>n>>m;
    vector<vector<edge>>a(n+1);
    for(int i=1;i<=m;i++)
    {
        int x,y,v;
        cin>>x>>y>>v;
        a[y].push_back(edge(x,v));
    }
    vector<vector<int>>dp(1<<n,vector<int>(n,2e9));
    dp[1][0]=0;
    for(int i=3;i<(1<<n);i+=2)
    {
        for(int j=0;j<n;j++)
        {
            if(i&(1<<j))
            {
                for(auto &c:a[j])
                {
                    dp[i][j]=min(dp[i][j],dp[i^(1<<j)][c.x]+c.v);
                }
            }
        }
    }
    int rez=2e9;
    for(auto &c:a[0])
    {
        rez=min(rez,dp[(1<<n)-1][c.x]+c.v);
    }
    if(rez==2e9)cout<<"Nu exista solutie";
    else cout<<rez;
}
