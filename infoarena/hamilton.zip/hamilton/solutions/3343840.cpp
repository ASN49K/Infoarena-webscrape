#include <fstream>

using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
int n, m, i, j, x, y, c, cost[21][21], dp[(1<<21)][21];
int main()
{
    fin>>n>>m;
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
         cost[i][j]=1e9;
    for(i=1; i<=m; i++)
    {
        fin>>x>>y>>c;
        cost[x][y]=c;
    }
    for(int mask=0; mask<(1<<n); mask++)
        for(int i=0; i<n; i++)
            dp[mask][i]=1e9;
    dp[1][0]=0;
    for(int mask=0; mask<(1<<n); mask++)
        for(int i=0; i<n; i++)
            if(mask&(1<<i))
                for(int j=0; j<n; j++)
                    if(mask&(1<<j))
                        dp[mask][i]=min(dp[mask][i], dp[mask-(1<<i)][j]+cost[j][i]);
    int ans=1e9;
    for(int i=0; i<n; i++)
        ans=min(ans, dp[(1<<n)-1][i]+cost[i][0]);
    if(ans==1e9)
        fout<<"Nu exista solutie";
    else
        fout<<ans;
    return 0;
}
