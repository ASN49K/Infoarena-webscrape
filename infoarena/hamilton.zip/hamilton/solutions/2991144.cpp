#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f("ciclu.in");
ofstream g("ciclu.out");
int n,m;
struct pct
{
    int x,dist;
};
const int N=1011;
vector<pct>a[N];
int     nr[N],b[N], dist[N];
bool bf(int med)
{
    for(int i=1;i<=n;i++)
        dist[i]=1e8;
    for(int i=1;i<=n;i++)
        nr[i]=0,b[i]=0;
    queue<int>q;
    for(int i=1;i<=n;i++)
    {
        q.push(i);
        dist[i]=0;
        nr[i]=0;
        b[i]=1;
        while(!q.empty())
        {
            int nod=q.front();
            q.pop();
            b[nod]=0;
            for( auto  it : a[nod])
            {
                if(dist[it.x]>dist[nod]+it.dist-med)
                {
                    dist[it.x]=dist[nod]+it.dist-med;
                    if(!b[it.x])
                    {
                        b[it.x]=1;
                        q.push(it.x);
                        nr[it.x]++;
                        if(nr[it.x]>=n)
                            return 1;
                    }
                }
            }
        }
    }
    return 0;
}
int main()
{
    f>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int X,Y,Z;
        f>>X>>Y>>Z;
        a[X].push_back({Y,Z*100});
    }
    int mj, st=1,dr=2e8;
    while(st<=dr)
    {
        mj=(st+dr)/2;
        if(bf(mj))
            dr=mj-1;
        else
            st=mj+1;
    }
    g<<double(st/100.0);
    return 0;
}
