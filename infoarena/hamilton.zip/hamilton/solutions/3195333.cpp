#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <cstring>

using namespace std;
ifstream fin("hamilton.in");
ofstream fout("hamilton.out");
vector<vector<int>>graph;
const int inf=0x3f3f3f3f;
int n,m,m1,m2,val;
int dp[18][18];
int cost[18][257];
bool muchie_primul(int nod)
{
    for(int vecin: graph[nod])
    {
        if(graph[nod][vecin]==0)
            return true;
    }
    return false;
}
int hamilton()
{
    for(int config=1; config<(1<<n)-1; config++)
    {
        for(int nod=0; nod<n; nod++)
        {
            if((config & (1<<nod)))
                for(int vecin: graph[nod])
                {
                    if(!(config & (1<<vecin)))
                        dp[config | (1<<vecin)][vecin]=min(dp[config][nod]+cost[nod][vecin],dp[config | (1<<vecin)][vecin]);
                }
        }
    }
}

int main()
{
    fin>>n>>m;
    graph.resize(n+1);

    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            dp[i][j] = inf;
    dp[1][0]=0;
    for(int i=1; i<=m; i++)
    {
        fin>>m1>>m2>>val;
        cost[m1][m2]=val;
        graph[m1].push_back(m2);
    }
    hamilton();
    int conf_cor=(1<<n)-1;
    int min_cost=inf;
    for(int nod=0; nod<graph[0].size(); nod++)
    {
        min_cost=min(min_cost,dp[conf_cor][graph[0][nod]] + cost[graph[0][nod]][0]);
    }
    cout<<min_cost;
    if (min_cost < inf)
    {
        fout<<min_cost;
    }
    else
    {
        fout<<"nu exista sol";
    }
}
