#include<fstream>
#include<vector>
#include<algorithm>
#define inf 180000005

using namespace std;

ifstream in("hamilton.in");
ofstream out("hamilton.out");

const int Nmax = 20;
vector<int> A[Nmax];

int main()
{
    int n, m, k, rez = inf;
    in >> n >> m;
    k = 1 << n;

    vector<vector<int> > cost(n + 1, vector<int>(n + 1));
    vector<vector<int> > dp(k + 1, vector<int>(n + 1));

    for (int i = 1; i <= k; i++)
        for (int j = 0; j < n; j++)
            dp[i][j] = inf;
    dp[1][0] = 0;

    for (int i = 1; i <= m; i++)
    {
        int x, y, c;
        in >> x >> y >> c;

        A[y].push_back(x);
        cost[y][x] = c;
    }

    for (int i = 1; i < k; i++)
    {
        for (int j = 0; j < n; j++)
            if ((1 << j) & i)
            {
                for (int w = 0; w < A[j].size(); w++)
                {
                    int nod = A[j][w];
                    if ((1 << nod) & i)
                        if (dp[i][j] > dp[i ^ (1 << j)][nod] + cost[j][nod])
                            dp[i][j] = dp[i ^ (1 << j)][nod] + cost[j][nod];
                }
            }
    }

    k--;
    for (int i = 0; i < A[0].size(); i++)
    {
        int nod = A[0][i];
        int rezCur = dp[k][nod] + cost[0][nod];
        if (rezCur < rez)
            rez = rezCur;
    }

    if (rez == inf)
        out << "Nu exista solutie";
    else
        out << rez;

    return 0;
}
