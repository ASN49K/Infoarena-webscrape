#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

vector<int> gf[351];
int cap[351][351], cost[351][351];
queue<int> q;
priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
int n, m, s, d, tata[351], dist[351], prev_dist[351], real_dist[351], fluxmax;
bool viz[351];
const int inf = 1e9;

void bellman_ford() {
    for (int i = 1; i <= n; i++)
        prev_dist[i] = inf;
    prev_dist[s] = 0;
    q.push(s);
    while (!q.empty()) {
        int nod = q.front();
        q.pop();
        for (int vecin : gf[nod])
            if (cap[nod][vecin] > 0 && prev_dist[vecin] > prev_dist[nod] + cost[nod][vecin]) {
                prev_dist[vecin] = prev_dist[nod] + cap[nod][vecin];
                q.push(vecin);
            }
    }
}

bool dijkstra() {
    for (int i = 1; i <= n; i++)
        dist[i] = inf, real_dist[i] = inf, viz[i] = 0, tata[i] = 0;
    real_dist[s] = 0;
    dist[s] = 0;
    pq.push({ dist[s], s });
    while (!pq.empty()) {
        int nod = pq.top().second;
        pq.pop();
        if (viz[nod])
            continue;
        viz[nod] = 1;
        for (auto vecin : gf[nod]) {
            int tmp_dist = dist[nod] + cost[nod][vecin] + prev_dist[nod] - prev_dist[vecin];
            if (cap[nod][vecin] > 0 && dist[vecin] > tmp_dist) {
                dist[vecin] = tmp_dist;
                tata[vecin] = nod;
                real_dist[vecin] = real_dist[nod] + cost[nod][vecin];
                pq.push({ dist[vecin], vecin });
            }
        }
    }
    for (int i = 1; i <= n; i++)
        prev_dist[i] = real_dist[i];
    if (dist[d] == inf)
        return false;

    int fluxnou = inf;
    for (int i = d; i != s; i = tata[i])
        fluxnou = min(fluxnou, cap[tata[i]][i]);
    for (int i = d; i != s; i = tata[i]) {
        cap[tata[i]][i] -= fluxnou;
        cap[i][tata[i]] += fluxnou;
    }
    fluxmax += fluxnou * real_dist[d];
    return true;
}

int main()
{
    fin >> n >> m >> s >> d;
    for (int i = 1; i <= m; i++) {
        int x, y, c, z;
        fin >> x >> y >> c >> z;
        gf[x].push_back(y);
        gf[y].push_back(x);
        cap[x][y] = c;
        cost[x][y] = z;
        cost[y][x] = -z;
    }
    bellman_ford();
    while (dijkstra());
    fout << fluxmax;
    return 0;
}
