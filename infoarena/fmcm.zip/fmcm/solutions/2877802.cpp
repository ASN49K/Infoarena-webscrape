#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream f("fmcm.in");
ofstream g("fmcm.out");

const int INF = 2e9;

struct pqElement
{
    int node;
    int cost;

    pqElement()
    {
        node = 0;
        cost = 0;
    }

    pqElement(const int _NODE, const int _COST)
    {
        node = _NODE;
        cost = _COST;
    }
};

class pqCompare
{
    public:
        bool operator () (const pqElement a, const pqElement b)
        {
            return a.cost > b.cost;
        }
};

int n, m, s, d;

int cap[351][351];
int cost[351][351];

int dist[351];
bool inQueue[351];

vector < int > adj[351];

void bellmanFord(int source)
{
    for (int i = 1; i <= n; i++)
    {
        dist[i] = INF;
        inQueue[i] = false;
    }

    queue < int > q;

    q.push(source);
    dist[source] = 0;
    inQueue[source] = true;

    while (!q.empty())
    {
        int node = q.front();
        q.pop();

        for (auto it : adj[node])
            if (cap[node][it] && dist[node] + cost[node][it] < dist[it])
            {
                dist[it] = dist[node] + cost[node][it];

                if (!inQueue[it])
                {
                    q.push(it);
                    inQueue[it] = true;
                }
            }

        inQueue[node] = false;
    }

    /*for (int i = 1; i <= n; i++)
        for (auto it : adj[i])
            cost[i][it] += dist[i] - dist[it], g << cost[i][it] << "\n";*/
}

priority_queue < pqElement, vector < pqElement >, pqCompare > pq;

bool dijkstra(int source)
{

}

int main()
{
    f >> n >> m >> s >> d;

    for (int i = 1; i <= m; i++)
    {
        int x, y, c, z; f >> x >> y >> c >> z;

        adj[x].push_back(y);
        adj[y].push_back(x);

        cap[x][y] = c;
        cost[x][y] = z;
        cost[y][x] = -z;
    }

    bellmanFord(s);

    return 0;
}
