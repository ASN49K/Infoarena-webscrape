#include <fstream>
#include <vector>
#include <queue>

using namespace std;
ifstream cin ("fmcm.in");
ofstream cout ("fmcm.out");
#pragma GCC optimize("O3")
priority_queue <pair<long long,int>,vector<pair<int,int> >,greater<pair<int,int> > >qu;
int par[355];
int dist[355];
int costdist[355];
int cap[355][355];
int flow[355][355];
int cost[355][355];
int jhon[355];     ///distante initiale pentru folosire dijkstra
queue<int>que;
vector<int>adj[355];
int maxflow=0,mincost=0;

void bellmanford(int st)
{
    int curr,i,k;
    que.push(st);
    while(que.size())
    {
        curr=que.front();
        que.pop();
        for(i=0; i<adj[curr].size(); i++)
        {
            k=adj[curr][i];
            if(jhon[curr]+cost[curr][k]<jhon[k] && cap[curr][k]!=0)
            {
                jhon[k]=jhon[curr]+cost[curr][k];
                    que.push(k);
            }
        }
    }
}
int inf=1e7;
int dijkstra(int st,int fs,int n)
{
    int i,k,curr,val,currflow;
    for(i=1; i<=n; i++)
    {
        dist[i]=inf;
        costdist[i]=inf;
    }
    qu.push({0,st});
    dist[st]=0;
    costdist[st]=0;
    while(qu.size())
    {
        curr=qu.top().second;
        val=qu.top().first;
        qu.pop();
        if(val==dist[curr])
        {
            for(i=0; i<adj[curr].size(); i++)
            {
                k=adj[curr][i];
                if((cap[curr][k]-flow[curr][k]>0) && (dist[k]>dist[curr]+cost[curr][k]-jhon[k]+jhon[curr]))
                {
                    dist[k]=dist[curr]+cost[curr][k]-jhon[k]+jhon[curr];
                    costdist[k]=costdist[curr]+cost[curr][k];
                    qu.push({dist[k],k});
                    par[k]=curr;
                }
            }
        }
    }
    if(dist[fs]!=inf)
    {
        curr=fs;
        currflow=inf;
        while(curr!=st)
        {
            currflow=min(currflow,cap[par[curr]][curr]-flow[par[curr]][curr]);
            curr=par[curr];
        }
        curr=fs;
        maxflow=maxflow+currflow;
        while(curr!=st)
        {
            flow[par[curr]][curr]+=currflow;
            flow[curr][par[curr]]-=currflow;
            curr=par[curr];
        }
        mincost=mincost+currflow*costdist[fs];
        for(i=1; i<=n; i++)
        {
            jhon[i]=dist[i];
        }
        return 1;
    }
    return 0;
}
int main()
{
    int i,j,k,l,n,m,a,b,capedge,costedge,st,fs,cst,cp;
    cin>>n>>m>>st>>fs;
    for(i=1; i<=m; i++)
    {
        cin>>a>>b>>cp>>cst;
        cap[a][b]=cp;
        adj[a].push_back(b);
        adj[b].push_back(a);
        cost[a][b]=cst;
        cost[b][a]=-cst;
    }
    for(i=1; i<=n; i++)
    {
        jhon[i]=inf;
    }
    jhon[st]=0;
    bellmanford(st);
    while(dijkstra(st,fs,n)==1) {};
    cout<<mincost;
    return 0;

}
