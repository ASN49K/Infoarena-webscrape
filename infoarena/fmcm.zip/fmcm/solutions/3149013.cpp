#include<fstream>
using namespace std;
ifstream F("fmcm.in");
ofstream G("fmcm.out");
int n,m,s,d,i,j,l,k,e,y,z,t,r[351],c[351][351],p[351],h[351],g[351][351],a[351],o[351][351],b[351];
int main()
{
	F>>n>>m>>s>>d;
	while(m--)
        F>>i>>j>>l>>k,g[i][a[i]++]=j,g[j][a[j]++]=i,c[i][j]=l,o[i][j]=k,o[j][i]=-k;
	for(i=1;i<=n;++i)
        b[i]=10001;
	for(b[s]=0,i=1;i<=n&&!y;++i)
        for(y=j=1;j<=n;++j)
            for(k=0,t=g[j][0];k<a[j];t=g[j][++k])
                if(c[j][t]&&b[j]+o[j][t]<b[t])
                    y=0,b[t]=b[j]+o[j][t];
	for(z=b[d],i=1;i<=n;++i)
        for(j=0,k=g[i][0];j<a[i];k=g[i][++j])
            o[i][k]+=b[i]-b[k];
	while(1) {
		for(i=1;i<=n;++i)
            b[i]=10001,h[i]=r[i]=i;
        for(b[s]=p[d]=0,h[1]=r[1]=s,l=n,h[s]=r[s]=1;l;) {
            for(i=h[1],h[1]=h[l--],j=1;(t=2*j)<=l;j=t) {
				if(t<l&&b[h[t+1]]<b[h[t]])
                    ++t;
                if(b[h[j]]<=b[h[t]])
                    break;
                k=h[j],h[j]=h[t],h[t]=k,r[h[t]]=t,r[h[j]]=j;
			}
            for(k=0,j=g[i][0];k<a[i];j=g[i][++k])
                if(b[j]>b[i]+o[i][j]&&c[i][j])
                    for(b[j]=b[i]+o[i][j],p[j]=i,t=r[j];t>1&&b[h[t]]<b[h[t/2]];t/=2)
                        y=h[t],h[t]=h[t/2],h[t/2]=y,r[h[t]]=t,r[h[t/2]]=t/2;
		}
        if(!p[d])
            break;
        for(m=10001,l=d;l!=s;l=p[l])
        	m=m>c[p[l]][l]?c[p[l]][l]:m;
        for(z+=b[d],e+=z*m,l=d;l!=s;l=p[l])
            c[p[l]][l]-=m,c[l][p[l]]+=m;
        for(i=1;i<=n;++i)
            for(j=0,k=g[i][0];j<a[i];k=g[i][++j])
                o[i][k]+=b[i]-b[k];
	}
	G<<e;
	return 0;
}
