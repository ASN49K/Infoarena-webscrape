#include <bits/stdc++.h>

using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
typedef long long ll;
vector <int> v[1006];
int mb[505],niv[505];
int cap[505][505];
int cost[505][505];
int viz[505],viz2[505];
int from[505];
int start,dest;
int ans;
int dist[505];
int n,m;
queue <int> q;
int dist2[1005];
void bellman(int start)
{

    for(int i=1;i<=n;i++)
        dist[i]=2e9,viz[i]=0;
    dist[start]=0;
    q.push(start);
    viz[start]=1;
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        viz[x]=0;
        for(auto nod:v[x])
            if(cap[x][nod]>0&&dist[nod]>dist[x]+cost[x][nod])
        {
            dist[nod]=dist[x]+cost[x][nod];
            if(viz[nod]==0)
            {
                q.push(nod);
                viz[nod]=1;
            }
        }
    }
}
int dijkstra(int start)
{
    for(int i=1;i<=n;i++)
        {
            dist2[i]=dist[i];
            dist[i]=2e9;
        }
    dist[start]=0;
    set <pair<int,int>> st;
    st.insert({0,start});
    while(!st.empty())
    {
        pair <int,int> prim=*st.begin();
        st.erase(st.begin());
        int nod=prim.second;
        if(viz2[nod]==0)
        {
        viz2[nod]=1;
        for(auto to:v[nod])
            if(dist[to]>dist[nod]+cost[nod][to]+dist2[nod]-dist2[to]&&cap[nod][to]>0)
        {
            dist[to]=dist[nod]+cost[nod][to]+dist2[nod]-dist2[to];
            from[to]=nod;
            if(dist[to]!=2e9)
                st.erase(*st.find({dist[to],to}));
            st.insert({dist[to],to});
        }
        }
    }
    for(int i=1;i<=n;i++)
        viz2[i]=0;
    if(dist[dest]!=2e9)
    {
        for(int i=1;i<=n;i++)
            dist[i]+=dist2[i];
        int flx=2e9;
        for(int i=dest;i!=start;i=from[i])
            flx=min(flx,cap[from[i]][i]);
        for(int i=dest;i!=start;i=from[i])
        {
            cap[from[i]][i]-=flx;
            cap[i][from[i]]+=flx;
        }
        return flx*dist[dest];
    }
    return 0;
}
void flux()
{
    bellman(start);
    int ras=-1;
    while(ras!=0)
    {
        ras=dijkstra(start);
        ans+=ras;
    }
}
int main()
{
    fin>>n>>m>>start>>dest;
    for(int i=1;i<=m;i++)
    {
        int x,y,z,t;
        fin>>x>>y>>z>>t;
        v[x].push_back(y);
        v[y].push_back(x);
        cost[x][y]=t;
        cost[y][x]=-t;
        cap[x][y]=z;
    }
    flux();
    fout<<ans;
    return 0;
}
