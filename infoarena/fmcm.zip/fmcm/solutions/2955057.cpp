#include <bits/stdc++.h>
using namespace std;

const int nmax = 357;
const int inf = 0x3f3f3f3f;
typedef long long llong;

int n, m, src, dst;
vector<int> adj[nmax];
int cap[nmax][nmax];
int cost[nmax][nmax];
int par[nmax];
int dist[nmax];

void bellmanFord() {

  memset(dist, inf, sizeof(dist));
  memset(par, -1, sizeof(par));

  static bool inq[nmax];
  inq[dst] = true;

  queue<int> q;
  q.push(src);
  dist[src] = 0;
  par[src] = 0;

  while (!q.empty()) {
    int u = q.front(); q.pop();
    inq[u] = false;
    for (int v : adj[u]) {
      if (cap[u][v] > 0 && dist[u] + cost[u][v] < dist[v]) {
        par[v] = u;
        dist[v] = dist[u] + cost[u][v];
        if (!inq[v]) q.push(v), inq[v] = true;
      }
    }
  }
}

llong solve() {

  cin >> n >> m >> src >> dst;
  for (int i = 0; i < m; i++) {
    int u, v, f, c;
    cin >> u >> v >> f >> c;
    adj[u].push_back(v);
    adj[v].push_back(u);
    cap[u][v] = f;
    cost[u][v] = c;
    cost[v][u] = -c;
  }

  llong totalCost = 0;

  for (;;) {
    
    bellmanFord();

    if (dist[dst] > inf / 2) return totalCost;
  
    int currentFlow = INT_MAX;

    for (int u = dst; u != src; u = par[u]) {
      currentFlow = min(currentFlow, cap[par[u]][u]);
    }

    for (int u = dst; u != src; u = par[u]) {
      cap[par[u]][u] -= currentFlow;
      cap[u][par[u]] += currentFlow;
    }

    totalCost += (llong)currentFlow * dist[dst];
  }

}

int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("fmcm.in", "r", stdin);
  freopen("fmcm.out", "w", stdout);
  #endif

  ios_base::sync_with_stdio(false), cin.tie(NULL);

  cout << solve() << endl;
}