#include <bits/stdc++.h>
#include <cstring>
//#pragma GCC optimize ("O3")
#define din cin
#define dout out
#define pi 3.14159265359
#define sw(x,y) x^=y,y^=x,x^=y
#define bmin(a,b)((a<b)?(a):(b))
#define bmax(a,b)((a>b)?(a):(b))
#define bminify(a,b)a=bmin(a,b)
#define bmaxify(a,b)a=bmax(a,b)
#define forq(i,ii,n)for(i=ii;i<n;i++)
#define f first
#define s second
#define mod 1000000297ll
#define smax 51000
using namespace std;
typedef long long ll;
//ifstream in("fmcm.in");
//ofstream out("fmcm.out");
FILE *fin=fopen("fmcm.in","r");
FILE *fout=fopen("fmcm.out","w");
int n,m,i,j,k,l,n1,n2,v0[351][351],v1[351][351],v2[351][351],d[351],e[351],f[351],w,ww;vector<int>g[351];
ll c[350000];bitset<351>b;ll tf,tc;
int main()
{
fscanf(fin,"%d%d%d%d",&n,&m,&n1,&n2);
forq(k,0,m)
    fscanf(fin,"%d%d",&i,&j),fscanf(fin,"%d%d",&v0[i][j],&v1[i][j]),g[i].push_back(j),g[j].push_back(i),v0[j][i]=-0,v1[j][i]=-v1[i][j];
//forq(i,0,n)for(auto j:g[i])printf("%d %d: %d %d %d %d\n",i,j,v[i][j][0],v[i][j][1],v[j][i][0],v[j][i][1]);
fill(d,d+n+1,INT_MAX/2);
d[n1]=0,c[0]=n1,l=1;
while(l)
{
    if(d[c[0]&1023]!=(c[0]>>10)){pop_heap(c,c+l,greater<ll>()),--l;continue;}
    i=c[0]&1023;pop_heap(c,c+l,greater<ll>()),--l;
    //printf("%d:%d\n",i,d[i]);
    for(auto j:g[i])
        if(v0[i][j])
            if(d[j]>d[i]+v1[i][j])
                d[j]=d[i]+v1[i][j],c[l++]=(d[j]<<10ll)|j,push_heap(c,c+l,greater<ll>());
}
forq(i,1,n+1)for(auto j:g[i])v2[i][j]=v1[i][j]+d[i]-d[j];
while(true)
{
    memset(e,0x1f,sizeof(e)),f[n2]=0;
    b[n1]=1,e[n1]=0,l=1,c[0]=(e[n1]<<10ll)|n1;
    while(l)
    {
        i=c[0]&1023,w=c[0]>>10;
        pop_heap(c,c+l,greater<ll>());--l;
        if(e[i]==w)
        {

            for(auto j:g[i])
                if(v0[i][j])
                    {ww=w+v1[i][j]+d[i]-d[j];if(e[j]>e[i]+v2[i][j])
                        e[j]=e[i]+v2[i][j],f[j]=i,c[l++]=(e[j]<<10ll)|j,push_heap(c,c+l,greater<ll>());}
        }
    }
    if(f[n2]==0)break;
    else{
        j=n2,k=INT_MAX;
        while(j!=n1)bminify(k,v0[f[j]][j]),j=f[j];
        //printf("pa%d\n",k);
        tf+=k,j=n2,i=0;
        while(j!=n1)
            v0[f[j]][j]-=k,v0[j][f[j]]+=k,tc+=v1[f[j]][j]*k,j=f[j];
    }
}
fprintf(fout,"%lld",tc);
fclose(fin),fclose(fout);
}
