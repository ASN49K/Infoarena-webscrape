#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define debug(x) cerr << #x << " " << x << "\n"
#define debugs(x) cerr << #x << " " << x << " "

using namespace std;
using namespace __gnu_pbds;
typedef long long ll;
typedef pair <ll, ll> pii;
typedef pair <long double, pii> muchie;

const ll NMAX = 351;
const ll VMAX = 21;
const ll INF = (1LL << 55);
const ll MOD = 998244353;
const ll BLOCK = 318;
const ll base = 31;
const ll nr_of_bits = 30;

vector <int> v[NMAX];

struct edge {
    int from, to, cap, cost;
} edges[25001];

int cnt = 0, s, d, n, viz[NMAX];
int dist[NMAX], last[NMAX];

void addEdge(int a, int b, int c, int cost) {
    edges[++cnt] = {a, b, c, cost};
    v[a].push_back(cnt);
    edges[++cnt] = {b, a, 0, -cost};
    v[b].push_back(cnt);
}

int invers(int x) {
    if(x % 2)
        return (x + 1);
    return (x - 1);
}

bool Dijkstra() {
    for(int i = 1; i <= n; i++) {
        viz[i] = 0, dist[i] = 2e9;
        last[i] = 0;
    }
    queue <int> pq;
    pq.push(s);
    viz[s] = 1;
    dist[s] = 0;
    while(pq.size()) {
        int node = pq.front();
        pq.pop();
        viz[node] = 0;
        for(auto x : v[node]) {
            if(!edges[x].cap)
                continue;
            int to = edges[x].to;
            int cost = edges[x].cost;
            if(dist[node] + cost < dist[to]) {
                dist[to] = dist[node] + cost;
                last[to] = x;
                if(!viz[to]) {
                    pq.push(to);
                    viz[to] = 1;
                }
            }
        }
    }
    if(dist[d] != 2e9)
        return 1;
    return 0;
}

int flow() {
    ll sol = 0;
    while(Dijkstra()) {
        int minim = 2e9;
        int node = last[d];
        while(node != 0) {
            minim = min(minim, edges[node].cap);
            node = last[edges[node].from];
        }
        sol += 1LL * minim * dist[d];
        node = last[d];
        while(node != 0) {
            edges[node].cap -= minim;
            edges[invers(node)].cap += minim;
            node = last[edges[node].from];
        }
    }
    return sol;
}

int main() {
    ifstream cin("fmcm.in");
    ofstream cout("fmcm.out");
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int m, i;
    cin >> n >> m >> s >> d;
    for(i = 1; i <= m; i++) {
        int a, b, c, d;
        cin >> a >> b >> c >> d;
        addEdge(a, b, c, d);
    }
    cout << flow();
    return 0;
}
