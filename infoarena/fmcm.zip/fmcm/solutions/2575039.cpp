#include <fstream>
#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
 
using namespace std;
 
ifstream inf("fmcm.in");
ofstream outf("fmcm.out");
 
const int NMAX = 351;
const int INF = 0x3f3f3f3f;
 
int flow[NMAX][NMAX];
int cap[NMAX][NMAX];
int cost[NMAX][NMAX];
int oldd[NMAX];
int dist[NMAX];
int trued[NMAX];
int pred[NMAX];
vector<int> ad[NMAX];
queue<int> q;
bool inq[NMAX];
 
priority_queue<pair<int, int> , vector<pair<int, int> >, greater<pair<int, int> > > pq;
 
int main() {
    int n, m, s, d, x, y, c, z;
    inf >> n >> m >> s >> d;
    for(int i = 0; i < m; i++) {
        inf >> x >> y >> c >> z;
        ad[x].push_back(y);
        ad[y].push_back(x);
        cost[x][y] = z;
        cost[y][x] = -z;
        cap[x][y] = c;
        cap[y][x] = 0;
    }
    memset(oldd, 0x3f, sizeof(oldd));
 
    // Bellman-Ford - serios?.... bine ca ziceti ca trebe Bellman-Ford... 
    q.push(s);
    oldd[s] = 0;
    while(!q.empty()) {
        x = q.front();
        q.pop();
        inq[x] = false;
        for(int el : ad[x]) {
            if(cap[x][el] && oldd[el] > oldd[x] + cost[x][el]) {
                oldd[el] = oldd[x] + cost[x][el];
                if(!inq[el]) {
                    inq[el] = true;
                    q.push(el);
                }
            }
        }
    }
 
    // Dijkstra loop
    int totcost = 0;
    do {
        memset(dist, 0x3f, sizeof(dist));
        memset(pred, 0x3f, sizeof(pred));
        dist[s] = 0;
        trued[s] = 0;
        inq[s] = true;
        pq.push({0, s});
        int cst;
        while(!pq.empty()) {
            x = pq.top().second;
            cst = pq.top().first;
            pq.pop();
            if(dist[x] != cst) {
                continue;
            }
            for(int el : ad[x]) {
                int tempd = dist[x] + oldd[x] - oldd[el] + cost[x][el];
                if(dist[el] > tempd && cap[x][el] > flow[x][el]) {
                    dist[el] = tempd;
                    trued[el] = trued[x] + cost[x][el];
                    pred[el] = x;
                    pq.push({dist[el], el});
                }
            }
        }
 
        if(dist[d] != INF) {
            int fmin = INF;
            for(x = d; x != s; x = pred[x]) {
                fmin = min(fmin, cap[pred[x]][x] - flow[pred[x]][x]);
            }
            for(x = d; x != s; x = pred[x]) {
                flow[pred[x]][x] += fmin;
                flow[x][pred[x]] -= fmin;
            }
            totcost += trued[d] * fmin;
        }
        memcpy(oldd, trued, sizeof(oldd));
 
    } while(dist[d] != INF);
 
    outf << totcost;
    return 0;
}