#include <bits/stdc++.h>
#define Nmax 355

using namespace std;
ifstream fin ("fmcm.in");
ofstream fout ("fmcm.out");

vector <int> v[Nmax];
int n, m, S, D, flux, cost, co[Nmax][Nmax], c[Nmax][Nmax];
int t[Nmax], be[Nmax], di[Nmax];
void bellmanford()
{
    queue <int> q;
    for(int i=1;i<=n;i++)
    {
        be[i]=INT_MAX;
        t[i]=0;
    }

    q.push(S);
    t[S]=1;
    be[S]=0;

    while(!q.empty())
    {
        int u=q.front();
        q.pop();
        t[u]=0;

        for(auto it:v[u])
            if(c[u][it] && be[it] > be[u] + co[u][it])
            {
                if(!t[it])
                {
                    q.push(it);
                    t[it]=1;
                }
                be[it] = be[u] + co[u][it];
            }
    }
}

struct criteriu
{
    bool operator()(int x, int y)
    {
        if(di[x]!=di[y])
            return di[x]<di[y];
        return x<y;
    }
};

bool dijkstra()
{
    set <int, criteriu> s;

    for(int i=1;i<=n;i++)
    {
        di[i]=INT_MAX;
        t[i]=0;
    }

    di[S]=0;
    s.insert(S);
    t[S]=-1;

    while(!s.empty())
    {
        int u = *s.begin();
        s.erase(s.begin());

        for(auto it:v[u])
            if(c[u][it])
            {
                int comuchie = co[u][it] + be[u] - be[it];
                if(di[it] > di[u] + comuchie)
                {
                    if(s.find(it)!=s.end())
                        s.erase(s.find(it));

                    di[it] = di[u] + comuchie;
                    s.insert(it);
                    t[it]=u;
                }
            }
    }

    if(!t[D])
        return 0;

    int fm=INT_MAX, drum=0;

    for(int i=D; i!=S; i=t[i])
    {
        drum=drum+co[t[i]][i];
        fm=min(fm, c[t[i]][i]);
    }

    flux += fm;
    cost = cost + fm *drum;

    for(int i=D;i!=S;i=t[i])
    {
        c[t[i]][i]-=fm;
        c[i][t[i]]+=fm;
    }

    return 1;
}
int main()
{
    fin >> n >> m >> S >> D;
    for(int i=1; i<=m; i++)
    {
        int x, y;
        fin >> x >> y;
        v[x].push_back(y);
        v[y].push_back(x);
        fin >> c[x][y] >> co[x][y];
        co[y][x]=-co[x][y];
    }
    bellmanford();
    while(dijkstra());
    fout << cost;
    return 0;
}
