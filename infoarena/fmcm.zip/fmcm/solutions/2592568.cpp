#include<fstream>
#include<algorithm>
#include<vector>
#include<queue>
#define INF 2000000000
using namespace std;
ifstream f("fmcm.in");
ofstream g("fmcm.out");
vector<int>a[352];
int n,s,d,flux,sol,r[352][352],z[352][352],tata[352],dist[352],distinit[352];
bool inq[352];
queue<int>q;
struct elem
{
    int x,dist;
    inline bool operator < (const elem &a) const
    {
        return dist>a.dist;
    }
};
priority_queue<elem>pq;

inline bool dijkstra()
{
    int i,l,Z;
    elem p;
    for(i=1;i<=n;i++)
        dist[i]=INF,tata[i]=0;
    pq.push({s,0});
    dist[s]=0;
    while(!pq.empty())
    {
        p=pq.top();
        pq.pop();
        if(p.dist==dist[p.x])
        {
            l=a[p.x].size();
            for(i=0;i<l;i++)
            {
                Z=distinit[p.x]-distinit[a[p.x][i]]+z[p.x][a[p.x][i]];
                if(r[p.x][a[p.x][i]]>0&&dist[a[p.x][i]]>dist[p.x]+Z)
                {
                    dist[a[p.x][i]]=dist[p.x]+Z;
                    tata[a[p.x][i]]=p.x;
                    pq.push({a[p.x][i],dist[a[p.x][i]]});
                }
            }
        }
    }
    return dist[d]!=INF;
}

inline void bellman_ford()
{
    int i,l,p;
    for(i=1;i<=n;i++)
        distinit[i]=INF;
    distinit[s]=0;
    q.push(s);
    inq[s]=1;
    while(!q.empty())
    {
        p=q.front();
        q.pop();
        inq[p]=0;
        l=a[p].size();
        for(i=0;i<l;i++)
        if(r[p][a[p][i]]>0&&distinit[a[p][i]]>distinit[p]+z[p][a[p][i]])
        {
            distinit[a[p][i]]=distinit[p]+z[p][a[p][i]];
            if(inq[a[p][i]]==0)
            {
                q.push(a[p][i]);
                inq[a[p][i]]=1;
            }
        }
    }
}

inline void fmcm()
{
    int i,flow,cost;
    bellman_ford();
    while(dijkstra()!=0)
    {
        flow=INF;
        for(i=d;i!=s;i=tata[i])
        {
            flow=min(flow,r[tata[i]][i]);
            if(flow==0)
                break;
        }
        if(flow!=0&&flow!=INF)
        {
            cost=0;
            for(i=d;i!=s;i=tata[i])
            {
                r[tata[i]][i]-=flow;
                r[i][tata[i]]+=flow;
                cost+=z[tata[i]][i];
            }
            flux+=flow;
            sol+=flow*cost;
        }
    }
}

int main()
{
    int m,i,x,y,c,zz;
    f>>n>>m>>s>>d;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>c>>zz;
        a[x].push_back(y);
        a[y].push_back(x);
        r[x][y]+=c;
        z[x][y]=zz;
        z[y][x]=-zz;
    }
    fmcm();
    g<<sol;
    return 0;
}
