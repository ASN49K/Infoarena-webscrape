#include <fstream>
#include <bits/stdc++.h>
#define cin fin
#define cout fout
using namespace std;
ifstream cin ("fmcm.in");
ofstream cout ("fmcm.out");
vector<int>G[1008];
vector<pair<int,int>>muchii;
int a,b,c,f,n,m,S,D,i;
int ok,cap[1008][1008],cost[1008][1008],F[1008][1008],dist[1008],tata[1008],incoada[1008],dist_pct[1008],dist2[1008];
struct compar
{
    bool operator()(int a,int b)
    {
        return dist[a]>dist[b];
    }
};
priority_queue<int,vector<int>,compar>Q;
void bellmanford()
{
    for(i=1; i<=n; i++)
    {
        dist_pct[i]=1e9;
    }
    dist_pct[S]=0;
    queue<int>Q;
    Q.push(S);
    incoada[S]=1;
    while(!Q.empty())
    {
        int nod=Q.front();
        Q.pop();
        for(auto i:G[nod])
            if(cap[nod][i]>0 && dist_pct[nod]+cost[nod][i]<dist_pct[i])
            {
                dist_pct[i]=dist_pct[nod]+cost[nod][i];
                tata[i]=nod;
                if(incoada[i]==0)
                {
                    Q.push(i);
                    incoada[i]=1;
                }
            }
        incoada[nod]=0;
    }
}
int dij()
{
    for(i=1; i<=n; i++)
    {
        dist[i]=1e9;
        tata[i]=-1;
        dist2[i]=1e9;
    }
    dist[S]=0;
    dist2[S]=0;
    Q.push(S);
    while(!Q.empty())
    {
        int nod=Q.top();
        Q.pop();
        incoada[nod]=0;
        for(auto i:G[nod])
        {
            if(i!=tata[nod] && cap[nod][i]-F[nod][i]>0 && dist[nod]+cost[nod][i]<dist[i])
            {
                dist[i]=dist[nod]+cost[nod][i];
                dist2[i]=dist2[nod]-dist_pct[nod]+dist_pct[i]+cost[nod][i];
                tata[i]=nod;
                if(incoada[i]==0)
                {
                    incoada[i]=1;
                    Q.push(i);
                }
            }
        }
    }
    if(dist[D]!=1e9)
    {
        int fluxul=1e9;
        i=D;
        while(i!=S)
        {
            fluxul=min(fluxul,cap[tata[i]][i]-F[tata[i]][i]);
            i=tata[i];
        }
        i=D;
        while(i!=S)
        {
            F[tata[i]][i]+=fluxul;
            F[i][tata[i]]-=fluxul;
            i=tata[i];
        }
        ok=1;
        return fluxul*dist2[D];
    }
    return 0;
}
int Flux()
{
    int ras=0;
    ok=1;
    bellmanford();
    for(auto i:muchii)
    {
        cost[i.first][i.second]+=dist_pct[i.first]-dist_pct[i.second];
        cost[i.second][i.first]+=dist_pct[i.second]-dist_pct[i.first];
    }
    while(ok==1)
    {
        ok=0;
        ras+=dij();
    }
    return ras;
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>n>>m>>S>>D;
    for(i=1; i<=m; i++)
    {
        cin>>a>>b>>f>>c;
        muchii.push_back({a,b});
        G[a].push_back(b);
        cap[a][b]=f;
        if(cap[b][a]==0)
            G[b].push_back(a);
        cost[a][b]=c;
        cost[b][a]=-c;
    }
    cout<<Flux();
    return 0;
}
