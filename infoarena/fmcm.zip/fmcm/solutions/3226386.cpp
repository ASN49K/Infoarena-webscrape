#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#pragma GCC optimize ("O1")
#pragma GCC optimize ("O2")
#pragma GCC optimize ("O3")
#pragma GCC optimize ("Ofast")
#pragma GCC optimize ("unroll-loops")
#pragma GCC target ("avx2")

using namespace std;
using namespace __gnu_pbds;

#define ordered_set tree <long long, null_type, less<long long>, rb_tree_tag, tree_order_statistics_node_update>
#define lsb(x)(x & (-x))

struct str{
    int nod, cost;
    bool operator < (const str & aux) const
    {
        return cost > aux.cost;
    }
};

const int max_size = 350 + 20, INF = 2e9 + 2;

int cap[max_size][max_size], cost[max_size][max_size], pr[max_size], d[max_size], aux[max_size], t[max_size], src, dest, n;
vector <int> mc[max_size];
priority_queue <str> pq;

void bf ()
{
    queue <int> q;
    for (int i = 1; i <= n; i++)
    {
        aux[i] = INF;
    }
    aux[src] = 0;
    q.push(src);
    while (!q.empty())
    {
        int nod = q.front();
      //  cerr
        q.pop();
        d[nod] = 0;
        for (auto f : mc[nod])
        {
            if (cap[nod][f] > 0 && aux[nod] + cost[nod][f] < aux[f])
            {
                aux[f] = aux[nod] + cost[nod][f];
                if (d[f] == 0)
                {
                    d[f] = 1;
                    q.push(f);
                }
            }
        }
    }
}

bool djk ()
{
    for (int i = 1; i <= n; i++)
    {
        d[i] = INF;
        pr[i] = INF;
        t[i] = 0;
    }
    d[src] = 0;
    pr[src] = 0;
    pq.push({src, 0});
    while (!pq.empty())
    {
        int nod = pq.top().nod, val = pq.top().cost;
        pq.pop();
        if (val > d[nod])
        {
            continue;
        }
        for (auto f : mc[nod])
        {
            if (cap[nod][f] > 0 && d[nod] + cost[nod][f] + aux[nod] - aux[f] < d[f])
            {
                d[f] = d[nod] + cost[nod][f] + aux[nod] - aux[f];
                pr[f] = pr[nod] + cost[nod][f];
                t[f] = nod;
                pq.push({f, d[f]});
            }
        }
    }
    return (d[dest] != INF);
}

void solve ()
{
    int m;
    cin >> n >> m >> src >> dest;
    while (m--)
    {
        int x, y, c, pret;
        cin >> x >> y >> c >> pret;
        mc[x].push_back(y);
        mc[y].push_back(x);
        cap[x][y] = c;
        cost[x][y] = pret;
        cost[y][x] = -pret;
    }
    bf();
    int ans = 0;
    while (djk())
    {
        int nod = dest, mn = INF;
        while (nod != src)
        {
            mn = min(mn, cap[t[nod]][nod]);
            nod = t[nod];
        }
        ans += mn * pr[dest];
        nod = dest;
        while (nod != src)
        {
            cap[t[nod]][nod] -= mn;
            cap[nod][t[nod]] += mn;
            nod = t[nod];
        }
        for (int i = 1; i <= n; i++)
        {
            aux[i] = d[i];
        }
    }
    cout << ans;
    cout << '\n';
}

signed main ()
{
#ifdef LOCAL
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#else
    freopen("fmcm.in", "r", stdin);
    freopen("fmcm.out", "w", stdout);
#endif // LOCAL
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    long long tt;
    //cin >> tt;
    tt = 1;
    while (tt--)
    {
        solve();
    }
    return 0;
}
