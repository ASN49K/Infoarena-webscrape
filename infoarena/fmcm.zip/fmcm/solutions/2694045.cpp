#include <bits/stdc++.h>

using namespace std;

ifstream f("fmcm.in");
ofstream g("fmcm.out");

int S,D,n,ans,tata[355],new_cost_bell[355],cost_dijk[355],cost_bell[355],inCoada[355],cost[355][355],flux[355][355],C[355][355];
vector <int> v[355];
priority_queue < pair < int , int > , vector < pair < int , int > > , greater < pair < int , int > > > h;
queue <int> q;

void Bellman()
{
    for(int i=1;i<=n;i++)cost_bell[i]=INT_MAX/2;

    cost_bell[S]=0;
    inCoada[S]=1;
    q.push(S);

    while(!q.empty())
    {
        int nod=q.front();
        inCoada[nod]=0;
        q.pop();

        for(int i=0;i<v[nod].size();i++)
        {
            int vecin=v[nod][i];
            if(flux[nod][vecin]<C[nod][vecin] && cost_bell[vecin]>cost_bell[nod]+cost[nod][vecin])
            {
                cost_bell[vecin]=cost_bell[nod]+cost[nod][vecin];
                if(inCoada[vecin]==0)
                {
                    inCoada[vecin]=1;
                    q.push(vecin);
                }
            }
        }
    }
}

int Dijkstra()
{
    for(int i=1;i<=n;i++)
    {
        cost_dijk[i]=INT_MAX/2;
        new_cost_bell[i]=INT_MAX/2;
        tata[i]=0;
    }

    h.push({0,S});
    cost_dijk[S]=0;
    new_cost_bell[S]=0;

    while(!h.empty())
    {
        int nod=h.top().second;
        int min_cost=h.top().first;
        h.pop();

        if(cost_dijk[nod]==min_cost)
        {
            for(int i=0;i<v[nod].size();i++)
            {
                int vecin=v[nod][i];
                int cost_intre=cost[nod][vecin]+cost_bell[nod]-cost_bell[vecin];
                if(flux[nod][vecin]<C[nod][vecin] && cost_dijk[vecin]>cost_dijk[nod]+cost_intre)
                {
                    cost_dijk[vecin]=cost_dijk[nod]+cost_intre;
                    new_cost_bell[vecin]=new_cost_bell[nod]+cost[nod][vecin];
                    tata[vecin]=nod;
                    h.push({cost_dijk[vecin],vecin});
                }
            }
        }
    }

    if(cost_dijk[D]==INT_MAX/2)return 0;

    int min_flow=C[tata[D]][D]-flux[tata[D]][D];
    int nod=tata[D];
    while(tata[nod]!=0)
    {
        min_flow=min(min_flow,C[tata[nod]][nod]-flux[tata[nod]][nod]);
        nod=tata[nod];
    }

    ans+=min_flow*new_cost_bell[D];

    nod=D;
    while(tata[nod]!=0)
    {
        flux[tata[nod]][nod]+=min_flow;
        flux[nod][tata[nod]]-=min_flow;
        nod=tata[nod];
    }

    for(int i=1;i<=n;i++)
        cost_bell[i]=new_cost_bell[i];

    return 1;
}

int m,i,x,y,c,z;
int main()
{
    f>>n>>m>>S>>D;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>c>>z;
        v[x].push_back(y);v[y].push_back(x);
        C[x][y]=c;
        cost[x][y]=z;cost[y][x]=-z;
    }

    Bellman();
    while(Dijkstra());

    g<<ans;
    return 0;
}
