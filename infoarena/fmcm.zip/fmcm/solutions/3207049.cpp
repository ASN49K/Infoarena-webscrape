#include <fstream>
#include <queue>
#include <vector>
#define s second
#define f first
const int NMAX=405;
#define int long long

using namespace std;
ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

vector <int> v[NMAX];
queue <int> c;
priority_queue <pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> ss;
int cost[NMAX][NMAX], cap[NMAX][NMAX];
int dist[NMAX], distb[NMAX], minm[NMAX], t[NMAX];
bool viz[NMAX];
int n, m, s, d;
bool newc=true;

int flux();
int dijkstra(int);
void bellman(int);

signed main()
{
    int i, a, b, c, dd;
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m>>s>>d;
    for(i=1; i<=m; i++)
    {
        fin>>a>>b>>c>>dd;
        v[a].push_back(b);
        v[b].push_back(a);
        cap[a][b]=c;
        cost[a][b]=dd;
        cost[b][a]=-dd;
    }
    fout<<flux();
    return 0;
}

int flux()
{
    bellman(s);
    int ans=0;
    while(newc)
    {
        newc=false;
        ans+=dijkstra(s);
    }
    return ans;
}

void bellman(int nod)
{
    int i, p;
    for(i=1; i<=n; i++)
    {
        distb[i]=1e18;
        viz[i]=false;
    }
    c.push(nod); distb[nod]=0; viz[nod]=true;
    while(!c.empty())
    {
        p=c.front(); c.pop(); viz[p]=false;
        for(auto i:v[p])
        {
            if(cap[p][i]>0 && distb[i]>distb[p]+cost[p][i])
            {
                distb[i]=distb[p]+cost[p][i];
                if(!viz[i])
                {
                    c.push(i);
                    viz[i]=true;
                }
            }
        }
    }
}

int dijkstra(int nod)
{
    int i, ans=0;
    pair<int, int> p;
    for(i=1; i<=n; i++)
    {
        dist[i]=1e18;
        minm[i]=1e18;
        t[i]=s;
        viz[i]=false;
    }
    dist[nod]=0; ss.push({0, nod});
    while(!ss.empty())
    {
        p=ss.top(); ss.pop();
        if(!viz[p.s])
        {
            viz[p.s]=true;
            for(auto i:v[p.s])
            {
                if(cap[p.s][i]>0 && dist[i]>p.f+cost[p.s][i]+distb[p.s]-distb[i])
                {
                    dist[i]=p.f+cost[p.s][i]+distb[p.s]-distb[i];
                    minm[i]=min(minm[p.s], cap[p.s][i]);
                    t[i]=p.s;
                    ss.push({dist[i], i});
                }
            }
        }
    }
    if(dist[d]==1e18) return 0;
    nod=d; newc=true;
    while(nod!=s)
    {
        ans+=minm[d]*cost[t[nod]][nod];
        cap[t[nod]][nod]-=minm[d];
        cap[nod][t[nod]]+=minm[d];
        nod=t[nod];
    }
    for(i=1; i<=n; i++) distb[i]+=dist[i];
    return ans;
}
