#include<iostream>
#include<vector>
#include<algorithm>
#include<queue>
#include<bitset>
#include<cstring>
using namespace std;

constexpr int NMAX = 1e3 + 10;
const int INF = 1e9;

struct muchie
{
    int from,to,cap,cost,flow;
};

vector<int> vecini[NMAX]; vector<muchie> muchii;
vector<int> dist,t;
bitset<NMAX> inq;

bool bf(int s,int e)
{
    fill(dist.begin(),dist.end(),INF); dist[s] = 0; t[s] = -1;
    queue<int> q; q.push(s); inq.reset(); inq[s] = 1;
    while(!q.empty())
        {
            int v = q.front(); q.pop(); inq[v] = 0;
            for(auto it : vecini[v])
                {
                    if((muchii[it].cap - muchii[it].flow) > 0)
                        {
                            if(dist[muchii[it].to] > dist[v] + muchii[it].cost)
                                {
                                    dist[muchii[it].to] = dist[v] + muchii[it].cost; t[muchii[it].to] = it;
                                    if(!inq[muchii[it].to])
                                        {
                                            inq[muchii[it].to] = 1;
                                            q.push(muchii[it].to);
                                        }
                                }
                        }
                }
        }

    return (dist[e] != INF);
}

int main()
{
    freopen("fmcm.in","r",stdin);
    freopen("fmcm.out","w",stdout);

    int n,m,s,e,a,b,c,d; cin >> n >> m >> s >> e;
    for(int i = 0; i < m ; i++)
        {
            cin >> a >> b >> c >> d;
            muchii.push_back({a,b,c,d,0}); vecini[a].emplace_back(2 * i);
            muchii.push_back({b,a,0,-d,0}); vecini[b].emplace_back(2 * i + 1);
        }

    long long ans = 0,flux = 0; dist.resize(n + 1); t.resize(n + 1);
    while(bf(s,e))
        {
            int delta = INF;
            for(int v = t[e]; v != -1 ; v = t[muchii[v].from]) delta = min(delta,muchii[v].cap - muchii[v].flow);
            for(int v = t[e]; v != -1 ; v = t[muchii[v].from]) muchii[v].flow += delta,muchii[v ^ 1].flow -= delta;
            ans += 1LL * delta * dist[e];
        }


    cout << ans;
}
