#include <bits/stdc++.h>
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("O3")
#pragma GCC optimize("fast-math")

using namespace std;
typedef long long ll;
typedef pair<ll,ll> pll;
const int NMAX=355,MMAX=12505,INF=1e9;
int cap[NMAX][NMAX],cost[NMAX][NMAX];
int edg[NMAX][NMAX],deg[NMAX];
int bellman_dist[NMAX],dist[NMAX],start,sink;
int prv[NMAX];
set<pair<int, int > > s;
int main()
{
    ifstream fin("fmcm.in");
    ofstream fout("fmcm.out");
    ios_base::sync_with_stdio(false); fin.tie(0); fout.tie(0);
    int n,m;
    fin>>n>>m>>start>>sink;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            cost[i][j]=INF;
    for(int i=0;i<m;i++){
        int u,v,c,z;
        fin>>u>>v>>c>>z;

        cost[u][v]=z,cost[v][u]=-z,cap[u][v]=c;
        edg[u][deg[u]++]=v;
        edg[v][deg[v]++]=u;
    }
    if(start==sink){
        fout<<0;
        return 0;
    }
    for(int i=1;i<=n;i++) bellman_dist[i]=INF;
    bellman_dist[start]=0;
    for(int iter=0;iter<n;iter++){
        for(int i=1;i<=n;i++){
            for(int j=0;j<deg[i];j++){
                int it=edg[i][j];
                if(cap[i][it])
                    bellman_dist[it]=min(bellman_dist[it],bellman_dist[i]+cost[i][it]);
            }
        }
    }
    //assert(0);
    //for(int i=1;i<=n;i++)
    //    for(int j=1;j<=n;j++)
    //        cost[i][j]+=bellman_dist[i]-bellman_dist[j];

    int ans=0,total_cost=0;
    while(1){
        for(int i=1;i<=n+1;i++) dist[i]=INF,prv[i]=0;
        dist[start]=0,prv[start]=start;
        s.insert({dist[start],start});
        while(!s.empty()){
            int u=s.begin()->second;
            s.erase(s.begin());
            for(int j=0;j<deg[u];j++){
                int it=edg[u][j],new_d=cost[u][it]+bellman_dist[u]-bellman_dist[it];
                if(cap[u][it] && dist[u]+new_d<dist[it]){
                    if(dist[it]!=INF) s.erase({dist[it],it});
                    dist[it]=dist[u]+new_d;
                    s.insert({dist[it],it});
                    prv[it]=u;
                }
            }
        }
        if(prv[sink]==0) break;
        //for(int i=1;i<=n;i++) bellman_dist[i]=dist[i];
        int total_flow=INF,aux=sink;
        while(aux!=start){
            if(cap[prv[aux]][aux]<total_flow)
                total_flow=cap[prv[aux]][aux];
            aux=prv[aux];
        }
        aux=sink;
        ans+=total_flow,total_cost+=(dist[sink]+bellman_dist[sink])*total_flow;
        while(aux!=start){
            cap[prv[aux]][aux]-=total_flow,cap[aux][prv[aux]]+=total_flow;
            aux=prv[aux];
        }
    }
    fout<<total_cost;
    return 0;
}
