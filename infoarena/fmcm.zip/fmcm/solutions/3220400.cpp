#include <bits/stdc++.h>

using namespace std;

#define cin fin
#define cout fout

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

const int inf = 1e9;

struct edge
{
    int u, v, cap, flow, cost;
};

struct MCMF
{
    vector<edge> edg;
    vector<vector<int>> g;
    int n;
    int s, t;
    MCMF(int n, int s, int t) : n(n), s(s), t(t)
    {
        g.resize(n + 1);
    }
    void add_edge(int u, int v, int c, int cost)
    {
        int sz = edg.size();
        edg.push_back({u, v, c, 0, cost});
        edg.push_back({v, u, 0, 0, -cost});
        g[u].push_back(sz);
        g[v].push_back(sz + 1);
    }

    vector<int> bellman()
    {
        vector<int> dist(n + 1, inf);
        dist[s] = 0;
        bool wtf = false;
        for (int i = 1; i <= n; ++i)
        {
            for (int x = 0; x < edg.size(); ++x)
            {
                auto j = edg[x];
                if (j.cap > 0)
                {
                    dist[j.v] = min(dist[j.v], dist[j.u] + j.cost);
                }
            }
        }
        return dist;
    }

    pair<int, int> dijkstra()
    {
        vector<int> dist(n + 1, inf);
        dist[s] = 0;

        vector<int> par(n + 1);

        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> best;
        best.push({0, s});

        vector<bool> vis(n + 1);

        while (!best.empty())
        {
            auto [cost, qui] = best.top();
            best.pop();
            if (vis[qui])
            {
                continue;
            }
            vis[qui] = true;
            for (auto i : g[qui])
            {
                auto e = edg[i];
                if (e.cap - e.flow == 0)
                {
                    continue;
                }

                if (cost + e.cost < dist[e.v])
                {
                    dist[e.v] = cost + e.cost;
                    par[e.v] = i;
                    best.push({dist[e.v], e.v});
                }
            }
        }

        if (dist[t] == inf)
        {
            return {0, inf};
        }

        pair<int, int> ans;
        int push = inf;
        int frog = t;
        while (frog != s)
        {
            int cap = edg[par[frog]].cap - edg[par[frog]].flow;
            push = min(push, cap);
            frog = edg[par[frog]].u;
        }
        frog = t;
        ans.first = push;
        while (frog != s)
        {
            edg[par[frog]].flow += push;
            edg[par[frog] ^ 1].flow -= push;
            ans.second += edg[par[frog]].cost * push;
            frog = edg[par[frog]].u;
        }
        return ans;
    }

    pair<int, int> flow()
    {
        vector<edge> cpy = edg;
        vector<int> dist = bellman();
        for (auto &i : edg)
        {
            i.cost = dist[i.u] + i.cost - dist[i.v]; // si acum un path isi schimba costu cu dist[s]-dist[t]
        }
        int c = dist[s] - dist[t];
        pair<int, int> ans;
        while (true)
        {
            pair<int, int> add = dijkstra();
            if (add.first == 0)
            {
                edg = cpy;
                return ans;
            }
            ans.first += add.first;
            ans.second += add.second - c * add.first;
        }
    }
};
int main()
{
    cin.tie(nullptr)->sync_with_stdio(false);
    int n, m, s, d;
    cin >> n >> m >> s >> d;
    MCMF G(n, s, d);
    for (int i = 1; i <= m; ++i)
    {
        int a, b, cap, cost;
        cin >> a >> b >> cap >> cost;
        G.add_edge(a, b, cap, cost);
    }
    cout << G.flow().second << '\n';
}