#include <bits/stdc++.h>

using namespace std;

ifstream f("fmcm.in");
ofstream g("fmcm.out");

queue < int> q;
vector < int > v[355];
priority_queue < pair < int , int > , vector < pair < int , int > > , greater < pair < int , int > > > h;
int n,s,maxflow,d,tata[355],inCoada[355],cost_bell[355],new_cost_bell[355],cost_dijk[355],cost[355][355],C[355][355],flux[355][355];

void Bellman()
{
    for(int i=1;i<=n;i++)cost_bell[i]=INT_MAX/2;
    cost_bell[s]=0;q.push(s);inCoada[s]=1;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        inCoada[nod]=0;

        for(int i=0;i<v[nod].size();i++)
        {
            int vecin=v[nod][i];
            int cost_intre=cost[nod][vecin];
            if(C[nod][vecin]>0 && cost_bell[vecin]>cost_bell[nod]+cost_intre)
            {
                cost_bell[vecin]=cost_bell[nod]+cost_intre;
                if(inCoada[vecin]==0)q.push(vecin),inCoada[vecin]=1;
            }
        }
    }
}

int Dijkstra()
{
    for(int i=1;i<=n;i++)new_cost_bell[i]=INT_MAX/2,cost_dijk[i]=INT_MAX/2,tata[i]=0;
    new_cost_bell[s]=0;cost_dijk[s]=0;h.push({0,s});

    while(!h.empty())
    {
        int nod=h.top().second;
        int cst=h.top().first;
        h.pop();

        if(cost_dijk[nod]==cst)
        {
            for(int i=0;i<v[nod].size();i++)
            {
                int vecin=v[nod][i];
                int cost_intre=cost[nod][vecin]+cost_bell[nod]-cost_bell[vecin];

                if(flux[nod][vecin]<C[nod][vecin] && cost_dijk[vecin]>cost_dijk[nod]+cost_intre)
                {
                    cost_dijk[vecin]=cost_dijk[nod]+cost_intre;
                    h.push({cost_dijk[vecin],vecin});
                    tata[vecin]=nod;
                    new_cost_bell[vecin]=new_cost_bell[nod]+cost[nod][vecin];
                }
            }
        }
    }

    if(cost_dijk[d]==INT_MAX/2)return 0;

    int nod,minflow=INT_MAX;

    nod=d;
    while(tata[nod]!=0)
    {
        minflow=min(minflow,C[tata[nod]][nod]-flux[tata[nod]][nod]);
        nod=tata[nod];
    }

    maxflow=maxflow+minflow*new_cost_bell[d];

    nod=d;
    while(tata[nod]!=0)
    {
        flux[tata[nod]][nod]+=minflow;
        flux[nod][tata[nod]]-=minflow;
        nod=tata[nod];
    }

    for(int i=1;i<=n;i++)cost_bell[i]=new_cost_bell[i];
    return 1;
}

int m,i,x,y,c,cst;
int main()
{
    f>>n>>m>>s>>d;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>c>>cst;
        v[x].push_back(y);
        v[y].push_back(x);
        C[x][y]=c;
        cost[x][y]=cst;cost[y][x]=-cst;
    }

    Bellman();
    while(Dijkstra());
    g<<maxflow;
    return 0;
}
