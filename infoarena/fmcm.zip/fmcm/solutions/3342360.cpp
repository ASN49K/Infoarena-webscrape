#include<bits/stdc++.h>
#define nl '\n'
#define pii pair<int,int>
using namespace std;
const string file="fmcm";
ifstream f(file+".in");
ofstream g(file+".out");
//#define f cin
//#define g cout
#define INF 0x3f3f3f3f
struct MinCostMaxFlow {
    struct edge {
        int to,rez,cap,cost;
    };
    int n,s,t;
    vector<vector<edge>>v;
    vector<int>dist,pot;
    vector<int>dad,dadedge;
    MinCostMaxFlow(int _n, int _s, int _t) {
        n=_n,s=_s,t=_t;
        v.resize(n+1);
        dist.resize(n+1);
        pot.resize(n+1);
        dad.resize(n+1);
        dadedge.resize(n+1);
    }
    void add(int x, int y, int cap, int cost) {
        edge a={y,(int)v[y].size(),cap,cost};
        edge b={x,(int)v[x].size(),0,-cost};
        v[x].push_back(a);
        v[y].push_back(b);
    }
    void bellman() {
        fill(pot.begin(),pot.end(),INT_MAX);
        pot[s]=0;
        queue<int>q;
        vector<bool>fr(n+1,0);
        q.push(s);
        fr[s]=1;
        while(!q.empty()) {
            int x=q.front();
            q.pop();
            fr[x]=0;
            if (pot[x]==INT_MAX) continue;
            for (auto &e:v[x]) {
                if (e.cap>0 && pot[e.to]>pot[x]+e.cost) {
                    pot[e.to]=pot[x]+e.cost;
                    if (!fr[e.to]) {
                        fr[e.to]=1;
                        q.push(e.to);
                    }
                }
            }
        }
    }
    bool dijkstra() {
        fill(dist.begin(),dist.end(),INF);
        dist[s]=0;
        priority_queue<pii,vector<pii>,greater<pii>>q;
        q.push({0,s});
        while(!q.empty()) {
            int cost=q.top().first;
            int x=q.top().second;
            q.pop();

            if (cost!=dist[x]) continue;
            for (int i=0; i<v[x].size(); ++i) {
                edge &e=v[x][i];
                if (e.cap>0) {
                    int d=cost+e.cost+pot[x]-pot[e.to];
                    if (d<dist[e.to]) {
                        dist[e.to]=d;
                        dad[e.to]=x;
                        dadedge[e.to]=i;
                        q.push({d,e.to});
                    }
                }
            }
        }
        return dist[t]!=INF;
    }
    pii mincostmaxflow() {
        bellman();
        int flow=0,cost=0;
        while (dijkstra()) {
            for (int i=1; i<=n; ++i)
                if (dist[i]<INF) pot[i]+=dist[i];
            int flux=INF;
            for (int x=t; x!=s; x=dad[x]) {
                edge &e=v[dad[x]][dadedge[x]];
                flux=min(flux,e.cap);
            }
            for (int x=t; x!=s; x=dad[x]) {
                edge &e=v[dad[x]][dadedge[x]];
                e.cap-=flux;
                v[x][e.rez].cap+=flux;
                cost+=flux*e.cost;
            }
            flow+=flux;
        }
        return {flow,cost};
    }
};

int n,m,s,t;
int main(){
    f>>n>>m>>s>>t;
    MinCostMaxFlow fl(n,s,t);
    for (int i=1; i<=m; ++i) {
        int x,y,cap,cost;
        f>>x>>y>>cap>>cost;
        fl.add(x,y,cap,cost);
    }
    g<<fl.mincostmaxflow().second;
    system("pause");
    return 0;
}