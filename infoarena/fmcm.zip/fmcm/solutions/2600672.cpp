#include <bits/stdc++.h>

using namespace std;
ifstream f("fmcm.in");
ofstream g("fmcm.out");
//----------------------------------------
///Globale
const int INF = 1000000000,MAX = 351;
int n,s,dest,cap[MAX][MAX],flux[MAX][MAX],d[MAX],cost[MAX][MAX],par[MAX];
vector<int>muchii[MAX];
bitset<MAX>ap;
//----------------------------------------
///Functii
void citire();
void rezolvare();
//----------------------------------------
int main()
{
    citire();
    rezolvare();
    return 0;
}
//----------------------------------------
bool bellman()
{
    for(int i = 1; i <= n; ++i)
        d[i] = INF;
    d[s] = 0;
    queue<int>q;
    q.push(s);
    ap[s] = 1;
    while(!q.empty())
    {
        int nod = q.front();
        q.pop();
        ap[nod] = 0;
        for(auto it : muchii[nod])
            if(d[it] > d[nod] + cost[nod][it] && flux[nod][it] < cap[nod][it])
            {
                d[it] = d[nod] + cost[nod][it];
                par[it] = nod;
                if(ap[it] == 0)
                {
                    q.push(it);
                    ap[it] = 1;
                }
            }
    }
    if(d[dest] != INF)
        return 1;
    return 0;
}
//----------------------------------------
void rezolvare()
{
    int rasp = 0;
    while(bellman())
    {
        int flow = INF;
        int nod = dest;
        while(nod != s)
        {
            int nod2 = par[nod];
            flow = min(flow,cap[nod2][nod] - flux[nod2][nod]);
            nod = nod2;
        }
        nod = dest;
        while(nod != s)
        {
            int nod2 = par[nod];
            flux[nod2][nod] += flow;
            rasp += flow * cost[nod2][nod];
            nod = nod2;
        }
    }
    g << rasp;
}
//----------------------------------------
void citire()
{
    int m;
    f >> n >> m >> s >> dest;
    while(m--)
    {
        int x,y,c,z;
        f >> x >> y >> c >> z;
        cap[x][y] = c;
        cost[x][y] = z;
        cost[y][x] = -z;
        muchii[x].push_back(y);
        muchii[y].push_back(x);
    }
}
