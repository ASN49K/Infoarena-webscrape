#include <bits/stdc++.h>

using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

const int NMAX = 355;
const int INF = (1<<29);
vector <int> v[NMAX];
int cost[NMAX][NMAX],tata[NMAX],dist[NMAX];
int capacitate[NMAX][NMAX],flux[NMAX][NMAX];
int n,m,S,D,rasp,x,y,c,z;
bool ver[NMAX];

void citire(){
    fin >> n >> m >> S >> D;
    for(int i=1;i<=m;i++){
        fin >> x >> y >> c >> z;
        capacitate[x][y]=c;
        v[x].push_back(y);
        v[y].push_back(x);
        cost[x][y]=z;
        cost[y][x]=-z;
    }
}

bool muchie_disponibila(int node1,int node2){
    if(capacitate[node1][node2]>flux[node1][node2])
        return true;
    return false;
}

bool BellMan(){
    for(int i=1;i<=n;i++) {
        dist[i]=INF;
        ver[i]=false;
    }
    queue <int> q;
    q.push(S);
    dist[S]=0;
    while(!q.empty()){
        int node=q.front();
        ver[node]=true;
        q.pop();
        for(int i=0;i<v[node].size();i++){
            int vecin=v[node][i];
            if(ver[vecin]==true) continue;
            if(muchie_disponibila(node,vecin) == true){
                if(dist[vecin]>dist[node]+cost[node][vecin]){
                    dist[vecin]=dist[node]+cost[node][vecin];
                    q.push(vecin);
                    tata[vecin]=node;
                }
            }
        }
    }
    if(ver[D]==true) return true;
    return false;
}

void solve(){
    /// rezolv intai fara optimizarea de dijkstra:
    while(BellMan()==true){
        int minim = INF;
        int aux = D;
        while(aux!=S){
            if(capacitate[tata[aux]][aux]-flux[tata[aux]][aux]<minim)
                minim=capacitate[tata[aux]][aux]-flux[tata[aux]][aux];
            aux=tata[aux];
        }
        rasp+=dist[D]*minim;
        aux = D;
        while(aux!=S){
            flux[tata[aux]][aux]+=minim;
            flux[aux][tata[aux]]-=minim;
            aux=tata[aux];
        }
    }
}

void afis(){
    fout << rasp;
}

int main()
{
    citire();
    solve();
    afis();
    return 0;
}
