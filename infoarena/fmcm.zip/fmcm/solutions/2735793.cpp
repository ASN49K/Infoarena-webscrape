#include <bits/stdc++.h>
#define inf (1LL<<31)-1

using namespace std;

ifstream f("fmcm.in");
ofstream g("fmcm.out");

int n,m,s,d,old[355],dist[355],reals[355];
int cap[355][355],cost[355][355],tata[355];

int sol;

bool fost[355];

vector<int>G[355];
priority_queue< pair<int,int> > cd;

bool dijkstra()
{
    for(int i=1; i<=n; i++) dist[i]=inf;

    dist[s]=0;
    cd.push( make_pair(0,s) );

    while( !cd.empty() )
    {
        int nod=cd.top().second;
        int z=-cd.top().first;
        cd.pop();

        if( dist[nod]!=z ){
         continue;
        }

        for(int i=0; i<G[nod].size(); i++)
        {
            int x=G[nod][i];

            if( cap[nod][x] )
            {
                int new_dist=dist[nod]+cost[nod][x]+old[nod]-old[x];
                if( new_dist<dist[x] )
                {
                    dist[x]=new_dist;
                    reals[x]=reals[nod]+cost[nod][x];
                    tata[x]=nod;
                    cd.push( make_pair(dist[x],x) );
                }
            }
        }
    }

    for(int i=1; i<=n; i++)
        old[i]=reals[i];

    if( dist[d]==inf ) return 0;

    int mini=inf;

    for(int nod=d; nod!=s; nod=tata[nod])
        mini=min( mini,cap[tata[nod]][nod] );

    for(int nod=d; nod!=s; nod=tata[nod])
    {
        cap[tata[nod]][nod]-=mini;
        cap[nod][tata[nod]]+=mini;
    }

    sol+=mini*reals[d];
    return 1;
}

void bellmanford()
{
    for(int i=1; i<=n; i++) old[i]=inf;

    queue <int> coada;
    old[s]=0;
    coada.push(s);
    fost[s]=1;

    while( !coada.empty() )
    {
        int x=coada.front();
        coada.pop();

        fost[x]=0;

        for(int i=0; i<G[x].size(); i++)
        {
            int nod=G[x][i];

            if( cap[x][nod]==0 ) continue;

            if( old[x]+cost[x][nod]<old[nod] )
            {
                old[nod]=old[x]+cost[x][nod];

                if( fost[nod]==0 )
                {
                    fost[nod]=1;
                    coada.push(nod);
                }
            }
        }
    }
}

int main()
{
    f>>n>>m>>s>>d;

    for(int i=1; i<=m; i++)
    {
        int x,y,c,z;
        f>>x>>y>>c>>z;
        cap[x][y]=c;
        cost[x][y]=z;
        cost[y][x]=-z;

        G[x].push_back(y);
        G[y].push_back(x);
    }

    bellmanford();

    while( dijkstra() );

    g<<sol;
}
