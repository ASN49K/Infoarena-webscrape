#include <bits/stdc++.h>
using namespace std;
ifstream fin("fmcm.in");
ofstream fout("fmcm.out");
const int INF = (1<<29);
const int NMAX = 355;
int f[NMAX][NMAX],c[NMAX][NMAX],cost[NMAX][NMAX],d[NMAX],tata[NMAX];
int S,D,n,m,x,y,z,cc,nr;
bool ver[NMAX];
vector <int> v[NMAX];
int Bellman_Ford(){
    queue <int> q;
    for(int i=1;i<=n;i++){
        d[i]=INF;
        ver[i]=false;
    }
    q.push(S);
    ver[S]=true;
    d[S]=0;
    while(!q.empty()){
        int nod=q.front();
        ver[nod]=false;
        q.pop();
        for(int i=0;i<v[nod].size();i++){
            int vecin=v[nod][i];
            if(c[nod][vecin]>f[nod][vecin] and d[vecin]>d[nod]+cost[nod][vecin]){
                d[vecin]=d[nod]+cost[nod][vecin];
                if(ver[vecin]==false){
                    ver[vecin]=true;
                    q.push(vecin);
                }
                tata[vecin]=nod;
            }
        }
    }
    if(d[D]!=INF){
        int minim=INF;
        nr=1;
        for(int i=D;i!=S;i=tata[i]) minim=min(minim,c[tata[i]][i]-f[tata[i]][i]);
        for(int i=D;i!=S;i=tata[i]) {
            f[tata[i]][i]+=minim;
            f[i][tata[i]]-=minim;
        }
        return minim*d[D];
    }
    return 0;
}

int main()
{
    fin >> n >> m >> S >> D;
    for(int i=1;i<=m;i++){
        fin >> x >> y >> cc >> z;
        v[x].push_back(y);
        v[y].push_back(x);
        c[x][y]=cc;
        cost[x][y]=z;
        cost[y][x]=-z;
    }
    int rasp=0;
    nr=1;
    while(nr==1){
        nr=0;
        rasp+=Bellman_Ford();
    }
    fout << rasp;
    return 0;
}
