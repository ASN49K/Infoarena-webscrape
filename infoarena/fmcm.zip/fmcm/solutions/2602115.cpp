#include <fstream>
#include <queue>
#include <vector>
#define inf 2000000000
using namespace std;
ifstream fin("fmcm.in");
ofstream fout("fmcm.out");
vector<int> g[351];
queue<int> q;
int tata[351];
int f[351][351],c[351][351],cost[351][351];
int d[351];
bool viz[351];
int n,m,x,y,start,finish;
long long sol;
int bfs()
{
    q.empty();
    q.push(start);
    for(int i=1;i<=n;i++)
    {
        tata[i]=viz[i]=0;
        d[i]=inf;
    }
    d[start]=0;
    viz[start]=1;
    while(!q.empty())
    {
        int nod=q.front();
        viz[nod]=0;
        q.pop();
        for(int i=0;i<g[nod].size();i++)
        {
            int nou=g[nod][i];
            if(c[nod][nou]-f[nod][nou]>0)
            {
                int dist=d[nod]+cost[nod][nou];
                if(dist<d[nou])
                {
                    if(viz[nou]==0)
                    {
                        viz[nou]=1;
                        q.push(nou);
                    }
                    d[nou]=dist;
                    tata[nou]=nod;
                }
            }
        }
    }
    return d[finish]!=inf;
}
int minim(int nod)
{
    int Min=inf;
    while(nod!=start)
    {
        int nou=tata[nod];
        Min=min(Min,c[nou][nod]-f[nou][nod]);
        nod=nou;
    }
    return Min;
}
void add(int val,int nod)
{
    while(nod!=start)
    {
        int nou=tata[nod];
        f[nou][nod]+=val;
        f[nod][nou]-=val;
        nod=nou;
    }
}
int main()
{
    fin>>n>>m>>start>>finish;
    for(int i=1;i<=m;i++)
    {
        fin>>x>>y;
        g[x].push_back(y);
        g[y].push_back(x);
        fin>>c[x][y]>>cost[x][y];
        cost[y][x]=-cost[x][y];
    }
    while(bfs()==1)
    {
        int qmin=minim(finish);
        add(qmin,finish);
        sol+=d[finish]*qmin;
    }
    fout<<sol;
    return 0;
}
