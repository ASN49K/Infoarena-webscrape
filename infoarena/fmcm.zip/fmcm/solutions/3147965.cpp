#include <bits/stdc++.h>
#include <cstring>
//#pragma GCC optimize ("O3")
#define din cin
#define dout out
#define pi 3.14159265359
#define sw(x,y) x^=y,y^=x,x^=y
#define bmin(a,b)((a<b)?(a):(b))
#define bmax(a,b)((a>b)?(a):(b))
#define bminify(a,b)a=bmin(a,b)
#define bmaxify(a,b)a=bmax(a,b)
#define forq(i,ii,n)for(i=ii;i<n;i++)
#define f first
#define s second
#define mod 1000000297ll
#define smax 51000
using namespace std;
typedef long long ll;
//ifstream in("fmcm.in");
//ofstream out("fmcm.out");
//FILE *fin=fopen("fmcm.in","r");
//FILE *fout=fopen("fmcm.out","w");
int n,m,i,j,k,l,n1,n2,v0[351][351],v1[351][351],v2[351][351],d[351],e[351],f[351],w,ww;vector<int>g[351];
priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>>qu;
queue<int>c;bitset<351>b;ll tf,tc;
int main()
{
freopen("fmcm.in", "rt", stdin);
freopen("fmcm.out", "wt", stdout);
scanf("%d%d%d%d",&n,&m,&n1,&n2);
forq(k,0,m)
    scanf("%d%d",&i,&j),scanf("%d%d",&v0[i][j],&v1[i][j]),g[i].push_back(j),g[j].push_back(i),v0[j][i]=-0,v1[j][i]=-v1[i][j];
//forq(i,0,n)for(auto j:g[i])printf("%d %d: %d %d %d %d\n",i,j,v[i][j][0],v[i][j][1],v[j][i][0],v[j][i][1]);
fill(d,d+n+1,INT_MAX/2);
d[n1]=0,c.push(n1),f[n1]=1;
while(l)
{
    i=c.front(),f[i]=0;c.pop();
    //printf("%d:%d\n",i,d[i]);
    for(auto j:g[i])
        if(v0[i][j])
            if(d[j]>d[i]+v1[i][j])
                {d[j]=d[i]+v1[i][j];if(f[j]==0)f[j]=1,c.push(f[j]);}
}
forq(i,1,n+1)for(auto j:g[i])v2[i][j]=v1[i][j]+d[i]-d[j];
while(true)
{
    memset(e,0x7f,sizeof(e)),f[n2]=0;
    b[n1]=1,e[n1]=0,l=1,qu.push(make_pair(0,n1));
    while(!qu.empty())
    {
        i=qu.top().s,w=qu.top().f;
        qu.pop();
        //pop_heap(c,c+l,greater<ll>());--l;
        if(e[i]==w)
        {

            for(auto j:g[i])
                if(v0[i][j])
                    {/*printf("%d %d %d\n",i,j,v2[i][j]);*/if(e[j]>e[i]+v2[i][j])
                        e[j]=e[i]+v2[i][j],f[j]=i,qu.push(make_pair(e[j],j));}
        }
    }
    if(e[n2]==0x7f7f7f7f)break;
    else{
        j=n2,k=INT_MAX;//printf("fini");
        while(j!=n1)bminify(k,v0[f[j]][j]),j=f[j];
        //printf("pa%d\n",k);
        tf+=k,j=n2,i=0;
        while(j!=n1)
            v0[f[j]][j]-=k,v0[j][f[j]]+=k,tc+=v1[f[j]][j]*k,j=f[j];
    }
}
printf("%lld",tc);
}
