#include <fstream>
#include <vector>
#include <queue>
#include <string>

using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

const int inf = (1<<30)-1;
const int nmax = 350, fmax = 10000;

vector <int> g[nmax+1];
int f[nmax+1][nmax+1], c[nmax+1][nmax+1];

int d[nmax+1];
queue <int> q;

struct str{
    int x, y;
    str(int xnew, int ynew) {
        x = xnew;
        y = ynew;
    }
};

struct str_cmp{
    bool operator ()( str x, str y ) {
        return x.y > y.y;
    }
};

priority_queue <str, vector <str>, str_cmp> h;
int r[nmax+1];

string::iterator it;
void read_int32( int & x ) {
    while ( *it != '-' && ( *it < '0' || *it > '9' ) ) {
        ++ it;
    }
    x = 0;
    int s;
    if ( *it == '-' ) {
        s = -1;
        ++ it;
    } else {
        s = 1;
    }
    while ( *it >= '0' && *it <= '9' ) {
        x = x*10+*it-'0';
        ++ it;
    }
    x *= s;
}

int main( ) {
    string s;
    getline(fin, s, char(0));
    it = s.begin();

    int n, m, source, destination;
    read_int32(n);
    read_int32(m);
    read_int32(source);
    read_int32(destination);
    for ( int i = 1; i <= m; ++ i ) {
        int x, y;
        read_int32(x);
        read_int32(y);
        read_int32(f[x][y]);
        read_int32(c[x][y]);
        g[x].push_back(y);
        g[y].push_back(x);
        c[y][x] = -c[x][y];
    }

    for ( int i = 1; i <= n; ++ i ) {
        d[i] = inf;
    }
    d[source] = 0;
    q.push(source);
    while ( q.empty() == 0 ) {
        int x = q.front();
        q.pop();
        for ( int i = 0; i < int(g[x].size()); ++ i ) {
            int xn = g[x][i];
            if ( f[x][xn] > 0 && d[xn] > d[x]+c[x][xn] ) {
                d[xn] = d[x]+c[x][xn];
                q.push(xn);
            }
        }
    }

    int sol = 0;
    while ( d[destination] != inf ) {
        for ( int x = 1; x <= n; ++ x ) {
            for ( int i = 0; i < int(g[i].size()); ++ i ) {
                int xn = g[x][i];
                if ( d[x] != inf && d[xn] != inf ) {
                    c[x][xn] += d[x]-d[xn];
                }
            }
        }
        for ( int i = 1; i <= n; ++ i ) {
            d[i] = inf;
        }
        d[source] = 0;
        h.push(str(source,d[source]));

        while ( h.empty() == 0 ) {
            int x = h.top().x, y = h.top().y;
            h.pop();
            if ( d[x] == y ) {
                for ( int i = 0; i < int(g[x].size()); ++ i ) {
                    int xn = g[x][i];
                    if ( f[x][xn] > 0 && d[xn] > d[x]+c[x][xn] ) {
                        d[xn] = d[x]+c[x][xn];
                        r[xn] = x;
                        h.push(str(xn, d[xn]));
                    }
                }
            }
        }

        if ( d[destination] != inf ) {
            int aux = fmax;
            for ( int i = destination; i != source; i = r[i] ) {
                if ( aux > f[r[i]][i] ) {
                    aux = f[r[i]][i];
                }
            }
            for ( int i = destination; i != source; i = r[i] ) {
                f[r[i]][i] -= aux;
                f[i][r[i]] += aux;
            }
            sol += aux*d[destination];
        }
    }

    fout << sol << "\n";

    return 0;
}
