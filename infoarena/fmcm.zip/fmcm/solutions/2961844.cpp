#include <iostream>
#include <fstream>
#include <vector>
#include <climits>
#include <queue>

using namespace std;

ifstream f("fmcm.in");
ofstream g("fmcm.out");

vector<vector<int> > v(1001);
int cost[1001][1001];
int capacitate[1001][1001], tata[1001], dDjikstra[1001], dBellmanFord[1001], d[1001], viz[1001], fluxMaxim;
int n, m, flux, fluxCost, S, D;
priority_queue<pair<int, int> > q;
queue<int> qBF;

bool djikstra()
{

    for(int i = 0; i <= n; i++)
        d[i] = INT_MAX;
    
    d[S] = 0;
    dDjikstra[S] = 0;

    q.push(make_pair(0, S));

    while(!q.empty())
    {
        int nod = q.top().second;
        int c = -q.top().first;
        q.pop();

        if(d[nod] != c)
            continue;
        
        for(int i = 0; i < v[nod].size(); i++)
        {
            int vecin = v[nod][i];
            int dist = c + cost[nod][vecin];
            dist = dist + dBellmanFord[nod] - dBellmanFord[vecin];
            
            if(dist < d[vecin] && capacitate[nod][vecin] > 0)
            {
                d[vecin] = dist;
                dDjikstra[vecin] = dDjikstra[nod] + cost[nod][vecin];
                tata[vecin] = nod;
                q.push(make_pair(-d[vecin], vecin));
            }
        }
    }

    for(int i = 1; i <= n; i++)
        dBellmanFord[i] = dDjikstra[i];

    if(d[D] == INT_MAX)
        return false;

    int flux = INT_MAX, fluxCost = 0;
    int x = D;
    while(x != S)
    {
        flux = min(flux, capacitate[tata[x]][x]);
        fluxCost += cost[tata[x]][x];
        x = tata[x];
    }

    fluxMaxim += fluxCost * flux;

    x = D;
    while(x != S)
    {
        capacitate[tata[x]][x] -= flux;
        capacitate[x][tata[x]] += flux;
        x = tata[x];
    }

    return true;    
    
}

void bellmanFord()
{
    
    for(int i = 0; i <= n; i++)
        dBellmanFord[i] = INT_MAX;

    qBF.push(S);

    dBellmanFord[S] = 0;

    viz[S] = 1;

    while(!qBF.empty())
    {
        int nod = qBF.front();
        qBF.pop();
        viz[nod] = 0;

        for(int i = 0; i < v[nod].size(); i++)
        {
            int vecin = v[nod][i];
            if(capacitate[nod][vecin] > 0 && dBellmanFord[vecin] > dBellmanFord[nod] + cost[nod][vecin])
            {
                dBellmanFord[vecin] = dBellmanFord[nod] + cost[nod][vecin];
                if(!viz[vecin])
                {
                    qBF.push(vecin);
                    viz[vecin] = 1;
                }
            }
        }
    }


                          

}

int main()
{
    int x, y, c, z;
    f >> n >> m >> S >> D;

    for (int i = 1; i <= m; i++)
    {
        f >> x >> y >> c >> z;
        v[x].push_back(y);
        v[y].push_back(x);
        capacitate[x][y] = c;
        cost[x][y] = z;
        cost[y][x] = -z;
        
    }

    bellmanFord();

    while(djikstra())
    {
        ;
    }

    g << fluxMaxim << '\n';
    




    return 0;
}