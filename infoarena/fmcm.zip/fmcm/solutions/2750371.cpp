#include<bits/stdc++.h>
using namespace std;
#define INIT  ios_base :: sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
#define mp make_pair
#define pb push_back
#define ft first
#define sc second
#define ll long long
#define pii pair<int, int>
#define count_bits __builtin_popcount
//#define int ll

int t, n, m, k, a[300010],s, T;



ifstream fin("fmcm.in"); ofstream fout("fmcm.out");
#define cin fin
#define cout fout



int g[351][351];

int e[12501][4];

int c[351][351];
int r[351][351];




int d[351], f[351];
int par[351];
int F=0, D=0;

bool bellman_ford(){
    for(int i=1; i<=n; i++){
        d[i]=1e9, f[i]=0;
    }
    d[s]=0, f[s]=1e9;


    for(int v=1; v<=n; v++){
        for(int i=1; i<=m; i++){
            if(min(f[e[i][0] ], c[e[i][0] ][e[i][1] ]-r[e[i][0] ][e[i][1] ] )>0  ){
                if(mp(d[e[i][0] ]+g[e[i][0] ][e[i][1] ], -min(f[e[i][0] ], c[e[i][0] ][e[i][1] ]-r[e[i][0] ][e[i][1] ] ) )<mp(d[e[i][1] ], -f[e[i][1] ] )  ){
                    f[e[i][1] ]=min(f[e[i][0] ], c[e[i][0] ][e[i][1] ]-r[e[i][0] ][e[i][1] ] );
                    d[e[i][1] ]=d[e[i][0] ]+g[e[i][0] ][e[i][1] ];
                    par[e[i][1] ]=e[i][0];
                }
            }
            swap(e[i][1], e[i][0]);
            if(min(f[e[i][0] ], c[e[i][0] ][e[i][1] ]-r[e[i][0] ][e[i][1] ] )>0  ){
                if(mp(d[e[i][0] ]+g[e[i][0] ][e[i][1] ], -min(f[e[i][0] ], c[e[i][0] ][e[i][1] ]-r[e[i][0] ][e[i][1] ] ) )<mp(d[e[i][1] ], -f[e[i][1] ] )  ){
                    f[e[i][1] ]=min(f[e[i][0] ], c[e[i][0] ][e[i][1] ]-r[e[i][0] ][e[i][1] ] );
                    d[e[i][1] ]=d[e[i][0] ]+g[e[i][0] ][e[i][1] ];
                    par[e[i][1] ]=e[i][0];
                }
            }
            swap(e[i][1], e[i][0]);


        }
    }

    if(f[T]==0){
        return false;
    }

    int ac=T;
    while( ac!=s){
        r[par[ac] ][ac]+=f[T], r[ac ][par[ac] ]-=f[T];
        ac=par[ac];
    }
    D+=f[T]*d[T], F+=f[T];
    return true;
}


int32_t main(){
INIT
cin>>n>>m>>s>>t;
T=t;
for(int i=1; i<=m; i++){

    cin>>e[i][0]>>e[i][1]>>e[i][2]>>e[i][3];
    c[e[i][0] ][e[i][1] ]=e[i][2];
    g[e[i][0] ][e[i][1] ]=e[i][3];
    g[e[i][1]  ][e[i][0] ]=-e[i][3];
}

while(bellman_ford()){

}
cout<<D;

return 0;
}
