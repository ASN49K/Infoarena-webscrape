#include <bits/stdc++.h>
using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

const int N_MAX = 350 + 1;

int N, M, source, sink, capacity[N_MAX][N_MAX], flow[N_MAX][N_MAX], cost[N_MAX][N_MAX], parent[N_MAX];
vector<vector<int>> graph(N_MAX, vector<int>());

bool inQueue[N_MAX];
int dist[N_MAX], cntInQueue[N_MAX];
struct cmp{ bool operator () (int x, int y){ return dist[x] > dist[y];}};
priority_queue<int, vector<int>, cmp> pq;

bool Dijkstra()
{
    fill(dist + 1, dist + N + 1, 1 << 29);
    fill(cntInQueue + 1, cntInQueue + N + 1, 0);

    dist[source] = 0;
    pq.push(source);

    while(pq.empty() == false)
    {
        int node = pq.top();
        pq.pop();
        inQueue[node] = false;

        cntInQueue[node]++;

        if(cntInQueue[node] > N) return false;

        if(node == sink) continue;

        for(auto& next : graph[node])
        {
            if(capacity[node][next] == flow[node][next]) continue;

            if(dist[next] > dist[node] + cost[node][next])
            {
                dist[next] = dist[node] + cost[node][next];

                parent[next] = node;

                if(inQueue[next] == false)
                {
                    inQueue[next] = true;
                    pq.push(next);
                }
            }
        }
    }

  return (dist[sink] != 1 << 29);
}

int main()
{
    fin >> N >> M >> source >> sink;

    for(int i = 1; i <= M; ++i)
    {
        int x, y, c, z;
        fin >> x >> y >> c >> z;

        graph[x].push_back(y);
        graph[y].push_back(x);

        capacity[x][y] = c;

        cost[x][y] = z;
        cost[y][x] = -z;
    }


    int min_cost = 0;

    while(Dijkstra())
    {
        int augument_flow = 1 << 29;

        for(int node = sink; node != source; node = parent[node])
            augument_flow = min(augument_flow, capacity[parent[node]][node] - flow[parent[node]][node]);

        for(int node = sink; node != source; node = parent[node])
        {
            flow[parent[node]][node] += augument_flow;
            flow[node][parent[node]] -= augument_flow;

            min_cost += augument_flow*cost[parent[node]][node];
        }
    }

    fout << min_cost;
}
