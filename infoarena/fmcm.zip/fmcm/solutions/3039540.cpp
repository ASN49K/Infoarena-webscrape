#include<iostream>
#include<vector>
#include<algorithm>
#include<queue>
#include<bitset>
#include<cstring>
using namespace std;

constexpr int NMAX = 5e2 + 1;
const int INF = 1 << 29;

int flow[NMAX][NMAX],cap[NMAX][NMAX],cost[NMAX][NMAX],t[NMAX];
vector<int> vecini[NMAX],dist;
bitset<NMAX> inq;

bool bf(int s,int e)
{
    fill(dist.begin(),dist.end(),INF); dist[s] = 0; memset(t,0,sizeof(t));
    queue<int> q; q.push(s); inq.reset(); inq[s] = 1;
    while(!q.empty())
        {
            int v = q.front(); q.pop(); inq[v] = 0;
            for(auto it : vecini[v])
                {
                    if((cap[v][it] - flow[v][it]) > 0)
                        {
                            if(dist[it] > dist[v] + cost[v][it])
                                {
                                    dist[it] = dist[v] + cost[v][it]; t[it] = v;
                                    if(!inq[it])
                                        {
                                            inq[it] = 1;
                                            q.push(it);
                                        }
                                }
                        }
                }
        }

    return (dist[e] != INF);
}

int main()
{
    freopen("fmcm.in","r",stdin);
    freopen("fmcm.out","w",stdout);

    int n,m,s,e,a,b,c,d; cin >> n >> m >> s >> e;
    for(int i = 1; i <= m ; i++)
        {
            cin >> a >> b >> c >> d;
            vecini[a].emplace_back(b);
            vecini[b].emplace_back(a);
            cap[a][b] = c; cost[a][b] = d;
            cost[b][a] = -d;
        }

    int ans = 0; dist.resize(n + 1);
    while(bf(s,e))
        {
            int delta = INF;
            for(int v = e; v != s; v = t[v]) delta = min(delta,cap[t[v]][v] - flow[t[v]][v]);
            for(int v = e; v != s; v = t[v]) flow[t[v]][v] += delta;

            ans += delta * dist[e];
        }

    cout << ans;
}
