#include<iostream>
#include<vector>
#include<algorithm>
#include<queue>
#include<bitset>
#include<cstring>
using namespace std;


constexpr int NMAX = 366;
const int INF = 1e9;

struct muchie
{
    int from,to,cap,cost,flow;
};

vector<int> vecini[NMAX]; vector<muchie> muchii;
int dist[NMAX],real[NMAX],pi[NMAX],t[NMAX];
bitset<NMAX> inq;

void bf(int s,int e)
{
    memset(pi,0x3f3f3f,sizeof(pi));
    queue<int> q; q.push(s); inq[s] = 1;
    while(!q.empty())
        {

            int v = q.front(); q.pop(); inq[v] = 0;
            for(auto it : vecini[v])
                {
                    if((muchii[it].cap - muchii[it].flow) <= 0) continue;
                    if(pi[muchii[it].to] > pi[v] + muchii[it].cost)
                        {
                            pi[muchii[it].to] = pi[v] + muchii[it].cost;
                            if(!inq[muchii[it].to])
                                {
                                    inq[muchii[it].to] = 1;
                                    q.push(muchii[it].to);
                                }
                        }

                }
        }
}

struct miau
{
    int w; bool operator <(const miau &lhs) const
    {
        return dist[lhs.w] > dist[w];
    }
};

bool dijkstra(int s,int e)
{
    memset(dist,0x3f3f3f,sizeof(dist)); dist[s] = 0; memset(t,-1,sizeof(t));
    priority_queue<miau> pq; pq.push({s}); real[s] = 0;
    while(!pq.empty())
        {
            int v = pq.top().w; pq.pop();
            for(auto it : vecini[v])
                {

                    muchie &h = muchii[it];
                    if((h.cap - h.flow) > 0)
                        {
                            int false_cost = dist[v] + h.cost + pi[v] - pi[h.to];
                            if(false_cost < 0) exit(1);
                            if(false_cost < dist[h.to])
                                {
                                    real[h.to] = real[v] + h.cost;
                                    dist[h.to] = false_cost;
                                    pq.push({h.to}); t[h.to] = it;
                                }
                        }
                }
        }

    return (t[e] != -1);
}

int main()
{
    freopen("fmcm.in","r",stdin);
    freopen("fmcm.out","w",stdout);

    int n,m,s,e,a,b,c,d; cin >> n >> m >> s >> e;
    for(int i = 0; i < m ; i++)
        {
            cin >> a >> b >> c >> d;
            muchii.push_back({a,b,c,d,0}); vecini[a].emplace_back(2 * i);
            muchii.push_back({b,a,0,-d,0}); vecini[b].emplace_back(2 * i + 1);
        }

    long long ans = 0,flux = 0; bf(s,e);
    while(dijkstra(s,e))
        {
            int delta = INF;
            for(int v = t[e]; v != -1 ; v = t[muchii[v].from]) delta = min(delta,muchii[v].cap - muchii[v].flow);
            for(int v = t[e]; v != -1 ; v = t[muchii[v].from]) muchii[v].flow += delta,muchii[v ^ 1].flow -= delta;
            ans += 1LL * delta * real[e];
            for(int i = 1; i <= n ; i++) pi[i] = real[i];
        }


    cout << ans;
}
