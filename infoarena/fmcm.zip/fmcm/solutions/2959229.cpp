#include <iostream>
#include <fstream>
#include <climits>
#include <vector>
#include <queue>

using namespace std;
ifstream fin("fmcm.in");
ofstream fout("fmcm.out");
int n, m, source, destination, max_flow;
vector<int>adjacency_list[351];
vector<int>parent, visited, distances;
int capacity[351][351], cost[351][351];
queue<int>q;

int bellman_ford(){
    visited.assign(n+1, 0);
    parent.assign(n+1, 0);
    distances.assign(n+1, INT_MAX);

    while(!q.empty())
        q.pop();
    q.push(source);
    visited[source] = 1;
    parent[source] = source;

    distances[source] = 0;

    while(!q.empty()){
        int node = q.front();
        q.pop();
        visited[node] = 0; //il marchez ca nevizitat, deoarece l am scos din coada de parcurgere
        for(auto neighbour: adjacency_list[node]){
            if(capacity[node][neighbour] > 0 && distances[neighbour] > distances[node] + cost[node][neighbour]){ //conditie flux + conditie bellman ford
                distances[neighbour] = distances[node] + cost[node][neighbour];
                parent[neighbour] = node;
                if(!visited[neighbour]){
                    q.push(neighbour);
                    visited[neighbour] = 1;
                }
            }
        }
    }
    //cout<<distances[destination];
    return distances[destination];
}

int main() {
    fin>>n>>m>>source>>destination;
    int a, b, c, d;
    for(int i=0; i<m; i++){
        fin>>a>>b>>c>>d;
        adjacency_list[a].push_back(b);
        adjacency_list[b].push_back(a);
        capacity[a][b] = c;
        cost[a][b] = d;
        cost[b][a] = -d;
    }
    while(true){
        int total_cost = bellman_ford();
        if(total_cost == INT_MAX) break;
        int flow = INT_MAX;
        for(int node = n; node != source; node = parent[node]) {
            flow = min(flow, capacity[parent[node]][node]);
        }
        for(int node = n; node != source; node = parent[node]) {
            capacity[parent[node]][node] -= flow;
            capacity[node][parent[node]] += flow;
        }
        //cout<<"  IN MAIN: "<<total_cost<<" "<<flow<<endl;
        max_flow += flow * total_cost;
    }
    fout<<max_flow;
    return 0;
}
