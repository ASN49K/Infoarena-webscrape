#include <fstream>
#include <queue>
#include <vector>
#pragma GCC optimize("unroll-loops")
#pragma gcc optimize("Ofast")
using namespace std;
ifstream f("fmcm.in");
ofstream g("fmcm.out");

int n,m,st,dr,sol;
int X,Y,Z,T;
const int N=355;
int flx[N][N];
int d[N][N],dist[N],viz[N],dad[N];
vector<int>a[N];
int drum (int st, int dr)
{
    for(int i=1;i<=n;i++)
    {
        viz[i]=0;
        dist[i]=1e9;
    }
    queue<int>q;
    q.push(st);
    viz[st]=true;
    dist[st]=0;
    dad[st]=st;
    while(!q.empty())
    {
        int nod =q.front();
        q.pop();
        viz[nod]=false;
        for(auto x: a[nod])
        {
            if(flx[nod][x]> 0 && dist[x]>dist[nod]+d[nod][x])
            {
                dist[x]=dist[nod]+d[nod][x];
                dad[x]=nod;
                if(viz[x]==false)
                {
                    viz[x]=true;
                    q.push(x);
                }
            }
        }
    }
    return dist[dr];
}
signed main()
{
    f>>n>>m>>st>>dr;
    for(int i=1;i<=m;i++)
    {
        f>>X>>Y>>Z>>T;
        flx[X][Y]=Z;
        d[X][Y]=T;
        d[Y][X]=-T;
        a[X].push_back(Y);
        a[Y].push_back(X);
    }
    while(true)
    {
        int sum=drum(st,dr);
        if(sum==1e9)
            break;
        int mn=1e9;
        for(int i=dr;i!=st;i=dad[i])
            mn=min(mn,flx[dad[i]][i]);
        for(int i=dr;i!=st;i=dad[i])
        {
            flx[dad[i]][i]-=mn;
            flx[i][dad[i]]+=mn;
        }
        sol=sol+mn*sum;
    }
    g<<sol;
}
