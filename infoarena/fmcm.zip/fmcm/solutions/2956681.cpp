#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream f ("fmcm.in");
ofstream g ("fmcm.out");

vector <int> l[355];
int n, dst, c[355][355], fl[355][355], cost[355][355], t[355], d[355];

int bellman_ford(int vf)
{
    int i;
    for (i = 1; i <= n; i++)
        d[i] = 999999;
    queue <int> q;
    q.push(vf);
    d[vf] = 0;
    t[vf] = 0;
    while (!q.empty())
    {
        vf = q.front();
        q.pop();
        for (i = 0; i < l[vf].size(); i++)
            if (fl[vf][l[vf][i]] < c[vf][l[vf][i]] && d[vf] + cost[vf][l[vf][i]] < d[l[vf][i]])
                {
                    q.push(l[vf][i]);
                    d[l[vf][i]] = d[vf] + cost[vf][l[vf][i]];
                    t[l[vf][i]] = vf;
                }
    }
    if (d[dst] < 999999) return 1;
    return 0;
}

int main()
{int m, s, flux = 0, i, x, y, capac, cst, mn;
f >> n >> m >> s >> dst;
for (i = 0; i < m; i++)
{
    f >> x >> y >> capac >> cst;
    l[x].push_back(y);
    l[y].push_back(x);
    c[x][y] = capac;
    cost[x][y] = cst;
    cost[y][x] = -cst;
}
while (bellman_ford(s))
{
    i = dst;
    mn = 999999;
    while (i != s)
    {
        if (c[t[i]][i] - fl[t[i]][i] < mn)
            mn = c[t[i]][i] - fl[t[i]][i];
        i = t[i];
    }
    flux += mn * d[dst];
    i = dst;
    while (i != s)
    {
        fl[t[i]][i] += mn;
        fl[i][t[i]] -= mn;
        i = t[i];

    }
    for (i = 1; i <= n; i++)
    {
        d[i] = 999999;
        t[i] = 0;
    }
}
g << flux;
return 0;
}
