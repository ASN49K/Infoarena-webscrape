#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <algorithm>

std::ifstream in("fmcm.in");
std::ofstream out("fmcm.out");

constexpr int nmax = 351;
const long long inf = 1e17;
int n,M,s,t;

struct edge
{
    int u, v;
    long long ca, f = 0, c;

    edge(int u, int v, int ca, int c):u(u), v(v), ca(ca), c(c){}
};

std::vector<edge> e;
std::vector<int> adj[nmax];
long long p[nmax], d[nmax], pe[nmax];

int m = 0;
void add(int u, int v, int ca, int c)
{
    e.emplace_back(u, v, ca, c);
    e.emplace_back(v, u, 0, -c);
    adj[u].emplace_back(m);
    adj[v].emplace_back(m+1);
    m+=2;
}

int cg[nmax];
bool bfs()
{
    for ( int i = 1; i <= n; ++i )
        p[i] = -1, d[i] = inf, cg[i] = 0, pe[i] = -1;
    p[s] = 0;
    d[s] = 0;

    for ( ;; )
    {
        bool gasit = false;
        for ( int id = 0; id < e.size(); ++id )
        {
            int u = e[id].u, v = e[id].v;
            if ( e[id].ca - e[id].f < 1 )
                continue;
            if (  d[u] < inf )
                if ( d[u] + e[id].c < d[v])
                {
                    gasit = true;
                    if ( u != v)
                    p[v] = u;
                    pe[v] = id;
                    d[v] = d[u] + e[id].c;
                }
        }
        if ( !gasit )
            break;
    }
    int u = t;
    while ( u != s)
    {

        if (p[u] == -1)
            return 0;
        u = p[u];
    }

    return p[t] != -1;
}

long long flo()
{
    long long cmin = 0;

    while ( bfs() )
    {
        int u = t;
        long long nf = inf, cc = 0;
        while ( u != s)
        {

            int id = pe[u];
            nf = std::min(nf, e[id].ca - e[id].f);
            cc += e[id].c;
            u = p[u];
        }
        u = t;
        while ( u != s )
        {
            int id = pe[u];
            e[id].f += nf;
            e[id ^ 1].f -= nf;
            u = p[u];
        }
        cmin += nf * cc;
    }
    return cmin;
}


int main()
{
    std::ios_base::sync_with_stdio(false);
    in.tie(0);

    in >> n >> M >> s >> t;

    for ( int i = 1; i <= M; ++i )
    {
        int u, v, ca, cc;
        in >> u >> v >> ca >> cc;
        add(u, v, ca, cc);
    }


    out << flo();
    return 0;
}
