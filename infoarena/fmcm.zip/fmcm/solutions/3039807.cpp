#include<algorithm>
#include<fstream>
#include<queue>

#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
ifstream fin("fmcm.in");
ofstream fout("fmcm.out");
int const N = 1001 , inf = 1e9;
int n , m , s , d , a , b , l , r;
int t[N] , dp[N] , dp2[N] , inq[N] , dst[N] , viz[N];
int f[N][N] , w[N][N] , q[N * N];
vector<int> v[N];
void bellman(){
    inq[s] = 1;
    fill(dst + 1 , dst + 1 + n , inf);
    q[l = r = 1] = s , dst[s] = 0;
    while(l <= r){
        int x = q[l++];
        inq[x] = 0;
        for(int i : v[x]){
            if(f[x][i] > 0 && dst[i] > dst[x] + w[x][i]){
                dst[i] = dst[x] + w[x][i];
                if(!inq[i]){
                    inq[i] = 1;
                    q[++r] = i;
                }
            }
        }
    }
}
bool dijkstra(){
    fill(dp + 1 , dp + 1 + n , inf);
    fill(dp2 + 1 , dp2 + 1 + n , inf);
    fill(t + 1 , t + 1 + n , 0);
    dp[s] = dp2[s] = 0;
    priority_queue<pii> h;
    h.emplace(0 , s);
    while(!h.empty()){
        int x = h.top().se;
        int e = -h.top().fi;
        h.pop();
        if(e != dp[x])
            continue;
        for(int i : v[x]){
            if(f[x][i] > 0 && e + w[x][i] - dst[x] + dst[i] < dp[i]){
                dp[i] = e + w[x][i] - dst[x] + dst[i];
                dp2[i] = dp2[x] + w[x][i];
                t[i] = x;
                h.emplace(-dp[i] , i);
            }
        }
    }
    copy(dp2 + 1 , dp2 + 1 + n , dst + 1);
    return (dp[d] != inf);
}
int fmcm(){
    int cost(0) , flow(0);
    while(dijkstra()){
        int x = d , fl = inf;
        while(t[x]){
            fl = min(fl , f[t[x]][x]);
            x = t[x];
        }
        if(!fl){
            continue;
        }
        x = d , flow += fl;
        while(t[x]){
            f[t[x]][x] -= fl;
            f[x][t[x]] += fl;
            cost += fl * w[t[x]][x];
            x = t[x];
        }
    }
    return cost;
}
int main(){
    fin >> n >> m >> s >> d;
    for(int i = 1 ; i <= m ; ++ i){
        fin >> a >> b >> f[a][b] >> w[a][b];
        v[a].push_back(b);
        v[b].push_back(a);
        w[b][a] = -w[a][b];
    }
    bellman();
    fout << fmcm() << '\n';
    return 0;
}
