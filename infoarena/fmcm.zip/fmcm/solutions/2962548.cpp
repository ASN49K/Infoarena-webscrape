#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

int n, m, sursa, dest, cost_min_flux_max = 0;
vector<int> la[2001];
int cost[2001][2001], capacitate[2001][2001];

int tata[2001]; 
int coada[2001]; 
int dist_bf[2001]; 
int dist_d[2001]; 
int dist[2001];
queue<int> q;

priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;

void BellmanFord()
{
    memset(dist_bf, INT_MAX, sizeof(dist_bf));

    dist_bf[sursa] = 0;
    q.push(sursa);
    coada[sursa] = 1;

    while (!q.empty())
    {
        int curent = q.front();
        coada[curent] = 0;
        q.pop();
        for (auto it : la[curent])
        {
            if (capacitate[curent][it] > 0)
            {
                if (dist_bf[curent] + cost[curent][it] < dist_bf[it])
                {
                    //actualizez distanta
                    dist_bf[it] = dist_bf[curent] + cost[curent][it];
                    if (!coada[it])
                    {
                        coada[it] = 1;
                        q.push(it);
                    }
                }
            }
        }
    }
}

int dijkstra()
{
    memset(dist, INT_MAX, sizeof(dist));

    dist[sursa] = 0;
    dist_d[sursa] = 0;

    pq.push(make_pair(dist[sursa], sursa));

    while (!pq.empty())
    {
        int c = pq.top().first;
        int x = pq.top().second;
        pq.pop();

        if (dist[x] == c)
        {
            for (auto it : la[x])
            {
                if (capacitate[x][it] > 0)
                {
                    if (dist[x] + cost[x][it] + dist_bf[x] - dist_bf[it] < dist[it])
                    {
                        dist[it] = dist[x] + cost[x][it] + dist_bf[x] - dist_bf[it];
                        dist_d[it] = dist_d[x] + cost[x][it];
                        tata[it] = x;
                        pq.push(make_pair(dist[it], it));
                    }
                }

            }
        }
    }
    memcpy(dist_bf, dist_d, sizeof(dist));
    if (dist[dest] == INT_MAX)
        return 0;

    int minim = INT_MAX;
    for (int i = dest; i != sursa; i = tata[i])
    {
        int j = tata[i];
        minim = min(minim, capacitate[j][i]);
    }
    for (int i = dest; i != sursa; i = tata[i])
    {
        int j = tata[i];
        capacitate[i][j] += minim;
        capacitate[j][i] -= minim;
    }
    cost_min_flux_max += minim * dist_d[dest];

    return 1;
}

int main()
{
    int x, y, c, z;
    fin >> n >> m >> sursa >> dest;
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y >> c >> z;
        la[x].push_back(y);
        la[y].push_back(x);

        capacitate[x][y] = z;
        cost[x][y] = c;
        cost[y][x] = -c;
    }
    fin.close();
    BellmanFord();
    while (dijkstra());

    fout << cost_min_flux_max;
    fout.close();
    return 0;
}