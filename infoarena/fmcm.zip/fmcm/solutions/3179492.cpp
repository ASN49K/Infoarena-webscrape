#include <bits/stdc++.h>
using namespace std;


const int NMAX = 357;


int n, m, s, d;
vector<int> adj[NMAX];
int flow[NMAX][NMAX];
int cost[NMAX][NMAX];
int par[NMAX];
int dist[NMAX];

long long bellman_ford() {

  static bool inq[NMAX];
  fill(dist + 1, dist + n + 1, INT_MAX);
  fill(inq + 1, inq + n + 1, false);
  fill(par + 1, par + n + 1, -1);

  queue<int> q;

  q.push(s), inq[s] = true;
  dist[s] = 0;

  while (!q.empty()) {
    int u = q.front();
    q.pop(), inq[u] = false;
    for (int v : adj[u]) {
      if (dist[u] + cost[u][v] < dist[v] && flow[u][v] > 0) {
        dist[v] = dist[u] + cost[u][v];
        par[v] = u;
        if (v != d && !inq[v]) q.push(v), inq[v] = true;
      }
    }
  }

  if (par[d] == -1) return 0;

  int fmin = INT_MAX;

  for (int u = n; u != s; u = par[u]) {
    fmin = min(fmin, flow[par[u]][u]);
  }

  for (int u = n; u != s; u = par[u]) {
    flow[par[u]][u] -= fmin;
    flow[u][par[u]] += fmin;
  }

  return dist[d] * fmin;

}


void solve() {

  cin >> n >> m >> s >> d;

  for (int i = 0; i < m; i++) {
    int u, v, f, c;
    cin >> u >> v >> f >> c;
    adj[u].push_back(v);
    adj[v].push_back(u);
    flow[u][v] = f;
    cost[u][v] = c;
    cost[v][u] = -c;
  }

  
  long long res = 0, p = 0;
  while (p = bellman_ford()) res += p;
  cout << res;

}


int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("fmcm.in", "r", stdin);
  freopen("fmcm.out", "w", stdout);
  #endif

  ios_base::sync_with_stdio(false), cin.tie(NULL);

  solve();
}