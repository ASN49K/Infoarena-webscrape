#include<bits/stdc++.h>
using namespace std;
#define INIT  ios_base :: sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
#define mp make_pair
#define pb push_back
#define ft first
#define sc second
#define ll long long
#define pii pair<int, int>
#define count_bits __builtin_popcount




ifstream fin("fmcm.in"); ofstream fout("fmcm.out");
#define cout fout
#define cin fin



int n, m, S, T;



int e[12501][4]; // muchiile
int r[351][351]; // graf rezidual
int c[351][351];// capacitatile
int D[351]; // distanta catre u, dupa primul bellman ford

vector<pair<int, pii>> g[351];


void bellman_ford(){
    for(int i=1; i<=n; i++){
        D[i]=1e9;
    }
        D[S]=0;
    for(int V=2; V<=(n); V++){
        for(int i=1; i<=m; i++){
            D[e[i][1] ]=min(D[e[i][1] ], D[e[i][0] ]+e[i][3]);
        }
    }
}

vector<pair<int, int>> g2[351];

void build_g2(){

for(int i=1; i<=m; i++){
    g2[e[i][0] ].pb( {e[i][1], D[e[i][0] ]-D[e[i][1] ]+e[i][3] } );
    g2[e[i][1] ].pb( {e[i][0], -(D[e[i][0] ]-D[e[i][1] ]+e[i][3]) } );
    c[e[i][0] ][e[i][1] ]=e[i][2];
}

}



int F=0, minD=0;

int f[351], d[351];
bool v[351];
int par[351];

pii dijkstra(){

for(int i=1; i<=n; i++){
    f[i]=0;
    d[i]=1e9;
    par[i]=0;
    v[i]=false;
}


multiset<pair<pii, int>> ms;
ms.insert({{0, -1e9}, S});
d[S]=0;
f[S]=1e9;
while(!ms.empty()){
    auto it=ms.begin();
    auto pr=*it; ms.erase(it);

    int nod=pr.sc; auto state=pr.ft;
    v[nod]=true;
    if(nod==T){
        break;
    }
    //cout<<nod<<"\n"<<flush;

    for(auto pr:g2[nod]){
        auto u=pr.ft, z=pr.sc;
        if(v[u]){
            continue;
        }
        auto it=ms.find({{d[u], -f[u]}, u} );
        //cout<<ms.size()<<"\n"<<flush;
        if(it==ms.end()){
                if( min(c[nod][u]-r[nod][u], f[nod] )<=0 ){
                    continue;
                }
            d[u]=d[nod]+(z), f[u]=min(c[nod][u]-r[nod][u], f[nod] );
            //r[nod][u]+=f[u], r[u][nod]-=f[u];
            par[u]=nod;
            ms.insert({{d[u], -f[u]}, u});
        }
        else{
            if( (mp( ( (z)+d[nod] ), -min(c[nod][u]-r[nod][u], f[nod])  )<it->ft) && (min(c[nod][u]-r[nod][u], f[nod])>0 )  ){
                d[u]=d[nod]+(z), f[u]=min(c[nod][u]-r[nod][u], f[nod] );
                //r[nod][u]+=f[u], r[u][nod]-=f[u];
                par[u]=nod;
                ms.erase(it);
                ms.insert({{d[u], -f[u]}, u});
            }
        }

    }
    //cout<<ms.size()<<"\n"<<flush;
}


if(f[T]==0){
    return {0, 0};
}
int ac=T;
while(ac!=S){
    r[par[ac] ][ac]+=f[T], r[ac][par[ac] ]-=f[T];
    ac=par[ac];
}

//cout<<f[T]<<" "<<d[T]+D[T]<<"\n"<<flush;
if(f[T]>0){minD+=(d[T]+D[T])*f[T];} if(f[T]>0){F+=f[T];}
return {f[T], (d[T]+D[T])*f[T]};
}


int32_t main(){
INIT

cin>>n>>m>>S>>T;
for(int i=1; i<=m; i++){
        cin>>e[i][0]>>e[i][1]>>e[i][2]>>e[i][3];
        g[e[i][0] ].pb({e[i][1], {e[i][2], e[i][3]} });
}
bellman_ford();
build_g2();
//cout<<D[T]<<"\n";
while(dijkstra().ft>0){
}
cout<<minD<<"\n";
//cout<<F;
return 0;
}
