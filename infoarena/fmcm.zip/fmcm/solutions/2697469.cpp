#include <stdio.h>
#include <vector>
using namespace std;
/*ifstream fin("fmcm.in");
ofstream fout("fmcm.out");*/
typedef long long ll;
const int inf=2000000000;
int N,M,S,D,C[501][501],Cost[501][501],G[501],drum,Dist[501],From[501],L,F[501][501];
int Q[1000010],U[501];
vector<int> A[501];
bool Drum;
int i,j,x,y,z,cap;
int BellmanFord()
{
    for(i=1;i<=N;i++)
    {
        Dist[i]=inf;
        From[i]=-1;
        U[i]=0;
    }
    Dist[S]=0;
    L=1;
    Q[L]=S;
    U[S]=1;
    for(i=1;i<=L;i++)
    {
        for(j=0;j<G[Q[i]];j++)
            if(C[Q[i]][A[Q[i]][j]]-F[Q[i]][A[Q[i]][j]]>0 && Dist[Q[i]]+Cost[Q[i]][A[Q[i]][j]]<Dist[A[Q[i]][j]])
            {
                Dist[A[Q[i]][j]]=Dist[Q[i]]+Cost[Q[i]][A[Q[i]][j]];
                From[A[Q[i]][j]]=Q[i];
                if(!U[A[Q[i]][j]])
                {
                    Q[++L]=A[Q[i]][j];
                    U[Q[L]]=1;
                }
            }
        U[Q[i]]=0;
    }

    if(Dist[D]!=inf)
    {
        int Vmin=inf;
        Drum=1;
        for(int i=D;i!=S;i=From[i])
            Vmin=min(Vmin,C[From[i]][i]-F[From[i]][i]);
        for(int i=D;i!=S;i=From[i])
        {
            F[From[i]][i]+=Vmin;
            F[i][From[i]]-=Vmin;
        }
        return Vmin*Dist[D];
    }
    return 0;
}
ll Flux()
{
    ll rez=0;
    Drum=1;
    while(Drum)
    {
        Drum=0;
        rez+=BellmanFord();
    }
    return rez;
}
int main()
{
    freopen("fmcm.in", "r", stdin);
	freopen("fmcm.out", "w", stdout);
    scanf("%d %d %d %d ",&N,&M,&S,&D);
    for(i=1;i<=M;i++)
    {
        scanf("%d %d %d %d ", &x, &y, &cap, &z);
        A[x].push_back(y);
        A[y].push_back(x);
        C[x][y]=cap;
        Cost[x][y]=z;
        Cost[y][x]=-z;
    }
    for(i=1;i<=N;i++)
        G[i]=A[i].size();
    printf("%lld",Flux());
    return 0;
}
