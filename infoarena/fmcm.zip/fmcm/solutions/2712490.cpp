#include <bits/stdc++.h>

using namespace std;

ifstream f("fmcm.in");
ofstream g("fmcm.out");

int n,S,D,ans,tata[510],inCoada[510],cost_bellman[510],cost_dijkstra[510],new_cost_bellman[510],flux[510][510],cost[510][510],C[510][510];
queue <int> q;
priority_queue < pair < int , int > , vector < pair < int , int > > , greater < pair < int , int > > > h;
vector <int> v[510];

void Bellman()
{
    for(int i=1;i<=n;i++)cost_bellman[i]=INT_MAX/2;
    cost_bellman[S]=0;
    inCoada[S]=1;
    q.push(S);

    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        inCoada[nod]=0;

        for(int i=0;i<v[nod].size();i++)
        {
            int vecin=v[nod][i];
            if(cost_bellman[vecin]>cost_bellman[nod]+cost[nod][vecin] && C[nod][vecin]>0)
            {
                cost_bellman[vecin]=cost_bellman[nod]+cost[nod][vecin];
                if(inCoada[vecin]==0)inCoada[vecin]=1,q.push(vecin);
            }
        }
    }
}

int Dijkstra()
{
    for(int i=1;i<=n;i++)cost_dijkstra[i]=INT_MAX/2,new_cost_bellman[i]=INT_MAX/2,tata[i]=0;
    cost_dijkstra[S]=0;
    h.push({0,S});
    new_cost_bellman[S]=0;

    while(!h.empty())
    {
        int min_cost=h.top().first;
        int nod=h.top().second;
        h.pop();

        if(min_cost>cost_dijkstra[nod])continue;

        for(int i=0;i<v[nod].size();i++)
        {
            int vecin=v[nod][i];
            int cost_intre=cost[nod][vecin]+cost_bellman[nod]-cost_bellman[vecin];
            if(flux[nod][vecin]<C[nod][vecin] && cost_dijkstra[vecin]>cost_dijkstra[nod]+cost_intre)
            {
                cost_dijkstra[vecin]=cost_dijkstra[nod]+cost_intre;
                new_cost_bellman[vecin]=new_cost_bellman[nod]+cost[nod][vecin];
                tata[vecin]=nod;

                h.push({cost_dijkstra[vecin],vecin});
            }
        }
    }

    if(cost_dijkstra[D]==INT_MAX/2)return 0;

    int min_flow=C[tata[D]][D]-flux[tata[D]][D];
    int nod=tata[D];
    while(tata[nod]!=0)
    {
        min_flow=min(min_flow,C[tata[nod]][nod]-flux[tata[nod]][nod]);
        nod=tata[nod];
    }

    ans+=min_flow*new_cost_bellman[D];

    nod=D;
    while(tata[nod]!=0)
    {
        flux[tata[nod]][nod]+=min_flow;
        flux[nod][tata[nod]]-=min_flow;
        nod=tata[nod];
    }

    for(int i=1;i<=n;i++)cost_bellman[i]=new_cost_bellman[i];

    return 1;
}

int m,x,y,i,c,z;
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    f>>n>>m>>S>>D;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>c>>z;
        v[x].push_back(y);
        v[y].push_back(x);
        C[x][y]=c;C[y][x]=0;
        cost[x][y]=z;cost[y][x]=-z;
    }

    Bellman();
    while(Dijkstra());

    g<<ans;
    return 0;
}
