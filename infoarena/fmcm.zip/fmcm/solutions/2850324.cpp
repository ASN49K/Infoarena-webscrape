#include <bits/stdc++.h>

using namespace std;
ifstream f("fmcm.in");
ofstream g("fmcm.out");
int tata[500],distrel[500],distanta[500],n,sel[500],flux[500][500],costDij[500][500];
vector <int> v[500];
int distb[500][500],cap[500][500],cost[500][500],distB[500],dist;
priority_queue <pair <int,int>, vector <pair <int,int>>,greater <pair <int,int>> > h;
bool ok(int sursa,int destinatie)
{
    int i;
    for (i=1; i<=n; i++)
    {
        tata[i]=-1;
        distanta[i]=1e9;
    }
    tata[sursa]=0;
    distrel[sursa]=distanta[sursa]=0;
    h.push({distanta[sursa],sursa});
    while (!h.empty())
    {
        while (!h.empty()&&distanta[h.top().second]!=h.top().first)
        {
            h.pop();
        }
        if (h.empty())
        {
            break;
        }
        int acum = h.top().second;
        h.pop();
        for (int i=0; i<v[acum].size(); i++)
        {
            int nod = v[acum][i];
            if (cap[acum][nod]-flux[acum][nod]<=0)
            {
                continue;
            }
            int distance = distanta[acum]+cost[acum][nod]+distB[acum]-distB[nod];
            if (distanta[nod]>distance)
            {
                tata[nod]=acum;
                distanta[nod]=distance;
                distrel[nod]=distrel[acum]+cost[acum][nod];
                h.push({distanta[nod],nod});
            }
        }
    }
    for (i=1;i<=n;i++)
    {
        distB[i]=distanta[i];
    }
    if (distanta[destinatie]==1e9)
    {
        return 0;
    }
    return 1;
}
int m,sursa,destinatie,i,x,y,c,z,viz[500],nod;
int main()
{
    f>>n>>m>>sursa>>destinatie;
    for (i=1; i<=m; i++)
    {
        f>>x>>y>>c>>z;
        v[x].push_back(y);
        v[y].push_back(x);
        cost[x][y]=z;
        cap[x][y]=c;
    }
    for (i=1; i<=n; i++)
    {
        distB[i]=1e9;
    }
    distB[sursa]=0;
    queue <int> q;
    q.push(sursa);
    while (!q.empty())
    {
        int acum = q.front();
        viz[acum]=0;
        q.pop();
        for (int i=0; i<v[acum].size(); i++)
        {
            int nod = v[acum][i];
            if (flux[acum][nod]<cap[acum][nod])
            {
                if (distB[nod]>distB[acum]+cost[acum][nod])
                {
                    distB[nod]=distB[acum]+cost[acum][nod];
                    if (viz[nod]==0)
                    {
                        viz[nod]=1;
                        q.push(nod);
                    }
                }
            }
        }
    }
    long long costfinal=0;
    while (ok(sursa,destinatie))
    {
        nod=destinatie;
        int sal = cap[tata[destinatie]][destinatie]-flux[tata[destinatie]][destinatie];
        while (nod!=sursa)
        {
            sal = min (cap[tata[nod]][nod]-flux[tata[nod]][nod],sal);
            nod=tata[nod];
        }
        costfinal += sal*distrel[destinatie];
        nod=destinatie;
        while (nod!=sursa)
        {
            flux[tata[nod]][nod]+=sal;
            flux[nod][tata[nod]]-=sal;
            nod=tata[nod];
        }
    }
    g<<costfinal;
    return 0;
}
