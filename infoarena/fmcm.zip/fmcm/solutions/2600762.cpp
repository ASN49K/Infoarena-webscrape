#include<bits/stdc++.h>
#define cost it.second
#define dest it.first
#define Nmax 351
#define INF 0x3f3f3f3f

using namespace std;
ifstream f("fmcm.in");
ofstream g("fmcm.out");
//------------------------------------------------------------------------
///Globale
int n,s,d,raspuns;
int v[Nmax];
short int par[Nmax],cap[Nmax][Nmax],flux[Nmax][Nmax];
bool ap[Nmax];
vector<pair<short int,short int>>muchii[Nmax];
queue<short int>q;
//------------------------------------------------------------------------
///Functii
void citire();
void rezolvare();
void afisare();
//------------------------------------------------------------------------
int main()
{
	citire();
	rezolvare();
	afisare();
	return 0;
}
//------------------------------------------------------------------------
void afisare()
{
    g << raspuns;
}
//------------------------------------------------------------------------
bool bellman()
{
	memset(ap,0,sizeof(ap));
	memset(v,INF,sizeof(v));
	v[s] = 0;
	q.push(s);
	while(!q.empty())
	{
		int nod = q.front();
		q.pop();
		ap[nod] = 0;
		for(auto it : muchii[nod])
		{
			if(v[dest] > v[nod] + cost && cap[nod][dest] > flux[nod][dest])
			{
				v[dest] = v[nod] + cost;
				par[dest] = nod;
				if(!ap[dest] && dest != d)
				{
					ap[dest] = 1;
					q.push(dest);
				}
			}
		}
	}
	if(v[d] != INF)
		return 1;
	return 0;
}
//------------------------------------------------------------------------
void rezolvare()
{
    while(bellman())
	{
		int flow = INF;
		for(int nod = d; nod != s; nod = par[nod])
			flow = min(flow,cap[par[nod]][nod] - flux[par[nod]][nod]);
		for(int nod = d; nod != s; nod = par[nod])
		{
			flux[par[nod]][nod] += flow;
			flux[nod][par[nod]] -= flow;
		}
		raspuns += flow * v[d];
	}
}
//------------------------------------------------------------------------
void citire()
{
    int m;
	f >> n >> m >> s >> d;
	while(m--)
	{
		int x,y,c,z;
		f >> x >> y >> c >> z;
		muchii[x].push_back({y,z});
		muchii[y].push_back({x,-z});
		cap[x][y] = c;
	}
}
