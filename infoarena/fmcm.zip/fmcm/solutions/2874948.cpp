#include <bits/stdc++.h>

using namespace std;

ifstream fin ("fmcm.in");
ofstream fout ("fmcm.out");

const int maxN = 360;
const int INF = 1e9;

int parent[maxN], dist[maxN], old[maxN], distNew[maxN];
int a[maxN][maxN], cost[maxN][maxN];

vector <int> g[maxN];

int dijkstra (int source, int sink, int n) {
    for(int i = 1; i <= n; ++i) {
        parent[i] = 0;
        dist[i] = INF;
    }

    set <pair<int,int>> s;
    s.insert({0, source});

    dist[source] = 0;
    parent[source] = -1;

    while(s.size() > 0) {
        pair <int,int> x = *(s.begin());
        s.erase(s.begin());

        int distNode = x.first;
        int node = x.second;

        if(dist[node] < distNode)
            continue;

        for(int to : g[node])
            if(a[node][to]) {
                int newDistance = distNode + cost[node][to] + (old[node] - old[to]);
                if(dist[to] > newDistance) {
                    dist[to] = newDistance;
                    distNew[to] = distNew[node] + cost[node][to];

                    parent[to] = node;
                    s.insert({newDistance, to});
                }
            }
    }

    for(int i = 1; i <= n; ++i)
        old[i] = distNew[i];

    return parent[sink];
}

int maxFlowMinCost (int source, int sink, int n) {
    int flow = 0;
    int flowCost = 0;

    while(dijkstra(source, sink, n)) {
        int newFlow = INF;

        int to = sink;
        while(to != source) {
            int node = parent[to];

            newFlow = min(newFlow, a[node][to]);

            to = node;
        }

        to = sink;
        while(to != source) {
            int node = parent[to];

            a[node][to] -= newFlow;
            a[to][node] += newFlow;

            to = node;
        }

        flow += newFlow;
        flowCost += newFlow * old[sink];
    }

    return flowCost;
}

int main() {

    int n, m, source, sink;
    fin >> n >> m >> source >> sink;

    for(int i = 1; i <= m; ++i) {
        int u, v, cap, cst;
        fin >> u >> v >> cap >> cst;

        a[u][v] += cap;
        cost[u][v] += cst;
        cost[v][u] -= cst;

        g[u].push_back(v);
        g[v].push_back(u);
    }

    int flow = maxFlowMinCost(source, sink, n);

    fout << flow;

    return 0;
}
