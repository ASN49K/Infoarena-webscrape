#include <iostream>
#include <vector>
#include <fstream>
#include <queue>
using namespace std;
ifstream f ("fmcm.in");
ofstream g ("fmcm.out");
struct elem{
int nod,cost;
bool operator <(const elem &aux)
const{
    return aux.cost<cost;
}
};
priority_queue<elem>q;
vector<pair<int,int>>adiacenta[351];
int n,m,s,d,rasp;
int capacitate[351][351];
int tati[351],dist[351];
bool bellman()
{
    for(int i = 1;i<=n;i++)
        dist[i] = (1<<30)-1;
    q.push({s,0});
    dist[s] = 0;
    while(!q.empty())
    {
        int curent = q.top().nod;
        int cost = q.top().cost;
        q.pop();
        if(curent == d){
            continue;
        }
        for(auto x:adiacenta[curent])
        {
            int nod_nou = x.first;
            int cost_nou = x.second;
            if(dist[nod_nou]>cost_nou+cost && capacitate[curent][nod_nou])
            {
                dist[nod_nou] = cost+cost_nou;
                q.push({nod_nou,dist[nod_nou]});
                tati[nod_nou] = curent;
            }
        }
    }
    if(dist[d]!=(1<<30)-1)
        return 1;
    return 0;
}
int main()
{
    f >> n >> m >> s >> d;
    for(int i= 1;i<=m;i++)
    {
        int x,y,c,cost;
        f >> x >> y >> c >> cost;
        capacitate[x][y] = c;
        adiacenta[x].push_back({y,cost});
        adiacenta[y].push_back({x,-cost});
    }

    while(bellman())
    {
        int nod_start = d,flux = (1<<30)-1;
        while(nod_start!=s)
        {
            flux = min(flux,capacitate[tati[nod_start]][nod_start]);
            nod_start = tati[nod_start];
        }
        if(flux == 0)
            continue;
        nod_start = d;
        while(nod_start!=s)
        {
            capacitate[tati[nod_start]][nod_start]-=flux;
            capacitate[nod_start][tati[nod_start]]+=flux;
            nod_start=tati[nod_start];
        }
        rasp = rasp + flux*dist[d];
    }
    g << rasp;
}
