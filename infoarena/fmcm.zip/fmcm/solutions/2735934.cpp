#include <bits/stdc++.h>
using namespace std;
#define SERVER 0
const string nameFile="fmcm";
ifstream in (nameFile+".in");
ofstream out(nameFile+".out");
typedef pair<int, int> Pii;
#if (SERVER)
    #define in cin
    #define out cout
#endif
const int nmax=350, mmax=12500;
const int oo=1e9;
int x, y, z, t, n, m, source, sink;
short cost[nmax+2][nmax+2];
short capacity[nmax+2][nmax+2];
vector <int> muchii[nmax+2];
int parent[nmax+2];
int dp[nmax+2];
int dp2[nmax+2];
int dp3[nmax+2];
bool inQ[nmax+2];
int costFin, flowFin;
priority_queue<Pii, vector <Pii>, greater<Pii> > pq;
bool dijkstra(){
    fill(dp2+1, dp2+n+1, oo);
    dp2[source]=dp3[source]=0;
    parent[source]=-2;

    pq.push({0, source});
    while(!pq.empty()){
        int cc=pq.top().first;
        int nodAct=pq.top().second;
        pq.pop();
        if(dp2[nodAct]!=cc)
            continue;
        for(auto &x:muchii[nodAct])
            if(capacity[nodAct][x]){
                int newCost=dp2[nodAct]+dp[x]-dp[nodAct]+cost[nodAct][x];
                if(newCost<dp2[x]){
                    dp2[x]=newCost;
                    dp3[x]=dp3[nodAct]+cost[nodAct][x];
                    parent[x]=nodAct;
                    pq.push({dp2[x], x});
                }
            }
    }
    return dp2[sink]!=oo;
}
void bellmanFord(){
    queue <int> q;
    fill(dp+1, dp+n+1, oo);
    fill(inQ+1, inQ+n+1, false);
    dp[source]=0;
    inQ[source]=true;
    q.push(source);

    while(!q.empty()){
        int nod=q.front();
        inQ[nod]=false;
        q.pop();
        for(auto &x:muchii[nod])
            if(capacity[nod][x] && dp[x]>dp[nod]+cost[nod][x]){
                dp[x]=dp[nod]+cost[nod][x];
                if(inQ[x]==false)
                    q.push(x), inQ[x]=true;
            }
    }
}
void flow(){
    bellmanFord();
    while(dijkstra()){
        int nodAct=sink;
        int flowAct=oo;
        while(nodAct!=source){
            flowAct=min(flowAct, 1*capacity[parent[nodAct]][nodAct]);
            nodAct=parent[nodAct];
        }
        nodAct=sink;
        while(nodAct!=source){
            capacity[parent[nodAct]][nodAct]-=flowAct;
            capacity[nodAct][parent[nodAct]]+=flowAct;
            nodAct=parent[nodAct];
        }
        flowFin+=flowAct;
        costFin+=flowAct*dp3[sink];
    }
}
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    in>>n>>m>>source>>sink;
    for(int i=1; i<=m; i++){
        in>>x>>y>>z>>t;
        cost[x][y]=t;
        cost[y][x]=-t;
        muchii[x].push_back(y);
        muchii[y].push_back(x);
        capacity[x][y]=z;
    }

    flow();
    out<<costFin<<"\n";
    return 0;
}
