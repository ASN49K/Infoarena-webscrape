#include <bits/stdc++.h>

using namespace std;
ifstream fin("fmcm.in");
ofstream fout("fmcm.out");
typedef pair<int,int> pii;
const int INF=1e9;
int n,m,S,D,F,C;
int cap[355][355],cost[355][355];
vector<int> muchii[355];
int old_d[355],real_d[355],d[355],from[355];
bool use[355];
void bellman()
{
    for(int i=1;i<=n;i++)
        old_d[i]=INF;
    old_d[S]=0;
    queue<int> coada;
    coada.push(S);
    while(!coada.empty())
    {
        int nod=coada.front();
        coada.pop();
        for(int i:muchii[nod])
            if(cap[nod][i]>0&&old_d[i]>old_d[nod]+cost[nod][i])
            {
                old_d[i]=old_d[nod]+cost[nod][i];
                coada.push(i);
            }
    }
}
bool flux()
{
    for(int i=1;i<=n;i++)
    {
        real_d[i]=INF;
        d[i]=INF;
        use[i]=0;
        from[i]=0;
    }
    real_d[S]=0;
    d[S]=0;
    priority_queue<pii,vector<pii>,greater<pii>> pq;
    pq.push({0,S});
    while(!pq.empty())
    {
        int nod=pq.top().second;
        pq.pop();
        if(use[nod])
            continue;
        use[nod]=1;
        for(int i:muchii[nod])
            if(cap[nod][i]>0&&d[i]>d[nod]+cost[nod][i]+old_d[nod]-old_d[i])
            {
                d[i]=d[nod]+cost[nod][i]+old_d[nod]-old_d[i];
                from[i]=nod;
                real_d[i]=real_d[nod]+cost[nod][i];
                pq.push({d[i],i});
            }
    }
    for(int i=1;i<=n;i++)
        old_d[i]==real_d[i];
    if(real_d[D]==INF)
        return 0;
    int mincap=1e9;
    for(int i=D;i!=S;i=from[i])
        mincap=min(mincap,cap[from[i]][i]);
    F+=mincap;
    C+=mincap*real_d[D];
    for(int i=D;i!=S;i=from[i])
    {
        cap[from[i]][i]-=mincap;
        cap[i][from[i]]+=mincap;
    }
    return 1;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m>>S>>D;
    for(int i=1;i<=m;i++)
    {
        int a,b,x,y;
        fin>>a>>b>>x>>y;
        muchii[a].push_back(b);
        muchii[b].push_back(a);
        cap[a][b]=x;
        cost[a][b]=y;
        cost[b][a]=-y;
    }
    bellman();
    while(flux());
    fout<<C;
    return 0;
}
