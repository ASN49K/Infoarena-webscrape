#include <fstream>
#include <queue>

using namespace std;
ifstream cin ("fmcm.in");
ofstream cout ("fmcm.out");
priority_queue <pair<long long,long long>,vector<pair<long long,long long> >,greater<pair<long long,long long> > >qu;
long long par[355];
long long dist[355];
long long costdist[355];
long long cap[355][355];
long long flow[355][355];
long long cost[355][355];
long long jhon[355];     ///distante initiale pentru folosire dijkstra
queue<long long>que;
vector<long long>adj[355];
long long maxflow=0,mincost=0;
void bellmanford(long long st)
{
    long long curr,i,k;
    que.push(st);
    while(que.size())
    {
        curr=que.front();
        que.pop();
        for(i=0;i<adj[curr].size();i++)
        {
            k=adj[curr][i];
            if(jhon[curr]+cost[curr][k]<jhon[k] && cap[curr][k]!=0)
            {
                jhon[k]=jhon[curr]+cost[curr][k];
                que.push(k);
            }
        }
    }
}
long long inf=1e7;
long long dijkstra(long long st,long long fs,long long n)
{
    long long i,k,curr,val,currflow;
    for(i=1;i<=n;i++)
    {
        dist[i]=inf;
        costdist[i]=inf;
    }
    qu.push({st,0});
    dist[st]=0;
    costdist[st]=0;
    while(qu.size())
    {
        curr=qu.top().first;
        val=qu.top().second;
        qu.pop();
        if(val==dist[curr])
        {
            for(i=0;i<adj[curr].size();i++)
            {
                k=adj[curr][i];
                if(cap[curr][k]-flow[curr][k]>0)
                {
                    if(dist[k]>dist[curr]+cost[curr][k]-jhon[k]+jhon[curr])
                    {
                        dist[k]=dist[curr]+cost[curr][k]-jhon[k]+jhon[curr];
                        costdist[k]=costdist[curr]+cost[curr][k];
                        qu.push({k,dist[k]});
                        par[k]=curr;
                    }
                }
            }
        }
    }
    if(dist[fs]!=inf)
    {
        curr=fs;
        currflow=inf;
        while(curr!=st)
        {
            currflow=min(currflow,cap[par[curr]][curr]-flow[par[curr]][curr]);
            curr=par[curr];
        }
        curr=fs;
        maxflow=maxflow+currflow;
        while(curr!=st)
        {
            flow[par[curr]][curr]=flow[par[curr]][curr]+currflow;
            flow[curr][par[curr]]=flow[curr][par[curr]]-currflow;
            curr=par[curr];
        }
        mincost=mincost+currflow*costdist[fs];
        for(i=1;i<=n;i++)
        {
            jhon[i]=dist[i];
        }
        return 1;
    }
    return 0;
}
int main()
{
    long long i,j,k,l,n,m,a,b,capedge,costedge,st,fs,cst,cp;
    cin>>n>>m>>st>>fs;
    for(i=1;i<=m;i++)
    {
        cin>>a>>b>>cp>>cst;
        cap[a][b]=cp;
        adj[a].push_back(b);
        adj[b].push_back(a);
        cost[a][b]=cst;
        cost[b][a]=-cst;
    }
    for(i=1;i<=n;i++)
    {
        jhon[i]=inf;
    }
    jhon[st]=0;
    bellmanford(st);
    while(dijkstra(st,fs,n)==1){};
    cout<<mincost;
    return 0;

}
