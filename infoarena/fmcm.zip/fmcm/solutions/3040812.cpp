#include <bits/stdc++.h>

using namespace std;
ifstream fin("fmcm.in");
ofstream fout("fmcm.out");
typedef pair<int,int> pii;
int n,m,S,D,Fans,Fcost;
vector<int> muchii[355];
int cap[355][355],cost[355][355],old_d[355],d[355];
int from[355];
bool use[355];
void Bellman()
{
    for(int i=1;i<=n;i++)
        old_d[i]=1e9;
    old_d[S]=0;
    queue<int> coada;
    coada.push(S);
    while(!coada.empty())
    {
        int nod=coada.front();
        coada.pop();
        for(int i:muchii[nod])
            if(cap[nod][i]>0)
            {
                if(old_d[i]>old_d[nod]+cost[nod][i])
                {
                    old_d[i]=old_d[nod]+cost[nod][i];
                    coada.push(i);
                }
            }
    }
    if(old_d[D]==1e9)
    {
        fout<<0;
        exit(0);
    }
}
priority_queue<pii,vector<pii>, greater<pii>> pq;
bool dijkstra()
{
    for(int i=1;i<=n;i++)
    {
        d[i]=1e9;
        use[i]=0;
    }
    d[S]=0;
    pq.push({0,S});
    while(!pq.empty())
    {
        int nod=pq.top().second;
        pq.pop();
        if(use[nod])
            continue;
        use[nod]=1;
        for(int i:muchii[nod])
            if(cap[nod][i]>0)
            {
                int cst=d[nod]+cost[nod][i]+old_d[nod]-old_d[i];
                if(d[i]>cst)
                {
                    d[i]=cst;
                    from[i]=nod;
                    pq.push({d[i],i});
                }
            }
    }
    if(d[D]==1e9)
        return 0;
    int nod=D;
    int minim=1e9;
    while(nod!=S)
    {
        int i=from[nod];
        minim=min(minim,cap[i][nod]);
        nod=from[nod];
    }
    Fans+=minim;
    nod=D;
    while(nod!=S)
    {
        int i=from[nod];
        cap[i][nod]-=minim;
        cap[nod][i]+=minim;
        Fcost+=cost[i][nod]*minim;
        nod=from[nod];
    }
    return 1;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m>>S>>D;
    for(int i=1;i<=m;i++)
    {
        int a,b,c,z;
        fin>>a>>b>>c>>z;
        cap[a][b]=c;
        cost[a][b]=z;
        cost[b][a]=-z;
        muchii[a].push_back(b);
        muchii[b].push_back(a);
    }
    Bellman();
    while(dijkstra());
    fout<<Fcost;
    return 0;
}
