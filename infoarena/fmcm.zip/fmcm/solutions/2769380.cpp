#include <bits/stdc++.h>
#define INF 0x3f3f3f3f
#define NMAX 355

using namespace std;

ifstream f("fmcm.in");
ofstream g("fmcm.out");

int n, m, cost, d[NMAX], D[NMAX], dist[NMAX][NMAX],c[NMAX][NMAX], F[NMAX][NMAX], R[NMAX], t[NMAX];
int start, stop;
bitset <NMAX> v;
vector <int> edges[NMAX];
queue <int> q;
set <pair <int, int>> s;

bool bf()
{
    bool ok = 0;
    v.reset();
    for(int i = 1; i <= n; i++)
        d[i] = INF;
    v[start] = 1;
    d[start] = 0;
    q.push(start);

    while(!q.empty())
    {
        int nod = q.front();
        q.pop();
        v[nod] = 0;
        for(auto child : edges[nod])
            if(c[nod][child] > F[nod][child] && d[child] > d[nod] + dist[nod][child])
            {
                d[child] = d[nod] + dist[nod][child];
                t[child] = nod;
                if(child == stop)
                    ok = 1;

                if(!v[child])
                {
                    v[child] = 1;
                    q.push(child);
                }
            }
    }

    return ok;
}

bool dijkstra()
{
    bool ok = 0;
    for(int i = 1; i <= n; i++)
    {
        t[i] = 0;
        D[i] = INF;
    }

    R[start] = 0;
    D[start] = 0;
    s.insert(make_pair(0, start));

    while(!s.empty())
    {
        pair <int, int> k = *s.begin();
        s.erase(s.begin());
        if(k.first != D[k.second])
            continue;
        int nod = k.second;
        for(auto child : edges[nod])
            if(c[nod][child] > F[nod][child] &&
               D[child] > D[nod] + dist[nod][child] + d[nod] - d[child])
            {
                s.erase(make_pair(D[child], child));
                D[child] = D[nod] + dist[nod][child] + d[nod] - d[child];
                R[child] = R[nod] + dist[nod][child];
                t[child] = nod;
                s.insert(make_pair(D[child], child));
                if(child == stop)
                    ok = 1;
            }
    }

    for(int i = 1; i <= n; i++)
        d[i] = R[i];
    return ok;
}


int main()
{
    f >> n >> m >> start >> stop;

    for(int i = 1; i <= m; i++)
    {
        int x, y, cost, cap;
        f >> x >> y >> cap >> cost;
        dist[x][y] = cost;
        dist[y][x] = -cost;
        edges[x].push_back(y);
        edges[y].push_back(x);
        c[x][y] = cap;
    }

    bf();

    while(dijkstra())
    {
        int minim = INF;
        int k = stop;
        while(k != start)
        {
            minim = min(minim, c[t[k]][k] - F[t[k]][k]);
            k = t[k];
        }

        k = stop;
        while(k != start)
        {
            cost += dist[t[k]][k] * minim;
            F[t[k]][k] += minim;
            F[k][t[k]] -= minim;
            k = t[k];
        }
    }

    g << cost;
    return 0;
}
