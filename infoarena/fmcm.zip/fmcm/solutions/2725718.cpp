#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

const int N = 355;
const int INF = 1e9;

int n, m, source, sink, fmax, costMin;
int t[N], cap[N][N], cost[N][N], flow[N][N];
vector<int> realDist, newRealDist, positiveDist;
vector<int> g[N];
vector<bool> vis;

vector<bool> inCoada;
void BellmanFordCoada(int startNode)
{
    inCoada.assign(n + 1, false);
    realDist.assign(n + 1, INF);

    queue<int> coada;
    coada.push(startNode);
    inCoada[startNode] = true;
    realDist[startNode] = 0;
    t[startNode] = 0;

    while(!coada.empty())
    {
        int x = coada.front();
        coada.pop();
        inCoada[x] = false;

        for (int y : g[x])
        {
            if (realDist[x] + cost[x][y] < realDist[y] && flow[x][y] != cap[x][y])
            {
                t[y] = x;
                realDist[y] = realDist[x] + cost[x][y];
                if (!inCoada[y])
                {
                    coada.push(y);
                    inCoada[y] = true;
                }
            }
        }
    }
}

void Dijkstra(int startNode)
{
    positiveDist.assign(n + 1, INF);
    newRealDist.assign(n + 1, INF);
    vis.assign(n + 1, false);

    priority_queue<pair<int, int>> heap;

    positiveDist[startNode] = newRealDist[startNode] = 0;
    heap.push({0, startNode});

    while(!heap.empty())
    {
        int x = heap.top().second;
        int distx = -heap.top().first;
        heap.pop();

        if(vis[x])
            continue;
        vis[x] = true;
        
        for(int y : g[x])
        {
            int positiveCostXY = realDist[x] + cost[x][y] - realDist[y];

            if(!vis[y] && flow[x][y] != cap[x][y] && distx + positiveCostXY < positiveDist[y])
            {
                heap.push({-(distx + positiveCostXY), y});
                positiveDist[y] = positiveDist[x] + positiveCostXY;
                newRealDist[y] = newRealDist[x] + cost[x][y];
                t[y] = x;
            }
        }
    }

    realDist = newRealDist;
}

void maxFlowMinCost()
{
    BellmanFordCoada(source);
    do
    {
        Dijkstra(source);

        if(positiveDist[sink] == INF)
            break;

        int fmin = 1 << 30;
        for(int node = sink; node != source; node = t[node])
            fmin = min(fmin, cap[t[node]][node] - flow[t[node]][node]);

        fmax += fmin;
        costMin += realDist[sink] * fmin;
        for(int node = sink; node != source; node = t[node])
        {
            flow[t[node]][node] += fmin;
            flow[node][t[node]] -= fmin;
        }
    } while(positiveDist[sink] != INF);
}

void addEdge(int x, int y, int c, int z)
{
    g[x].push_back(y);
    g[y].push_back(x);
    cap[x][y] = c;
    cap[y][x] = 0;
    cost[x][y] = z;
    cost[y][x] = -z;
}

int main()
{
    fin >> n >> m >> source >> sink;

    for (int i = 0; i < m; i++)
    {
        int x, y, c, z;
        fin >> x >> y >> c >> z;
        addEdge(x, y, c, z);
    }

    maxFlowMinCost();
    fout << costMin << '\n';

    return 0;
}