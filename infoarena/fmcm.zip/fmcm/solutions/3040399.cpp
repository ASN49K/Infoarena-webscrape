include <bits/stdc++.h>
using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

const int N = 352;

int cap[N][N], cost[N][N];
vector<bool> vis;
int n, m, x, y, z, c, s, d;

vector<int> gr[N], dist, prnt;

int dijkstra(int s, int t)
{
    queue<int> q;
    vis.assign(N, 0);
    dist.assign(N, INT_MAX);
    q.push(s);
    prnt[s] = s;
    vis[s] = 1;
    dist[s] = 0;
    while(!q.empty())
    {
        int nod = q.front();
        q.pop();
        vis[nod] = 0;
        for (auto i: gr[nod])
        {
            if(cap[nod][i] > 0 && dist[nod] + cost[nod][i] < dist[i])
            {
                dist[i] = dist[nod] + cost[nod][i];
                prnt[i] = nod;
                if (vis[i] == 0)
                {
                    q.push(i);
                    vis[i] = 1;
                }
            }
        }
    }
    return dist[t];
}


int main()
{
    fin>>n>>m>>s>>d;
    for (int i = 1; i <= m; i ++)
    {
        fin>>x>>y>>z>>c;
        gr[x].push_back(y);
        gr[y].push_back(x);
        cap[x][y] = z;
        cost[x][y] = c;
        cost[y][x] = -c;
    }
    int flow = 0;
    prnt.assign(N, 0);
    while (true)
    {
        int mindist = dijkstra(s, d);
        if (mindist == INT_MAX) break;
        int minflow = INT_MAX;
        for (int i = d; i != s; i = prnt[i])
            minflow = min(minflow, cap[prnt[i]][i]);
        for (int i = d; i != s; i = prnt[i])
        {
            cap[prnt[i]][i] -= minflow;
            cap[i][prnt[i]] += minflow;
        }
        flow += minflow * mindist;
    }
    fout<<flow;
}