#include <cmath>
#include <functional>
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <set>
#include <map>
#include <list>
#include <time.h>
#include <math.h>
#include <random>
#include <deque>
#include <cassert>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <iomanip>
#include <bitset>
#include <sstream>
#include <stack>
#include <chrono>
#include <cstring>
#include <numeric>
using namespace std;
typedef long long ll;
const ll INFLL = (ll)1e18 + 7;
const int INFINT = (int)1e9 + 7;
struct MCMF {
	struct Edge {
		int to, cap, cost;
	};
	int n, source, dest;
	int flow;
	ll cost;
	vector<Edge> edges;
	vector<vector<int>> g;
	vector<ll> optimal;
	vector<ll> inits;
	vector<int> parind;
	priority_queue<pair<ll, int>> pq;
	void init(int nn, int ss, int dd) {
		n = nn;
		source = ss;
		dest = dd;
		flow = 0;
		cost = 0;
		source = ss - 1;
		dest = dd - 1;
		edges.clear();
		g.clear();
		g.resize(n);
		assert(0 <= source && source < n);
		assert(0 <= dest && dest < n);
		assert(source != dest);
	}
	void addedge(int a, int b, int cap, int cost) {
		a--;
		b--;
		assert(0 <= a && a < n);
		assert(0 <= b && b < n);
		edges.push_back({ b, cap, cost });
		edges.push_back({ a, 0, -cost });
		g[a].push_back((int)edges.size() - 2);
		g[b].push_back((int)edges.size() - 1);
	}
	bool pumpfirst() {
		assert(pq.empty());
		optimal.clear();
		optimal.resize(n, INFLL);
		optimal[source] = 0;
		parind.clear();
		parind.resize(n, -1);
		pq.push({ -optimal[source], source });
		while (!pq.empty()) {
			auto itpq = pq.top();
			pq.pop();
			int vertex = itpq.second;
			if (-itpq.first != optimal[vertex]) {
				continue;
			}
			for (auto& index : g[vertex]) {
				int b = edges[index].to;		
				if (edges[index].cap == 0) {
					continue;
				}
				if (optimal[vertex] + edges[index].cost < optimal[b]) {
					optimal[b] = optimal[vertex] + edges[index].cost;
					parind[b] = index;
					pq.push({ -optimal[b], b });
				}
			}
		}
		if (parind[dest] == -1) {
			return 0;
		}
		return 1;
	}
	bool pumponce() {
		inits.clear();
		inits.resize(n);
		for (int i = 0; i < n; i++) {
			inits[i] = optimal[i];
		}
		assert(pq.empty());
		optimal.clear();
		optimal.resize(n, INFLL);
		optimal[source] = 0;
		parind.clear();
		parind.resize(n, -1);
		pq.push({ -optimal[source], source });
		while (!pq.empty()) {
			auto itpq = pq.top();
			pq.pop();
			int vertex = itpq.second;
			if (-itpq.first != optimal[vertex]) {
				continue;
			}
			for (auto& index : g[vertex]) {
				int b = edges[index].to;
				if (edges[index].cap == 0) {
					continue;
				}
				assert(inits[vertex] - inits[b] + edges[index].cost >= 0);
				if (optimal[vertex] + inits[vertex] - inits[b] + edges[index].cost < optimal[b]) {
					optimal[b] = optimal[vertex] + inits[vertex] - inits[b] + edges[index].cost;
					parind[b] = index;
					pq.push({ -optimal[b], b });
				}
			}
		}
		for (int i = 0; i < n; i++) {
			optimal[i] = optimal[i] + inits[i];
		}
		if (parind[dest] == -1) {
			return 0;
		}
		return 1;
	}
	void pumpall() {
		pumpfirst();
		while (pumponce()) {
			int mn = INFINT;
			int v = dest;
			while (v != source) {
				int i = parind[v];
				assert(edges[i].to == v);
				mn = min(mn, edges[i].cap);
				v = edges[i ^ 1].to;
			}
			assert(mn > 0);
			flow += mn;
			cost += mn * (ll)optimal[dest];
			v = dest;
			while (v != source) {
				int i = parind[v];
				assert(edges[i].to == v);
				edges[i].cap -= mn;
				edges[i ^ 1].cap += mn;
				v = edges[i ^ 1].to;
			}
		}
	}
};
signed main() {
#ifdef ONPC
	FILE* stream;
	freopen_s(&stream, "input.txt", "r", stdin);
#else
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	freopen("fmcm.in", "r", stdin);
	freopen("fmcm.out", "w", stdout);
#endif
	MCMF flow;
	int n, m, s, d;
	cin >> n >> m>>s >> d;
	flow.init(n, s, d);
	for (int i = 1; i <= m; i++) {
		int a, b, cap, cost;
		cin >> a >> b >> cap >> cost;
		flow.addedge(a, b, cap, cost);
	}
	flow.pumpall();
	cout << flow.cost << "\n";
	return 0;
}