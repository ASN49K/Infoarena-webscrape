#include <bits/stdc++.h>

using namespace std;
ifstream fin("fmcm.in");
ofstream fout("fmcm.out");
int n,m,S,D,c[355][355],cost[355][355],ans,dist[355],from[355];
vector<int> muchii[355];
const int INF=1e9;
bool in_queue[355];
bool BellmanFord()
{
    for(int i=1;i<=n;i++)
    {
        dist[i]=1e9;
        from[i]=0;
        in_queue[i]=0;
    }
    queue<int> Q;
    dist[S]=0;
    in_queue[S]=1;
    Q.push(S);
    while(!Q.empty())
    {
        int nod=Q.front();
        in_queue[nod]=0;
        Q.pop();
        for(auto i:muchii[nod])
            if(c[nod][i]>0&&dist[i]>dist[nod]+cost[nod][i])
            {
                dist[i]=dist[nod]+cost[nod][i];
                from[i]=nod;
                if(!in_queue[i])
                {
                    in_queue[i]=1;
                    Q.push(i);
                }
            }
    }
    if(dist[D]==INF)
        return 0;
    int mincap=1e9;
    for(int nod=D;nod!=S;nod=from[nod])
        mincap=min(mincap,c[from[nod]][nod]);
    ans+=mincap*dist[D];
    for(int nod=D;nod!=S;nod=from[nod])
    {
        c[from[nod]][nod]-=mincap;
        c[nod][from[nod]]+=mincap;
    }
    return 1;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fout.tie(0);
    fin>>n>>m>>S>>D;
    for(int i=1;i<=m;i++)
    {
        int a,b;
        fin>>a>>b;
        fin>>c[a][b]>>cost[a][b];
        cost[b][a]=-cost[a][b];
        muchii[a].push_back(b);
        muchii[b].push_back(a);
    }
    while(BellmanFord());
    fout<<ans;
    return 0;
}
