#include <bits/stdc++.h>
#include <fstream>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
using namespace std;
template<class T> using ordered_set = tree<T, null_type, less<T>, rb_tree_tag, tree_order_statistics_node_update>;
struct custom_hash {static uint64_t splitmix64(uint64_t x) {x += 0x9e3779b97f4a7c15;x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9;x = (x ^ (x >> 27)) * 0x94d049bb133111eb;return x ^ (x >> 31);}size_t operator()(uint64_t x) const {static const uint64_t FIXED_RANDOM = chrono::steady_clock::now().time_since_epoch().count();return splitmix64(x + FIXED_RANDOM);}};
string __fname = "fmcm"; ifstream in (__fname + ".in"); ofstream out (__fname + ".out"); 
#define cin in 
#define cout out
#define int64 long long
#define uint64 unsigned long long
#define x first
#define y second
#define pb push_back
#define pii pair <int, int> 
#define pii64 pair <int64, int64>
#define db(x) cout << "> " << #x << ": " << (x) << "\n"
#define qr queries()
#define yn(x) if (x) {ctn("Yes");}else {ctn("No");}
void solve(int);
void queries(){int n;cin >> n;for (int i = 1; i <= n; i++) solve(i);}
template<class T>T ceildiv(T a, T b) {return a / b + !!(a % b);}
template<class T>T gcd (T a, T b){return (b ? gcd(b, a % b): a);}
template<class T>T lcm (T a, T b){return a * b / gcd(a, b);}
// // // // // // // // // // // // // // // // // // // // // // 
/*                  TEMPLATE - VANILLA                         */
// // // // // // // // // // // // // // // // // // // // // //
const int ddx[] = {-1, -1, 0, 1, 1, 1, 0, -1};
const int ddy[] = {0, 1, 1, 1, 0, -1, -1, -1};
const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};
const double pi = 3.14159265359;
const double eps = 1e-6;
const int64 hash_inv = 940594066;
const int64 hash_p = 101;
const int64 mod = 1e9 + 7;
const int maxn = 351;
vector <pii> ad [maxn];
int cp [maxn][maxn];
int dist [maxn];
int from [maxn];
bool inqueue [maxn];

void solve(int id){
    
    return;
}

void getflow (int s, int d) {
    queue <int> q;
    fill(dist, dist + maxn, 1e9);
    fill(from, from + maxn, -1);
    fill(inqueue, inqueue + maxn, 0);
    dist[s] = 0;
    q.push(s);
    inqueue[s] = 1;
    while (!q.empty()) {
        int u = q.front();
        inqueue[u] = 0;
        q.pop();
        for (auto [v, cost]: ad[u]) {
            if (dist[u] + cost < dist[v] && cp[u][v]) {
                dist[v] = dist[u] + cost;
                from[v] = u;
                if (!inqueue[v]) {
                    inqueue[v] = 1;
                    q.push(v);
                }
            }
        }
    }

}


int main(){
    ios_base::sync_with_stdio(0); cin.tie(0); cout << fixed; cout << setprecision(10); 
    int n,m,s,d;
    cin >> n >> m >> s >> d;
    for (int i = 0; i < m; i++){
        int x,y, c, w;
        cin >> x >> y >> c >> w;
        cp[x][y] = c;
        ad[x].push_back({y, w});
    }
    int rs = 0;
    while (1) {
        getflow(s, d);
        if (dist[d] == 1e9) break;
        int flow = 1e9;
        int now = d;
        while (now != s) {
            flow = min(flow, cp[from[now]][now]);
            now = from[now];
        }
        rs+=flow * dist[d];
        now = d;
        while (now != s) {
            cp[now][from[now]]+=flow;
            cp[from[now]][now]-=flow;
            now = from[now];
        }
    }
    cout << rs;
    return 0;
}