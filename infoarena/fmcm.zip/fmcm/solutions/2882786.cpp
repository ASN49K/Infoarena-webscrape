#include <bits/stdc++.h>
#define INF 0x3f3f3f3f

using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

const int kN = 350;
short n, m, s, t, par[1 + kN], q[kN * kN], C[1 + kN][1 + kN], W[1 + kN][1 + kN];
int minCost, d[1 + kN], dp[1 + kN], D[1 + kN];
vector<short> g[1 + kN];
bitset<1 + kN> inQ;

void BellmanFord() {
  d[s] = 0;
  int l = 0, r = -1;
  q[++r] = s;
  inQ[s] = true;
  while (l <= r) {
    int u = q[l++];
    inQ[u] = false;
    for (int v : g[u]) {
      if (C[u][v] && d[v] > d[u] + W[u][v]) {
        d[v] = d[u] + W[u][v];
        if (!inQ[v]) {
          q[++r] = v;
          inQ[v] = true;
        }
      }
    }
  }
}

bool Dijkstra() {
  for (short i = 1; i <= n; ++i) {
    dp[i] = INF;
  }
  dp[s] = 0;
  D[s] = 0;
  priority_queue<pair<int, short>, vector<pair<int, short>>, greater<pair<int, short>>> pq;
  pq.emplace(0, s);
  while (!pq.empty()) {
    int cost;
    short u;
    tie(cost, u) = pq.top();
    pq.pop();
    if (cost != dp[u]) {
      continue;
    }
    for (short v : g[u]) {
      if (C[u][v] && dp[v] > cost + W[u][v] + d[u] - d[v]) {
        dp[v] = cost + W[u][v] + d[u] - d[v];
        D[v] = D[u] + W[u][v];
        par[v] = u;
        pq.emplace(dp[v], v);
      }
    }
  }
  if (dp[t] == INF) {
    return false;
  }
  for (short i = 1; i <= n; ++i) {
    d[i] = D[i];
  }
  int flow = INF;
  for (short v = t; v != s; v = par[v]) {
    if (C[par[v]][v] < flow) {
      flow = C[par[v]][v];
    }
  }
  minCost += flow * D[t];
  for (short v = t; v != s; v = par[v]) {
    C[par[v]][v] -= flow;
    C[v][par[v]] += flow;
  }
  return true;
}

void testCase() {
  fin >> n >> m >> s >> t;
  for (int i = 0; i < m; ++i) {
    short u, v, c, w;
    fin >> u >> v >> c >> w;
    g[u].emplace_back(v);
    g[v].emplace_back(u);
    C[u][v] += c;
    W[u][v] = w;
    W[v][u] = -w;
  }
  BellmanFord();
  while (Dijkstra());
  fout << minCost << '\n';
}

int main() {
  short tests = 1;
  for (short tc = 0; tc < tests; ++tc) {
    testCase();
  }
  fin.close();
  fout.close();
  return 0;
}
