#include <bits/stdc++.h>
//#pragma GCC optimize("unroll-loops")

using namespace std;
typedef long long ll;
typedef pair<ll,ll> pll;
const int NMAX=355,MMAX=12505,INF=1e9;
int cap[NMAX][NMAX],cost[NMAX][NMAX];
vector<ll> edg[NMAX];
int bellman_dist[NMAX],dist[NMAX],start,sink;
int prv[NMAX];
random_device rd;
mt19937 gen(rd());
int rndnext(int l, int r){
    uniform_int_distribution<int> rnd(l,r);
    return rnd(gen);
}
int main()
{
    ifstream fin("fmcm.in");
    ofstream fout("fmcm.out");
    int n,m;
    fin>>n>>m>>start>>sink;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            cost[i][j]=INF;
    for(int i=0;i<m;i++){
        int u,v,c,z;
        fin>>u>>v>>c>>z;

        cost[u][v]=z,cost[v][u]=-z,cap[u][v]=c;
        edg[u].push_back(v);
        edg[v].push_back(u);
    }
    if(start==sink){
        fout<<0;
        return 0;
    }
    for(int i=1;i<=n;i++) bellman_dist[i]=INF;
    bellman_dist[start]=0;
    for(int iter=0;iter<n;iter++){
        for(int i=1;i<=n;i++){
            for(auto it : edg[i]){
                if(cap[i][it])
                    bellman_dist[it]=min(bellman_dist[it],bellman_dist[i]+cost[i][it]);
            }
        }
    }
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            cost[i][j]+=bellman_dist[i]-bellman_dist[j];
    int ans=0,total_cost=0;
    while(1){
        set<pair<int,int>> s;
        for(int i=1;i<=n;i++) dist[i]=INF,prv[i]=-1;
        dist[start]=0,prv[start]=start;
        s.insert({dist[start],start});
        while(!s.empty()){
            int u=s.begin()->second;
            s.erase(s.begin());
            if(u==sink){
                s.clear();
                break;
            }
            for(const auto &it : edg[u]){
                if(cap[u][it] && dist[u]+cost[u][it]<dist[it]){
                    if(dist[it]!=INF) s.erase({dist[it],it});
                    dist[it]=dist[u]+cost[u][it];
                    s.insert({dist[it],it});
                    prv[it]=u;
                }
            }
        }
        if(prv[sink]==-1) break;
        int total_flow=INF,aux=sink;
        while(aux!=start){
            total_flow=min(total_flow,cap[prv[aux]][aux]);
            aux=prv[aux];
        }
        aux=sink;
        ans+=total_flow,total_cost+=(dist[sink]+bellman_dist[sink])*total_flow;
        while(aux!=start){
            cap[prv[aux]][aux]-=total_flow,cap[aux][prv[aux]]+=total_flow;
            aux=prv[aux];
        }
    }
    fout<<total_cost;
    return 0;
}
