#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream f ("a.in");
ofstream g ("a.out");
struct elem{
int nod,cost;
bool operator < (const elem &aux)
const{
        return aux.cost<cost;
    }
};
int dist[351],capacitate[351][351];
priority_queue < elem>q;
vector<pair<int,int>>adiacenta[351];
int n,m,s,d,rasp_cost;
int tati[351];
int bellman()
{
    for(int i = 1;i<=n;i++)
        dist[i]=(1<<30)-1;
    dist[s] = 0;
    q.push({s,0});
    while(!q.empty())
    {
        int curent = q.top().nod;
        int cost = q.top().cost;
        q.pop();
        if(curent==d)
            continue;
        for(auto x:adiacenta[curent])
        {
            int newnod = x.first;
            int newcost = x.second;
            if(capacitate[curent][newnod] && dist[newnod]>cost+newcost)
            {
                dist[newnod] = cost+newcost;
                q.push({newnod,dist[newnod]});
                tati[newnod] = curent;
            }
        }
    }
    if(dist[d]!=(1<<30)-1)
        return 1;
    return 0;
}
int main()
{
    f >> n >> m>>s>>d;
    for(int i=1;i<=m;i++)
    {
        int x,y,c,cost;
        f >> x >> y >> c>> cost;
        adiacenta[x].push_back({y,cost});
        adiacenta[y].push_back({x,-cost});
        capacitate[x][y] = c;
    }
    while(bellman())
    {
        for(auto x:adiacenta[d])
        {
             if(capacitate[x.first][d]!=0 && dist[x.first]!=0)
            {
                int flux = (1<<30)-1;
                int nod_start = d;
                while(nod_start!=s)
                {
                    flux= min(flux,capacitate[tati[nod_start]][nod_start]);
                    nod_start = tati[nod_start];
                }
                if(flux==0)
                    continue;
                nod_start = d;
                while(nod_start!=s)
                {
                    capacitate[tati[nod_start]][nod_start]-=flux;
                    capacitate[nod_start][tati[nod_start]]+=flux;
                    nod_start = tati[nod_start];
                }
                rasp_cost+=flux*dist[d];
            }
        }
    }
    g<<rasp_cost;
}
