#include <bits/stdc++.h>
using namespace std;
ifstream in("fmcm.in");
ofstream out("fmcm.out");
const int inf=1e9+7;
priority_queue<pair<int,int> > pq;
vector<int> vec[355];
vector<int> dir[355];
int cost[355][355];
int base[355][355];
int cap[355][355];
int last[355];
int dist[355];
int part[355];
bool inq[355];
queue<int> q;
int src,dest;
int x,y,c,z;
int n,m;
int main()
{
    in>>n>>m;
    in>>src>>dest;
    for(int i=1;i<=m;++i)
        in>>x>>y>>c>>z,
        dir[x].push_back(y),
        vec[x].push_back(y),
        vec[y].push_back(x),
        base[y][x]=-z,
        base[x][y]=z,
        cap[x][y]=c;
    for(int i=1;i<=n;++i)
        inq[i]=false,
        dist[i]=inf;
    q.push(src);
    dist[src]=0;
    while(!q.empty())
    {
        int nod=q.front();
        inq[nod]=false,q.pop();
        for(int x:dir[nod])
        if(dist[x]>dist[nod]+base[nod][x])
        {
            dist[x]=dist[nod]+base[nod][x];
            if(!inq[x]) inq[x]=true,q.push(x);
        }
    }
    for(int i=1;i<=n;++i)
    for(int x:vec[i])
        cost[i][x]=base[i][x]+dist[i]-dist[x];
    int flow=0,ans=0;
    do
    {
        for(int i=1;i<=n;++i)
            part[i]=inf,
            last[i]=0;
        last[src]=-1;
        part[src]=0;
        pq.push({0,src});
        while(!pq.empty())
        {
            int c=-(pq.top()).first;
            int u=(pq.top()).second;
            pq.pop();
            if(c!=part[u])
                continue;
            for(int x:vec[u])
            if(cap[u][x]>0 and part[x]>part[u]+cost[u][x])
            {
                part[x]=part[u]+cost[u][x];
                pq.push({-part[x],x});
                last[x]=u;
            }
        }
        if(last[dest])
        {
            int minim=inf;
            for(int k=dest;last[k]>0;k=last[k])
                minim=min(minim,cap[last[k]][k]);
            flow+=minim;
            ans+=minim*(part[dest]-(dist[src]-dist[dest]));
            for(int k=dest;last[k]>0;k=last[k])
                cap[last[k]][k]-=minim,
                cap[k][last[k]]+=minim;
        }
    }while(last[dest]);
    out<<ans<<'\n';
    return 0;
}
