#include<bits/stdc++.h>
#define int long long
#define INF 1000000000000000000
using namespace std;
ifstream f("fmcm.in");
ofstream g("fmcm.out");

int n,m,s,d,a[355][355],tata[355],inq[355],dist[355],sol=0,b[355][355];
vector<int>v[355];
queue<int>q;

int bellman()
{
    int i;
    for(i=1; i<=n; i++)
        tata[i]=0,dist[i]=INF;
    q.push(s);
    inq[s]=1;
    dist[s]=0;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        inq[nod]=0;
        for(auto it:v[nod])
        {
            if(a[nod][it]>0 && dist[it]>dist[nod]+b[nod][it])
            {
                dist[it]=dist[nod]+b[nod][it];
                tata[it]=nod;
                if(inq[it]==0)
                {
                    inq[it]=1;
                    q.push(it);
                }
            }
        }
    }
    return dist[d];
}

void flux_maxim()
{
    int flux=INF,nr,val;
    while(bellman()!=INF)
    {
        nr=d;
        flux=INF;
        while(nr!=s)
        {
            flux=min(flux,a[tata[nr]][nr]);
            if(flux==0)
                break;
            nr=tata[nr];
        }
        if(flux==INF || flux==0)
            continue;
        nr=d;
        val=0;
        while(nr!=s)
        {
            a[tata[nr]][nr]-=flux;
            a[nr][tata[nr]]+=flux;
            val+=b[tata[nr]][nr];
            nr=tata[nr];
        }
        sol+=(val*flux);
    }
}

signed main()
{
    int i,c,z,x,y;
    f>>n>>m>>s>>d;
    for(i=1; i<=m; i++)
    {
        f>>x>>y>>c>>z;
        v[x].push_back(y);
        v[y].push_back(x);
        a[x][y]+=c;
        b[x][y]=z;
        b[y][x]=-z;
    }
    flux_maxim();
    g<<sol;
    return 0;
}
