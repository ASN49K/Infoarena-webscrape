#include <bits/stdc++.h>
#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("fmcm.in" , "r" , stdin) , freopen("fmcm.out" , "w" , stdout)
#define pii pair < int , int >
#define pb push_back

namespace FastRead
{
    char __buff[5000];int __lg = 0 , __p = 0;
    char nc()
    {
        if(__lg == __p){__lg = fread(__buff , 1 , 5000 , stdin);__p = 0;if(!__lg) return EOF;}
        return __buff[__p++];
    }
    template<class T>void read(T&__x)
    {
        T __sgn = 1; char __c;while(!isdigit(__c = nc()))if(__c == '-')__sgn = -1;
        __x = __c - '0';while(isdigit(__c = nc()))__x = __x * 10 + __c - '0';__x *= __sgn;
    }
}

using namespace FastRead;
using namespace std;

const int N = 355;

int n , m , source , sink , x , y , z , c;
int capacity[N][N] , weight[N][N] , parent[N];
int d[N] , nd[N];
vector < int > G[N];
set < pii > s;
bitset < N > inq;
queue < int > q;

void bellman()
{
    for(int i = 1 ; i <= n ; i++)
        d[i] = INT_MAX;

    d[source] = 0;
    q.push(source);

    while(!q.empty())
    {
        int u = q.front(); q.pop();
        inq[u] = 0;

        for(auto v : G[u])
        {
            if(capacity[u][v] && d[v] > d[u] + weight[u][v])
            {
                d[v] = d[u] + weight[u][v];

                if(inq[v])
                    continue;

                inq[v] = 1;
                q.push(v);
            }
        }
    }
}

int k = INT_MAX;
int flow;
int minCost = 0;

bool djikstra()
{
    for(int i = 1 ; i <= n ; i++)
        nd[i] = INT_MAX;

    nd[source] = 0;

    s.insert({0 , source});

    while(!s.empty())
    {
        int u = s.begin() -> second;
        int cst = s.begin() -> first;

        s.erase(s.begin());

        if(nd[u] != cst)
            continue;

        for(auto v : G[u])
        {
            if(capacity[u][v])
            {
                if(nd[v] > nd[u] + weight[u][v] + d[u] - d[v])
                {
                    parent[v] = u;
                    nd[v] = nd[u] + weight[u][v] + d[u] - d[v];
                    s.insert({nd[v] , v});
                }
            }
        }
    }

    if(nd[sink] == INT_MAX)
        return 0;

    int minFlow = k - flow;
    int curr;

    for(curr = sink ; curr != source ; curr = parent[curr])
        minFlow = min(minFlow , capacity[parent[curr]][curr]);

    for(curr = sink ; curr != source ; curr = parent[curr])
    {
        capacity[parent[curr]][curr] -= minFlow;
        capacity[curr][parent[curr]] += minFlow;
        minCost += minFlow * weight[parent[curr]][curr];
    }

    flow += minFlow;

    return 1;
}

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

    cin >> n >> m >> source >> sink;
    //read(n) , read(m) , read(source) , read(sink);

    for(int i = 1 ; i <= m ; i++)
    {
        cin >> x >> y >> c >> z;
        //read(x) , read(y) , read(c) , read(z);

        capacity[x][y] = c;

        weight[x][y] = z;
        weight[y][x] = -z;

        G[x].pb(y);
        G[y].pb(x);
    }

    bellman();
    while(djikstra());
    cout << minCost;

    return 0;
}
