#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <climits>
#include <cstring>
using namespace std;

ifstream f ("bellmanford.in");
ofstream g ("bellmanford.out");

vector < int >v[505];

int maxflow;
int dist[500] , tata[500] , viz[500] , n , m , x , y , cap[505][505] , z , cost[505][505] , start , stop , c;


int dij (int start , int stop)
{
    memset (dist , INT_MAX , sizeof (dist));
    memset (viz , 0 , sizeof (viz));
    memset (tata , 0 , sizeof (tata));
    queue < int >coada;
    coada.push (start);
    viz[start] = 1;
    dist[start] = 0;
    tata[start] = start;
    while (!coada.empty ())
    {
        int nod = coada.front ();
        coada.pop ();
        viz[nod] = 0;
        for (int i = 0 ; i < v[nod].size () ; i++)
         {
            int vecin = v[nod][i];
            if (cap[nod][vecin] > 0 && dist[vecin] > dist[nod] + cost[nod][vecin])
            {
                tata[vecin] = nod;
                dist[vecin] = dist[nod] + cost[nod][vecin];
                if (viz[vecin] == 0)
                {
                    coada.push (vecin);
                    viz[vecin] = 1;
                }
            }
         }
    }
    return dist[stop];
}

int flux (int start , int stop)
{
    int s = 0 , maxflow = 0 ;
    while (true)
    {

        s = dij (start , stop);
        if (s == INT_MAX)
            break;

        int flow = INT_MAX;

        for (int j = stop ; j != start ; j = tata[j])
            flow = min (flow , cap[tata[j]][j]);

        for (int j = stop ; j != start ; j = tata[j])
            {
                cap[tata[j]][j] -= flow;
                cap[j][tata[j]] += flow;
            }
            maxflow += flow * s;

    }
    return maxflow;
}

int main()
{
    f >> n >> m >> start >> stop;
    for (int i = 1 ; i <= m ; i++)
    {
        f >> x >> y >> c >> z;
        v[x].push_back (y);
        v[y].push_back (x);
        cap[x][y] = c;
        cost[x][y] = z;
        cost[y][x] = -z;
    }

    g << flux (start , stop);
    return 0;
}
