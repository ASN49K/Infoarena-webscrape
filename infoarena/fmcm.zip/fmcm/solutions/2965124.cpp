#include <bits/stdc++.h>
#pragma GCC optimize("unroll-loops")
#pragma GCC optimize("O3")
#pragma GCC optimize("fast-math")

using namespace std;
//typedef long long ll;
//typedef pair<ll,ll> pll;
const int NMAX=512,MMAX=12505,INF=0x3f3f3f3f,buffsize=1<<18;
int cap[NMAX][NMAX],cost[NMAX][NMAX];
short edg[NMAX][NMAX],deg[NMAX];
int bellman_dist[NMAX],dist[NMAX];
short prv[NMAX];
set<pair<int, int > > s;

FILE* fin;
char buff[buffsize];
int buffpos=0;
short read(){
    short n=0,sgn=1;
    while(buff[buffpos]<'0' || buff[buffpos]>'9'){
        if(buff[buffpos]=='-') sgn=-1;
        ++buffpos;
    }
    while(buff[buffpos]>='0' && buff[buffpos]<='9'){
        n=(n<<1)+(n<<3)+(buff[buffpos]^48);
        ++buffpos;
    }
    return n*sgn;
}
int main()
{
    fin=fopen("fmcm.in","r");
    fread(buff,1,buffsize,fin);
    ofstream fout("fmcm.out");
    short n=read(),m=read(),start=read(),sink=read();
    for(short i=1;i<=n;i++)
        for(short j=1;j<=n;j++)
            cost[i][j]=INF;
    for(short i=0;i<m;i++){
        short u=read(),v=read(),c=read(),z=read();

        cost[u][v]=z,cost[v][u]=-z,cap[u][v]=c;
        edg[u][deg[u]++]=v;
        edg[v][deg[v]++]=u;
    }
    if(start==sink){
        fout<<0;
        return 0;
    }
    for(short i=1;i<=n;++i) bellman_dist[i]=INF;
    bellman_dist[start]=0;
    for(short iter=0;iter<n;++iter){
        for(short i=1;i<=n;++i){
            for(short j=0;j<deg[i];++j){
                short it=edg[i][j];
                if(cap[i][it] && bellman_dist[i]+cost[i][it]<bellman_dist[it])
                    bellman_dist[it]=bellman_dist[i]+cost[i][it];
            }
        }
    }
    //assert(0);
    for(short i=1;i<=n;++i)
        for(short j=1;j<=n;++j)
            cost[i][j]+=bellman_dist[i]-bellman_dist[j];

    int total_cost=0;
    while(1){
        memset(dist,0x3f,sizeof dist);
        memset(prv,0,sizeof prv);
        dist[start]=0,prv[start]=start;
        s.insert({dist[start],start});
        while(!s.empty()){
            short u=s.begin()->second;
            s.erase(s.begin());
            for(short j=0;j<deg[u];++j){
                int it=edg[u][j],new_d=cost[u][it]+dist[u];
                if(cap[u][it] && new_d<dist[it]){
                    if(dist[it]!=INF) s.erase({dist[it],it});
                    dist[it]=new_d;
                    s.insert({dist[it],it});
                    prv[it]=u;
                }
            }
        }
        if(prv[sink]==0) break;
        //for(int i=1;i<=n;i++) bellman_dist[i]=dist[i];
        int total_flow=INF;
        short aux=sink;
        while(aux!=start){
            if(cap[prv[aux]][aux]<total_flow)
                total_flow=cap[prv[aux]][aux];
            aux=prv[aux];
        }
        aux=sink;
        total_cost+=(dist[sink]+bellman_dist[sink])*total_flow;
        while(aux!=start){
            cap[prv[aux]][aux]-=total_flow,cap[aux][prv[aux]]+=total_flow;
            aux=prv[aux];
        }
    }
    fout<<total_cost;
    return 0;
}
