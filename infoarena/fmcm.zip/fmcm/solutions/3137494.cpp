#include <stdio.h>
#include <assert.h>
#include <vector>

using namespace std;

#define maxn 360
#define inf 2000000000
#define ll long long

int N, M, S, D;
int Drum, L, Sum;
vector <int> A[maxn];
int G[maxn];
int Dist[maxn], From[maxn], Pot[maxn];
int H[maxn], P[maxn];
int C[maxn][maxn], F[maxn][maxn], Cost[maxn][maxn];

void push(int x)
{
	int aux;

	while (x/2>1 && Dist[H[x]]<Dist[H[x/2]])
	{
		aux = H[x], H[x] = H[x/2], H[x/2] = aux;

		P[H[x]] = x;
		P[H[x/2]] = x/2;

		x /= 2;
	}
}

void pop(int x)
{
	int y = 0, aux;

	while (x != y)
	{
		y = x;
		if (y*2<=L && Dist[H[x]]>Dist[H[y*2]]) x = y*2;
		if (y*2+1 <= L && Dist[H[x]]>Dist[H[y*2+1]]) x = y*2+1;

		aux = H[x], H[x] = H[y], H[y] = aux;
		P[H[x]] = x;
		P[H[y]] = y;
	}
}

int BellmanFord()
{
	int i, stop = 0, j, k;

	for (i = 1; i <= N; i++) Dist[i] = inf;
	Dist[S] = 0;

	for (i = 1; i <= N && !stop; i++)
	{
		stop = 1;

		for (j = 1; j <= N; j++)
			for (k = 0; k < G[j]; k++)
				if (C[j][A[j][k]]-F[j][A[j][k]]>0 && Dist[j]+Cost[j][A[j][k]]<Dist[A[j][k]])
				{
					stop = 0;
					Dist[A[j][k]] = Dist[j] + Cost[j][A[j][k]];
				}
	}

	Sum = Dist[D];

	return stop;
}

int Dijkstra()
{
	int i, j;

	// Fac transformarea astfel incat sa am doar costuri pozitive pe arcele active (cele cu capacitate > flux)

	for (i = 1; i <= N; i++)
		for (j = 0; j < G[i]; j++) 
			if (Dist[i] != inf && Dist[A[i][j]] != inf) Cost[i][A[i][j]] += Dist[i] - Dist[A[i][j]];

	// Initializari

	for (i = 1; i <= N; i++)
	{
		Dist[i] = inf;
		H[i] = i;
		P[i] = i;
		From[i] = -1;
	}

	// Fac Dijkstra

	Dist[S] = 0;
	H[1] = S, H[S] = 1;
	P[1] = S, P[S] = 1;
	L = N;

	while (L>1 && Dist[H[1]] != inf)
	{
		for (i = 0; i < G[H[1]]; i++)
		{
			int v = A[H[1]][i];

			if (C[H[1]][v]-F[H[1]][v]>0) assert(Cost[H[1]][v]>=0); // Verific daca am arce cu cost negativ active

			if (C[H[1]][v]-F[H[1]][v]>0 && Dist[H[1]]+Cost[H[1]][v]<Dist[v])
			{
				Dist[v] = Dist[H[1]] + Cost[H[1]][v];
				From[v] = H[1];
				push(P[v]);
			}
		}

		H[1] = H[L--];
		P[H[1]] = 1;
		if (L > 1) pop(1);
	}

	// Daca am gasit drum, cresc fluxul pe el

	if (Dist[D] != inf) 
	{
		int Vmin = inf;
		Drum = 1;

		for (i = D; i != S; i = From[i]) 
			Vmin = min(Vmin, C[From[i]][i] - F[From[i]][i]);

		for (i = D; i != S; i = From[i]) 
		{
			F[From[i]][i] += Vmin;
			F[i][From[i]] -= Vmin;
		}

		Sum += Dist[D];
		return Vmin * Sum;
	}

	return 0;
}

ll Flux()
{
	ll Rez = 0;
	Drum = 1;

	// Cat timp mai exista un drum valabil, bag flux

	while (Drum)
	{
		Drum = 0;
		Rez += Dijkstra();
	}

	return Rez;
}

int main()
{
	freopen("fmcm.in", "r", stdin);
	freopen("fmcm.out", "w", stdout);

	int i, x, y, z, cap;

	// Citesc graful

	scanf("%d %d %d %d ", &N, &M, &S, &D);

	for (i = 1; i <= M; i++)
	{
		scanf("%d %d %d %d ", &x, &y, &cap, &z);

		A[x].push_back(y);
		A[y].push_back(x);

		C[x][y] = cap;
		Cost[x][y] = z;
		Cost[y][x] = -z;
	}

	for (i = 1; i <= N; i++) G[i] = A[i].size();

	// Fac primul Bellman-Ford, cand inca am costuri negative

	assert(BellmanFord());

	// Calculez fluxul maxim de cost minim

	printf("%lld\n", Flux());

	return 0;
}
