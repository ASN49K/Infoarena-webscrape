#include<fstream>
#include<vector>
#include<algorithm>
#include<queue>
#include<bitset>
#include<cstring>
using namespace std;

ifstream cin("fmcm.in");
ofstream cout("fmcm.out");

constexpr int NMAX = 5e2;
const int INF = 1e9;

struct muchie
{
    int from,to,cap,cost,flow;
};

vector<int> vecini[NMAX]; vector<muchie> muchii;
vector<int> dist,t,pi;
bitset<NMAX> inq;

void bf(int s,int e)
{
    fill(pi.begin(),pi.end(),INF); dist[s] = 0;
    queue<int> q; q.push(s); inq.reset(); inq[s] = 1;
    while(!q.empty())
        {
            int v = q.front(); q.pop(); inq[v] = 0;
            for(auto it : vecini[v])
                {
                    if((muchii[it].cap))
                        {
                            if(pi[muchii[it].to] > pi[v] + muchii[it].cost)
                                {
                                    pi[muchii[it].to] = pi[v] + muchii[it].cost; t[muchii[it].to] = it;
                                    if(!inq[muchii[it].to])
                                        {
                                            inq[muchii[it].to] = 1;
                                            q.push(muchii[it].to);
                                        }
                                }
                        }
                }
        }
}

struct miau
{
    int w; bool operator <(const miau &lhs) const
    {
        return dist[lhs.w] > dist[w];
    }
};

bool dijkstra(int s,int e)
{
    fill(dist.begin(),dist.end(),INF); dist[s] = 0; fill(t.begin(),t.end(),-1);
    priority_queue<miau> pq; pq.push({s});
    while(!pq.empty())
        {
            int v = pq.top().w; pq.pop();
            for(auto it : vecini[v])
                {
                    muchie &h = muchii[it];
                    if((h.cap - h.flow) > 0)
                        {
                            int false_cost = dist[v] + h.cost + pi[v] - pi[h.to];
                            if(false_cost < dist[h.to])
                                {
                                    dist[h.to] = false_cost;
                                    pq.push({h.to}); t[h.to] = it;
                                }
                        }
                }
        }

    return (dist[e] != INF);
}

int main()
{
    freopen("spioni.in","r",stdin);
    freopen("spioni.out","w",stdout);

    int n,m,s,e,a,b,c,d; cin >> n >> m >> s >> e;
    for(int i = 0; i < m ; i++)
        {
            cin >> a >> b >> c >> d;
            muchii.push_back({a,b,c,d,0}); vecini[a].emplace_back(2 * i);
            muchii.push_back({b,a,0,-d,0}); vecini[b].emplace_back(2 * i + 1);
        }

    long long ans = 0,flux = 0; dist.resize(n + 1); t.resize(n + 1); pi.resize(n + 1); bf(s,e);
    while(dijkstra(s,e))
        {
            int delta = INF;
            for(int v = t[e]; v != -1 ; v = t[muchii[v].from]) delta = min(delta,muchii[v].cap - muchii[v].flow);
            for(int v = t[e]; v != -1 ; v = t[muchii[v].from]) muchii[v].flow += delta,muchii[v ^ 1].flow -= delta;
            ans += 1LL * delta * (dist[e] + pi[e] - pi[s]);
            for(int i = 1; i <= n ; i++) pi[i] = dist[i];
        }


    cout << ans;
}
