#include <bits/stdc++.h>
using namespace std;
ifstream in("cc.in");
ofstream out("cc.out");
const int inf=1e9+7;
priority_queue<pair<int,int> > pq;
vector<int> vec[205];
vector<int> dir[205];
int cost[205][205];
int cap[205][205];
int last[205];
int dist[205];
int part[205];
bool inq[205];
queue<int> q;
int src,dest;
int x,y,c,z;
int n,m;
int main()
{
    in>>n;
    src=1,dest=2*n+2;
    for(int x=1,y=2;y<=n+1;++y)
        dir[x].push_back(y),
        vec[x].push_back(y),
        vec[y].push_back(x),
        cost[y][x]=0,
        cost[x][y]=0,
        cap[x][y]=1;
    for(int x=2;x<=n+1;++x)
    for(int y=n+2;y<=2*n+1;++y)
        in>>z,
        dir[x].push_back(y),
        vec[x].push_back(y),
        vec[y].push_back(x),
        cost[y][x]=-z,
        cost[x][y]=z,
        cap[x][y]=1;
    for(int x=n+2,y=2*n+2;x<=2*n+1;++x)
        dir[x].push_back(y),
        vec[x].push_back(y),
        vec[y].push_back(x),
        cost[y][x]=0,
        cost[x][y]=0,
        cap[x][y]=1;
    for(int i=1;i<=2*n+2;++i)
        inq[i]=false,
        dist[i]=inf;
    q.push(src);
    dist[src]=0;
    while(!q.empty())
    {
        int nod=q.front();
        inq[nod]=false,q.pop();
        for(int x:dir[nod])
        if(dist[x]>dist[nod]+cost[nod][x])
        {
            dist[x]=dist[nod]+cost[nod][x];
            if(!inq[x]) inq[x]=true,q.push(x);
        }
    }
    for(int i=1;i<=2*n+2;++i)
    for(int x:vec[i])
        cost[i][x]+=dist[i]-dist[x];
    int flow=0,ans=0;
    int ct=(dist[src]-dist[dest]);
    do
    {
        for(int i=1;i<=2*n+2;++i)
            part[i]=inf,
            last[i]=0;
        last[src]=-1;
        part[src]=0;
        pq.push({0,src});
        while(!pq.empty())
        {
            int c=-(pq.top()).first;
            int u=(pq.top()).second;
            pq.pop();
            if(c!=part[u])
                continue;
            for(int x:vec[u])
            if(cap[u][x]>0 and part[x]>part[u]+cost[u][x])
            {
                part[x]=part[u]+cost[u][x];
                pq.push({-part[x],x});
                last[x]=u;
            }
        }
        if(last[dest])
        {
            int minim=inf;
            for(int k=dest;last[k]>0;k=last[k])
                minim=min(minim,cap[last[k]][k]);
            flow+=minim;
            ans+=minim*(part[dest]-ct);
            for(int k=dest;last[k]>0;k=last[k])
                cap[last[k]][k]-=minim,
                cap[k][last[k]]+=minim;
        }
    }while(last[dest]);
    out<<ans<<'\n';
    return 0;
}
