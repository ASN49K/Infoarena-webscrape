#include<fstream>
#include<algorithm>
#include<vector>
#include<queue>
#define INF 2000000000
using namespace std;
ifstream f("fmcm.in");
ofstream g("fmcm.out");
vector<int>a[352];
int n,s,d,flux,sol,r[352][352],z[352][352],tata[352],dist[352];
bool inq[352];
queue<int>q;

int bellman_ford()
{
    int i,l,p;
    for(i=1;i<=n;i++)
        dist[i]=INF,tata[i]=0;
    dist[s]=0;
    q.push(s);
    inq[s]=1;
    while(!q.empty())
    {
        p=q.front();
        q.pop();
        inq[p]=0;
        l=a[p].size();
        for(i=0;i<l;i++)
        if(r[p][a[p][i]]>0&&dist[a[p][i]]>dist[p]+z[p][a[p][i]])
        {
            dist[a[p][i]]=dist[p]+z[p][a[p][i]];
            tata[a[p][i]]=p;
            if(inq[a[p][i]]==0)
            {
                q.push(a[p][i]);
                inq[a[p][i]]=1;
            }
        }
    }
    return dist[d]!=INF;
}

void fmcm()
{
    int i,flow,cost;
    while(bellman_ford())
    {
        flow=INF;
        for(i=d;i!=s;i=tata[i])
        {
            flow=min(flow,r[tata[i]][i]);
            if(flow==0)
                break;
        }
        if(flow!=0&&flow!=INF)
        {
            cost=0;
            for(i=d;i!=s;i=tata[i])
            {
                r[tata[i]][i]-=flow;
                r[i][tata[i]]+=flow;
                cost+=z[tata[i]][i];
            }
            flux+=flow;
            sol+=flow*cost;
        }
    }
}

int main()
{
    int m,i,x,y,c,zz;
    f>>n>>m>>s>>d;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>c>>zz;
        a[x].push_back(y);
        a[y].push_back(x);
        r[x][y]+=c;
        z[x][y]=zz;
        z[y][x]=-zz;
    }
    fmcm();
    g<<sol;
    return 0;
}
