#include <fstream>
#include <vector>
#include <queue>

using namespace std;
const int maxn=1001;
int n,m;
vector<int>adj[maxn];
int cap[maxn][maxn];
int tav[maxn];

int bfs(int start,int fin)
{
    for(int i=0;i<n;i++)
        tav[i]=-1;
    queue<int>q;
    q.push(start);
    tav[start]=-2;
    while(!q.empty()){
        int v=q.front();
        q.pop();
        for(auto sz : adj[v])
        {
            if(tav[sz]==-1 && cap[v][sz])
            {
                tav[sz]=v;
                q.push(sz);
            }
        }
    }
    return tav[fin];
}

int maxflow(int start,int fin)
{
    int t_flow=0;
    int new_flow;
    while(bfs(start,fin)!=-1)
    {
        for(auto v:adj[fin]){
            new_flow=cap[v][fin];
            for(int i=v;i!=0;i=tav[i])
                new_flow=min(new_flow,cap[tav[i]][i]);
            for(int i=v;i!=0;i=tav[i]){
                cap[tav[i]][i] -= new_flow;
				cap[i][tav[i]] += new_flow;
            }
            t_flow += new_flow;
			cap[v][fin] -= new_flow;
			cap[fin][v] += new_flow;
        }

    }
    return t_flow;
}


int main()
{
    ifstream be("maxflow.in");
    ofstream ki("maxflow.out");
    be>>n>>m;

    for(int i=0;i<m;i++)
    {
        int x,y,c;
        be>>x>>y>>c;
        x--;
        y--;
        adj[x].push_back(y);
        adj[y].push_back(x);
        cap[x][y]=c;

    }


    ki<<maxflow(0,n-1);

    return 0;
}
