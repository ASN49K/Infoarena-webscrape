#include <bits/stdc++.h>
#define dim 400
#define inf INT_MAX
using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

short int n,m,s,d;
short int x,y,c,z;
short int capacitate[dim][dim];
short int flux[dim][dim];
short int nod_flux[dim];
vector<pair<short int, short int>> graf[dim]; 
vector<int> cost;
vector<bool> vizitat;
int flowCurent, nodCurent;
int total = 0;
vector<pair<short int, short int>> ::iterator it;

struct cmp{
 bool operator() (const short int &a, const short int &b) const{
  return cost[a] < cost[b];
 }
};


priority_queue<short int, vector<short int>, cmp> pq;

int dijkstra(){
  cost.clear();
  cost.resize(dim, inf);
  vizitat.clear();
  vizitat.resize(dim , 0);
  pq.push(s);
  cost[s] = 0;

  while(!pq.empty()){
    int nodCurent = pq.top();
    pq.pop();
    vizitat[nodCurent] = 0;
    for(it = graf[nodCurent].begin(); it!= graf[nodCurent].end(); it++){
      if(cost[it->first] <= cost[nodCurent] + it->second)
        continue;
      if(capacitate[nodCurent][it->first] <= flux[nodCurent][it->first])
        continue;
      cost[it->first] = cost[nodCurent] + it->second;
      nod_flux[it->first] = nodCurent;
      if(vizitat[it->first] == 1)
        continue;
      vizitat[it->first] = 1;
      pq.push(it->first);
    }
  }
  if(cost[d] == inf)
    return 0;
  return 1;
}

void solve(){
  while(dijkstra()){
    flowCurent = inf;
    for(nodCurent = d; nodCurent != s; nodCurent = nod_flux[nodCurent]){
        flowCurent = min(flowCurent,capacitate[nod_flux[nodCurent]][nodCurent] - flux[nod_flux[nodCurent]][nodCurent]);
    }
    for(nodCurent = d; nodCurent != s; nodCurent = nod_flux[nodCurent]){
     flux[nod_flux[nodCurent]][nodCurent] += flowCurent;
     flux[nodCurent][nod_flux[nodCurent]] -= flowCurent;
    }
    total = total + flowCurent * cost[d];
  }
  fout<<total<<endl;
  fin.close();
  fout.close();
}

void read(){
  fin>>n>>m>>s>>d;
  for(int i=1;i<=m;i++){
    fin>>x>>y>>c>>z;
    graf[x].push_back(make_pair(y,z));
    graf[y].push_back(make_pair(x,-z));
    capacitate[x][y] = c;
  }
  solve();
}

int main() 
{
  ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  int t = 1;

  while(t--){
    read();
  }

  return 0;
}