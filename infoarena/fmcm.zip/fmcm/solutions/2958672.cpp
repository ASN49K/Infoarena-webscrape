#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;
ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

int bellman_ford(int& n, int& source, int& target, vector<vector<int>>& cost, vector<vector<int>>& capacity, vector<vector<int>>& ad_list, vector<int>& parent)
{
    vector<bool> visited(n+1, false);
    vector<int> distance(n+1, INT_MAX);
    queue<int> bf_q;

    parent[source] = 0;
    distance[source] = 0;
    bf_q.push(source);

    while(!bf_q.empty())
    {
        int curr_v = bf_q.front();
        bf_q.pop();

        visited[curr_v] = false;

        for(auto next : ad_list[curr_v])
            if(capacity[curr_v][next] > 0 && distance[curr_v] + cost[curr_v][next] < distance[next])
            {
                parent[next] = curr_v;
                distance[next] = distance[curr_v] + cost[curr_v][next];

                if(!visited[next])
                {
                    bf_q.push(next);
                    visited[next] = true;
                }
            }

    }

    return distance[target];
}

int main()
{
    int n, m, source, target;
    fin >> n >> m >> source >> target;

    vector<vector<int>>ad_list(n+1);
    vector<vector<int>>capacity(n+1, vector<int>(n+1));
    vector<vector<int>>cost(n+1, vector<int>(n+1));
    vector<int> parent(n+1);

    int fmcm = 0, min_flow = INT_MAX;

    for(int i = 0; i < m; i++)
    {
        int x, y, cap, cst;
        fin >> x >> y >> cap >> cst;

        ad_list[x].push_back(y);
        ad_list[y].push_back(x);
        capacity[x][y] = cap;
        capacity[y][x] = 0;
        cost[x][y] = cst;
        cost[y][x] = -cst;
    }

    while(true)
    {
        int cost_to_target = bellman_ford(n, source, target, cost, capacity, ad_list, parent);
        if(cost_to_target == INT_MAX)
            break;

        min_flow = INT_MAX;

        for(auto curr_v = target; curr_v != source; curr_v = parent[curr_v])
            min_flow = min(min_flow, capacity[parent[curr_v]][curr_v]);
        
        fmcm += min_flow * cost_to_target;

        for(auto curr_v = target; curr_v != source; curr_v = parent[curr_v])
        {
            capacity[parent[curr_v]][curr_v] -= min_flow;
            capacity[curr_v][parent[curr_v]] += min_flow;
        }

    }

    fout << fmcm;
    return 0;
}