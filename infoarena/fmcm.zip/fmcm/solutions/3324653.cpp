#include <bits/stdc++.h>

using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");
const int MAX = 1e9 + 7;
struct Muchie {
    int x, y, c;
};
int n, m, i, j, surs, dest, cap[352][352], flux[352][352], rasp;
int gol[352], cost[352], ant[352], costMch[352][352];
vector<Muchie> gr[352];
Muchie mch[12502];

static inline bool Dijkstra(int surs, int dest) {
    for(int i = 1; i <= n; i++) {
        cost[i] = MAX;
        ant[i] = -1;
    }
    multiset<pair<int, int>> s;


    cost[surs] = 0;

    s.insert({0, surs});

    while(!s.empty()) {
        int cc = s.begin()->first;
        int nod = s.begin()->second;
        s.erase(s.begin());

        if(cost[nod] < cc) continue;

        for(Muchie urm : gr[nod]) {
            int costNou = urm.c - gol[urm.y] + gol[nod] + cost[nod];
            if(costNou < cost[urm.y] && cap[nod][urm.y] > flux[nod][urm.y]) {
                cost[urm.y] = costNou;
                ant[urm.y] = nod;
                s.insert({cost[urm.y], urm.y});
            }
        }
    }

    if(cost[dest] == MAX) return false;
    for(int i = 1; i <= n; i++) gol[i] = cost[i] + gol[i] - gol[surs];
    return true;
}

static inline void Reverse(int surs, int dest) {
    int cur = dest;
    int ma = MAX;
    while(cur != surs) {
        ma = min(ma, cap[ant[cur]][cur] - flux[ant[cur]][cur]);
        cur = ant[cur];
    }

    cur = dest;
    while(cur != surs) {
        flux[ant[cur]][cur] += ma;
        flux[cur][ant[cur]] -= ma;
        rasp += ma * costMch[ant[cur]][cur];
        cur = ant[cur];
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin >> n >> m >> surs >> dest;
    for(i = 1; i <= n; i++) gol[i] = MAX;

    gol[surs] = 0;
    for(i = 1; i <= m; i++) {
        int x, y, ma, cost;
        fin >> x >> y >> ma >> cost;
        mch[i] = {x, y, cost};

        gr[x].push_back({x, y,  cost});
        gr[y].push_back({y, x, -cost});
        cap[x][y] += ma;

        costMch[x][y] =  cost;
        costMch[y][x] = -cost;
    }

    for(i = 1; i <= n; i++) {
        for(j = 1; j <= m; j++) {
            Muchie cur = mch[j];
            if(gol[cur.x] != MAX) {
                gol[cur.y] = min(gol[cur.y], gol[cur.x] + cur.c);
            }
        }
    }

    while(Dijkstra(surs, dest)) Reverse(surs, dest);

    fout << rasp;

    return 0;
}
