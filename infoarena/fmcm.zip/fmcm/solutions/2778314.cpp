#include <bits/stdc++.h>
//#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("fmcm.in" , "r" , stdin) , freopen("fmcm.out" , "w" , stdout)
#define ll long long
#define ull unsigned long long
#define ld long double
#define eb emplace_back
#define pb push_back
#define qwerty1 first
#define qwerty2 second
#define qwerty3 -> first
#define qwerty4 -> second
#define umap unordered_map
#define uset unordered_set
#define pii pair < int , int >
#define pq priority_queue
#define dbg(x) cerr << #x << ": " << x << '\n'

namespace FastRead
{
    char __buff[5000];int __lg = 0 , __p = 0;
    char nc()
    {
        if(__lg == __p){__lg = fread(__buff , 1 , 5000 , stdin);__p = 0;if(!__lg) return EOF;}
        return __buff[__p++];
    }
    template<class T>void read(T&__x)
    {
        T __sgn = 1; char __c;while(!isdigit(__c = nc()))if(__c == '-')__sgn = -1;
        __x = __c - '0';while(isdigit(__c = nc()))__x = __x * 10 + __c - '0';__x *= __sgn;
    }
}

using namespace FastRead;
using namespace std;

const int N = 355;
const int M = 1e9 + 7;
const ld PI = acos(-1);
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int n , m , source , sink , x , y , z , c;
int capacity[N][N] , weight[N][N] , parent[N];
int d[N] , nd[N];
vector < int > G[N];
set < pii > s;

void bellman(int source , int sink)
{
    fill(d + 1 , d + N , INT_MAX);
    s.insert({0 , source});
    d[source] = 0;
    int cnt = 0;

    while(!s.empty() && cnt <= n * m)
    {
        ++cnt;
        int u = s.begin() -> second;
        s.erase(s.begin());

        for(auto v : G[u])
        {
            if(v != source && d[v] > d[u] + weight[u][v])
            {
                d[v] = d[u] + weight[u][v];
                s.insert({d[v] , v});
            }
        }
    }
}

void djikstra(int source , int sink)
{
    fill(nd , nd + N , INT_MAX);
    nd[source] = 0;

    s.insert({0 , source});

    while(!s.empty())
    {
        int u = s.begin() -> second;
        s.erase(s.begin());

        for(auto v : G[u])
        {
            if(capacity[u][v])
            {
                if(nd[v] > nd[u] + weight[u][v] + d[u] - d[v])
                {
                    parent[v] = u;
                    nd[v] = nd[u] + weight[u][v] + d[u] - d[v];
                    s.insert({nd[v] , v});
                }
            }
        }
    }
}

int minCostmaxFlow(int source , int sink , int k)
{
    int flow = 0;
    int minCost = 0;

    while(flow < k)
    {
        djikstra(source , sink);

        if(nd[sink] == INT_MAX)
            break;

        int minFlow = k - flow;

        for(int curr = sink ; curr != source ; curr = parent[curr])
            minFlow = min(minFlow , capacity[parent[curr]][curr]);

        for(int curr = sink ; curr != source ; curr = parent[curr])
        {
            capacity[parent[curr]][curr] -= minFlow;
            capacity[curr][parent[curr]] += minFlow;
            minCost += minFlow * weight[parent[curr]][curr];
        }

        flow += minFlow;
    }

    return minCost;
}

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

    cin >> n >> m >> source >> sink;

    for(int i = 1 ; i <= m ; i++)
    {
        cin >> x >> y >> c >> z;

        capacity[x][y] = c;

        weight[x][y] = z;
        weight[y][x] = -z;

        G[x].pb(y);
        G[y].pb(x);
    }

    bellman(source, sink);

    cout << minCostmaxFlow(source , sink , INT_MAX);

    return 0;
}
