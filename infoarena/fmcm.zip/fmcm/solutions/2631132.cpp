#include<bits/stdc++.h>
#define pb push_back
#define ft first
#define maxn 355
#define sd second
#define inf 0x3f3f3f3f
using namespace std;
vector<int>v[maxn];
queue<int>q;
pair<int,int> c[maxn][maxn];
int cost[maxn],viz[maxn],tt[maxn],n,m,d,s,flux,Cost;
 
void solve(){
	while(cost[d]!=inf){
		q.push(s);
		memset(cost, inf, sizeof(cost));
		viz[s]=1;cost[s]=0;
		while(!q.empty()){
			int nod=q.front();
			q.pop();
			viz[nod]=0;
			if(nod==d)
				continue;
			for(int i=0; i<v[nod].size(); i++){
				int dest=v[nod][i];
				if(cost[nod]+c[nod][dest].sd>=cost[dest] || c[nod][dest].ft==0)
					continue;
				cost[dest]=cost[nod]+c[nod][dest].sd;
				tt[dest]=nod;
				if(viz[dest]==0)viz[dest]=1,q.push(dest);
			}
		}
		if(cost[d]!=inf){
				flux=inf;
				if(cost[tt[d]]==inf  || c[tt[d]][d].ft==0)
					continue;
				for(int wh=d; wh!=s; wh=tt[wh])
					flux=min(flux, c[tt[wh]][wh].ft);
				for(int wh=d; wh!=s; wh=tt[wh])
					c[tt[wh]][wh].ft-=flux,
					c[wh][tt[wh]].ft+=flux;
				Cost+=flux*cost[d];
			}
	}
	cout<<Cost;
}
 
 
int main(){
	freopen("fmcm.in","r",stdin);
	freopen("fmcm.out", "w", stdout);
	ios_base::sync_with_stdio(0);
	cin.tie(0);
	cin>>n>>m>>s>>d;
	int x,y,z,w;
	while(m--){
		cin>>x>>y>>w>>z;
		v[x].pb(y); v[y].pb(x);
		c[x][y].ft=w; c[x][y].sd=z; c[y][x].sd=-z;
	}
	solve();
	return 0;
}
