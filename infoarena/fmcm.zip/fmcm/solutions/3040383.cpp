#include <fstream>
#include <vector>
#include <stack>
#include <stack>
#include <queue>
#include <algorithm>
#include <map>
#include <deque>
#include <cstring>
#define Nmax 1001
using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");

int n, x, y, c, m, s, d, p;
int C[Nmax][Nmax], F[Nmax][Nmax], Dad[Nmax], Cost[Nmax], Pret[Nmax][Nmax], Vis[Nmax];
vector <int> V[Nmax];
int oo = 1 << 28;

int BFS(int vertex){
    queue <int> Q;
    Q.push(vertex);
    fill(Cost + 1, Cost + 1 + n, oo);
    memset(Vis, 0 , sizeof(Vis));
    Cost[vertex] = 0;
    Vis[s] = 1;
    bool eOk = 0;

    while(!Q.empty()){
        vertex = Q.front();
        Q.pop();
        Vis[vertex] = 0;

        for(auto new_vertex : V[vertex])
            if(C[vertex][new_vertex] != F[vertex][new_vertex] && Cost[new_vertex] > Cost[vertex] + Pret[vertex][new_vertex]){
                Cost[new_vertex] = Cost[vertex] + Pret[vertex][new_vertex];
                Dad[new_vertex] = vertex;
                
                if(Vis[new_vertex] == 0){
                    Vis[new_vertex] = 1;
                    Q.push(new_vertex);
                }

                if(new_vertex == n)
                    eOk = 1;
            }
    }
    return Cost[d];
}

int main() {
    fin >> n >> m >> s >> d;

    for(int i = 1; i <= m; ++i) {
        fin >> x >> y >> c >> p;

        V[x].push_back(y);
        V[y].push_back(x);
        C[x][y] = c;
        Pret[x][y] = p;
        Pret[y][x] = -p;
    }

    int flow = 0, ans = 0;

    while(true){
        int add = BFS(s);
        
        if(add == oo)
            break;

        int mini = oo;

        for(int vertice = d; vertice != s; vertice = Dad[vertice])
            mini = min(mini, C[Dad[vertice]][vertice] - F[Dad[vertice]][vertice]);
                
        for(int vertice = d; vertice != s; vertice = Dad[vertice]){
            F[Dad[vertice]][vertice] += mini;
            F[vertice][Dad[vertice]] -= mini;
        }
        ans += add * mini;
    }
    
    fout << ans;

    return 0;
}