#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream f ( "fmcm.in" );
ofstream g ( "fmcm.out" );

const int N = 351;
const int inf = 125000000;
vector < int > graph[N];
queue < int > q;
int C[N][N], F[N][N], d[N], tata[N], cost[N][N];
int S, D, n;
bool viz[N];

bool bfs ( int start ){
    for ( int i = 1; i <= n; i++ ){
        viz[i] = tata[i] = 0;
        d[i] = inf;
    }
    d[start] = 0;
    viz[start] = 1;
    q.push ( start );
    while ( !q.empty ( ) ){
        int node = q.front ( );
        q.pop ( );
        viz[node] = 0;
        for ( int i = 0; i < graph[node].size ( ); i++ ){
            int new_node = graph[node][i];
            if ( C[node][new_node] - F[node][new_node] > 0 ){
                if ( d[node] + cost[node][new_node] < d[new_node] ){
                    d[new_node] = d[node] + cost[node][new_node];
                    tata[new_node] = node;
                    if ( viz[new_node] == 0 ){
                        q.push ( new_node );
                        viz[new_node] = 1;
                    }
                }
            }
        }
    }
    return d[D] != inf;
}

int main()
{   int m, x, y, c, z, sol = 0, i;
    f >> n >> m >> S >> D;
    for ( i = 1; i <= m; i++ ){
        f >> x >> y >> c >> z;
        C[x][y] = c;
        cost[x][y] = z;
        cost[y][x] = -z;
        graph[x].push_back ( y );
        graph[y].push_back ( x );
    }
    while ( bfs ( S ) == 1 ){
        int node = D;
        int Min = inf;
        while ( node != S ){
            Min = min ( Min, C[tata[node]][node] - F[tata[node]][node] );
            node = tata[node];
        }
        node = D;
        while ( node != S ){
            F[tata[node]][node] += Min;
            F[node][tata[node]] -= Min;
            node = tata[node];
        }
        sol += d[D] * Min;
    }
    g << sol;
    return 0;
}
