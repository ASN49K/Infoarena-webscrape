#include <fstream>
#include <queue>
#include <vector>
using namespace std;

ifstream fin("fmcm.in");
ofstream fout("fmcm.out");
const int NMAX=400,inf=1000000000;

int n,m,s,d;
int dist[NMAX],pre[NMAX];
int flux[NMAX][NMAX],capac[NMAX][NMAX],cost[NMAX][NMAX];
int costMinim;
vector<int>lista[NMAX];
struct muchie{
    int x,y,c,z;
};
vector<muchie>muchii;
void citire()
{
    fin>>n>>m>>s>>d;
    muchii.reserve(2*m+10);
    int x,y,c,z;
    muchie cont;
    for (int i=1; i<=m; i++){
        fin>>x>>y>>c>>z;
        lista[x].push_back(y);
        lista[y].push_back(x);
        capac[x][y]=c;
        cost[x][y]=z;
        cost[y][x]=-z;
        cont.x=x;
        cont.y=y;
        cont.c=c;
        cont.z=z;
        muchii.push_back(cont);
        cont.z=-z;
        cont.x=y;
        cont.y=x;
        cont.c=0;
        muchii.push_back(cont);
    }
}
void bellmanford()
{
    bool viz[NMAX];
    for (int i=1; i<=n; i++){
        viz[i]=false;
        dist[i]=inf;
        pre[i]=-1;
    }
    dist[s]=0;
    viz[s]=true;
    queue<int>q;
    q.push(s);
    int cont;
    while (!q.empty()){
        cont=q.front();
        q.pop();
        viz[cont]=false;
        for (vector<int>::iterator it=lista[cont].begin(); it!=lista[cont].end(); it++){
            if (capac[cont][*it]-flux[cont][*it]>0 && dist[*it]>dist[cont]+cost[cont][*it]){
                dist[*it]=dist[cont]+cost[cont][*it];
                pre[*it]=cont;
                if (!viz[*it]){
                    viz[*it]=true;
                    q.push(*it);
                }
            }
        }
    }
}
void actualizareFlux()
{
    int minim=inf;
    int i=d;
    while (pre[i]!=-1){
        minim=min(minim,capac[pre[i]][i]-flux[pre[i]][i]);
        i=pre[i];
    }
    i=d;
    while (pre[i]!=-1){
        flux[pre[i]][i]+=minim;
        flux[i][pre[i]]-=minim;
        costMinim+=(minim*cost[pre[i]][i]);
        i=pre[i];
    }
}
void rezolvare()
{
    do{
        bellmanford();
        actualizareFlux();
    }while (dist[d]!=inf);
}
int main()
{
    citire();
    fin.close();
    rezolvare();
    fout<<costMinim<<'\n';
}
