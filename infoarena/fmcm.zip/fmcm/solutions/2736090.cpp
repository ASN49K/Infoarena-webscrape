#include <bits/stdc++.h>

using namespace std;
ifstream fin("fmcm.in");
ofstream fout("fmcm.out");
typedef long long ll;
int N,M,S,D,C[501][501],Cost[501][501],G[501],Drum,Dist[505],From[505],L,Q[1000010],U[505],F[505][505];
const int inf=2000000000;
vector<int> A[100005];
int BellmanFord()
{
    for(int i=1;i<=N;i++)
    {
        Dist[i]=inf;
        From[i]=-1;
    }
    Dist[S]=0;
    L=1;
    Q[L]=S;
    memset(U,0,sizeof(U));
    U[S]=1;
    for(int i=1;i<=L;i++)
    {
        for(int j=0;j<G[Q[i]];j++)
            if(C[Q[i]][A[Q[i]][j]]-F[Q[i]][A[Q[i]][j]]>0&&Dist[Q[i]]+Cost[Q[i]][A[Q[i]][j]]<Dist[A[Q[i]][j]])
            {
                From[A[Q[i]][j]]=Q[i];
                Dist[A[Q[i]][j]]=Dist[Q[i]]+Cost[Q[i]][A[Q[i]][j]];
                if(!U[A[Q[i]][j]])
                {
                    U[A[Q[i]][j]]=1;
                    Q[++L]=A[Q[i]][j];
                }
            }
        U[Q[i]]=0;
    }
    if(Dist[D]!=inf)
    {
        int Vmin=inf;
        Drum=1;
        for(int i=D;i!=S;i=From[i])
            Vmin=min(Vmin,C[From[i]][i]-F[From[i]][i]);
        for(int i=D;i!=S;i=From[i])
        {
            F[From[i]][i]+=Vmin;
            F[i][From[i]]-=Vmin;
        }
        return Vmin*Dist[D];
    }
    return 0;
}
ll Flux()
{
    ll rez=0;
    Drum=1;
    while(Drum)
    {
        Drum=0;
        rez+=BellmanFord();
    }
    return rez;
}
int main()
{
    fin>>N>>M>>S>>D;
    for(int i=1;i<=M;i++)
    {
        int x,y,z,cap;
        fin>>x>>y>>cap>>z;
        A[x].push_back(y);
        A[y].push_back(x);
        C[x][y]=cap;
        Cost[x][y]=z;
        Cost[y][x]=-z;
    }
    for(int i=1;i<=N;i++)
        G[i]=A[i].size();
    fout<<Flux();
    return 0;
}
