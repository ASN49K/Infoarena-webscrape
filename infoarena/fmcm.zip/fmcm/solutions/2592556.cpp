#include<fstream>
#include<algorithm>
#include<vector>
#include<queue>
#define INF 2000000000
using namespace std;
ifstream f("fmcm.in");
ofstream g("fmcm.out");
struct elem
{
    int x,poz;
};
vector<elem>a[352];
elem tata[352];
int n,s,d,flux,sol,r[25002],z[25002],dist[352];
bool inq[352];
queue<int>q;

inline int bellman_ford()
{
    int i,l,p;
    for(i=1;i<=n;i++)
        dist[i]=INF,tata[i]={0,0};
    dist[s]=0;
    q.push(s);
    inq[s]=1;
    while(!q.empty())
    {
        p=q.front();
        q.pop();
        inq[p]=0;
        l=a[p].size();
        for(i=0;i<l;i++)
        if(r[a[p][i].poz]>0&&dist[a[p][i].x]>dist[p]+z[a[p][i].poz])
        {
            dist[a[p][i].x]=dist[p]+z[a[p][i].poz];
            tata[a[p][i].x].x=p;
            tata[a[p][i].x].poz=a[p][i].poz;
            if(inq[a[p][i].x]==0)
            {
                q.push(a[p][i].x);
                inq[a[p][i].x]=1;
            }
        }
    }
    return dist[d]!=INF;
}

void fmcm()
{
    int i,flow,cost;
    while(bellman_ford())
    {
        flow=INF;
        for(i=d;i!=s;i=tata[i].x)
        {
            flow=min(flow,r[tata[i].poz]);
            if(flow==0)
                break;
        }
        if(flow!=0&&flow!=INF)
        {
            cost=0;
            for(i=d;i!=s;i=tata[i].x)
            {
                r[tata[i].poz]-=flow;
                r[tata[i].poz^1]+=flow;
                cost+=z[tata[i].poz];
            }
            flux+=flow;
            sol+=flow*cost;
        }
    }
}

int main()
{
    int m,i,x,y,c,zz,k=0;
    f>>n>>m>>s>>d;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>c>>zz;
        r[k]=c;
        z[k]=zz;
        a[x].push_back({y,k});
        k++;
        r[k]=0;
        z[k]=-zz;
        a[y].push_back({x,k});
        k++;
    }
    fmcm();
    g<<sol;
    return 0;
}
