﻿#include <bits/stdc++.h>

using namespace std;
using pi = pair<int, int>;

vector<int> G[351];
int cost[351][351], c[351][351], dd[351], inq[351], last[351], dp[351], dp2[351];

int main() {
	ifstream cin("fmcm.in");
	ofstream cout("fmcm.out");
	int n, m, s, t, x, y, z, w;
	cin >> n >> m >> s >> t;
	while (m--) {
		cin >> x >> y >> z >> w;
		G[x].emplace_back(y);
		G[y].emplace_back(x);
		cost[x][y] = w, cost[y][x] = -w;
		c[x][y] = z;
	}
	int flow = 0, curcost = 0;
	queue<int> Q;
	memset(dd, 0x3F, sizeof(dd));
	inq[s] = 1;
	dd[s] = 0;
	while (!Q.empty()) {
		int node = Q.front();
		Q.pop();
		inq[node] = 0;
		for (auto x : G[node])
			if (c[node][x] && dd[node] + cost[node][x] < dd[x]) {
				dd[x] = dd[node] + cost[node][x];
				if (!inq[x]) {
					inq[x] = 1;
					Q.emplace(x);
				}
			}
	}
	while (1) {
		priority_queue<pi, vector<pi>, greater<pi>> Q;
		memset(last, 0xFF, sizeof(last));
		memset(dp, 0x3F, sizeof(dp));
		memset(dp2, 0, sizeof(dp2));
		Q.emplace(0, s);
		dp[s] = 0;
		while (!Q.empty()) {
			int node, curcost;
			tie(curcost, node) = Q.top();
			Q.pop();
			if (dp[node] == curcost)
				for (auto x : G[node])
					if (c[node][x]) {
						int fakecost = cost[node][x] + dd[node] - dd[x];
						if (curcost + fakecost < dp[x]) {
							last[x] = node;
							dp[x] = curcost + fakecost;
							dp2[x] = dp2[node] + cost[node][x];
							Q.emplace(curcost + fakecost, x);
						}
					}
		}
		int curflow = INT_MAX;
		if (last[t] == -1)
			break;
		for (int i = t; i != s; i = last[i])
			curflow = min(curflow, c[last[i]][i]);
		for (int i = t; i != s; i = last[i]) {
			c[last[i]][i] -= curflow;
			c[i][last[i]] += curflow;
		}
		curcost += dp2[t] * curflow;
		flow += curflow;
	}
	cout << curcost << '\n';
}