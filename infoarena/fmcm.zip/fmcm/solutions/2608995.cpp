#include <bits/stdc++.h>

using namespace std;
int flux[1001][1001], capacitate[1001][1001], cost[1001][1001];

class cmp {
public:
    bool operator () (const pair <int, int> &A, const pair <int, int> &B) const {
        return A.second > B.second;
    }
};
priority_queue <pair <int, int>, vector <pair <int, int>>, cmp> sol;

int tata[1001];
int s, d;
int viz[1001];
int dist[1001];
int n;
vector <int> graf[1001];

int distBellman[1001];
bool maxflow (int nod)
{
    dist[nod] = 0;
    sol.push({nod, dist[nod]});
    bool verif = 0;
    while (!sol.empty())
    {
        int node = sol.top().first;
        int cst = sol.top().second;
        sol.pop();
        if (node == d) {
            verif = 1;
        }
        if (dist[node] != cst) continue;
        for (auto x:graf[node])
        {
            if (capacitate[node][x]>flux[node][x] && dist[x]>dist[node] + cost[node][x] + distBellman[node] - distBellman[x])
            {
                tata[x] = node;
                dist[x] = dist[node] + cost[node][x] + distBellman[node] - distBellman[x];
                sol.push({x, dist[x]});
            }
        }
    }
    return verif;
}

void buildDist() {
    queue <int> Q;
    Q.push(s);
    for (int i = 1; i <= n; ++i) {
        distBellman[i] = 1000000000;
    }
    distBellman[s] = 0;
    while (Q.size()) {
        int node = Q.front();
        Q.pop();
        for (auto x : graf[node]) {
            if (distBellman[x] > distBellman[node] + cost[node][x] and capacitate[node][x] > 0) {
                distBellman[x] = distBellman[node] + cost[node][x];
                Q.push(x);
            }
        }
    }
}
int main()
{
    ifstream fin ("fmcm.in");
    ofstream fout ("fmcm.out");
    int m, fluxul = 0;
    fin >> n >> m >> s >> d;
    for (int i = 1; i<=m; ++i)
    {
        int x, y, cap, cst;
        fin >> x >> y >> cap >> cst;
        graf[x].push_back(y);
        graf[y].push_back(x);
        cost[x][y] = cst;
        cost[y][x] = -cst;
        capacitate[x][y] += cap;
    }
    buildDist();
    for (int i = 1; i<=n; ++i)
        dist[i] = 1<<30;
    for (; maxflow(s);)
    {
        int minim = 1<<30;
        int copie = d;
        while (copie!=s)
        {
            if (minim > capacitate[tata[copie]][copie]-flux[tata[copie]][copie])
                minim = capacitate[tata[copie]][copie]-flux[tata[copie]][copie];
            copie = tata[copie];
        }
        if (minim == 0)
            continue;
        fluxul+=(minim*(dist[d] + distBellman[d] - distBellman[s]));
        copie = d;
        while (copie!=s)
        {
            flux[tata[copie]][copie]+=minim;
            flux[copie][tata[copie]]-=minim;
            copie = tata[copie];
        }
        memset(tata, 0, sizeof(tata));
        for (int i = 1; i<=n; ++i)
            dist[i] = 1<<30;
        memset(viz, 0, sizeof(viz));
    }
    fout << fluxul;
    return 0;
}