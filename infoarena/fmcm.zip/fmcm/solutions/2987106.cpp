#include <bits/stdc++.h>
#include <fstream>
#define cin  fin
#define  cout fout
using namespace std;
ifstream cin ("fmcm.in");
ofstream cout ("fmcm.out");
int S,D,n,a,b,c,f,ras,m,cost[1008][1008],dist1[1008],dist2[1008],disttot[1008],i,incoada[1008],cap[1008][1008],F[1008][1008],ok,tata[1008];
vector<int>G[1008];
vector<pair<int,int>>muchii;
struct compar
{
    bool operator ()(int a,int b)
    {
        return dist2[a]>dist2[b];
    }
};
priority_queue<int,vector<int>,compar>Q;
void bellmanford()
{
    for(i=1;i<=n;i++)
    {
        dist1[i]=1e9;
    }
    dist1[S]=0;
    queue<int>Q;
    Q.push(S);
    while(!Q.empty())
    {
        int nod=Q.front();
        Q.pop();
        for(auto i:G[nod])
        {
            if(cap[nod][i]>0 && dist1[i]>dist1[nod]+cost[nod][i])
            {
                dist1[i]=dist1[nod]+cost[nod][i];
                if(incoada[i]==0)
                {
                    incoada[i]=1;
                    Q.push(i);
                }
            }
        }
        incoada[nod]=0;
    }
}
int dij()
{
    for(i=1;i<=n;i++)
    {
        dist2[i]=1e9;
        disttot[i]=1e9;
        tata[i]=-1;
    }
    dist2[S]=0;
    disttot[S]=0;
    Q.push(S);
    while(!Q.empty())
    {
        int nod=Q.top();
        Q.pop();
        incoada[nod]=0;
        for(auto i:G[nod])
        {
            if(tata[nod]!=i && cap[nod][i]-F[nod][i]>0 && dist2[nod]+cost[nod][i]<=dist2[i])
            {
                tata[i]=nod;
                dist2[i]=dist2[nod]+cost[nod][i];
                disttot[i]=disttot[nod]+cost[nod][i]-dist1[nod]+dist1[i];
                if(incoada[i]==0)
                {
                    incoada[i]=1;
                    Q.push(i);
                }
            }
        }
    }
    if(dist2[D]!=1e9)
    {
        int fluxul=1e9;
        for(i=D;i!=S;i=tata[i])
        {
            fluxul=min(fluxul,cap[tata[i]][i]-F[tata[i]][i]);
        }
        for(i=D;i!=S;i=tata[i])
        {
            F[tata[i]][i]+=fluxul;
            F[i][tata[i]]-=fluxul;
        }
        ok=1;
        return fluxul*disttot[D];
    }
    return 0;
}
int flux()
{
    bellmanford();
    for(auto i:muchii)
    {
        cost[i.first][i.second]+=dist1[i.first]-dist1[i.second];
        cost[i.second][i.first]+=dist1[i.second]-dist1[i.first];
    }
    ok=1;
    while(ok==1)
    {
        ok=0;
        ras+=dij();
    }
    return ras;
}
int main()
{
    cin>>n>>m>>S>>D;
    for(i=1;i<=m;i++)
    {
        cin>>a>>b>>f>>c;
        G[a].push_back(b);
        cap[a][b]=f;
        if(cap[b][a]==0)
            G[b].push_back(a);
        cost[a][b]=c;
        cost[b][a]=-c;
        muchii.push_back({a,b});
    }
    cout<<flux();
    return 0;
}
