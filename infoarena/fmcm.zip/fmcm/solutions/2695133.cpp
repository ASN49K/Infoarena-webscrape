#include <bits/stdc++.h>
using namespace std;
ifstream fin("fmcm.in");
ofstream fout("fmcm.out");
const int INF = (1<<29);
const int NMAX = 355;
int f[NMAX][NMAX],c[NMAX][NMAX],cost[NMAX][NMAX],d[NMAX],tata[NMAX];
int S,D,n,m,x,y,z,cc,nr,dp[NMAX],new_d[NMAX];
bool ver[NMAX];
priority_queue < pair<int,int> , vector < pair<int,int> > , greater < pair<int,int> > > pq;
vector <int> v[NMAX];
int Bellman_Ford(){
    queue <int> q;
    for(int i=1;i<=n;i++){
        d[i]=INF;
        ver[i]=false;
    }
    q.push(S);
    ver[S]=true;
    d[S]=0;
    while(!q.empty()){
        int nod=q.front();
        ver[nod]=false;
        q.pop();
        for(int i=0;i<v[nod].size();i++){
            int vecin=v[nod][i];
            if(c[nod][vecin]>f[nod][vecin] and d[vecin]>d[nod]+cost[nod][vecin]){
                d[vecin]=d[nod]+cost[nod][vecin];
                if(ver[vecin]==false){
                    ver[vecin]=true;
                    q.push(vecin);
                }
            }
        }
    }
}

bool dijkstra(){
    for(int i=1;i<=n;i++)
        dp[i]=new_d[i]=INF;
    dp[S]=new_d[S]=0;
    pq.push({0,S});
    while(!pq.empty()){
        int nod=pq.top().second;
        int cst=pq.top().first;
        pq.pop();
        if(dp[nod]!=cst) continue;
        for(int i=0;i<v[nod].size();i++){
            int vecin=v[nod][i];
            if(c[nod][vecin]==f[nod][vecin]) continue;
            if(dp[nod]+d[nod]+cost[nod][vecin]-d[vecin]>=dp[vecin]) continue;
            dp[vecin]=dp[nod]+d[nod]+cost[nod][vecin]-d[vecin];
            new_d[vecin]=new_d[nod]+cost[nod][vecin];
            pq.push({dp[vecin],vecin});
            tata[vecin]=nod;
        }
    }
    for(int i=1;i<=n;i++) d[i]=new_d[i];
    if(dp[D]!=INF) return true;
    return false;
}

int main()
{
    fin >> n >> m >> S >> D;
    for(int i=1;i<=m;i++){
        fin >> x >> y >> cc >> z;
        v[x].push_back(y);
        v[y].push_back(x);
        c[x][y]=cc;
        cost[x][y]=z;
        cost[y][x]=-z;
    }
    Bellman_Ford();
    int rasp=0;
    while(dijkstra()==true){
        int minim=INF;
        for(int i=D;i!=S;i=tata[i])
            minim=min(minim,c[tata[i]][i]-f[tata[i]][i]);
        rasp+=minim*d[D];
        for(int i=D;i!=S;i=tata[i]){
            f[tata[i]][i]+=minim;
            f[i][tata[i]]-=minim;
        }
    }
    fout << rasp;
    return 0;
}
