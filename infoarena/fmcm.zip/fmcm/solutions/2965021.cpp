#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef pair<ll,ll> pll;
const ll NMAX=355,MMAX=12505;
struct edge{
    ll u, v, cap, flow, cost;
}edges[MMAX];
ll id[NMAX][NMAX];
vector<ll> edg[NMAX];
ll bellman_dist[NMAX],dist[NMAX],start,sink;
ll prv[NMAX];
int main()
{
    ifstream fin("fmcm.in");
    ofstream fout("fmcm.out");
    ll n,m;
    fin>>n>>m>>start>>sink;
    for(ll i=0;i<m;i++){
        fin>>edges[i*2].u>>edges[i*2].v>>edges[i*2].cap>>edges[i*2].cost;
        edges[i*2+1]={edges[i*2].v,edges[i*2].u,0,0,-edges[i*2].cost};
        id[edges[i*2].u][edges[i*2].v]=i*2;
        id[edges[i*2+1].u][edges[i*2+1].v]=i*2+1;
        edg[edges[i*2].u].push_back(i*2);
        edg[edges[i*2+1].u].push_back(i*2+1);
    }
    if(start==sink){
        fout<<0;
        return 0;
    }
    for(ll i=1;i<=n;i++) bellman_dist[i]=INT_MAX;
    bellman_dist[start]=0;
    for(ll iter=0;iter<n;iter++){
        for(ll it=0;it<2*m;it+=2)
            bellman_dist[edges[it].v]=min(bellman_dist[edges[it].v],bellman_dist[edges[it].u]+edges[it].cost);
    }
    for(ll it=0;it<2*m;it++){
        if(it%2==0)
            edges[it].cost+=bellman_dist[edges[it].u]-bellman_dist[edges[it].v];
        else
            edges[it].cost+=bellman_dist[edges[it].v]-bellman_dist[edges[it].u];
    }
    ll ans=0,cost=0;
    while(1){
        set<pll> s;
        for(ll i=1;i<=n;i++) dist[i]=INT_MAX,prv[i]=-1;
        dist[start]=0,prv[start]=start;
        s.insert({dist[start],start});
        while(!s.empty()){
            ll u=s.begin()->second;
            s.erase(s.begin());
            for(auto it : edg[u]){
                if(edges[it].flow<edges[it].cap && dist[u]+edges[it].cost<dist[edges[it].v]){
                    s.erase({dist[edges[it].v],edges[it].v});
                    dist[edges[it].v]=dist[u]+edges[it].cost;
                    s.insert({dist[edges[it].v],edges[it].v});
                    prv[edges[it].v]=u;
                }
            }
        }
        if(prv[sink]==-1) break;
        ll total_flow=INT_MAX,aux=sink;
        while(aux!=start){
            ll it=id[prv[aux]][aux];
            total_flow=min(total_flow,edges[it].cap-edges[it].flow);
            aux=prv[aux];
        }
        aux=sink;
        ans+=total_flow,cost+=(dist[sink]+bellman_dist[sink])*total_flow;
        while(aux!=start){
            ll it=id[prv[aux]][aux];
            edges[it].flow+=total_flow,edges[it^1].flow-=total_flow;
            aux=prv[aux];
        }
    }
    fout<<cost;
    return 0;
}
