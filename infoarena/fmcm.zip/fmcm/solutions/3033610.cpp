#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <cstring>
using namespace std;
ifstream f ("fmcm.in");
ofstream g ("fmcm.out");
struct elem
{
    int nod,cost;

    bool operator <(const elem &aux)
    const
    {
        return aux.cost<cost;
    }
};
int capacitate[351][351];
vector<elem>adiacenta[351];
priority_queue<elem>q;
int n,m,s,d,raspcost;
int dist[351];
int tati[351];
bool belman()
{
    for(int i =1; i<=n; i++)
        dist[i] = (1<<30)-1;
    q.push({s,0});
    dist[s] = 0;
    while(!q.empty())
    {
        int curent = q.top().nod;
        int cost = q.top().cost;
        q.pop();
        if(curent==d)
            continue;
        for(auto x:adiacenta[curent])
        {
            int newnod = x.nod;
            int newcost = x.cost;
            if(capacitate[curent][newnod] && dist[newnod]>cost+newcost)
            {
                dist[newnod] = cost+newcost;
                q.push({newnod,dist[newnod]});
                tati[newnod] = curent;
            }
        }
    }
    if(dist[d]!=(1<<30)-1)
        return 1;
    return 0;
}
int main()
{
    f >> n>>m >> s>>d;
    for(int i =1; i<=m; i++)
    {
        int x,y,c,cost;
        f >> x >> y >> c>> cost;
        adiacenta[x].push_back({y,cost});
        adiacenta[y].push_back({x,-cost});
        capacitate[x][y] = c;
    }
    while(belman())
    {
        for(auto x:adiacenta[d])
        {
             if(capacitate[x.nod][d]!=0 && dist[x.nod]!=0)
            {
                int flux = (1<<30)-1;
                int nod_start = d;
                while(nod_start!=s)
                {
                    flux= min(flux,capacitate[tati[nod_start]][nod_start]);
                    nod_start = tati[nod_start];
                }
                if(flux==0)
                    continue;
                nod_start = d;
                while(nod_start!=s)
                {
                    capacitate[tati[nod_start]][nod_start]-=flux;
                    capacitate[nod_start][tati[nod_start]]+=flux;
                    nod_start = tati[nod_start];
                }
                raspcost+=flux*dist[d];
            }
        }

    }
    g<<raspcost;

}

