#include <bits/stdc++.h>
using namespace std;
ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");
struct puncte
{
    double x,y;
};
puncte v[120005];
stack<puncte> S;
stack<puncte> ans;
double determinant(puncte a,puncte b,puncte c)
{
    double det=a.x*b.y+b.x*c.y+c.x*a.y;
    return det-a.y*b.x-b.y*c.x-c.y*a.x;
}
bool cmp(puncte a,puncte b)
{
    double det=determinant(v[0],a,b);
    if(det>0) return 1;
    else if(det<0) return 0;
    return a.x<b.x;
}
int main()
{
    int n;
    fin>>n>>v[0].x>>v[0].y;
    for(int i=1;i<n;i++)
    {
        fin>>v[i].x>>v[i].y;
        if(v[i].x<v[0].x || (v[i].x==v[0].x && v[i].y<v[0].y))
        {
            swap(v[0],v[i]);
        }
    }
    v[n]=v[0];
    sort(v+1,v+n,cmp);
    ans.push(v[0]);
    for(int i=1;i<=n;i++)
    {
        while(ans.size()>=2)
        {
            puncte x=ans.top();
            ans.pop();
            if(determinant(ans.top(),x,v[i])>0)
            {
                ans.push(x);
                break;
            }
        }
        ans.push(v[i]);
    }
    while(!ans.empty())
    {
        S.push(ans.top());
        ans.pop();
    }
    S.pop();
    fout<<S.size()<<'\n';
    while(!S.empty())
    {
        fout<<setprecision(8)<<fixed<<S.top().x<<' '<<S.top().y<<'\n';
        S.pop();
    }
    return 0;
}
