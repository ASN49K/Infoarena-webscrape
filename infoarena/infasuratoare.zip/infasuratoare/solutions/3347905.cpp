
#include <fstream>
#include <iomanip>
using namespace std;

ifstream cin ("infasuratoare.in");
ofstream cout ("infasuratoare.out");

struct a
{
    long double x, y;
}v[100001];

int valfinal[100001];
int main()
{
    int n;
    cin >>n;
    for (int i = 1; i <= n; i++)
    {
        cin >>v[i].x>>v[i].y;
    }
    int st = 0;
    for (int i = 1; i <= n; i++)
    {
        if (v[i].x < v[st].x)
            st = i;
    }
    int cnt = 0;
    int p = st, q;
    while (cnt < n)
    {
        valfinal[cnt] = p;
        cnt++;
        if (p == n)
        {
            q = 1;
        }
        else
        {
            q = p + 1;
        }
        for (int i = 1; i <= n; i++)
        {
            // Calculam orientarea: (y2-y1)*(x3-x2) - (x2-x1)*(y3-y2)
            long long val = (v[q].y - v[p].y) * (v[i].x - v[q].x) - (v[q].x - v[p].x) * (v[i].y - v[q].y);
            if (val < 0)
                q = i;
        }
        p = q;
        if (p == st)
        {
            break;
        }
    }
    cnt--;
    cout <<cnt - 1<<"\n";
    for (int i = cnt - 1; i >= 1; i--)
    {
        cout <<fixed<<setprecision(6)<<v[valfinal[i]].x<<" ";
        cout <<fixed<<setprecision(6)<<v[valfinal[i]].y<<"\n";
    }

    return 0;
}
