#include <bits/stdc++.h>

using namespace std;
ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");
struct punct
{
    double x,y;
}v[120010],s[120010];
bool cmp1(punct a,punct b)
{
    return ((a.y<b.y)||(a.y==b.y&&a.x<b.x));
}
bool cmp2(punct a,punct b)
{
    return ((double)(a.y-v[1].y)*(b.x-v[1].x)<(double)(b.y-v[1].y)*(a.x-v[1].x));
}
double determinant(punct a,punct b,punct c)
{
    return (a.x*b.y+b.x*c.y+c.x*a.y-a.x*c.y-b.x*a.y-c.x*b.y);
}
int n,i,k;
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>v[i].x>>v[i].y;
    sort(v+1,v+n+1,cmp1);
    k++;
    s[k].x=v[1].x;
    s[k].y=v[1].y;
    sort(v+2,v+n+1,cmp2);
    k++;
    s[k].x=v[2].x;
    s[k].y=v[2].y;
    for(i=3;i<=n;i++)
    {
        k++;
        s[k].x=v[i].x;
        s[k].y=v[i].y;
        double d=determinant(s[k-2],s[k-1],s[k]);
        while(k>2&&d<0)
        {
            k--;
            s[k].x=v[i].x;
            s[k].y=v[i].y;
            d=determinant(s[k-2],s[k-1],v[i]);
        }
    }
    fout<<k<<'\n';
    for(i=1;i<=k;i++)
        fout<<fixed<<setprecision(6)<<s[i].x<< " "<<s[i].y<<'\n';
    return 0;
}
