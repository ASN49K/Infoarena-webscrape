#include <fstream>
#include <iostream>
#include <algorithm>

struct pct
{
	bool p;
    double x, y;
};

bool abc(pct x, pct y)
{
    if(x.x < y.x) return 1;
    else if(x.x == y.x && x.y < y.y) return 1;
    return 0;
}

int main()
{
    int n, i, s1[120001], s2[120001], k1 = 0, k2 = 0;
    pct z[120001];
    std::ifstream fi("infasuratoare.in");
    std::ofstream fo("infasuratoare.out");
    fi >> n;
    for(i = 0; i < n; i++) fi >> z[i].x >> z[i].y;
    std::sort(z, z + n, abc);
	for(i = 0 ; i < n; i++)
	{
		int arie = 0;
		if(arie >= 0) z[i].p = 0;
		else z[i].p = 1;
	}
	for(i = 0 ; i < n; i++)
	{
		if(z.p == 1);
	}
}
