#include <fstream>
#include <vector>
using namespace std;
ifstream cin("permutare4.in");
ofstream cout("permutare4.out");
 unsigned long long dp [2202] [2202];
unsigned  long long sp[2202][2202];
 unsigned long long sp2[2202][2202];
 unsigned long long frv [3001];
void solve1()
{
    int n, p ;
    cin >> n >> p;

    for ( int i =1 ; i<= 2 * n + 1; i++)
        frv [i] = 0;

    for ( int j = n   ; j <= 2 * n - 1   ; j ++ )
    {
        sp [n][j] = 0 ;
        dp[ n][j] = 1;
    }
    for ( int j = 2 * n - 1 ; j >= n ; j -- )
    {
        sp [n] [j] += sp [n] [j+1] + dp[n][j];
    }
    for ( int i = n - 1 ; i >= 1; i -- )
    {
        for ( int j = i ; j <= 2 * i - 1; j ++ )
        {
            dp [i] [j] = sp[i+1][ j + 1] ;
        }

        for ( int j = 2 * i - 1; j >= i ; j -- )
            sp[i][j] = sp[i][j+1] + dp[i][j];
    }

    long long last = 0;
    for ( int i = 1 ; i <= n ; i ++ )
    {
        for ( int j = last + 1 ; j <= 2 * i - 1; j ++ )
        {
            if ( p > dp [i] [j])
                p -= dp[i][j];
            else
            {

                last = j ;
                cout << j << " ";
                frv[j] = 1;
                break ;
            }
        }
    }
    for ( int i = 1; i <= 2 * n ; i ++)
    {
        if ( frv[i] == 0 )
            cout << i << " ";
    }

    cout << '\n';


}
unsigned long long v [ 2203];
void solve2()
{
    int n ;
    cin >> n ;
    for ( int j = n   ; j <= 2 * n - 1   ; j ++ )
    {
        dp[ n][j] = 1;
        sp2[n][j]=0;
        sp[n][j] = 0 ;
    }
    for ( int j = 2 * n - 1 ; j >= n ; j -- )
    {
        sp [n] [j] += sp [n] [j+1] + 1;
    }
    for ( int i = n - 1 ; i >= 1; i -- )
    {
        for ( int j = i ; j <= 2 * i - 1; j ++ )
        {
            dp [i] [j] = sp[i+1][ j + 1] ;
        }

        for ( int j = 2 * i - 1; j >= i ; j -- )
            sp[i][j] = sp[i][j+1] + dp[i][j];

        for ( int j = i; j  <= 2 * i - 1 ; j ++ )
        {

            sp2[i][j] = dp[i][j] + sp2[i] [j-1];
        }
    }


    unsigned  long long s = 1 ;
    for ( int i = 1; i <= 2 * n ; i ++)
        cin >>v[i];
    for ( int i = 1; i < n  ; i ++ )
    {
        s += sp2 [i] [v[i] - 1 ] - sp2[i] [v[i-1] ]; ;

    }

    s += v[n] - v[ n - 1] - 1;

    cout << s << '\n';
}
int c ;
int main()
{

    while ( cin >> c )
    {
        if ( c == 1 )
        {
            solve1();
            //cout << "mata";
        }
        else
            solve2();
    }
    return 0;
}
