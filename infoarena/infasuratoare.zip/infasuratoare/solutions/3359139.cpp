#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

ifstream fin("inv.in");
ofstream fout("inv.out");

#define mod 9917
#define n_max 100000

vector<int> tree (4 * n_max + 5, 0);

void update(int nod, int st, int dr, int poz, int val){
    if(st == dr){
        tree[nod] = val;
            return;
    }

    int mij = (st + dr) / 2;

    if(poz <= mij){
        update(nod * 2, st, mij, poz, val);
    }
    else{
        update(nod * 2 + 1, mij + 1, dr, poz, val);
    }

    tree[nod] = tree[nod * 2] + tree[nod * 2 + 1];
}

int pls(int nod, int st, int dr, int int1, int int2){
    if(int1 <= st && dr <= int2){
        return tree[nod];
    }
    
    int mij = (st + dr) / 2;
    int x1 = 0, x2 = 0;

    if(int1 <= mij){
        x1 = pls(nod * 2, st, mij, int1, int2);
    }
    if(int2 > mij){
        x2 = pls(nod * 2 + 1, mij + 1, dr, int1, int2);
    }
    return x1 + x2;
}

int main(){
    int n;
    long long rez = 0;
    vector <pair<int, int>> s(n_max + 5);
    vector<int> c(n_max + 5);
    fin >> n;
    int i;
    for(i = 1; i <= n; i++){
        fin >> s[i].first;
        s[i].second = i;
    }

    sort(s.begin() + 1, s.begin() + n + 1);

    for(i = 1; i <= n; i++){
        c[s[i].second] = i;
    }

    for(i = 1; i <= n; i++){
        if(c[i] < n){
            rez = (rez + pls(1, 1, n, c[i] + 1, n)) % mod;
        }
        update(1, 1, n, c[i], 1);
    }

    fout << rez;


    fin.close();
    fout.close();
    return 0;
}