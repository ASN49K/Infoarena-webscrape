#include <fstream>
#include <algorithm>

using namespace std;

ifstream cin("infasuratoare.in");
ofstream cout("infasuratoare.out");

struct pnct{
    double x,y;
};

pnct v[120001],jos[120001],sus[120001],stiva[120001];
int a=1,b=1,cap=1;

bool cmp(pnct a,pnct b){
    if(a.x>b.x)
        return true;
    if(a.x==b.x)
        if(a.y<b.y)
            return true;
    return false;
}

double arie(pnct a,pnct b,pnct p){
    return a.x*b.y+b.x*p.y+p.x*a.y-p.x*b.y-a.x*p.y-b.x*a.y;
}

int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
        cin>>v[i].x>>v[i].y;

    //sort(v+1,v+n+1,cmp());
    /// SORTARE
    for(int i=1;i<n;i++)
        for(int j=i+1;j<=n;j++){
            if(v[i].x>v[j].x)
                swap(v[i],v[j]);
            if(v[i].x==v[j].x)
                if(v[i].y>v[j].y)
                    swap(v[i],v[j]);
        }

    ///CLASIFICARE JOS/SUS
    pnct mini=v[1],maxi=v[n];

    for(int i=2;i<n;i++){
        if(arie(mini,maxi,v[i])<0)
            jos[a++]=v[i];
        else
            sus[b++]=v[i];
    }

    for(int i=1;i<b;i++)
        cout<<sus[i].x<<' '<<sus[i].y<<'\n';
    for(int i=1;i<a;i++)
        cout<<jos[i].x<<' '<<jos[i].y<<'\n';

    ///DETERMINARE EXTREMITATI

    //jos
    stiva[1]=1;
    cap=1;
    int d=2;
    while(cap!=0){
        if(arie())
    }


    for(int i=1;i<=n;i++)
        cout<<"Punct " << i<<": x="<<v[i].x<<", y="<<v[i].y<<'\n';
    return 0;
}
