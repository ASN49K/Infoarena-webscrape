#include <bits/stdc++.h>
using namespace std;
ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");
const int NMAX = 120005;
const int EPS = 1e-12;
struct point {double x, y;} a[NMAX];
int st[NMAX];
bool vis[NMAX];

bool cmp(point A, point B)
{
    if(A.x != B.x)
        return A.x < B.x;
    return A.y < B.y;
}

double prod_vec(point A, point B, point O)
{
    return (A.x - O.x) * (B.y - O.y) - (A.y - O.y) * (B.x - O.x);
}

signed main()
{
    int n;
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> a[i].x >> a[i].y;

    sort(a + 1, a + 1 + n, cmp);
    int vf = 2;
    st[1] = 1, st[2] = 2, vis[2] = 1;
    for(int i = 1, p = 1; i >= 1; i += (p = ((i == n) ? -p : p)))
    {
        if(vis[i])
            continue;
        while(vf >= 2 && prod_vec(a[st[vf]], a[st[vf-1]], a[i]) < EPS)
            vis[st[vf--]] = 0;
        st[++vf] = i;
        vis[i] = 1;
    }
    fout << vf - 1 << "\n";
    for(int i = vf - 1; i >= 1; i--)
        fout << fixed << setprecision(6) << a[st[i]].x << " " << a[st[i]].y << "\n";

    return 0;
}
