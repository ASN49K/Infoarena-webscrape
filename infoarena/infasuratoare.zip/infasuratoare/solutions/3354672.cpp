#include <bits/stdc++.h>

using namespace std;
ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");
struct pct
{
    double x,y;
    int parte;
};
pct v[120001];
pct a,b;
bool cmp(pct a, pct b)
{
    if(a.x<b.x)
        return true;
    if(a.x>b.x)
        return false;
    if(a.y<b.y)
        return true;
    if(a.y>b.y)
        return false;
}
int st[120001];
double arie(pct a, pct b, pct c)
{
    return  a.x*b.y+b.x*c.y+c.x*a.y-b.y*c.x-c.y*a.x-a.y*b.x;
}
int n;
int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
        fin>>v[i].x>>v[i].y;
    sort(v+1,v+n+1,cmp);
    a=v[1];
    b=v[n];
    for(int i=2; i<=n-1; i++)
    {
        if(arie(a,b,v[i])<0)
        {
            v[i].parte=1;
        }
        else
        {
            v[i].parte=2;
        }
    }
    st[1]=1;
    int k=1;
    for(int i=2; i<=n; i++)
    {
        if(v[i].parte==1 || v[i].parte==0)
        {
            while(k>1 && arie(v[st[k-1]],v[st[k]],v[i])<0)
            {
                k--;
            }
            k++;
            st[k]=i;
        }
    }
    int ck=k;
    st[k]=n;
    for(int i=n-1; i>=1; i--)
    {
        if(v[i].parte==2 || v[i].parte==0)
        {
            while(k>ck && arie(v[st[k-1]],v[st[k]],v[i])<0)
                k--;
            k++;
            st[k]=i;
        }
    }
    fout<<k-1<<"\n";
    for(int i=1; i<k; i++)
        fout<<fixed<<setprecision(6)<<v[st[i]].x<<" "<<v[st[i]].y<<" "<<"\n";

    return 0;

}
