#include <fstream>
#include <algorithm>
#include <iomanip>
#include <vector>
#include <cmath>

using namespace std;
const int NMAX = 120002;

ifstream cin("infasuratoare.in");
ofstream cout("infasuratoare.out");

struct puncte {
    double x, y;
    double unghi;
}init[NMAX], med = {0, 0};

bool cmp(puncte a, puncte b) {
    return a.unghi < b.unghi;
}
vector <puncte> v;

double determ(puncte a, puncte b, puncte c) {
    return a.x * b.y + b.x * c.y + c.x * a.y -
           a.y * b.x - b.y * c.x - c.y * a.x;
}

int main()
{
    int n, m;
    cin >> n >> m;
    for(int i = 1; i <= n; i++) {
        cin >> init[i].x >> init[i].y;
        med.x += init[i].x;
        med.y += init[i].y;
    }
    med.x /= n;
    med.y /= n;
    for(int i = 1; i <= n; i++) {
        init[i].unghi = atan2(init[i].y - med.y, init[i].x - med.x);
    }
    sort(init + 1, init + n + 1, cmp);
    v.push_back(init[1]);
    v.push_back(init[2]);
    for(int i = 3; i <= n; i++) {
        while(v.size() >= 2 && determ(v[v.size() - 2], v[v.size() - 1], init[i]) < 0)
            v.pop_back();
        v.push_back(init[i]);
    }
    int ult = 0, sizee = v.size();
    while(sizee > 3) {
        if(determ(v[v.size() - 2], v[v.size() - 1], v[ult]) < 0) {
            v.pop_back();
            sizee--;
        }
        else if(determ(v[v.size() - 1], v[ult], v[ult + 1]) < 0) {
            ult++;
            sizee--;
        }
        else
            break;
    }
    v.erase(v.begin(), v.begin() + ult + 1);
    cout << sizee << '\n';
    for(int i = 0; i < v.size(); i++)
        cout << setprecision(12) << fixed << v[i].x << " " << v[i].y << '\n';
    return 0;
}
