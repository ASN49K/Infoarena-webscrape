#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <iomanip>

#define ld long double

using namespace std;
ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");

ld x[120005], y[120005];
int idx[120005];
int st[120005];

ld cross_prod(int O, int A, int B) {
    return (x[A]-x[O]) * (y[B]-y[O]) - (y[A]-y[O]) * (x[B]-x[O]);
}

bool comp(int a, int b) {
    ld cr = cross_prod(0, a, b);
    if (fabsl(cr) > 1e-12) return cr > 0;
    ld da = (x[a]-x[0])*(x[a]-x[0]) + (y[a]-y[0])*(y[a]-y[0]);
    ld db = (x[b]-x[0])*(x[b]-x[0]) + (y[b]-y[0])*(y[b]-y[0]);
    return da<db;
}

int main()
{
    int n, cnt=0;
    fin.tie(0);
    fin.sync_with_stdio(false);

    fin>>n;
    for (int i=1; i<=n; i++) 
        fin>>x[i]>>y[i];

    int pi=1;
    for (int i=2; i<=n; i++) {
        if (y[i]<y[pi] || (y[i]==y[pi] && x[i]<x[pi])) {
            pi=i;
        }
    }

    swap(x[1], x[pi]); swap(y[1], y[pi]);
    for (int i=0; i<n; i++) { 
        x[i]=x[i+1]; 
        y[i]=y[i+1]; 
    }
    for (int i=1; i<n; i++) idx[i]=i;
    sort(idx+1, idx+n, comp);

    st[0]=0; st[1]=idx[1]; cnt=2;
    for (int i=2; i<n; i++) {
        while (cnt >= 2 && cross_prod(st[cnt-2], st[cnt-1], idx[i]) <= 0) {
            cnt--;
        }
        st[cnt++]=idx[i];
    }

    fout<<cnt<<"\n";
    fout << fixed << setprecision(6);
    for (int i=0; i<cnt; i++) {
        fout<<x[st[i]]<<" "<<y[st[i]]<<"\n";
    }
    return 0;
}