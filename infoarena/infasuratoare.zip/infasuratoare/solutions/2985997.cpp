#include<iostream>
#include<deque>
#include<algorithm>
#include<vector>
#include<fstream>
#include<iomanip>
using namespace std;

ifstream in("infasuratoare.in");
ofstream out("infasuratoare.out");

struct point{
	double x,y;
};

// Used to find the lower cover.
bool compare1(const point&a, const point&b){
	return a.x<b.x || (a.x==b.x && a.y<b.y);
}

// Used to find the upper cover.
bool compare2(const point&a, const point&b){
	return a.x>b.x || (a.x==b.x && a.y>b.y);
}

/* 1    1   1
 * a.x b.x c.x
 * a.y b.y c.y
 */
double determinant(const point&a, const point&b, const point&c){
	return b.x*c.y + a.x*b.y + a.y*c.x - b.x*a.y - c.x*b.y - c.y*a.x;
}


int n;
vector<point> points;

void read(){
	in>>n;
	points.resize(n);
	for(int i=0;i<n;i++){
		in>>points[i].x>>points[i].y;
	}
}

// Find the lower/upper part of the hull.
vector<point> get_hull(){
	vector<point> hull;
	hull.push_back(points[0]);
	hull.push_back(points[1]);

	for(int i=2;i<n;i++){
		while(hull.size()>=2 && determinant(hull[hull.size()-2], hull.back(), points[i]) <=0){
			hull.pop_back();
		}
		hull.push_back(points[i]);
	}

	return hull;
}

void solve(){
	sort(points.begin(),points.end(),compare1);
	std::vector<point> lower = get_hull();
	reverse(points.begin(),points.end());
	std::vector<point> upper= get_hull();

	lower.pop_back();
	upper.pop_back();
	out<<lower.size()+upper.size()<<'\n';

	for(const point&p:lower){
		out<<fixed<<setprecision(10)<<p.x<<" "<<p.y<<'\n';
	}
	for(const point&p:upper){
		out<<fixed<<setprecision(10)<<p.x<<" "<<p.y<<'\n';
	}
}


int main(){
	read();
	solve();

	return 0;
}
