#include <fstream>
#include <iomanip>
#include<algorithm>
using namespace std;
ifstream f("infasuratoare.in");
ofstream g("infasuratoare.out");
int i,n,k,s[1001],poz;
struct punct
{
 double x,y;
 double panta;
}v[120001],o,aux;


int cmp( punct a , punct b)
{if(a.panta==b.panta) return a.x<b.x;
return a.panta<b.panta;
}


int convex()
{punct a,b,c;
double S;
a=v[s[k-1]];
b=v[s[k]];
c=v[i];
S=(a.x-c.x)*(b.y-a.y)+(a.x-b.x)*(a.y-c.y);
if(S>0) return 1;
return 0;
}



int main()
{f>>n;
o.x=o.y=100001;
for(i=1;i<=n;i++)
{f>>v[i].x>>v[i].y;
if(v[i].x<o.x||v[i].x==o.x&&v[i].y<o.y)
o=v[i],poz=i;

}
aux=v[1];
v[1]=v[poz];
v[poz]=aux;
for(i=2;i<=n;i++)
    v[i].panta=(v[i].y-o.y)/(v[i].x-o.x);
    sort(v+2,v+n+1,cmp);
s[1]=1;s[2]=2;k=2;

for(i=3;i<=n;i++)
{while(!convex()&&k>2)
k--;
s[++k]=i;

}

 g<<k<<'\n';

 for(i=2;i<=k;i++)
    g<<fixed<<setprecision(6)<<v[s[i]].x<<" "<<v[s[i]].y<<'\n';
g<<fixed<<setprecision(6)<<v[s[1]].x<<" "<<v[s[1]].y<<'\n';

    return 0;
}
