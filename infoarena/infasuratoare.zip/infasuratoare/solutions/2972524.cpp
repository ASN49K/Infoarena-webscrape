#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
#define pb push_back
#define mp make_pair
#define f first
#define s second

struct pt{
    double x, y;
};

int n;
vector<pt> a(200001);

double cross(pt a, pt b, pt c){
    return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}

void sort_points() {
    int pos = 0;
    for (int i = 1; i < n; i++)
        if(mp(a[i].x, a[i].y) < mp(a[pos].x, a[pos].y))
            pos = i;
    swap(a[0], a[pos]);
    sort(a.begin()+1, a.begin()+n, [](pt &p1, pt &p2){return cross(a[0], p1, p2) < 0;});
}

vector<pt> convex_hull(){
    vector<pt> s;
    s.pb(a[0]);
    s.pb(a[1]);
    for(int i = 2; i < n; i++){
        while(s.size() >= 2 && (cross(s[s.size()-2], s[s.size()-1], a[i]) > 0))
            s.pop_back();
        s.push_back(a[i]);
    }
    return s;
}

void solve(){
    cin >> n;
    for(int i = 0; i < n; i++)
        cin >> a[i].x >> a[i].y;
    sort_points();
    vector<pt> c1 = convex_hull();
    cout << fixed;
    cout << c1.size() << '\n';
    for(int i = 0; i < c1.size(); i++)
        cout << setprecision(9) << c1[i].x << ' ' << c1[i].y << '\n';
}  
 
int main(){
    freopen("infasuratoare.in", "r", stdin);
    freopen("infasuratoare.out", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}