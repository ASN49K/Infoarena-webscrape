///circular
//unordered_
#include <bits/stdc++.h>
#define MOD 1000000009
using namespace std;
ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");
int i,n,q[100010],vf;
long double s,det;
struct ceva
{
    long double x,y,pan;
};
ceva v[120010];
long double rot(ceva a,ceva b,ceva c)
{
    return(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
}
bool cmp(ceva a,ceva b)
{
    return (rot(v[1],a,b)<0);
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    fin>>n;
    for(i=1; i<=n; i++)
        fin>>v[i].x>>v[i].y;
    int pos=1;
    for(i=2; i<=n; i++)
        if(v[i].y<v[pos].y || (v[i].y==v[pos].y && v[i].x>v[pos].x))
            pos=i;
    swap(v[1],v[pos]);
    sort(v+2,v+1+n,cmp);
    q[++vf]=1;
    q[++vf]=2;
    for(i=3; i<=n; i++)
    {
        det=rot(v[q[vf-1]],v[q[vf]],v[i]);
        while(det>0 && vf>=2)
        {
            vf--;
            det=rot(v[q[vf-1]],v[q[vf]],v[i]);
        }
        q[++vf]=i;
    }
    fout<<vf<<'\n';
    fout<<fixed<<setprecision(12)<<v[1].x<<" "<<v[1].y<<'\n';
    for(i=vf; i>1; i--)
        fout<<fixed<<setprecision(12)<<v[q[i]].x<<" "<<v[q[i]].y<<'\n';

    return 0;
}
