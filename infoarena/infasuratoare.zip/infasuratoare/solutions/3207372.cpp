#include <fstream>
#include <vector>
#include <iomanip>
#include <algorithm>
#include <stack>
#define dd double

using namespace std;

ifstream cin("infasuratoare.in");
ofstream cout("infasuratoare.out");

struct coord{
    dd x, y;
};

int n, poz;
coord pct0 = {1e9 + 5, 1e9 + 5};
vector <coord> v;
stack <coord> stak;

dd determinant(dd x1, dd y1, dd x2, dd y2, dd x3, dd y3){
    return x1 * (y2-y3) + x2 * (y3-y1) + x3 * (y1-y2);
}

bool cmp(coord a, coord b){
    double det = determinant(pct0.x, pct0.y,a.x,a.y,b.x,b.y);
    return det > 0;
}

void solve(){
    for(int i = 0; i < n; i++)
        if(v[i].x < pct0.x or (v[i].x == pct0.x and v[i].y < pct0.y))
            pct0 = v[i], poz = i;
    swap(v[0], v[poz]);
    sort(v.begin() + 1, v.end(), cmp);
    stak.push(v[0]);
    stak.push(v[1]);
    coord a = v[0];
    for(int i = 2; i < v.size(); i++) {
        while (stak.size() >= 2 and determinant(a.x, a.y, stak.top().x, stak.top().y, v[i].x, v[i].y) < 0)
            stak.pop();
        a = stak.top();
        stak.push(v[i]);
    }
}

int main(){
    cin >> n;
    cout << fixed << setprecision(12);
    for(int i = 0; i < n; i++){
        double x, y;
        cin >> x >> y;
        v.push_back({x, y});
    }
    solve();
    cout << stak.size() << '\n';
    while(!stak.empty()) {
        cout << stak.top().x << ' ' << stak.top().y << '\n';
        stak.pop();
    }
    return 0;
}