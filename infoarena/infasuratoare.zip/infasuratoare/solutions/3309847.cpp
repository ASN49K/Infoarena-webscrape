#include <bits/stdc++.h>
using namespace std;

class Point
{
    public:
        long double x, y;
        bool operator<(const Point &other)
        {
            if(this->x == other.x)
                return this->y < other.y;
            return this->x < other.x;
        }
};

int n;
vector<Point> v;

long double cross_product(Point A, Point B, Point C)
{
    return (B.x - A.x) * (C.y - A.y) - (B.y - A.y) * (C.x - A.x);
}

bool cmp(Point A, Point B)
{
    return cross_product(v[1], A, B) < 0;
}

int main()
{
    freopen("infasuratoare.in", "r", stdin);
    freopen("infasuratoare.out", "w", stdout);
    cin.tie(nullptr)->sync_with_stdio(false);
    cin >> n;
    v.resize(n + 5);
    for(int i = 1; i <= n; i++)
    {
        cin >> v[i].x >> v[i].y;
    }
    int p = 1;
    for(int i = 2; i <= n; i++)
    {
        if(v[i] < v[p])
            p = i;
    }
    swap(v[1], v[p]);
    sort(v.begin() + 2, v.begin() + n + 1, cmp);
    vector<Point> s;
    s.push_back(v[1]);
    s.push_back(v[2]);
    for(int i = 3; i <= n; i++)
    {
        while(s.size() > 1 && cross_product(s[s.size() - 2], s[s.size() - 1], v[i]) > 0)
        {
            s.pop_back();
        }
        s.push_back(v[i]);
    }
    cout << s.size() << "\n";
    cout << fixed << setprecision(7);
    for(int i = s.size() - 1; i >= 0; i--)
    {
        cout << s[i].x << " " << s[i].y << "\n";
    }
}