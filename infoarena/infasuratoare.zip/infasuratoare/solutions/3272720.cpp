#include <fstream>
#include <algorithm>
#include <cmath>
#include <iomanip>
using namespace std;
const double eps=1.0e-12;
const int NMAX=120005;

struct POINT{
    double x,y;
};
POINT p[NMAX];
int h[NMAX];
POINT LL;

int ccw(POINT P1,POINT P2,POINT P3)
{
    double cp;
    cp=(P2.x-P1.x)*(P3.y-P2.y)-(P2.y-P1.y)*(P3.x-P2.x);
    if(fabs(cp) < eps)
        return 0;
    if(cp >= eps)
        return 1;
    return -1;
}

bool cmp(POINT P1,POINT P2)
{
    return ccw(LL,P1,P2)>0;
}

ifstream fin ("infasuratoare.in");
ofstream fout ("infasuratoare.out");

int main()
{
    int n,i,top;
    fin>>n;
    fin>>p[0].x>>p[0].y;
    for(i=1;i<n;++i)
    {
        fin>>p[i].x>>p[i].y;
        if(p[i].y-p[0].y <= -eps || (fabs(p[i].y-p[0].y)<eps && p[i].x-p[0].x <= -eps))
            swap(p[0],p[i]);
    }
    LL=p[0];
    sort(p+1,p+n,cmp);
    p[n]=LL;
    h[0]=0;
    h[1]=1;
    top=1;
    i=2;
    while(i<=n)
    {
        if(ccw(p[h[top-1]],p[h[top]],p[i]) > 0)
        {
            h[++top]=i;
            i++;
        }
        else
            top--;
    }
    fout<<top<<"\n";
    fout<<fixed<<showpoint;
    for(i=0;i<top;++i)
    {
        fout<<setprecision(6)<<p[h[i]].x<<" "<<p[h[i]].y<<"\n";
    }
    return 0;
}
