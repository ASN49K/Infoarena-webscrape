// Cu streamuri si setprecision
// 100 de puncte cu setprecision(20)

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <fstream>

using namespace std;

const int maxn = 120000;
const int INF = 1000000000;

double x[maxn], y[maxn];
int pInitial, ind[maxn], n, st[maxn], p, l;

bool cmp(int i, int j) { return (x[i] - x[pInitial]) * (y[j] - y[pInitial]) > (x[j] - x[pInitial]) * (y[i] - y[pInitial]); }

double semn(int i1, int i2, int i3) {
    return x[i1] * y[i2] + x[i2] * y[i3] + x[i3] * y[i1] - y[i1] * x[i2] - y[i2] * x[i3] - y[i3] * x[i1];
}

int main() {
    ifstream fin("infasuratoare.in");
    ofstream fout("infasuratoare.out");

    fin >> n;
    x[0] = INF;
    y[0] = INF;
    pInitial = 0;
    for (int i = 1; i <= n; i++) {
        fin >> x[i] >> y[i];
        if (y[i] < y[pInitial])
            pInitial = i;
    }
    for (int i = 1; i <= n; i++)
        if (i != pInitial)
            ind[++l] = i;
    sort(ind + 1, ind + n, cmp);
    p = 1;
    st[p] = pInitial;
    for (int i = 1; i <= n - 1; ++i) {
        while (p >= 2 and semn(st[p - 1], st[p], ind[i]) < 0)
            --p;
        st[++p] = ind[i];
    }
    fout << p << '\n';
    for (int i = 1; i <= p; ++i)
        fout << setprecision(20) << x[st[i]] << ' ' << setprecision(10) << y[st[i]] << '\n';
    return 0;
}

/*

(y[i] - y[pInitial]) / (x[i] - x[pInitial])   <   (y[j] - y[pInitial]) / (x[j] - x[pInitial])

*/
