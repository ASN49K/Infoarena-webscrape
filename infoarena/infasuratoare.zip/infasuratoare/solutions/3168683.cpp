#include <iostream>
#include <fstream>
#include <stdio.h>
#include <iomanip>
#include <algorithm>
#define NMAX 120000
#define INF 1000000000

using namespace std;

ifstream fin( "infasuratoare.in" );
ofstream fout( "infasuratoare.out" );

struct point {
    double x, y;
} v[NMAX+1], st[NMAX+1];

bool compare( point& a, point& b ) {
    if( a.x == b.x )
        return a.y < b.y;
    return a.x < b.x;
}

double unghirel( point& a, point& b, point& c ) {
    return ( b.x - a.x ) * ( c.y - a.y ) - ( b.y - a.y ) * ( c.x - a.x );
}

bool cmp( point& a, point& b ) {
    return unghirel( v[1], a, b ) < 0; // <=> ( b.x - a.x ) * ( c.y - a.y ) < ( b.y - a.y ) * ( c.x - a.x )
                                        // <=> ( c.y - a.y ) / ( c.x - a.x ) < ( b.y - a.y ) / ( b.x - a.x )
                                        // <=> mac < mab ( panta root - c < panta root - b )
}

int n, k;

void infasuratoare() {
    // gasesc cel mai din stanga punct
    int posmin = 1;
    for( int i = 2; i <= n; i++ ) {
        if( compare( v[i], v[posmin] ) )
            posmin = i;
    }
    point aux = v[posmin];
    v[posmin] = v[1];
    v[1] = aux;
    //sortez dupa unghi toate punctele mai ptn primul din stanga
    sort( v + 2, v + n + 1, cmp );
    
    k = 2;
    st[1] = v[1];
    st[2] = v[2];
    for( int i = 3; i <= n; i++ ) {
        if( k >= 2 && unghirel( st[k-1], st[k], v[i] ) > 0 ) // panta pe care as avea-o cu root si v[i] e mai mica decat cea pe care o am deja
            k--;
        k++;
        st[k] = v[i];
    }
}

int main() {
    int i;
    
    fin >> n;
    for( i = 1; i <= n; i++ )
        fin >> v[i].x >> v[i].y;
    
    infasuratoare();
    
    fout << fixed;
    fout << k << '\n';
    for( i = k; i >= 1; i-- )
        fout << setprecision(9) << st[i].x << ' ' << st[i].y << '\n';
    
    return 0;
}
