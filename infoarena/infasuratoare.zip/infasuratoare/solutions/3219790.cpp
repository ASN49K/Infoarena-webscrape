#include <bits/stdc++.h>
using namespace std;

/**
Se dau n puncte in plan. Sa se determine varfurile
care formeaza poligonul de arie minima ce contine
toate cele n puncte pe frontiera sau in interior.

Convex Hull
- Utilizam sortarea punctelor si o stiva.
*/

struct Punct
{
    long double x, y;
};

ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");
Punct a[120003];
int n, st[120003], top;
int viz[120003];
/// viz[i] = 1, daca i este deja pus in stiva
/// viz[i] = 0, daca i nu este in stiva

bool Compar(Punct A, Punct B)
{
    if (A.y == B.y)
        return A.x < B.x;
    return A.y < B.y;
}

long double f(Punct A, Punct B, Punct C)
{
    long double a, b, c;
    a = A.y - B.y;
    b = B.x - A.x;
    c = A.x * B.y - B.x * A.y;
    return a * C.x + b * C.y + c;
}

int main()
{
    int i;
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> a[i].x >> a[i].y;
    sort(a + 1, a + n + 1, Compar);
    top = 0;
    st[++top] = 1;
    st[++top] = 2;
    viz[1] = viz[2] = 1;
    for (i = 3; i <= n; i++)
    {
        while (top > 1 &&
               f(a[st[top-1]], a[st[top]], a[i]) <= 0)
        {
            viz[st[top]] = 0;
            top--;
        }
        st[++top] = i;
        viz[i] = 1;
    }
    viz[1] = 0;
    for (i = n - 1; i >= 1; i--)
        if (viz[i] == 0)
        {
            while (top > 1 &&
               f(a[st[top-1]], a[st[top]], a[i]) <= 0)
            {
                viz[st[top]] = 0;
                top--;
            }
            st[++top] = i;
            viz[i] = 1;
        }
    fout << top-1 << "\n";
    for (i = 1; i < top; i++)
    {
        fout << setprecision(12) << fixed;
        fout << a[st[i]].x << " " << a[st[i]].y << "\n";
    }
    return 0;
}
