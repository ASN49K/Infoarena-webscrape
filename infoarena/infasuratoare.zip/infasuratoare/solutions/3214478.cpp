#include <fstream>
#include <algorithm>
#include <iomanip>
using namespace std;
ifstream fin ("infasuratoare.in");
ofstream fout("infasuratoare.out");
int n,poz,k,i,j;
const int INF=5e8;
#define PAIR pair <double,double>
PAIR V[120012],st[120012];
int cadran(const PAIR &a)
{
    double x=a.first;
    double y=a.second;
    if(x>0&&y>=0)
        return 1;
    if(x>=0&&y<0)
        return 4;
    if(x<=0&&y>0)
        return 2;
    return 3;
}
double det(const PAIR &a,const PAIR &b,const PAIR &c)
{
    return (b.first-a.first)*(c.second-a.second)-(c.first-a.first)*(b.second-a.second);
}
bool cmp(const PAIR &a,const PAIR &b)
{
    //int c1=cadran(a);
    //int c2=cadran(b);
    //if(c1!=c2)
        //return c1<c2;
    double d=det({0,0},a,b);
    if(d!=0)
        return d>0;
    else
        return a.first*a.first+a.second*a.second>b.first*b.first+b.second*b.second;

}
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>V[i].first>>V[i].second;
    poz=0;
    V[0]={INF,INF};
    for(i=2;i<=n;i++)
        if(V[i]<V[poz])
            poz=i;
    V[0]=V[poz];
    V[poz]=V[1];
    V[1]=V[0];
    for(i=1;i<=n;i++)
    {
        V[i].first-=V[0].first;
        V[i].second-=V[0].second;
    }
    sort(V+2,V+n+1,cmp);
    for(j=3;j<=n;j++)
        if(det(V[1],V[2],V[j]))
            break;
    i=2;
    j--;
    while(i<j)
    {
        swap(V[i],V[j]);
        i++;
        j--;
    }
    st[1]=V[1];
    st[2]=V[2];
    k=2;
    for(i=3;i<=n;i++)
    {
        while(k>=2&&det(st[k-1],st[k],V[i])<0)
            k--;

        st[++k]=V[i];
    }
    fout<<k<<"\n";
    for(i=k;i;i--)
        fout<<setprecision(9)<<fixed<<st[i].first+V[0].first<<" "<<st[i].second+V[0].second<<"\n";
    return 0;
}
