#include <bits/stdc++.h>

using namespace std;
ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");

typedef long double ld;
struct punct
{
    long double x,y;
    bool operator<(punct &other) const
    {
        return (x<other.x||(x==other.x&&y<other.y));
    }
}v[120005];
vector <punct> st;
int n;
bool sortbycomp(punct a,punct b)
{
    return (a.x<b.x||(a.x==b.x&&a.y<b.y));
}
ld cross(punct a,punct b,punct c)
{
    return (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
}
bool sortbyangle(punct a,punct b)
{
    return cross(v[1],a,b)<0;
}
int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>v[i].x>>v[i].y;
    }
    punct minm={1e9,1e9};
    for(int i=1;i<=n;i++)
        if(minm<v[i])
        minm=v[i];
    sort(v+2,v+n+1,sortbyangle);
    st.push_back(v[1]);
    st.push_back(v[2]);
    for(int i=3;i<=n;i++)
        {
        while(st.size()>=2&&cross(st[st.size()-2],st[st.size()-1],v[i])>0)
            st.pop_back();
        st.push_back(v[i]);
        }
    fout<<st.size()<<'\n';
    reverse(st.begin(),st.end());
    for(punct i:st)
        fout<<fixed<<setprecision(15)<<i.x<<' '<<i.y<<'\n';
    return 0;
}
