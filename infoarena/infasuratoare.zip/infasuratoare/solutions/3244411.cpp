#include <fstream>
#include<algorithm>
#include<iomanip>

using namespace std;

ifstream cin("infasuratoare.in");
ofstream cout("infasuratoare.out");

struct ura
{
    double x,y;
    int parte;
}v[120001],a,b;

bool cmp(ura a, ura b)
{
    if(a.x<b.x)
        return true;
    if(a.x>b.x)
        return false;
    if(a.y<b.y)
        return true;
    if(a.y>b.y)
        return false;
}

int st[120001];

double arie(ura a, ura b, ura c)
{
    return a.x*b.y + b.x*c.y + c.x*a.y -b.y*c.x -c.y*a.x - a.y*b.x;
}

int main()
{
    int n,i;
    cin>>n;
    for(i=1;i<=n;i++)
        cin>>v[i].x>>v[i].y;
    sort(v+1,v+n+1,cmp);
    a=v[1];
    b=v[n];
    for(i=2;i<=n-1;i++)
        if(arie(a,b,v[i])<0)
            v[i].parte=1;
        else
            v[i].parte=2;
   /* for(i=1;i<=n;i++)
            cout<<v[i].x<<" "<<v[i].y<<" "<<v[i].parte<<"\n";
    */
    st[1]=1;
    int k=1;
    for(i=2;i<=n;i++)
        if(v[i].parte==1)
        {
            while(k>1 && arie(v[st[k-1]],v[st[k]],v[i])<0)
                k--;
            k++;
            st[k]=i;
        }
    k++;
    st[k]=n;
    for(i=n-1;i>1;i--)
        if(v[i].parte==2)
        {
            while(k>1 && arie(v[st[k-1]],v[st[k]],v[i])<0)
                k--;
            k++;
            st[k]=i;
        }
    cout<<k<<"\n";
    for(i=1;i<=k;i++)
        cout<<fixed<<setprecision(6)<<v[st[i]].x<<" "<<v[st[i]].y<<" "<<"\n";

    return 0;

}
