#include <fstream>
#include <algorithm>
#include <iomanip>
using namespace std;
ifstream cin("infasuratoare.in");
ofstream cout("infasuratoare.out");
struct date
{
    double x,y;
    int parte;
}v[120001];

double arie(date a, date b, date c)
{
    return a.x*b.y+b.x*c.y+c.x*a.y-b.y*c.x-c.y*a.x-a.y*b.x;
}
bool cmp(date a,date b)
{
    if(a.x<b.x)
    {
        return true;
    }
    if(a.x==b.x and a.y<b.y)
        return true;
    return false;
}
int st[120001];
int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>v[i].x>>v[i].y;
    }
    sort(v+1,v+n+1,cmp);
    for(int i=2;i<n;i++)
    {
        if(arie(v[1],v[n],v[i])<0)
            v[i].parte=1;
        else
            v[i].parte=2;
        //cout<<v[i].parte<<" "<<v[i].x<<" "<<v[i].y<<endl;
    }
    int inc=1;
    st[1]=1;
    int sf=1;
    for(int i=2;i<=n;i++)
    {
        if(v[i].parte==1 or v[i].parte==0)
        {
            while(sf>1 and arie(v[st[sf-1]],v[st[sf]],v[i])<0)
            {
                sf--;
            }
            sf++;
            st[sf]=i;
        }
    }

    int sfi=sf;
    for(int i=n-1;i>=1;i--)
    {
        if(v[i].parte==2 or v[i].parte==0)
        {
            while(sf>sfi and arie(v[st[sf-1]],v[st[sf]],v[i])<0)
            {
                sf--;
            }
            sf++;
            st[sf]=i;
        }
    }
    cout<<sf-1<<endl;
    for(int i=1;i<sf;i++)
    {
        cout<<fixed<<setprecision(6)<<v[st[i]].x<<" "<<v[st[i]].y<<"\n";
    }
    return 0;
}
