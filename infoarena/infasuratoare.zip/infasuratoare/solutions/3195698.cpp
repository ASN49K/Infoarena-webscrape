#include <bits/stdc++.h>
#define x first
#define y second
#define NMAX 320000
using namespace std;

ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");

typedef pair<double,double> Point;

Point v[NMAX+1];
Point Stack[NMAX+1];
int det(Point a,Point b,Point c)
{
    return (b.x-a.x)*(c.y-a.y) - (b.y-a.y) * (c.x-a.x);
}
int cmp(Point a,Point b)
{
    return det(v[1],a,b) < 0;
}
int main()
{
    int n;
    fin >> n;
    for(int i=1;i<=n;i++)
    {
        fin >> v[i].x >> v[i].y;
    }
    int pos=1;
    for(int i=2;i<=n;i++)
    {
       pos = v[i] < v[pos] ? i : pos;
    }
    swap(v[1],v[pos]);
    sort(v+2,v+n+1,cmp);

    Stack[1]=v[1];
    Stack[2]=v[2];
    int head=2;
    for(int i=3;i<=n;i++)
    {
        while(head >= 2 && det(Stack[head-1],Stack[head],v[i]) >= 0)
        {
            head--;
        }
        Stack[++head]=v[i];
    }
    fout << head << "\n";
    for(int i=head;i>=1;i--)
    {
        fout << setprecision(12) << fixed << Stack[i].x << " " << Stack[i].y << "\n";
    }
    return 0;

}
