#include <fstream>
#include<iomanip>
#include<algorithm>
using namespace std;
struct ura
{
    double x, y;
    bool ok;
}v[120002];
bool cmp (ura a, ura b)
{
    if (a.x<b.x)
    {
        return true;
    }
    else
    if (a.x==b.x)
    {
        if (a.y<b.y)
        {
            return true;
        }
    }
    return false;
}
bool  arie (ura a, ura b, ura c)
{
    double rez;
    rez=a.x * b.y + b.x * c.y + c.x * a.y - b.y * c.x - a.x * c.y - a.y * b.x;
    if (rez<0)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}
int st[120002];
int main()
{
    ifstream cin ("infasuratoare.in");
    ofstream cout("infasuratoare.out");
    int n, i, cnt=1;
    ura a, b;
    cin>>n;
    for (i=1;i<=n;i++)
    {
        cin>>v[i].x>>v[i].y;
    }
    sort(v+1, v+n+1, cmp);
    a=v[1];
    b=v[n];
    for (i=2;i<=n;i++)
    {
        v[i].ok=arie(a, b, v[i]);
    }
    st[cnt]=1;
    for (i=2;i<n;i++)
    {
        if (v[i].ok==0)
        {
            while (cnt>1 && arie(v[st[cnt]], v[st[cnt-1]], v[i]))
            {
                cnt--;
            }
            st[++cnt]=i;
        }
    }
    for (i=n-1;i>=1;i--)
    {
        if (v[i].ok==1)
        {
            while (cnt>1 && arie(v[st[cnt]], v[st[cnt-1]], v[i] ))
            {
                cnt--;
            }
            st[++cnt]=i;
        }
    }
    cout<<cnt<<'\n';
    for (i=1;i<=cnt;i++)
    {
        cout<<fixed<<setprecision(6)<<v[st[i]].x<<" "<<v[st[i]].y <<'\n';
    }
    return 0;
}
