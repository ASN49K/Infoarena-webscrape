#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

ifstream fin ("infasuratoare.in");
ofstream fout ("infasuratoare.out");

struct a
{
    double x,y;
    int loc;
}v[120001];

int cmp(a A , a B)
{
    return A.x < B.x;
}

int cmp2 (a A , a B)
{
    return A.loc < B.loc;
}

int main()
{
    int n;
    cin >>n;
    for (int i = 1; i <= n; i++)
    {
        cin >>v[i].x>>v[i].y;
    }
    sort (v + 1 , v + n + 1 , cmp);
    for (int i = 2; i < n; i++)
    {
        ///loc = 1 ==> sub sau loc = 2 ==> peste
        if (v[1].x * v[n].y + v[n].x * v[i].y + v[i].x * v[1].y - v[1].y * v[n].x - v[n].y * v[i].x - v[i].y * v[1].x < 0)
        {
            v[i].loc = 1;
        }
        else
        {
            v[i].loc = 2;
        }
    }
    sort (v + 1 , v + n + 1 , cmp2);
    for (int i = 1; i <= n; i++)
    {
        cout <<v[i].x<<" "<<v[i].y<<" "<<v[i].loc<<"\n";
    }
    return 0;
}
