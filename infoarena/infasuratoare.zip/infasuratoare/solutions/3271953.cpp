#include <bits/stdc++.h>
using namespace std;
ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");
const int NMAX = 120005;
const double EPS = 1e-12;
typedef pair<double, double> point;
#define x first
#define y second
point a[NMAX];
int n, stk[NMAX];
bool vis[NMAX];

double crosspd(point A, point B, point O)
{
    return (A.x - O.x) * (B.y - O.y) - (A.y - O.y) * (B.x - O.x);
}

void convex_hull()
{
    sort(a + 1, a + 1 + n);
    stk[1] = 1, stk[2] = 2, vis[2] = 1;
    int vf = 2;
    for(int i = 1, p = 1; i > 0; i += (p = (i == n) ? -p : p))
    {
        if(vis[i])
            continue;
        while(vf >= 2 && crosspd(a[stk[vf]], a[stk[vf-1]], a[i]) < EPS)
            vis[stk[vf--]] = false;
        stk[++vf] = i;
        vis[i] = true;
    }
    fout << vf - 1 << "\n";
    for(int i = 1; i < vf; i++)
        fout << fixed << setprecision(6) << a[stk[i]].x << " " << a[stk[i]].y << "\n";
}

signed main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
        fin >> a[i].x >> a[i].y;
    convex_hull();

    return 0;
}
