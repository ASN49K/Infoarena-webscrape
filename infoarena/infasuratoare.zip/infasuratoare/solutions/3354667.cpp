#include <bits/stdc++.h>

using namespace std;
struct ura {
    double x,y;
};
bool cmp(ura a , ura b){
    if(a.x<b.x)
        return true;
    if(a.x>b.x)
        return false;
    if (a.y < b.y)
        return true;
    return false;
}
ura v[120001],st[120001],v1[120001],v2[120001];
int main()
{
    int n,i;
    int idx1=0,idx2=0;
    cin >> n;
    for( i=1;i <= n; i++)
    {
        cin >> v[i].x >> v[i].y;
    }
    sort(v+1,v+n+1,cmp);
    for(i = 1; i<= n; i++)
    {
        if(v[i].x <= v[i].y){
            idx1++;
            v1[idx1].x=v[i].x;
            v1[idx1].y=v[i].y;
        }
        else{
            v2[++idx2].x=v[i].x;
            v2[idx2].y=v[i].y;
        }
    }
    int st=0;
    return 0;
}
