#include <bits/stdc++.h>
#define x first
#define y second
using namespace std;
ifstream f("infasuratoare.in");
ofstream g("infasuratoare.out");

typedef pair<double,double> point;

int n;
point a[120005];

double det(point a,point b,point c)
{
    return (a.x*b.y)+(a.y*c.x)+(b.x*c.y)-(b.y*c.x)-(a.y*b.x)-(c.y*a.x);
}
int cmp(point l,point r)
{
    return det(a[1],l,r)>0;
}
int main()
{
    f>>n;
    long long mn=1;

    for(int i=1; i<=n; i++)
    {
        f>>a[i].x>>a[i].y;
        if(a[i].x<a[mn].x || a[i].x==a[mn].x && a[i].y<a[mn].y) mn=i;

    }
    swap(a[1],a[mn]);
    sort(a+2,a+n+1,cmp);

    int l=2;
    a[n+1]=a[1];
    for(int i=3; i<=n+1; i++)
    {
        while(l>=2 && det(a[l-1],a[l],a[i])<0)
            l--;
            a[++l]=a[i];

    }
    g<<l-1<<'\n';
    for(int i=1; i<l; i++)
        g<<fixed<<setprecision(6)<<a[i].x<<' '<<a[i].y<<'\n';

return 0;
}
