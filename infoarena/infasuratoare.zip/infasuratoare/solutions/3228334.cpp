#include <bits/stdc++.h>
using namespace std;

using ll = long long;
#define int ll

#define endl '\n'
#define pb push_back
using pi = array<int, 2>;

int32_t main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  
  int n, m;
  cin >> n >> m;
  
  vector<int> l(n), r(n), len(n);
  for (int i = 0; i < n; ++i) {
    cin >> l[i] >> r[i];
    --l[i];
    --r[i];
    len[i] = r[i] - l[i] + 1;
  }
  
  vector<int> max_moved(n);
  max_moved[0] = m - len[0];
  for (int i = 1; i < n; ++i) {
    max_moved[i] = len[i - 1] - len[i];
  }

  vector<int> moved(n);
  int level = 0, total_moved = 0;
  while (level < n) {
    int impact = 0;
    for (int i = level; i < n; ++i) {
      if (total_moved >= l[i]) {
        ++impact;
      } else if (total_moved + len[level] - len[i] < l[i]) {
        --impact;
      }
    }
    
    if (impact < 0 && moved[level] < max_moved[level]) {
      ++moved[level];
      ++total_moved;
    } else {
      ++level;
    }
  }
  
  ll ans = 0;
  int pos = 0;
  for (int i = 0; i < n; ++i) {
    pos += moved[i];
    ans += abs(pos - l[i]);
  }
  cout << ans;
}
