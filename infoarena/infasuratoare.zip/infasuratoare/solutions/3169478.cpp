#include <cstdio>
#include <algorithm>
#include <fstream>
#include <iomanip>

using namespace std;

#define x first
#define y second

typedef pair<double, double> point;

ifstream fin( "infasuratoare.in" );
ofstream fout( "infasuratoare.out" );

#define MAX_N 120001

int n;
point v[MAX_N];

point st[MAX_N];
int k;

double unghirel( point& A, point& B, point& C ) {
    return ( B.x - A.x ) * ( C.y - A.y ) - ( B.y - A.y ) * ( C.x - A.x );
}

int cmp( point& p1, point& p2 ) {
    return unghirel( v[1], p1, p2 ) < 0;
}

void sort_points() {
    int posmin = 1;
    for( int i = 2; i <= n; ++i )
        if( v[i] < v[posmin] )
            posmin = i;
    swap( v[1], v[posmin] );
    sort( v + 2, v + n + 1, cmp );
}

void convex_hull() {
    sort_points();

    st[1] = v[1];
    st[2] = v[2];
    k = 2;
    for( int i = 3; i <= n; ++i ) {
        while( k >= 2 && unghirel( st[k - 1], st[k], v[i] ) > 0 )
            k--;
        st[++k] = v[i];
    }
}

void write() {
    fout << fixed;
    fout << k << "\n";
    for (int i = k; i >= 1; --i)
        fout << setprecision(9) << st[i].x << " " << st[i].y << "\n";
}

int main() {
    fin >> n;
    for( int i = 1; i <= n; i++ )
        fin >> v[i].x >> v[i].y;
    convex_hull();
    write();
}
