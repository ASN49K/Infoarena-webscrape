#include <bits/stdc++.h>


using namespace std;


ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");

struct punct
{
    double x, y;
};

int n;
vector<punct> a;

void citire_punct(punct &a)
{
    fin >> a.x >> a.y;
}

void afis_punct(punct a)
{
    fout << a.x << " " << a.y;
}
bool cmp(punct a, punct b)
{
    if (a.x != b.x) return a.x < b.x;
    return a.y < b.y;
}

double determinant(punct a, punct b, punct c)
{
    return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}

int main()
{   
    fin >> n;

    for(int i = 1; i <= n; i++)
    {
        punct x;
        citire_punct(x);

        a.push_back(x);
    }

    sort(a.begin(), a.end(), cmp);

    vector<punct> stack(n + 2);
    int top = 0;

    stack[top++] = a[0];
    stack[top++] = a[1];
    
    for(int i = 2; i < n; i++)
    {
        while(top >= 2 and determinant(stack[top - 2], stack[top - 1], a[i]) <= 0)
        {
            top--;
        }
        stack[top++] = a[i];
    }
    // for(int i = 0; i < top; i++)
    // {
    //     afis_punct(stack[i]);
    //     cout << "\n";
    // }
    // cout << "\n";
    
    int t = top;
    for(int i = n - 2; i >= 0; i--)
    {
        while(top >= t and determinant(stack[top - 2], stack[top - 1], a[i]) <= 0)
            top--;
            
        stack[top++] = a[i];
    }

    fout << top << "\n";

    for(int i = 0; i < top - 1; i++)
    {
        afis_punct(stack[i]);
        fout << "\n";
    }
    return 0;
}