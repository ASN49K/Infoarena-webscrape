#include <bits/stdc++.h>
#define x first
#define y second
using namespace std;

ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");

typedef pair<double, double > punct;

vector<punct> v(10000);

double det(punct a, punct b, punct c) {
    return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}


bool cmp1(punct a, punct b) {
    if (a.x == b.x) {
        return a.y < b.y;
    }
    else {
        return a.x < b.x;
    }
}

bool cmp2(punct a, punct b) {
    return det(v[1], a, b) < 0;
}


int main()
{
    int n;
    fin >> n;

    for (int i = 1; i <= n; i++) {
        fin >> v[i].x >> v[i].y;
    }

   // sort(v.begin() + 1, v.begin() + 1 + n, cmp1);
    int pos = 1;
    for (int i = 2; i <= n; i++) {
        if (v[i] < v[pos]) {
            pos = i;
        }
    }
    swap(v[1], v[pos]);

    sort(v.begin() + 2, v.begin() + 1 + n, cmp2);


    vector<punct> S(10000);
    S[1] = v[1];
    S[2] = v[2];

    int head = 2;
    for (int i = 3; i <= n; i++) {
        while (head >= 2 && det(S[head - 1], S[head], v[i]) > 0) {
            head--;
        }
        S[++head] = v[i];

    }
    fout << head<<'\n';
    for (int i = head; i >=1; i--) {
        fout <<fixed<< setprecision(6)<< S[i].x<<' '<<S[i].y << '\n';
    }

    return 0;
}