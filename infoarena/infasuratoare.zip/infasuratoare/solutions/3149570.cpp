#include <iostream>
#include <fstream>
#include <algorithm>
#include <iomanip>

using namespace std;

ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");

struct punct {
    double x, y;
} v[120001], s[120001];

int n, vf;

double produs_vectorial(punct A, punct B, punct C) {
    return (B.x - A.x) * (C.y - A.y) - (B.y - A.y) * (C.x - A.x);
}

bool cmp(punct p1, punct p2) {
    return produs_vectorial(v[1], p1, p2) < 0;
}

int main() {
    fin >> n;
    for (int i = 1; i <= n; i++)
        fin >> v[i].x >> v[i].y;

    int pos = 1;
    for (int i = 2; i <= n; i++)
        if (v[i].x < v[pos].x)
            pos = i;
    swap(v[1], v[pos]);
    sort(v + 2, v + n + 1, cmp);

    s[1] = v[1];
    s[2] = v[2];
    vf = 2;
    for (int i = 3; i <= n; i++) {
        while (vf >= 2 && produs_vectorial(s[vf - 1], s[vf], v[i]) > 0)
            --vf;
        s[++vf] = v[i];
    }

    fout << fixed << vf << "\n";
    for (int i = vf; i >= 1; i--)
        fout << setprecision(9) << s[i].x << " " << s[i].y << "\n";
}
