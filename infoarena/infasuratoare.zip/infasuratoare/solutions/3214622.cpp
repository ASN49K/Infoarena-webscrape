#include <bits/stdc++.h>

using namespace std;

ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");

struct vrajeala
{
    double x, y;
    bool operator < (const vrajeala A) const
    {
        if (y == A.y)
            return x < A.x;
        return y < A.y;
    }
}a[120005];
int n, st[120005], top;
bitset <120005> viz;

int F(vrajeala A, vrajeala B, vrajeala C)
{
    return (A.y - B.y) * C.x + (B.x - A.x) * C.y
        + A.x * B.y - A.y * B.x;
}

int main()
{
    int i;
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> a[i].x >> a[i].y;
    sort(a + 1,a + n + 1);

    st[++top] = 1;
    st[++top] = 2;
    viz[2] = 1;
    for (i = 3; i <= n; i++)
    {
        while (top >= 2 and F(a[st[top - 1]], a[st[top]], a[i]) <= 0)
        {
            viz[st[top]] = 0;
            top--;
        }
        st[++top] = i;
        viz[i] = 1;
    }

    for (i = n; i >= 1; i--)
        if (viz[i] == 0)
        {
            while (top >= 2 and F(a[st[top - 1]], a[st[top]], a[i]) <= 0)
                top--;
            st[++top] = i;
        }

    fout << top - 1 << "\n";
    for (i = 1; i < top; i++)
        fout << setprecision(12) << fixed << a[st[i]].x << " " << a[st[i]].y << "\n";

    return 0;
}
