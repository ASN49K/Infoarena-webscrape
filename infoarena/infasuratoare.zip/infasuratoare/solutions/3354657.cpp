#include <iostream>
#define MOD 1000000007
using namespace std;
int ridic(int baza, int exp)
{
    int rez=1;
    while(exp!=0)
    {
        if(exp%2==0)
        {
            exp/=2;
            baza=1LL*baza*baza%MOD;
        }
        else
        {
            exp--;
            rez=1LL*rez*baza%MOD;
        }
    }
    return rez;
}
int fact[1000001];
int main()
{
    int p,n,q,i,rez,rezf;
    cin>>n>>p>>q;
    fact[0]=1;
    fact[1]=1;
    for(i=2;i<=n;i++)
        fact[i]=1LL*fact[i-1]*i%MOD;
    rezf=0;
    for(i=p;i<=q;i++)
    {
        rez=fact[n];
        rez=1LL*rez*ridic(fact[i],MOD-2)%MOD;
        rez=1LL*rez*ridic(fact[n-i],MOD-2)%MOD;
        rezf=(1LL*rezf+rez)%MOD;
    }
    cout<<rezf;
    return 0;
}
