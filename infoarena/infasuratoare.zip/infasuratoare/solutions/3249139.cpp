#include <iostream>
#include <fstream>
#include <algorithm>
#include <iomanip>
using namespace std;

ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");

struct pct{
    double x,y;
    int semiplan;
}v[120001],pct1,pctn;

int n,stiva[120001];

int compara(pct a, pct b){
    if(a.x<b.x)
        return 1;
    if(a.x>b.x)
        return 0;
    if(a.y<b.y)
        return 1;
    if(a.y>b.y)
        return 0;
    return 0;
}

double arie(pct a, pct b, pct c){
    return  a.x*b.y+b.x*c.y+c.x*a.y-b.y*c.x-c.y*a.x-a.y*b.x;
}

int main(){
    fin>>n;
    for(int i=1;i<=n;i++)
        fin>>v[i].x>>v[i].y;
    sort(v+1,v+n+1,compara);
    pct1=v[1];
    pctn=v[n];
    for(int i=2;i<=n-1;i++)
        if(arie(pct1,pctn,v[i])<0)
            v[i].semiplan=1;
        else
            v[i].semiplan=2;
    stiva[1]=1;
    int k=1;
    for(int i=2;i<=n;i++)
        if(v[i].semiplan==1||v[i].semiplan==0){
            while(k>1&&arie(v[stiva[k-1]],v[stiva[k]],v[i])<0)
                k--;
            stiva[++k]=i;
        }

    int ck=k;
    stiva[k]=n;
    for(int i=n-1;i>=1;i--)
        if(v[i].semiplan==2||v[i].semiplan==0){
            while(k>ck&&arie(v[stiva[k-1]],v[stiva[k]],v[i])<0)
                k--;
            stiva[++k]=i;
        }
    fout<<k-1<<endl;
    for(int i=1;i<k;i++)
        fout<<fixed<<setprecision(6)<<v[stiva[i]].x<<" "<<v[stiva[i]].y<<" "<<endl;
    return 0;

}
