#include <cstdio>
#include <algorithm>
#include <fstream>
#include <iomanip>

using namespace std;

#define x first
#define y second

typedef pair<double, double> point;

ifstream fin( "infasuratoare.in" );
ofstream fout( "infasuratoare.out" );

#define MAX_N 120001

int n;
point v[MAX_N];

point st[MAX_N];
int k;

double unghirel( point& a, point& b, point& c ) {
    return ( b.x - a.x ) * ( c.y - a.y ) - ( b.y - a.y ) * ( c.x - a.x ); // <=> ( b.x - a.x ) * ( c.y - a.y ) < ( b.y - a.y ) * ( c.x - a.x )
    // <=> ( c.y - a.y ) / ( c.x - a.x ) < ( b.y - a.y ) / ( b.x - a.x )
    // <=> mac < mab ( panta root - c < panta root - b )
}

int cmp( point& p1, point& p2 ) {
    return unghirel( v[1], p1, p2 ) < 0;
}

void infasuratoare() {
    // gasesc cel mai din stanga punct
    int posmin = 1;
    for( int i = 2; i <= n; ++i )
        if( v[i] < v[posmin] )
            posmin = i;
    swap( v[1], v[posmin] );
    //sortez dupa unghi toate punctele mai ptn primul din stanga
    sort( v + 2, v + n + 1, cmp );

    st[1] = v[1];
    st[2] = v[2];
    k = 2;
    for( int i = 3; i <= n; i++ ) {
        while( k >= 2 && unghirel( st[k - 1], st[k], v[i] ) > 0 ) // panta pe care as avea-o cu root si v[i] e mai mica decat cea pe care o am deja
            k--;
        k++;
        st[k] = v[i];
    }
}

int main() {
    fin >> n;
    for( int i = 1; i <= n; i++ )
        fin >> v[i].x >> v[i].y;
    
    infasuratoare();
    
    fout << fixed;
    fout << k << "\n";
    for (int i = k; i >= 1; --i)
        fout << setprecision(9) << st[i].x << " " << st[i].y << "\n";
}
