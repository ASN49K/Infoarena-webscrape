#define NMAX 120005
#include <iostream>
#include <algorithm>
#include <vector>
#include <fstream>
#include <iomanip>
#include <cassert>

using namespace std;

ifstream f("infasuratoare.in");
ofstream g("infasuratoare.out");

enum Orientation {
	COLLINEAR,
	CLOCKWISE,
	COUNTER_CLOCKWISE
};

struct Point {
	double x, y;

	Point(): x(0), y(0) {}
	Point(double xobj, double yobj) {
		x = xobj;
		y = yobj;
	}
}P[NMAX];

int n;
vector<Point> v1, v2;


Orientation getOrientation(Point P1, Point P2, Point P3)
{
	double det = (P2.x - P1.x) * (P3.y - P1.y) - (P2.y - P1.y) * (P3.x - P1.x);
	if (det > 0)
		return COUNTER_CLOCKWISE;
	if (det < 0)
		return CLOCKWISE;
	return COLLINEAR;
}

bool cmp(Point A, Point B)
{
	if (A.x < B.x || A.x == B.x && A.y < B.y)
		return 1;
	return 0;
}



void read()
{
	f >> n;
	for (int i = 0; i < n; ++i)
		f >> P[i].x >> P[i].y;
	sort(P, P + n, cmp);/*
	for (int i = 0; i < n; ++i)
		cout << P[i].x << " " << P[i].y<<'\n';*/

}


void solve_halfs()
{
	v1.push_back(P[0]);
	for (int i = 1; i < n; ++i)
	{
		while (v1.size() > 1 && getOrientation(v1[v1.size() - 2], v1[v1.size() - 1], P[i]) == CLOCKWISE)
			v1.pop_back();
		v1.push_back(P[i]);
	}
	v2.push_back(P[n-1]);
	for (int i = n - 2; i >= 0; --i)
	{
		while (v2.size() > 1 && getOrientation(v2[v2.size() - 2], v2[v2.size() - 1], P[i]) == CLOCKWISE)
			v2.pop_back();
		v2.push_back(P[i]);
	}

}

void write()
{
	g << v1.size() + v2.size() - 2 << '\n';
	for (auto& v : v1)
		g << fixed << setprecision(6) << v.x << " " << v.y << "\n";
	v2.erase(v2.begin());
	for (auto& v : v2)
		g << fixed << setprecision(6) << v.x << " " << v.y << "\n";
}


void solve_graham() {
	int idx_llp = 0;
	f >> n;
	for (int i = 0; i < n; ++i)
	{
		f >> P[i].x >> P[i].y;
		if (P[i].x < P[idx_llp].x || P[i].x == P[idx_llp].x && P[i].y < P[idx_llp].y)
			idx_llp = i;
	}
	swap(P[idx_llp], P[0]);

	sort(P+1, P + n, [](const Point& a, const Point& b) {
		return getOrientation(P[0], a, b) == CLOCKWISE; // keep in order;
	});
	

	vector<Point> pts;
	pts.push_back(P[0]);
	pts.push_back(P[1]);
	for (int i = 2; i < n; ++i)
	{
		while (pts.size() > 1 && getOrientation(pts[pts.size() - 2], pts[pts.size() - 1], P[i]) == COUNTER_CLOCKWISE)
			pts.pop_back();
		pts.push_back(P[i]);
	}

	g << pts.size() << '\n';
	for (auto& pt : pts)
		g << fixed << setprecision(6) << pt.x << " " << pt.y << '\n';

}


int main()
{
	read();
	//solve_halfs();
	solve_graham();
	//write();
	
	return 0;
}