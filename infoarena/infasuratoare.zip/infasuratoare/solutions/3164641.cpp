#include <bits/stdc++.h>
#define eps 1e-12
using namespace std;
ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");
struct point{
    double x,y;
};
point p[120005];
double det(const point &p1, const point &p2, const point &p3){
    return (p2.x - p1.x) * (p3.y - p1.y) - (p3.x - p1.x) * (p2.y - p1.y);
}
void citire(point &P){
    fin >> P.x >> P.y;
}
void print(const point &P){
    fout << fixed << setprecision(6);
    fout << P.x << " " << P.y << "\n";
}

bool comp(const point &p1, const point &p2){
    return det(p[1],p1,p2) > 0;
}
point st[120005];
int n;
void graham_scan(){
    int i,s = 0;
    st[++s] = p[1];
    st[++s] = p[2];
    for(i = 3; i <= n; i++){
        while(s >= 2 && det(st[s - 1],st[s],p[i]) < 0) s--;
        st[++s] = p[i];
    }
    fout << s << "\n";
    for(i = s; i >= 1; i--) print(st[i]);
}
int main()
{
    int i,poz;
    fin >> n;
    citire(p[1]);
    poz = 1;
    for(i = 2; i <= n; i++){
        citire(p[i]);
        if(p[poz].y > p[i].y) poz = i;
        else if(p[poz].y == p[i].y && p[i].x > p[poz].x) poz = i;
    }
    swap(p[poz], p[1]);
    sort(p + 2, p + n + 1, comp);
    graham_scan();
    return 0;
}
