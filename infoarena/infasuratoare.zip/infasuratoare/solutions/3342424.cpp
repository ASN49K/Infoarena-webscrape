#include <bits/stdc++.h>
using namespace std;

ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");
struct Punct
{
    double x, y;
    bool operator< (const Punct A) const
    {
        if (y == A.y) return x < A.x;
        return y < A.y;
    }
};
Punct a[120001];
int n, viz[120001];
int st[120001], top;
/// ret. -1 daca C se afla in semiplanul - fata de dr. (AB)
/// ret. 1 daca C este in semiplanul +
int F(Punct A, Punct B, Punct C)
{
    if ((A.y-B.y)*C.x+(B.x-A.x)*C.y+A.x*B.y-B.x*A.y <= 0)
        return -1;
    return 1;
}

int main()
{
    int i, j;
    fin >> n;
    for (i = 1; i <= n; i++)
        fin >> a[i].x >> a[i].y;
    sort(a + 1, a + n + 1);
    st[1] = 1;
    st[2] = 2;
    viz[2] = 1;
    top = 2;
    for (i = 3; i <= n; i++)
    {
        /// scot din stiva cat timp top>=2 si
        /// punctul a[i] este in semiplanul - fata
        /// de dreapta a[st[top-1]], a[st[top]]
        while (top >= 2 && F(a[st[top-1]], a[st[top]], a[i]) < 0)
        {
            viz[st[top]] = 0;
            top--;
        }
        st[++top] = i;
        viz[i] = 1;
    }
    for (i = n - 1; i >= 1; i--)
        if (viz[i] == 0)
        {
            while (top >= 2 && F(a[st[top-1]], a[st[top]], a[i]) < 0)
            {
                viz[st[top]] = 0;
                top--;
            }
            st[++top] = i;
            viz[i] = 1;
        }
    fout << top - 1 << "\n";
    fout << setprecision(12) << fixed;
    for (i = 1; i < top; i++)
    {
        j = st[i];
        fout << a[j].x << " " << a[j].y << "\n";
    }
    return 0;
}
