#include<fstream>
#include<algorithm>
#include<iostream>
#include<vector>
#include<iomanip>
#include<stack>
#define inf 1e3+1
using namespace std;
ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");
struct punct {
    double x, y;
    punct() :x(0), y(0) {};
    punct(int i, int j) :x(i), y(j) {};
};
//produs determinanti:
// x1 y1 1
// x2 y2 1
// x3 y3 1
//arie => x3*y2+ x2*y1+ x1*y3
//      - x3*y1+ x2*y3 + x1*y2
//      =>x3(y2-y1)+x2(y1-y3)+ x1(y3-y2)
double calcArieTriunghi(punct a, punct b, punct c) {
    return (c.x * (b.y - a.y) + b.x * (a.y - c.y) + a.x * (c.y - b.y)) / 2;
}

punct start= punct(inf,inf);//in functie de punctul asta vom sorta toate punctele
//trebuie ca punctul asta sa apartina infasuratorii ,deci il luam cel mai din stanga (apoi cel mai de jos)  punct

double calcPanta(punct& p1, punct& p2) {
    return (p1.y - p2.y) / (p1.x - p2.x);
}

bool cmp(punct a, punct b) {
    return calcPanta(a, start) < calcPanta(b, start);//sortam in functie de panta formata din punctul crt si (0,0)
}


vector<punct> convexHull(vector<punct>& v,int sens) {
    sort(v.begin(), v.end(), cmp);//sortam in functie de panta formata cu punctul de incepur
    vector<punct>s;//un stack cu punctele de pe infasuratoarea convexa
    s.push_back(start);
    s.push_back(v[0]);
    int stackSize = 2;
    for (int i = 1; i < v.size(); ++i) {
        while (stackSize >=2 && ((sens==1 && calcArieTriunghi(s[stackSize-2],s[stackSize-1],v[i])>=0)||(sens == -1 && calcArieTriunghi(s[stackSize - 2], s[stackSize - 1], v[i])<=0)))
        {
            s.pop_back();
            stackSize--;
        }
        s.push_back(v[i]);
        stackSize++;
    }
    return s;
}


int main() {
   int n;
    fin >> n;
    vector<punct>v(n);
     start.x = inf;
    start.y = inf;
    int pozFound = 0;
    for (int i = 0; i < n; ++i) {
          fin >> v[i].x >> v[i].y;
        if (start.x > v[i].x || (v[i].x == start.x && start.y > v[i].y)) {
            pozFound = i;
            start.x = v[i].x;
            start.y = v[i].y;
        }
    }
    v.erase(v.begin()+pozFound);//ca sa stergem inceputul
    vector<punct>upperHalf;
    vector<punct>lowerHalf;
    upperHalf = convexHull(v, 1);
    lowerHalf = convexHull(v, -1);
    fout << upperHalf.size() + lowerHalf.size() - 2<< "\n";
    for (auto i : upperHalf) {
        fout << fixed << setprecision(14) << i.x << " " << i.y << "\n";
    }
    for (int i = lowerHalf.size() - 2; i >= 1; --i) {
        fout << fixed << setprecision(14) << lowerHalf[i].x << " " << lowerHalf[i].y << "\n";
    }
    return 0;
}