#include <bits/stdc++.h>

using namespace std;
ifstream fin("infasuratoareconvexa.in");
ofstream fout("infasuratoareconvexa.out");
const int lim=14e4;
int i,n,st;
struct point
{
    double x,y;
}v[lim],ans[lim];
bool comp1(point a,point b)
{
    return (a.y<b.y)||(a.y==b.y&&a.x<b.x);
}
bool comp2(point a,point b)
{
    return (ans[1].y-a.y)*(ans[1].x-b.x)<(ans[1].x-a.x)*(ans[1].y-b.y);
}
double determinant(point a,point b,point c)
{
    return (a.x*b.y+b.x*c.y+c.x*a.y-a.x*c.y-b.x*a.y-c.x*b.y);
}
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
        fin>>v[i].x>>v[i].y;
    sort(v+1,v+n+1,comp1);
    ans[1]=v[1];
    sort(v+2,v+n+1,comp2);
    ans[2]=v[2];
    st=2;
    for(i=3;i<=n;i++)
    {
        ans[++st]=v[i];
        double d=determinant(ans[st-2],ans[st-1],ans[st]);
        while(st>2&&d<0)
        {
            st--;
            ans[st]=v[i];
            d=determinant(ans[st-2],ans[st-1],ans[st]);
        }
    }
    fout<<st<<'\n';
    for(i=1;i<=st;i++)
        fout<<fixed<<setprecision(6)<<ans[i].x<< " "<<ans[i].y<<'\n';
    return 0;
}
