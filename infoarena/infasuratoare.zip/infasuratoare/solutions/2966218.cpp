#include <algorithm>
#include <cmath>
#include <cstdio>

using namespace std;

const int maxn = 120000;
const int INF = 1000000000;

double X[maxn], Y[maxn];
int PI, IND[maxn], N, ST[maxn], p, l;

bool cmpf(int i, int j) { return (X[i] - X[PI]) * (Y[j] - Y[PI]) > (X[j] - X[PI]) * (Y[i] - Y[PI]); }
double semn (int i1, int i2, int i3) {
  return X[i1] * Y[i2] + X[i2] * Y[i3] + X[i3] * Y[i1] - Y[i1] * X[i2] - Y[i2] * X[i3] - Y[i3] * X[i1];
}

int main() {
    freopen("infasuratoare.in", "r", stdin);
    freopen("infasuratoare.out", "w", stdout);
    scanf("%d\n", &N);
    X[0] = INF;
    Y[0] = INF;
    PI = 0;
    for (int i = 1; i <= N; i++) {
        scanf("%lf %lf", &X[i], &Y[i]);
        if (Y[i] < Y[PI])
            PI = i;
        else //
            if (Y[i] == Y[PI])
                if (X[i] < X[PI])
                    PI = i;
    }
    for (int i = 1; i <= N; i++)
        if (i != PI)
            IND[++l] = i;
    sort(IND + 1, IND + N, cmpf);
    p = 1;
    ST[p] = PI;
    for (int i = 1; i <= N - 1; ++i) {
        while (p >= 2 and semn(ST[p - 1], ST[p], IND[i]) < 0))
            --p;
        ST[++p] = IND[i];
    }
  printf("%d\n", p);
  for (int i = 1; i <= p; ++i)
    printf("%lf %lf\n", X[ST[i]], Y[ST[i]]);
  return 0;
}
