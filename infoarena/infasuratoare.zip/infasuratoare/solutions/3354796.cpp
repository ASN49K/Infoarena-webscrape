#include <fstream>
#include <algorithm>
using namespace std;
ifstream cin ("infasuratoare.in");
ofstream cout ("infasuratoare.out");
struct Puncte {
    long long x, y;
};
Puncte p[120005], v[240010];
long long cross_prod(Puncte a, Puncte b, Puncte c) {
    return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);
}
bool f(Puncte a, Puncte b) {
    if (a.x == b.x) return a.y < b.y;
    return a.x < b.x;
}
int main() {
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> p[i].x >> p[i].y;
    }
    sort(p, p + n, f);
    int k = 0;
    for (int i = 0; i < n; i++) {
        while (k >= 2 && cross_prod(v[k-2], v[k-1], p[i]) <= 0) {
            k--;
        }
        v[k++] = p[i];
    }
    int t = k;
    for (int i = n - 2; i >= 0; i--) {
        while (k > t && cross_prod(v[k-2], v[k-1], p[i]) <= 0) {
            k--;
        }
        v[k++] = p[i];
    }
    k--;
    cout << k << "\n";
    cout.setf(ios::fixed);
    cout.precision(6);
    for (int i = 0; i < k; i++) {
        cout << v[i].x << " " << v[i].y << "\n";
    }

    return 0;
}
