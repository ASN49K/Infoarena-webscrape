#include <bits/stdc++.h>

using namespace std;

ifstream fin("cuvinte.in");
ofstream fout("cuvinte.out");

int n, k, dp[205], a[205], ma, nr[205];

int main()
{
    int i, l = 0, j, last, ok, poz;
    fin >> n >> k;
    for (i = 1; i <= n; i++)
        fin >> a[i];

    for (i = n; i >= 1; i--)
    {
        ma = 0;
        for (j = i + 1; j <= n; j++)
            if (a[j] > a[i] and dp[j] > ma)
                ma = dp[j];

        dp[i] = ma + 1;
        for (j = i + 1; j <= n; j++)
            if (a[j] > a[i] and dp[j] == dp[i] - 1)
                nr[i] += nr[j];
        if (nr[i] == 0)
            nr[i] = 1;
    }

    for (i = 1; i <= n; i++)
        l = max(l, dp[i]);
    for (i = 1; i <= n; i++)
    {
        cout << nr[i] << " " << dp[i] << "\n";
    }
    poz = 1;
    last = 0;
    for (i = l; i >= 1; i--)
    {
        ok = 0;
        for (j = poz; j <= n and ok == 0; j++)
            if (i == dp[j] and last < a[j])
            {
                if (nr[j] < k)
                    k -= nr[j];
                else
                {
                    fout << j << " ";
                    last = a[j];
                    ok = 1;
                    poz = j;
                }
            }
    }



    return 0;
}
