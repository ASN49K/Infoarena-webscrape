#include<bits/stdc++.h>
using namespace std;
ifstream F("infasuratoare.in");
ofstream G("infasuratoare.out");
#define P pair<long double,long double>
int n,i,j,c=2e9,d=2e9,k;
P a[120005],p,s[120005];
long double B(P a,P b,P c)
{
    return (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first);
}
bool A(P a,P b)
{
    return atan2(a.second-p.second,a.first-p.first)<atan2(b.second-p.second,b.first-p.first);
}
int main()
{
    for(F>>n;i<n;F>>a[i].first>>a[i].second,a[i].second<d?c=a[i].first,d=a[i].second,k=i:a[i].second==d&&a[i].first<c?c=a[i].first,k=i:0,++i);
    for(swap(a[0],a[k]),p=a[0],sort(a+1,a+n,A),i=0;i<n;s[++j]=a[i++])
        for(;j>1&&B(s[j-1],s[j],a[i])<=0;--j);
    for(G<<j<<'\n',G<<fixed<<setprecision(6),i=1;i<=j;G<<s[i].first<<' '<<s[i].second<<'\n',++i);
    return 0;
}
