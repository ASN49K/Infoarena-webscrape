/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <bits/stdc++.h>

using namespace std;

ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");

#define limn 120010

int N, leftPointIndex, dr;
struct pct{double x, y;} points[limn], leftPoint, st[limn];

double det(pct A, pct B, pct C) {
    return A.x*B.y + B.x*C.y + A.y*C.x - B.y*C.x - A.y*B.x - C.y*A.x;
}

bool cmp(pct A, pct B) {
    return det(leftPoint, A, B) >= 0;
}

int main()
{
    fin>>N;
    for(int i = 0; i < N; i++) {
        fin>>points[i].x>>points[i].y;
        if(points[i].x < points[leftPointIndex].x || (points[i].x == points[leftPointIndex].x && points[i].y < points[leftPointIndex].y))
            leftPointIndex = i;
    }
    swap(points[leftPointIndex], points[0]); // fixez punctul initial pe 0
    leftPoint = points[0];
    sort(points+1, points+N, cmp);
    
    st[++dr] = leftPoint; // acelasi cu points[0]
    for(int i = 1; i < N; i++) {
        while(dr > 1 && det(st[dr-1], st[dr], points[i]) < 0)
            dr--;
        st[++dr] = points[i];
    }
    
    sort(st+2, st+dr+1, cmp);
    fout<<dr<<'\n';
    for(int i = 1; i <= dr; i++)
        fout<<fixed<<st[i].x<<' '<<st[i].y<<'\n';

    
    return 0;
};