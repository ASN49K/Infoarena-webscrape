#include<fstream>
#include <algorithm>
#include <iomanip>
#define  Lmax 120003
using namespace std;
ifstream f("infasuratoare.in");
ofstream g("infasuratoare.out");
struct Punct{
    double x,y;
};
Punct a[Lmax],stiva[Lmax];
int n,i,k;
bool cmp(Punct a, Punct b)
{
    if(a.y < b.y || (a.y == b.y && a.x < b.x)) return true;
    return false;
}
int semn(Punct a,Punct b, Punct c){
if((a.x-c.x)*(b.y-c.y)-(b.x-c.x)*(a.y-c.y)>=0)return 1;
else return 0;
}

int main()
{
    f>>n;
    for(i = 1; i <= n; i++)     f>>a[i].x>>a[i].y;
    sort(a + 1, a + n + 1, cmp);
    stiva[1]=a[1];
    k = 1;
    for(i = 2; i <= n; i++)
    {
        while(k > 1 && !semn(stiva[k-1], stiva[k], a[i])) k--;
        stiva[++k]=a[i];
    }
    for(i = n - 1; i >= 1; i--)
    {
        while(!semn(stiva[k-1], stiva[k], a[i]))k--;
        stiva[++k]=a[i];
    }
    g<<fixed; g<<setprecision(6);
    g<<k-1<<'\n';
    for(i = 1; i <= k-1 ; i++) g<< stiva[i].x <<" "<<stiva[i].y<<'\n';
    g.close();
    return 0;
}
