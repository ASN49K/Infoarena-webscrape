#include <fstream>
#include <algorithm>
#include <iomanip>
using namespace std;
ifstream fin ("infasuratoare.in");
ofstream fout ("infasuratoare.out");
struct punct
{
    long double x,y;
};
punct v[120001],stiva[120001],pct;
int n,poz,k;
long double dist (punct a)
{
    return a.x*a.x+a.y*a.y;
}
long double det (punct a,punct b,punct c)
{
    return (b.y-a.y)*(c.x-a.x)-(c.y-a.y)*(b.x-a.x);
}
bool cmp (punct a,punct b)
{
    if (det (v[1],a,b)==0)
        return dist (a)>dist (b);
    return det (v[1],a,b)<0;
}
int main()
{
    fin>>n;
    poz=1;
    for (int i=1; i<=n; i++)
    {
        fin>>v[i].x>>v[i].y;
        if (v[i].y<v[poz].y||(v[i].y==v[poz].y&&v[i].x<v[poz].x))
            poz=i;
    }
    swap (v[1],v[poz]);
    for (int i=2; i<=n; i++)
    {
        v[i].x-=v[1].x;
        v[i].y-=v[1].y;
    }
    pct=v[1];
    v[1]={0,0};
    sort (v+2,v+n+1,cmp);
    int j;
    for (j=3; j<=n; j++)
    {
        if (det (v[j-2],v[j-1],v[j]))
            break;
    }
    reverse (v+2,v+j);
    stiva[1]=v[1];
    stiva[2]=v[2];
    k=2;
    for (int i=3; i<=n; i++)
    {
        while (k>1&&det (stiva[k-1],stiva[k],v[i])>0)
            k--;
        stiva[++k]=v[i];
    }
    fout<<k<<"\n";
    for (int i=1; i<=k; i++)
        fout<<fixed<<setprecision (6)<<stiva[i].x+pct.x<<" "<<stiva[i].y+pct.y<<"\n";
    return 0;
}
