#include <bits/stdc++.h>
#include <ctime>
using namespace std;

#define MOD 1000000007
#define NMAX 120005
#define KMAX 2000
#define ll long long int

#define x first
#define y second

ifstream fin("infasuratoare.in");
ofstream fout("infasuratoare.out");


typedef pair<double,double> Point;
Point v[NMAX+1];
vector<Point> Stack;
double orientation(Point a,Point b,Point c)
{
    // (b.y-a.y) / (b.x-a.x) < (c.y-b.y)/(c.x/b.x)
    return (b.y-a.y)*(c.x-b.x) - (b.x-a.x)*(c.y-b.y);
}
bool cmp(Point a,Point b)
{
    return orientation(v[1],a,b) < 0;
}

int main()
{
    int n;
    fin >> n;
    for(int i=1;i<=n;i++)
    {
        fin >> v[i].x >> v[i].y;
    }
    int pos=1;
    for(int i=2;i<=n;i++)
    {
        pos = v[i] < v[pos] ? i : pos;
    }
    swap(v[pos],v[1]);
    sort(v+2,v+n+1,cmp);

    Stack.push_back(v[1]);
    Stack.push_back(v[2]);
    for(int i=3;i<=n;i++)
    {
        while(Stack.size() >= 2 && orientation(Stack[Stack.size()-2],Stack[Stack.size()-1],v[i]) >= 0)
        {
            Stack.pop_back();
        }
        Stack.push_back(v[i]);
    }
    fout << Stack.size() << "\n";
    for(auto i : Stack)
    {
        fout << i.x << " " << i.y << "\n";
    }
}

