#include <bits/stdc++.h>
using namespace std;

#define x first
#define y second

typedef pair<double, double> pt;

ifstream f("infasuratoare.in");
ofstream g("infasuratoare.out");

const int N = 12e5 + 5;

int rez[N], n;
pt v[N];

void init();
inline double det(pt a, pt b, pt c){
    return (a.x*b.y + b.x*c.y + c.x*a.y - b.x*a.y - c.x*b.y - a.x*c.y);
}
inline bool sortTrig(pt a, pt b){
    return det(v[0], a, b) > 0;
}

int main()
{
    init();
    rez[1] = 1;
    int k = 1;
    for (int i = 2; i < n; i++){
        while (k > 1 && det(v[rez[k - 1]], v[rez[k]], v[i]) <= 0) k--;
        rez[++k] = i;
    }
    g << k + 1 << '\n' << fixed << setprecision(12);
    for (int i = 0; i <= k; i++) g << v[rez[i]].x << ' ' << v[rez[i]].y << '\n';
    
    
}

void init(){
    f >> n;
    for (int i = 0; i < n; i++)
        f >> v[i].x >> v[i].y;
        
    int i = 0;
    for (int j = 1; j < n; j++)
        if (v[i] > v[j]) i = j;
    swap(v[i], v[0]);
    sort(v + 1, v + n, sortTrig);
}