#include <fstream>
#include <algorithm>
#include <iomanip>
using namespace std;
ifstream cin("infasuratoare.in");
ofstream cout("infasuratoare.out");
struct ura
{
    double x,y;
    short int poz;
}v[120001];
int st[120001];
bool cmp(ura a, ura b)
{
    if(a.x<b.x)
        return true;
    if(a.x==b.x)
        if(a.y<b.y)
        return true;
    return false;
}
double aria(ura a, ura b, ura c)
{
    return  a.x*b.y + b.x*c.y + c.x*a.y -b.y*c.x -c.y*a.x - a.y*b.x;
}
int main()
{
    int n,i,k;
    cin>>n;
    for(i=1;i<=n;i++)
        cin>>v[i].x>>v[i].y;
    sort(v+1,v+n+1,cmp);
    for(i=2;i<n;i++)
    {
        if(aria(v[1],v[n],v[i])<0)
            v[i].poz=-1;
        else
            v[i].poz=1;
    }
    v[1].poz=v[n].poz=2;
    k=1;
    st[1]=1;
    for(i=2;i<=n;i++)
    {
        if(v[i].poz==1 or v[i].poz==2)
        {
            while(aria(v[st[k-1]],v[st[k]],v[i])>0 and k>1)
                k--;
            k++;
            st[k]=i;
        }
    }
    int ck=k;
    st[k]=n;
    for(i=n-1;i>=1;i--)
    {
        if(v[i].poz==-1 or v[i].poz==2)
        {
            while(aria(v[st[k-1]],v[st[k]],v[i])>0 and k>ck)
                k--;
            k++;
            st[k]=i;
        }
    }
    cout<<k-1<<'\n';
    for(i=1;i<k;i++)
        cout<<fixed<<setprecision(6)<<v[st[i]].x<<" "<<v[st[i]].y<<'\n';
    return 0;
}
