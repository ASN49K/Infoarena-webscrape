#include <bits/stdc++.h>
#define SIZE 120005

using namespace std;

ifstream f("infasuratoare.in");
ofstream g("infasuratoare.out");

struct punct
{
    long double x,y;
}v[SIZE];

int n,vf,vz[SIZE],st[SIZE];

inline bool cmp(const punct &a,const punct &b)
{
    if(a.x==b.x)return a.y<b.y;
    else return a.x<b.x;
}

inline bool determinant(punct a,punct b,punct c)
{
    return (c.y-a.y)*(b.x-a.x)<=(b.y-a.y)*(c.x-a.x);
}

int main()
{
    int i,pas;
    f>>n;
    for(i=1;i<=n;i++)f>>v[i].x>>v[i].y;
    sort(v+1,v+n+1,cmp);
    st[1]=1;
    st[2]=2;
    vf=2;
    vz[2]=1;
    i=3;
    pas=1;
    while(vz[1]==0)
    {
        if(vz[i]==0)
        {
            while(vf>1 && determinant(v[st[vf-1]],v[st[vf]],v[i])==1 && st[vf]!=n)
                vz[st[vf]]=0,vf--;
            st[++vf]=i;
            vz[i]=1;
        }
        if(i==n)pas=-1;
        i+=pas;
    }
    vf--;
    g<<vf<<'\n';
    for(i=1;i<=vf;i++)
    {
          g<<fixed<<setprecision(12)<<v[st[i]].x<<' ';
          g<<fixed<<setprecision(12)<<v[st[i]].y<<'\n';
    }

}
