#include <fstream>
#include <algorithm>
#include <stack>
using namespace std;
ifstream cin("infasuratoare.in");
ofstream cout("infasuratoare.out");
struct inf
{
    float x,y;
};
inf v[120001];
bool cmp(inf a, inf b)
{
    if(a.x<b.x)
        return true;
    else if(a.y<b.y)
            return true;
    return false;
}
stack<float> st;
int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>v[i].x>>v[i].y;
    }
    sort(v+1,v+n+1);
    for(int i=1;i<=n;i++)
    {
        if
    }
    return 0;
}
