#include <cstdio>
#include <algorithm>
#include <vector>
#include <string>
#include <cmath>
#define eps 0.0000001

using namespace std;

#define NMax 400005
#define PII pair< pair<int, int>, int >
#define pb push_back
#define mp make_pair

const int maxn = 1000000;

int NR,NR2;
double XOUT[maxn],YOUT[maxn],XANS[maxn],YANS[maxn];


void result(const string& msg, int p)
{
    fprintf(stderr, "%s", msg.c_str());
    printf("%d", p);
    exit(0);
}

bool myequal(double x,double y)
{
	return fabs(x - y) <= eps;
}

int main()
{
	FILE *f;
	int i;

	f = fopen("infasuratoare.ok", "r");
	if (!f) result("Fisier ok lipsa!", 0);
	if (fscanf(f, "%d\n", &NR) != 1) result("Fisier ok corupt!", 0);
	for(int i = 1;i <= NR; ++i)
		if (fscanf(f,"%lf %lf\n",&XANS[i],&YANS[i]) != 2) result("Fisier ok corupt!", 0);
	fclose(f);

	f = fopen("infasuratoare.out", "r");
	if (!f) result("Fisier de iesire lipsa!", 0);
	if (fscanf(f, "%d\n", &NR2) != 1) result("Prima linie in format incorect!", 0);
	if (NR != NR2) result("Numar de puncte incorect", 0);
	for(int i = 1;i <= NR; ++i)
		if (fscanf(f,"%lf %lf\n",&XOUT[i],&YOUT[i]) != 2) result("Fisier out corupt!", 0);
	fclose(f);

	for(int i = 1;i <= NR; ++i)
	{
		XOUT[i + NR] = XOUT[i];
		YOUT[i + NR] = YOUT[i];
	}

	for(i = 1;i <= NR; ++i)
	{
		if (myequal(XOUT[i], XANS[1]) && myequal(YOUT[i], YANS[1])) break;
	}
	for(int j = 1;j <= NR;++j,++i)
	{
		if (!myequal(XOUT[i],XANS[j]) || !myequal(YOUT[i],YANS[j])) result("Poligon gresit!",0);
	}
	result("Corect", 10);

	return 0;
}
