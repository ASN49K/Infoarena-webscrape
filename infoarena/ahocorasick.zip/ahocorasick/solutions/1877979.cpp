#include <bits/stdc++.h>
using namespace std;
ifstream f("ahocorasick.in");
ofstream g("ahocorasick.out");
int i,j,n,l,x,y,k,m,S[1<<20];
char a[1<<20];
struct trie
{
    int nr,bak,Son[26];
}T[1<<18];
vector <int> Sol,Q;
int main()
{
    f>>a;
    for(i=0;a[i]>='a'&&a[i]<='z';++i) S[++n]=a[i]-'a';
    f>>m;
    for(j=1;j<=m;++j)
    {
        f>>a;
        int l=strlen(a);
        for(i=x=0;i<l;++i)
        {
            int y=a[i]-'a';
            if(!T[x].Son[y])
            {
                T[x].Son[y]=++k;
                x=k;
            }
            else x=T[x].Son[y];
        }
        Sol.push_back(x);
    }
    for(i=0;i<=k;++i) T[i].bak=-1;
    Q.push_back(0);
    for(i=0;i<Q.size();++i)
    {
        x=Q[i];
        for(j=0;j<26;++j)
            if(T[x].Son[j])
        {
            y=T[x].bak;
            if(y!=-1)
            while(!T[y].Son[j])
            {
                y=T[y].bak;
                if(y==-1) break;
            }
            int nod=T[x].Son[j];
            if(y!=-1) T[nod].bak=T[y].Son[j];
            else T[nod].bak=0;
            Q.push_back(nod);
        }
    }
    x=0;
    for(i=1;i<=n;++i)
    {
        while(!T[x].Son[S[i]])
        {
            x=T[x].bak;
            if(x==-1) break;
        }
        if(x==-1) x=0;
        else
        {
            x=T[x].Son[S[i]];
            T[x].nr++;
        }
    }
    for(i=Q.size()-1;i>=0;--i)
        if(T[Q[i]].bak) T[T[Q[i]].bak].nr+=T[Q[i]].nr;
    for(j=0;j<m;++j) g<<T[Sol[j]].nr<<'\n';
    return 0;
}
