#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct M {
	int a;
	struct M *l[26],*x;
}N;
int i,n,j,p,u;
char e[1000001],a[10001],*k;
N *c[100000001],*s,*q,*b[100],*t;
N *V() {
    N *r=(N*)malloc(sizeof(N));
    a=0,memset(r,0,sizeof(N)),memset(r->l,0,26),memset(x,0,sizeof(N));
    return r;
}
void A(N *r) {
	if(!(*k)) {
		b[j]=r;
     	return;
	}
	*k-='a';
	if(!r->l[*k])
     	r->l[*k]=V();
	A(r->l[*k++]);
}
int main() {
	freopen("ahocorasick.in","r",stdin),freopen("ahocorasick.out","w",stdout),fgets(e,1000001,stdin),scanf("%d\n",&n),r=V();
	for(j=0;j<n;j++)
    	fgets(a,10001,stdin),k=a,A(r);
	for(r->x=c[u++]=r;p<u;)
    for(t=c[p++],i=0;i<26;i++)
    if(t->l[i]) {
        for(s=t->x;s!=r&&!s->l[i];s=s->x);
        t->l[i]->x=(s->l[i]&&s->l[i]!=t->l[i]?s->l[i]:r),c[u++]=t->l[i];
	}
	for(q=r,i=0;e[i];i++) {
		for(;!q->l[e[i]-'a']&&q!=r;q=q->x);
		q=(q->l[e[i]-'a']?q->l[e[i]-'a']:q),q->a++;
	}
	for(i=u-1;i>=0;i--)
    	c[i]->x->a+=c[i]->a;
	for(i=0;i<n;i++)
    	printf("%d\n",b[i]->a);
}
