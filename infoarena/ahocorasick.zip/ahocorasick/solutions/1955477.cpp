#include <bits/stdc++.h>
#define maxN 1000005
#define maxL 10005
#define SIGMA 26
#define maxW 102
using namespace std;

FILE *fin = freopen("ahocorasick.in", "r", stdin);
FILE *fout = freopen("ahocorasick.out", "w", stdout);

/* ====================== */
int n;
char Word[maxL];
char Txt[maxN];
/* ====================== */
struct Trie
{
    Trie *son[26];
    vector < short int > out;
    Trie* f;
};
Trie* T;
queue < Trie* > q;
int frq[maxW];
/* ====================== */


Trie* new_empty_node()
{
    Trie *node = new Trie;
    node->f = NULL;
    node->out.clear();
    for(int i = 0; i < SIGMA; ++ i)
        node->son[i] = NULL;
    return node;
}

void insert(Trie* node, char *w, int idx)
{
    if (*w == 0)
    {
        node->out.push_back(idx);
        return;
    }
    if (node->son[*w - 'a'] == NULL)
        node->son[*w - 'a'] = new_empty_node();
    insert(node->son[*w - 'a'], w + 1, idx);
}

void Goto()
{
    T->f = T;
    for (int i = 0; i < SIGMA; ++ i)
        if (T->son[i] == NULL)
        {
            T->son[i] = new_empty_node();
            T->son[i]->f = T;
        }
        else
        {
            T->son[i]->f = T;
            q.push(T->son[i]);
        }
}

void Fail()
{
    while (!q.empty())
    {
        Trie* st = q.front();
        q.pop();
        for (int i = 0; i < SIGMA; ++ i)
            if (st->son[i] != NULL)
            {
                Trie* failure = st->f;
                while (failure->son[i] == NULL)
                    failure = failure->f;

                failure = failure->son[i];
                st->son[i]->f = failure;

                for (int j = 0; j < failure->out.size(); ++ j)
                    st->son[i]->out.push_back(failure->out[j]);

                q.push(st->son[i]);
            }
    }
}

Trie* NextSt(Trie* node, int ch)
{
    Trie* ret = node;

    while (ret->son[ch] == NULL)
        ret = ret->f;

    return ret->son[ch];
}

void Out()
{
    int len = strlen(Txt);
    Trie* st = T;

    for (int i = 0; i < len; ++ i)
    {
        st = NextSt(st, Txt[i] - 'a');
        for (int j = 0; j < st->out.size(); ++ j)
            ++ frq[st->out[j]];
    }
}

int main()
{
    gets(Txt);
    scanf("%d\n", &n);
    T = new_empty_node();
    for (int i = 1; i <= n; ++ i)
    {
        gets(Word);
        insert(T, Word, i);
    }

    Goto();
    Fail();
    Out();

    for (int i = 1; i <= n; ++ i)
        printf("%d\n", frq[i]);
    return 0;
}
