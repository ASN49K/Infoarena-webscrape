#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream f ("ahocorasick.in");
ofstream g ("ahocorasick.out");

char c[1000005];

char mat[105][10005];

int n , m , i , lngc , p[10005] , q;

int main()
{
    f >> c;
    f >> n;
    lngc = strlen (c + 1);
    for (int i = 1 ; i <= n ; i++)
    {
            int cnt = 0;
        f >> (mat[i] + 1);
        m = strlen (mat[i] + 1);
        p[1] = 0;
        q = 0;
        for (int j = 2 ; j <= m ; j++)
        {
            while (q > 0 && mat[i][q + 1] != mat[i][j])
                q = p[q];
            if (mat[i][q + 1] == mat[i][j])
                q++;
            p[j] = q;
        }

        q = 0;
        for (int j = 1 ; j <= n ; j++)
        {
            while (q > 0 && mat[i][q + 1] != c[j])
                q = p[q];
            if (mat[i][q + 1] == c[j])
                q++;
            if (q == m)
                cnt++;
        }
        g << cnt << '\n';;
        for (int i = 1 ; i <= m ; i++)
            p[i] = 0;



    }
    return 0;
}
