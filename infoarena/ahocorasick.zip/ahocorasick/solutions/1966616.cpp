﻿#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>
#include <cmath>
#include <ctime>

using namespace std;

const int INF=2140e6;
const int MaxN=1e2+5;
const int MaxW=1e4+5;
const int MaxL=1e6+5;
FILE *IN,*OUT;

int N,Out[MaxN];
char word[MaxW],String[MaxL+5];
struct Trie
{
	vector<int> List;
	int fr;
	Trie *Son[26],*pi;
	Trie()
	{
		fr=0;
		memset(Son,0,sizeof Son);
		pi=NULL;
	}
}*Root;
queue<Trie*>Q;
vector<Trie*>Rev;
void Insert(Trie *node,char *w,int n)
{
	if(node->Son[*w-'a']==NULL)
		node->Son[*w-'a']=new Trie;
	if(*w==0)
		node->List.push_back(n);
	else Insert(node->Son[*w-'a'],w+1,n);
}
void Get_Pi(Trie *node)
{
	Trie *aux,*p;
	Q.push(node);
	node->pi=node;
	while(!Q.empty())
	{
		p=Q.front();
		Q.pop();
		Rev.push_back(p);
		for(int i=0;i<26;i++)
			if(p->Son[i]!=NULL)
			{
				for(aux=p->pi;aux!=node&&aux->Son[i]==NULL;aux=aux->pi);
				if(aux->Son[i]!=NULL&&aux->Son[i]!=p->Son[i])
					aux=aux->Son[i];
				p->Son[i]->pi=aux;
				Q.push(p->Son[i]);
			}
	}
	node->pi=NULL;
}
void Complete_Trie()
{
	Trie *node;
	for(int i=Rev.size()-1;i>=0;i--)
	{
		node=Rev[i];
		if(node->pi!=NULL)
			node->pi->fr+=node->fr;
		for(int j=0;j<node->List.size();j++)
			Out[node->List[j]]=node->fr;
	}
}
int main()
{
	IN=fopen("ahocorasick.in","r");
	OUT=fopen("ahocorasick.out","w");

	fscanf(IN,"%s %d",String,&N);
	Root=new Trie;
	for(int i=1;i<=N;i++)
	{
		memset(word,0,sizeof word);
		fscanf(IN,"%s",word);
		Insert(Root,word,i);
	}
	Get_Pi(Root);
	Trie *node=Root;
	for(int i=0;String[i]!=0;i++)
	{
		int next=String[i]-'a';
		while(node->Son[next]==NULL&&node!=Root)
			node=node->pi;
		if(node->Son[next]!=NULL)
			node=node->Son[next];
		node->fr++;
	}
	Complete_Trie();
	for(int i=1;i<=N;i++)
		fprintf(OUT,"%d\n",Out[i]);
	return 0;
}