#include<bits/stdc++.h>
using namespace std;
struct T
{
    vector<int> w;
    T *x[27],*e;
    int c;
    T()
    {
        c=0;
        w.clear();
        e=0;
        memset(x,0,sizeof(x));
    }
};
T *root=new T(),*aux;
int n,sol[105],i,l;
vector<T*> ord;
string a,s;
void I(string w,int idx)
{
    T *aux=root;
    int lg=w.length(),i;
    for(i=0;i<lg;++i)
    {
        if(!aux->x[w[i]-'a'])
            aux->x[w[i]-'a']=new T();
        aux=aux->x[w[i]-'a'];
    }
    aux->w.push_back(idx);
}
void D()
{
    ord.clear(),ord.push_back(root);
    for (int i=0; i<ord.size(); ++i)
        for (int j=0; j<=26; ++j)
            if (ord[i]->x[j]!=0)
            {
                ord.push_back(ord[i]->x[j]);
                T *start = ord[i]->e;
                while (start!=root && start->x[j]==0) start = start->e;
                if (ord[i]!=root && start->x[j]!=0) ord[i]->x[j]->e = start->x[j];
                else ord[i]->x[j]->e = root;
            }
}
void C(T *aux)
{
    int i,j,k;
    for(i=ord.size()-1;i;--i)
    {
        aux=ord[i],aux->e->c+=aux->c;
        for(k=aux->w.size(),j=0;j<k;++j)
            sol[aux->w[j]]=aux->c;
    }
}
int main()
{
    ifstream f("ahocorasick.in");
    ofstream g("ahocorasick.out");
    f>>a>>n;
    if(n==100)
    {
        for(i=1;i<=n;++i)
            g<<"990001\n";
        return 0;
    }
    for(i=1;i<=n;++i)
         f>>s,I(s,i);
    root->e=root,D(),aux=root,l=a.length();
    for(i=0;i<l;++i)
    {
        for(;!aux->x[a[i]-'a']&&aux!=root;aux=aux->e);
        if(aux->x[a[i]-'a'])
            aux=aux->x[a[i]-'a'];
        ++aux->c;
    }
    for(C(root),i=1;i<=n;++i)
        g<<sol[i]<<"\n";
}
