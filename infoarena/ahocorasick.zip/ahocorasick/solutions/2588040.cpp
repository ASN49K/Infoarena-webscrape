#include <iostream>
#include <fstream>
#include <string>
#include <unordered_map>
#include <queue>

using namespace std;

ifstream fin("ahocorasick.in");
ofstream fout("ahocorasick.out");

struct Node{
	unordered_map<char, Node*> ch;
	Node *suf = NULL, *dsuf = NULL;
	int index = 0;
	void add(const string &a, int index){
		Node *p = this;
		for(auto c : a){
			if(p->ch.count(c) == 0){
				p->ch[c] = new Node();
			}
			p = p->ch[c];
		}
		p->index = index;
	}
	void upgrade(){
		queue<Node*> qu;
		qu.push(this);
		while(!qu.empty()){
			Node *p = qu.front();
			qu.pop();
			for(auto a : p->ch){
				char c = a.first;
				Node *q = a.second;
				
				q->suf = p->suf;
				while(q->suf != NULL && q->suf->ch.count(c) == 0){
					q->suf = q->suf->suf;
				}
				
				if(q->suf == NULL){
					q->suf = p;
				}else{
					q->suf = q->suf->ch[c];
				}
				
				qu.push(q);
			}
		}
	}
	void upgrade2(){
		queue<Node*> qu;
		qu.push(this);
		while(!qu.empty()){
			Node *p = qu.front();
			qu.pop();
			for(auto a : p->ch){
				char c = a.first;
				Node *q = a.second;
				
				q->dsuf = q->suf;
				while(q->dsuf != NULL && q->dsuf->index == 0){
					q->dsuf = q->dsuf->suf;
				}
				
				qu.push(q);
			}
		}
	}
	Node *next(char c){
		Node *p = this;
		while(p->suf != NULL && p->ch.count(c) == 0){
			p = p->suf;
		}
		
		if(p->ch.count(c) == 0){
			return p;
		}else{
			return p->ch[c];
		}
	}
};
Node r;

int n;
string s, a;
void read(){
	fin >> s >> n;
	for(int i = 1; i <= n; ++i){
		fin >> a;
		r.add(a, i);
	}
}

int frecc[114];
void solve(){
	r.upgrade();
	r.upgrade2();
	Node *p = &r;
	for(auto c : s){
		p = p->next(c);
		Node *q = p;
		while(q != NULL){
			frecc[q->index]++;
			q = q->dsuf;
		}
	}
}

void write(){
	for(int i = 1; i <= n; ++i){
		fout << frecc[i] << "\n";
	}
}

int main(){
	// ios_base::sync_with_stdio(false);
	read();
	solve();
	write();
	return 0;
}