#include <cstdio>
#include <cstring>
using namespace std;
char a[10005], b[1000001], z;
int phia[10005], phib[1000001], m, n, nr=0;
int KMP ()
{
    int i, k; phia[1]=0; a[m+1]=' '; nr=0;
    for (i=2; i<=m; i++)
    {
        k=phia[i-1];
        while (k>0 && a[i]!=a[k+1]) k=phia[k];
        if (a[i]==a[k+1]) phia[i]=k+1;
        else phia[i]=0;
    }
    for (i=1; i<=n; i++)
    {
        k=phib[i-1];
        while (k>0 && b[i]!=a[k+1]) k=phia[k];
        if (b[i]==a[k+1]) phib[i]=k+1;
        else phib[i]=0;
        if (phib[i]==m) nr++;
    }
}
int main()
{
    int i, t;
    freopen("ahocorasick.in","r",stdin);
    freopen("ahocorasick.out","w",stdout);
    gets(b+1); n=strlen(b+1);
    scanf("%d%c",&t,&z);
    for (i=1; i<=t; i++)
    {
        gets(a+1);  m=strlen(a+1); a[m+1]=' ';
        KMP();
        printf("%d\n",nr);
    }
    return 0;
}
