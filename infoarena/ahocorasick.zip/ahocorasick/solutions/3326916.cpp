#include<bits/stdc++.h>
#pragma GCC optimize("Ofast,unroll-loops,inline")
#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
#define fast ios_base::sync_with_stdio(0);f.tie(0);g.tie(0);
#define setinf(x) memset(x,0x3f3f3f3f,sizeof(x));
#define set0(x) memset(x,0,sizeof(x));
#define all(x) x.begin(),x.end()
#define pii pair<int,int>
#define INF 0x3f3f3f3f
#define vi vector<int>
#define ll long long
#define vll vector<ll>
#define pb push_back
#define fi first
#define se second
#define DD 100001
#define nl '\n'
using namespace std;
const string file="ahocorasick";
ifstream f(file+".in");
ofstream g(file+".out");
//#define f cin
//#define g cout
const int SIGMA=26;
int n;
struct aho {
    struct node {
        int nxt[SIGMA];
        int suf;
        vector<int>out;
        node() {
            fill(nxt,nxt+SIGMA,-1);
            suf=-1;
        }
    };
    vector<node>t;
    aho() {
        t.push_back(node());
    }
    void insert(string s, int id) {
        int nod=0;
        for (char c:s) {
            if (t[nod].nxt[c-'a']==-1) {
                t[nod].nxt[c-'a']=t.size();
                t.push_back(node());
            }
            nod=t[nod].nxt[c-'a'];
        }
        t[nod].out.push_back(id);
    }
    void build() {
        queue<int>q;
        for (int i=0; i<SIGMA; ++i) {
            if (t[0].nxt[i]!=-1) {
                int child=t[0].nxt[i];
                t[child].suf=0;
                q.push(child);
            }
        }
        while (!q.empty()) {
            int nod=q.front();
            q.pop();
            for (int i=0; i<SIGMA; ++i) {
                int fiu=t[nod].nxt[i];
                if (fiu==-1) continue;
                q.push(fiu);
                int sufixtata=t[nod].suf;
                while (sufixtata!=-1 && t[sufixtata].nxt[i]==-1)
                    sufixtata=t[sufixtata].suf;
                if (sufixtata==-1)
                    t[fiu].suf=0;
                else {
                    t[fiu].suf=t[sufixtata].nxt[i];
                    for (int id:t[t[fiu].suf].out) {
                        t[fiu].out.push_back(id);
                    }
                }
            }
        }
    }
    vector<int>search(string txt) {
        vector<int>fr(n+1,0);
        int nod=0;
        for (int i=0; i<txt.size(); ++i) {
            int idx=txt[i]-'a';
            while (nod!=0 && t[nod].nxt[idx]==-1)
                nod=t[nod].suf;
            if (t[nod].nxt[idx]!=-1)
                nod=t[nod].nxt[idx];
            for (int id:t[nod].out)
                fr[id]++;
        }
        return fr;
    }
};
int main(){fast
    string t;
    f>>t;
    f>>n;
    aho ac;
    for (int i=1; i<=n; ++i) {
        string s;
        f>>s;
        ac.insert(s,i);
    }
    ac.build();
    vi fr=ac.search(t);
    for (int i=1; i<=n; ++i) g<<fr[i]<<nl;
  //  system("pause");
    return 0;
}