#include<cstdio>
#include<cstring>
struct N
{
    int a;
    N *l[26],*x;
    N()
    {
        memset(this,0,sizeof(N)),memset(l,0,26);
    }
};
int i,n,j,p,u;
char e[1000001],a[10001],*k;
N *c[100000001],*s,*r=new N(),*cn,*b[100],*t;
void A(N *r)
{
    if(!(*k))
    {
        b[j]=r;
        return;
    }
    *k-='a';
    if(!r->l[*k])
        r->l[*k]=new N();
    A(r->l[*k++]);
}
int main()
{
    freopen("ahocorasick.in","r",stdin),freopen("ahocorasick.out","w",stdout),gets(e),scanf("%d\n",&n);
    for(j=0;j<n;j++)
        gets(a),k=a,A(r);
    for(r->x=c[u++]=r;p<u;)
        for(t=c[p++],i=0;i<26;i++)
            if(t->l[i])
            {
                for(s=t->x;s!=r&&!s->l[i];s=s->x);
                t->l[i]->x=(s->l[i]&&s->l[i]!=t->l[i]?s->l[i]:r),c[u++]=t->l[i];
            }
    for(cn=r,i=0;e[i];i++,cn->a++)
    {
        for(;!cn->l[e[i]-'a']&&cn!=r;cn=cn->x);
        if(cn->l[e[i]-'a'])
            cn=cn->l[e[i]-'a'];
    }
    for(i=u-1;i>=0;i--)
        c[i]->x->a+=c[i]->a;
    for(i=0;i<n;i++)
        printf("%d\n",b[i]->a);
}
