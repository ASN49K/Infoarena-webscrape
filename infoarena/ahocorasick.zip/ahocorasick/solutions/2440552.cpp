#include <iostream>
#include <fstream>
#include <math.h>
#include <iomanip>
using namespace std;
int n;
long double v1[100500];
long double v2[100500];
long double aria;
int main()
{
  freopen("aria.in","r",stdin);
  freopen("aria.out","w",stdout);
  cin>>n;
  for(int i=0;i<n;i++)
    scanf("%llf %llf",&v1[i],&v2[i]);
  v1[n]=v1[0];
  v2[n]=v2[0];
  for(int i=0;i<=n;i++)
    aria+=v1[i]*v2[i+1]- v1[i+1]*v2[i];
  cout<<setprecision(6)<<fixed;
  cout<<fabs (aria / 2.0);
}
