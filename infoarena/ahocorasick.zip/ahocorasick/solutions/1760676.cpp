#include<bits/stdc++.h>
using namespace std;
 
typedef struct state {
    int len,link,cnt;
    map<char,int> next;
}State;
 
typedef struct lnod {
    int nod;
    lnod *next;
}*nod;
 
int i,n,q,sz,last;
nod lens[1000005];
string s;
State sa[200005];
 
void add(int x,nod &y) {
    nod p=new lnod;
    p->nod=x;
    p->next=y;
    y=p;
}
 
void add_letter(char c) {
    int now=sz++,p;
 
    sa[now].len=sa[last].len+1; sa[now].cnt=1;
    add(now,lens[sa[now].len]);
 
    for(p=last;p!=-1 && !sa[p].next.count(c);p=sa[p].link) sa[p].next[c]=now;
 
    if(p==-1) sa[now].link=0;
    else {
           int q=sa[p].next[c];
 
           if(sa[q].len==sa[p].len+1) sa[now].link=q;
           else {
                  int clone=sz++;
 
                  sa[clone]=sa[q];
                  sa[clone].len=sa[p].len+1;
                  sa[clone].cnt=0;
 
                  for(;p!=-1 && sa[p].next[c]==q;p=sa[p].link) sa[p].next[c]=clone;
 
                  sa[now].link=sa[q].link=clone;
                  add(clone,lens[sa[clone].len]);
                }
         }
 
    last=now;
}
 
int Solve() {
    int now=0,i,n=s.length();
 
    for(i=0;i<n;++i)
     if(sa[now].next[s[i]]) now=sa[now].next[s[i]];
     else return 0;
 
    return sa[now].cnt;
}
 
int main()
{
  ifstream cin("ahocorasick.in");
  ofstream cout("ahocorasick.out");
 
  ios_base::sync_with_stdio(0);
 
  cin>>s; sz=1; sa[0].link=-1; n=s.length();
  for(i=0;i<n;++i) add_letter(s[i]);
 
  for(i=1e6;i;--i)
   for(nod p=lens[i];p;p=p->next)
    sa[sa[p->nod].link].cnt+=sa[p->nod].cnt;
 
  for(cin>>q;q;--q) cin>>s,cout<<Solve()<<'\n';
 
 return 0;
}