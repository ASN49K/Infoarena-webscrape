#include <bits/stdc++.h>
#define dic_size 26
 
using namespace std;
ifstream f("ahocorasick.in");
ofstream g("ahocorasick.out"); 
char a[1000000], t[10000];
int n, rez[10005], st, sf;
 
struct Trie
{
  int nr;
  vector<int> siruri;
  Trie *fiu[dic_size], *fail;
 
  Trie()
  {
    nr = 0;
    fail = NULL;
    memset(fiu, 0, sizeof(fiu));
  }
};
 
Trie *T = new Trie;
Trie *q[10000 * 10000 + 5];
 
void insert(Trie *nod, char *s, int index)
{
  if(!(*s))
    {
      nod -> siruri.push_back(index);
      return;
    }
  if(!(nod -> fiu[s[0] - 'a']))
    nod -> fiu[s[0] - 'a'] = new Trie;
  insert(nod -> fiu[s[0] - 'a'], s + 1, index);
}
 
void compute()
{
  Trie *top, *fa;
  T -> fail = T;
  
  for(q[st = sf = 1] = T;st <= sf;++st)
  {
    top = q[st];
    
    for(short ch = 0;ch < dic_size;++ch)
      if(top -> fiu[ch])
      {
        for(fa = top -> fail;fa != T && !fa -> fiu[ch];fa = fa -> fail);
        if(fa -> fiu[ch] && fa -> fiu[ch] != top -> fiu[ch]) fa = fa -> fiu[ch];
        top -> fiu[ch] -> fail = fa;
        q[++sf] = top -> fiu[ch];
      }   
  }
  T -> fail = NULL;
} 
void Read()
{
  f>>a>>n;
  for(int i = 1;i <= n;++i)
    f>>t, insert(T, t, i);
  f.close();
}
 
void reverse()
{
  Trie *top;
  for(int i = sf;i > 0;--i)
  {
    top = q[i];
    if(top -> fail) top -> fail -> nr += top -> nr;
 
    for(auto it : top -> siruri)
      rez[it] = top -> nr;
  }
}
 
void Solve()
{
  compute();
  int len = strlen(a); Trie *U = T;
  for(int i = 0;i < len;++i)
    {
      int urm = a[i] - 'a';
      for(;!U -> fiu[urm] && U != T;U = U -> fail);
      if(U -> fiu[urm])
        U = U -> fiu[urm];
      U -> nr++;
    }
  reverse();
  for(int i = 1;i <= n;++i)
    g<<rez[i]<<'\n';
  g.close();
}
 
int main()
{
  Read();
  Solve();
  return 0;
}
