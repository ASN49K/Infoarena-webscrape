#include <stdio.h>
#include <string.h>
#include <vector>
#include <queue>
#define MAX 105
#define MAX1 1000005
#define MAX2 10005
#define p(c) (c - 'a')
using namespace std;

typedef struct Trie{
	int val;
	Trie* fiu[26], *suflink;
	vector<Trie*> v;

	Trie(){
		val = 0;
		suflink = 0;
		memset(fiu, 0, sizeof(fiu));
	}
} Trie;

int n, i;
char c[MAX1], s[MAX2];
Trie* T = new Trie();
Trie* l[MAX];
queue<Trie*> q;

Trie* pushTrie(Trie* T, char* s);
void dfs(Trie* T);

int main(){
	freopen("ahocorasick.in", "r", stdin);
	freopen("ahocorasick.out", "w", stdout);
	scanf("%s", c);
	scanf("%d", &n);
	for(i = 0; i < n; i++){
		scanf("%s", s);
		l[i] = pushTrie(T, s);
	}
	q.push(T);

	while(!q.empty()){
		Trie* t = q.front();
		q.pop();

		for(i = 0; i < 26; i++)
			if(t->fiu[i]){
				Trie* prez = t->suflink;
				while(prez && !prez->fiu[i])
					prez = prez->suflink;
				if(!prez){
					t->fiu[i]->suflink = T;
					T->v.push_back(t->fiu[i]);
				}
				else{
					t->fiu[i]->suflink = prez->fiu[i];
					prez->fiu[i]->v.push_back(t->fiu[i]);
				}
				q.push(t->fiu[i]);
			}
	}

	Trie* t = T;
	for(i = 0; c[i]; i++){
		while(t && !t->fiu[p(c[i])])
			t = t->suflink;
		if(!t)
			t = T;
		else
			t = t->fiu[p(c[i])];
		t->val++;
	}

	dfs(T);
	for(i = 0; i < n; i++)
		printf("%d\n", l[i]->val);
	return 0;
}

Trie* pushTrie(Trie* T, char* s){
	if(*s == 0)
		return T;
	if(!T->fiu[p(*s)])
		T->fiu[p(*s)] = new Trie();
	pushTrie(T->fiu[p(*s)], s + 1);
}

void dfs(Trie* T){
	int i;
	for(i = 0; i < T->v.size(); i++){
		dfs(T->v[i]);
		T->val += T->v[i]->val;
	}
}
