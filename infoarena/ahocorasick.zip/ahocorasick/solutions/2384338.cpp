#include <bits/stdc++.h>
#define Lmax 1000001
#define Nmax 10001
using namespace std;
ifstream f("ahocorasick.in");
ofstream g("ahocorasick.out");
int final[Nmax];
char tx[Lmax];
char c[Nmax];
int lg,n,l,ic,sc;
struct aho_corasick
{
    vector<int> nd;
    int n0;
    aho_corasick *f[30],*fail;
    aho_corasick()
    {
        n0=0;
        fail=NULL;
        memset(f,0,sizeof(f));
    }
};
aho_corasick *q[Nmax*Nmax],*t,*p;
void ins(aho_corasick *t,char *p,int i)
{
    if(!isalpha(*p))
    {
        t->nd.push_back(i);
        return;
    }
    int urm=*p-'a';
    if(0==t->f[urm]) t->f[urm]=new aho_corasick;
    ins(t->f[urm],p+1,i);
}
void bfs(aho_corasick *t)
{
    aho_corasick *dolar;
    t->fail=t;
    for(q[ic=sc=1]=t;ic<=sc;++ic)
    {
        aho_corasick *fr=q[ic];
        for(int i=0; i<26; ++i) if(fr->f[i]!=NULL)
        {
            for(dolar=fr->fail;dolar!=t and dolar->f[i]==NULL;dolar=dolar->fail);
            if(dolar->f[i]!=NULL and dolar->f[i]!=fr->f[i]) dolar=dolar->f[i];
            fr->f[i]->fail=dolar;
            q[++sc]=fr->f[i];
        }
    }
    t->fail=NULL;
}
void antibfs(aho_corasick *t)
{
    for(int i=sc; i>0; --i)
     {
        aho_corasick *fr=q[i];
        if(fr->fail!=NULL) fr->fail->n0+=fr->n0;
        for(int j=0; j<fr->nd.size(); ++j) final[fr->nd[j]]=fr->n0;
    }
}
int main()
{
    f>>tx>>n;
    t=new aho_corasick;
    for(int i=1;i<=n;i++)
    {
        f>>c;
        ins(t,c,i);
    }
    bfs(t);
    p=t;
    lg=strlen(tx);
    for(int i=0; i<lg; ++i)
    {
        int urm=tx[i]-'a';
        for(;p->f[urm]==NULL && p!=t;p=p->fail);
        if(p->f[urm]!=NULL) p=p->f[urm];
        ++p->n0;
    }
    antibfs(t);
    for(int i=1; i<=n; ++i)
        g<<final[i]<<'\n';
    return 0;
}
