#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream fin("ahocorasick.in");
ofstream fout("ahocorasick.out");

struct trie{
    int sol;
    trie* f[26];
    trie* back;
    vector <trie*> v;

    trie(){
        sol=0;
        for(int i=0;i<26;i++)
            f[i]=0;
        back=0;
        v.clear();
    }
};

trie* root=new trie();
char A[1000001],s[10001];
int n,i,j;
trie *w[101], *nod, *aux;
queue<trie*> Q;

trie* add(trie* r, char* s){
    if(! *s)
        return r;

    if(r->f[*s-'a']==0)
        r->f[*s-'a']=new trie();
    return add(r->f[*s-'a'],s+1);
}

void dfs(trie* nod){
    for(int i=0;i < nod->v.size(); i++){
        dfs(nod->v[i]);
        nod->sol+=nod->v[i]->sol;
    }
}

int main(){
    fin>>A;
    fin>>n;
    for(i=1;i<=n;i++){
        fin>>s;
        w[i]=add(root,s);
    }

    Q.push(root);
    while(!Q.empty()){
        nod=Q.front();
        Q.pop();

        for(i=0;i<26;i++){
            if(nod->f[i]!=0){
                aux=nod->back;
                while(aux && aux->f[i]==0)
                    aux=aux->back;

                if(aux==0)
                    nod->f[i]->back=root;
                else
                    nod->f[i]->back=aux->f[i];

                nod->f[i]->back->v.push_back(nod->f[i]);
                Q.push(nod->f[i]);
            }
        }
    }

    aux=root;
    for(i=0;A[i]!=0;i++){
        while(aux!=root && aux->f[A[i]-'a']==0)
            aux=aux->back;
        if(aux->f[A[i]-'a']!=0)
            aux=aux->f[A[i]-'a'];
        aux->sol++;
    }

    dfs(root);

    for(i=1;i<=n;i++)fout<<w[i]->sol<<"\n";

    return 0;
}
