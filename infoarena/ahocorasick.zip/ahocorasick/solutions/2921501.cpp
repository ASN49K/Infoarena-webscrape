#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;
int ap[101];
struct Trie{
    bool exis;
    vector <int> care;
    int fiu[26],tata; 
    int fail;
    int green;
    Trie(int daddy){
        for(int i=0;i<26;i++)
            fiu[i]=-1;
        fail=-1;
        tata=daddy;
        exis=0;
    }
};
queue <int> coada;
vector <Trie> copac;
char s[1000001];
char a[10001];
int main()
{
    freopen("ahocorasick.in","r",stdin);
    freopen("ahocorasick.out","w",stdout);
    fgets(s,1000001,stdin);
    int i,q;
    cin>>q>>ws;
    Trie root(-1);
    copac.push_back(root);
    for(i=1;i<=q;i++)
    {
        fgets(a,10001,stdin);
        int n=strlen(a)-1;
        int nod=0;
        for(int j=0;j<n;j++)
        {
            if(copac[nod].fiu[a[j]-'a']==-1)
            {
                Trie urm(nod);
                copac.push_back(urm);
                copac[nod].fiu[a[j]-'a']=copac.size()-1;
            }
            nod=copac[nod].fiu[a[j]-'a'];
        }
        copac[nod].care.push_back(i);
        copac[nod].exis=1;
    }
    for(i=0;i<26;i++)
        if(copac[0].fiu[i]==-1)
            copac[0].fiu[i]=0;
        else
        {
            coada.push(copac[0].fiu[i]);
            copac[copac[0].fiu[i]].fail=0;
            copac[copac[0].fiu[i]].green=0;
        }
    while(coada.size())
    {
        int cur=coada.front();
        coada.pop();
        for(i=0;i<26;i++)
            if(copac[cur].fiu[i]!=-1)
            {
                coada.push(copac[cur].fiu[i]);
                int inc=copac[cur].fail;
                while(copac[inc].fiu[i]==-1)
                    inc=copac[inc].fail;
                copac[copac[cur].fiu[i]].fail=copac[inc].fiu[i];
                if(copac[copac[inc].fiu[i]].exis)
                    copac[copac[cur].fiu[i]].green=copac[inc].fiu[i];
                else
                    copac[copac[cur].fiu[i]].green=copac[copac[inc].fiu[i]].green;
            }
    }
    int start=0;
    copac[0].green=0;
    int n=strlen(s)-1;
    for(i=0;i<n;i++)
    {
        while(copac[start].fiu[s[i]-'a']==-1)
            start=copac[start].fail;
        start=copac[start].fiu[s[i]-'a'];
        int interes=start;
        if(!copac[interes].exis)
            interes=copac[interes].green;
        while(interes)
        {
            for(auto it:copac[interes].care)
                ap[it]++;
            interes=copac[interes].green;
        }
    }
    for(i=1;i<=q;i++)
        cout<<ap[i]<<'\n';
    return 0;
}