#include <iostream>
#include <fstream>
#include <queue>
#include <list>
#include <vector>
using namespace std;

ifstream fin("ahocorasick.in");
ofstream fout("ahocorasick.out");

struct nod
{
  int cnt;
  std::vector<int> id;
  nod* back;
  nod* son['z'-'a'+1]={0};
};

char c[1005000];
char v[150][10500];
int countt[150];
nod * root;
int n,t;
char clear[10];
std::vector<nod *> q;

int main()
{
  fin.getline(c,1005000);
  fin>>n;
  fin.getline(clear,10);
  root= new nod;
  root->back= root;
  for(int i=0;i<n;i++)
  {
    fin.getline(v[i],10500);
    nod * nd= root;
    for(int j=0;v[i][j]!='\0';j++)
    {
      int ch= v[i][j]-'a';
      if(nd->son[ch]==0)
        nd->son[ch]=new nod;
      nd= nd->son[ch];
      if(v[i][j+1]=='\0')
        nd->id.push_back(i);
    }
  }
  q.push_back(root);
  for(int i=0;i<q.size();++i)
  {
    nod * tp= q[i];
    for(int i=0;i<='z'-'a';i++)
    {
      nod * u = tp->son[i];
      if(u!=0)
      {
        nod *nd= tp->back;
        while( nd!=root &&nd->son[i]==0)
          nd= nd->back;
        if(nd->son[i]!=0 && nd->son[i]!=u)
          nd=nd->son[i];
        u->back= nd;
        q.push_back(u);
      }
    }
  }
  root->back=0;
  nod *nd= root;
  for(int i=0;c[i]!='\0';i++)
  {
    int ch = c[i]-'a';
    while(nd->son[ch]==0 && nd!=root) nd= nd->back;
    if(nd->son[ch]!=0)
      nd=nd->son[ch];
    (nd->cnt)++;
  }//*//*
  /*
  for(int i=q.size()-1;i>0;i--)
  {
    nod * u =q[i];
    for(int it= 0;it!=u->id.size();++it )
      countt[u->id[it]]+=u->cnt;
    u->back->cnt+=u->cnt;
  }*/
  for(int i=0;i<n;i++)
    fout<<countt[i]<<"\n";
}
