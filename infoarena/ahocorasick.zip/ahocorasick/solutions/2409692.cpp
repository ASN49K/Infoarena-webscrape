#include <bits/stdc++.h>
using namespace std;

const int SIGMA = 26;
const int NMAX = 1000005;
const int MMAX = 10005;
const int QMAX = 105;

struct Node
{
  Node *son[SIGMA], *suffLink;
  int cnt; vector<Node*> edg;

  Node ()
  {
    suffLink = NULL; cnt = 0;
    memset(son, 0, sizeof son);
  }
};

Node *root;
char str[NMAX], aux[QMAX][MMAX];

void add (Node *&node, char *str, int l, int p = 1)
{
  if (node == NULL) {
    node = new Node(); }
  if (p == l + 1) {
    return; }
  add(node -> son[str[p] - 'a'], str, l, p + 1);
}

void build_aho (Node *root)
{
  deque<Node*> que; Node *node, *aux;
  for (que.assign(1, root); que.size(); que.pop_front()) {
    node = que.front();
    for (int i = 0; i < SIGMA; ++i) {
      if (node -> son[i] != NULL) {
        aux = node -> suffLink;
        while (aux != NULL && aux -> son[i] == NULL) {
          aux = aux -> suffLink; }
        if (aux == NULL) {
          node -> son[i] -> suffLink = root; }
        else {
          node -> son[i] -> suffLink = aux -> son[i]; }
        (node -> son[i] -> suffLink -> edg).push_back(node -> son[i]);
        que.push_back(node -> son[i]); } } }
}

void dfs (Node *node)
{
  for (Node *next : node -> edg) {
    dfs(next); node -> cnt += next -> cnt; }
}

void run_aho (Node *root, char *str, int n)
{
  Node *node = root;
  for (int i = 1; i <= n; ++i) {
    while (node != root && node -> son[str[i] - 'a'] == NULL) {
      node = node -> suffLink; }
    if (node -> son[str[i] - 'a'] != NULL) {
      node = node -> son[str[i] - 'a']; }
    ++node -> cnt; }
  dfs(root);
}

int query (Node *node, char *str, int l, int p = 1)
{
  if (p == l + 1) {
    return node -> cnt; }
  else {
    return query(node -> son[str[p] - 'a'], str, l, p + 1); }
}

int main (void)
{
  freopen("ahocorasick.in", "r", stdin);
  freopen("ahocorasick.out", "w", stdout);
  scanf("%s", str + 1);
  int n = (int) strlen(str + 1);
  int q; scanf("%d", &q);
  root = new Node();
  for (int i = 1; i <= q; ++i) {
    scanf("%s", aux[i] + 1);
    add(root, aux[i], (int) strlen(aux[i] + 1)); }
  build_aho(root); run_aho(root, str, n);
  for (int i = 1; i <= q; ++i) {
    printf("%d\n", query(root, aux[i], (int) strlen(aux[i] + 1))); }
  return 0;
}
