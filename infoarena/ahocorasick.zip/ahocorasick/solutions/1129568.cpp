#include <fstream>
#include <iostream>
#include <string>
using namespace std;

int urmator[10001];
char x[1000001];
char p[10001];
long i,j,m,n;
void urmatorul (char *p)
{
	int i,j;
	urmator[0]=-1;
	for (i=1, j=0; i<n; i++,j++, urmator[i]=j)
		while (j>=0 and p[j]!=p[i])
			j=urmator[j];
}

long kmp ()
{
	long i,j,total=0;
	urmator[0]=-1;
	for (i=0, j=0; i<m; i++,j++)
	{
		while (j>=0 and p[j]!=x[i])
			j=urmator[j];
		if (j==n-1) total++;
	}
	return total;
}

int main ()
{
	int nr;
	long pkmp;
	ifstream f("ahocorasick.in");
	FILE *g;
	g=fopen("ahocorasick.out", "w");
	
	f>>x;
	f>>nr;
	m=strlen(x);
	for (;nr>0;--nr)
	{
		f>>p;
		n=strlen(p);
		urmatorul(p);
		pkmp=kmp();
		fprintf(g, "%d\n", pkmp);
	}
	f.close(); fclose(g);
	return 0;
}