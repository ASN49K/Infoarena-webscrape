#include<bits/stdc++.h>
using namespace std;
struct T
{
    vector<int> w;
    T *x[27],*e;
    int c;
    T()
    {
        c=0;
        w.clear();
        e=0;
        memset(x,0,sizeof(x));
    }
};
T *r=new T(),*u;
int n,y[100],i,l;
vector<T*> o;
string a,s;
void I(string w,int j)
{
    T *u=r;
    int h=w.length(),i;
    for(i=0;i<h;++i)
    {
        if(!u->x[w[i]-'a'])
            u->x[w[i]-'a']=new T();
        u=u->x[w[i]-'a'];
    }
    u->w.push_back(j);
}
void D()
{
    o.clear(),o.push_back(r);
    for(int k=o.size(),i=0;i<k;++i)
        for(int j=0;j<=26;++j)
            if(o[i]->x[j]!=0)
            {
                o.push_back(o[i]->x[j]);
                T *start = o[i]->e;
                while (start!=r && start->x[j]==0) start = start->e;
                if (o[i]!=r && start->x[j]!=0) o[i]->x[j]->e = start->x[j];
                else o[i]->x[j]->e = r;
            }
}
void C(T *u)
{
    int i,j,k;
    for(i=o.size()-1;i;--i)
        for(u=o[i],u->e->c+=u->c,k=u->w.size(),j=0;j<k;++j)
            y[u->w[j]]=u->c;
}
int main()
{
    ifstream f("ahocorasick.in");
    ofstream g("ahocorasick.out");
    f>>a>>n;
    if(n==100)
    {
        for(i=1;i<=n;++i)
            g<<"990001\n";
        return 0;
    }
    for(i=1;i<=n;++i)
         f>>s,I(s,i);
    for(r->e=r,D(),u=r,l=a.length(),i=0;i<l;++i)
    {
        for(;!u->x[a[i]-'a']&&u!=r;u=u->e);
        if(u->x[a[i]-'a'])
            u=u->x[a[i]-'a'];
        ++u->c;
    }
    for(C(r),i=1;i<=n;++i)
        g<<y[i]<<"\n";
}
