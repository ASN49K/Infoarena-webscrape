#define WMAX 10005
#define AMAX 1000005

char p[WMAX];
char c[WMAX];
char tx[AMAX];
int lg,lgc,n;

void pf() {
  for (int i = 2,q = 0; i <= lgc; ++i) {
    for(;q != 0 && c[i] != c[q+1]; q = p[q]);
    if (c[i] == c[q+1]) ++q;
    p[i] = q;
  }
}


using namespace std;

// To execute C++, please define "int main()"
int main() {  	
  freopen("ahocorasick.in","r",stdin);
  freopen("ahocorasick.out","w",stdout);
  scanf("%s %d",tx+1, &n);
  lg = strlen(tx+1);
  
  for (int k=1; k<=n; ++k) {
    scanf("%s",c+1);
    lgc = strlen(c+1);
    for (int i = 0; i <= lgc; ++i) {
      p[i] = 0;
    }
    pf();
    int matches = 0;
    for (int i=1,q=0; i <= lg; ++i) {
      for (;q!=0 && c[q+1] != tx[i]; q = p[q]);
      if (c[q+1] == tx[i]) q++;
      if (q == lgc) {
        matches++;
      }
    }
    printf("%d\n",matches);
  }
  return 0;
}