#include <cstdio>
#include <cstring>
#include <cctype>

FILE *fin, *fout;

#define LGA 1000000
#define LGC 10000
#define MAXN 100

char a[LGA + 5];
int m, n;

#define sigma 26

struct trie  {
    trie *fail, *fii[sigma];
    int nr;
    trie()  {
        fail = 0;
        nr = 0;
        memset(fii, 0, sizeof fii);
    }
};

trie *root, *ans[MAXN + 1];
trie *q[LGC * MAXN + 1];
int st, dr;

inline void Fail()  {
    st = 1, dr = 0;
    for(int i = 0;i < sigma;i++)  {
        if(root -> fii[i])  {
            root -> fii[i] -> fail = root;
            q[++dr] = root -> fii[i];
        }
    }
    while(st <= dr)  {
        for(int i = 0;i < sigma;i++)  {
            if(q[st] -> fii[i])  {
                q[++dr] = q[st] -> fii[i];
                trie *aux;
                aux = q[st] -> fail;
                while(aux -> fii[i] == 0 && aux != root)  {
                    aux = aux -> fail;
                }
                if(aux -> fii[i])  {
                    q[st] -> fii[i] -> fail = aux -> fii[i];
                }
                else
                    q[st] -> fii[i] -> fail = root;
            }
        }
        st++;
    }
}

int main()  {
    fin = fopen("ahocorasick.in", "r");
    fout = fopen("ahocorasick.out", "w");
    fgets(a + 1, LGA + 3, fin);
    m = strlen(a + 1) - 1;
    fscanf(fin, "%d", &n);
    fgetc(fin);
    root = new trie;
    trie *aux;
    for(int i = 1;i <= n;i++)  {
        char ch = fgetc(fin);
        aux = root;
        while(isalpha(ch))  {
            if(aux -> fii[ch - 'a'] == 0)  {
                aux -> fii[ch - 'a'] = new trie;
            }
            aux = aux -> fii[ch - 'a'];
            ch = fgetc(fin);
        }
        ans[i] = aux;
    }
    Fail();
    aux = root;
    for(int i = 1;i <= m;i++)  {
        while(aux != root && aux -> fii[a[i] - 'a'] == 0)
            aux = aux -> fail;
        if(aux -> fii[a[i] - 'a'])  {
            aux = aux -> fii[a[i] - 'a'];
        }
        aux -> nr++;
    }
    for(int i = dr;i;i--)  {
        q[i] -> fail -> nr += q[i] -> nr;
    }
    for(int i = 1;i <= n;i++)
        fprintf(fout, "%d\n", ans[i] -> nr);
    fclose(fin);
    fclose(fout);
    return 0;
}
