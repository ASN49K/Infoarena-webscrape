#include <bits/stdc++.h>

using namespace std;

struct nod_trie{
    int opriri;
    nod_trie *fiu[26],*fail;
    nod_trie(){
        opriri = 0;
        fail = 0;
        memset(fiu,0,sizeof(fiu));
    }
};

nod_trie *t = new nod_trie,*p;
nod_trie *capat_cuvant[105] , *q[10000000];

char cuv[1000005] , dic[10005];
int n,i,inc,fin;

inline void add(nod_trie *nod,char *c){
    while(*c != '\0'){
        if(  !nod->fiu[*c - 'a'] )
              nod->fiu[*c - 'a'] = new nod_trie;
        nod = nod->fiu[*c - 'a'];
        ++c;
    }
    capat_cuvant[i] = nod;
}

inline void bfs(nod_trie *nod){
    int i;
    nod_trie *tmp,*fail;
    nod->fail = nod;
    for( q[ inc = fin = 1] = nod ; inc <= fin ; ++inc ){
        tmp = q[inc];
        for(i=0;i<26;++i){
            if( !tmp->fiu[i] ) continue;
            for(fail = tmp->fail ; fail->fiu[i] == 0 && fail != nod;fail = fail->fail);
                if(fail != tmp  && fail->fiu[i]) fail = fail->fiu[i];
                tmp->fiu[i]->fail = fail;
                q[++fin] = tmp->fiu[i];
        }
    }
    nod->fail = NULL;
}



int main()
{
    freopen("ahocorasick.in" , "r" , stdin);
    freopen("ahocorasick.out", "w" , stdout);

    scanf("%s\n%d",&cuv,&n);
    for(i=1;i<=n;++i){
        scanf("%s\n",dic);
        add(t,dic);
    }

    bfs(t);
    p = t;

    for(i=0; cuv[i] ; ++i){
        for( ; !(p->fiu[cuv[i]-'a']) && p!=t; p = p->fail);
        if( p->fiu[cuv[i]-'a'] )
            p = p->fiu[cuv[i]-'a'];
        ++(p->opriri);
    }
    for(i = fin ; i ; --i){
        if( q[i]->fail )
            q[i]->fail->opriri += q[i]->opriri;
    }
    for(i=1;i<=n;++i)
        printf("%d\n",capat_cuvant[i]->opriri);



    return 0;
}
