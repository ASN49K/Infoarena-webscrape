#include <iostream>
#include <fstream>
#include <tuple>
#include <queue>
#include <vector>

const int MAXLIT = 27;
const int MAXN = 101;

using namespace std;

ifstream in("ahocorasick.in");
ofstream out("ahocorasick.out");


struct Nod{
    Nod *muchii[MAXLIT];
    Nod *suffixLink;
    int aparitii = 0;
    string s;
    char val;
    Nod(){
        val = '@';
        s = "";
        suffixLink = nullptr;
        for(int i = 0; i < MAXLIT; i++)
            muchii[i] = nullptr;
    }
};
class Trie{
public:

    Trie(){
        radacina = new Nod();
        radacina->suffixLink = radacina;
    }
    void adauga(string sir){
        Nod *nod = radacina;
        for(char caracter : sir){
            int poz = caracter - 'a';
            if(nod->muchii[poz] != nullptr){
                nod = nod->muchii[poz];
            }else{
                Nod *nou = new Nod();
                nou->val = caracter;
                nou->s = nod->s + caracter;
                nod->muchii[poz] = nou;
                nod = nod->muchii[poz];
            }
        }
    }
    int numarAparitii(string sir){
        Nod *nod = radacina;
        for(char caracter : sir){
            int poz = caracter - 'a';
            nod = nod->muchii[poz];
        }
        return nod->aparitii;
    }
    void construiesteFailureLink(){
        /// tuple de Nod, Tata si Caracter Curent
        queue<tuple<Nod*,Nod*,char>>coada;
        for(int i = 0; i < MAXLIT; i++)
            if(radacina->muchii[i] != nullptr){
                coada.push(make_tuple(radacina->muchii[i],radacina,'a' + i));
            }
        while(coada.size()){
            auto it = coada.front();
            Nod *curent = get<0>(it);
            Nod *tata = get<1>(it);
            char x = get<2>(it);
            coada.pop();

            Nod *fail = tata->suffixLink;
            while(!areCaracterul(fail,x)){
                if(fail == radacina)
                    break;
                fail = fail->suffixLink;
            }
            if(areCaracterul(fail,x) && fail->muchii[x - 'a'] != nullptr && fail->muchii[x - 'a'] != curent){
                fail = fail->muchii[x - 'a'];
            }
            curent->suffixLink = fail;
//            cout<<curent->s<<" -> ";
//            if(fail == radacina)
//                cout<<"radacina"<<endl;
//            else
//                cout<<fail->s<<endl;
            for(int i = 0; i < MAXLIT; i++){
                if(curent->muchii[i] != nullptr){
                    coada.push(make_tuple(curent->muchii[i],curent,i + 'a'));
                }
            }
        }
    }
    void rezolva(string input){
        Nod *nod = radacina;

        int index = 0;
        for(char caracter : input){
            int poz = caracter - 'a';
            index++;
            if(areCaracterul(nod,caracter)){

                if(nod->muchii[poz] != nullptr){
                    nod = nod->muchii[poz];
                    nod->aparitii++;
                }else
                    nod->aparitii++;
            }
            else{
                /// ma duc pe un pe fail si vad daca am caracterul in continuare
                while(!areCaracterul(nod,caracter)){
                    if(nod == radacina)
                        break;
                    nod = nod->suffixLink;
                }
//                cout<<index<<" "<<nod->s<<endl;

                if(nod->muchii[poz] != nullptr){
                    nod = nod->muchii[poz];
                    nod->aparitii++;
                }

            }
        }
    }
    void aparitii(){
        calculeazaAparitii(radacina);
    }
    void afisare(){
        print(radacina);
    }

private:
    Nod *radacina;

    bool areCaracterul(Nod *nod,char c){
        if(nod->val == c)
            return true;
        int pozitie = c - 'a';
        if(nod->muchii[pozitie] != nullptr)
            return true;
        return false;
    }
    void print(Nod *nod){
        cout<<nod->s<<" "<<nod->aparitii<<endl;
        for(int i = 0; i < MAXLIT; i++){
            if(nod->muchii[i] != nullptr){
                print(nod->muchii[i]);
            }
        }
    }
    void calculeazaAparitii(Nod *nod){
        for(int i = 0; i < MAXLIT; i++){
            Nod* vecin = nod->muchii[i];
            if(vecin != nullptr){
                calculeazaAparitii(vecin);
                vecin->suffixLink->aparitii += vecin->aparitii;
            }
        }
    }

};

int main()
{
    string input;
    int n;
    in>>input>>n;
    Trie *trie = new Trie();
    vector<string>cuvinte(n + 1);
    for(int i = 1; i <= n; i++){
        in>>cuvinte[i];
        trie->adauga(cuvinte[i]);
    }
    trie->construiesteFailureLink();
    trie->rezolva(input);
    trie->aparitii();
    for(int i = 1; i <= n; i++)
        out<<trie->numarAparitii(cuvinte[i])<<"\n";

    return 0;
}
