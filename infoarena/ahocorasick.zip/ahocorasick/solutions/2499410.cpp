#include <fstream>
#include <string>
#include <cstring>
#include <vector>
#include <queue>
#include <stack>
#include <cassert>

using namespace std;

ifstream cin ("ahocorasick.in");
ofstream cout ("ahocorasick.out");
struct TRIE
{
    int frecv;
    TRIE *next[26];
    TRIE *link;
    TRIE()
    {
        frecv = 0;
        link = nullptr;
        memset(next, 0, sizeof(next));
    }
};

TRIE *root = new TRIE();

vector <TRIE*> leafs;

void insert_letter(TRIE *&node, const string &s, int poz)
{
    if(poz == s.size()) {
        leafs.push_back(node);
        return;
    }
    int next_node = s[poz] - 'a';
    if(node -> next[next_node] == nullptr) {
        node -> next[next_node] = new TRIE();
    }
    insert_letter(node -> next[next_node], s, poz + 1);
}

int main()
{
    string d;
    int n;
    cin>>d>>n;
    for(int i = 1; i <= n; ++i) {
        string s;
        cin>>s;
        insert_letter(root, s, 0);
    }
    queue <TRIE*> q;
    stack <TRIE*> st;
    q.push(root);
    while(!q.empty()) {
        auto a = q.front();
        st.push(a);
        q.pop();
        for(int i = 0; i < 26; ++i) {
            if(a -> next[i] != nullptr) {
                auto aux = a -> link;
                auto p = a -> next[i];
                while(aux != nullptr && aux != root && aux -> next[i] == nullptr) {
                    aux = aux -> link;
                }
                if(aux == root || aux == nullptr) {
                    aux = root;
                    if(p != root -> next[i] && root -> next[i] != nullptr)
                        p -> link = root -> next[i];
                    else
                        p -> link = root;
                }
                else
                    p -> link = aux -> next[i];
                assert(p -> link != nullptr);
                q.push(p);
            }
        }
    }
    auto curr = root;
    for(int i = 0; i < d.size(); ++i) {
        if(curr == nullptr)
            curr = root;
        while(curr != root && curr != nullptr && curr -> next[d[i] - 'a'] == nullptr)
            curr = curr -> link;
        if(curr != nullptr && curr -> next[d[i] - 'a'] != nullptr) {
            curr = curr -> next[d[i] - 'a'];
            curr -> frecv += 1;
        }
    }
    root -> link = root;
    while(st.size()) {
        auto vf = st.top();
        st.pop();
        vf -> link -> frecv += vf -> frecv;
    }
    for(auto x: leafs)
        cout<<x -> frecv<<"\n";
    return 0;
}
