#include <fstream>
#include <iostream>
#include <queue>
#include <vector>

using namespace std;
ifstream fin("ahocorasick.in");
ofstream fout("ahocorasick.out");



struct trie {
    int nr;
    trie *f[26], *back;
    vector<trie*> v;
    trie() {
        nr = 0;
        back = 0;
        for (int i=0;i<26;i++)
            f[i] = 0;
    }
};

char A[1000010];
trie *r = new trie, *nod, *aux;
trie *W[102];
queue<trie *> Q;
char s[10002];
int n, i;

trie *insert (trie *nod, char *p) {
    if (*p == 0) {
        return nod;
    }
    if (nod->f[*p-'a'] == 0)
        nod->f[*p-'a'] = new trie;
    return insert(nod->f[*p-'a'], p+1);
}

void dfs(trie *nod) {
    for (int i = 0; i<nod->v.size(); i++) {
        dfs(nod->v[i]);
        nod->nr+=nod->v[i]->nr;
    }
    //cout<<nod->nr<<"\n";

}

int main (){
    fin>>A;

    fin>>n;
    for (i=1;i<=n;i++) {
        fin>>s;
        W[i] = insert(r, s);
    }

    Q.push(r);
    while (!Q.empty()) {
        nod = (trie*)Q.front();
        Q.pop();
        // calculez back ta toti fii lui nod si apoi ii pun pe acestia in coada
        for (i=0;i<26;i++)
            if (nod->f[i]) {
                aux = nod->back;
                while (aux && aux->f[i]==0)
                    aux = aux->back;

                if (!aux)
                    nod->f[i]->back = r;
                else
                    nod->f[i]->back = aux->f[i];

                nod->f[i]->back->v.push_back(nod->f[i]);
                Q.push(nod->f[i]);
            }
    }
    char *p;
    for (p = A, aux = r; *p!=0;p++) {
        while(aux && aux->f[*p-'a'] == 0)
            aux = aux->back;

        if (aux == 0)
            aux = r;
        else
            aux = aux->f[*p-'a'];

        aux->nr++;

    }

    dfs(r);

    for (i=1;i<=n;i++)
        fout<<W[i]->nr<<"\n";

    return 0;
}
