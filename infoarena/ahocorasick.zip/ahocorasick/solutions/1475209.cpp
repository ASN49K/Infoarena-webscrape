# include <bits/stdc++.h>
using namespace std;
# define db double
# define ll long long
# define pi 3.14159265359
# define rad(x) (x * pi / 180)
const int p_1[] = {1,-1};
const ll mod1 = 100000004987ll;
const int mod2 = 1e9 + 7;
const int mod3 = 666013;
const int mod4 = 997;
const int mod5 = 1000004123;
template < class T > inline T sqr(T x) {return x*x;}
template < class T > inline T min(T a,T b,T c) {return min(a,min(b,c));}
template < class T > inline T min(T a,T b,T c,T d) {return min(min(a,b),min(b,c));}
template < class T > inline T max(T a,T b,T c) {return max(a,max(b,c));}
template < class T > inline T max(T a,T b,T c,T d) {return max(max(a,b),max(b,c));}
template < class T > inline T det(T a,T b,T c,T d) {return a * c - b * d;}
template < class T > inline T det(T s[3][3])
{
    return - s[0][0] * det(s[1][1],s[1][2],s[2][1],s[2][2]) + s[0][1] * det(s[1][0],s[1][2],s[2][0],s[2][2]) - s[0][2] * det(s[1][0],s[1][1],s[2][0],s[2][1]);
}
template < class T1 , class T2 , class T3 > inline T3 pow(T1 a,T2 b,T3 mod) {T3 ans = 1;while (b){if (b&1) ans = (1LL * ans * a) % mod;a = (1LL * a * a) % mod;b >>= 1;}return ans;}
template < class T > T phi(T n){T cnt = n,p = n,ans = n;for (T i = 2;i*i <= p;++i)if (!(cnt%i)){ans /= i;ans *= (i-1);while (!(cnt%i)) cnt /= i;}if (cnt > 1) ans /= cnt,ans *= (cnt - 1);return ans;}
template < class T > T f(T a,T b) {return a < b ? 0 : a / b + f(a / b);}
template < class T > T gcd(T a,T b) {return __gcd(a,b);}
class Reader {
  public:
    Reader(const string& filename):
            m_stream(filename),
            m_pos(kBufferSize - 1),
            m_buffer(new char[kBufferSize]) {
        next();
    }

    Reader& operator>>(int& value) {
        value = 0;
        while (current() < '0' || current() > '9')
            next();
        while (current() >= '0' && current() <= '9') {
            value = value * 10 + current() - '0';
            next();
        }
        return *this;
    }

  private:
    const int kBufferSize = 32768;

    char current() {
        return m_buffer[m_pos];
    }

    void next() {
        if (!(++m_pos != kBufferSize)) {
            m_stream.read(m_buffer.get(), kBufferSize);
            m_pos = 0;
        }
    }

    ifstream m_stream;
    int m_pos;
    unique_ptr<char[]> m_buffer;
};
struct automat
{
    int link,len;
    map < char , int > next;
} s[2000005];
vector < int > dp;
int last,n;
void go(char ch)
{
    int nw = ++n;
    dp.push_back(1);
    int g = last;
    s[nw].len = s[last].len + 1;
    for (;g != -1 && !s[g].next.count(ch);g = s[g].link) s[g].next[ch] = nw;
    if (g == -1) s[nw].link = 0;
    else
    {
        int to = s[g].next[ch];
        if (s[to].len == s[g].len+1) s[nw].link = to;
        else
        {
            int clon = ++n;
            dp.push_back(0);
            s[clon] = s[to];
            s[clon].len = s[g].len+1;
            for (;g != -1 && to == s[g].next[ch];g = s[g].link) s[g].next[ch] = clon;
            s[to].link = s[nw].link = clon;
        }
    }
    last = nw;
}
char c[1000005];
char d[10005];
int rs(void)
{
    int vertex = 0;
    int k = 1,len = strlen(d+1);
    while (k <= len)
    {
        if (!s[vertex].next.count(d[k])) return 0;
        vertex = s[vertex].next[d[k]];
        ++k;
    }
    return dp[vertex];
}
vector < vector < int > > inv;
int get(int k)
{
    if (inv[k].empty()) return dp[k];
    for (auto it : inv[k]) dp[k] += get(it);
    return dp[k];
}
int main(void)
{
    dp.push_back(0);
    s[0].link = -1;
    freopen("ahocorasick.in","r",stdin);
    ofstream fo("ahocorasick.out");
    gets(c+1);
    for (int i = 1;c[i];++i) go(c[i]);
    int t;
    scanf("%d\n",&t);
    inv.resize(n+5);
    for (int i = n;i;--i) if (s[i].link != -1) inv[s[i].link].push_back(i);
    dp[0] = get(0);
    while (t --)
    {
        gets(d+1);
        fo << rs() << '\n';
    }
    return 0;
}

