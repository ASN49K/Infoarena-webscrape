#include <fstream>
#include <vector>
#include <cstring>
using namespace std;

ifstream f("ahocorasick.in");
ofstream g("ahocorasick.out");

int n,rez[101];
string s,c;

struct trie{
    trie *f[26],*fail;
    int val;
    vector<int> P;
    trie()
    {
        memset(f,0,sizeof(f));
        fail = NULL;
        val = 0;
    }
}*T;
vector<trie*> C;


void add(int index)
{
    trie *nod = T;
    for (int i=0;i<c.size();i++)
    {
        if (nod->f[c[i]-'a']==NULL)
            nod->f[c[i]-'a'] = new trie();
        nod = nod->f[c[i]-'a'];
    }
    nod->P.push_back(index);
}

void bfs()
{
    trie *nod;
    C.push_back(T);
    T->fail = T;
    for (int i=0;i<C.size();i++)
    {
        for (int k=0;k<26;k++)
        {
            if (C[i]->f[k]!=NULL)
            {
                nod = C[i]->fail;
                while (nod->f[k]==NULL && nod!=T)
                    nod = nod->fail;
                if (nod->f[k]!=NULL && nod->f[k]!=C[i]->f[k])
                    nod = nod->f[k];
                C[i]->f[k]->fail = nod;
                C.push_back(C[i]->f[k]);
            }
        }
    }
}

void bfs2()
{
    for (int i=C.size()-1;i>=0;i--)
    {
        if (C[i]->fail!=NULL)
            C[i]->fail->val += C[i]->val;
        for (int j = 0;j<C[i]->P.size();j++)
            rez[C[i]->P[j]]+=C[i]->val;
    }
}

int main()
{
    f>>s;
    f>>n;
    T = new trie();
    for (int i=1;i<=n;i++)
    {
        f>>c;
        add(i);
    }

    bfs();

    trie *nod = T;
    for (int i=0;i<s.size();i++)
    {
        while (nod->f[s[i]-'a']==NULL && nod!=T)
            nod = nod->fail;
        if (nod->f[s[i]-'a']!=NULL)
            nod = nod->f[s[i]-'a'];
        nod->val++;
    }

    bfs2();

    for (int i=1;i<=n;i++)
        g<<rez[i]<<'\n';

    return 0;
}
