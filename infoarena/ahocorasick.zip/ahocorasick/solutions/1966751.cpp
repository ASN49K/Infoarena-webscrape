﻿#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
#include <algorithm>
#include <cmath>

#define MaxN 105
#define MaxW 10005
#define Sigma 26
#define MaxL 1000005

using namespace std;

FILE *IN,*OUT;

int N;
char word[MaxW],String[MaxL+5];
struct Trie
{
	int fr;
	Trie *Son[Sigma],*pi;
	Trie()
	{
		fr=0;
		memset(Son,0,sizeof Son);
		pi=NULL;
	}
}*Root,*Pos[MaxN];
queue<Trie*>Q;
vector<Trie*>Rev;
void Insert(Trie *node,char *w,int index)
{
	if(node->Son[*w-'a']==NULL)
		node->Son[*w-'a']=new Trie;
	if(*w==0)
		Pos[index]=node;
	else Insert(node->Son[*w-'a'],w+1,index);
}
void Get_Pi()
{
	Trie *aux,*node;
	for(int i=0;i<Sigma;i++)
		if(Root->Son[i]!=NULL)
		{
			Q.push(Root->Son[i]);
			Root->Son[i]->pi=Root;
			Rev.push_back(Root->Son[i]);
		}
	while(!Q.empty())
	{
		node=Q.front();
		Q.pop();
		for(int i=0;i<Sigma;i++)
			if(node->Son[i]!=NULL)
			{
				Rev.push_back(node->Son[i]);
				Q.push(node->Son[i]);
				aux=node->pi;
				while(aux!=Root&&aux->Son[i]==NULL)
					aux=aux->pi;
				if(aux->Son[i]!=NULL)
					node->Son[i]->pi=aux->Son[i];
				else node->Son[i]->pi=Root;
			}
	}
}
int main()
{
	IN=fopen("ahocorasick.in","r");
	OUT=fopen("ahocorasick.out","w");

	fscanf(IN,"%s",String);
	fscanf(IN,"%d",&N);
	Root=new Trie;
	for(int i=1;i<=N;i++)
	{
		fscanf(IN,"%s",word);
		Insert(Root,word,i);
	}
	Get_Pi();
	Trie *node=Root;
	for(int i=0;String[i]!=0;i++)
	{
		int next=String[i]-'a';
		while(node->Son[next]==NULL&&node!=Root)
			node=node->pi;
		if(node->Son[next]!=NULL)
			node=node->Son[next];
		node->fr++;
	}

	for(int i=Rev.size()-1;i>=0;i--)
		Rev[i]->pi->fr+=Rev[i]->fr;
	
	for(int i=1;i<=N;i++)
		fprintf(OUT,"%d\n",Pos[i]->fr);
	return 0;
}