#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("ahocorasick.in");
ofstream fout("ahocorasick.out");

struct trie{
    int sol;
    trie *f[26];
    trie *inapoi;
    vector <trie *>v;
    trie(){
        sol=0;
        for(int i=0; i<26; i++){
            f[i]=NULL;
        }
        inapoi=0;
        v.clear();
    }
};

trie *AdaugaCuvant(trie *nod, char *sir){
    if(*sir!=0){
        if(nod->f[*sir-'a']==NULL){
            nod->f[*sir-'a']=new trie;
        }
        return AdaugaCuvant(nod->f[*sir-'a'], sir+1);
    }
    else{
        return nod;
    }
}


void dfs(trie *nod){
    for(int i=0;i<nod->v.size();i++){
        dfs(nod->v[i]);
        nod->sol += nod->v[i]->sol;
    }
}

char propozitie[1000010], cuvant[10010];
int n;
trie *date = new trie();
trie *w[110], *nod, *aux;
queue <trie *> coada;

int main(){
    fin>>propozitie;
    fin>>n;

    for(int i=1; i<=n; i++){
        fin>>cuvant;
        w[i]=AdaugaCuvant(date, cuvant);
    }

    coada.push(date);
    while(!coada.empty()){
        nod=coada.front();
        coada.pop();
        for(int i=0; i<26; i++){
            if(nod->f[i]){
                aux=nod->inapoi;
                while(aux && aux->f[i]==0){
                    aux=aux->inapoi;
                }
                if(aux==0){
                    nod->f[i]->inapoi=date;
                }
                else{
                    nod->f[i]->inapoi=aux->f[i];
                }
                nod->f[i]->inapoi->v.push_back(nod->f[i]);
                coada.push(nod->f[i]);
            }
        }
    }

    aux=date;
    for(int i=0; propozitie[i]!=0; i++){
        int caracter=propozitie[i]-'a';
        while(aux!=date && !(aux->f[caracter])){
            aux=aux->inapoi;
        }
        if(aux->f[caracter]){
            aux=aux->f[caracter];
        }
        aux->sol++;
    }

    dfs(date);

    for(int i=1;i<=n;i++){
        fout<<w[i]->sol<<"\n";
    }
}
