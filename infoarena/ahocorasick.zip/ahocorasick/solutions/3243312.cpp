#include <bits/stdc++.h>

using namespace std;
ifstream fin("ahocorasick.in");
ofstream fout("ahocorasick.out");
int go(int me, int lit);
int getsuf(int me);
string v;
int n,where[105];
struct node
{
	int go[26];
	int par,niv;
	int lit;
	int suflink;
	int dp;
} emp;
vector<node> t;
bool comp(int a,int b)
{
	return t[a].niv>t[b].niv;
}
int newnode()
{
	int x=t.size();
	t.push_back(emp);
	return x;
}
void add(string s,int ind)
{
	int me=0;
	for(char c:s)
	{
		int lit=c-'a';
		if(t[me].go[lit]==-1)
		{
			int x=newnode();
			t[me].go[lit]=x;
			t[x].par=me;
			t[x].lit=lit;
			t[x].niv=t[me].niv+1;
		}
		me=t[me].go[lit];
	}
	where[ind]=me;
}
int go(int me,int lit)
{
	if(t[me].go[lit]!=-1)
		return t[me].go[lit];
	if(me==0)
		return 0;
	t[me].go[lit]=go(getsuf(me),lit);
	return t[me].go[lit];
}
int getsuf(int me)
{
	if(t[me].suflink!=-1)
		return t[me].suflink;
	if(me==0||t[me].par==0)
		return 0;
	t[me].suflink=go(getsuf(t[me].par),t[me].lit);
	return t[me].suflink;
}
int main()
{
	ios_base::sync_with_stdio(false);
	fin.tie(0);
	for(int i=0;i<26;i++)
		emp.go[i]=-1;
	emp.par=0;
	emp.suflink=-1;
	emp.dp=0;
	t.push_back(emp);
	fin>>v;
	fin>>n;
	for(int i=1;i<=n;i++)
	{
		string s;
		fin>>s;
		add(s,i);
	}
	int me=0;
	for(char c:v)
	{
		me=go(me,c-'a');
		t[me].dp++;
	}
	vector<int> ord;
	for(int i=1;i<t.size();i++)
		ord.push_back(i);
	sort(ord.begin(),ord.end(),comp);
	for(int nod:ord)
		t[getsuf(nod)].dp+=t[nod].dp;
	for(int i=1;i<=n;i++)
		fout<<t[where[i]].dp<<'\n';
	return 0;
}
