#include <bits/stdc++.h>

using namespace std;

ifstream fin ("ahocorasick.in");
ofstream fout ("ahocorasick.out");

struct Trie {
  int cuv;
  Trie* fii[26];
  Trie *fail;
  Trie () {
    cuv = 0;
    fail = NULL;
    for (int i = 0; i < 26; i++)
      fii[i] = NULL;
  }
} *root;

Trie* add (string s, int i) {
  Trie* p = root;
  for (int i = 0; i < s.size(); i++) {
    if (p -> fii[s[i] - 'a'] == NULL)
      p -> fii[s[i] - 'a'] = new Trie;
    p = p -> fii[s[i] - 'a'];
  }
  p -> cuv = i;
  return p;
}

int n, ans[103];
string s, a;

int main()
{
  fin >> s >> n;
  root = new Trie;
  for (int i = 1; i <= n; i++) {
    fin >> a;
    add(a, i);
  }
  queue<Trie*>q;
  root -> fail = NULL;
  for (int i = 0; i < 26; i++) {
    if (root -> fii[i] != NULL) {
      root -> fii[i] -> fail = root;
      q.push(root -> fii[i]);
    }
  }
  while (!q.empty()) {
    Trie* nod = q.front();
    q.pop();
    for (int i = 0; i < 26; i++) {
      if (nod -> fii[i] != NULL) {
        q.push(nod -> fii[i]);
        Trie* aux = nod -> fail;
        while (aux != root && aux -> fii[i] == NULL)
          aux = aux -> fail;
        if (aux -> fii[i] != NULL)
          nod -> fii[i] -> fail = aux -> fii[i];
        else
          aux -> fii[i] -> fail = root;
      }
    }
  }
  Trie* p = root;
  for (int i = 0; i < s.size(); i++) {
    while(p != root && p -> fii[s[i] - 'a'] == NULL)
      p = p -> fail;
    if (p -> fii[s[i] - 'a'] != NULL)
      p = p -> fii[s[i] - 'a'];
    else
      p = root;
    Trie* aux = p;
    while (aux != root) {
      ans[aux -> cuv]++;
      aux = aux -> fail;
    }
  }
  for (int i = 1; i <= n; i++)
    fout << ans[i] << "\n";
  return 0;
}
