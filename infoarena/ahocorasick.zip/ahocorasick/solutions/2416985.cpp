#include <bits/stdc++.h>
#define maxL 10002
#define maxN 1000002
#define maxW 102
#define SIGMA 26

using namespace std;


FILE *fin = freopen("ahocorasick.in", "r", stdin);
FILE *fout = freopen("ahocorasick.out", "w", stdout);

int n;
char a[maxN], s[maxL];

struct Trie
{
    int cnt;
    Trie *fLink, *sons[SIGMA];
    vector < int > idx;
} *Root;
queue < Trie* > Q;
vector < Trie* > outQ;

int frq[maxW];


Trie* new_emptyNode()
{
    Trie *node = new Trie();
    node->fLink = NULL;
    for (int c = 0; c < SIGMA; ++ c)
        node->sons[c] = NULL;
    node->cnt = 0;
}
void insert(Trie *node, char *w, int id)
{
    if (*w == NULL)
    {
        node->idx.push_back(id);
        return ;
    }
    if (node->sons[*w - 'a'] == NULL)
        node->sons[*w - 'a'] = new_emptyNode();
    insert(node->sons[*w - 'a'], w + 1, id);
}
void compFail()
{
    Root->fLink = Root;
    for (int ch = 0; ch < SIGMA; ++ ch)
        if (Root->sons[ch] != NULL)
        {
            Root->sons[ch]->fLink = Root;
            Q.push(Root->sons[ch]);
        }
    outQ.push_back(Root);
    while (!Q.empty())
    {
        Trie *node = Q.front();
        Q.pop();
        outQ.push_back(node);
        for (int ch = 0; ch < SIGMA; ++ ch)
            if (node->sons[ch] != NULL)
            {
                Trie *nxt = node->fLink;

                while (nxt != Root && nxt->sons[ch] == NULL)
                    nxt = nxt->fLink;
                if (nxt->sons[ch] != NULL)
                    node->sons[ch]->fLink = nxt->sons[ch];
                else node->sons[ch]->fLink = Root;
                Q.push(node->sons[ch]);

            }
    }
}
void StrOcc()
{
    Trie* node = Root;
    int len = strlen(s);
    for (int i = 0; i < len; ++ i)
    {
        while (node != Root && node->sons[s[i] - 'a'] == NULL)
            node = node->fLink;
        if (node->sons[s[i] - 'a'] != NULL)
        {
            node = node->sons[s[i] - 'a'];
            node->cnt ++;
        }
    }
}
void compFrq()
{
    while (!outQ.empty())
    {
        Trie *node = outQ.back();
        outQ.pop_back();
        for (int id : node->idx)
            frq[id] += node->cnt;
        node->fLink->cnt += node->cnt;
    }
}
int main()
{
    Root = new_emptyNode();
    scanf("%s\n%d", s, &n);

    for (int i = 0; i < n; ++ i)
    {
        scanf("\n%s", a);
        insert(Root, a, i);
    }
    compFail();
    StrOcc();
    compFrq();
    for (int i = 0; i < n; ++ i) printf("%d\n", frq[i]);
    return 0;
}
