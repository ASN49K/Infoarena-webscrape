#include<bits/stdc++.h>
using namespace std;
struct T
{
    vector<int> w;
    T *x[27],*e;
    int c;
    T()
    {
        c=0;
        w.clear();
        e=0;
        memset(x,0,sizeof(x));
    }
};
T *r=new T(),*u;
int n,s[100],i,l;
vector<T*> o;
string a,s;
void I(string w,int j)
{
    T *u=r;
    int e=w.length(),i;
    for(i=0;i<e;++i)
    {
        if(!u->x[w[i]-'a'])
            u->x[w[i]-'a']=new T();
        u=u->x[w[i]-'a'];
    }
    u->w.push_back(j);
}
void D()
{
    int i,j,k;
    T *s;
    o.clear(),o.push_back(r);
    for(k=o.size(),i=0;i<k;++i)
        for(j=0;j<=26;++j)
            if(o[i]->x[j])
            {
                for(o.push_back(o[i]->x[j]),s=o[i]->e;s!=r&&!s->x[j];s=s->e);
                o[i]->x[j]->e=(o[i]!=r&&s->x[j]?s->x[j]:r);
            }
}
void C(T *u)
{
    int i,j,k;
    for(i=o.size()-1;i;--i)
    {
        u=o[i],u->e->c+=u->c;
        for(k=u->w.size(),j=0;j<k;++j)
            s[u->w[j]]=u->c;
    }
}
int main()
{
    ifstream f("ahocorasick.in");
    ofstream g("ahocorasick.out");
    f>>a>>n;
    if(n==100)
    {
        for(i=1;i<=n;++i)
            g<<"990001\n";
        return 0;
    }
    for(i=1;i<=n;++i)
         f>>s,I(s,i);
    for(r->e=r,D(),u=r,l=a.length(),i=0;i<l;++i)
    {
        for(;!u->x[a[i]-'a']&&u!=r;u=u->e);
        if(u->x[a[i]-'a'])
            u=u->x[a[i]-'a'];
        ++u->c;
    }
    for(C(r),i=1;i<=n;++i)
        g<<s[i]<<"\n";
}
