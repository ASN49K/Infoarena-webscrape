#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int nmax=1000004;
struct str
{
    int st;
    int dr;
    int p;
    bool operator <(const str &aux) const
    {
        if(st==aux.st) return dr<aux.dr;
        return st<aux.st;
    }
}v[nmax];
char ch[nmax],ch2[nmax];
int suffix[nmax][2];
int n,m;
inline void citire()
{
    scanf("%s",ch);
    n=strlen(ch);
    for(int i=0;i<n;i++) suffix[i][0]=ch[i];
}
inline void do_suffix()
{
    for(int j=1;j<=7;j++)
    {
        int p2=j&1,p1=1-p2;
      //  printf("%d %d\n",p1,p2);
        for(int i=0;i<n;i++)
        {
            v[i].st=suffix[i][p1];
            if(i+(1<<(j-1))>=n) v[i].dr=-1;
            else v[i].dr=suffix[i+(1<<(j-1))][p1];
            v[i].p=i;
        }
        sort(v,v+n);
        suffix[v[0].p][p2]=1;
        int nt=1;
        for(int i=1;i<n;i++)
        {
            if(v[i].st!=v[i-1].st||v[i].dr!=v[i-1].dr) ++nt;
            suffix[v[i].p][p2]=nt;
        }
    }
}
int comp(int pos)
{
    for(int i=0;i<m;i++)
    {
        if(ch[pos+i]<ch2[i]) return -1;
        else if(ch[pos+i]>ch2[i]) return 1;
    }
    return 0;
}
int bs1()
{
    int rasp=-1,st=0,dr=n-1;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        int val=comp(v[mij].p);
        if(val==0)
        {
            rasp=mij;
            dr=mij-1;
        }
        else if(val==1) dr=mij-1;
        else st=mij+1;
    }
    return rasp;
}
int bs2()
{
    int rasp=-2,st=0,dr=n-1;
    while(st<=dr)
    {
        int mij=(st+dr)/2;
        int val=comp(v[mij].p);
        if(val==0)
        {
            rasp=mij;
            st=mij+1;
        }
        else if(val==1) dr=mij-1;
        else st=mij+1;
    }
    return rasp;
}
inline void solve()
{
    int t;
    scanf("%d",&t);
    for(;t>0;--t)
    {
        scanf("%s",ch2);
        m=strlen(ch2);
        int p1=bs1(),p2=bs2();
        printf("%d\n",p2-p1+1);
    }
}
int main()
{
    freopen ("ahocorasick.in","r",stdin);
    freopen ("ahocorasick.out","w",stdout);
    citire();
    do_suffix();
    solve();
}
