#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
using namespace std;
int n,i,j;
char s[1001000],t[10100],*c;
struct trie{
    int sol;
    trie *x[29],*back;
    vector<trie*>L;
    trie(){
        sol=0;
        back=0;
        for(int i=0;i<=26;i++){
            x[i]=0;
        }
        L.clear();
    }
}*r=new trie;
queue<trie*>q;
trie *v[110],*aux,*nod;
FILE *f,*g;
trie *insertt(trie *nod,char *c){
    if(*c==0)
        return nod;
    if( nod->x[ *c - 'a' ] == 0)
        nod->x[ *c - 'a' ] = new trie;
    return insertt( nod->x[ *c - 'a' ] , c + 1 );
}
void dfs(trie *nod){
    for(int i=0;i<nod->L.size();i++){
        dfs( nod->L[i] );
        nod->sol+=nod->L[i]->sol;
    }
}
int main(){
    f=fopen("ahocorasick.in","r");
    g=fopen("ahocorasick.out","w");
    fscanf(f,"%s%d\n",s,&n);
    for(i=1;i<=n;i++){
        fscanf(f,"%s",t);
        v[i]=insertt(r,t);
    }
    q.push(r);
    while(!q.empty()){
        nod=q.front();
        q.pop();
        for(i=0;i<26;i++){
            if( nod->x[i] != 0 ){
                aux=nod->back;
                while( aux && !aux->x[i] ){
                    aux=aux->back;
                }
                if(aux==0)
                    nod->x[i]->back=r;
                else
                    nod->x[i]->back=aux->x[i];
                nod->x[i]->back->L.push_back(nod->x[i]);
                q.push(nod->x[i]);
            }
        }
    }
    aux=r;
    for(c=s;*c!=0;c++){
        while( aux && aux->x[ *c - 'a' ] == 0  ){
            aux=aux->back;
        }
        if(aux==0)
            aux=r;
        else
            aux=aux->x[ *c - 'a' ];
        aux->sol++;
    }
    dfs(r);
    for(i=1;i<=n;i++){
        fprintf(g,"%d\n",v[i]->sol);
    }
    fclose(f);
    fclose(g);
    return 0;
}
