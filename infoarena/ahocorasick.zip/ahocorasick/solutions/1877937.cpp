#include <bits/stdc++.h>
using namespace std;
ifstream f("ahocorasick.in");
ofstream g("ahocorasick.out");
int i,j,n,l,x,y,k,m,S[1<<20];
char a[1<<20];
struct trie
{
    int nr,bak,Son[26];
    trie()
    {
        bak=-1;
    }
}T[1<<19];
vector <int> Sol,Q;
void rec(int x,int y)
{
    int ok=0;
    for(int i=0;i<26;++i)
        if(T[x].Son[i])
    {
        if(!ok)
        {
            ok=1;
            for(int j=1;j<=y;++j) g<<"  ";
            g<<T[x].bak<<'\n';
        }
        rec(T[x].Son[i],y+1);
    }
    if(!ok)
    {
        for(int j=1;j<=y;++j) g<<"  ";
        g<<T[x].bak<<'\n';
    }
}
int main()
{
    f>>a;
    for(i=0;a[i]>='a'&&a[i]<='z';++i) S[++n]=a[i]-'a';
    f>>m;
    for(j=1;j<=m;++j)
    {
        f>>a;
        int l=strlen(a);
        for(i=x=0;i<l;++i)
        {
            int y=a[i]-'a';
            if(!T[x].Son[y])
            {
                T[x].Son[y]=++k;
                x=k;
            }
            else x=T[x].Son[y];
        }
        Sol.push_back(x);
    }
    Q.push_back(0);
    for(i=0;i<Q.size();++i)
    {
        x=Q[i];
        for(j=0;j<26;++j)
            if(T[x].Son[j])
        {
            for(y=T[x].bak;y!=-1&&!T[y].Son[j];y=T[y].bak);
            int nod=T[x].Son[j];
            if(y!=-1) T[nod].bak=T[y].Son[j];
            else T[nod].bak=0;
            //g<<"Case "<<i<<": \n";
            //rec(0,0);
            Q.push_back(nod);
        }
    }
    //rec(0,0);
    //return 0;
    x=0;
    for(i=1;i<=n;++i)
    {
        while(x!=-1&&!T[x].Son[S[i]]) x=T[x].bak;
        if(x==-1) x=0;
        else
        {
            x=T[x].Son[S[i]];
            T[x].nr++;
        }
    }

    for(i=Q.size()-1;i>=0;--i)
        if(T[Q[i]].bak) T[T[Q[i]].bak].nr+=T[Q[i]].nr;
    for(j=0;j<m;++j) g<<T[Sol[j]].nr<<'\n';
    return 0;
}
