#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
using namespace std;
int n,i,j;
char s[1001000],a[10100],*c;
struct trie{
    int n;
    trie *x[27],*back;
    vector<trie*>v;
    trie(){
        n=0;
        back=0;
        for(int i=0;i<27;i++){
            x[i]=0;
        }
    }
}*t=new trie;
queue<trie*>q;
trie *v[110],*aux,*nod;
FILE *f,*g;
trie *insertt(trie *nod,char *c){
    if(*c==0)
        return nod;
    if(nod->x[ *c - 'a' ]==0)
        nod->x[ *c - 'a' ]=new trie;
    return insertt(nod->x[ *c - 'a' ],c+1);
}
void dfs(trie *nod){
    for(int i=0;i<nod->v.size();i++){
        dfs(nod->v[i]);
        nod->n+=nod->v[i]->n;
    }
}
int main(){
    f=fopen("ahocorasick.in","r");
    g=fopen("ahocorasick.out","w");
    fscanf(f,"%s%d\n",s,&n);
    for(i=1;i<=n;i++){
        fscanf(f,"%s",a);
        v[i]=insertt(t,a);
    }
    q.push(t);
    while(!q.empty()){
        nod=q.front();
        q.pop();
        for(i=0;i<26;i++){
            if(nod->x[i]!=0){
                aux=nod->back;
                while(aux&&!aux->x[i]){
                    aux=aux->back;
                }
                if(!aux)
                    nod->x[i]->back=t;
                else
                    nod->x[i]->back=aux->x[i];
                nod->x[i]->back->v.push_back(nod->x[i]);
                q.push(nod->x[i]);
            }
        }
    }
    for(c=s,aux=t;*c!=0;c++){
        while(aux&&!aux->x[ *c - 'a' ]){
            aux=aux->back;
        }
        if(!aux)
            aux=t;
        else
            aux=aux->x[ *c - 'a' ];
        aux->n++;
    }
    dfs(t);
    for(i=1;i<=n;i++){
        fprintf(g,"%d\n",v[i]->n);
    }
    fclose(f);
    fclose(g);
    return 0;
}
