#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

ll sm[N];
ll sol[N];

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);



    return 0;
}
