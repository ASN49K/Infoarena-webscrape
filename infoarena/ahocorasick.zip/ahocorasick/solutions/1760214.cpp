#include<iostream>
#include<fstream>
#include<cstring>
#include<string>
#include<vector>
using namespace std;

struct trie {
  	vector<int> cuv;
  	int sum;
  	trie *a[26];
  	trie *back;
	trie () { memset(a,0,sizeof(a)); back=0; sum=0; cuv.clear(); }
};

trie *root = new trie();
trie *bfsorder[1000002];
string t;
int i,n,l,r;
int sol[105];

void insert(string s, int c) {
  
  trie *aux=root;
  
  for (int i=0; i<s.length(); ++i) {
    if (!aux->a[s[i]-'a']) aux->a[s[i]-'a']=new trie();
    aux=aux->a[s[i]-'a'];
   }
   
   aux->cuv.push_back(c);
	
}

int main(void) {
	ifstream cin("ahocorasick.in");
	ofstream cout("ahocorasick.out");
	
	getline(cin,t);
	cin>>n;
	
	string c;
	getline(cin,c);
	
	for (i=1; i<=n; ++i) {
	    getline(cin,c);
		insert(c,i);	
	}
	
	l=1; r=0; 
	root->back=root;
	
	for (i=0; i<26; ++i) 
	 if (root->a[i]!=0) { 
	          root->a[i]->back=root;
	          bfsorder[++r]=root->a[i];
	          }
	
	while (l<=r) {
	 
	 trie *curent=bfsorder[l++];
	 
	 for (i=0; i<26; ++i)
	  if (curent->a[i]!=0) {
	     
		 trie *aux=curent->back;
		 while (aux!=root && aux->a[i]==0) aux=aux->back;
		 
		 if (aux->a[i]!=0) aux=aux->a[i];
		 
		 curent->a[i]->back=aux;	
	  	
	  	 bfsorder[++r]=curent->a[i];
	  }
	
	}
	
	trie *aux=root;
	
	for (i=0; i<t.length(); ++i) {
		
		while (aux!=root && aux->a[t[i]-'a']==0) 
		     aux=aux->back;
		if (aux->a[t[i]-'a']) aux=aux->a[t[i]-'a'];
		++aux->sum;
		
	}
	
	for (i=r; i>=1; --i) {
	   
	    trie *curent=bfsorder[i];
		
		for (int j=0; j<curent->cuv.size(); ++j) sol[curent->cuv[j]]=curent->sum;	
		
		curent->back->sum+=curent->sum;
	}
	
	for (i=1; i<=n; ++i) cout<<sol[i]<<"\n";
	
	return 0;
}
