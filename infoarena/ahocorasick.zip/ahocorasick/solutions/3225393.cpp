#include <bits/stdc++.h>
#pragma GCC optimize ("Ofast")
#pragma GCC optimize ("unroll-loops")
#pragma GCC optimize ("fast-math")
#pragma GCC target ("avx2")
using namespace std;
ifstream fin("ahocorasick.in");
ofstream fout("ahocorasick.out");
int go(int,int);
int getsuf(int);
string v;
int n,sol[105];
string s;
struct node
{
    int lit;
    int par;
    int go[27];
    int suflink;
    int dictlink;
    int dp;
    int niv;
    vector<int> who;
} emp;
vector<node> t;
void add(int ind)
{
    int me=0;
    for(char c:s)
    {
        int lit=c-'a';
        if(t[me].go[lit]==-1)
        {
            t[me].go[lit]=t.size();
            int x=t.size();
            t.push_back(emp);
            t[x].par=me;
            t[x].lit=lit;
            t[x].niv=t[me].niv+1;
        }
        me=t[me].go[lit];
    }
    t[me].who.push_back(ind);
}
int go(int me,int lit)
{
    if(t[me].go[lit]!=-1)
        return t[me].go[lit];
    if(me==0)
        return 0;
    t[me].go[lit]=go(getsuf(me),lit);
    return t[me].go[lit];
}
int getsuf(int me)
{
    if(t[me].suflink!=-1)
        return t[me].suflink;
    if(me==0||t[me].par==0)
    {
        t[me].suflink=0;
        return 0;
    }
    t[me].suflink=go(getsuf(t[me].par),t[me].lit);
    return t[me].suflink;
}
bool byniv(int a,int b)
{
    return t[a].niv>t[b].niv;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    emp.suflink=-1;
    emp.dictlink=-1;
    emp.niv=0;
    for(int i=0;i<=26;i++)
        emp.go[i]=-1;
    t.push_back(emp);
    t[0].suflink=0;
    t[0].dictlink=0;
    fin>>v;
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        fin>>s;
        add(i);
    }
    int me=0;
    for(char c:v)
    {
        int lit=c-'a';
        me=go(me,lit);
        t[me].dp++;
    }
    vector<int> ord;
    for(int i=0;i<t.size();i++)
        ord.push_back(i);
    sort(ord.begin(),ord.end(),byniv);
    for(int nod:ord)
    {
        for(int i:t[nod].who)
            sol[i]=t[nod].dp;
        t[getsuf(nod)].dp+=t[nod].dp;
    }
    for(int i=1;i<=n;i++)
        fout<<sol[i]<<'\n';
    return 0;
}
