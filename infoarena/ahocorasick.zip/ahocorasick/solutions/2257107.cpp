#include <bits/stdc++.h>

using namespace std;

#define LA (int)(2+1e6)
#define LC (int)(2+1e4)

char a[LA],c[LC];
int n,m,p[LC],r;

void prefixe(){
    int i,k=0;
    for (i=0;i<=n;i++) p[i]=0;
    for (i=2;i<=n;i++){
        for (;k!=0&&c[k+1]!=c[i];) k=p[k];
        if (c[k+1]==c[i]) k++;
        p[i]=k;
    }
}

void potrivire(){
    int k=0,i;
    r=0;
    for (i=1;i<=m;i++){
        for (;k!=0&&c[k+1]!=a[i];) k=p[k];
        if (c[k+1]==a[i]) k++;
        if (k==n) r++;
    }
}

int main()
{
    freopen("ahocorasick.in","r",stdin);
    freopen("ahocorasick.out","w",stdout);
    int nr,i;
    scanf("%s%d",a+1,&nr);
    m=strlen(a+1);
    for (i=1;i<=nr;i++){
        scanf("%s",c+1);
        n=strlen(c+1);
        prefixe();
        potrivire();
        printf("%d\n",r);
    }
    return 0;
}
