#include <bits/stdc++.h>
using namespace std;
ifstream fin ("ahocorasick.in");
ofstream fout ("ahocorasick.out");
struct nod{
    int sol=0;
    nod *f[26];
    nod *back=0;
    vector< nod *> v;
    nod(){
        for(int i=0;i<26;i++)
            f[i]=0;
        v.clear();
    }
};
int n,m,i;
nod *cuv[110], *fiu, *aux, *rad, *x, *y;
char S[1000010],s[10010];
queue<nod *> q;

void BACK(){
    q.push(rad);
    while(!q.empty()){
        x=q.front();
        q.pop();
        for(int i=0;i<26;i++){
            fiu=x->f[i];
            if(fiu){
                y=x->back;
                while(y && y->f[i]==NULL)
                    y=y->back;
                if(y==0){
                    fiu->back=rad;
                    //cout<<1;
                }
                else
                    fiu->back=y->f[i];

                fiu->back->v.push_back(fiu);
                q.push(fiu);

            }
        }

    }
}
nod *adaugare(char *s, nod *p){
    char ch=*s;
    if(ch==0)
        return p;
    if(p->f[ch-'a']==NULL){
        p->f[ch-'a']= new nod;
    }


    return adaugare(s+1,p->f[ch-'a']);
}
void dfs(nod *p){
     for(int i=0;i<p->v.size();i++){
        dfs(p->v[i]);
        p->sol+=p->v[i]->sol;
    }
}
int main(){
    fin>>S;
    fin>>n;
    rad = new nod;
    for(i=1;i<=n;i++){
        fin>>s;
        cuv[i]=adaugare(s,rad);
    }
    BACK();
    m=strlen(S);
    aux=rad;
    for (i=0;i<m;i++) {
        int fiu=S[i]-'a';
        while (aux!=rad && aux->f[fiu]==NULL)
            aux=aux->back;
        if (aux->f[fiu]!=NULL)
            aux=aux->f[fiu];
        aux->sol++;
    }
    //cout<<rad->v.size();
    dfs(rad);

    for(i=1;i<=n;i++)
        fout<<cuv[i]->sol<<"\n";

    return 0;
}
