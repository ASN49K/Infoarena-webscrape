#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstring>
#include<vector>
#include<string>
#include<queue>
#define in cin
#define out cout
using namespace std;
char S[1000001],s[10001];
int N,K,id[101],ans[101];
struct aho{
    vector<aho*> v;
    char c;int h,k;
    aho *fail,*mfail;
    aho(){v.clear(),fail=NULL,c=h=k=0;}
    aho* hson(char &c){
        aho *ch=NULL;
        for(vector<aho*>::iterator it=this->v.begin();it!=this->v.end();it++) if((*it)->c==c) ch=*it;
        return ch;
    }
} *root;
int push_dict(char s[]){
    int ns=strlen(s);
    aho *w=root,*ch;
    for(int i=0;i<ns;i++){
        ch=w->hson(s[i]);
        if(!ch){
            ch=new aho();
            ch->c=s[i];
            w->v.push_back(ch);
        }
        w=ch;
    }
    w->h=1;
    if(!w->k) w->k=++K;
    return w->k;
}
queue< pair<aho*,aho*> > q;
void fails_bfs(){
    pair<aho*,aho*> temp;
    aho *w=root,*tat;
    for(vector<aho*>::iterator it=w->v.begin();it!=w->v.end();it++) q.push(make_pair(w,*it));
    while(!q.empty()){
        temp=q.front(); q.pop();
        tat=temp.first,w=temp.second;
        w->fail=tat->fail;
        while(w->fail && !w->fail->hson(w->c)) w->fail=w->fail->fail;
        if(!w->fail) w->fail=root;
        else w->fail=w->fail->hson(w->c);
        for(vector<aho*>::iterator it=w->v.begin();it!=w->v.end();it++) q.push(make_pair(w,*it));
        w->mfail=w->fail;
        while(w->mfail && !w->mfail->h) w->mfail=w->mfail->fail;
    }
}
void print(aho *r,int l){
    for(int i=1;i<=2*l;i++) out<<' ';
    out<<r->c<<'\n';
    for(vector<aho*>::iterator it=r->v.begin();it!=r->v.end();it++){
        print(*it,l+1);
    }
}
int main(){
    //#ifndef ONLINE_JUDGE
    ifstream in("ahocorasick.in");
    ofstream out("ahocorasick.out");
    //#endif
    root=new aho(); root->c='$';
    in.getline(S,1000001);
    in>>N; in.get();
    for(int i=0;i<N;i++){
        in.getline(s,10001);
        id[i]=push_dict(s);
    }
    fails_bfs();
    int NS=strlen(S);
    aho *w=root;
    for(int i=0;i<NS;i++){
        while(w && !w->hson(S[i])) w=w->fail;
        if(!w) w=root;
        else w=w->hson(S[i]);
        aho *t=w;
        while(t){
            ans[t->k]+=t->h;
            t=t->mfail;
        }
    }
    for(int i=0;i<N;i++) out<<ans[id[i]]<<'\n';
    return 0;
}
