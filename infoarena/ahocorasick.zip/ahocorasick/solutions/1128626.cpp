#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstring>
using namespace std;
char sir[1000001],crt[10002];
int urmator[10001];
long m;
int n;

void urmatorul ()
{
	int i,j;
	urmator[0]=-1;
	for (i=1,j=0; i<n; i++,j++, urmator[i]=j)
		while (j>=0 and crt[i]!=crt[j])
			j=urmator[j];
}

long kmp ()
{
	long i,j,k=0;
	for (i=0, j=0; i<m; i++, j++)
	{
		
		while (j>=0 and sir[i]!=crt[j])
			j=urmator[j];
		if (j==n-1) {k++;j=-1;}
	}
	return k;
}

int main ()
{
	int nr,i;
	ifstream f("ahocorasick.in");
	ofstream g("ahocorasick.out");
	//FILE *g;
	//g=fopen("ahocorasick.out", "w");
	f>>sir;
	m=strlen(sir);
	f>>nr;
	for (;nr>0; nr--)
	{
		f>>crt;
		n=strlen(crt);
		urmatorul();
		//for (i=0; i<=n; i++) g<<urmator[i]<<" ";
		g<<kmp();
		g<<"\n";
	}
	
	
	//cout<<m;
	f.close(); g.close();
	return 0;
}