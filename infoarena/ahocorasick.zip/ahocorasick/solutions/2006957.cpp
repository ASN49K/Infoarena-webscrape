#include<bits/stdc++.h>
#define sigma 26
#define f(i) (i-'a'+1)
using namespace std;
char s[1000005];
char str[10005];
int n,m;
struct trie
{
    int sol;
    trie *sons[sigma+5];
    trie *back;
    vector<trie*> v;
    trie()
    {
        sol=0;
        for(int i=0;i<=sigma;i++)
            sons[i]=NULL;
        back=NULL;
        v.clear();
    }
}*root=new trie();
trie* w[105];
inline trie* Insert(trie *node,char *s)
{
    if(*s==NULL)
    {
        return node;
    }
        else
    {
        if(!node->sons[s[0]-'a'+1]) node->sons[s[0]-'a'+1]=new trie();
        return Insert(node->sons[s[0]-'a'+1],s+1);
    }
}
inline void dfs(trie *node)
{
    int sz=node->v.size();
    for(int i=0;i<sz;i++)
    {
        dfs(node->v[i]);
        node->sol+=node->v[i]->sol;
    }
}
deque<trie*> q;
trie* aux;
int main()
{
    freopen("ahocorasick.in","r",stdin);
    freopen("ahocorasick.out","w",stdout);
    scanf("%s",s);
    m=strlen(s);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%s",str);
        w[i]=Insert(root,str);
    }

    q.push_back(root);
    while(!q.empty())
    {
        trie *node=q.front();
        q.pop_front();
        for(int i=1;i<=26;i++)
        {
            if(node->sons[i])
            {
                aux=node->back;
                while(aux && aux->sons[i]==NULL) aux=aux->back;
                if(aux==NULL) node->sons[i]->back=root;
                    else node->sons[i]->back=aux->sons[i];
                node->sons[i]->back->v.push_back(node->sons[i]);
                q.push_back(node->sons[i]);
            }
        }
    }

    aux=root;
    for(int i=0;i<m;i++)
    {
        while(aux!=root && aux->sons[s[i]-'a'+1]==NULL) aux=aux->back;
        if(aux->sons[s[i]-'a'+1]!=NULL) aux=aux->sons[s[i]-'a'+1];
        aux->sol++;
    }
    dfs(root);
    for(int i=1;i<=n;i++)
        printf("%d\n",w[i]->sol);
    return 0;
}
