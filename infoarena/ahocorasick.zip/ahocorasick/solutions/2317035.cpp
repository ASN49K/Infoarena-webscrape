#include <fstream>
#include <deque>
#define nmax 100
#define L 1000000
#define l 10000
using namespace std;
int n,val[nmax+5];
char text[L+5],cuv[l+5];
struct trie
{
    int k=0,val=0;
    char ch;
    trie* fiu[28]={0},*fail=0;
}*v;
deque<trie*> q1,q2;
void add(int k, char *charr)
{
    trie *d=v;
    while(*charr!='\0')
    {
        if(!d->fiu[charr[0]-'a'])
            d->fiu[charr[0]-'a']=new trie;
        d=d->fiu[charr[0]-'a'];
        d->ch=charr[0];
        charr++;
    }
    if(!d->k)
        d->k=k;
}
void link()
{
    v->fail=v;
    trie *d,*f;
    for(int i=0;i<26;i++)
        if(v->fiu[i])
        q1.push_back(v->fiu[i]),v->fiu[i]->fail=v;
    while(!q1.empty())
    {
        d=q1.front();
        q1.pop_front();
        q2.push_back(d);
        for(int i=0;i<26;i++)
            if(d->fiu[i])
            {
                f=d->fail;
                while(f!=v && !f->fiu[i])
                    f=f->fail;
                if(f->fiu[i])
                    d->fiu[i]->fail=f->fiu[i];
                else
                    d->fiu[i]->fail=v;
                q1.push_back(d->fiu[i]);
            }
    }
}
void match(char *a)
{
    trie* d=v;
    while(*a)
    {
        while(d!=v && !d->fiu[a[0]-'a'])
            d=d->fail;
        if(d->fiu[a[0]-'a'])
            d=d->fiu[a[0]-'a'];
        d->val++;
        a++;
    }
}
void solve()
{
    trie *d;
    while(!q2.empty())
    {
        d=q2.back();
        q2.pop_back();
        d->fail->val+=d->val;
        if(!val[d->k])
            val[d->k]=d->val;
    }
}
int main()
{
    ifstream fin("ahocorasick.in");
    ofstream fout("ahocorasick.out");
    fin>>text;
    fin>>n;
    v=new trie;
    v->ch='\0';
    for(int i=1;i<=n;i++)
    {
        fin>>cuv;
        add(i,cuv);
    }
    link();
    match(text);
    solve();
    for(int i=1;i<=n;i++)
        fout<<val[i]<<"\n";
    return 0;
}
