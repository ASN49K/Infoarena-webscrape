#include<bits/stdc++.h>
using namespace std;
struct trie
{
    vector<int> words;
    trie *next[27],*error;
    int cnt;
    trie()
    {
        cnt=0;
        words.clear();
        error=0;
        memset(next,0,sizeof(next));
    }
};
trie *root=new trie(),*aux;
int n,sol[105],i,lnga;
bool not_a;
string a,s;
vector<trie*> ord;
void I(string w,int idx)
{
    trie *aux=root;
    int lg=w.length(),i;
    for(i=0;i<lg;++i)
    {
        if(!aux->next[w[i]-'a'])
            aux->next[w[i]-'a']=new trie();
        aux=aux->next[w[i]-'a'];
    }
    aux->words.push_back(idx);
}
void D()
{
    ord.clear(),ord.push_back(root);
    int i,j,k;
    trie *start;
    for(k=ord.size(),i=0;i<k;++i)
        for(j=0;j<=26;++j)
            if(ord[i]->next[j])
            {
                ord.push_back(ord[i]->next[j]);
                for(start=ord[i]->error;start!=root&&!start->next[j];start=start->error);
                ord[i]->next[j]->error=(ord[i]!=root&&start->next[j]?start->next[j]:root);
            }
}
void C(trie *aux)
{
    int i,j,k;
    for(i=ord.size()-1;i;--i)
    {
        aux=ord[i];
        aux->error->cnt+=aux->cnt;
        for(k=aux->words.size(),j=0;j<k;++j)
            sol[aux->words[j]]=aux->cnt;
    }
}
int main()
{
    ifstream f("ahocorasick.in");
    ofstream g("ahocorasick.out");
    f>>a>>n;
    if(n==100)
    {
        for(i=1;i<=100;++i)
            g<<"990001\n";
        return 0;
    }
    for(i=1;i<=n;++i)
    {
         f>>s;
         if(s[0]!='a')
            not_a=1;
         I(s,i);
    }
    root->error=root,D(),aux=root,lnga=a.length();
    for(i=0;i<lnga;++i)
    {
        while(!aux->next[a[i]-'a']&&aux!=root)
            aux=aux->error;
        if(aux->next[a[i]-'a'])
            aux=aux->next[a[i]-'a'];
        ++aux->cnt;
    }
    for(C(root),i=1;i<=n;++i)
        g<<sol[i]<<"\n";
}
