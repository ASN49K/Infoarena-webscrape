/**
 * Abordarea KMP
* */

#include <bits/stdc++.h>

using namespace std;

#define INFILE "ahocorasick.in"
#define OUTFILE "ahocorasick.out"

vector<int> zFunction(string s){

    int n = s.length();
    vector<int> z(n);

    int left = 0, right = 0;
    for(int i = 1; i < n; ++i){
        if(i < right) z[i] = min(right - i, z[i - left]);
        while(i + z[i] < n && s[z[i]] == s[i + z[i]]) ++z[i];
        if(i + z[i] > right) left = i, right = i + z[i];
    }

    return z;

}

void solve(){

    string s; cin >> s;
    int queries; cin >> queries;

    while(queries--){
        string aux; cin >> aux;
        int sz = aux.length();
        aux += '#';
        aux += s;
        vector<int> z = zFunction(aux);
        int ans = count(z.begin(), z.end(), sz);
        cout << ans << '\n';
    }

}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);
    solve();
    return 0;
}