#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstring>
using namespace std;

class SufA {
public:
	const char* s;
	const int n;
	vector<int> sa;
	vector<int> elcp;
public:
	SufA(const char* _s, const int _n) : s(_s), n(_n) {
	}
	template <typename T>
	void sais(const int n, const T s, const int nc) {
		const int nil = -1;
		fill(begin(sa), begin(sa)+n, nil);
		vector<bool> t(n);
		t[n-1] = true;
		for (int i = n-2; i >= 0; i--) {
			t[i] = s[i] < s[i+1]
				|| s[i] == s[i+1] && t[i+1];
		}
		auto isLMS = [&t] (int i) {
			return t[i] &&  i >= 1 && !t[i-1];
		};
		vector<int> bkt0(nc+1);
		for (int i = 0; i < n; i++) {
			bkt0[s[i]+1]++;
		}
		partial_sum(begin(bkt0), end(bkt0), begin(bkt0));
		auto bkt = bkt0;
		for (int i = n-1; i >= 1; i--) {
			if (isLMS(i)) {
				sa[--bkt[s[i]+1]] = i;
			}
		}
		auto induceSAl = [&] () {
			auto bkt = bkt0;
			for (int i = 0; i < n-1; i++) {
				int j = sa[i]-1;
				if (j >= 0 && !t[j]) {
					sa[bkt[s[j]]++] = j;
				}
			}
		};
		auto induceSAs = [&] () {
			auto bkt = bkt0;
			for (int i = n-1; i >= 2; i--) {
				int j = sa[i]-1;
				if (j >= 0 && t[j]) {
					sa[--bkt[s[j]+1]] = j;
				}
			}
		};
		induceSAl();
		induceSAs();
		int n1 = 0;
		for (int i = 0; i < n; i++) {
			if (isLMS(sa[i])) {
				sa[n1++] = sa[i];
			}
		}
		int ord = 0;
		for (int i = 0; i < n1; i++) {
			if (i >= 1) {
				ord++;
				for (int j = 0; s[sa[i-1]+j] == s[sa[i]+j]; j++) {
					if (isLMS(sa[i]+j) && j >= 1) {
						if (isLMS(sa[i-1]+j)) ord--;
						break;
					}
				}
			}
			sa[n1+sa[i]/2] = ~ord;
		}
		if (ord+1 < n1) {
			int* s1 = &sa[0]+n1;
			for (int i = n1, j = 0; j < n1; i++) {
				if (sa[i] < 0) {
					s1[j++] = ~sa[i];
				}
			}
			sais(n1, s1, ord+1);
			for (int i = 1, j = 0; i < n; i++) {
				if (isLMS(i)) {
					s1[j++] = i;
				}
			}
			for (int i = 0; i < n1; i++) {
				sa[i] = s1[sa[i]];
			}
		}
		fill(begin(sa)+n1, begin(sa)+n, nil);
		bkt = bkt0;
		for (int i = n1-1; i >= 0; i--) {
			int j = sa[i];
			sa[i] = nil;
			sa[--bkt[s[j]+1]] = j;
		}
		induceSAl();
		induceSAs();
	}
	void buildsa() {
		sa.resize(n);
		if (n >= 2) sais(n, s, 128);
	}
	void buildelcp() {
		elcp.resize(2*n);
		for (int i = 0; i < n; i++) {
			elcp[sa[i]] = i;
		}
		for (int j = 0, len = 0; j < n-1; j++) {
			int i = sa[elcp[j]-1];
			while (s[i+len] == s[j+len]) len++;
			elcp[n+elcp[i]] = len;
			len = max(len-1, 0);
		}
		elcp[n+n-1] = -1;
		for (int i = n-1; i >= 1; i--) {
			elcp[i] = min(elcp[2*i], elcp[2*i+1]);
		}
	}
	pair<int,int> range(const char t[]) const {
		int l = n;
		int i = n>>__builtin_ctz(n);
		int cp = 0;
		bool right = false;
		while (i <= l) {
			bool next;
			if (elcp[i+right] != cp) {
				next = right == elcp[i+right] < cp;
			} else {
				int k = sa[l-n+l/i];
				while (t[cp] == s[k+cp]) cp++;
				if (t[cp] == '\0') {
					l = l+l/i;
					i++;
					i <<= 1;
					break;
				}
				next = s[k+cp] < t[cp];
				right = !next;
			}
			if (next) {
				l += l/i;
				i++;
				i = i&1 ? i<<1 : i>>__builtin_ctz(i);
			} else {
				i <<= 1;
			}
		}
		if (t[cp] != '\0') {
			int k = l-n+1;
			return {k, k};
		}
		int r = l;
		while (i <= l) {
			if (elcp[i-1] < cp) {
				i <<= 1;
			} else {
				l -= l/i;
				i--;
				i <<= 1;
			}
		}
		l -= n;
		i = r>>__builtin_ctz(r);
		while (i <= r) {
			if (elcp[i] < cp) {
				i <<= 1;
			} else {
				r += r/i;
				i++;
				i = i&1 ? i<<1 : i>>__builtin_ctz(i);
			}
		}
		r -= n-1;
		return {l, r};
	}
};

int main() {
	freopen("ahocorasick.in", "r", stdin);
	freopen("ahocorasick.out", "w", stdout);
	char s[int(1e6)+1];
	scanf("%s", s);
	int n = strlen(s)+1;
	s[n-1] = '\1';
	SufA suf(s, n);
	suf.buildsa();
	suf.buildelcp();
	int nq;
	scanf("%d", &nq);
	char t[int(1e4)+1];
	for (int iq = 0; iq < nq; iq++) {
		scanf("%s", t);
		auto res = suf.range(t);
		printf("%d\n", res.second-res.first);
	}
}
