#include<cstdio>
#include<cstring>
#define MAX_LEN 1000000
using namespace std;

char T[MAX_LEN+1], P[MAX_LEN/100+1];
int pi[MAX_LEN/100+1], n, ap, a, m;

void buildPrefix() {
    int i, k = 0;
    pi[0] = 0;
    m = strlen(P);
    for(i = 1; i < m; i++) {
        while(k > 0 && P[i] != P[k])
            k = pi[k-1];
        if(P[i] == P[k])
            k++;
        pi[i] = k;
    }
}

void KMP() {
    int i, k = 0;
    ap = 0;
    for(i = 0; i < n; i++) {
        while(k > 0 && T[i] != P[k])
            k = pi[k-1];
        if(T[i] == P[k])
            k++;
        if(k == m)
            ap++;
    }
}

int main() {
    int i;
    FILE* fin, *fout;
    fin = fopen("ahocorasick.in","r");
    fout = fopen("ahocorasick.out","w");
    fscanf(fin,"%s",T);
    fscanf(fin,"%d",&a);
    n = strlen(T);
    for(i = 1; i <= a; i++) {
        fscanf(fin,"%s",P);
        buildPrefix();
        KMP();
        fprintf(fout,"%d\n",ap);
        //printf("%s\n",P);
    }
    fclose(fin);
    fclose(fout);
    return 0;
}
