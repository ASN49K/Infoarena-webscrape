#include <iostream>
#include <cstdio>
#include <queue>
#include <cstring>
#include <stack>
using namespace std;
struct trie
{
    trie *F[27];
    int indice;
    trie *fail;
    trie()
    {
        for(int i=0; i<=26; i++)
            F[i]=NULL;
        indice=0;
    }
}*root;

queue<trie*>deBFS;
stack<trie*>intoarcere;
char dictionar[1001][10001];
char cuv[1000001];
int v[1003];
int n;

void insertTrie(trie* nod,int indice,char cuvant[])
{
    for(int i=0; i<=strlen(cuvant)-1; i++)
    {
        if(!nod->F[*(cuvant+i)-'a'])
        {
            nod->F[*(cuvant+i)-'a']=new trie();
        }
        nod=nod->F[*(cuvant+i)-'a'];
    }
    nod->indice=indice;
}

void citire()
{
    scanf("%s\n",cuv);
    scanf("%d\n",&n);
    for(int i=1; i<=n; i++)
    {
        scanf("%s\n",dictionar[i]);
        insertTrie(root,i,dictionar[i]);
    }
}
void makeFail(trie *nod)
{
    for(int i=0; i<=26; i++)
    {
        if(nod->F[i])
        {
            nod->F[i]->fail=nod;
            deBFS.push(nod->F[i]);
        }
    }
    trie*aux;
    while(!deBFS.empty())
    {
        nod=deBFS.front();
        deBFS.pop();
        for(int i=0; i<=26; i++)
        {
            if(nod->F[i])
            {
                nod->F[i]->fail=nod->fail;
                aux=nod->fail;
                deBFS.push(nod->F[i]);
                intoarcere.push(nod->F[i]);

                while(!aux->F[i]&&aux!=root)
                    aux=aux->fail;
                if(aux->F[i])
                    nod->F[i]->fail=aux->F[i];
                else
                    nod->F[i]->fail=root;
            }
        }
    }
}
void solve()
{
    trie*aux;
    while(!intoarcere.empty())
    {
        aux=intoarcere.top();
        intoarcere.pop();
        while(aux->fail!=root)
        {
            v[aux->fail->indice]++;
            aux=aux->fail;
        }
    }
}
int main()
{
    freopen("ahocorasick.in","r",stdin);
    freopen("ahocorasick.out","w",stdout);
    root=new trie;
    citire();
    makeFail(root);
    trie*nod=root;
    for(int i=0;i<strlen(cuv);i++)
    {
        while(nod!=root&&!nod->F[*(cuv+i)-'a'])
        {
            nod=nod->fail;
        }
        nod=nod->F[*(cuv+i)-'a'];
        v[nod->indice]++;
    }
    solve();
    for(int i=1;i<=n;i++)
    {
        printf("%d %s",v[i],dictionar[i]);
        printf("\n");
    }

    return 0;
}
