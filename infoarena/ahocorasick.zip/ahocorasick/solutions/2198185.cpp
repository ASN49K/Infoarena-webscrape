#include <bits/stdc++.h>

using namespace std;

const int S = 'z' + 1 - 'a';
const int N = 100;

class Trie;

queue<Trie*> q;
vector<Trie*> q2;

vector<int> bulan[N];

class Trie {
public:
    Trie* v[S];
    Trie* fail;
    int app;
    int print;
    bool root;

    Trie(bool f) {
        print = -1;
        app = 0;
        root = f;
        fail = NULL;
        for (int i = 0; i < S; i++)
            v[i] = NULL;
    }

    void add(int where, char s[], unsigned int p) {
        if (s[p] == NULL) {
            if (print >= 0) {
                bulan[print].push_back(where);
            }
            else {
                print = where;
            }
            return;
        }
        if (v[s[p] - 'a'] == NULL) {
            v[s[p] - 'a'] = new Trie(false);
        }
        v[s[p] - 'a']->add(where, s, p + 1);
    }
};

void bfs (Trie* trie) {
    q.push(trie);
    q2.push_back(trie);
    while (!q.empty()) {
        Trie* node = q.front();
        bool leaf = true;
        q.pop();
        for (int i = 0; i < S; i++) {
            Trie* son = node->v[i];
            if (son != NULL) {
                leaf = false;
                q.push(son);
                q2.push_back(son);
                if (node->root) {
                    son->fail = node;
                    continue;
                }
                Trie* curr = node->fail;
                while (!curr->root && curr->v[i] == NULL) {
                    curr = curr->fail;
                }
                if(curr->v[i] != NULL) {
                    son->fail = curr->v[i];
                }
                else {
                    son->fail = curr;
                }
            }
        }
    }
}

Trie* T = new Trie(true);
const int MAX = 1e6;
int ans[N + 1];
char text[MAX + 1];
int n;

void solve() {
    Trie* curr = T;
    for (unsigned int i = 0; text[i]; i++) {
        int c = text[i]- 'a';
        while (!curr->root && curr->v[c] == NULL) {
            curr = curr->fail;
        }
        if (curr->v[c] != NULL) {
            curr = curr->v[c];
            curr->app++;
        }
    }
}

void init() {
    freopen("ahocorasick.in", "r", stdin);
    freopen("ahocorasick.out", "w", stdout);
}

void bfs2() {
    for (int i = q2.size() - 1; i >= 0; i--) {
        Trie* node = q2[i];
        if (node->root) {
            continue;
        }
        node->fail->app += node->app;
        if (node->print >= 0) {
            ans[node->print] = node->app;
        }
    }
}

const int L = 1e4;
char s[L + 1];

int main() {
    init();
    gets(text);
    scanf("%d\n",&n);
    for (int i = 0; i < n; i++) {
        gets(s);
        T->add(i, s, 0);
    }
    bfs(T);
    solve();
    bfs2();
    for (int i = 0; i < n; i++) {
        for (int x : bulan[i]) {
            ans[x] = ans[i];
        }
    }
    for (int i = 0; i < n; i++) {
        cout << ans[i] << '\n';
    }
    return 0;
}
