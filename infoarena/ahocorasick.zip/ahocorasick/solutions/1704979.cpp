// Template v2
#define pb push_back
#define mp make_pair
#define det(a,b,c,d)  (a*d-b*c)
#define first x
#define second y
#define l(x) (x<<1)
#define r(x) ((x<<1)|1)
#define lsb(x) x & -x
#define PI   3.14159265358979323846
#include<iostream>
#include<vector>
#include<iomanip>
#include<unordered_map>
#include<algorithm>
#include<string.h>
#include<stack>
#include<set>
#include <bitset>
using namespace std;
  
typedef long long LL;
typedef long double LD;
typedef vector<int> VI;
typedef pair<int, int> PII;
typedef pair<LL, LL> PLL;
typedef pair<double, double> PKK;
// primes less than 100
const int PRIM[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97}; const int CMAX = 100069;
const int MOD1 = 10039;
const int MOD2 = 10067;
const int MOD3 = 10429;
const int P = 73;
const int NMAX = 1005666;
const double EPS = 1e-7;
const int INF16 = 320000;
const int INF = 1e9 + 6661369;
const LL INF64 = LL(1e18);
const int dx[]={-1,1,0,0};
const int dy[]={0,0,1,-1};

ifstream cin("ahocorasick.in");
ofstream cout("ahocorasick.out");

trie{
	int val=0;
	vector<int>v;
	trie *next[26];
	trie *fail;
	trie()
	{
		memset(next, 0, sizeof(next));
		fail=0;
	}
};
typedef ptrie *trie;

ptrie r, q[NMAX];
string s;

void insert(ptrie t, int i)
{
	if(i==c.size())
	{
		t->v.pb(i);
		return;
	}
	if(!t->next[c[i]-'a'])
		t->next[c[i]-'a']=new trie();
		
	insert(t->next[c[i]-'a'], i+1);
}

int main()
{
	
	
	return 0;
}


