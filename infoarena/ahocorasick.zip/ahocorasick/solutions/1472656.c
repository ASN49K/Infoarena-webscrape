#include<stdio.h>
#include<string.h>
#include<ctype.h>
int lg,n,l,final[10005],ic,sc;
char tx[1000005],c[10005];
typedef struct A {
    int n0,d[10005],e;
    struct A *f[26],*fail;
}C;
C *q[100100025],*t,*p;
C *V() {
    C *r=(N*)malloc(sizeof(N));
    r->n0=0,r->fail=NULL,memset(r->f,0,sizeof(r->f));
    return r;
}
void ins(ac *t,char *p,int i) {
    if(!isalpha(*p)) {
        t->d[t->e++]=i;
        return;
    }
    int urm=*p-'a';
    if(!t->f[urm])
        t->f[urm]=V();
    ins(t->f[urm],p+1,i);
}
void bfs(ac *t) {
    ac *dolar;
    t->fail=t;
    for(q[ic=sc=1]=t;ic<=sc;++ic) {
        ac *fr=q[ic];
        for(int i=0;i<26;++i)
        if(fr->f[i]) {
            for(dolar=fr->fail;dolar!=t && dolar->f[i]==NULL;dolar=dolar->fail);
            if(dolar->f[i]!=NULL&&dolar->f[i]!=fr->f[i])
                dolar=dolar->f[i];
            fr->f[i]->fail=dolar,q[++sc]=fr->f[i];
        }
    }
    t->fail=NULL;
}
void antibfs(ac *t) {
    for(int i=sc; i>0; --i) {
        ac *fr=q[i];
        if(fr->fail!=NULL)
            fr->fail->n0+=fr->n0;
        for(int j=0;j<fr->e;++j)
            final[fr->d[j]]=fr->n0;
    }
}
int main() {
    freopen("ahocorasick.in","r",stdin),freopen("ahocorasick.out","w",stdout),scanf("%s",tx),scanf("%d",&n),t=V();
    for(int i=1;i<=n;++i)
        scanf("%s",c),ins(t,c,i);
    bfs(t),p=t,lg=strlen(tx);
    for(int i=0;i<lg;++i) {
        int urm=tx[i]-'a';
        for(;p->f[urm]==NULL&&p!=t;p=p->fail);
        if(p->f[urm]!=NULL)
            p=p->f[urm];
        ++p->n0;
    }
    antibfs(t);
    for(int i=1;i<=n;++i)
        printf("%d\n",final[i]);
    return 0;
}
