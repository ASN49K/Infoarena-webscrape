#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("ahocorasick.in");
ofstream fout("ahocorasick.out");
struct trie{
    int sol=0;
    trie *f[26], *ant=0;
    vector<trie*> v;
    trie(){
        for(int i=0;i<26;i++)
            f[i]=0;
        v.clear();
    }
};
trie *root=new trie(),*w[110],*nod,*aux;
queue<trie*> q;
int n,i;
char A[1000010],s[10010];
trie *inserare(trie *r, char *s){
    if(*s==0)
        return r;
    if(r->f[*s-'a']==NULL)
        r->f[*s-'a']=new trie;
    return inserare(r->f[*s-'a'],s+1);
}
void dfs(trie *nod){
    for(int i=0;i<nod->v.size();i++){
        dfs(nod->v[i]);
        nod->sol+=nod->v[i]->sol;
    }
}
int main(){
    fin>>A>>n;
    for(i=1;i<=n;i++){
        fin>>s;
        w[i]=inserare(root,s);
    }
    q.push(root);
    while(!q.empty()){
        nod=q.front();
        q.pop();
        for(i=0;i<26;i++)
            if(nod->f[i]){
                aux=nod->ant;
                while(aux&&aux->f[i]==NULL)
                    aux=aux->ant;
                if(!aux)
                    nod->f[i]->ant=root;
                else
                    nod->f[i]->ant=aux->f[i];
                nod->f[i]->ant->v.push_back(nod->f[i]);
                q.push(nod->f[i]);
            }
    }
    aux=root;
    for(i=0;A[i]!=0;i++){
        while(aux!=root&&aux->f[A[i]-'a']==NULL)
            aux=aux->ant;
        if(aux->f[A[i]-'a']!=NULL)
            aux=aux->f[A[i]-'a'];
        aux->sol++;
    }
    dfs(root);
    for(i=1;i<=n;i++)
        fout<<w[i]->sol<<"\n";
    return 0;
}
