#include <bits/stdc++.h>
std::ifstream cin("ahocorasick.in");
std::ofstream cout("ahocorasick.out");
int ans[110],n,v[1000010][30],pd[1000010],nr;
char a[1000010],s[10010];
std::vector<int>ad[1000010];
void adauga(int poz)
{
    int spoz=0,nod=0;
    while(s[spoz]&&v[nod][s[spoz]-'a'])
    {
        nod=v[nod][s[spoz]-'a'];
        ++spoz;
    }
    while(s[spoz])
    {
        v[nod][s[spoz]-'a']=++nr;
        nod=nr;
        ++spoz;
    }
    ad[nod].push_back(poz);
}
void construiestesufix()
{
    std::queue<int>q;
    for(int i=0;i<26;++i)
        if(v[0][i])
            q.push(v[0][i]);
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(int i=0;i<26;++i)
            if(v[nod][i])
            {
                int nodant=v[nod][27];
                while(nodant!=0&&v[nodant][i]==0)
                    nodant=v[nodant][27];
                if(v[nodant][i])
                {
                    v[v[nod][i]][27]=v[nodant][i];
                    for(auto x:ad[v[nodant][i]])
                        ad[v[nod][i]].push_back(x);
                }
                q.push(v[nod][i]);
            }
    }
}
int main()
{
    cin>>a;
    cin>>n;
    for(int i=1;i<=n;++i)
    {
        cin>>s;
        adauga(i);
    }
    construiestesufix();
    int nod=0;
    for(int i=0;a[i];++i)
    {
        while(nod!=0&&v[nod][a[i]-'a']==0)
            nod=v[nod][27];
        nod=v[nod][a[i]-'a'];
        ++pd[nod];
    }
    for(int nod=0;nod<=nr;++nod)
        if(pd[nod])
            for(auto x:ad[nod])
                ans[x]+=pd[nod];
    for(int i=1;i<=n;++i)
        cout<<ans[i]<<'\n';
    return 0;
}
