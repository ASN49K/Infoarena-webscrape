#include <fstream>
#include <queue>
#include <stack>
using namespace std;

ifstream f("ahocorasick.in");
ofstream g("ahocorasick.out");

struct nod{
    int nr;
    nod* link;
    nod* child[26];
    nod(){
        nr = 0;
        link = NULL;
        for(int i = 0; i < 26; ++ i){
            child[i] = NULL;
        }
    }
};

nod *root, *where[105];
stack<nod*> parcurg;

void ins(nod* node, int ind){
    char c;
    c = f.get();
    if(c < 'a' || c > 'z'){
        where[ind] = node;
        return;
    }
    int lit = c-'a';
    if(node->child[lit] == NULL) node->child[lit] = new nod();
    ins(node->child[lit], ind);
}

void build_prefix(){
    root -> link = root;
    queue<nod*> q;
    q.push(root);
    while(q.size()){
        nod* temp = q.front();
        parcurg.push(temp);
        q.pop();
        for(int i = 0; i < 26; ++ i){
            if(temp->child[i] == NULL) continue;
            nod* sufix = temp->link;
            while(sufix->child[i] == NULL && sufix != root) sufix = sufix->link;
            if(sufix->child[i] != NULL && sufix->child[i] != temp->child[i]) temp->child[i]->link = sufix->child[i];
            else temp->child[i]->link = root;
            q.push(temp->child[i]);
        }
    }
}
int main(){
    root = new nod();
    string s;
    f >> s;
    int n;
    f >> n;
    f.get();
    for(int i = 0; i < n; ++i) ins(root, i);
    build_prefix();

    nod* curr = root;
    for(int i = 0; i < s.size(); ++i){
        int lit = s[i]-'a';
        while(curr != root && curr->child[lit] == NULL) curr = curr->link;
        if(curr -> child[lit] != NULL) curr = curr->child[lit];
        curr->nr++;
    }

    while(parcurg.size()){
        nod* temp = parcurg.top();
        parcurg.pop();
        temp->link->nr += temp->nr;
    }
    for(int i = 0; i < n; ++i) g<<where[i]->nr << '\n';
    return 0;
}
