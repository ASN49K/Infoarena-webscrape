#include <bits/stdc++.h>
#define Nmax 101
using namespace std;

ifstream f("ahocorasick.in");
ofstream g("ahocorasick.out");

int n,rez[Nmax];
string S,c;

struct trie{
    trie *f[26],*fail;
    vector<int> P;
    int val;
    trie()
    {
        val = 0;
        memset(f,0,sizeof(f));
        fail = NULL;
    }
}*T;
vector<trie*> C;

void add(int poz)
{
    trie *nod = T;
    for (int i=0;i<c.size();i++)
    {
        if (nod->f[c[i]-'a']==NULL)
            nod->f[c[i]-'a'] = new trie();
        nod = nod->f[c[i]-'a'];
    }
    nod->P.push_back(poz);
}

void bfs()
{
    C.push_back(T);
    T->fail = T;
    for (int k=0;k<C.size();k++)
    {
        for (int i=0;i<26;i++)
            if (C[k]->f[i]!=NULL)
            {
                trie *nod = C[k]->fail;
                while (nod->f[i]==NULL && nod!=T)
                    nod = nod->fail;
                if (nod->f[i]!=NULL && nod->f[i]!=C[k]->f[i])
                    nod = nod->f[i];
                C[k]->f[i]->fail = nod;
                C.push_back(C[k]->f[i]);
            }
    }
}

void bfs2()
{
    for (int i=C.size()-1;i>=0;i--)
    {
        C[i]->fail->val += C[i]->val;
        for (int j=0;j<C[i]->P.size();j++)
            rez[C[i]->P[j]] += C[i]->val;
    }
}

int main()
{
    T = new trie();
    f>>S;
    f>>n;
    for (int i=1;i<=n;i++)
    {
        f>>c;
        add(i);
    }

    bfs();

    trie *nod = T;
    for (int i=0;i<S.size();i++)
    {
        while (nod->f[S[i]-'a']==NULL && nod!=T)
            nod = nod->fail;
        if (nod->f[S[i]-'a']!=NULL)
            nod = nod->f[S[i]-'a'];
        nod->val++;
    }

    bfs2();

    for (int i=1;i<=n;i++)
        g<<rez[i]<<'\n';

    return 0;
}
