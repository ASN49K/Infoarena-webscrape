#include <bits/stdc++.h>
#define maxText 1000005
#define maxLen 10005
#define maxN 105
#define sigma 26
using namespace std;
struct trie
{
    trie *fiu[sigma];
    trie *fail;
    vector<int>_list;
    int cnt;
    trie()
    {
        for(int i=0;i<sigma;i++)
            fiu[i]=NULL;
        fail=NULL;
        cnt=0;
    }
}*root=new trie();

trie * q[maxLen*maxLen];
int n,i,fq[maxN],st,dr;
char text[maxText],word[maxLen];

queue<trie*>Que;
vector<trie*>node_list;
void _insert(trie *nod,char *s,int idx)
{
    if(!*s){
        nod->_list.push_back(idx);
        return;
    }

    if(nod->fiu[*s-'a']==NULL)
        nod->fiu[*s-'a']=new trie();
    _insert(nod->fiu[*s-'a'],s+1,idx);
}

void solve(trie *root, char *str)
{
    trie *nod=root;
    while(*str)
    {
        while(nod!=root && nod->fiu[*str-'a']==NULL)
            nod=nod->fail;

        if(nod->fiu[*str-'a']!=NULL)
            nod=nod->fiu[*str-'a'];

        nod->cnt++;
        str++;
    }

    for(int i=dr;i>=1;i--)
    {
        for(auto idx:q[i]->_list)
            fq[idx]+=q[i]->cnt;

        if(q[i]->fail!=NULL)
            q[i]->fail->cnt+=q[i]->cnt;
    }
}
int main()
{
    freopen("ahocorasick.in","r",stdin);
    freopen("ahocorasick.out","w",stdout);
    scanf("%s",text);
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        scanf("%s",word);
        _insert(root,word,i);
    }

    root->fail=root;
    for(int i=0;i<sigma;i++)
        if(root->fiu[i]){
            root->fiu[i]->fail=root;
            Que.push(root->fiu[i]);
        }

    q[st=dr=1]=root;
    while(st<=dr)
    {
        trie *nod=q[st];
        for(int i=0;i<sigma;i++)
        {
            if(nod->fiu[i])
            {
                trie *failnod=nod->fail;
                while(failnod!=root && failnod->fiu[i]==NULL)
                    failnod=failnod->fail;

                if(failnod->fiu[i]!=NULL && failnod->fiu[i]!=nod->fiu[i])
                    failnod=failnod->fiu[i];
                nod->fiu[i]->fail=failnod;

                q[++dr]=nod->fiu[i];
            }
        }
        st++;
    }

    solve(root,text);

    for(i=1;i<=n;i++)
        printf("%d\n",fq[i]);
    return 0;
}
