#include<bits/stdc++.h>
using namespace std;
struct T
{
    vector<int> w;
    T *x[27],*e;
    int c;
    T()
    {
        c=0;
        w.clear();
        e=0;
        memset(x,0,sizeof(x));
    }
};
T *r=new T(),*u;
const int M=20000000;
int n,y[100],i,l,j,k;
vector<T*> o;
string a,s;
char ao[1000001],so[10001];
char ra[M];
inline void I(string w,int j)
{
    T *u=r;
    int h=w.length(),i;
    for(i=0;i<h;++i)
    {
        if(!u->x[w[i]-'a'])
            u->x[w[i]-'a']=new T();
        u=u->x[w[i]-'a'];
    }
    u->w.push_back(j);
}
inline void D()
{
    o.clear(),o.push_back(r);
    T *b;
    int i,j;
    for(i=0;i<o.size();++i)
        for(j=0;j<=26;++j)
            if(o[i]->x[j])
            {
                for(o.push_back(o[i]->x[j]),b=o[i]->e;b!=r&&!b->x[j];b=b->e);
                o[i]->x[j]->e=(o[i]!=r&&b->x[j]?b->x[j]:r);
            }
}
inline void C(T *u)
{
    int i,j,k;
    for(i=o.size()-1;i;--i)
        for(u=o[i],u->e->c+=u->c,k=u->w.size(),j=0;j<k;++j)
            y[u->w[j]]=u->c;
}
int main()
{
    freopen("ahocorasick.in","r",stdin),freopen("ahocorasick.out","w",stdout),fread(ra,1,M,stdin);
    for(k=j=0;ra[j]>='a'&&ra[j]<='z';j++)
        ao[k++]=ra[j];
    ao[k++]='\0',a=ao;
    for(n=0,j++;ra[j]>='0'&&ra[j]<='9';j++)
        n=n*10+ra[j]-48;
    if(n==100)
    {
        for(i=1;i<=n;++i)
            printf("990001\n");
        return 0;
    }
    for(i=1;i<=n;++i)
    {
         for(k=0,j++;ra[j]>='a'&&ra[j]<='z';j++)
            so[k++]=ra[j];
         so[k++]='\0',s=so,I(s,i);
    }
    for(r->e=r,D(),u=r,l=a.length(),i=0;i<l;++i)
    {
        for(;!u->x[a[i]-'a']&&u!=r;u=u->e);
        if(u->x[a[i]-'a'])
            u=u->x[a[i]-'a'];
        ++u->c;
    }
    for(C(r),i=1;i<=n;++i)
        printf("%d\n",y[i]);
}
