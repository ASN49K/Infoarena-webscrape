#include <fstream>
#define MOD 98999
#define NMAX 201
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int t,op,n,m,a[NMAX][NMAX],b[NMAX][NMAX];
int main() {
    fin>>t;
    a[1][1]=1;
    for (int i=2;i<NMAX;i++)
        for (int j=1;j<=i;j++)
            a[i][j]=(a[i-1][j-1]-(i-1)*a[i-1][j])%MOD;
    b[1][1]=1;
    for (int i=2;i<NMAX;i++)
        for (int j=1;j<=i;j++)
            b[i][j]=(b[i-1][j-1]+j*b[i-1][j])%MOD;
    while (t--) {
        fin>>op>>n>>m;
        if (op==1)
            fout<<a[n][m]<<"\n";
        else
            fout<<b[n][m]<<"\n";
    }
    return 0;
}
