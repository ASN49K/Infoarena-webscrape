#include <fstream>
using namespace std;

ifstream cin ("stirling.in");
ofstream cout ("stirling.out");

int stirling[2][201][201];
const int mod = 98999;

int main ()
{
    stirling[0][0][0] = stirling[1][0][0] = 1;
    for (int total = 1 ; total <= 200 ; total++)
        for (int luate = 1 ; luate <= total ; luate++)
        {
            stirling[0][total][luate] = (stirling[0][total - 1][luate - 1] - stirling[0][total - 1][luate] * (total - 1)) % mod;
            stirling[1][total][luate] = (stirling[1][total - 1][luate - 1] + stirling[1][total - 1][luate] * luate) % mod;
        }

    int numar_intrebari;
    cin >> numar_intrebari;

    for (int tip , total , luate ; numar_intrebari ; numar_intrebari--)
        { cin >> tip >> total >> luate; cout << stirling[tip - 1][total][luate] << '\n'; }

    cout.close(); cin.close();
    return 0;
}