#include <iostream>
#include <fstream>
#define R 98999
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int stir2[203][203],i,j,n;
int stir1[203][203];
int main()
{
    f>>n;
    stir2[0][0]=1;
    stir1[0][0]=1;
    for(i=1;i<=200;i++)
        for(j=1;j<=i;j++)
        {
            stir2[i][j]=(stir2[i-1][j-1]+j*stir2[i-1][j])%R;
            stir1[i][j]=((i-1)*stir1[i-1][j]+stir1[i-1][j-1])%R;
        }
    for(i=1;i<=n;i++)
    {
        int speta,x,y;
        f>>speta>>x>>y;
        if(speta==2)
            g<<stir2[x][y]<<'\n';
        else g<<stir1[x][y]<<'\n';
    }

}
