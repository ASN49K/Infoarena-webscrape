#include <cstdio>

#define Nmax 205
#define Mmax 205
#define mod 98999

using namespace std;

int s[Nmax][Mmax],S[Nmax][Mmax];

int main()
{
    freopen("stirling.in","rt",stdin);
    freopen("stirling.out","wt",stdout);

    int t,n,m,x,i,j;

    s[0][0]=1;
    S[0][0]=1;
    for(i=1;i<=Nmax;i++) {
        for(j=1;j<=Mmax;j++) {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%mod;
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%mod;
        }
    }

    scanf("%d",&t);
    for(i=0;i<t;i++) {
        scanf("%d%d%d",&x,&n,&m);
        switch(x) {
        case 1:
            printf("%d\n",s[n][m]);
            break;
        case 2:
            printf("%d\n",S[n][m]);
            break;
        }
    }

    return 0;
}
