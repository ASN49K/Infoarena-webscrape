#include<fstream>
using namespace std;

ifstream cin("grader_test2.in");
ofstream cout("stirling.out");

const int nmax = 210, p=98999;

int s[nmax][nmax],S[nmax][nmax],t,n,m,i,j,x;

int main()
{
    s[1][1]=S[1][1]=1;
    for (i=2;i<nmax;i++)
        for (j=1;j<=i;j++)
        s[i][j]=( s[i-1][j-1] - (i-1)*s[i-1][j] ) % p,
        S[i][j]=( S[i-1][j-1] + j*S[i-1][j] ) % p;
    cin>>t;
    for (; t -- ;)
    {
        cin>>x>>n>>m;
        if (x==1) cout<<s[n][m]<<"\n";
         else cout<<S[n][m]<<"\n";
    }
    return 0;
}
