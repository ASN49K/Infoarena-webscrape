#include <fstream>
#include <iostream>
#define MOD 98999

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int T, type, a, b, s[205][205], S[205][205];

void preprocess()
{
	s[1][1] = S[1][1] = 1;
	for(int i = 2; i < 205; ++i)
		for(int j = 1; j <= i; ++j)
		{
			s[i][j] = (s[i-1][j-1] - (i-1) * s[i-1][j]) % MOD;
			S[i][j] = (S[i-1][j-1] + j * S[i-1][j]) % MOD;
		}
}

int main()
{
	preprocess();
	
	f >> T;
	while( T-- )
	{
		f >> type >> a >> b;
		switch( type )
		{
			case 1: g << s[a][b] << "\n"; break;
			case 2: g << S[a][b] << "\n"; break;
		}
	}
}
