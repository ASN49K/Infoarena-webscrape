#include <bits/stdc++.h>

using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");


int a[205][205],b[205][205];
int main()
{
    a[1][1]=b[1][1]=1;
    for(int i=1; i<=200; i++)
        for(int j=1; j<=200; j++)
            if(i!=1||j!=1)
                a[i][j]=a[i-1][j-1]-(i-1)*a[i-1][j],b[i][j]=b[i-1][j-1]+j*a[i-1][j];
    int T;
    f>>T;
    while(T--)
    {
        int cer,x,y;
        f>>cer>>x>>y;
        assert(cer==1||cer==2);
        if(cer==1)
            g<<a[x][y]<<'\n';
        else
            g<<b[x][y]<<'\n';
    }

    return 0;
}
