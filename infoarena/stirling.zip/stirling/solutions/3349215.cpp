#include <iostream>
#include <fstream>
#define VMAX 205
#define INF 2147000000
#define double long double
using namespace std;
ifstream fin ("stirling.in");
ofstream fout ("stirling.out");

const int mod = 98999;
int sterling[2][VMAX][VMAX];

signed main()
{
    long long int n,m,i,j,k,t,q,nr,p;
    sterling[0][0][0]=sterling[1][0][0]=1;
    for(i=1;i<VMAX;i++)
    {
        for(j=1;j<=VMAX;j++)
        {
            sterling[1][i][j]=(sterling[1][i-1][j-1]+sterling[1][i-1][j]*j)%mod;
            sterling[0][i][j]=(sterling[0][i-1][j-1]+(i-1)*sterling[0][i-1][j])%mod;
        }
    }

    fin>>t;
    while(t--)
    {
        fin>>k>>i>>j;
        fout<<sterling[k-1][i][j]<<'\n';
    }


    return 0;
}