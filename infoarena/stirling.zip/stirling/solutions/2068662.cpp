#include <fstream>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int t, n, m, x, s[205][205], S[205][205];

void calculare_s();
void calculare_S();

int main()
{
    calculare_s();
    calculare_S();

    fin>>t;

    int i;

    for(i=1; i<=t; i++)
        {
        fin>>x>>n>>m;
        if(x==1)
            fout<<s[n][m]<<'\n';
            else
            fout<<S[n][m]<<'\n';
        }
    return 0;
}


void calculare_s()
{   int i, j;
    s[1][1]= 1;
    for(i=2; i<205; i++)
        for(j=1; j<=i ; j++)
            s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j];
}

void calculare_S()
{   int i, j;
    S[1][1]=1;
    for(i=2; i<205; i++)
        for(j=1; j<=i; j++)
            S[i][j]=S[i-1][j-1]+j*S[i-1][j];
}
