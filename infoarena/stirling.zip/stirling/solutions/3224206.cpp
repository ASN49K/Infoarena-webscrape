#include <bits/stdc++.h>
using namespace std;
const int MAXN = 200, MAXT = 1000, MOD = 98999;
ifstream f("stirling.in");
ofstream g("stirling.out");
int t, speta, n, m;
int s1[MAXN + 2][MAXN + 2], s2[MAXN + 2][MAXN + 2];

void calcS1() {
	s1[1][1] = 1;

	for (int i = 2; i <= MAXN; ++ i) {
		for (int j = 1; j <= i; ++ j) {
			s1[i][j] = (s1[i - 1][j - 1] - (i - 1) * s1[i - 1][j]) % MOD;
		}
	}
}

void calcS2() {
	s2[1][1] = 1;

	for (int i = 2; i <= MAXN; ++ i) {
		for (int j = 1; j <= i; ++ j) {
			s2[i][j] = (s2[i - 1][j - 1] + j * s2[i - 1][j]) % MOD;
		}
	}

}


int main() {
	calcS1();
	calcS2();
	f >> t;
	while (t --) {
		f >> speta >> n >> m;
		if (speta == 1)
			g << s1[n][m] << '\n';
		else
			g << s2[n][m] << '\n';

	}

	return 0;
}