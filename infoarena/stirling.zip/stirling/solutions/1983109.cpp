#include <fstream>
using namespace std;
ifstream cin("stirling.in");
ofstream cout("stirling.out");

int t,n,m,x,y,a[205][205],b[205][205],i,j,c;
void stirling()
{
    a[0][0]=1;
    b[0][0]=1;
    for(int i=1;i<=200;++i)
        for(int j=1;j<=200;++j)
        {
            a[i][j]=a[i-1][j-1] - (i-1)*a[i-1][j];
            b[i][j]=b[i-1][j-1] + m*a[i-1][j];
        }




}
int main()
{
    stirling();
    cin>>t;
    while(t--)
    {
        cin>>c>>x>>y;
        if(c==1) cout<<a[x][y]<<"\n";
        else cout<<b[x][y]<<"\n";
    }
    return 0;
}
