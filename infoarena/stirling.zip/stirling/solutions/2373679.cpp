#include <cstdio>
#define MOD 98999

using namespace std;

int n, m, t, x;
int s2[205][205];
int s1[205][205];

void speta2(int i, int j)
{
    for(int i=1; i<=200; i++)
    {
        for(int j=1; j<=i; j++)
            s2[i][j]=(s2[i-1][j-1]+(j*s2[i-1][j])%MOD)%MOD;
    }

}

void speta1(int i, int j)
{
    for(int i=1; i<=200; i++)
    {
        for(int j=1; j<=i; j++)
            s1[i][j]=(s1[i-1][j-1]-((i-1)*s1[i-1][j])%MOD)%MOD;
    }
}

int main()
{

    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    scanf("%d", &t);
    s2[1][1]=1;
    s2[0][0]=1;
    s1[1][1]=1;
    s1[0][0]=1;
    speta2(2, 1);
    speta1(2, 1);
    for(int i=1; i<=t; i++)
    {
        scanf("%d %d %d", &x ,&n, &m);
        if(x == 1)
        {
            printf("%d\n", s1[n][m]);
        }
        else
        {
            printf("%d\n", s2[n][m]);
        }
    }

    return 0;
}
