#include <iostream>
#include <fstream>

using namespace std;

int stirling1(int n, int m)
{

    if(n == m)
        return 1;

    if(m == 0)
        return 0;

    return stirling1(n - 1, m - 1) - (n - 1) * stirling1(n - 1, m) % 98999;

}

int stirling2(int n, int m)
{
    if(n == m)
        return 1;
    if(m == 1)
        return 1;

    return stirling2(n - 1, m - 1) + m * stirling2(n - 1, m) % 98999;

}

int main()
{

    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    int T, x, n, m;

    scanf("%d", &T);

    //cout<<T;

    for(int i=1;i<=T;++i)
    {
        scanf("%d %d %d", &x, &n, &m);

        if(x == 1)
            cout<<stirling1(n, m)<<"\n";
        else if(x == 2)
            cout<<stirling2(n, m)<<"\n";
    }
    return 0;
}
