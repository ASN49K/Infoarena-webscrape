#include <cstdio>
#define MAXN 200
int s[MAXN+1][MAXN+1],S[MAXN+1][MAXN+1];
int main(){
   FILE*fi,*fout;
   int i,j,n,t,m,x;
   fi=fopen("stirling.in" ,"r");
   fout=fopen("stirling.out" ,"w");
   fscanf(fi,"%d" ,&t);
   s[1][1]=1;
   for(i=1;i<=MAXN;i++)
    for(j=1;j<=MAXN;j++)
     if(!(i==1&&j==1))
       s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j];
   S[1][1]=1;
   for(i=1;i<=MAXN;i++)
    for(j=1;j<=MAXN;j++)
     if(!(i==1&&j==1))
       S[i][j]=S[i-1][j]*j+S[i-1][j-1];
   while(t>0){
      t--;
      fscanf(fi,"%d%d%d" ,&x,&n,&m);
      if(x==1)
        fprintf(fout,"%d\n" ,s[n][m]);
      else
        fprintf(fout,"%d\n" ,S[n][m]);
   }
   fclose(fi);
   fclose(fout);
   return 0;
}
