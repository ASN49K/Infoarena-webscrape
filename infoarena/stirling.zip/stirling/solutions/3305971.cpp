#include <iostream>
#include <fstream>

using namespace std;
const int MOD = 98999, NMAX = 200;

int T, n, m, speta;
int S[NMAX + 1][NMAX + 1], s[NMAX + 1][NMAX + 1];

ifstream f("stirling.in");
ofstream g("stirling.out");
void precalc()
{
    S[0][0] = s[0][0] = 1;
    for(int i = 1; i <= NMAX; i++)
        for(int j = 1; j <= i; j++)
        {
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
        }
}

int main()
{
    f >> T;
    precalc();
    for(int i = 1; i <= T; i++)
    {
        f >> speta >> n >> m;
        if(speta == 1)
            g << s[n][m] << '\n';
        else
            g << S[n][m] << '\n';
    }
    f.close();
    g.close();
    return 0;
}
