#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int t, x, n, m;
int st1[205][205], st2[205][205];
void sp1()
{
    st1[1][1]=1;
    for(int i=2;i<=200;i++)
        for(int j=1;j<=i;j++)
                st1[i][j]=(st1[i-1][j-1]-(i-1)*st1[i-1][j])%98999;
}
void sp2()
{
    st2[1][1]=1;
    for(int i=2;i<=200;i++)
        for(int j=1;j<=i;j++)
                st2[i][j]=(st2[i-1][j-1]+j*st2[i-1][j])%98999;
}
int main()
{
    sp1();
    sp2();
    fin >> t;
    for(int i=1;i<=t;i++)
    {
        fin >> x >> n >> m;
        if(x==1)
        {
            fout << st1[n][m] << '\n';
        }
        else
        {
            fout << st2[n][m] << '\n';
        }
    }
    return 0;
}
