﻿#include <fstream>
#include <bitset>

using namespace std;

ifstream in("stirling.in");
ofstream out("stirling.out");

int s[201][201]={},S[201][201]={},MOD=98999,T,x,m,n;

int main()
{
	s[0][0]=1,S[0][0]=1;
	for(int i=1;i<=200;i++)
		for(int j=1;j<=i;j++)
		{
			s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
			S[i][j]=(S[i-1][j-1]+j*s[i-1][j])%MOD;
		}
	in>>T;
	for(int i=1;i<=T;i++)
	{
		in>>x>>n>>m;
		if(x==1)
			out<<s[n][m];
		else
			out<<S[n][m];
	}
	return 0;
}