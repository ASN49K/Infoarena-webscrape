#include<bits/stdc++.h>
using namespace std;
ifstream fin ("stirling.in");
ofstream fout("stirling.out");
int dp1[202][202],dp2[202][202],mod=98999;

int main ()
{
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    int i,j,t,tip,n,m;
    dp1[1][1]=1,dp2[1][1]=1;
    for (i=2;i<=200;i++)
        for (j=1;j<=200;j++)
        {
            dp1[i][j]=(dp1[i-1][j-1]+(1-i)*dp1[i-1][j])%mod;
            dp2[i][j]=(dp2[i-1][j-1]+dp2[i-1][j]*j)%mod;
        }

    fin>>t;
    while (t--)
    {
        fin>>tip>>n>>m;
        if (tip==1)
            fout<<dp1[n][m]<<'\n';
        else    fout<<dp2[n][m]<<'\n';
    }
}
