#include <bits/stdc++.h>

using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int main()
{int t,n,m,k,u,i,j;
fin>>t;
for(u=1;u<=t;u++){
    fin>>k>>n>>m;
    int a[205][205]={0};
  if(k==1){
    for(i=1;i<=n;i++){
        for(j=1;j<=m;j++){
            if(i==1 && j==1)
            a[i][j]=1;
        else{
            if(i>=j)
            a[i][j]=a[i-1][j-1]-(i-1)*a[i-1][j];}}}
    fout<<a[n][m]<<"\n";}
else{
      for(i=1;i<=n;i++){
            a[i][1]=1;
        for(j=2;j<=m;j++){
            if(i==1)
            a[i][j]=1;
        else{
        a[i][j]=a[i-1][j-1]+j*a[i-1][j];}}}
    fout<<a[n][m]<<"\n";}}
    return 0;
}
