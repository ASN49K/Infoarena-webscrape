#include <iostream>
#include <fstream>

using namespace std;

int s[201][201], S[201][201];

void initStirling()
{
    for (int i=0;i<=200;i++)
    {
        for (int j=0;j<=200;j++)
        {
            if (j>i)
                break;
            if (j==0)
            {
                if (i==0)
                    s[i][j]=1;
                else
                    s[i][j]=0;
            }
            else if (j==i)
            {
                s[i][j]=1;
            }
            else
            {
                s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999;
            }
        }
    }
    for (int i=0;i<=200;i++)
    {
        for (int j=0;j<=200;j++)
        {
            if (j>i)
                break;
            if (j==0)
            {
                if (i==0)
                    S[i][j]=1;
                else
                    S[i][j]=0;
            }
            else if (j==i)
            {
                S[i][j]=1;
            }
            else
            {
                S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
            }
        }
    }
}

void Solve()
{
    ifstream f("stirling.in");
    ofstream g("stirling.out");
    int T, a, b, c;
    f>>T;
    while (T--)
    {
        f>>a>>b>>c;
        if (a==1)
            g<<s[b][c]<<'\n';
        else
            g<<S[b][c]<<'\n';
    }
}

int main()
{
    initStirling();
    Solve();
}
