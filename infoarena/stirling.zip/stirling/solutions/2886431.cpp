#include <bits/stdc++.h>

using namespace std;

const int NMAX = 200,MOD = 98999;
int s[NMAX + 5][NMAX + 5],S[NMAX + 5][NMAX + 5];

void precalc() {
    s[1][1] = 1;
    for (int i = 2;i <= NMAX;i++)
        for(int j = 1;j <= i;j++)
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
    S[1][1] = 1;
    for (int i = 2;i <= NMAX;i++)
        for(int j = 1;j <= i;j++)
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
}
int main()
{
    ifstream fin("stirling.in");
    ofstream fout("stirling.out");
    int t,c,n,m;
    fin >> t;
    precalc();
    while (t--) {
        fin >> c >> n >> m;
        if (c == 1)
            fout << s[n][m] << '\n';
        else
            fout << S[n][m] << '\n';
    }
    return 0;
}
