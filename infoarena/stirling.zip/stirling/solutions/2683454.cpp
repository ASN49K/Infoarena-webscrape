#include <fstream>
using namespace std;
ifstream in("stirling.in");
ofstream out("stirling.out");

const int mod = 98999, nmax = 200;
int t, s[nmax + 5][nmax + 5], S[nmax + 5][nmax + 5];

int main()
{
    s[1][1] = S[1][1] = 1;
    for(int i = 2; i<=nmax; i++)
    {
        for(int j = 1; j<=i; j++)
        {
            s[i][j] = s[i - 1][j - 1] - (i - 1) * s[i - 1][j];
            S[i][j] = S[i - 1][j - 1] + j * S[i - 1][j];

            if(s[i][j]>mod || s[i][j]<-mod)
                s[i][j] %= mod;
            if(S[i][j]>mod || S[i][j]<-mod)
                S[i][j] %= mod;
        }
    }

    in>>t;
    for(int i = 0; i<t; i++)
    {
        int tip, n, m;
        in>>tip>>n>>m;

        if(tip==1)
            out<<s[n][m]<<'\n';
        if(tip==2)
            out<<S[n][m]<<'\n';
    }

    return 0;
}
