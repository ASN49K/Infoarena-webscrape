#include <iostream>
#include <fstream>
#define DN 205
#define MAX 200
#define MOD 98999
using namespace std;

int SI[DN][DN],SII[DN][DN];

int main()
{
    int t;
    ifstream f("stirling.in");
    ofstream g("stirling.out");
    f>>t;
    SI[0][0]=0;
    for(int i=1;i<=MAX;++i)
        {
            SI[i][i]=1;
            SII[i][i]=1;
            SII[i][1]=1;
        }

    for(int i=2;i<=MAX;++i)
        for(int j=1;j<=i;++j)
        {
            SI[i][j] = (SI[i-1][j-1] - SI[i-1][j]*(i-1) ) % MOD;
            SII[i][j] = ( SII[i-1][j-1] + SII[i-1][j]*j ) % MOD;

        }
    for(;t--;)
    {
        int a,b,c;
        f>>a>>b>>c;
        if(a==1)
            g<<SI[b][c]<<"\n";
        else
            g<<SII[b][c]<<"\n";

    }
    return 0;
}
