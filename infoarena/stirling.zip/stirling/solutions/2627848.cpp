#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("stirling.in");
ofstream fout ("stirling.out");

const int MAXN = 200;
const int MOD = 98999;

int t;
int s[2][MAXN+3][MAXN+3];

void speta1()
{
    s[0][0][0] = 1;
    for(int i = 0; i <= MAXN; i++)
        for(int j = 0; j <= MAXN; j++)
            s[0][i][j] += (s[0][i-1][j-1]%MOD - (1LL*(i-1)*s[0][i-1][j])%MOD)%MOD;
}

void speta2()
{
    s[1][0][0] = 1;
    for(int i = 1; i <= MAXN; i++)
        for(int j = 1; j <= MAXN; j++)
            s[1][i][j] = ((1LL*j*s[1][i-1][j])%MOD + s[1][i-1][j-1]%MOD)%MOD;
}

int main()
{
    speta1();
    speta2();
    fin >> t;
    for(int i = 0; i < t; i++)
    {
        int cer, n, m;
        fin >> cer >> n >> m;
        fout << s[cer-1][n][m] << "\n";
    }
    return 0;
}
