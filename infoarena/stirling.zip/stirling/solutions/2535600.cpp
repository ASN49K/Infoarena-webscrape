#include <fstream>
#define MOD 98999
using namespace std;
ifstream in ("stirling.in");
ofstream out ("stirling.out");
long long n,t,i,k,x;
long long puss(long long n,long long k)
{long long s;
    if(k==1)return 1;
s=puss(n-1,k-1)%MOD;
if(n-1>=k)s+=k*puss(n-1,k)%MOD;
return s;
}
int main()
{
    in>>t;
    for(i=1;i<=t;i++)
    {
        in>>x>>n>>k;
        if(x==1)out<<"kys"<<'\n';
        else{out<<puss(n,k)%MOD<<'\n';}
    }
    return 0;
}
