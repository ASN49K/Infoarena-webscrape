#include <fstream>
#include <cstring>

constexpr const int MOD = 98999;
constexpr const int MAX_N = 200;

int s[MAX_N + 1][MAX_N + 1] = {0};
int S[MAX_N + 1][MAX_N + 1] = {0};

int calc_s(int n, int k) {
    if (n == 0 && k == 0) return 1;
    if (n == 0 || k == 0) return 0;

    if (s[n][k] != -1) return s[n][k];

    return s[n][k] = (calc_s(n - 1, k - 1) - (n - 1) * calc_s(n - 1, k)) % MOD;
}

int calc_S(int n, int k) {
    if (n == k) return 1;
    if (n == 0 || k == 0) return 0;
    if (S[n][k] != -1) return S[n][k];

    return S[n][k] = (k * calc_S(n - 1, k) + calc_s(n - 1, k - 1)) % MOD;
}

int main() {
    std::ifstream input("stirling.in");
    std::ofstream output("stirling.out");

    memset(S, -1, sizeof S);
    memset(s, -1, sizeof s);

    int t;
    input >> t;
    while (t--) {
        int op, n, k;
        input >> op >> n >> k;
        output << (op == 1 ? calc_s(n, k) : calc_S(n, k)) << '\n';
    }
    return 0;
}
