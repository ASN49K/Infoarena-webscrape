#include <fstream>
#define MOD 98999
using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int s1stirling[201][201];
int s2stirling[201][201];

void formarestirlin_despeta_1(){
    s1stirling[0][0]=1;
    s1stirling[1][1]=1;
    for(int n=1; n<=200; n++){
        for(int k=n; k>0; k--)
            s1stirling[n][k]=(s1stirling[n-1][k-1]-(n-1)*s1stirling[n-1][k])%MOD;
    }
}

void formarestirlin_despeta_2(){
    s2stirling[0][0]=1;
    s2stirling[1][1]=1;
    for(int n=1; n<=200; n++){
        for(int k=n; k>0; k--)
            s2stirling[n][k]=(s2stirling[n-1][k-1]+k*s2stirling[n-1][k])%MOD;
    }
}

int n, k;
int t, tip;

int main(){
    formarestirlin_despeta_1();
    formarestirlin_despeta_2();
    f>>t;
    for(int i=1;i<=t;i++){
        f>>tip>>n>>k;
        if(tip==1)
            g<<s1stirling[n][k]%MOD<<'\n';
        else g<<s2stirling[n][k]%MOD<<'\n';
    }
    return 0;
}
