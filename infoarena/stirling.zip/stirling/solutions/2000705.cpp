#include <fstream>
#define MOD 98999

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int T,n,m,p,nr,s[201][201],S[201][201];

void __precalculare_s()
{
    s[1][1]=1;
    for (int i=2;i<=200;i++)
        for (int j=1;j<=i;j++)
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
}

void __precalculare_S()
{
    S[1][1]=1;
    for (int i=2;i<=200;i++)
        for (int j=1;j<=i;j++)
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
}

int main()
{
    fin >> T;

    __precalculare_s();
    __precalculare_S();

    while(T--)
    {
        fin >> p >> n >> m;
        if (p==1)
            fout << s[n][m] << "\n";
        else fout << S[n][m] << "\n";
    }

    return 0;
}
