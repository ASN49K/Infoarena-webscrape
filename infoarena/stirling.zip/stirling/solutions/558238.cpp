#include <fstream>
#include <cstdlib>
#define MODULO 98999

using namespace std;
int S[211][211], s[211][211];
int main( void )
{
	int N, M, i, j;
	ifstream in( "stirling.in" );
	ofstream out( "stirling.out" );
	S[1][1]=s[1][1]=1;
	for( i=2; i <= 200; ++i )
		for( j=1; j <= i; ++j )
			S[i][j]=(S[i-1][j-1]+1LL*j*S[i-1][j])%MODULO, s[i][j]=( s[i-1][j-1]-(i-1)*s[i-1][j] )%MODULO;
	for( in>>M; M; --M )
	{
		in>>N>>i>>j;
		switch(N)
		{
			case 1 : out<<s[i][j]<<'\n'; break;
			case 2 : out<<S[i][j]<<'\n'; break;
		}
	}

}