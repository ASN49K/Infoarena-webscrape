#include <iostream>
#include <fstream>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
const int MOD=98999;
int s[202][202],S[202][202];
int main()
{
    int i,j,n,x,m;
    s[1][1]=1;
    for(i=1;i<=200;i++)
        for(j=1;j<=i;j++)
            if(!(i==1&&j==1))
                s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
    S[1][1]=1;
    for(i=1;i<=200;i++)
        for(j=1;j<=i;j++)
            if(!(i==1&&j==1))
                S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
    int nrTeste;
    f>>nrTeste;
    for(i=1;i<=nrTeste;i++)
    {
        f>>x>>n>>m;
        if(x==1)
            g<<s[n][m]%MOD<<'\n';
        else g<<S[n][m]%MOD<<'\n';
    }
}
