#include<cstdio>
using namespace std;
int t,n,m,x,s[201][201],S[201][201];
int main(){
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    s[1][1]=1;
    S[1][1]=1;
    for(int i=2;i<201;i++)
        for(int j=1;j<201;j++){
            s[i][j]=(s[i-1][j-1]-((i-1)*s[i-1][j])%98999)%98999;
            S[i][j]=(S[i-1][j-1]+(j*S[i-1][j])%98999)%98999;
        }
    scanf("%d",&t);
    for(int i=1;i<=t;i++){
        scanf("%d%d%d",&x,&n,&m);
        if(x==1)
            printf("%d\n",s[n][m]);
        else
            printf("%d\n",S[n][m]);
    }
    return 0;
}
