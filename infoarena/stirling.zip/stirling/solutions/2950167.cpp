#include <bits/stdc++.h>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

#define MOD 98999

int T;
int dp[2][201][201];

void gen(){
    // base

    dp[0][1][1] = 1;
    dp[1][0][0] = 1;


    for(int i = 2; i <= 200; i++){
        for(int j = 0; j <= i; j++){
            dp[0][i][j] = (dp[0][i-1][j] * (1 - i) + dp[0][i-1][j-1]) % MOD;
        }
    }

    for(int i = 1; i <= 200; i++){
        for(int j = 1; j <= i; j++){
            dp[1][i][j] = (dp[1][i-1][j-1] + dp[1][i-1][j] * j) % MOD;
        }
    }
}

int main()
{
    gen();

    fin >> T;

    for(int i = 0; i < T; i++){
        int x, n, m;

        fin >> x >> n >> m;

        fout << dp[x-1][n][m] << '\n';
    }

    return 0;
}
