#include <fstream>

using namespace std;
int n,i,j,I[205][205],II[205][205],o,a,b;
int main()
{
    ifstream f("stirling.in");
    ofstream g("stirling.out");
    f>>n;
    for(i=1;i<=200;i++)
    for(j=1;j<=i;j++)
    {
        if(i==j)
        I[i][j]=1,II[i][j]=1;
        else
        {
            I[i][j]=(I[i-1][j-1]-(i-1)*I[i-1][j])%98999;
            II[i][j]=(II[i-1][j-1]+j*II[i-1][j])%98999;
        }
    }

    for(i=1;i<=n;i++)
    {
        f>>o>>a>>b;
        if(o==1)
        g<<I[a][b]<<'\n';
        else
        g<<II[a][b]<<'\n';
    }
f.close();
g.close();
    return 0;
}
