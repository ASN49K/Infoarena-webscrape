#include <bits/stdc++.h>
#define M 98999
using namespace std;
ifstream in("stirling.in");
ofstream out("stirling.out");
long long s[205][205],S[205][205];
int x,i,n,m,k,l,j;

int main()
{
    s[1][1]=S[1][1]=1;
    for (i=2;i<=200;i++)
        for (j=1;j<=i;j++)
        {
            s[i][j]=(s[i-1][j-1]-s[i-1][j]*(i-1)%M)%M;
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j]%M)%M;
        }
    in>>k;
    for (l=1;l<=k;l++)
    {
        in>>x>>n>>m;
        if (x==1)
        out<<s[n][m]<<'\n';
        else
        out<<S[n][m]<<'\n';
    }
    return 0;
}
