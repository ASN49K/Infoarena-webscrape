#include <bits/stdc++.h>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
// #define f cin
// #define g cout
const int nmax = 209, mod = 98999;
int s1[nmax][nmax], s2[nmax][nmax];
int c1(int x, int y)
{
    if (s1[x][y] == (0x3f3f3f3f))
    {
        if (!x || !y || x < y)
            s1[x][y] = 0;
        else if (x == 1 && y == 1)
            s1[x][y] = 1;
        else
            s1[x][y] = (c1(x - 1, y - 1) - (x - 1) * c1(x - 1, y)) % mod;
    }
    return s1[x][y];
}
int c2(int x, int y)
{
    if (s2[x][y] == (0x3f3f3f3f))
    {
        if (!x || !y || x < y)
            s2[x][y] = 0;
        else if (x == 1 && y == 1)
            s2[x][y] = 1;
        else
            s2[x][y] = (c2(x - 1, y - 1) + y * c2(x - 1, y)) % mod;
    }
    return s2[x][y];
}
int32_t main()
{
    memset(s1, 0x3f3f3f3f, sizeof s1);
    memset(s2, 0x3f3f3f3f, sizeof s2);
    int t;
    f >> t;
    for (int n, m, x; t; t--)
    {
        f >> x >> n >> m;
        if (x == 1)
            g << c1(n, m) << '\n';
        else
            g << c2(n, m) << '\n';
    }
    return 0;
}
