#include<bits/stdc++.h>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int T,x,N,M,s[201][201],S[201][201];
void sp1(){
    s[1][1]=1;
    for(int i=2;i<201;++i)
        for(int j=1;j<=i;++j)
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999;
}
void sp2(){
    S[1][1]=1;
    for(int i=2;i<201;++i)
        for(int j=1;j<=i;++j)
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
}
int main()
{
    f>>T;
    sp1();
    sp2();
    while(T--){
        f>>x>>N>>M;
        if(x==1)g<<s[N][M]<<'\n';
        else g<<S[N][M]<<'\n';
    }
    return 0;
}
