#include<cstdio>
#define N_MAX 210
#define MOD 98999
using namespace std;
int S[3][N_MAX][N_MAX],T,k,x,y;
inline void PreCalc_S1(int N)
{
    S[1][1][1]=1;
    for (int i=2;i<=N;++i)
        for (int j=1;j<=i;++j)
            S[1][i][j]=(S[1][i-1][j-1] - (i-1)*S[1][i-1][j])%MOD;
}
inline void PreCalc_S2(int N)
{
    S[2][1][1]=1;
    for (int i=2;i<=N;++i)
        for (int j=1;j<=i;++j)
            S[2][i][j]=(S[2][i-1][j-1] + j*S[2][i-1][j])%MOD;
}
int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    PreCalc_S1(N_MAX-8);
    PreCalc_S2(N_MAX-8);
    scanf("%d",&T);
    for (int i=1;i<=T;++i)
    {
        scanf("%d%d%d",&k,&x,&y);
        printf("%d\n",S[k][x][y]);
    }
    fclose(stdin); fclose(stdout);
    return 0;
}
