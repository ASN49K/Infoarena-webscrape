#include <bits/stdc++.h>
using namespace std;
 
#define pb push_back
#define mp make_pair
#define all(x) (x).begin(), (x).end()
#define imax INT_MAX
#define llmax LLONG_MAX
#define sz(x) (int((x).size()))
#define start ios_base::sync_with_stdio(false), cin.tie(0)
#define finish fin.close(), fout.close()
 
 
using ll = long long;
using uint = unsigned int;
 
const string filename = "stirling";
 
fstream fin(filename + ".in");
ofstream fout(filename + ".out");
 

const int mod = 98999;

int n, m;
int s1[203][203], s2[203][203];


void pre_s1()
{
    s1[1][1] = 1;
    for(int i = 2; i <= 200; ++i)
        for(int j = 1; j <= i; ++j)
            s1[i][j] = (s1[i - 1][j - 1] - s1[i - 1][j] * (i - 1)) % mod;
}

void pre_s2()
{
    s2[1][1] = 1;
    for(int i = 2; i <= 200; ++i)
        for(int j = 1; j <= i; ++j)
            s2[i][j] = (s2[i - 1][j - 1] + s2[i - 1][j] * j) % mod;
}

int main()
{
	start;
    
    pre_s1();
    pre_s2();

    short op;
    int q;
    fin >> q;
    while(q--)
    {
        fin >> op >> n >> m;
        if(op == 1)
            fout << s1[n][m];
        else fout << s2[n][m];
        fout << '\n';
    }

	finish;	
	return 0;	
}