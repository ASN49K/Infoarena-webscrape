#include<cstdio>
int t,n,m,i,j,s[201][201],S[201][201];
int main()
{freopen("stirling.in","r",stdin);
freopen("stirling.out","w",stdout);
scanf("%d",&t);
for(i=1;i<201;i++)
      for(j=1;j<201;j++)
      if(i>j)
              s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999,S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
      else
              if(i==j)
                       s[i][j]=S[i][j]=1;
while(t--)
      scanf("%d%d%d",&i,&n,&m),
      printf("%d\n",i==1?s[n][m]:S[n][m]);
return 0;}
