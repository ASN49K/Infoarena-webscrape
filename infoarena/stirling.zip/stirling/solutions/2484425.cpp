// infoarena 049 Numerele lui Stirling
#include <fstream>
#include <string>
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");

int s[201][201],S[201][201];

void stirling()
{
  int n,m;
  s[0][0]=1;
  s[0][1]=1;
  S[0][0]=1;
  S[0][1]=1;
  for(n=1;n<=200;n++)
    for(m=1;m<=n;m++)
    {
      s[n][m]=s[n-1][m-1]-(n-1)*s[n-1][m];
      S[n][n]=S[n-1][m-1]+m*S[n-1][m];
    }
}

int main()
{
    int T,x,n,m,i;
    stirling();
    fin>>T;
    for(i=1;i<=T;i++)
    {
        fin>>x>>n>>m;
        if(x==1)
          fout<<s[n][m]<<'\n';
        else
          fout<<S[n][m]<<'\n';
    }
}
