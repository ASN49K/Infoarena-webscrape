#include<stdio.h>
#define Nmax 210
#define Mod 98999

int S1[Nmax][Nmax],S2[Nmax][Nmax],n,k,x,T;

void preprocesare()
{
	int i,j;
	
	S1[0][0] = S2[0][0] = 1 ;
	
	for ( i = 1 ; i <= 200 ; i++ )
		for ( j = 1 ; j <= i ; j++ )
			S1[i][j] = ( S1[i-1][j-1] - (i-1) * S1[i-1][j] ) % Mod ;
		
	for ( i = 1 ; i <= 200 ; i++ )
		for ( j = 1 ; j <= i ; j++ )
			S2[i][j] = ( S2[i-1][j-1] + j * S2[i-1][j] ) % Mod ;
}

int main()
{
	freopen("stirling.in","r",stdin);
	freopen("stirling.out","w",stdout);
	
	preprocesare();
	
	scanf("%d",&T);
	
	for( ; T ; T-- )
	{
		scanf("%d %d %d",&x,&n,&k);
		
		if( x == 1 ) printf("%d\n",S1[n][k]);
		else         printf("%d\n",S2[n][k]);
	}
	
	return 0;
}