#include <fstream>
#define nmax 202
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int s[nmax][nmax];
int s2[nmax][nmax];

int main()
{
    s[1][1]=1;
    for(int i=2;i<=202;i++)
    {
        for(int j=1;j<=i;j++)
        {
            s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j];
        }
    }
    s2[1][1]=1;
    for(int i=2;i<=202;i++)
    {
        for(int j=1;j<=i;j++)
        {
            s2[i][j]=s2[i-1][j-1]+j*s2[i-1][j];
        }
    }
    int t,x,y,s1;
    fin>>t;
    for(int i=1;i<=t;i++)
    {
        fin>>s1>>x>>y;
        if(s1==1)
        {
            fout<<s[x][y];
        }
        if(s1==2)
        {
            fout<<s2[x][y];
        }
        fout<<"\n";
    }
    return 0;
}
