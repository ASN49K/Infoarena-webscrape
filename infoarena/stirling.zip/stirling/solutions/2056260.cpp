#include <iostream>
#include <cstdio>
#include <vector>
#define MOD 98999

using namespace std;
int s1[205][205], s2[205][205];
int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    int t,tip,n,m;
    s1[0][0]=s2[0][0]=1;
    for(int i=1;i<=200;i++)
    {
        s1[i][i]=s2[i][i]=1;
        for(int j=1;j<i;j++)
        {
            s1[i][j]=s1[i-1][j-1]-(i-1)*s1[i-1][j];
            s2[i][j]=s2[i-1][j-1]+j*s2[i-1][j];
        }
    }
    scanf("%d",&t);
    for(int i=0;i<t;i++)
    {
        scanf("\n%d %d %d", &tip, &n,&m);
        if(tip==1)
            cout<<s1[n][m]<<"\n";
        else
            cout<<s2[n][m]<<"\n";
    }
    return 0;
}
