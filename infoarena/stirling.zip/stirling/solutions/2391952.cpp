#include<cstdio>
const int M=20000000;
int t,k,i,j,s[2][201][201],o,e;
char r[M];
inline int A()
{
  	int s=0;
  	for(;r[o]<'0'||r[o]>'9';o++);
  	for(;r[o]>='0'&&r[o]<='9';o++)
  		s=s*10+r[o]-'0';
  	return s;
}
inline void S(int x)
{
    if(x<0)
        x=-x,r[e++]='-';
    int i,d=x>9999?5:x>999?4:x>99?3:x>9?2:1;
    for(i=d-1;i>=0;x/=10,i--)
        r[e+i]=x%10+48;
    r[e+d]=10,e+=d+1;
}
int main()
{
    freopen("stirling.in","r",stdin),freopen("stirling.out","w",stdout),fread(r,1,M,stdin),t=A();
    for(i=1;i<201;i++)
        for(j=1;j<201;j++)
            if(i>j)
                s[0][i][j]=(s[0][i-1][j-1]-(i-1)*s[0][i-1][j])%98999,s[1][i][j]=(s[1][i-1][j-1]+j*s[1][i-1][j])%98999;
            else if(i==j)
                s[0][i][j]=s[1][i][j]=1;
    while(t--)
        i=A(),j=A(),k=A(),S(s[i-1][j][k]);
    fwrite(r,1,e,stdout);
}
