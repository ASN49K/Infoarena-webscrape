#include <fstream>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

const int DIM = 201;
const int MOD = 98999;

int s[DIM][DIM], S[DIM][DIM];

int main() {
    s[1][1] = S[1][1] = 1;
    for (int i = 2; i < DIM; i++) {
        for (int j = 1; j <= i; j++) {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
        }
    }

    int t;
    fin >> t;
    while (t--) {
        int x, n, m;
        fin >> x >> n >> m;
        fout << (x == 1 ? s[n][m] : S[n][m]) << '\n';
    }

    return 0;
}