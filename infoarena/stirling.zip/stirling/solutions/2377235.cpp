#include<fstream>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
const int N=201,MOD=98999;

int t,n,m,speta,s[N][N],S[N][N],k;
int main()
{
    s[1][1]=S[1][1]=1;
    for(int i=2;i<N;i++)
        for(int j=1;j<=i;j++)
    {
        s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
        S[i][j]=(S[i-1][j-1]-j*S[i-1][j])%MOD;
    }
    f>>t;
    while(t--)
    {
        f>>k>>n>>m;
        if(k==1)
            g<<s[n][m]<<"\n";
        else
            g<<S[n][m]<<"\n";
    }
}
