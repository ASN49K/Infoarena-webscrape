#include <stdio.h>

#define NMAX 201
#define MOD 98999

int s[NMAX][NMAX], S[NMAX][NMAX];

inline int read() {
    int n = 0;
    char c = getchar_unlocked();

    while (!('0' <= c && c <= '9')) {
        c = getchar_unlocked();
    }

    while ('0' <= c && c <= '9') {
        n = (n << 3) + (n << 1) + c - '0';
        c = getchar_unlocked();
    }

    return n;
}

inline void print(int n) {
    char snum[65];
    int i = 0, semn = 1;

    if (n < 0) {
        semn = -1;
    }

    do {
        snum[i++] = (semn * n) % 10 + '0';
        n /= 10;
    } while (n);

    --i;

    if (semn == -1) {
        putchar('-');
    }

    while (i >= 0) {
        putchar(snum[i--]);
    }

    putchar('\n');
}

void precalc() {
    s[1][1] = S[1][1] = 1;
    for (int i = 2 ; i < NMAX ; ++i) {
        for (int j = 1 ; j <= i ; ++j) {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD; 
        }
    }
}

int main() {
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);
    int T, x, n, m;
    precalc();
    T = read();
    for (; T ; --T) {
        x = read(), n = read(), m = read();

        if (x == 1) {
            print(s[n][m]);
        } else {
            print(S[n][m]);
        }
    }

    return 0;
}
