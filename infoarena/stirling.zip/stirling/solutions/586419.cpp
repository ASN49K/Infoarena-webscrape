#include <stdio.h>
#define MOD 98999
int t,n,m,s[201][201],S[201][201],i,j,x;
int main(void)
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    s[1][1]=1;
    S[1][1]=1;
    for (i=2;i<=200;i++)
        for (j=1;j<=i;j++)
            {
                s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j];
                s[i][j]%=MOD;
                S[i][j]=S[i-1][j-1]+j*S[i-1][j];
                S[i][j]%=MOD;
            }
    scanf("%d",&t);
    while (t--)
    {
        scanf("%d%d%d",&x,&n,&m);
        if (x==1) printf("%d\n",s[n][m]);
        else printf("%d\n",S[n][m]);
    }
    return 0;
}

