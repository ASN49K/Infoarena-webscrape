#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <vector>
#include <cstring>
#include <cctype>
using namespace std;

#ifdef INFOARENA
#define ProblemName "striling"
#endif

#define MCONCAT(A, B) A B
#ifdef ProblemName
#define InFile MCONCAT(ProblemName, ".in")
#define OuFile MCONCAT(ProblemName, ".out")
#else
#define InFile "fis.in"
#define OuFile "fis.out"
#endif

#define MAXN 210
#define MODNR 98999
typedef long long LL;
LL S[2][MAXN][MAXN];

void precS0() {
	S[0][0][0] = 1;
	for (int i = 1; i < MAXN; i++)
		S[0][0][i] = 0;
	for (int n = 1; n < MAXN - 1; n++) {
		S[0][n][0] = S[0][n][n + 1] = 0;
		for (int m = 1; m <= n; m++)
			S[0][n][m] = (S[0][n - 1][m - 1] - S[0][n - 1][m] * (n - 1)) % MODNR;
		for (int m = n + 1; m < MAXN; m++)
			S[0][n][m] = 0;
	}
}

void precS1() {
	S[1][0][0] = 1;
	for (int i = 1; i < MAXN; i++)
		S[1][0][i] = 0;
	for (int n = 1; n < MAXN - 1; n++) {
		S[1][n][0] = 1;
		S[1][n][n + 1] = 0;
		for (int m = 1; m <= n; m++)
			S[1][n][m] = m * S[1][n - 1][m] + S[1][n - 1][m - 1];
		for (int m = n + 1; m < MAXN; m++)
			S[1][n][m] = 0;
	}
}

int main() {
	assert(freopen(InFile, "r", stdin));
	assert(freopen(OuFile, "w", stdout));
	precS0(); precS1();
	int T;
	scanf("%d", &T);
	while (T--) {
		int a, b, c;
		scanf("%d%d%d", &a, &b, &c);
		printf("%lld\n", S[a - 1][b][c]);
	}
	return 0;
}