#include <fstream>

using namespace std;

ifstream fin ("stirling.in");
ofstream fout ("stirling.out");

const int N = 210, mod = 98999;

int n, i, j, t, s[N][N], S[N][N];

void p_s() {
    s[1][1] = 1;
    for (i = 2; i < N; ++i) {
        for (j = 1; j <= i; ++j) {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % mod;
        }
    }
}

void p_S() {
    S[1][1] = 1;
    for (i = 2; i < N; ++i) {
        for (j = 1; j <= i; ++j) {
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % mod;
        }
    }
}

int main () {
    p_s();
    p_S();
    fin >> n;
    for(; n; --n) {
        fin >> t >> i >> j;
        if (t == 1) {
            fout << s[i][j] << "\n";
        } else {
            fout << S[i][j] << "\n";
        }
    }
    return 0;
}
