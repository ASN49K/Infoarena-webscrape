#include <bits/stdc++.h>

using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int T;
int x,n,m;
int s[205][205],S[205][205];
int main()
{
    fin>>T;
    s[0][0]=1;
    S[0][0]=1;
    for(int i=1;i<=201;++i)
    {
        for(int j=1;j<=i;++j)
        {
         s[i][j]=(s[i-1][j-1]+(i-1)*s[i-1][j])%98999;
         S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
        }
    }
    for(;T;T--)
    {
        fin>>x>>n>>m;
        if(x==1)fout<<s[n][m]<<'\n';
        else fout<<S[n][m]<<'\n';
    }
    return 0;
}
