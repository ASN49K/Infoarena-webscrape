#include <fstream>

using namespace std;
int s[210][210], n,m,t,x,i,j,k,r;
ifstream f("stirling.in");
ofstream g("stirling.out");

using namespace std;

int main()
{
    for (i=1; i<=200; i++)
        s[i][i] = s[i][1] = 1;
    for (i=2; i<=200; i++)
        for (j=2; j<=200; j++)
           s[i][j] = s[i-1][j-1] + j * s[i-1][j];

    f>>t;
    for (k=1; k<=t; k++)
    {
        f>>x>>n>>m;

        if (x==2) g<<s[n][m]<<'\n';

    }
    return 0;
}
