#include <bits/stdc++.h>

#define nmax 205
#define MOD 98999
using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int n,m,t,x,s[nmax][nmax],S[nmax][nmax];

void precalculare_s()
{   s[1][1]=1;
    for(int i=2;i<nmax;i++)
        for(int j=1;j<nmax;j++)
        s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
}

void precalculare_S()
{   S[1][1]=1;
        for(int i=2;i<nmax;i++)
        for(int j=1;j<nmax;j++)
        S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
}

int main()
{
    f>>t;

    precalculare_S();
    precalculare_s();

    for(int i=1;i<=t;i++)
        {f>>x>>n>>m;
        if(x==1)
            g<<s[n][m]<<"\n";
        else
            g<<S[n][m]<<"\n";}

    return 0;
}
