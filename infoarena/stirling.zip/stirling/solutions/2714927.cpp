#include <fstream>

using namespace std;

ifstream cin("stirling.in");
ofstream cout("stirling.out");

const int NMAX = 200;
const int MOD = 98999;

int s1[NMAX + 2][NMAX + 2], s2[NMAX + 2][NMAX + 2];

int main() {

    s1[1][1] = s2[1][1] = 1;

    for(int i = 2; i <= NMAX; i++) {
        for(int j = 1; j <= i; j++) {
            if(j != i) {
                s1[i][j] = (s1[i - 1][j] * (-i + 1) + s1[i - 1][j - 1]) % MOD;
            } else {
                s1[i][i] = 1;
            }

            s2[i][j] = (s2[i - 1][j - 1] + s2[i - 1][j] * j) % MOD;
        }
    }

    int T;
    cin >> T;

    while(T--) {
        int x, n, m;
        cin >> x >> n >> m;

        if(x == 1) {
            ///stirling of the first kind
            cout << s1[n][m] << '\n';
        } else {
            ///stirling of the second kind
            cout << s2[n][m] << '\n';
        }
    }

    return 0;
}
