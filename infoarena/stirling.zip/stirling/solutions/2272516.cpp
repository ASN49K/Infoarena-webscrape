#include <fstream>
# define M  98999

using namespace std;
int s[210][210], n,m,t,x,i,j,k,r;
ifstream f("stirling.in");
ofstream g("stirling.out");

using namespace std;

int main()
{
    for (i=1; i<=201; i++)
        s[i][i] = s[i][1] = 1;
    for (i=2; i<=201; i++)
        for (j=2; j<=i; j++)
           s[i][j] = (s[i-1][j-1] + (j * s[i-1][j]) % M) % M;

    f>>t;
    for (k=1; k<=t; k++)
    {
        f>>x>>n>>m;

        if (x==1) g<<-1<<'\n';
        else g<<s[n][m]<<'\n';

    }
    return 0;
}
