#include <fstream>
#define MOD 98999

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int T,i,j,x,n,m,s[205][205],S[205][205];

int main()
{
    fin >> T; s[1][1] = S[1][1] = 1;
    for (i=2; i<=200; i++)
        for (j=1; j<=i; j++)
        {
            s[i][j] = (s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
            S[i][j] = (S[i-1][j-1]+j*S[i-1][j])%MOD;
        }
    for (;T--;)
    {
        fin >> x >> n >> m;
        if (x == 1)
            fout << s[n][m] << "\n";
        else
            fout << S[n][m] << "\n";
    }
    return 0;
}
