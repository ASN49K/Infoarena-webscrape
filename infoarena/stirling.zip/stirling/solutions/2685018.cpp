#include <bits/stdc++.h>
using namespace std;
#define NMAX 200
#define MOD 98999
int x, m, n, t;
int S[205][205], s[205][205];
void dp_S()
{
    S[1][1] = 1;
    for (int i=2;i<=NMAX;i++){
        for (int j=1;j<=i;j++){
            S[i][j] = (S[i-1][j-1] + j * S[i-1][j]) %MOD;
        }
    }
}
void dp_s()
{
    s[1][1] = 1;
    for (int i=2;i<=NMAX;i++){
        for (int j=1;j<=i;j++){
            s[i][j] = (s[i-1][j-1] - (i-1) * s[i-1][j]) %MOD;
        }
    }
}
int main() {
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    scanf("%d", &t);
    dp_s();
    dp_S();
    for (int i=1;i<=t;i++){
        scanf("%d%d%d", &x, &n,&m);
        if (x == 1){
            printf("%d\n", s[n][m]);
        }else{
            printf("%d\n", S[n][m]);
        }
    }
    return 0;
}
