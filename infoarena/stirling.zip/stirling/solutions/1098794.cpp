#include <fstream>
#include <algorithm>
#include <vector>
#include <cstring>

#define NMAX 205
#define MOD 98999

using namespace std;

ifstream in ( "stirling.in" );
ofstream out ( "stirling.out" );
int n , m , Tests , DP[2][NMAX][NMAX];


void Precalculate_First( void )
{
	int i , j ;
	DP[0][1][1] = 1;
	for( i = 2 ; i <= NMAX ; ++i )
		for ( j = 1 ; j <= i ; ++j )
			DP[0][i][j]	= ( DP[0][i-1][j-1] - ( i-1 ) *DP[0][i-1][j] ) % MOD;
}
void Precalculate_Second ( void )
{
	int i , j ;
	DP[1][1][1] = 1;
	for( i = 2 ; i <= NMAX ; ++i )
		for ( j = 1 ; j <= i ; ++j )
			 DP[1][i][j] = ( DP[1][i-1][j-1] + j*DP[1][i-1][j] )  % MOD;
	
}

int main ( void )
{
	int i , j , sp	;
	Precalculate_First();
	Precalculate_Second();
	in >> Tests;
	for ( ; Tests > 0 ; --Tests )
	{
	   in >> sp >> n >> m ;
		out << DP[sp-1][n][m] << "\n";
	}
	in.close();
	out.close();
	return 0;
}