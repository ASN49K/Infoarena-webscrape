#include <bits/stdc++.h>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

const int MAX_DIM = 200;
const int MOD = 98999;

int s[MAX_DIM + 1][MAX_DIM + 1];
int S[MAX_DIM + 1][MAX_DIM + 1];

int t, x, n, m;

void Stirling_Speta_I() {
    s[0][0] = 1;
    for (int i = 1; i <= MAX_DIM; i++)
        for (int j = 1; j <= i; j++)
            s[i][j] = (s[i - 1][j - 1] - 1LL * (i - 1) * s[i - 1][j]) % MOD;
}

void Stirling_Speta_II() {
    S[0][0] = 1;
    for (int i = 1; i <= MAX_DIM; i++)
        for (int j = 1; j <= i; j++)
            S[i][j] = (S[i - 1][j - 1] + 1LL * j * S[i - 1][j]) % MOD;
}

int main() {
    Stirling_Speta_I();
    Stirling_Speta_II();
    
    f >> t;
    while (t--) {
        f >> x >> n >> m;
        if (x == 1)
            g << s[n][m] << "\n";
        else
        if (x == 2)
            g << S[n][m] << "\n";
    }
    
    f.close();
    g.close();
    return 0;
}