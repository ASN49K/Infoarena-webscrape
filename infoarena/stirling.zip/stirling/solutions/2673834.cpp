#define MAX_SZ 200
#define MOD 98999

#include <fstream>
using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int T, s[MAX_SZ + 1][MAX_SZ + 1], S[MAX_SZ + 1][MAX_SZ + 1];

int main()
{	
	s[1][1]= 1;
	
	for(int i = 2; i < (MAX_SZ + 1); ++i)
	{
		for( int j = 1; j <= i; ++j)
		{
			s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
		}
	}
	
	S[1][1] = 1;
	
	for(int i = 2; i < (MAX_SZ + 1); ++i)
	{
		for(int j = 1; j <= i; ++j)
		{
			S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
		}
	}
	
	fin >> T;
	
	for (int i = 1; i <= T; ++i)
	{
		int c, n, m;
		
		fin >> c >> n >> m;
		
		switch (c)
		{
		case 1:
			{	
				fout << s[n][m] << '\n';
				break;
			}
		case 2:
			{
				fout << S[n][m] << '\n';
				break;
			}
		default:
			break;
		}
	}
	
	fin.close();
	fout.close();
	return 0;
}
