#include<stdio.h>
#define MAXN 200
void precalc();
FILE*fin,*fout;
int s[MAXN+1][MAXN+1];
int S[MAXN+1][MAXN+1];
int main()
{
    fin=fopen("stirling.in","r");
    fout=fopen("stirling.out","w");
    precalc();
    int T;
    fscanf(fin,"%d",&T);
    for(int i=1;i<=T;i++)
    {
        int v,n,m;
        fscanf(fin,"%d%d%d",&v,&n,&m);
        if(v==1)
        {
            fprintf(fout,"%d\n",((n-m)%2==0)?s[n][m]:-s[n][m]);
        }
        if(v==2)
        {
            fprintf(fout,"%d\n",S[n][m]);
        }
    }
    fclose(fin);
    fclose(fout);
    return 0;
}
void precalc()
{
    s[0][0]=1;
    S[0][0]=1;
    for(int i=1;i<=MAXN;i++)
    {
        for(int j=1;j<=MAXN;j++)
        {
            s[i][j]=s[i-1][j-1]+(i-1)*s[i-1][j];
            S[i][j]=j*S[i-1][j]+S[i-1][j-1];
        }
    }
}
