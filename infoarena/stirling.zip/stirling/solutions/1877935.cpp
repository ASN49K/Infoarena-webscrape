#include <fstream>
#include <iostream>
#include <vector>
using namespace std;

#define MOD 98999
#define MAX_N 201

ifstream fin("stirling.in");
ofstream fout("stirling.out");

long long S[MAX_N][MAX_N];
long long s[MAX_N][MAX_N];


long long recursion_S(long long n, long long m)
{
	if (!n || !m)
	{
		S[n][m] = 0;
		return 0;
	}
	if (n<m)
	{
		S[n][m] = 0;
		return 0;
	}
	if (n == 1 && m == 1)
	{
		S[n][m] = 1;
		return 1;
	}
	if (S[n][m])
	{
		return S[n][m];
	}
	else
	{
		S[n][m] = (recursion_S(n - 1, m - 1) + (m*recursion_S(n - 1, m)));

	}
	return S[n][m];
}



long long recursion_s(int n, int m)
{
	if (!n || !m)
	{
		s[n][m] = 0;
		return 0;
	}
	if (n<m)
	{
		s[n][m] = 0;
		return 0;
	}
	if (n == 1 && m == 1)
	{
		s[n][m] = 1;
		return 1;
	}
	if (s[n][m])
	{
		return s[n][m];
	}
	else
	{
		s[n][m] = (recursion_s(n - 1, m - 1) - (n - 1)*recursion_s(n - 1, m));
	}

	return s[n][m];
}

int main()
{

	long long n = 0;
	fin >> n;
	for (unsigned int i = 0; i<n; ++i)
	{
		int x, y;
		int type;
		fin >> type;
		fin >> x >> y;
		if (type == 1)
		{
			fout << recursion_s(x, y) % MOD << '\n';
		}
		else fout << recursion_S(x, y) % MOD << '\n';
	}

	return 0;

}
