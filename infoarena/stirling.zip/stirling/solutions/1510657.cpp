#include <fstream>
#define N 201
using namespace std;
int t,n,m,s[201][201],S[201][201],x=0,modulo=98999;
void speta1(){
    s[1][1]=1;
    for(int i=2;i<=N;i++)
        for(int j=1;j<=i;j++)
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%modulo;

}
void speta2(){
    S[1][1]=1;
    for(int i=2;i<=N;++i)
        for(int j=1;j<=i;j++)
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%modulo;
}
int main()
{
    ifstream f("stirling.in");
    ofstream g("stirling.out");
    f >> t;
    speta1();
    speta2();
    while(t--){
        f >> x >> n >> m;
        if(x==1) g <<s[n][m] << endl;
        else  g << S[n][m] <<endl;
        }
    return 0;
}
