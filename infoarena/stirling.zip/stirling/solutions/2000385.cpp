#include <fstream>
#include <fstream>
using namespace std;
ifstream in("stirling.in");
ofstream out("stirling.out");
int s[201][201], S[201][201];
int main()
{
    int t;
    in >> t;
    for(int i = 1; i <= 200; i++)
    {
        for(int j = 1; j <= 200; ++j)
        {
            if(i > j)
            {
                s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % 98999;
                S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % 98999;
            }
            else if(i == j)
                s[i][j] = S[i][j] = 1;
        }
    }
    for(int i=1;i<=t;++i)
    {
        int a, n, m;
        in >> a >> n >> m;
        if(a==1)
            out << s[n][m] << '\n';
        else
            out << S[n][m] << '\n';
    }
    return 0;
}
