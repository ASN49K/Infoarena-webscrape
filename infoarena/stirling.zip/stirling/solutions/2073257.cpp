#include <fstream>

using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int n,m,i,j,t,s1[250][250],s2[250][250],x;
int main()
{
    f>>t;
    n=200;
    m=200;
    s1[1][1]=1;
    s2[1][1]=1;
    for(i=2;i<=n;i++)
    {
            for(j=1;j<=i;j++)
        {
                s1[i][j]=(s1[i-1][j-1]-(i-1)*s1[i-1][j])%98999;
                s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%98999;
        }
    }
        for(i=1;i<=t;i++)
        {

        f>>x>>n>>m;
            if(x==1)
            g<<s1[n][m]<<"\n";
        else
        g<<s2[n][m]"\n";
        }

    return 0;
}
