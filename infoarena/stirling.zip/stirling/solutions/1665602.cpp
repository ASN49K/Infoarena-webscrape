#include <fstream>

using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int s[230][230],x,n,m,s1,s2,i,j,t,S[230][230];
int main()
{
    s[0][0]=1;
    s[1][1]=1;
    S[0][0]=1;
    S[1][1]=1;
    for(i=2; i<=220; i++)
        for(j=1; j<=i; j++)
        {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999;
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
        }

    fin>>t;
    for(i=1; i<=t; i++)
    {
        fin>>x>>n>>m;
        if(x==1)
            fout<<s[n][m]<<'\n';
        else
            fout<<S[n][m]<<'\n';
    }
    return 0;
}
