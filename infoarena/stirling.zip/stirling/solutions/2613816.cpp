#include <bits/stdc++.h>

using namespace std;

const int MAXN = 205, mod = 98999;

int s[MAXN][MAXN], S[MAXN][MAXN];

int main()
{
    ifstream fin("stirling.in");
    ofstream fout("stirling.out");
    int t, x, n, m;
    fin >> t;
    for(int i = 1; i <= 200; ++i) s[i][i] = S[i][1] = S[i][i] = 1;
    for(int i = 1; i <= 200; ++i){
        for(int j = 1; j <= 201; ++j){
            s[i + 1][j] = (s[i][j - 1] - i * s[i][j]) % mod;
            S[i + 1][j] = ((S[i][j - 1] + j * S[i][j]) % mod + mod) % mod;
        }
    }
    while(t--){
        fin >> x >> n >> m;
        if(x == 1) fout << s[n][m] << "\n";
        else fout << S[n][m] << "\n";
    }
    return 0;
}
