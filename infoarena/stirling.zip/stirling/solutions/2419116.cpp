#include <cstdio>

using namespace std;

const int NMAX = 205;
const int MOD = 98999;

int s[NMAX][NMAX];
int S[NMAX][NMAX];
int m , n , t;

void precalc()
{
    s[1][1] = 1;
    for(int i = 2 ; i < 200 ; i++)
        {
            for(int j = 1 ; j <= i ; j++)
                s[i][j] = (s[i-1][j-1] - (i-1)*s[i-1][j]) % MOD;
        }
}
void precalc1()
{
    S[1][1] = 1;
    for(int i = 2 ; i < 200 ; i++)
        {
            for(int j = 1 ; j <= i ; j++)
                S[i][j] = (S[i-1][j-1] + j*S[i-1][j]) % MOD;
        }
}

int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    precalc();
    precalc1();
    scanf("%d",&t);
    int tip;
    while(t--)
    {
        scanf("%d%d%d",&tip,&n,&m);
        if(tip==1)
            printf("%d\n",s[n][m]);
        else
            printf("%d\n",S[n][m]);
    }
    return 0;
}
