#include <bits/stdc++.h>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int t;
int speta1[201][201],speta2[201][201];
int x,n,m;

int main()
{
    fin >> t;
    speta1[0][0] = 1;
    speta2[0][0] = 1;
    for(int i = 1; i <= 200; ++i)
    {
        for(int j = 1; j <= i; ++j)
        {
            speta1[i][j] = (speta1[i - 1][j - 1] - (i - 1) * speta1[i - 1][j]) % 98999;
            speta2[i][j] =  (speta2[i - 1][j - 1] +j * speta2[i - 1][j]) % 98999;
        }
    }
    for(int i = 1; i <= t; ++i)
    {
        fin >> x >> n >> m;
        if(x == 1)fout << speta1[n][m] << '\n';
        else fout << speta2[n][m] << '\n';
    }
    return 0;
}
