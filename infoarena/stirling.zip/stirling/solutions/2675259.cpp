#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("stirling.in");
ofstream fout ("stirling.out");

const int MOD=98999;
long long s1[201][201], s2[201][201];
int main()
{
    int n, i, j, c, x, y;
    fin>>n;
    s1[1][1]=1;
    s2[1][1]=1;
    for(i=2; i<=200; i++)
    {
        for(j=1; j<=200; j++)
        {
            s1[i][j]=s1[i-1][j-1]-(i-1)*s1[i-1][j];
            s2[i][j]=s2[i-1][j-1] + j*s2[i-1][j];
        }
    }
    //s2[i][j]=s2[i-1][j-1] + j*s[i-1][j];
    for(i=1; i<=n; i++)
    {
        fin>>c>>x>>y;
        if(c==1) fout<<s1[x][y];
        else fout<<s2[x][y];
        fout<<"\n";
    }
}
