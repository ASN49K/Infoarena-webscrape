#include <iostream>
#include <fstream>
#include <cstdlib>
#include <iomanip>
#include <string>
#include <ctime>
#include <vector>
#include <algorithm>
int s[202][202], S[202][202];

using namespace std;


int main(int argc, char const *argv[])
 {
	
     ifstream cin("stirling.in");
     ofstream cout("stirling.out");
     s[1][1] = S[1][1] = 1;
     s[0][0] = S[0][0] = 1;
     for(int i = 1; i <= 201;i++)
        s[i][i] = S[i][i] = 1;

    for(int i = 2; i <= 201;i++)
        for(int j = 1; j <= i;j++){
            s[i][j] = (s[i-1][j-1] - (i - 1) * s[i-1][j]) % 98999;
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j])% 98999;
        }
     
     int t, x, n, m;
     cin >> t;
     for(int i = 1; i <= t; ++i)
    {
        cin >> x >> n>> m;
        if(x == 1)cout<<s[n][m]<<'\n';
           else cout<<S[n][m]<<'\n';
    }
   
     return 0;
 }