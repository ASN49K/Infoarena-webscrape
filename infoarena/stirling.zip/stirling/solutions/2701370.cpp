#include <bits/stdc++.h>
using namespace std;

ifstream in("stirling.in");
ofstream out("stirling.out");

int s[205][205], S[205][205];
int n, k, t, caz;

int main(){
    s[0][0] = S[0][0] = 1;
    for(int i = 1; i <= 200; i++)
        for(int j = 1; j <= 200; j++)
            s[i][j] = s[i - 1][j - 1] + (i - 1) * s[i - 1][j],
            S[i][j] = S[i - 1][j - 1] + j * S[i- 1][j];

    in>>t;
    while(t--){
        in>>caz>>n>>k;
        if(caz == 1)
            out<<s[n][k]<<"\n";
        else
            out<<S[n][k]<<"\n";
    }


}
