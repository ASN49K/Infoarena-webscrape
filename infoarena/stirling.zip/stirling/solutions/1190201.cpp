#include <cstdio>
using namespace std;

const int NMAX = 202, MOD = 98999;

int s[NMAX][NMAX], S[NMAX][NMAX];

inline void preproc () {

    int i, j;
    s[0][0] = S[0][0] = 1;
    for (i = 1; i < NMAX; ++i)
        for (j = 1; j <= i; ++j) {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
        }

}

int main () {

    freopen ("stirling.in", "r", stdin);
    freopen ("stirling.out", "w", stdout);
    int Q, a, b, t;
    preproc ();
    scanf ("%d", &Q);
    while (Q--) {
        scanf ("%d%d%d", &t, &a, &b);
        if (t == 1)
            printf ("%d\n", s[a][b]);
        else
            printf ("%d\n", S[a][b]);
    }

}
