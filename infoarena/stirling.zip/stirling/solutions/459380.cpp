#include <stdio.h>
#include <assert.h>

#define MOD 98999

int s[205][205], S[205][205];

int main()
{
	int T, x, n, m, i, j;
	
	freopen("stirling.in", "r", stdin);
	freopen("stirling.out", "w", stdout);
	
	s[1][1] = 1;
	for (i = 2; i <= 200; ++i)
		for (j = 1; j <= i; ++j)
			s[i][j] = (s[i-1][j-1] - (i-1) * s[i-1][j]) % MOD;
	S[1][1] = 1;
	for (i = 2; i <= 200; ++i)
		for (j = 1; j <= i; ++j)
			S[i][j] = (S[i-1][j-1] + j * S[i-1][j]) % MOD;
	
	scanf("%d", &T);
	assert(1 <= T && T <= 1000);
	for (; T; --T)
	{
		scanf("%d %d %d", &x, &n, &m);
		assert(x == 1 || x == 2);
		assert(1 <= n && n <= 200 && 1 <= m && m <= 200);
		printf("%d\n", x == 1 ? s[n][m] : S[n][m]);
	}
	
	return 0;
}
