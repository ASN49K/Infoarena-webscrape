#include <cstdio>
#define N 201
#define mod 98999
using namespace std;
int s[N][N],S[N][N],i,n,m,speta,j,T;

void spet1()
    {
        s[1][1]=1;
        for (i=2; i<=N ;++i)
            for (j=1;j<=i;++j)
                 {
                     s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%mod;
                 }
    }
void spet2()
    {
        S[1][1]=1;
        for (i=2;i<=N;++i)
             for (j=1;j<=i;++j)
                 {
                     S[i][j]=S[i-1][j-1]+j*S[i-1][j];
                 }
    }
int main()
    {
        freopen("stirling.in","r",stdin);
        freopen("stirling.out","w",stdout);
        scanf("%d",&T);
        spet1();
        spet2();
        for (i=1;i<=T;i++)
        {
            scanf("%d%d%d",&speta,&n,&m);
            if (speta==1)printf("%d\n",s[n][m]);
            if (speta==2)printf("%d\n",s[n][m]);
        }
    }
