#include <bits/stdc++.h>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
#define mod 98999
int s1[202][202],s2[202][202];
int main()
{
    s1[1][1]=1,s2[1][1]=1;
    for(int i=2;i<=201;i++)for(int j=1;j<=i;j++)s1[i][j]=(s1[i-1][j-1]-(i-1)*s1[i-1][j])%mod;
    for(int i=2;i<=201;i++)for(int j=1;j<=i;j++)s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%mod;
    int n;f>>n;
    for(int k=1;k<=n;k++){
        int speta,a,b;
        f>>speta>>a>>b;
        if(speta==1)g<<s1[a][b];
        if(speta==2)g<<s2[a][b];
        g<<"\n";
    }
    return 0;
}
