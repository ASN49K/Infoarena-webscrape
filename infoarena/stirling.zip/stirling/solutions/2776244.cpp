#include<fstream>
using namespace std;
ifstream F("stirling.in");
ofstream G("stirling.out");
int t,k,i,j,s[2][201][201];
int main()
{
    F>>t;
    for(i=1;i<201;++i)
        for(j=1;j<201;++j)
            if(i>j)
                s[0][i][j]=(s[0][i-1][j-1]-(i-1)*s[0][i-1][j])%98999,s[1][i][j]=(s[1][i-1][j-1]+j*s[1][i-1][j])%98999;
            else if(i==j)
                s[0][i][j]=s[1][i][j]=1;
    while(t--)
        F>>i>>j>>k,G<<s[i-1][j][k]<<"\n";
    return 0;
}
