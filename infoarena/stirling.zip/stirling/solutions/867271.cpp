#include<fstream>
using namespace std;

int a[201][201],b[201][201],i,j,n,k,x,y;
const int mod=98999;

int main()
{
	ifstream f("stirling.in");
	ofstream g("stirling.out");
	a[1][1]=1;b[1][1]=1;
	for (i=2;i<=200;i++)
		for (j=1;j<=i;j++)
		{
			a[i][j]=(a[i-1][j-1]-(i-1)*a[i-1][j]) % mod;
			b[i][j]=(b[i-1][j-1]+j*b[i-1][j]) % mod;
		}
	f >> n;
	for (i=1;i<=n;i++)
	{
		f >> k >> x >> y;
		if (k==1)
			g << a[x][y] << "\n";
		else g << b[x][y] << "\n";
	}
	return 0;
}