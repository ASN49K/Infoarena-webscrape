#include <bits/stdc++.h>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

const int NMAX = 200;
const int MMAX = 200;
const int MOD = 98999;

int Q;
int dp[2][NMAX + 1][MMAX + 1];

int main() {
	dp[0][0][0] = 1;
	dp[1][0][1] = 1;

	for(int i = 1; i <= NMAX; i++) {
		for(int j = 1; j <= MMAX; j++) {
			dp[0][i][j] = (dp[0][i - 1][j - 1] - (long long) dp[0][i - 1][j] * (i - 1) % MOD) % MOD;
			dp[1][i][j] = ((long long) dp[1][i - 1][j] * j % MOD + dp[1][i - 1][j - 1]) % MOD;
		}
	}

	fin >> Q;
	
	for(int i = 1; i <= Q; i++) {
		int x, n, m;
		fin >> x >> n >> m;

		x--;

		fout << dp[x][n][m] << '\n';
	}
	return 0;
}