#include <cstdio>

#define MAX_N 205

int s1[MAX_N][MAX_N];
int s2[MAX_N][MAX_N];

int main () {
    freopen ("stirling.in", "r", stdin);
    freopen ("stirling.out", "w", stdout);
    
    s1[1][1] = s2[1][1] = 1;
    for (int i = 2; i < MAX_N; ++i)
        for (int j = 1; j <= i; ++j) {
            s1[i][j] = (s1[i - 1][j - 1] - (i - 1)*s1[i - 1][j]) % 98999;
            s2[i][j] = (s2[i - 1][j - 1] + j * s2[i - 1][j]) % 98999;
        }
        
    int tests;
    scanf ("%d", &tests);
    while (tests--) {
        int x, n, m;
        scanf ("%d %d %d", &x, &n, &m);
        
        printf ("%d\n", (x == 1) ? s1[n][m] : s2[n][m]);  
    }
    
    return 0;
}
