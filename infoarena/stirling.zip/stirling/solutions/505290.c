#include <stdio.h>
#define r 98999

int main () {
	long A[2][210][210]; short T,t,i,j;
	for (i=0; i<201; i++) A[0][i][i]=A[1][i][i]=1;
	for (i=1; i<201; i++)
		for (j=0; j<i; j++) {
			A[0][i][j]=(A[0][i-1][j-1]-(i-1)*A[0][i-1][j])%r;
			A[1][i][j]=(A[1][i-1][j-1]+j*A[1][i-1][j])%r;
		}
	freopen ("stirling.in","r",stdin);
	freopen ("stirling.out","w",stdout);
	scanf ("%hd",&T);
	for (; T; T--) {
		scanf ("%hd%hd%hd",&t,&i,&j);
		printf ("%ld\n",A[t-1][i][j]);
	}
	return 0;
}
