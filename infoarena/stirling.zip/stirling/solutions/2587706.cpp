#include <cstdio>

using namespace std;
const int mod = 98999;
int dp1[205][205];
int dp2[205][205];
int main()
{   freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);
    int t,i,j,tip,n,m;
    scanf("%d", &t);
    dp1[1][1]=dp2[1][1]=1;
    for(i=1; i<=200; i++)
        for(j=1; j<=i; j++){
            if(i!=1 || j!=1){
            dp1[i][j]=(dp1[i-1][j-1]-(i-1)*dp1[i-1][j])%mod;
            dp2[i][j]=(dp2[i-1][j-1]+m*dp2[i-1][j])%mod;
        }
        }
    while(t){
        scanf("%d%d%d", &tip, &n, &m);
        if(tip==1)
            printf("%d\n", dp1[n][m]);
        else
            printf("%d\n", dp2[n][m]);
        t--;
    }
    return 0;
}
