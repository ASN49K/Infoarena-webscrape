/*
    Keep It Simple!
*/
 
#include<stdio.h>

#define Max_N 201
#define MOD 98999

int StrlingFirstKind[201][201], StrlingSecondKind[201][201];
int N,x,n,k;

void PreComputeStrlingFirstKind()
{
	StrlingFirstKind[0][0] = 1;

	for(int i=1; i<=Max_N; i++)
		for(int j=1; j<=i; j++)
			StrlingFirstKind[i][j] = ( StrlingFirstKind[i-1][j-1] - (i-1) * StrlingFirstKind[i-1][j] ) % MOD;
}

void PreComputeStrlingSecondKind()
{
	StrlingSecondKind[0][0] = 1;

	for(int i=1; i<=Max_N; i++)
		for(int j=1; j<=i; j++)
			StrlingSecondKind[i][j] = ( StrlingSecondKind[i-1][j-1] + j*StrlingSecondKind[i-1][j] ) % MOD;
}

int main()
{
	freopen("strling.in","r",stdin);
	freopen("strling.out","w",stdout);

	PreComputeStrlingFirstKind();
	PreComputeStrlingSecondKind();

	scanf("%d",&N);

	for(int i=1; i<=N; i++)
	{
		scanf("%d %d %d",&x,&n,&k);
		if(x == 1)
			printf("%d\n",StrlingFirstKind[n][k]);
		else
			printf("%d\n",StrlingSecondKind[n][k]);
	}
}