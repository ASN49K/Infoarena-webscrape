#include <iostream>
#include <fstream>

using namespace std;

const int MAXN = 2e2, MOD = 98999;

ifstream fin("stiriling.in");
ofstream fout("stiriling.out");

int stiriling1[MAXN + 10][MAXN + 10], stiriling2[MAXN + 10][MAXN + 10];

void preprocess() {
    stiriling1[0][0] = 1;
    for (int i = 1; i <= MAXN; ++i)
        for (int j = 1; j <= i; ++j)
            stiriling1[i][j] = (1ll * stiriling1[i - 1][j - 1] - 1ll * (i - 1) * stiriling1[i - 1][j]) % MOD;
    stiriling2[0][0] = 1;
    for (int i = 1; i <= MAXN; ++i)
        for (int j = 1; j <= i; ++j)
            stiriling2[i][j] = (1ll * stiriling2[i - 1][j - 1] + 1ll * j * stiriling2[i - 1][j]) % MOD;
}

int main() {
    int t, x, y, nr;
    preprocess();
    fin >> t;
    for (int i = 0; i < t; ++i) {
        fin >> nr >> x >> y;
        if (nr == 1)
            fout << stiriling1[x][y] << "\n";
        else
            fout << stiriling2[x][y] << "\n";
    }
    return 0;
}
