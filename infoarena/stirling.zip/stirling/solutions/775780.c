#include <stdio.h>

const int mod = 98999;
int s[201][201], S[201][201];

void compute1stKind() ;
void compute2ndKind() ;

int main()
{
    int t, op, n, m;
    FILE *in = fopen("stirling.in", "r");
    FILE *out = fopen("stirling.out", "w");

    compute1stKind() ;
    compute2ndKind() ;

    for (fscanf (in, "%d", &t); t; --t)
    {
        fscanf (in, "%d %d %d", &op, &n, &m);
        if (op == 1) fprintf (out, "%d\n", s[n][m]);
        else fprintf (out, "%d\n", S[n][m]);
    }

    fclose(in);
    fclose(out);
    return 0;
}

void compute1stKind()
{
    int n, k;
    s[0][0] = 1;
    for (n = 1; n <= 200; ++n)
        for (k = 1; k <= n; ++k)
            s[n][k] = (s[n-1][k-1] - (n-1) * s[n-1][k]) % mod;
}

void compute2ndKind()
{
    int n, k;
    S[0][0] = 1;
    for (n = 1; n <= 200; ++n)
        for (k = 1; k <= n; ++k)
            S[n][k] = (S[n-1][k-1] + k * S[n-1][k]) % mod;
}
