#include <cstdio>

#define Nmax 220
#define MOD 98999

using namespace std;
int SI[Nmax][Nmax];
int SII[Nmax][Nmax];

void dynamic()
{
    SII[0][0] = 1;
    SI[0][0] = 1;
    for(int i = 1; i <= 205; ++i)
        for(int j = 1; j <= i; ++j)
        {
            SII[i][j] = (j * SII[i-1][j] + SII[i-1][j-1])%MOD;
            SI[i][j] = (SI[i-1][j-1] - (i-1)*SI[i-1][j])%MOD;
        }
}

int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);

    dynamic();
    int T;
    scanf("%d",&T);
    int a,b,c;
    for(int i = 1; i <= T; ++i)
    {
        scanf("%d%d%d",&a,&b,&c);
        if(a == 1)
            printf("%d\n",SI[b][c]);
        else
            printf("%d\n",SII[b][c]);
    }

    return 0;
}
