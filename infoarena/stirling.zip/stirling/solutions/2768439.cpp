#include <fstream>

using namespace std;
typedef long long ll;
const int NMAX = 200;

ifstream fin("sterling.in");
ofstream fout("sterling.out");

int dp1[NMAX + 5][NMAX + 5];
int dp2[NMAX + 5][NMAX + 5];

int main()
{
    int t;
    fin >> t;
    int i,j;
    dp1[1][1] = dp2[1][1] = 1;
    for(i = 2; i <= NMAX; i++)
        for(j = 1; j <= NMAX; j++)
            dp1[i][j] = dp1[i - 1][j - 1] - 1LL * (i - 1) * dp1[i - 1][j];
    for(i = 2; i <= NMAX; i++)
        for(j = 1; j <= NMAX; j++)
            dp2[i][j] = dp2[i - 1][j - 1] - 1LL * j * dp2[i - 1][j];
    while(t--)
    {
        int a,b,c;
        fin >> c >> a >> b;
        if(c == 1)
            fout << dp1[a][b] << "\n";
        else
            fout << dp2[a][b] << "\n";
    }
    return 0;
}
