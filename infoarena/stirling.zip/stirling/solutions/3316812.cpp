#include <bits/stdc++.h>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

const int nmax=200;
const int mod=98999;

int s1[nmax+5][nmax+5],s2[nmax+5][nmax+5];

void stirling1()
{
    s1[0][0]=1;
    s1[0][nmax]=s1[nmax][0]=1;

    for (int i=1; i<=nmax; i++ )
       for (int j=1; j<=i; j++ )
            s1[i][j]=(s1[i-1][j-1]-1LL*(i-1)*s1[i-1][j])%mod;
}

void stirling2()
{
    s2[0][0]=1;
    s2[0][nmax]=s2[nmax][0]=1;

    for (int i=1; i<=nmax; i++ )
       for (int j=1; j<=i; j++ )
            s2[i][j]=(s2[i-1][j-1]%mod+1LL*j*s2[i-1][j]%mod)%mod;
}


int main()
{
    stirling1();
    stirling2();

    int t; f >> t;
    while ( t-- )
    {
        int x,n,m; f >> x >> n >> m;
        if ( x==1 ) g << s1[n][m] << '\n';
        else g << s2[n][m]%mod << '\n';
    }
    return 0;
}
