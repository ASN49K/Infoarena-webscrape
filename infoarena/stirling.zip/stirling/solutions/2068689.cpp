#include <bits/stdc++.h>
#define modulo  98999;
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");

int S[205][205],s[205][205],i,j,n,m,k,x,a;

void SUMA();
void suma();

int main()
{
    fin >> m;
    suma();
    SUMA();
    for(i=1;i<=m;i++)
    {
        fin >> x >> n >> k;
        if(x==1)
        {
            fout << s[n][k] <<'\n';
        }
        else
        {
            fout << S[n][k] <<'\n';
        }
    }

    return 0;
}
void suma()
{
    int i,j;
    s[1][1]=1;
    for(i=2;i<=200;i++)
    {
        for(j=1;j<=i;j++)
            s[i][j]=(s[i-1][j-1]-s[i-1][j]*(i-1))%modulo;
    }

}
void SUMA()
{
  int i,j;
  S[1][1]=1;
  for(i=2;i<=200;i++)
  {
      for(j=1;j<=i;j++)
        S[i][j]=(S[i-1][j-1]+S[i-1][j]*j)%modulo;
  }
}
