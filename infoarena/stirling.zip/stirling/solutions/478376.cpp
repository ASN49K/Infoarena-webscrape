#include<fstream>
#include<iostream>
using namespace std;

#define MAXN 202
#define MAXM 202
typedef long long int64;
typedef unsigned long long uint64;

uint64 F[MAXN];
int64 S[MAXN][MAXM];

void CalcFact(uint64 *F, int n)
{
	F[0]=1;
	for(int i=1; i<n; i++)
	{
		F[i]=F[i-1]*i;;
	}
}

int64 StirlingS2(int64 n, int64 m)
{
	if(S[n][m])
		return S[n][m];
	else if(n==m)
	{
		S[n][m]=1;
		return 1;
	}
	else if(m==1)
	{
		S[n][m]=1;
		return 1;
	}
	else if(m==0)
	{
		S[n][m]=1;
		return 0;
	}
	else
	{
		int64 rez1=StirlingS2(n-1,m-1);
		S[n-1][m-1]=rez1;
		int64 rez2=StirlingS2(n-1,m);
		S[n-1][m]=rez2;
		S[n][m]=rez1+m*rez2;
		return rez1+m*rez2;
	}
}

int64 StirlingS1(int64 n, int64 m)
{
	if(S[m][n])
		return S[m][n];
	if(n==m)
	{
		S[m][n]=1;
		return 1;
	}
	else if(m==0)
	{
		S[m][n]=0;
		return 0;
	}
	else if(n>1 && m==1)
	{
		S[m][n]=F[n-1];
		return F[n-1];
	}
	else
	{
		int64 rez1=StirlingS1(n-1,m);
		S[m][n-1]=rez1;
		int64 rez2=StirlingS1(n-1,m-1);
		S[m-1][n-1]=rez2;
		S[m][n]=(n-1)*rez1+rez2;
		return (n-1)*rez1+rez2;
	}
}

int main()
{
	fstream fin("stirling.in",fstream::in);
	fstream fout("stirling.out",fstream::out);
	CalcFact(F,200);
	int T,x,n,m;
	
	for(int i=0; i<=100; i++)
	{
		for(int j=0; j<=i; j++)
		{
			StirlingS1(i,j);
			StirlingS2(i,j);
		}
	}
	fin>>T;
	for(int i=0; i<T; i++)
	{
		fin>>x>>n>>m;
		switch(x)
		{
			case 1:
			{
				fout<<((n-m)%2?-1:1)*S[m][n]<<"\n";
			}; break;
			default:
				fout<<S[n][m]<<"\n";
		}
	}
	/*for(int i=0; i<=9; i++)
	{
		for(int j=0; j<=i; j++)
			cout<<((i-j)%2?-1:1)*S[j][i]<<" ";
		cout<<"\n";
	}
	cout<<endl<<endl;
	for(int i=0; i<=9; i++)
	{
		for(int j=0; j<=i; j++)
			cout<<S[i][j]<<" ";
		cout<<"\n";
	}*/
	
	fin.close();
	fout.close();
	return 0;
}
