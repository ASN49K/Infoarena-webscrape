#include <iostream>
#include <fstream>

using namespace std;

fstream in("stirling.in", ios::in);
fstream out("stirling.out", ios::out);

int sunu(int,int);
int sdoi(int,int);

int main()
{
	int t,x,n,m,i;

	in>>t;
	
	for(i=1;i<=t;i++)
	{
		in>>x>>n>>m;
		if(x == 1)
			out<<sunu(n,m)<<" ";
		else if(x == 2)
			out<<sdoi(n,m)<<" ";
	}

	

    in.close();
    out.close();

	return 0;
}


int sunu(int n,int m)
{
	if(n==0 && m==0)
		return 1;
	else if((n==0 && m>0) || (m==0 && n>0))
		return 0;
	else
		return sunu(n-1,m-1)- (n-1)* sunu(n-1,m);

}


int sdoi(int n,int m)
{
	if(n==0 && m==0)
		return 1;
	else if((n==0 && m>0) || (m==0 && n>0))
		return 0;
	else
		return sdoi(n-1,m-1)+ m* sdoi(n-1,m);
}