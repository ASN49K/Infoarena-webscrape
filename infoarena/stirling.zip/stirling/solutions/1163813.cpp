#include <iostream>
#include <cstdio>

#define mod 98999
#define nmax 205

using namespace std;

int n, m, t, speta, s1[nmax][nmax], s2[nmax][nmax];

void calculareS1()
{
    s1[1][1] = 1;
    for (int i=2; i<nmax; i++)
        for (int j=1; j<=i; j++)
            s1[i][j]= (s1[i-1][j-1] - (i-1)*s1[i-1][j])%mod;
}

void calculareS2()
{
    s2[1][1] = 1;
    for (int i=2; i<nmax; i++)
        for (int j=1; j<=i; j++)
             s2[i][j]= (s2[i-1][j-1] + j*s2[i-1][j])%mod;
}

int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    scanf("%d",&t);

    calculareS1();
    calculareS2();

    while(t--)
    {
        scanf("%d %d %d",&speta, &n, &m);
        if (speta == 1)
            printf("%d\n",s1[n][m]);
        else
            printf("%d\n",s2[n][m]);
    }
    return 0;
}
