#include <iostream>
#include <fstream>

using namespace std;

ifstream in("stirling.in");
ofstream out("stirling.out");

const int MOD = 98999;
const int NMAX = 200 + 10;

int dist1[1+ NMAX][1+ NMAX];
int dist2[1+ NMAX][1+ NMAX];
int t, n, m;

int main()
{
  in >> t;
  dist1[1][1] = 1;
  dist2[1][1] = 1;

  n=200;
  m=200;

  for(int i = 2; i <= n; i++) {
    for(int j = 1; j <= i; j++) {
      dist1[i][j] = (dist1[i - 1][j - 1] - dist1[i - 1][j] * (i - 1)) % MOD;
      dist2[i][j] = (dist2[i - 1][j - 1] + dist2[i - 1][j] * j) % MOD;
    }
  }

  for(int  i = 1; i <= t; i++) {
    int x, n, m;
    in >> x >> n >> m;
    if(x == 1)
      out << dist1[n][m] << '\n';
    else
      out << dist2[n][m] << '\n';
  }

  in.close();
  out.close();
  return 0;
}
