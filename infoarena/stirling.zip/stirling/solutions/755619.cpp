                                                     
#include <fstream>
using namespace std;

long s[205][205];
long S[205][205];

void Compute(void)
{
 long i,j;
 s[0][0] = 1;
 S[0][0] = 1;
 for (i = 1;i <= 200;i += 1)//n
  {
   for (j = 1;j <= i;j += 1)//m
    {
     s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % 98999;
     S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % 98999;
    }
  }
}

int main(void)
{
 long T,n,m,i,a;
 Compute();
 fstream fin("stirling.in",ios::in);
 fstream fout("stirling.out",ios::out);
 fin >> T;
 for (i = 0;i < T;i += 1)
  {
   fin >> a >> n >> m;
   if (a == 1)
     {
      fout << s[n][m] << "\n";
     }
    else
     {
      fout << S[n][m] << "\n";
     }
  }
 fin.close();
 fout.close();
 return 0;
}
