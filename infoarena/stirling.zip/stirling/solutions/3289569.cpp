#include <cstdint>
#include <iostream>
const int64_t NMAX = 2e2, MOD = 98999;

void precomputeStirlingFirstKind(int64_t stirling[NMAX + 1][NMAX + 1], const int64_t &n, const int64_t &MOD) {
    int64_t i, j;
    stirling[0][0] = 1;
    for (i = 1; i <= n; ++ i) {
        for (j = 1; j <= i; ++ j) {
            stirling[i][j] = (stirling[i - 1][j - 1] - ((i - 1) * stirling[i - 1][j]) % MOD) % MOD;
        }
    }
}
void precomputeStirlingSecondKind(int64_t stirling[NMAX + 1][NMAX + 1], const int64_t &n, const int64_t &MOD) {
    int64_t i, j;
    stirling[0][0] = 1;
    for (i = 1; i <= n; ++ i) {
        for (j = 1; j <= i; ++ j) {
            stirling[i][j] = ((j * stirling[i - 1][j]) % MOD + stirling[i - 1][j - 1]) % MOD;
        }
    }
}

int64_t stirlingFirst[NMAX + 1][NMAX + 1], stirlingSecond[NMAX + 1][NMAX + 1];

int64_t stirlingFirstKind(const int64_t &n, const int64_t &k) {
    if (k > n) {
        return 0;
    }
    return stirlingFirst[n][k];
}
int64_t stirlingSecondKind(const int64_t &n, const int64_t &k) {
    if (k > n) {
        return 0;
    }
    return stirlingSecond[n][k];
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    precomputeStirlingFirstKind(stirlingFirst, NMAX, MOD);
    precomputeStirlingSecondKind(stirlingSecond, NMAX, MOD);

    int64_t tests, task, n, k;
    std::cin >> tests;
    for (; tests > 0; -- tests) {
        std::cin >> task >> n >> k;
        if (task == 1) {
            std::cout << stirlingFirstKind(n, k) << '\n';
        }
        else {
            std::cout << stirlingSecondKind(n, k) << '\n';
        }
    }
    return 0;
}
