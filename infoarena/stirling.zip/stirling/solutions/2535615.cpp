#include <fstream>
#define M 98999
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
long long s[205][205],S[205][205];
int x,i,n,m,k,l,j;

int main()
{
    s[1][1]=S[1][1]=1;
    for (i=2;i<=200;i++)
        for (j=1;j<=i;j++)
        {
            s[i][j]=(s[i-1][j-1]-s[i-1][j]*(i-1)%M)%M;
            S[i][j]=(S[i-1][j-1]+j*s[i-1][j]%M)%M;
        }
    f>>k;
    for (l=1;l<=k;l++)
    {
        f>>x>>n>>m;
        if (x==1) g<<s[n][m]<<'\n';
        else g<<S[n][m]<<'\n';
    }
    return 0;
}
