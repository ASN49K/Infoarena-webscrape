#include <stdio.h>
#define mod 98999
using namespace std;
int i,n,tip,x,y,s1[210][210],s2[210][210];
void build()
{
    s1[1][1]=s2[1][1]=1; int i,j;
    for (i=2;i<=200;i++)
        for (j=1;j<=i;j++)
        s1[i][j]=(s1[i-1][j-1]-(i-1)*s1[i-1][j])%mod,
        s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%mod;

}
int main() {
freopen("stirling.in","r",stdin);
freopen("stirling.out","w",stdout);
scanf("%d",&n);
build();
for (i=1;i<=n;i++) {
    scanf("%d %d %d",&tip,&x,&y);
    if (tip==1) printf("%d\n",s1[x][y]); else
        printf("%d\n",s2[x][y]);
}
return 0;
}
