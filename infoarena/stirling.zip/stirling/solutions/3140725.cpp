#include<fstream>
using namespace std;
ifstream F("stirling.in");
ofstream G("stirling.out");
int t,a[201][201],b[201][201],i,j,k;
int main()
{
    for(i=0;i<201;++i)
        for(a[i][i]=1,j=0;j<i;a[i][j]=(a[i-1][j-1]-(i-1)*a[i-1][j])%98999,b[i][j]=(b[i-1][j-1]+j*b[i-1][j])%98999:0,++j);
    for(F>>t;t--;F>>k>>i>>j,G<<(k<2?a[i][j]:b[i][j])<<'\n');
    return 0;
}
