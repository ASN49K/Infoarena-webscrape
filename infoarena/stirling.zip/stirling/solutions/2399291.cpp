#include <bits/stdc++.h>

using namespace std;
int s[3][205][205];
int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    int n=200,m=200,t,tip;
    scanf("%d",&t);
    s[1][1][1]=1;
    s[2][1][1]=1;
    for(int i=2;i<=n;++i)
    {
        for(int j=1;j<=m;++j)
        {
            s[1][i][j]=s[1][i-1][j-1]-(i-1)*s[1][i-1][j];
            s[2][i][j]=s[2][i-1][j-1]+j*s[2][i-1][j];
        }
    }
    for(int i=1;i<=t;++i)
    {
        scanf("%d %d %d",&tip,&n,&m);
        printf("%d\n",s[tip][n][m]);
    }
    return 0;
}
