#include <fstream>

int s[201][201],S[201][201],n,m,r,t;

void pres(){
	for (int i = 1; i < 201;++i)
		for (int j = 1; j <= i; ++j)
		if (i>j){
			s[i][j] = (s[i - 1][j - 1] - (i - 1)*s[i - 1][j]) % 98999;
			S[i][j] = (S[i - 1][j - 1] + j*S[i - 1][j]) % 98999;
		}
		else s[i][j] = S[i][j] = 1;
}



int main(){
	std::ifstream f("stirling.in");
	std::ofstream g("stirling.out");
	pres();
	f >> t;
	for (int i = 0; i < t; ++i){
		f >> r >> n >> m;
		g << (r == 1 ? s[n][m] : S[n][m])<<"\n";
	}
}