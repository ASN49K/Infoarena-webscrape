#include<cstdio>
int t,i,j,k,s[201][201],S[210][201];
void read(),solve();
int main()
{
    read();
    solve();
    return 0;
}
void read()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    scanf("%d",&t);
}
void solve()
{
    s[0][0]=S[0][0]=1;
    for(i=1;i<=200;i++)
        for(j=1;j<=200;j++)
        {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999;
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
        }
    for(;t;t--)
    {
        scanf("%d%d%d",&i,&j,&k);
        k-1?printf("%d\n",S[i][j]):printf("%d\n",s[i][j]);
    }
}

