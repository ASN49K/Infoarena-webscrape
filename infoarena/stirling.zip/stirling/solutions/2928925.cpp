#include <fstream>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

const int MAX = 200, MOD = 98999;

int s[MAX + 1][MAX + 1],
    S[MAX + 1][MAX + 1];

void construire()
{
    s[1][1] = S[1][1] = 1;
    for(int i = 2 ; i <= MAX ; i++)
        for(int j = 1 ; j <= i ; j++)
        {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
        }
}

int main()
{
    int x, c, n, m;
    construire();
    fin >> x;
    while(x--)
    {
        fin >> c >> n >> m;
        if(c == 1) fout << s[n][m];
        else fout << S[n][m];
        fout << '\n';
    }
    fin.close();
    fout.close();
    return 0;
}
