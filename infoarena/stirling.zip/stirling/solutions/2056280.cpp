#include <iostream>
#include <cstdio>

using namespace std;


int a[200][200],n,m,t,a2[200][200];


void Speta1()
{
    cout<<"LUL"<<endl;
}


void Generare1()
{
    a[0][0]=1;
    for (int i=1;i<200;i++)
    {
        for (int j=1;j<=i;j++)
            a[i][j]=a[i-1][j-1]-(i-1)*a[i-1][j];
    }
}


void Generare2()
{
    a2[0][0]=1;
    for (int i=1;i<200;i++)
    {
        for (int j=1;j<=i;j++)
            a2[i][j]=a2[i-1][j-1]+j*a2[i-1][j];
    }
}


int main()
{
    freopen ("stirling.in","r",stdin);
    freopen ("stirling.out","w",stdout);
    cin>>t;
    Generare1();
    Generare2();
    for (int i=0;i<t;i++)
    {
        int x;
        cin>>x>>n>>m;
        if (x==1)
            cout<<a[n][m]<<endl;
        else
            cout<<a2[n][m]<<endl;
    }
    return 0;
}
