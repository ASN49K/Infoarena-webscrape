#include <fstream>
using namespace std;
#define MOD 98999
int str_1[205][205], str_2[205][205];
int main(){
	int t, i, j, tip, x, y;
	ifstream fin( "stirling.in" );
	ofstream fout( "stirling.out" );
	fin >> t;
	str_1[0][0] = str_2[0][0] = 1;
	for( i = 1; i < 205; i++ ){
		for( j = 1; j <= min( i, 204 ); j++ ){
			str_1[i][j] = ( str_1[i - 1][j - 1] - 1ll * str_1[i - 1][j] * ( i - 1 ) ) % MOD;
			str_2[i][j] = ( str_2[i - 1][j - 1] + 1ll * str_2[i - 1][j] * ( j - 1 ) ) % MOD;
		}
	}
	for( i = 0; i < t; i++ ){
		fin >> tip >> x >> y;
		if( tip == 1 ){
			fout << str_1[x][y] << '\n';
		}
		else{
			fout << str_2[x][y] << '\n';
		}
	}
	return 0;
}