#include <fstream>

const int N = 205;
const int mod = 98999;

int s[N][N], S[N][N];

int sum(int a, int b) { return (a+b)%mod; }
int p(int a, int b) { return (1ll*a*b)%mod; }

int main() {
	std::ifstream fin("stirling.in");
	std::ofstream fout("stirling.out");
	s[1][1] = S[1][1] = 1;
	for(int i=2;i<N;i++)
		for(int j=1;j<N;j++) {
			s[i][j] = sum(s[i-1][j-1], p(-(i-1), s[i-1][j]));
			S[i][j] = sum(S[i-1][j-1], p(j, S[i-1][j]));
		}
	int t, a, b, c;
	fin>>t;
	while(t--) {
		fin>>a>>b>>c;
		fout<<((a==1)?s[b][c]:S[b][c])<<"\n";
	}
}