#include <fstream>

using namespace std;
ifstream in("stirling.in");
ofstream out("stirling.out");
int s1[201][201],s2[201][201];
int mod=98999;
struct cook
{
    int cerinta,first,second;
};
cook v[1001];
void stirling1(int n, int k)
{
    int i,j;
    s1[1][1]=1;

    for(i=1; i<=n; i++)
        for(j=1; j<=k; j++)
        {
            if(!(i==1&&j==1))
            s1[i][j]=(s1[i-1][j-1]-(i-1)*s1[i-1][j])%mod;

        }

}
void stirling2(int n, int k)
{
    int i,j;
    s2[0][0]=1;
    s2[0][1]=0;
    s2[1][0]=1;
    for(i=1; i<=n; i++)
        for(j=1; j<=k; j++)
            s2[i][j]=(k*s2[i-1][j]+s2[i][j-1])%mod;
}
int main()
{
    int n,m,t,maxn=-1,maxk=-1,i;
    in>>t;
    for(i=1; i<=t; i++)
    {
        in>>v[i].cerinta>>v[i].first>>v[i].second;
        if(maxn<v[i].first)
            maxn=v[i].first;
        if(maxk<v[i].second)
            maxk=v[i].second;
    }
    stirling1(maxn,maxk);
    stirling2(maxn,maxk);
    for(i=1; i<=t; i++)
    {
        if(v[i].cerinta==1)
            out<<s1[v[i].first][v[i].second]<<'\n';
        if(v[i].cerinta==2)
            out<<s2[v[i].first][v[i].second]<<'\n';
    }
    return 0;
}
