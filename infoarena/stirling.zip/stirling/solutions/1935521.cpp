#include <cstdio>
#include <algorithm>

#define MOD 98999LL

using namespace std;

long long spe1[256][256], spe2[256][256];

void modulo (long long &a)
{
    a %= MOD;
}

int main ()
{
    freopen ("stirling.in", "r", stdin);
    freopen ("stirling.out", "w", stdout);

    spe1[0][0] = 1LL;
    spe2[0][0] = 1LL;

    for (int i = 1; i <= 200; ++i)
        for (int j = 0; j <= i; ++j)
        {
            if (j == 0)
            {
                spe1[i][j] = spe1[i - 1][j] * (1 - i);
                modulo (spe1[i][j]);

                continue;
            }

            spe1[i][j] = spe1[i - 1][j] * (1 - i) + spe1[i - 1][j - 1];
            spe2[i][j] = spe2[i - 1][j] * j + spe2[i - 1][j - 1];

            modulo (spe1[i][j]);
            modulo (spe2[i][j]);
        }

    int k;
    scanf ("%d", &k);

    for (; k; --k)
    {
        int op, n, m;
        scanf ("%d %d %d", &op, &n, &m);

        if (op == 1) printf ("%lld\n", spe1[n][m]);
        else printf ("%lld\n", spe2[n][m]);
    }

    return 0;
}
