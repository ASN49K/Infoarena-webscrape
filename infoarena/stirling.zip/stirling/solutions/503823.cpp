#include <cstdio>

const int NMAX=202;
const int MOD=98999;

int s[NMAX][NMAX],S[NMAX][NMAX];

int main()
{
	int i,j;
	s[1][0]=0;s[1][1]=1;S[1][1]=1;
	for (i=2;i<NMAX;++i)
	{
		s[i][0]=0;
		for (j=1;j<=i;++j)
		{
			s[i][j]=(s[i-1][j-1] - (i-1)*s[i-1][j])%MOD;
			S[i][j]=(j*S[i-1][j] + S[i-1][j-1])%MOD;
		}
	}
	freopen("stirling.in","r",stdin);
	freopen("stirling.out","w",stdout);
	int T;
	scanf("%d",&T);
	while (T--)
	{
		int k;
		scanf("%d %d %d",&k,&i,&j);
		printf("%d\n",k==1?s[i][j]:S[i][j]);
	}

	return 0;
}
