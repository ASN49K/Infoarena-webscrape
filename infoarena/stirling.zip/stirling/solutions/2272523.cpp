#include <fstream>
# define M 98999

using namespace std;
int s[201][201],s1[201][201], n,m,t,x,i,j,k,r;
ifstream f("stirling.in");
ofstream g("stirling.out");

using namespace std;

int main()
{
   /* for (i=1; i<=200; i++)
        s[i][i] = s[i][1] = 1; */
    s[1][1]=s1[1][1]=1;
    for (i=2; i<=200; i++)
        for (j=1; j<=i; j++)
           { s[i][j] = (s[i-1][j-1] + (j * s[i-1][j]) % M) % M;  //stirling speta II
             s1[i][j] = (s1[i-1][j-1] - s1[i-1][j]*(i-1)) % M; //stirling speta I
           }


    f>>t;
    while (t--)
    {
        f>>x>>n>>m;

        if (x==1) g<<s1[n][m]<<'\n';
        else g<<s[n][m]<<'\n';

    }
    return 0;
}
