#include <bits/stdc++.h>
#define mod 98999
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int q,i,n,t,a,b;
int task1()
{
    int i,j;
    vector <vector<int>>s(a+1,vector<int> (b+1));
    s[0][0]=1;
    for(i=1;i<=a;i++)
        for(j=1;j<=min(b,i);j++)
        s[i][j]=1LL*(s[i-1][j-1]+(i-1)*s[i-1][j])%mod;
    return s[a][b];
}
int task2()
{
    int i,j;
    vector <vector<int>>s(a+1,vector<int>(b+1));
    s[0][0]=1;
    for(i=1;i<=a;i++)
        for(j=1;j<=min(b,i);j++)
        s[i][j]=1LL*(s[i-1][j-1]+j*s[i][j-1])%mod;
    return s[a][b];
}
void query()
{
    fin>>q;
    for(i=1;i<=q;i++)
    {
        fin>>t>>a>>b;
        if(t==1)fout<<task1()<<'\n';
        else fout<<task2()<<'\n';
    }
}
int main()
{
    query();
    return 0;
}
