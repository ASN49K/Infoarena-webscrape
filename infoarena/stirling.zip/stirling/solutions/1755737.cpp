#include <fstream>

using namespace std;
const int N=201, MOD=98999;
int sp, n, m, tests;
int s[N][N], S[N][N];

void precalculare_s()
{
    s[1][1]=1;
    for(int i=2; i<N; i++)
        for(int j=1; j<=i; j++)
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
}

void precalculare_S()
{
    S[1][1]=1;
    for(int i=2; i<N; i++)
        for(int j=1; j<=i; j++)
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
}

int main()
{
    ifstream in("stirling.in");
    ofstream out("stirling.out");
    precalculare_s();
    precalculare_S();
    in>>tests;
    while(tests--)
    {
        in>>sp>>n>>m;
        if(sp==1)
            out<<s[n][m]<<'\n';
        else
            out<<S[n][m]<<'\n';
    }
    return 0;
}
