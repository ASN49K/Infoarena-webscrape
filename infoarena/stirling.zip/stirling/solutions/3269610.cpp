#include <bits/stdc++.h>
#define mod 98999
#define lim 210
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int q,i,n,t,a,b;
int s[lim][lim],S[lim][lim];
int sterling()
{
    int i,j;
    s[1][1]=1;
    for(i=2;i<=lim;i++)
        for(j=1;j<=i;j++)
        s[i][j]=1LL*(s[i-1][j-1]-(i-1)*s[i-1][j])%mod;
}
int Sterling()
{
    int i,j;
    S[1][1]=1;
    for(i=2;i<=lim;i++)
        for(j=1;j<=i;j++)
        S[i][j]=1LL*(S[i-1][j-1]+j*S[i][j-1])%mod;
}
void query()
{
    fin>>q;
    for(i=1;i<=q;i++)
    {
        fin>>t>>a>>b;
        if(t==1)fout<<s[a][b]<<'\n';
        else fout<<S[a][b]<<'\n';
    }
}
int main()
{
    sterling();
    Sterling();
    query();
    return 0;
}
