#include <fstream>
#define MOD 98999
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int n,i,j,k,a,b,s1[210][210],s2[210][210];
int main()
{
    f>>n;
    s1[1][1]=1;
    s2[1][1]=1;
    for(i=2;i<=200;i++)
    {
        for(j=1;j<=i;j++)
        {
            s1[i][j]=(s1[i-1][j-1]+s1[i-1][j]*j)%MOD;
            s2[i][j]=(s2[i-1][j-1]-(i-1)*s2[i-1][j])%MOD;
        }
    }
    for(i=1;i<=n;i++)
    {
        f>>k>>a>>b;
        if(k==1)g<<s2[a][b]<<'\n';
        else g<<s1[a][b]<<'\n';
    }
    return 0;
}
