#include<stdio.h>
#define MOD 98999
FILE *in,*out;
int s[201][201],S[201][201],speta,n,m,T;
										//N max 201
void Precalc_s()		//speta 1
{
	s[1][1]=1;
	
	for(int i=2;i<201;i++)
		for(int j=1;j<=i;j++)
			s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;		//s(n,m)=s(n-1,m-1)-(n-1)*s(n-1,m);
	
}

void Precalc_S()		//speta 2
{
	S[1][1]=1;
	
	for(int i=2;i<201;i++)
		for(int j=1;j<=i;j++)
			S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;						//S(n,k)=S(n-1,k-1)+k*S(n-1,k);
	
}
int main()
{
	in=fopen("stirling.in","rt");
	out=fopen("stirling.out","wt");
	Precalc_s();
	Precalc_S();
	fscanf(in,"%d",&T);
	for(int i=1;i<=T;i++)
	{
		fscanf(in,"%d %d %d",&speta,&n,&m);
		if(speta==1)
			fprintf(out,"%d\n",s[n][m]);
		else
			fprintf(out,"%d\n",S[n][m]);
	}
	
	
	
	return 0;
}