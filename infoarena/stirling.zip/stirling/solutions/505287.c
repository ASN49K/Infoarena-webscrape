#include <stdio.h>
#define r 98999

int main () {
	FILE *in,*out;
	long A[2][210][210]; short T,n,m,t,i,j,k;
	for (i=0; i<201; i++) {
		A[0][i][i]=1;
		A[1][i][i]=1;
	}
	for (i=1; i<201; i++)
		for (j=0; j<i; j++) {
			A[0][i][j]=(A[0][i-1][j-1]-(i-1)*A[0][i-1][j])%r;
			A[1][i][j]=(A[1][i-1][j-1]+j*A[1][i-1][j])%r;
		}
	in=fopen ("stirling.in","r"); out=fopen ("stirling.out","w");
	fscanf (in,"%hd",&T);
	for (i=0; i<T; i++) {
		fscanf (in,"%hd%hd%hd",&t,&n,&m);
		fprintf (out,"%ld\n",A[t-1][n][m]);
	}
	fclose (in); fclose (out);
	return 0;
}
