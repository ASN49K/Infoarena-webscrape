#include <fstream>
#define N 200
#define MOD 98999
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int T,x,m,n,s[201][201],S[201][201];

void I()
{
    s[1][1]=1;
    for(int i=2;i<=N;i++)
        for(int j=1;j<=i;j++)
            s[i][j]=(s[i-1][j-1]%MOD-s[i-1][j]*(i-1)%MOD)%MOD;
}
void II()
{
    S[1][1]=1;
    for(int i=2;i<=N;i++)
        for(int j=1;j<=i;j++)
            S[i][j]=(S[i-1][j-1]%MOD+S[i+1][j]*j%MOD)%MOD;
}
int main()
{
    fin>>T;
    I();
    II();
    for(int i=1;i<=T;i++)
    {
        fin>>x>>n>>m;
        if(x==1) fout<<s[n][m]<<'\n';
        else fout<<S[n][m]<<'\n';
    }
    return 0;
}
