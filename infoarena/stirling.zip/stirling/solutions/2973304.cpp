#include <fstream>
using namespace std;
ifstream cin("stirling.in");
ofstream cout("stirling.out");
const int NMAX=200,MOD=98999;
int s[NMAX+5][NMAX+5],S[NMAX+5][NMAX+5];

int main()
{
    int t,x,m,n;
    cin>>t;
    s[1][1]=1;
	for(int i=2;i<NMAX;i++)
		for(int j=1;j<=i;j++)
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
    S[1][1]=1;
	for( int i=2;i<NMAX;i++)
		for( int j=1;j<=i;j++)
			S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
    for(int i=1;i<=t;i++)
    {
        cin>>x>>n>>m;
        if(x==1)
            cout<<s[n][m]<<'\n';
        else cout<<S[n][m]<<'\n';
    }
    return 0;
}
