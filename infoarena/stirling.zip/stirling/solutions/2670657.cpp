#include <fstream>

using namespace std;

ifstream cin("stirling.in");
ofstream cout("stirling.out");

const int NMAX = 200;
const int MOD = 98999;

int s1[NMAX + 5][NMAX + 5], s2[NMAX + 5][NMAX + 5];

int main()
{
    s1[0][0] = 1;
    for(int i = 1; i <= NMAX; i++)
        for(int j = 0; j <= i; j++)
        {
            if(j == 0)
                s1[i][j] = ((-i) * s1[i - 1][j]) % MOD;
            else
                s1[i][j] = (s1[i - 1][j - 1] + (-i) * s1[i - 1][j]) % MOD;

            if(j > 0)
            {
                if(j == 1 || j == i)
                    s2[i][j] = 1;
                else
                    s2[i][j] = (j * s2[i - 1][j] + s2[i - 1][j - 1]) % MOD;
            }
        }

    int T;
    cin >> T;

    while(T--)
    {
        int t, a, b;
        cin >> t >> a >> b;

        if(t == 1) cout << s1[a - 1][b - 1] << '\n';
        else cout << s2[a][b] << '\n';
    }

    return 0;
}
