#include <bits/stdc++.h>
using namespace std;

ifstream fin ("stirling.in");
ofstream fout ("stirling.out");

const int mod = 98999;

int s[205][205];

int main ()
{
    s[1][1] = 1;
    for (int i = 2; i <= 200; i++)
        for (int j = 1; j <= i; j++)
            s[i][j] = (s[i - 1][j - 1] + j * s[i - 1][j]) % mod;
    int t;
    fin >> t;
    for (int i = 1; i <= t; i++)
    {
        int x, n, k;
        fin >> x >> n >> k;
        if (x == 2)
            fout << s[n][k] << '\n';
    }
    return 0;
}