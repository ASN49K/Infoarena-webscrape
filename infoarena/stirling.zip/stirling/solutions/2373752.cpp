#include <iostream>
#include <fstream>
#define MOD 98999
using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int s[205][205],S[205][205  ];

void generares()
{
    s[0][0]=1;
    s[1][0]=0, s[1][1]=1;
    for(int i=2; i<200; i++)
    {
        s[i][0]=0;
        s[i][i]=1;
        for(int j=1; j<i; j++)
        {
            s[i][j]=s[i-1][j-1]%MOD - ((i-1)*s[i-1][j]%MOD)%MOD;
            s[i][j]%=MOD;
        }
    }
}
void generareS()
{
    S[0][0]=1;
    S[1][0]=0, S[1][1]=1;
    for(int i=2; i<200; i++)
    {
        S[i][0]=0;
        S[i][i]=1;
        for(int j=1; j<i; j++)
        {
            S[i][j]=((S[i-1][j-1]%MOD)+(j*S[i-1][j])%MOD)%MOD;
        }
    }
}

int main()
{
    int t;
    f>>t;
    generareS();
    generares();
    for(int i=0; i<t; i++)
    {
        int x,n,m;
        f>>x>>n>>m;
        if(x==1)
        {
            //g<<s[n][m]<<endl;
        }
        else
            g<<S[n][m]<<endl         ;
    }
    return 0;
}
