

#include <iostream>
#include <fstream>


const int NMMAX = 203;
const int MODULO = 98999;

long long int Stir1[NMMAX][NMMAX];
long long int Stir2[NMMAX][NMMAX];


void precalculare_stirling_s1() {

	Stir1[0][0] = 1;

	for (int i = 1; i < NMMAX; ++i) {
		for (int j = 1; j < NMMAX; ++j) {
			Stir1[i][j] = Stir1[i - 1][j - 1] - (i - 1) * Stir1[i - 1][j];
		}
	}
}

void precalculare_stirling_s2() {
	
	Stir2[0][0] = 1;

	for (int i = 1; i < NMMAX; ++i) {
		for (int j = 1; j < NMMAX; ++j) {
			Stir2[i][j] = Stir2[i - 1][j - 1] + j * Stir2[i - 1][j];
		}
	}
}


int main() {


	precalculare_stirling_s1();
	precalculare_stirling_s2();

	std::ifstream in("stirling.in");
	std::ofstream out("stirling.out");


	int T;
	in >> T;

	while (--T >= 0) {
		int speta, n, m;
		in >> speta >> n >> m;

		if (speta == 1) {
			out << Stir1[n][m] << '\n';
		}
		else {
			out << Stir2[n][m] << '\n';
		}

	}

	return 0;
}