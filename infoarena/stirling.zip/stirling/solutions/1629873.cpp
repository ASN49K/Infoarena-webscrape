#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int Mn = 203;
const int mod = 98999;

int t, n, m;
int s[2][Mn][Mn];

int main()
{
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    scanf("%d", &t);
    s[0][1][1] = s[1][1][1] = 1;
    for (int i = 2; i < Mn; i++)
        for (int j = 1; j <= i; j++)
            s[0][i][j] = (s[0][i - 1][j - 1] - (i - 1) * s[0][i - 1][j]) % mod;

    for (int i = 2; i < Mn; i++)
        for (int j = 1; j <= i; j++)
            s[1][i][j] = (s[1][i - 1][j - 1] + j * s[1][i - 1][j]) % mod;

    for (; t; t--)
    {
        int type;
        scanf("%d %d %d", &type, &n, &m);
        type--;
        printf("%d\n", s[type][n][m]);
    }

  return 0;
}


