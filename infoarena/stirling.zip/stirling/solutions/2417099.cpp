#include <bits/stdc++.h>
using namespace std ;
ifstream in ("stirling.in") ;
ofstream out ("stirling.out") ;
int s [ 205 ][ 205 ] , S [ 205 ][ 205 ] , q ;
int main() {
    int i , j , tip , x , y ;
    in >> q ;
    s [ 1 ][ 1 ] = 1 ;
    S [ 1 ][ 1 ] = 1 ;
    for ( i = 2 ; i <= 200 ; ++ i )
        for ( j = 1 ; j <= i ; ++ j ) {
            s [ i ][ j ] = s [ i - 1 ][ j - 1 ] - ( i - 1 ) * s [ i - 1 ][ j ] ;
            S [ i ][ j ] = S [ i - 1 ][ j - 1 ] + j * S [ i - 1 ][ j ] ;
        }
    while ( q -- )  {
        in >> tip >> x >> y ;
        if ( tip == 1 ) out << s [ x ][ y ] << '\n' ;
        else            out << S [ x ][ y ] << '\n' ;
    }
}
