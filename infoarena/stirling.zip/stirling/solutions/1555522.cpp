#include<fstream>
#define mod 98999
using namespace std;
int T, n, m, i, j, speta, s[202][202], S[202][202];
void precalc_s()
{
    s[1][1]=1;
    for(i=2; i<=200; i++)
    {
        for(j=1; j<=i; j++)
        {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%mod;
        }
    }
}
void precalc_S()
{
    S[1][1]=1;
    for(i=2; i<=200; i++)
    {
        for(j=1; j<=i; j++)
        {
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%mod;
        }
    }
}
ifstream in("stirling.in");
ofstream out("stirling.out");
int main()
{
    precalc_s();
    precalc_S();
    in>>T;
    for(;T--;)
    {
        in>>speta>>n>>m;
        if(speta==1)
            out<<s[n][m]<<"\n";
        else
            out<<S[n][m]<<"\n";
    }
    return 0;
}
