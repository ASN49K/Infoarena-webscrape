#include <bits/stdc++.h>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
const int NMAX = 200 + 1, MOD = 98999;
int stir1[NMAX][NMAX],stir2[NMAX][NMAX];
void precalculare_stir1()
{
	stir1[1][1]= 1;
	for( int i=2 ; i<= NMAX-1 ; ++i )
		for( int j=1 ; j<=i ; ++j )
			stir1[i][j]= ( stir1[i-1][j-1] - (i-1)*stir1[i-1][j] )%MOD ;
}

void precalculare_stir2()
{
	stir2[1][1]= 1;
	for( int i=2 ; i<=NMAX-1 ; ++i )
		for( int j=1 ; j<=i ; ++j )
			stir2[i][j]= ( stir2[i-1][j-1] + j*stir2[i-1][j] )%MOD;
}
int main()
{
    precalculare_stir1();
    precalculare_stir2();
    int t,n,m,tip;
    f>>t;
    for(int i=1;i<=t;i++)
    {
        f>>tip>>n>>m;
        if(tip-2)
            g<<stir1[n][m]<<'\n';
        else
            g<<stir2[n][m]<<'\n';
    }
    return 0;
}
