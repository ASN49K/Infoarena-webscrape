#include <iostream>
#include <fstream>
#define Mod 98999
#define NN 203

using namespace std;

ifstream in("stirling.in");
ofstream out("stirling.out");

int ss[NN][NN], s[NN][NN], i, j, n, a, m, x;
void rezolva()
{
	ss[1][1] = 1;
	for (int i = 2; i<NN; i++)
	{
		for (int j = 1; j <= i; j++)
			ss[i][j] = (ss[i - 1][j - 1] - (i - 1)*ss[i - 1][j]) % Mod;
	}
}
void rezolva2()
{
	s[1][1] = 1;
	for (int i = 2; i<NN; i++)
	{
		for (int j = 1; j <= i; j++)
		{
			s[i][j] = (s[i - 1][j - 1] + (s[i - 1][j] * j)) % Mod;
		}
	}
}

int main()
{
	in >> a;
	rezolva();
	rezolva2();
	for (i = 1; i <= a; i++)
	{
		in >> x >> n >> m;
		if (x == 1)
		{
			out << ss[n][m] << '\n';
		}
		if (x == 2)
		{
			out << s[n][m] << '\n';
		}
	}
	return 0;
}
