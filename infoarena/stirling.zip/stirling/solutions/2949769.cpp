#include<fstream>
using namespace std;
ifstream F("stirling.in");
ofstream G("stirling.out");
int a[201][201],b[201][201],i,j,m;
int main()
{
	for(a[0][0]=b[0][0]=i=1;i<201;++i)
        for(j=1;j<201;i==j?a[i][i]=b[i][i]=1:a[i][j]=(a[i-1][j-1]-(i-1)*a[i-1][j])%98999,b[i][j]=(b[i-1][j-1]+j*b[i-1][j])%98999,++j);
    for(F>>m;F>>m>>i>>j;G<<(m==1?a[i][j]:b[i][j])<<'\n');
    return 0;
}
