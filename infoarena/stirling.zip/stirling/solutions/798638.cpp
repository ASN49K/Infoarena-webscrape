#include <fstream>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int a[205][205],b[205][205];
void s()
{
    int i,j;
    for(i=2;i<201;i++)
        for(j=1;j<=i;j++)
            a[i][j]=(a[i-1][j-1]-(i-1)*a[i-1][j])%98999;
}
void S()
{
    int i,j;
    for(i=2;i<201;i++)
        for(j=1;j<=i;j++)
            b[i][j]=(b[i-1][j-1]+j*b[i-1][j])%98999;
}
int main()
{
    int q,t,n,m;
    f>>q;
    a[1][1]=b[1][1]=1;
    while(q--)
    {
        f>>t>>n>>m;
        if(t==1)
        {
            s();
            g<<a[n][m]<<'\n';
        }
        else
        {
            S();
            g<<b[n][m]<<'\n';
        }

    }
    g.close();
    return 0;
}
