#include <iostream>
#include <fstream>
using namespace std;
const int N=201,MOD= 98999;
int t,x,n,m,s[N][N],S[N][N];
ifstream f("stirling.in");
ofstream g("stirling.out");
void generare_speta_I()
{
    s[1][1]= 1;
    for( int i=2 ; i<N ; ++i )
        for( int j=1 ; j<=i ; ++j )
            s[i][j]= ( s[i-1][j-1] - (i-1)*s[i-1][j] ) ;
}

void generare_speta_II()
{
    S[1][1] = 1;
    for(int i = 2 ; i < N; ++i)
        for(int j = 1 ; j < i ; ++j)
            S[i][j] = (S[i-1][j-1]+j*S[i-1][j]);
}

int main()
{
    generare_speta_I();
    generare_speta_II();
    f>>t;
    for(int i = 1; i <= t ; i++)
    {
        f>>x>>n>>m;
        if(x==1) g<<s[n][m]%MOD<<'\n';
        if(x==2) g<<S[n][m]%MOD<<'\n';
    }
    return 0;
}

