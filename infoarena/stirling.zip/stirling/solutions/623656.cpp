#include <cstdio>
#define nmax 210
#define mx 201
FILE *f,*g;
typedef int mat[nmax][nmax];

int T,d,x,y,i;
mat s1,s2;


inline int stirling1(int x,int y) {
return s1[x][y];
}
inline int stirling2(int x,int y) {
return s2[x][y];
}

inline void preprocesare() {
int i,j;

for (i=1,j=0;j<=mx;j++)
    s2[i][j]=1;
for (s1[1][1]=1,i=1,j=2;j<=mx;j++)
    s1[i][j]=0;

for (i=2;i<=mx;i++)
    for (j=1;j<=mx;j++) {
        s1[i][j]=(s1[i-1][j-1]-(i-1)*s1[i-1][j]) % 98999;
        s2[i][j]=(s2[i-1][j-1]+s2[i-1][j]*j) % 98999;

        }

}

int main() {
f=fopen("stirling.in","r");
g=fopen("stirling.out","w");

preprocesare();

fscanf(f,"%d",&T);
for (i=1;i<=T;i++) {
    fscanf(f,"%d%d%d",&d,&x,&y);
    if (d==1)
        fprintf(g,"%d\n",stirling1(x,y));
    else
        fprintf(g,"%d\n",stirling2(x,y));

    }


fclose(g);
return 0;
}
