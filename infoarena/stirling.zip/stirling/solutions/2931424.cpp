#include<fstream>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
const int N=201,MOD=98999;

int t,n,m,speta,s[N][N],S[N][N];

void precalculare_s()
{
	s[1][1]= 1;
	for( int i=2 ; i<N ; ++i )
		for( int j=1 ; j<=i ; ++j )
			s[i][j]= ( s[i-1][j-1] - (i-1)*s[i-1][j] )%MOD ;
}

void precalculare_S()
{
	S[1][1]= 1;
	for( int i=2 ; i<N ; ++i )
		for( int j=1 ; j<=i ; ++j )
			S[i][j]= ( S[i-1][j-1] + j*S[i-1][j] )%MOD;
}

int main()
{


	precalculare_s();
	precalculare_S();
	f>>t;

	while(t--)
	{
	f>>speta>>n>>m;
		if(speta==1)
			printf("%d\n",s[n][m]);
		if(speta==2)
			printf("%d\n",S[n][m]);
	}

	return 0;
}
