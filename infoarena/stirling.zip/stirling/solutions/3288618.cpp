#include <bits/stdc++.h>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int s[230][230],S[230][230];
const int mod=98999;

int main()
{
    s[0][0]=1;
    for(int i=1; i<=200; i++)
        for(int j=1; j<=i; j++)
            s[i][j]=s[i-1][j-1]+(i-1)*s[i-1][j];
    S[0][0]=1;
    for(int i=1; i<=200; i++)
        for(int j=1; j<=i; j++)
            S[i][j]=S[i-1][j-1]+j*s[i-1][j];
    int t; f>>t;
    for(int i=1; i<=t; i++)
    {
        int op,n,k;
        f>>op>>n>>k;
        if(op==1)
        {
            if((n-k)%2==1)
                g<<'-';
            g<<s[n][k]<<'\n';
        }
        else
            g<<S[n][k]<<'\n';
    }
    return 0;
}
