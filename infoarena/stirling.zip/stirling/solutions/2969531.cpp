#include <fstream>
#include <vector>

std::ifstream fin("stirling.in");
std::ofstream fout("stirling.out");

const int MOD = 98999;

int s[201][201], S[201][201];

void preCompute_s () {
    s[1][1] = 1;
    for (int i = 2; i <= 200; i += 1) {
        for (int j = 1; j <= i; j += 1)
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
    }
}

void preCompute_S () {
    S[1][1] = 1;
    for (int i = 2; i <= 200; i += 1) {
        for (int j = 1; j <= i; j += 1)
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
    }
}

int main () {
    preCompute_s (), preCompute_S ();
    int testCases; fin >> testCases;
    while (testCases > 0) {
        int kind, n, m; fin >> kind >> n >> m;
        if (kind == 1) fout << s[n][m];
        else fout << S[n][m];
        fout << '\n', testCases -= 1;
    }
    fin.close (), fout.close ();
    return 0;
}
