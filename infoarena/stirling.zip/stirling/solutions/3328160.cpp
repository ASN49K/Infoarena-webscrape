#include <iostream>
#include <fstream>

using namespace std;
const int MOD=98999,
          MAX=200;

int n,m,T;
int S1[MAX+1][MAX+1],S2[MAX+1][MAX+1];

ifstream f("stirling.in");
ofstream g("stirling.out");

void calc(){
    S1[0][0]=S2[0][0]=1;
    for(int i=1;i<=MAX;i++){
        S1[i][i]=S2[i][i]=1;
        S1[i][0]=S2[i][0]=0;
        for(int j=1;j<i;j++){
            S1[i][j]=(S1[i-1][j-1]-1ll*(i-1)*S1[i-1][j]%MOD)%MOD;
            S2[i][j]=(S2[i-1][j-1]+1ll*j*S2[i-1][j]%MOD)%MOD;
        }
    }
}

int main()
{
    int x;
    calc();
    f >> T;
    while(T--){
        f >> x >> n >> m;
        if(x==1) g << S1[n][m] << '\n';
        else g << S2[n][m] << '\n';
    }
    return 0;
}
