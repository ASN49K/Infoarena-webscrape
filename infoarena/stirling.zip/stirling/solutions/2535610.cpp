#include <iostream>
#include <fstream>

#define M 98999

using namespace std;

ifstream in("stirling.in");
ofstream out("stirling.out");

int k,x,n,m;

int s[201][201],s1[201][201];

int main()
{
    in>>k;
    s[1][1]=1;
    s1[1][1]=1;
    for(int i=2;i<=200;i++)
    {
        for(int j=1;j<=i;j++)
        {
            s[i][j]=(s[i-1][j-1]+j*s[i-1][j]%M)%M;
            s1[i][j]=(s1[i-1][j-1]-s1[i-1][j]*(i-1)%M)%M;
        }
    }
    for(int i=1;i<=k;i++)
    {
        in>>x>>n>>m;
        if(x==2)
            out<<s[n][m];
        else
            out<<s1[n][m];
        out<<'\n';
    }
}
