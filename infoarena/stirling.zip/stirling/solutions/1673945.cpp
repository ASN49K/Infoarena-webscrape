#include<cstdio>
using namespace std;

FILE *fin = freopen("stirling.in", "r", stdin);
FILE *fout = freopen("stirling.out", "w", stdout);

const int N = 201;
const int MOD = 98999;
int T, X, A, B, s[N][N], S[N][N];


void Find_s()
{
    s[1][1] = 1;

    for (int i = 2; i < N; i++)
        for (int j = 1; j <= i; j++)
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
}

void Find_S()
{
    S[1][1] = 1;

    for (int i = 2; i < N; i++)
        for (int j = 1; j <= i; j++)
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
}
int main()
    {
        Find_s(); Find_S();
        scanf("%d", &T);

        while (T--)
        {
            scanf("%d%d%d", &X, &A, &B);
            if (X == 1)
                printf("%d\n", s[A][B]);
            else
                printf("%d\n", S[A][B]);
        }
    }
