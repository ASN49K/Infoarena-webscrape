#include <iostream>
#include <fstream>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int t,n,m,x,s1[210][210],s2[210][210],i;
void stirling1()
{
    s1[0][0]=1;
    int i,j;
    for(i=1;i<=205;i++)
        for(j=1;j<=i;j++)
            s1[i][j]=(s1[i-1][j-1]-(i-1)*s1[i-1][j])%98999;

}
void stirling2()
{
    s2[0][0]=1;
    int i,j;
    for(i=1;i<=205;i++)
        for(j=1;j<=i;j++)
            s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%98999;
}
int main()
{
    f>>t;
    stirling1();
    stirling2();
    for(i=1;i<=t;i++)
        {
            f>>x>>n>>m;
            if(x==1) g<<s1[n][m]<<'\n';
            else g<<s2[n][m]<<'\n';
        }
    return 0;
}
