#include <bits/stdc++.h>
#define mod 98999;
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int t, n, m, k;
int s[201][201], S[201][201];

void precomputes()
{
    s[1][1] = 1;
    for(int i = 2;i < 201;++i)
        for(int j = 1;j <= i;++j)
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % mod
}

void precomputeS()
{
    S[1][1] = 1;
    for(int i = 2; i < 201;++i)
        for(int j = 1;j <= i;++j)
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % mod;
}

void Read()
{
    precomputes();
    precomputeS();
    f>>t;
    for(int i = 1;i <= t;++i)
    {
        f>>k>>n>>m;
        if(k == 1)
            g<<s[n][m]<<'\n';
        else
            g<<S[n][m]<<'\n';
    }
}

int main()
{
    Read();
    return 0;
}
