#include <fstream>
#include <iostream>

using namespace std;

int s[1000][1000];
int S[1000][1000];


int main(){
	ifstream fin("stirling.in");
	ofstream fout("stirling.out");
	int t, a, b;
	fin >> t;

	for(int i = 0; i <= 999; ++i){
		s[i][i] = 1;
		S[i][i] = 1;
	}

	for(int i = 1; i <= 999; ++i){
		for(int j = 1; j <= i; ++j){
			s[i][j] = s[i - 1][j - 1] - (i - 1) * s[i - 1][j];
			S[i][j] = S[i - 1][j - 1] + j * S[i - 1][j];
		}
	}

	int x, n, m;
	for(int i = 0; i < t; ++i){
		fin >> x >> n >> m;
		if(x == 1)
			fout << s[n][m] << "\n";
		else
			fout << S[n][m] << "\n";
	}

}