#include <iostream>
#include <fstream>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

const int NMAX=200;

const int MOD=98999;

int s1[NMAX+1][NMAX+1],s2[NMAX+1][NMAX+1];

void precalc(int n)
{
    s1[0][0]=s2[0][0]=1;

    for(int i=1;i<=n;i++)
    {
        s1[i][i]=s2[i][i]=1;
        s1[i][0]=s2[i][0]=0;

        for(int j=1;j<i;j++)
        {
            s1[i][j]=(s1[i-1][j-1]-1ll*(i-1)*s1[i-1][j]%MOD)%MOD;
            s2[i][j]=(s2[i-1][j-1]+1ll*j*s2[i-1][j]%MOD)%MOD;
        }
    }

}

int main()
{
    int t,x,n,m;

    precalc(NMAX);

    f>>t;

    while(t--)
    {
        f>>x>>n>>m;
        if(x==1) g<<s1[n][m]<<'\n';
        else g<<s2[n][m]<<'\n';
    }


    return 0;
}
