#include<iostream>
#include<fstream>
using namespace std;

#define N 201
#define MOD 98999
int T;
int x,n,m;
int s[201][201], S[201][201];

void calculate_lower_upper(){
	s[1][1] = 1;
	S[1][1] = 1;
	for(int i=2;i<N;i++)
		for(int j=1;j<=i;j++){
			s[i][j] = (s[i-1][j-1] - (i-1)*s[i-1][j]) % MOD;
			S[i][j] = (S[i-1][j-1] + j * S[i-1][j]) % MOD;
		}
}


int main(){
ifstream f("stirling.in");
ofstream g("stirling.out");

calculate_lower_upper();

f>>T;
while(T--){
	f>>x>>n>>m;
	if(x==1){
		g<<s[n][m]<<endl;
	}
	if(x==2){
		g<<S[n][m]<<endl;
	}
}
return 0;
}
