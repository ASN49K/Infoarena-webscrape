#include<fstream>
using namespace std;
const int MAXN=201;
const int MOD=98999;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int s[MAXN][MAXN];
int S[MAXN][MAXN];

void precalc1()
{
	s[1][1]=1;
	for (int i=2;i<MAXN;++i)
	{
		for (int j=1;j<=i;++j)
			s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
	}
}
void precalc2()
{
	S[1][1]=1;
	for (int i=2;i<MAXN;++i)
	{
		for (int j=1;j<=i;++j)
			S[i][j]=(S[i-1][j-1]-j*S[i-1][j])%MOD;
	}
}

int main()
{
	precalc1();
	precalc2();
	int t,n,m,op;
	fin>>t;
	for (int k=1;k<=t;++k)
	{
		fin>>op>>n>>m;
		if (op==1)
			fout<<s[n][m]<<'\n';
		else if (op==2)
			fout<<S[n][m]<<'\n';
	}
	fin.close();
	fout.close();
	return 0;
}
