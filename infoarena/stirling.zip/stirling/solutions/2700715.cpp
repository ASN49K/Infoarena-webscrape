#include <iostream>
#include <fstream>

using namespace std;
ifstream f("sterling.in");
ofstream g("sterling.out");

int t, speta, n ,k;

int s2[201][201];
int s1[201][201];
void pregen2()
{
s2[0][0]=1;
for(int i=1;i<200;i++)
    for(int j=1;j<=i;j++)
        s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%98999;
}
void pregen1()
{
s1[0][0]=1;
for(int i=1;i<200;i++)
    for(int j=1;j<=i;j++)
        s1[i][j]=(s1[i-1][j-1]+(i-1)*s1[i-1][j])%98999;
}




int main()
{
    pregen1();
    pregen2();
    f>>t;

    for(int i=0;i<t;i++)
    {
        f>>speta>>n>>k;
        if(speta==2)
            g<<s2[n][k];
        if(speta==1)
            g<<s1[n][k];

    }
    return 0;
}
