#include<fstream>
#include<stdio.h>
using namespace std;

const int MOD=98999;
int stirling1[201][201], stirling2[201][201];

int main(){
    ifstream inFile("stirling.in");
    ofstream outFile("stirling.out");

    int T;
    inFile>>T;



    for(int i=0;i<201;i++)
        for(int j=0;j<201;j++){
            if(j>i){
                stirling1[i][j]=0;
                stirling2[i][j]=0;
            }else if(i==j){
                       stirling1[i][j]=1;
                       stirling2[i][i]=i;
                   }else if(i==0){
                              stirling1[i][j]=0;
                              stirling2[i][j]=0;
                          }else if(j==0){
                                     stirling1[i][j]=0;
                                     stirling2[i][j]=0;
                                 }else{
                                    stirling1[i][j]=(stirling1[i-1][j-1] - (i-1)*stirling1[i-1][j])%MOD;
                                    stirling2[i][j]=(stirling2[i-1][j-1] + j*stirling2[i-1][j])%MOD;
                                  }
        }

    int n,m,id;
    for(int i=0;i<T;i++){
        inFile>>id>>n>>m;
        if(id==1) outFile<<stirling1[n][m]<<"\n";
        else outFile<<stirling2[n][m]<<"\n";
    }
}


