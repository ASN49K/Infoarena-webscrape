#include<stdio.h>

const int N=201,MOD=98999;

int t,n,m,speta,s[N][N],S[N][N];

void precalculare_s()
{
	s[1][1]= 1;
	for( int i=2 ; i<N ; ++i )//precalculam pana la limita maxima
		for( int j=1 ; j<=i ; ++j )//pentru j>i s(i,j)=0 pentru ca ciclurile au cel putin un element
			s[i][j]= ( s[i-1][j-1] - (i-1)*s[i-1][j] )%MOD ;
}

void precalculare_S()
{
	S[1][1]= 1;
	for( int i=2 ; i<N ; ++i )
		for( int j=1 ; j<=i ; ++j )
			S[i][j]= ( S[i-1][j-1] + j*S[i-1][j] )%MOD;
}

int main()
{
	freopen("stirling.in","r",stdin);
	freopen("stirling.out","w",stdout);
	
	precalculare_s();
	precalculare_S();
	
	scanf("%d",&t);
	
	while(t--)
	{
		scanf("%d%d%d",&speta,&n,&m);
		if(speta==1)
			printf("%d\n",s[n][m]);
		if(speta==2)
			printf("%d\n",S[n][m]);
	}
	
	return 0;
}
