#include <bits/stdc++.h>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");
typedef long long ll;
const ll MOD = 98999;
const ll MAX = 200;
ll q, i, j, stir[2][MAX + 2][MAX + 2];

int main() {
    fin.tie(NULL);
    fout.tie(NULL);

    stir[0][0][0] = 1;
    stir[1][0][0] = 1;
    for(i = 1; i <= MAX; i++) {
        for(j = 1; j <= i; j++) {
            stir[0][i][j] = (stir[0][i - 1][j - 1] +  j      * stir[0][i - 1][j] % MOD + MOD) % MOD;
            stir[1][i][j] = (stir[1][i - 1][j - 1] - (i - 1) * stir[1][i - 1][j] % MOD + MOD) % MOD;
        }
    }
    fin >> q;
    while(q--) {
        fin >> i;
        if(i == 1) {
            fin >> i >> j;
            fout << stir[1][i][j] << "\n";
        }
        else {
            fin >> i >> j;
            fout << stir[0][i][j] << "\n";
        }
    }

    return 0;
}

