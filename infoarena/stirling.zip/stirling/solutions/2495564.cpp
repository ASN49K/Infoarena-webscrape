#include <iostream>
#include <fstream>
using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int s[205][205];
int S[205][205];

void spetaI()
{
    int i,j;
    s[1][1]=1;
    for(i=2; i<=204; i++)
        for(j=1; j<=i; j++)
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999;

}

void spetaII()
{
    int i,j;
    S[1][1]=1;
    for(i=2; i<=204; i++)
        for(j=1; j<=i; j++)
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
}

int t;
int x,n,m;

int main()
{
    spetaI();
    spetaII();
    int i;
    f>>t;
    for(i=1; i<=t; i++)
    {
        f>>x>>n>>m;
        if(x==1) g<<s[n][m]<<'\n';
        else g<<S[n][m]<<'\n';

    }
    return 0;
}
