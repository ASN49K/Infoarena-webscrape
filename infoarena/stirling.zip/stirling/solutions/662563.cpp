#include <fstream>
using namespace std;

int speta, n,m,s[212][212],S[212][212],i,j,t;

void stirling()
{
	s[0][0]=1;
	S[0][0]=1;
	for (i=1;i<=211;i++) 
	{
		S[i][0]=0;
		S[i][i]=1;
		s[i][i]=0;
		s[i][0]=0;
	}
 
	for (i=1;i<=211;i++)
		for (j=1;j<=211;j++) 
		{
			s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j]) % 98999;
			S[i][j]=(S[i-1][j-1]+j*S[i-1][j]) % 98999;
		}
}

int main ()
{
	ifstream f ("stirling.in");
	ofstream g ("stirling.out");
	stirling();
	f >>t;
	for (i=1; i<=t; ++i)
	{
		f >> speta >> n >>m;
		if (speta==1) g <<s[n][m];
		else g<<S[n][m];
		g<<endl;
	}
	return 0;
}
