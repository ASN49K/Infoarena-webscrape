#include <fstream>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int n,m, speta[201][201],altaSpeta[201][201];


void speta1()
{
    int i,j;
    speta[1][1]=1;
    for(i=2;i<201;i++)
        for(j=1;j<=i;j++)
            speta[i][j]=(speta[i-1][j-1]-(i-1)*speta[i-1][j])%98999;
}

void speta2()
{
    int i,j;
    altaSpeta[1][1]=1;
    for(i=2;i<201;i++)
        for(j=1;j<=i;j++)
            altaSpeta[i][j]=(altaSpeta[i-1][j-1]+j*altaSpeta[i-1][j])%98999;
}

int main()
{
    int x,n,m;
    short int t;
    f>>t;
    speta1();speta2();
    while(t)
    {
        f>>x>>n>>m;
        if(x==1) g<<speta[n][m];
        else g<<altaSpeta[n][m];
        if(t>1) g<<'\n';
        t--;
    }
    return 0;
}
