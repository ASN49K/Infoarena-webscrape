#include<cstdio>
#include<iostream>
using namespace std;

const int MOD = 98999;
const int NMAX = 201;
const int MMAX = 201;
int T;
long long s[2][NMAX][MMAX];
int speta, n, m;

void calcul_stirling()
{
	s[0][1][1] = 1;
	s[1][1][1] = 1;
	for(int i = 2 ; i < NMAX ; i++)
		for(int j = 1 ; j <= i ; j++)
		{
			s[0][i][j] = -1LL *(i - 1) * s[0][i - 1][j] + s[0][i - 1][j - 1];
			s[1][i][j] = 1LL * j * s[1][i - 1][j] + s[1][i - 1][j - 1];
		}
}

int main()
{
	freopen("stirling.in", "r", stdin);
	freopen("stirling.out", "w", stdout);
	
	calcul_stirling();
	
	cin>> T;
	for(int i = 1 ; i <= T ; i++)
	{
		scanf("%d%d%d", &speta, &n, &m);
		printf("%lld\n", s[speta - 1][n][m]);
	}
	
	return 0;
}
