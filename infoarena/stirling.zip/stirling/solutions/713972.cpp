#include<stdio.h>
FILE *fin=fopen("padure.in","r");
FILE *fout=fopen("padure.out","w");

int i,j,ii,jj,a[51][51],n,m,x,max;

int vizibile(int x, int y){
int s=0;

	if( x>=1 && y>=1 ) s += a[x][y-1] + a[x-1][y] - a[x-1][y-1];
	
	if( n-x>=1 && y>=1 ) s += a[n-x][y-1] + a[n-x-1][y] - a[n-x-1][y-1];
	
	if( n-x>=1 && m-y>=1 ) s += a[n-x][m-y-1] + a[n-x-1][m-y] - a[n-x-1][m-y-1];
	
	if(x>=1 && m-y>=1) s += a[x][m-y-1] + a[x-1][m-y] - a[x-1][m-y-1];

return s;
}
int main(){
	
	fscanf(fin,"%d %d", &n, &m);
	
	for(i=1;i<n;i++){
		for(j=1;j<m;j++){
			if( a[i][j]==0 && (i!=0 && j!=0) ){
				
				ii=i+i;
				jj=j+j;
				while(ii<=n && jj<=n){
					a[ii][jj]=1;
					ii+=i;
					jj+=j;
				}
			}
		}
	}
	
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			a[i][j] = (a[i][j]+1)%2 + a[i][j-1] + a[i-1][j] - a[i-1][j-1];
		}
	}
	
	
	for(i = 0; i<n; i++){
		for(j = 0; j<m; j++){
			x = vizibile(i,j);
			
			if(x > max){
				max = x;
			}
		}
	}
	
	fprintf(fout,"%d",max);
	
	fclose(fout);
	fclose(fin);
	
	return 0;
}