#include <iostream>
#include <fstream>
#include <cstring>
#include <cmath>
const int N=201,MOD=98999;
using namespace std;


int t,n,m,speta,s[N][N],S[N][N];
void speta1()
 {
  s[1][1]=1;
  for(int i=2;i<N;i++)
    for(int j=1;j<=i;j++)
   s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
 }
void speta2()
 {
  S[1][1]=1;
  for(int i=2;i<N;i++)
    for(int j=1;j<=i;j++)
   S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
 }
int main()
{
ifstream f("stirling.in");
ofstream g("stirling.out");
f>>t;
speta1();
speta2();
for(int i=1;i<=t;i++)
 {
  f>>speta>>n>>m;
  if(speta==1) g<<s[n][m];
  else g<<S[n][m];
  g<<endl;
 }
}
