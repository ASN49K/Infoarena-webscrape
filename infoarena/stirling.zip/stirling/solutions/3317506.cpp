#include <bits/stdc++.h>
using namespace std;

ifstream fin ("stirling.in");
ofstream fout ("stirling.out");

const int mod = 98999;

int s1[205][205];

void fkind ()
{
    s1[1][1] = 1;
    for (int i = 2; i <= 200; i++)
        for (int j = 1; j <= i; j++)
            s1[i][j] = (s1[i - 1][j - 1] - (i - 1) * s1[i - 1][j]) % mod;
}

int s2[205][205];

void skind ()
{
    s2[1][1] = 1;
    for (int i = 2; i <= 200; i++)
        for (int j = 1; j <= i; j++)
            s2[i][j] = (s2[i - 1][j - 1] + j * s2[i - 1][j]) % mod;
}

int main ()
{
    fkind ();
    skind ();
    int t;
    fin >> t;
    for (int i = 1; i <= t; i++)
    {
        int x, n, k;
        fin >> x >> n >> k;
        if (x == 1)
            fout << s1[n][k] << '\n';
        else
            fout << s2[n][k] << '\n';
    }
    return 0;
}
