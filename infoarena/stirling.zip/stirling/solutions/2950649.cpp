#include <bits/stdc++.h>

using namespace std;

ifstream fin ("stirling.in");
ofstream fout ("stirling.out");

const int MaxN = 205;
const int MOD = 98999;

int task;

int s[MaxN][MaxN], S[MaxN][MaxN];


void Calc_s() {
    s[1][1] = 1;
    for (int i = 2; i < MaxN; i++)
        for (int j = 1; j <= i; j++)
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * (s[i - 1][j])) % MOD;
}

void Calc_S() {
    S[1][1] = 1;
    for (int i = 2; i < MaxN; i++)
        for (int j = 1; j <= i; j++)
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
}

int main()
{
    Calc_S();
    Calc_s();
    fin >> task;
    while (task --) {
            int q, n , m;
            fin >> q >> n >> m;
            if (q == 1) {
                fout << s[n][m] << "\n";
            }
            else fout << S[n][m] << "\n";
    }
    return 0;
}
