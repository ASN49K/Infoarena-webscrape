#include <fstream>
#include <iostream>
#define mod 98999
#define maxx 205
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int t;
int s[maxx][maxx];
int S[maxx][maxx];
void Compute()
{
    // stirling de speta 1
    s[0][0] = 1;
    for(int i = 1; i <= 200; i++)
    {
        s[i][0] = 0;
        s[i][i] = 1;
    }
    for(int i = 2; i <= 200; i++)
    {
        for(int j = 1; j < i; j++)
        {
            s[i][j] = s[i-1][j-1] - (i - 1) * s[i - 1][j];
            s[i][j] %= mod;
        }
    }
    // stirling de speta doua
    S[0][0] = 1;
    for(int i = 1; i <= 200; i++)
    {
        S[i][0] = 0;
        S[i][i] = 1;
    }
    for(int i = 2; i <= 200; i++)
    {
        for(int j = 1; j < i; j++)
        {
            S[i][j] = S[i-1][j-1] + j * S[i-1][j];
            S[i][j] %= mod;
        }
    }
}
int main()
{
    Compute();
    fin >> t;
    for(int i = 1; i <= t; i++)
    {
        int x, n, m;
        fin >> x >> n >> m;
        if(x == 1)
        {
            fout << s[n][m] << "\n";
        }
        else
        {
            fout << S[n][m] << "\n";
        }
    }
    /*for(int i = 0; i <= 10; i++)
    {
        for(int j = 0; j <= i; j++)
        {
            cout << s[i][j] << " ";
        }
        cout << endl;
    }
    cout << "----------------------------\n";
    for(int i = 0; i <= 10; i++)
    {
        for(int j = 0; j <= i; j++)
        {
            cout << S[i][j] << " ";
        }
        cout << endl;
    }*/
    return 0;
}
