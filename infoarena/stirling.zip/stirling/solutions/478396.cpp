#include<fstream>
#include<iostream>
using namespace std;

#define MAXN 202
#define MAXM 202

long s[MAXN][MAXM],S[MAXN][MAXM];

int main()
{
	fstream fin("stirling.in",fstream::in);
	fstream fout("stirling.out",fstream::out);
	int T,x,n,m;

	for(int i=1; i<=MAXN; i++)
	{
		S[i][i]=s[i][i]=1;
		S[i][0]=s[i][0]=0;
		S[i][1]=1;
	}
	S[0][0]=s[0][0]=1;
	for(int i=2; i<MAXN; i++)
	{
		for(int j=1; j<i; j++)
		{
			s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999;
		}
	}
	for(int i=1; i<MAXN; i++)
	{
		for(int j=1; j<i; j++)
		{
			S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
		}
	}
	fin>>T;
	for(int i=0; i<T; i++)
	{
		fin>>x>>n>>m;
		switch(x)
		{
			case 1:
			{
				fout<<s[n][m]<<"\n";
			}; break;
			default:
				fout<<S[n][m]<<"\n";
		}
	}
	fin.close();
	fout.close();
	/*for(int i=0; i<=9; i++)
	{
		for(int j=0; j<=i; j++)
			cout<<s[i][j]<<" ";
		cout<<"\n";
	}
	cout<<endl<<endl;
	for(int i=0; i<=9; i++)
	{
		for(int j=0; j<=i; j++)
			cout<<S[i][j]<<" ";
		cout<<"\n";
	}*/
	return 0;
}
