#include <cstdio>

using namespace std;

const int MOD=98999, N(201);
int T,x,n,m;
int s[N][N],S[N][N];
int i,j;
void speta1()
{
    s[1][1]=1;
    for(i=2; i<N; i++)
        for(j=1; j<=i; j++)
        {
            s[i][j]=( s[i-1][j-1] - (i-1) * s[i-1][j] ) % MOD;
            if(i==n && j==m)
                break;
        }
}
void speta2()
{
    S[1][1]=1;
    for(i=2; i<N; i++)
        for(j=1; j<=i; j++)
            S[i][j]=( S[i-1][j-1] + j * S[i-1][j] ) % MOD;
}
int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d%d%d",&x,&n,&m);
        if(x==1)
        {
            speta1();
            printf("%d\n",s[n][m]);
        }
        else
        {
            speta2();
            printf("%d\n",S[n][m]);
        }
    }
    return 0;
}
