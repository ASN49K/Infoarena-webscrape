#include<cstdio>
#define MOD 98999
#define N 201
int s[2][N][N];
int T,x,y,q;
inline void citire()
{
	freopen("stirling.in","r",stdin);
	freopen("stirling.out","w",stdout);
	scanf("%d",&T);
	T=1;
	int aux;
	while (T--)
	{
		scanf("%d%d%d",&q,&x,&y);
		aux=s[(q&1)][x][y];
		printf("%d\n",aux);
	}
}
inline int mod(int a)
{
	return (a>=MOD)?(a-MOD):(a);
}
inline void stirling_sp1_cu_semn()
{
	s[1][N][1]=1;
	for (int i=2; i<=N; ++i)
	{
		for (int j=1; j<i &&j<=N; ++j)
			s[1][i][j]=mod(s[1][i-1][j-1]-(i-1)*s[1][i-1][j]);
		//s[1][i][i]=1;
	}
}
inline void stirling_sp2()
{
	s[0][N][1]=1;
	s[0][N][N]=1;
	for (int i=2; i<=N; ++i)
	{
		for (int j=1; j<i&&j<=N; ++j)
			s[0][i][j]=mod(j*s[0][i-1][j]+s[0][i-1][j-1]);
		//s[0][i][i]=1;
	}
}
int main()
{
	
	stirling_sp1_cu_semn();
	stirling_sp2();
	citire();
	return 0;
}
