#include<stdio.h>
using namespace std;

FILE*f=fopen("stirling.in","r");
FILE*g=fopen("stirling.out","w");

int i,j,n,m,t,c,a[201][201],b[201][201];

int main() {

    for(i=0;i<=200;i++)
        for(j=0;j<=200;j++) {
            if(i==0||j==0||i<j) a[i][j]=0;
            else if(i==1&&j==1) a[i][j]=1;
                 else a[i][j]=(a[i-1][j-1]-(i-1)*a[i-1][j])%98999;
        }

    for(i=0;i<=200;i++)
        for(j=0;j<=200;j++)
            if(j==1||i==j) b[i][j]=1;
            else b[i][j]=(b[i-1][j-1]+j*b[i-1][j])%98999;

    fscanf(f,"%d",&t);

    for(i=1;i<=t;i++) {
        fscanf(f,"%d%d%d",&c,&n,&m);
        if(c==1) fprintf(g,"%d\n",a[n][m]);
        else fprintf(g,"%d\n",b[n][m]);
    }


    return 0;
}
