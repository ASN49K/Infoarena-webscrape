#include <iostream>
#include <fstream>
#define MOD 98999
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int x,m,n,t,s[201][201],S[201][201],maxn1,maxn2,maxm1,maxm2;
int main()
{
    s[1][1]=S[1][1]=1;
    for(int i=2;i<201;i++)
    {
        for(int j=1;j<=i;j++)
        {
            s[i][j]=(s[i-1][j-1]-((i-1)*s[i-1][j]))%MOD;
            S[i][j]=(S[i-1][j-1]+(S[i-1][j]*j))%MOD;
        }
    }
    fin>>t;
    for(int l=1;l<=t;l++)
    {
        fin>>x>>n>>m;
        if(x==1)
        {
            fout<<s[n][m]<<"\n";
        }
        if(x==2)
        {
            fout<<S[n][m]<<"\n";
        }
    }
    return 0;
}
