#include<fstream>

#define mod 98999 
#define max_n 202

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int s[max_n][max_n] , S[max_n][max_n];

void comp(){
	
	int i , j;
	
	s[1][1] = S[1][1] = 1;
	
	for(i = 2 ; i < max_n ; i++){
		for(j = 1 ; j <= i ; j++){
			s[i][j] = ( s[i-1][j-1] - (i-1)*s[i-1][j] ) % mod;
			S[i][j] = ( S[i-1][j-1] + j*S[i-1][j] ) % mod;
		}
	}
	
}


int main(){
	
	comp();
	
	int T , op , a , b;
	
	f>>T;
	
	while(T--){
		f>>op>>a>>b;
		
		switch(op){
		case 1:
			g<<s[a][b]<<"\n";
			break;
		default:
			g<<S[a][b]<<"\n";
			break;
		}
		
	}
	
	return 0;
}
