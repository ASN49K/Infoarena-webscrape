#include <cstdio>
#include <algorithm>

using namespace std;

const int N = 205;

int t;

int mat1[210][210];
int mat2[210][210];

void calculareMat(){
    mat1[1][1] = 1;
    mat2[1][1] = 1;

    for(int i = 2; i < N; i++){
        for(int j = 1; j < N; j++){
            mat1[i][j] = mat1[i - 1][j - 1] - (i - 1) * mat1[i - 1][j];
            mat2[i][j] = mat2[i - 1][j - 1] + j * mat2[i - 1][j];
        }
    }
}

void solve(){
    scanf("%d", &t);

    int tmp1, tmp2, tmp3;

    for(int i = 0; i < t; i++){
        scanf("%d %d %d", &tmp1, &tmp2, &tmp3);

        if(tmp1 == 1){
            printf("%d\n", mat1[tmp2][tmp3]);
        }
        else if(tmp1 == 2){
            printf("%d\n", mat2[tmp2][tmp3]);
        }
    }
}

int main() {
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    calculareMat();
    solve();

    return 0;
}