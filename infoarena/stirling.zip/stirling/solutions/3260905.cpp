#include <iostream>
#include<fstream>
using namespace std;int t,c,n,m,s[201][201],S[201][201],i,j;const int MOD=98999;ifstream fin("stirling.in");ofstream fout("stirling.out");
void precalcs(){s[1][1]=1;
for(i=2;i<=200;i++)for(j=1;j<=i;j++)s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;}
void precalcS(){S[1][1]=1;
for(i=2;i<=200;i++)for(j=1;j<=i;j++)S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;}
int main()
{fin>>t;precalcs();precalcS();while(t--){fin>>c>>n>>m;
if(c==1)fout<<s[n][m];else fout<<S[n][m];fout<<"\n";
}
    return 0;
}
