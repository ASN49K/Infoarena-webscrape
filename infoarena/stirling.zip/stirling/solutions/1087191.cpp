#include<cstdio>
#include<iostream>
using namespace std;

const int MOD=98999;
int s[201][201], S[201][201];
void generate_s();
void generate_S();

int main(){
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);

    int T;
    cin>>T;

    int id,n,m;
    for(int i=0;i<T;i++){
        cin>>id>>n>>m;
        if(id==1) cout<<s[n][m]<<"\n";
           else cout<<S[n][m]<<"\n";
    }
}

void generate_s(){
    s[1][1]=1;
    for(int i=2;i<201;i++)
        for(int j=1;j<=i;i++)
            s[i][j]=( s[i-1][j-1] - (i-1)*s[i-1][j] )%MOD;
}

void generate_S(){
    S[1][1]=1;
    for(int i=2;i<201;i++)
        for(int j=1;j<=i;i++)
            S[i][j]=( S[i-1][j-1] - j*S[i-1][j] )%MOD;
}
