#include <iostream>
#include <fstream>

using namespace std;

const int MOD = 98999;
const int MAX = 205;

int stirling[3][MAX][MAX];

void precompute() {
    stirling[1][0][0] = 1;
    stirling[2][0][0] = 1;

    for (int n = 1; n <= 200; n++) {
        stirling[1][n][0] = 0;
        stirling[2][n][0] = 0;

        for (int m = 1; m <= n; m++) {
            // s(n, m) = s(n-1, m-1) - (n-1) * s(n-1, m)
            stirling[1][n][m] = (stirling[1][n - 1][m - 1] - (1LL * (n - 1) * stirling[1][n - 1][m]) % MOD) % MOD;

            // S(n, m) = S(n-1, m-1) + m * S(n-1, m)
            stirling[2][n][m] = (stirling[2][n - 1][m - 1] + (1LL * m * stirling[2][n - 1][m]) % MOD) % MOD;
        }
    }
}

int main() {
    ifstream fin("stirling.in");
    ofstream fout("stirling.out");

    if (!fin || !fout) return 0;

    precompute();

    int T;
    if (fin >> T) {
        while (T--) {
            int x, n, m;
            fin >> x >> n >> m;

            if (m > n || m < 0 || n < 0 || n > 200 || m > 200) {
                fout << 0 << "\n";
            }
            else {
                fout << stirling[x][n][m] << "\n";
            }
        }
    }

    return 0;
}
