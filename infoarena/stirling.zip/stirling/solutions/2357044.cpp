#include <fstream>

using namespace std;

ifstream fin( "stirling.in" );
ofstream fout( "stirling.out" );

const int NMAX = 205;

int nr_q;

int s[NMAX][NMAX], S[NMAX][NMAX];

int main()
{
    S[1][1] = 1;

    for( int i = 2; i <= 200; ++i )
      for( int j = 1; j <= 200; ++j )
       S[i][j] = S[i - 1][j - 1] + j * S[i - 1][j];

    s[1][1] = 1;

    for( int i = 2; i <= 200; ++i )
      for( int j = 1; j <= 200; ++j )
       s[i][j] = s[i - 1][j - 1] - ( i - 1 ) * s[i - 1][j];

    int tip, n, k;

    fin >> nr_q;

    for( int i = 1; i <= nr_q; ++i )
    {
      fin >> tip >> n >> k;

      if( tip == 1 ) fout << s[n][k] << '\n';
      else fout << S[n][k] << '\n';
    }

    return 0;
}
