#include <fstream>
#define N 200
using namespace std;
int s[210][210][2],i,j,n,k,x,t;
void stirling1()
{	
	s[1][1][0]=1; s[2][1][0]=-1; s[2][2][0]=1;
	for(i=3;i<=N;i++)
	for(j=1;j<=i;j++)
	s[i][j][0]=s[i-1][j-1][0]-(i-1)*s[i-1][j][0];
}
void stirling2()
{
	s[1][1][1]=s[2][1][1]=s[2][2][1]=1;
	for(i=3;i<=N;i++)
	for(j=1;j<=i;j++)
	s[i][j][1]=s[i-1][j-1][1]+j*s[i-1][j][1];
}
int main()
{
	ifstream fi("stirling.in");
	ofstream fo("stirling.out");
	stirling1(); stirling2();
	fi>>t;
	while(t--)
	{
		fi>>x>>n>>k;
		fo<<s[n][k][x-1]<<"\n";
	}
	return 0;
}
