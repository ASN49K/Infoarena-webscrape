#include <fstream>
#define DIM 311
#define MOD 98999
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int n,m,T;
long long DI[DIM][DIM],DII[DIM][DIM];

int main(void){
    register int i,j,x;

    DI[1][1]=DII[1][1]=1;
    for(i=2;i<=DIM;i++)
        for(j=1;j<=i;j++)
            DI[i][j]=(DI[i-1][j-1]-(i-1)*DI[i-1][j])%MOD,DII[i][j]=(DII[i-1][j-1]+j*DII[i-1][j])%MOD;

    f>>T;
    for(;T;T--){
        f>>x>>n>>m;
        if(x==1)
            g<<DI[n][m]<<"\n";
        else
            g<<DII[n][m]<<"\n";
    }
    return 0;
}
