#include <iostream>
#include <fstream>
#define mod 98999
using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

long long t,p,n,m,s[205][205],S[205][205];

void creeares()
{
    s[1][1]=1;
    s[2][1]=-1;
    s[2][2]=1;
    for (int i=3; i<=204; i++)
    {
        s[i][1]=s[i-1][1]*(-(i-1));
        for (int j=2; j<i; j++)
        {
            s[i][j]=s[i-1][j-1]-(((i-1)%mod)*(s[i-1][j]%mod))%mod;
        }
        s[i][i]=1;
    }
}

void creeareS()
{
    S[1][1]=1;
    S[2][1]=1;
    S[2][2]=1;
    for (int i=3; i<=204; i++)
    {
        S[i][1]=1;
        S[i][i]=1;
        for (int j=2; j<i; j++)
        {
           S[i][j]= S[i-1][j-1]+((j%mod)*(S[i-1][j]%mod))%mod;
        }
    }
}

int main()
{
    f >> t;
    creeares();
    creeareS();
    for (int i=0; i<t; i++)
    {
        f >> p >> n >> m;
        if (p==1)
            g << s[n][m] << endl;
        else
            g << S[n][m] << endl;
    }
    return 0;
}
