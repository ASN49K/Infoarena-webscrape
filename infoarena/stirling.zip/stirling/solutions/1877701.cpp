#include <fstream>
#include <iostream>
using namespace std;

#define MOD 98999

ifstream fin("stirling.in");
ofstream fout("stirling.out");



int recursion_S(int n,int m)
{
  if( !n || !m )
  {
    return 0;
  }
   if( n<m )
   {
     return 0;
   }
   if( n==1 && m==1 )
   {
     return 1;
   }
  return recursion_S(n-1,m-1)+(m*recursion_S(n-1,m));

}

int recursion_s(int n,int m)
{
  if( !n || !m )
  {
    return 0;
  }
   if( n<m )
   {
     return 0;
   }
   if( n==1 && m==1 )
   {
     return 1;
   }
  return recursion_s(n-1,m-1)-((n-1)*recursion_s(n-1,m));

}

int main()
{

  int n=0;
  fin>>n;
  for(unsigned int i=0; i<n;++i)
  {
    int x,y;
    int type;
    fin>>type;
    fin>>x>>y;
    if(type==1)
    {
      fout<<recursion_s(x,y)%MOD<<'\n';
    }
    else fout<<recursion_S(x,y)%MOD<<'\n';
  }

  return 0;

}
