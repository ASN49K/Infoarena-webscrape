#include <bits/stdc++.h>
#define MaxN 201
using namespace std;
int s[MaxN][MaxN],S[MaxN][MaxN];

void compute()
{
    s[0][0]=S[0][0]=1;
    for(int i=1;i<MaxN;i++)
        for(int j=1;j<MaxN;j++)
        s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j],
        S[i][j]=S[i-1][j-1]+j*S[i-1][j];

    s[0][0]=S[0][0]=0;
}

int main()
{
    int T;
    ifstream f("stirling.in");
    ofstream g("stirling.out");
    compute();
    f>>T;
    while(T--)
    {
        int type,x,y;
        f>>type>>x>>y;
        if(type==1) g<<s[x][y]<<'\n';
        else g<<S[x][y]<<'\n';
    }

}
