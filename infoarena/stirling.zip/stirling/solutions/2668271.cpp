#include <bits/stdc++.h>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

const int mod = 98999;
int dp[205][205][2];

int main(){
    int t;
    fin >> t;
    dp[0][0][1] = dp[0][0][0] = 1;
    for (int i = 1; i <= 200; ++i){
        for (int j = 1; j <= 200; ++j){
            dp[i][j][1] = (1LL * dp[i - 1][j - 1][1] + 1LL * dp[i - 1][j][1] * j) % mod;
            dp[i][j][0] = (1LL * dp[i - 1][j - 1][0] - 1LL * dp[i - 1][j][0] * (i - 1)) % mod;
        }
    }
    while (t--){
        int x, n, m;
        fin >> x >> n >> m;
        if (x == 1) fout << dp[n][m][0] << "\n";
        else fout << dp[n][m][1] << "\n";
    }
    fin.close();
    fout.close();
    return 0;
}
