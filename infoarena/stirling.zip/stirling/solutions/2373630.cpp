#include <fstream>
#define MOD 98999;
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int s[1000][1000], S[1000][1000];
int x, n, m;
void speta1(int x, int y)
{
    if(x==200)
        return;
    if(y==x)
    {
        s[x][y]=1;
        speta1(x+1, 1);
        return;
    }
    s[x][y]=(s[x-1][y-1]-(x-1)*s[x-1][y])%MOD;
    speta1(x, y+1);
}
void speta2(int x, int y)
{
    if(x==200)
        return;
    if(y==x)
    {
        S[x][y]=1;
        speta2(x+1, 1);
        return;

    }
    S[x][y]=(S[x-1][y-1]+y*S[x-1][y])%MOD;
    speta2(x, y+1);
}
int main()
{
    int t;
    f>>t;
    S[1][1]=1;
    S[0][0]=1;
    s[0][0]=1;
    s[1][1]=1;
    //speta2(2, 1);
    speta1(2, 1);
    for(int i=0; i<t; i++)
    {
        f>>x>>n>>m;
        if(x==2)
            g<<S[n][m]<<endl;
        else
            g<<s[n][m]<<endl;
    }
    return 0;
}
