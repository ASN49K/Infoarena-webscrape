#include <iostream>
#include <fstream>
#define mod 98999

using namespace std;

int v[205][205],v1[205][205];

void speta1()
{
    for(int i=0;i<=200;i++)
        v[i][0]=0;
    for(int i=1;i<=200;i++)
        v[i][i]=i;

    for(int i=2;i<=200;i++)
        for(int j=1;j<=200;j++)
        v[i][j]=(v[i-1][j-1]+(1-i)*v[i-1][j])%mod;
}

void speta2()
{
    for(int i=0;i<=200;i++)
        v1[i][0]=0;
    for(int i=1;i<=200;i++)
        v1[i][i]=i;

    for(int i=2;i<=200;i++)
        for(int j=1;j<=200;j++)
        v1[i][j]=(v1[i-1][j-1]+(j-1)*v1[i-1][j])%mod;
}

int main()
{ int n,i,j,x,m,T;
    ifstream f("stirling.in");
    ofstream g("stirling.out");
    f>>T;
speta1();
speta2();

    while(T)
    {

        f>>x>>n>>m;
        if(x==1)
        {
        g<<v[n][m]<<"\n";
        }
        else
        {g<<v1[n][m]<<"\n";

        }
        T--;
    }
    return 0;
}
