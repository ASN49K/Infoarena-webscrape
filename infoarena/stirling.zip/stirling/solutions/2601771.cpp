	#include <bits/stdc++.h>
#define newline '\n'
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
///***********************
const int NMAX = 203;
const int MOD = 98999;
int s1[NMAX][NMAX], s2[NMAX][NMAX];

void getS1()
{
    s1[1][1] = 1;
    for (int i = 2; i < NMAX; i++)
        for (int j = 1; j <= i; j++)
            s1[i][j] = (s1[i - 1][j - 1] - (i - 1) * s1[i - 1][j]) % MOD;
}

void getS2()
{
    s2[1][1] = 1;
    for (int i = 2; i < NMAX; i++)
        for (int j = 1; j <= i; j++)
            s2[i][j] = (s2[i - 1][j - 1] + j * s2[i - 1][j]) % MOD;
}

int main()
{
    getS1();
    getS2();
    int q;
    for (fin >> q; q--;)
    {
        int x, n, m;
        fin >> x >> n >> m;
        if (x == 1)
            fout << s1[n][m] << newline;
        else
            fout << s2[n][m] << newline;
    }
    fout.close();
    return 0;
}
