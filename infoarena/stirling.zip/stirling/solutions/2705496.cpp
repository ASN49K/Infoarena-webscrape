#include <fstream>

using namespace std;

#define mod 98999
#define maxn 201

ifstream be("stirling.in");
ofstream ki("stirling.out");

int s1[maxn][maxn],s2[maxn][maxn];

int n;

void s_1()
{
    s1[1][1]=1;
    for(int i=2;i<maxn;i++)
        for(int j=1;j<=i;j++)
            s1[i][j]=(s1[i-1][j-1]- (i-1)*s1[i-1][j] )%mod;
}

void s_2()
{
    s2[1][1]=1;
    for(int i=2;i<maxn;i++)
        for(int j=1;j<=i;j++)
            s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%mod;
}

int main()
{

    be>>n;
    s_1(),s_2();
    for(int i=0;i<n;i++){
        int s,x,y;
        be>>s>>x>>y;
        if(s==1)ki<<s1[x][y]<<"\n";
        else ki<<s2[x][y]<<"\n";
    }


    return 0;
}
