#include<fstream>
#define DN 205
#define M 98999
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int dp1[DN][DN],dp2[DN][DN];
int n,m,t,type;
int main()
{
    dp1[1][1]=dp2[1][1]=1;for(int i=2;i<DN;i++)for(int j=1;j<=i;j++){dp1[i][j]=(dp1[i-1][j-1]-(i-1)*dp1[i-1][j])%M;dp2[i][j]=(dp2[i-1][j-1]+j*dp2[i-1][j])%M;}
    fin>>t;
    for(int i=1;i<=t;i++)
    {fin>>type>>n>>m;if(type==1)
            fout<<dp1[n][m];
        else
            fout<<dp2[n][m];
        fout<<'\n';
    }
}
