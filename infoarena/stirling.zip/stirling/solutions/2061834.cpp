#include <bits/stdc++.h>

using namespace std;
ifstream fin ("stirling.in");
ofstream fout ("stirling.out");
int s[202][202],S[202][202],n,m,t;
int main()
{
    s[1][1]=S[1][1]=1;
    for(int i=2; i<=201; i++)
    {
        for(int j=1; j<=i; j++)
        {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999;
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
        }
    }
    fin>>t;

    for(int i=1; i<=t; i++)
    {
        int x;
        fin>>x>>n>>m;
        if(x==1)
            fout<<s[n][m]<<'\n';
        else
            fout<<S[n][m]<<'\n';
    }
    return 0;
}
