#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#define N 201
#define MOD 98999


using namespace std;

int nr_stir1[N][N];
int nr_stir2[N][N];

int main(){
    int i,j;
    int t,p,n,m;

    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);

    scanf("%d",&t);

    nr_stir1[0][0]=nr_stir2[0][0]=1;
    nr_stir1[1][1]=nr_stir2[1][1]=1;

    for(i=2;i<N;i++){
        for(j=1;j<=i;j++){
            nr_stir1[i][j]=(nr_stir1[i-1][j-1] - (i-1) * nr_stir1[i-1][j])%MOD;
            nr_stir2[i][j]=(nr_stir2[i-1][j-1] + j * nr_stir2[i-1][j])%MOD;
        }
    }


    for(;t;t--){
        scanf("%d%d%d",&p,&n,&m);
        if(p==1){
            printf("%d\n", nr_stir1[n][m] );
        }else{
            printf("%d\n", nr_stir2[n][m]);
        }
    }


    return 0;
}
