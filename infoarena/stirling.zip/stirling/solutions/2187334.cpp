#include <iostream>
#include <fstream>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
const int MOD=98999;
int s[201][201],S[201][201];
int T,N,M;
void precalc()
{
    S[1][1]=S[2][1]=S[2][2]=1;
    s[1][1]=s[2][1]=s[2][2]=1;
    for(int i=1;i<=200;i++)
    {
        S[i][i]=s[i][i]=1;
        for(int j=1;j<i;j++)
        {
            S[i][j]=(S[i-1][j]+j*S[i-1][j-1])%MOD;
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
        }
    }
}

int main()
{
    f>>T;
    precalc();
    while(T--)
    {
        short int x;
        f>>x>>N>>M;
        if(x==1)
            g<<s[N][M]<<'\n';
        else
            g<<S[N][M]<<'\n';
    }
    return 0;
}
