#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <stack>
#include <queue>

#include <iomanip>

#define int long long

using namespace std;

string filename = "stirling";

#ifdef LOCAL
    ifstream fin("input.in");
    ofstream fout("output.out");
#else
    ifstream fin(filename + ".in");
    ofstream fout(filename + ".out");
#endif

const int NMAX = 200;
const int MOD = 98999;

int dp[NMAX + 1][NMAX + 1];
int Dp[NMAX + 1][NMAX + 1];

signed main(){

    Dp[0][0] = 1;
    for(int i = 1; i <= NMAX; i++){
        for(int j = 1; j <= NMAX; j++){
            Dp[i][j] = (Dp[i - 1][j - 1] + Dp[i - 1][j] * j) % MOD;
        }
    }

    dp[0][0] = 1;
    for(int i = 1; i <= NMAX; i++){
        for(int j = 1; j <= NMAX; j++){
            dp[i][j] = (dp[i - 1][j - 1] - dp[i - 1][j] * (i - 1)) % MOD;
        }
    }

    int T;
    fin >> T;

    while(T--){
        int t, a, b;
        fin >> t >> a >> b;

        if(t == 1){
            fout << dp[a][b] << '\n';
        }else{  
            fout << Dp[a][b] << '\n';
        }
    }

    return 0;
}