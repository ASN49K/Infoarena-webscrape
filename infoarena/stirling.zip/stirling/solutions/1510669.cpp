#include <fstream>
#define N 205
#define M 98999
using namespace std;
int t,n,m,s[205][205],S[205][205],x;

int main()
{
    ifstream f("stirling.in");
    ofstream g("stirling.out");
    s[1][1]=S[1][1]=1;

    for(int i=2;i<=N;i++)
    for(int j=1;j<=i;j++){
            s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j];
            S[i][j]=S[i-1][j-1]+j*S[i-1][j];
            }
    f >> t;
    while(t--){
        f >> x >> n >> m;
        if(x==1) g <<s[n][m] << endl;
        else  g << S[n][m] <<endl;
        }
    return 0;
}
