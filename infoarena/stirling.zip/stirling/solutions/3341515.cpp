#include <iostream>

#define MOD 98999
#define NMAX 201

int main()
{
    int t, x, n, m;
    int s[NMAX][NMAX] = {0};
    int S[NMAX][NMAX] = {0};

    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    s[1][1] = 1;

    for (int i = 2; i < NMAX; ++i)
        for (int j = 1; j <= i; ++j)
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;

    S[1][1] = 1;

    for (int i = 2; i < NMAX; ++i)
        for (int j = 1; j <= i; ++j)
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;

    std::cin >> t;

    for (int i = 0; i < t; ++i) {
        std::cin >> x >> n >> m;

        switch (x) {
        case 1:
            printf("%d\n", s[n][m]);
            break;
        case 2:
            printf("%d\n", S[n][m]);
            break;
        default:
            break;
        }
    }

    return 0;
}
