#include <fstream>

const int MAX_N = 200;
const int MOD = 98999;

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int t, n, m, op;
int s1[MAX_N + 5][MAX_N + 5], s2[MAX_N + 5][MAX_N + 5];

int main() {
    s1[0][0] = s2[0][0] = 1;

    for(int i = 1; i <= MAX_N; i++)
        s1[0][i] = s2[0][i] = 0;

    for(int i = 1; i <= MAX_N; i++)
        for(int j = 1; j <= MAX_N; j++) {
            s1[i][j] = (s1[i - 1][j - 1] - (i - 1) * s1[i - 1][j] % MOD) % MOD;
            s2[i][j] = (s2[i - 1][j - 1] + j * s2[i - 1][j] % MOD) % MOD;
        }

    fin >> t;
    while(t-- ) {
        fin >> op >> n >> m;
        fout << ((op == 1) ? s1[n][m] : s2[n][m]) << '\n';
    }
    return 0;
}
