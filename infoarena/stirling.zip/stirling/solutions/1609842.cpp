#include <iostream>
#include <fstream>
#define MOD 98999
#define NMAX 201
using namespace std;
ifstream in("stirling.in");
ofstream out("stirling.out");
int T, m, n, s[NMAX+1][NMAX+1], S[NMAX+1][NMAX+1], sp, i, j;
int main()
{
    s[1][1]=1;
    for(i=2;i<=NMAX;i++)
        for(j=1;j<=NMAX;j++)
            s[i][j] = (s[i-1][j-1] - (i-1)*s[i-1][j])%MOD;
    S[1][1]=1;
    for(i=2;i<=NMAX;i++)
        for(j=1;j<=NMAX;j++)
            S[i][j] = (S[i-1][j-1] - j*S[i-1][j])%MOD;

    in>>T;
    while(T--)
    {
        in>>sp>>m>>n;
        if(sp==1) out<<s[m][n]<<'\n';
        if(sp==2) out<<S[m][n]<<'\n';
    }
    return 0;
}
