#include<fstream>
using namespace std ;
 
ifstream fin("stirling.in");
ofstream fout("stirling.out");
 
#define mod 98999
#define maxn 201
 
int tst ;
 
int s[maxn][maxn], S[maxn][maxn] ;
 
 
void precalc_s()
{
    s[0][0] = 1 ;
 
    for(int i = 1; i < maxn; ++i )
        for(int j = 1; j < maxn; ++j )
            s[i][j] = ( s[ i - 1 ][ j - 1 ] - ( i - 1 ) * s[ i - 1 ][j] ) % mod ;
}
 
void precalc_S()
{
    S[0][0] = 1 ;
 
    for(int i = 1; i < maxn; ++i )
        for(int j = 1; j < maxn; ++j )
            S[i][j] = ( S[ i - 1 ][ j - 1 ] + j * S[ i - 1 ][j] ) % mod ;
}
 
int main()
{
    precalc_s() ;
 
    precalc_S() ;
 
    fin >> tst ;
 
    while( tst-- )
    {
        int cod, a, b ;
 
        fin >> cod >> a >> b ;
 
        if( cod == 1 )
            fout << s[a][b] << "\n" ;
        else
            fout << S[a][b] << "\n" ;
    }
 
    return 0 ;
}