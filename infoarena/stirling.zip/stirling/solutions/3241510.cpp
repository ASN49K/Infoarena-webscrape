#include <iostream>
#include <fstream>
using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

const int MOD = 98999,
          MAX = 201;
int stir[MAX + 1][MAX + 1];

void setare_zero()
{
    int i, j;
    for(i = 1; i <= MAX; ++i)
        for(j = 1; j <= MAX; ++j)
            stir[i][j] = 0;
}

void stirling1(int n, int k)
{
    int i, j;
    stir[1][1] = 1;
    for(i = 2; i <= n; ++i)
        for(j = 1; j <= i; ++j)
            stir[i][j] = (stir[i - 1][j - 1] - (i - 1) * stir[i - 1][j]) % MOD;
    g << stir[n][k];
}

void stirling2(int n, int k)
{
    int i, j;
    stir[1][1] = 1;
    for(i = 2; i <= n; ++i)
        for(j = 1; j <= i; ++j)
            stir[i][j] = (stir[i - 1][j - 1] + j * stir[i - 1][j]) % MOD;
    g << stir[n][k];
}

int main()
{
    int T, x, n, k;
    f >> T;
    while(T--)
    {
        f >> x >> n >> k;
        setare_zero();
        if(x == 1)
            stirling1(n, k);
        else
            stirling2(n, k);
        g << '\n';
    }
    f.close();
    g.close();
    return 0;
}
