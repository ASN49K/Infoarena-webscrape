#include <fstream>
using namespace std;
ofstream fout("stirling.out");
ifstream fin("stirling.in");
const int NMAX = 205;
const int MOD = 98999;

int T;
int s1[NMAX][NMAX], s2[NMAX][NMAX];

void g1()
{
    s1[0][0] = s1[1][1] = 1;
    for(int i=2; i<=NMAX; i++)
        for(int j=1; j<=i; j++)
          s1[i][j] = (s1[i-1][j-1] - (i - 1) * s1[i-1][j]) % MOD;
}

void g2()
{
    s2[1][1] = s2[2][1] = s2[2][2] = 1;
    for(int i=3; i<=NMAX; i++)
        for(int j=1; j<=i; j++)
            s2[i][j] = (s2[i-1][j-1] + j * s2[i-1][j]) % MOD;
}

int main()
{
    fin >> T;

    g1(), g2();

    for(int i=1, OP, x, y; i<=T; i++)
    {
        fin >> OP >> x >> y;

        if(OP == 1) fout << s1[x][y] << '\n';
        else fout << s2[x][y] << '\n';
    }

    return 0;
}
