Program stirling_numere;
var fi,fo : text;
    i,n,t,x,m : longint;

Procedure speta1(n,m:longint);
var i,j:longint;
    s:array[0..201,0..201] of longint;
begin
     s[1,1]:=1;
     for i:=2 to n do
        for j:=1 to m do s[i,j]:=(s[i-1,j-1]-(i-1)*s[i-1,j]) mod 98999;
     writeln(fo,s[n,m]);
end;

Procedure speta2(n,m:longint);
var i,j:longint;
    s:array[0..201,0..201] of longint;
begin
    s[1,1]:=1;
    for i:=2 to n do
       for j:=1 to m do s[i,j]:=(s[i-1,j-1]+j*s[i-1,j]) mod 98999;
    writeln(fo,s[n,m]);
end;

begin
    assign(fi,'stirling.in'); reset(fi); readln(fi,t);
    assign(fo,'stirling.out'); rewrite(fo);

    for i:=1 to t do begin
                     readln(fi,x,n,m);
                     if x=1 then speta1(n,m)
                            else speta2(n,m);
                     end;
    close(fi); close(fo);
end.
