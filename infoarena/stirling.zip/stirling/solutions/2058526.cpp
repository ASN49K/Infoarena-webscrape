#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");

int n, i, j, m, q, speta, mod=98999;
int s[210][210], S[210][210];

int main () {
	
	s[1][1] = 1;
	S[1][1] = 1;
	for (i = 2; i <= 205; i++)
	{
		for (j = 1; j <= i; j++)
			s[i][j] = (s[i-1][j-1] - (i-1)*s[i-1][j])% mod;
		
		for (j = 1; j <= i; j++)
			S[i][j] = (S[i-1][j-1] + j*S[i-1][j])% mod;
	}
	
	fin >> q;	
	while (q)
	{
		fin >> speta >> n >> m;
		if (speta == 1)	fout << s[n][m] << "\n";
		else fout << s[n][m] << "\n";
		q--;
	}
}
