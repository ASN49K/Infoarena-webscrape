#include <fstream>
#define X 98999
#define Nmax 205
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int T,s[Nmax][Nmax],S[Nmax][Nmax];

void SpetaI(int n)
{
    s[1][1]=1;
    for(int i=2;i<n;++i)
        for(int j=1;j<=i;++j)s[i][j]=( s[i-1][j-1]-(i-1)*s[i-1][j] ) % X;
}
void SpetaII(int n)
{
    S[1][1]=1;
    for(int i=2;i<n;++i)
        for(int j=1;j<=i;++j)S[i][j]=( S[i-1][j-1]+j*S[i-1][j] )% X;
}
int main ()
{
    SpetaI(Nmax);
    SpetaII(Nmax);
    f>>T;
    for(int i=1;i<=T;i++)
    {
        int x,n,m;
        f>>x>>n>>m;
        if(x==1)g<<s[n][m]<<'\n';
           else g<<S[n][m]<<'\n';
    }
    return 0;
}
