#include <iostream>
#include <fstream>
using namespace std;
const int NMAX=200,
          MOD=98999;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int s2[NMAX+1][NMAX+1],s1[NMAX+1][NMAX+1],t,cer,m,n;

void stirling1()
{
    s1[1][1]=1;
    for(int i=2;i<=NMAX;i++)
        for (int j=1;j<=i;j++)
            s1[i][j]=(s1[i-1][j-1]-(i-1)*s1[i-1][j])%MOD;
}

void stirling2()
{
    s2[1][1]=1;
    for(int i=2;i<=NMAX;i++)
        for(int j=1;j<=i;j++)
            s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%MOD;
}


int main()
{
    fin>>t;
    stirling1();
    stirling2();
    while(t--)
    {
        fin>>cer>>n>>m;
        if(cer==1)
            fout<<s1[n][m]<<'\n';
        else
         fout<<s2[n][m]<<'\n';
    }
    return 0;
}
