#include <iostream>
#include <cstdio>

#define mx 205
#define mod 98999

using namespace std;

int S[mx][mx],s[mx][mx] ;

void SpetaI()
{
    s[0][0] = 1 ;
    for ( int i = 1 ; i <= 200 ; i ++ )
        for ( int j = 1 ; j <= i ; j ++ )
            s[i][j] = ( s[i-1][j-1] - (i-1)*s[i-1][j] ) % mod ;
}

void SpetaII()
{
    S[0][0] = 1 ;
    for ( int i = 1 ; i <= 200 ; i ++ )
        for ( int j = 1 ; j <= i ; j ++ )
            S[i][j] = ( S[i-1][j-1] + j*S[i-1][j] ) % mod ;
}

int main()
{
    int t,n,k,tip;
    freopen( "stirling.in" , "r" , stdin ) ;
    freopen( "stirling.out" , "w" , stdout  ) ;
    SpetaI() ;
    SpetaII() ;
    scanf( "%d" , &t ) ;
    for ( ; t ; t -- )
    {
        scanf( "%d %d %d" , &tip , &n , &k ) ;
        if ( tip == 1 )
            printf( "%d\n" , s[n][k] ) ;
        else
            printf( "%d\n" , S[n][k] ) ;
    }
    return 0;
}
