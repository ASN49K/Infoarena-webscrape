#include <stdio.h>
#include <stdio.h>>
#define Mod 98999
using namespace std;
int x , m , n,nr;
int vec[210][210];
int vec2[210][210];

void s_n_m()
{
   for(int i  = 2 ; i <= 200 ; i++)
        for(int j = 1 ; j <= i ; j++)
            vec[i][j] = (vec[i-1][j-1] - (i - 1)*vec[i-1][j])% Mod;
}

void S_n_m()
{
    for(int i = 2 ; i <= 200 ; i++)
        for(int j = 1 ; j <= i  ; j++)
            vec2[i][j] = (vec2[i-1][j-1] + j*vec2[i-1][j])% Mod;
}

int main()
{
   freopen("stirling.in","r",stdin);
   freopen("stirling.out","w",stdout);
   scanf("%d",&nr);
   vec[1][1] = 1;
   vec2[1][1] = 1;
   s_n_m();
   S_n_m();
    for(int i = 0 ; i  < nr ; i++)
    {
        scanf("%d %d %d",&x,&n,&m);
        if(x == 1)
            printf("%d\n",vec[n][m]);
        else
            printf("%d\n",vec2[n][m]);
    }
    return 0;
}
