#include<fstream>
using namespace std;
int n,m,i,j,t,x;
long s[200][200],S[200][200];
int main()
{
	ifstream fin("stirling.in");
	ofstream fout("stirling.out");
	s[0][0]=S[0][0]=1;
	for(i=1;i<=200;i++)
		for(j=1;j<=200;j++)
			s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j],S[i][j]=S[i-1][j-1]+i*S[i-1][j];
	fin>>t;
	for(i=1;i<=t;i++)
	{
		fin>>x>>n>>m;
		if(x==1)
			fout<<s[n][m]<<"\n";
		else
			fout<<S[n][m]<<"\n";
	}
}