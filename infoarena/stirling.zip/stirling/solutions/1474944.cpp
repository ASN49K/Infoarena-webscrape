#include<fstream>
#define mod 98999
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int t,n,m,i,j,sp1[201][201],sp2[201][201],sp;
void speta1()
{
    sp1[1][1]=1;
    for(i=2;i<201;i++)
      for(j=1;j<=i;j++)
        sp1[i][j]=(sp1[i-1][j-1]-(i-1)*sp1[i-1][j])%mod;
}
void speta2()
{
    sp2[1][1]=1;
    for(i=2;i<201;i++)
      for(j=1;j<=i;j++)
        sp2[i][j]=(sp2[i-1][j-1]-j*sp2[i-1][j])%mod;
}
int main()
{
    f>>t;
    speta1();
    speta2();
    while(t--)
    {
        f>>sp>>n>>m;
        if(sp==1)
          g<<sp1[n][m]<<"\n";
        else
          g<<sp2[n][m]<<"\n";
    }
    return 0;
}
