#include <iostream>
#include <cstdio>

#define mod 98999
using namespace std;

int n, m, x, r;
int a[201][201];
int b[201][201];

///s(n,m) = s(n-1,m-1) - (n-1)*s(n-1,m)
/// S(n,m) = S(n-1,m-1) + m*S(n-1,m)
void Form()
{
    a[0][0]=1;
    b[0][0]=1;
    for(int i=1; i<=200; i++)
        for(int j=1; j<=i; j++)
            {
                a[i][j]=(a[i-1][j-1]-((i-1)*a[i-1][j])%mod)%mod;
                b[i][j]=(b[i-1][j-1]+(j*b[i-1][j])%mod)%mod;
            }
}

int main()
{
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);
    scanf("%d\n", &r);
    Form();
    for(int i=0; i<r; i++)
    {
        scanf("%d %d %d\n", &x, &n, &m);
        if(x==1)
            cout<<a[n][m]<<endl;
        else
            cout<<b[n][m]<<endl;
    }
    return 0;
}
