#include <cstdio>

#define Nmax 205
#define MOD 98999
#define FOR(i,a,b) for(int i = (a); i <= (b); ++i)

using namespace std;

int S1[Nmax][Nmax], S2[Nmax][Nmax];



void initialize()
{
    S1[1][1] = S2[1][1] = 1;
    FOR(i,2,Nmax-1)
        FOR(j,1,i)
        {
            S1[i][j] = (S1[i-1][j-1] - (i-1)*S1[i-1][j]) % MOD;
            S2[i][j] = (S2[i-1][j-1] + j*S2[i-1][j]) % MOD;
        }
}

void solve()
{
    int nrt,a,b,op;
    scanf("%d", &nrt);
    for(;nrt--;)
    {
        scanf("%d %d %d", &op, &a, &b);
        op == 1 ? printf("%d\n",S1[a][b]):printf("%d\n",S2[a][b]);
    }
}

int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);

    initialize();
    solve();

    return 0;
}
