#include <fstream>
#define M 98999

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int q,max1,max2;

long long s[201][201],S[201][201];

struct
{
    int ord,n,m;
}test[1001];

void sp2()
{
    for(int i=2;i<=max2;++i)
    {
        for(int j=1;j<=i;++j)
        {
            s[i][j] = (s[i-1][j-1]+ j*s[i-1][j]) %M;
        }
    }
}

void sp1()
{
    for(int i=2;i<=max1;++i)
    {
        for(int j=1;j<=i;++j)
        {
            S[i][j] = (S[i-1][j-1] - (i-1) * S[i-1][j])%M;
        }
    }
}

int main()
{
    f>>q;
    s[1][1]=1;
    S[1][1]=1;
    for(int z=1;z<=q;++z)
    {
        f>>test[z].ord>>test[z].n>>test[z].m;
        if(test[z].ord==1 && test[z].n>max1)max1=test[z].n;
        if(test[z].ord==2 && test[z].n>max2)max2=test[z].n;
    }
    sp2();
    sp1();
    for(int z=1;z<=q;++z)
    {
        if(test[z].ord==1)
        {
            g<<S[test[z].n][test[z].m]<<'\n';
        }
        else
        {
            g<<s[test[z].n][test[z].m]<<'\n';
        }
    }
    return 0;
}
