#include<algorithm>
#include<bitset>
#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<ctime>
#include<deque>
#include<fstream>
#include<iomanip>
#include<iostream>
#include<map>
#include<queue>
#include<set>
#include<stack>
#include<unordered_map>
#include<unordered_set>
#include<utility>
#include<vector>

using namespace std;

#ifdef HOME
const string inputFile = "input.txt";
const string outputFile = "output.txt";
#else
const string problemName = "stirling";
const string inputFile = problemName + ".in";
const string outputFile = problemName + ".out";
#endif

const int MOD = 98999;

int T;
int s[205][205];
int S[205][205];

int main() {
    int i, j, t, n, m;

#ifndef ONLINE_JUDGE
    freopen(inputFile.c_str(), "r", stdin);
    freopen(outputFile.c_str(), "w", stdout);
#endif

    scanf("%d", &T);

    s[0][0] = 1;
    S[0][0] = 1;

    for(i = 1; i <= 200; i++)
        for(j = 1; j <= 200; j++) {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
        }

    while(T--) {
        scanf("%d%d%d", &t, &n, &m);

        if(t == 1)
            printf("%d\n", s[n][m]);
        else
            printf("%d\n", S[n][m]);
    }

    return 0;
}
