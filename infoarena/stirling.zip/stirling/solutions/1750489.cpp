#include<fstream>
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int s1[210][210],i,x,n,k,t,s2[210][210],modulo=98999;
void stirling2(){
   int i,j;
   s2[1][1]=1;
   for (i=2;i<=205;i++)
    for (j=1;j<=i;j++)
       s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%modulo;
}
void stirling1(){
   int i,j;
   s1[1][1]=1;
   for (i=2;i<=205;i++)
    for (j=1;j<=i;j++)
       s1[i][j]=(s1[i-1][j-1]-(i-1)*s1[i-1][j])%modulo;
}
int main(){
    fin>>t;
    stirling1();
    stirling2();
    for (i=1;i<=t;i++)
    {
        fin>>x>>n>>k;
        if (x==1) fout<<s1[n][k]<<'\n';
          else
            fout<<s2[n][k]<<'\n';
    }
    fin.close();
    fout.close();
    return 0;
}
