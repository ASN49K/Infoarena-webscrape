#include <iostream>
#include <fstream>
#include <algorithm>
#include <climits>

std::ifstream f("stirling.in");
std::ofstream g("stirling.out");

using namespace std;
typedef long long int ll;

const int nMax = 1e3 + 5, mod = 98999;

int T;
int cerinta, n, m;
ll st1[nMax][nMax], st2[nMax][nMax];

void init()
{
    st1[0][0] = 1;st2[0][0] = 1;
    for (int i = 1;i <= 205;i++){
        for (int j = 1;j <= 205;j++)st1[i][j] = (st1[i-1][j-1] - (i - 1) * st1[i-1][j] % mod) % mod;
    }

    for (int i = 1;i <= 205;i++){
        for (int j = 1;j <= 205;j++)st2[i][j] = (st2[i-1][j-1] + j * st2[i-1][j] % mod) % mod;
    }
}

void solve1()
{
    g << st1[n][m] << '\n';
}

void solve2()
{
    g << st2[n][m] << '\n';
}

int main()
{
    f >> T;
    init();
    while(T--){
        f >> cerinta >> n >> m;
        (cerinta == 1) ? solve1() : solve2();
    }
}
