#include<fstream>
using namespace std;
ifstream cin("stirling.in");
ofstream cout("stirling.out");
#define MOD 98999
int t,x,n,m,s[205][205],S[205][205];
void spita1(){
    s[1][1]=1;
    for(int i=2;i<=200;++i)
        for(int j=1;j<=i;++j)
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
}
void spita2(){
    S[1][1]=1;
    for(int i=2;i<=200;++i)
        for(int j=1;j<=i;++j)
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
}
signed main(){
    cin>>t;
    spita1();
    spita2();
    while(t--){
        cin>>x>>n>>m;
        if(x==1)
            cout<<s[n][m];
        else
            cout<<S[n][m];
        cout<<'\n';
    }
}
