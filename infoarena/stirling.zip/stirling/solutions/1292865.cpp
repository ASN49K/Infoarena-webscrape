#include<cstdio>
#include<fstream>
#include<iostream>
#include<iomanip>
#include<algorithm>
#include<vector>
#include<bitset>
#include<deque>
#include<queue>
#include<set>
#include<map>
#include<cmath>
#include<cstring>
#include<ctime>
#include<cstdlib>
#include<unordered_map>

#define ll long long
#define pb push_back
#define mp make_pair
#define pii pair<int,int>
#define pll pair<ll,ll>

using namespace std;

const int mod = 98999;
const int nmax = 205;

int i, j, t, op, x, y, s[nmax][nmax], S[nmax][nmax];

int main()
{
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    s[1][1] = S[1][1] = 1;

    for(i = 2; i < nmax; i++)
        for(j = 1; j <= i; j++)
        {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % mod;
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % mod;
        }

    scanf("%d", &t);
    for(; t; t--)
    {
        scanf("%d%d%d", &op, &x, &y);
        printf("%d\n", (op == 1) ? s[x][y] : S[x][y]);
    }

    return 0;
}
