#include <fstream>
#include <vector>
#include <algorithm>
using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");


const int nmax = 200;
const int mmax = 200;

int t;

const int mod = 98999;
int n,m;

int sp1[nmax + 5][nmax + 5];
int sp2[nmax + 5][nmax + 5];

int main()
{
    sp1[1][1]=1;
    for(int i=2;i<=nmax;i++)
        for(int nrc=1;nrc<=i;nrc++)
            sp1[i][nrc] = (sp1[i][nrc] - sp1[i-1][nrc]*(i-1) + sp1[i-1][nrc-1])%mod;
    sp2[1][1]=1;
    for(int i=2;i<=nmax;i++)
        for(int nrsb=1;nrsb<=i;nrsb++)
            sp2[i][nrsb] =(sp2[i][nrsb] + sp2[i-1][nrsb] *nrsb + sp2[i-1][nrsb-1])%mod;
    fin>>t;
    for(int i=1;i<=t;i++){
        int x;
        fin>>x>>n>>m;
        if(x==1)
        {
                fout<<sp1[n][m]<<'\n';
        }
        else
            fout<<sp2[n][m]<<'\n';
    }


}
