#include <stdio.h>

int s[201][201];
int p[201][201];

void calc() {
	int i, j;
	for(i = 0; i <= 200; ++i) {
		s[i][0] = 0;
		s[0][i] = i == 0 ? 1 : 0;
		p[i][0] = 0;
		p[0][i] = i == 0 ? 1 : 0;
	}
	for(i = 1; i <= 200; i++) {
		for(j = 1; j <= 200; j++) {
			s[i][j] = s[i-1][j-1] - (i-1)*s[i-1][j];
			p[i][j] = p[i-1][j-1] - (j)*p[i-1][j];;
		}
	}
}

int main() {

	int x, n, m, t;

	calc();

	freopen("stirling.in", "r", stdin);
	freopen("stirling.out", "w", stdout);

	scanf("%d", &t);

	while(t--) {
		scanf("%d %d %d", &x, &n, &m);
		printf("%d\n", x == 1 ? s[n][m] : p[n][m]);
	}

	fclose(stdout);
	return 0;
}
