#include <iostream>
#include <fstream>

const int MAXN = 200 + 1;
const int MOD = 98999;

using namespace std;

ifstream in("stirling.in");
ofstream out("stirling.out");

int dp_coef[MAXN][MAXN],dp_submultimi[MAXN][MAXN];

void precalculeaza_coeficienti(){
    /// x * (x - 1) * ... * (x - n + 1)
    /// n = 0 => x * (x + 1) ?
    /// nu o sa am termeni pt x^0 dp[i][0] =
    dp_coef[1][1] = 1;
    //dp[0][2] = 1;
    for(int i = 2; i <= MAXN - 1; i++){
        for(int j = 1; j <= MAXN - 1; j++){
            dp_coef[i][j] = -dp_coef[i - 1][j] * (i - 1) + dp_coef[i - 1][j - 1];
            dp_coef[i][j] %= MOD;
        }
    }
}
void precalculeaza_submultimi(){
    /// { ... } n elemente => o impart in { ... } in m submultimi nevide
    /// m = 0 => 0 daca n = 0 => 0
    /// am doua alegeri pt un nou element -> ori il bag in submultimile deja existente
    /// ori il pun intr-o submultime separata
    dp_submultimi[1][1] = 1;
    for(int i = 2; i <= MAXN - 1; i++){
        for(int j = 1; j <= MAXN - 1; j++){
            dp_submultimi[i][j] = dp_submultimi[i - 1][j] * j + dp_submultimi[i - 1][j - 1];
        }
    }
}

int main()
{
    precalculeaza_submultimi();
    precalculeaza_coeficienti();
//    cout<<dp_coef[1][1]<<" "<<dp_coef[3][2];
//    cout<<dp_submultimi[10][3];
    int intrebari;
    in>>intrebari;
    for(int i = 1; i <= intrebari; i++){
        int tip,n,m;
        in>>tip>>n>>m;
        if(tip == 1){
            if(n == 0 && m == 1)
                out<<1<<"\n";
            else
                out<<dp_coef[n][m]<<"\n";
        }
        else
            out<<dp_submultimi[n][m]<<"\n";
    }
    return 0;
}
