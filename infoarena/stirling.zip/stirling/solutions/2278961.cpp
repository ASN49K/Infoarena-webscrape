#include <iostream>
#include <fstream>
using namespace std;
ifstream in("stirlnig.in");
ofstream out("stirling.out");

int t, n, x, m;


int main()
{
    in>>t;
    for(int i=1;i<=t;i++){
        in>>x>>n>>m;
        if(x==1 && n==m){
            out<<1;
        }
    }
}
