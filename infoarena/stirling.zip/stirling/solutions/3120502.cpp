#include<fstream>
using namespace std;
ifstream F("stirling.in");
ofstream G("stirling.out");
int i,j,c,a[201][201],b[201][201];
int main()
{
    for(F>>j;i<201;++i)
        for(a[i][i]=b[i][i]=j=1;j<i;a[j][i]=a[i][j]=(a[i-1][j-1]-(i-1)*a[i-1][j])%98999,b[j][i]=b[i][j]=(b[i-1][j-1]+j*b[i-1][j])%98999,++j);
    for(;F>>c>>i>>j;G<<(c<2?a[i][j]:b[i][j])<<'\n');
    return 0;
}
