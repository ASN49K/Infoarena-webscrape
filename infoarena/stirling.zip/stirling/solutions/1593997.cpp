#include <cstdio>

using namespace std;

FILE *f=fopen("stirling.in","r");
FILE *g=fopen("stirling.out","w");

int t,n,m,x,i,s1[201][201],s2[201][201],j;

int main()
{
    fscanf(f,"%d",&t);

    s1[1][1]=1;
    for (i=2;i<200;i++)
        for (j=1;j<=i;j++)
            s1[i][j]=(s1[i-1][j-1]-(i-1)*s1[i-1][j])%98999;

    s2[1][1]=1;
    for (i=2;i<200;i++)
        for (j=1;j<=i;j++)
            s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%98999;


    for (i=1;i<=t;i++)
    {
        fscanf(f,"%d%d%d",&x,&n,&m);
        if (x==1) fprintf(g,"%d\n",s1[n][m]);
        if (x==2) fprintf(g,"%d\n",s2[n][m]);
    }

    fclose(f);
    fclose(g);
    return 0;
}
