#include <bits/stdc++.h>
#define M 98999

using namespace std;

int test, v[2][202][202];

int main()
{
    ifstream fin ("stirling.in");
    ofstream fout ("stirling.out");
    fin >> test;
    v[0][1][1] = v[1][1][1] = 1;
    for (int i = 2; i <= 200; ++i)
        for (int j = 1; j <= i; ++j)
            v[0][i][j] = (v[0][i-1][j-1] - (i-1)*v[0][i-1][j])%M;
    for (int i = 2; i <= 200; ++i)
        for (int j = 1; j <= i; ++j)
            v[1][i][j] = (v[1][i-1][j-1] + j*v[1][i-1][j])%M;
    while(test--){
        int t, x, y;
        fin >> t >> x >> y;
        if(t == 1)
            fout << v[0][x][y];
        else fout << v[1][x][y];
        fout << "\n";
    }
    fin.close();
    fout.close();
    return 0;
}
