#include <fstream>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

const int n=201;
int t,s[205][205],S[205][205],sp;

int main()
{
    int i,j;
    s[0][0]=s[1][1]=S[0][0]=S[1][1]=1;
    for(i=2;i<n;++i)
        for(j=1;j<=i;++j) s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j], S[i][j]=S[i-1][j-1]+j*S[i-1][j];
    for(f>>t;t;--t)
    {
        f>>sp>>i>>j;
        if(sp==1) g<<s[i][j]<<'\n';
        else g<<S[i][j]<<'\n';
    }
    f.close(); g.close();
    return 0;
}
