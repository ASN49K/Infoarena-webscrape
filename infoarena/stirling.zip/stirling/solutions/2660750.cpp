#include <fstream>
using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

const int NMAX = 201,
          MOD = 98999;

int n, k, t, speta;
int s[NMAX][NMAX], S[NMAX][NMAX];

void speta1(int N)
{
    s[1][1] = 1;
    for(int i = 2; i <= N; i++)
        for(int j = 1; j <= i; j++)
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
}

void speta2(int N)
{
    S[1][1] = 1;
    for(int i = 2; i <= N; i++)
        for(int j = 1; j <= i; j++)
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
}

int main()
{
    speta1(NMAX);
    speta1(NMAX);
    f >> t;
    while(t--)
    {
        f >> speta >> n >> k;
        switch(speta)
        {
        case 1:
        {
            g << s[n][k] << '\n';
            break;
        }
        case 2:
        {
            g << S[n][k] << '\n';
            break;
        }
        }
    }
    f.close();
    g.close();
    return 0;
}
