#include <iostream>
#include <fstream>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int s1[205][205],s2[205][205],mod=98999;
void Precalc()
{ int i,j;
   s1[1][1]=1;
   s2[1][1]=1;

   for(i=2;i<=200;i++)
    for(j=1;j<=i;j++)
     {s1[i][j]=(s1[i-1][j-1]+(i-1)*s1[i-1][j])%mod;
      s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%mod;
     }
}

int main()
{ int i,t,x,y,caz,semn;
   Precalc();
   f>>t;

   for(;t;t--)
   { f>>caz>>x>>y;
      if ((x-y)%2==0) semn=1; else semn=-1;
     if (caz==1) g<<semn*s1[x][y]<<"\n";
      else g<<semn*s2[x][y]<<"\n";
   }

    return 0;
}
