#include <bits/stdc++.h>

using namespace std;

inline void Open(const string Name) {
    #ifndef ONLINE_JUDGE
        (void)!freopen((Name + ".in").c_str(), "r", stdin);
        (void)!freopen((Name + ".out").c_str(), "w", stdout);
    #endif
}

const int MOD = 98999;

int s[201][201], S[201][201];

void PreCompute() {
    s[1][1] = S[1][1] = 1;
    for(int i = 2;i <= 200;i++)
        for(int j = 1;j <= i;j++) {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
        }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    Open("stirling");

    PreCompute();

    int Q;
    cin >> Q;
    while(Q--) {
        int type, x, y;
        cin >> type >> x >> y;
        if(type == 1) cout << s[x][y] << "\n";
        if(type == 2) cout << S[x][y] << "\n"; 
    }
    
    return 0;
}