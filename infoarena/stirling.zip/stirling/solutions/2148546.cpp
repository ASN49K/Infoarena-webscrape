#include <bits/stdc++.h>
using namespace std;
ifstream fin ("stirling.in");
ofstream fout ("stirling.out");
const int Mod = 98999;
const short Nmax = 205;
int Q, dp[Nmax][Nmax] , n , m;


/**
    De speta 1 : numarul de permutari de ordin n cu exact m cicluri
    De speta 2 :numarul de partitionari ale unei submultimi de n elemente in m submultimi nevide
*/


inline void Speta_2()
{
    /**
        dp[i][j] = dp[i - 1][j - 1] + j * dp[i - 1][j]
        Dinamica se explica astfel : ori formam o submultime separata cu numarul j (dp[i - 1][j - 1)
                                    adaugand astfel  inca  o submultime sau inseram numarul j in fiecare dintre
                                    cele j submultimi
    */
    dp[1][1] = 1;
    for(int i = 1 ; i <= n ; i++)
        for(int j = 1 ; j <= i ; j++)
        {
            if(i == 1 && j == 1)
                continue;
            dp[i][j] = (dp[i - 1][j - 1] + 1LL * j * dp[i - 1][j] % Mod) % Mod;
        }
    fout << dp[n][m] << "\n";
}

inline void Speta_1()
{
    /**
        dp[i][j] = dp[i - 1][j - 1] - (i - 1) * dp[i - 1][j]
    */
    dp[1][1] = 1;
    for(int i = 1 ; i <= n ; i++)
        for(int j = 1 ; j <= i ; j++)
        {
            if(i == 1 && j == 1)
                continue;
            dp[i][j] = (dp[i - 1][j - 1] - 1LL * (i - 1) * dp[i - 1][j] % Mod) % Mod;
        }
    fout << dp[n][m] << "\n";
}
int main()
{
    int op;
    fin >> Q;
    while(Q -- )
    {
        fin >> op >> n >> m;
        if(op == 1)
            Speta_1();
        else Speta_2();
        for(int i = 1 ; i <= n ; i++)
            for(int j = 1 ; j <= m ; j++)
                dp[i][j] = 0;
    }

    fin.close();
    fout.close();
    return 0;
}
