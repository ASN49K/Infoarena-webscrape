#include <fstream>

using namespace std;

const int N=205, MOD=98999;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int s[N][N], S[N][N];

int main()
{
    int t, n, m, op, i, j;
    fin>>t;
    s[1][1]=1;
    for(i=2;i<=N;i++)
    {
        for(j=1;j<=i;j++)
        {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
        }
    }
    S[1][1]=1;
    for(i=2;i<=N;i++)
    {
        for(j=1;j<=i;j++)
        {
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
        }
    }
    while(t--)
    {
        fin>>op>>n>>m;
        if(op==1) fout<<s[n][m]<<"\n";
        else fout<<S[n][m]<<"\n";
    }
    fin.close();
    fout.close();
}
