#include <bits/stdc++.h>
#pragma GCC optimize("Ofast,unroll-loops")
#pragma GCC target("sse,avx,fma,avx2,bmi,bmi2,lzcnt,popcnt")

using namespace std;
using ll = long long;

const int MOD = 98999;
const int maxN = 200;

void solve() {

  vector<vector<ll>> s(1 + maxN, vector<ll>(1 + maxN, 0));
  vector<vector<ll>> S(1 + maxN, vector<ll>(1 + maxN, 0));

  s[1][1] = 1, S[1][1] = 1;
  for (int i = 2; i <= maxN; ++i) {
    for (int j = 1; j <= maxN; ++j) {
      s[i][j] = (s[i - 1][j - 1] + s[i - 1][j] * (-i + 1)) % MOD;
      S[i][j] = (S[i - 1][j - 1] + S[i - 1][j] * j) % MOD;
    }
  }

  int t;
  cin >> t;

  for (int type, n, m; t; --t) {
    cin >> type >> n >> m;
    if (type == 1)
      cout << s[n][m] << endl;
    else
      cout << S[n][m] << endl;
  }
}

int main() {
  freopen("stirling.in", "r", stdin);
  freopen("stirling.out", "w", stdout);

  int t = 1;
  // cin >> t;
  while (t--)
    solve();

  return 0;
}
