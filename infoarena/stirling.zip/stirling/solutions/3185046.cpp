#include <fstream>
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");

const int   NMAX=201,
            MOD=98999;
int s[NMAX][NMAX], S[NMAX][NMAX];
int t, x, n, m;

int main() {
    s[1][1] = S[1][1] = 1;
    for(int i = 2; i < NMAX; i++)
        for(int j = 1; j <= i; j++)
            s[i][j] = (s[i - 1][j - 1] - (i-1) * s[i - 1][j]) % MOD;
    for(int i = 2; i < NMAX; i++)
        for(int j = 1; j <= i; j++)
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
    f >> t;
    while(t--) {
        f >> x >> n >> m;
        if(x == 1) g << s[n][m] << '\n';
        else g << S[n][m] << '\n';
    }

    f.close();
    g.close();
    return 0;
}