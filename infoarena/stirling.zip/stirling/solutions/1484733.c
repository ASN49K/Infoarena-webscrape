#include <stdio.h>
#define MAX 201
#define M 98999

int main() {
	int s[MAX][MAX], S[MAX][MAX];
	int i, j;
	
	s[0][0] = 1;
	S[0][0] = 1;
	for(i=1; i<MAX; i++) {
		s[i][0] = 0;
		S[i][0] = 0;
	}
	for(i=1; i<MAX; i++) {
		for(j=1; j<i; j++) {
			s[i][j] = (s[i-1][j-1] - (i - 1) * s[i-1][j]) % M;
			S[i][j] = (S[i-1][j-1] + j * s[i-1][j]) % M;
		}
		s[i][i] = 1;
		S[i][i] = 1;
	}
	
	FILE* fin = fopen("stirling.in", "r");
	int t;
	fscanf(fin, "%d\n", &t);
	int x, n, m;
	FILE* fout = fopen("stirling.out", "w");
	for(i=0; i<t; i++) {
		fscanf(fin, "%d %d %d\n", &x, &n, &m);
		if(x == 1) {
			fprintf(fout, "%d\n", s[n][m]);
		} else {
			fprintf(fout, "%d\n", S[n][m]);
		}
	}
	
	fclose(fin);
	fclose(fout);
	return 0;
}