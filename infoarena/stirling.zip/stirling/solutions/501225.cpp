#include <algorithm>
using namespace std;

#define MOD 98999
#define DIM 205

int s[2][DIM][DIM];
int t,n,m;

void solve ()
{
    int i,j;

    s[0][1][1]=s[1][1][1]=1;
    for (i=2; i<DIM; ++i)
        for (j=1; j<=i; ++j)
        {
            s[0][i][j]=(s[0][i-1][j-1]-(i-1)*s[0][i-1][j])%MOD;
            s[1][i][j]=(s[1][i-1][j-1]+j*s[1][i-1][j])%MOD;
        }
}

void query ()
{
    int i,tip;

    scanf ("%d",&t);
    for (i=1; i<=t; ++i)
    {
        scanf ("%d%d%d",&tip,&n,&m);
        printf ("%d\n",s[tip-1][n][m]);
    }
}

int main ()
{
    freopen ("stirling.in","r",stdin);
    freopen ("stirling.out","w",stdout);

    solve ();
    query ();

    return 0;
}
