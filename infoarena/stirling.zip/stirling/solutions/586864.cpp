#include <stdio.h>

FILE *f,*s;

int i,j,k,l,m,n;

int v1[205][205],v2[205][205];

int main()
{
	f=fopen("stirling.in","r");
	s=fopen("stirling.out","w");
	
	v1[1][1]=1;
	for(i=1;i<=200;i++)
		for(j=2;j<=i;j++)
			v1[i][j]=(v1[i-1][j-1]-(i-1)*v1[i-1][j])%98999;
		
	v2[1][1]=1;
	for(i=1;i<=200;i++)
		for(j=2;j<=i;j++)
			v1[i][j]=(v1[i-1][j-1]+(j*v1[i-1][j]))%98999;	
	
	fscanf(f,"%d",&n);
	
	while(n>0)
	{
		n--;
		
		fscanf(f,"%d %d %d",&i,&j,&k);
		
		if(i==1) fprintf(s,"%d\n",v1[j][k]);
		if(i==2) fprintf(s,"%d\n",v2[j][k]);	
	}	
	
	fclose(s);
	
	return 0;
}