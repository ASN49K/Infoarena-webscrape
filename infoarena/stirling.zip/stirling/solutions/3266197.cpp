#include <bits/stdc++.h>
using namespace std;

const int MOD = 98999;
int t, x, n, m;
int s[3][201][201];

int main() {
    ifstream cin("stirling.in");
    ofstream cout("stirling.out");
    s[1][0][0] = s[2][0][0] = 1;
    for (int i = 1; i <= 200; ++i) {
        for (int j = 1; j <= 200; ++j) {
            s[1][i][j] = (s[1][i - 1][j - 1] - (i - 1) * s[1][i - 1][j] % MOD + MOD) % MOD;
            s[2][i][j] = (s[2][i - 1][j - 1] + j * s[2][i - 1][j] % MOD) % MOD;
        }
    }
    cin >> t;
    while (t--) {
        cin >> x >> n >> m;
        cout << s[x][n][m] << "\n";
    }
}
