        #include <cstdio>
        #include <cstring>
        #define MOD 98999
        using namespace std;
        int a[210][210], b[210][210];
        void speta1 (int n, int m)
        {
            int i, j;
            for (i=1; i<n; i++)
            {
                for (j=1; j<=m; j++)
                {
                    a[i+1][j]=(a[i][j-1]-i*a[i][j])%MOD;
                }
            }
        }
        void speta2 (int n, int m)
        {
            int i, j;
            for (i=2; i<n; i++)
            {
                for (j=1; j<=i; j++)
                {
                    b[i][j]=(b[i-1][j-1]+j*b[i-1][j])%MOD;
                }
            }
        }
        int main()
        {
            int t, x, n, m, i;
            freopen("stirling.in","r",stdin);
            freopen("stirling.out","w",stdout);
            scanf("%d",&t);
            a[1][1]=1; speta1(201,201);
            b[1][1]=1; speta2(201,201);
            for (i=1; i<=t; i++)
            {
                scanf("%d%d%d",&x,&n,&m);
                if (x==1)
                {
                    if (m==0 || n==0) {printf("0\n"); continue;}
                    else if (m==n) {printf("1\n"); continue;}
                    else if (m>n) {printf("0\n"); continue;}
                    printf("%d\n",a[n][m]);
                }
                else if (x==2)
                {
                    if (m==0 || n==0) {printf("0\n"); continue;}
                    else if (m==n || m==1) {printf("1\n"); continue;}
                    else if (m>n) {printf("0\n"); continue;}
                    printf("%d\n",b[n][m]);
                }
            }
            fclose(stdin);
            fclose(stdout);
            return 0;
        }
