#include <fstream>
#define NMAX 201
#define MOD 98999
using namespace std;
ifstream  fin("stirling.in");
ofstream fout("stirling.out");
int s[NMAX][NMAX],S[NMAX][NMAX];

void pre_calculare()
{
    s[1][1]=S[1][1]=1;

    for(int i=2; i<NMAX; i++)
    {
        for(int j=1; j<=i; j++)
        {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
            S[i][j]=(S[i-1][j-1]-j*S[i-1][j])%MOD;
        }
    }
}

int main()
{
    int T,tip,n,m;

    fin>>T;

    pre_calculare();

    for(int i=1; i<=T; i++)
    {
        fin>>tip>>n>>m;

        if(tip==1)
        {
            fout<< s[n][m];
        }
        else
        {
            fout<< S[n][m];
        }
        fout<< "\n";
    }

    return 0;
}
