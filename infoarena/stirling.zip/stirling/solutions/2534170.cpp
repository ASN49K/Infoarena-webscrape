#include<fstream>
using namespace std;

ifstream in("stirling.in");
ofstream out("stirling.out");

const int NMax = 200, MOD = 98999;

int T, x, n, m, DPS[NMax+5][NMax+5], DPs[NMax+5][NMax+5];

int S(int n, int m) {
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            DPS[i][j] = (DPS[i-1][j-1] + j*DPS[i-1][j] % MOD) % MOD;
}

int s(int n, int m) {
     for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            DPs[i][j] = (DPs[i-1][j-1] - (i-1)*DPs[i-1][j] % MOD) % MOD;
}

int main() {
    in >> T;

    DPS[0][0] = 1;
    DPs[0][0] = 1;
    S(NMax,NMax);
    s(NMax,NMax);
    while (T--) {
        in >> x >> n >> m;
        switch(x) {
            case 1: out << DPs[n][m] << '\n';break;
            case 2: out << DPS[n][m] << '\n';break;
        }
    }
}
