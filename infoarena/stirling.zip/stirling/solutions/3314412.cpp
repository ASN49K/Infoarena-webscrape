#include <bits/stdc++.h>

using namespace std;

static constexpr int MAX = 200;

int main() {
  static constexpr int MOD = 98999;
#ifndef LOCAL
  freopen("stirling.in", "r", stdin);
  freopen("stirling.out", "w", stdout);
#endif
  ios::sync_with_stdio(false);
  cin.tie(nullptr);
  static int s[MAX + 1][MAX + 1] = {};
  static int S[MAX + 1][MAX + 1] = {};
  s[0][0] = S[0][0] = 1;
  for (int n = 1; n <= MAX; ++n) {
    for (int m = 1; m <= n; ++m) {
      s[n][m] = (s[n - 1][m - 1] - 1LL * (n - 1) * s[n - 1][m]) % MOD;
    }
  }
  for (int n = 1; n <= MAX; ++n) {
    for (int m = 1; m <= n; ++m) {
      S[n][m] = (S[n - 1][m - 1] + 1LL * m * S[n - 1][m]) % MOD;
    }
  }
  int T;
  if (!(cin >> T)) {
    return 1;
  }
  for (; T--;) {
    int X;
    int N;
    int M;
    if (!(cin >> X >> N >> M)) {
      return 1;
    }
    if (X == 1) {
      cout << s[N][M];
    } else if (X == 2) {
      cout << S[N][M];
    } else {
      return 1;
    }
    cout << '\n';
  }
  return 0;
}