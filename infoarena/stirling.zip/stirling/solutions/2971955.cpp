#include <fstream>

using namespace std;
ifstream cin("stirling.in");
ofstream cout("stirling.out");
int Map1[202][202];
int Map2[202][202];
int const n = 201;
int const mod = 98999;
void ds1()
{
     Map1[1][1] = 1;
     for(int i = 2; i < n; i ++)
     {
          for(int j =1; j <= i; j ++)
          {
              Map1[i][j] = (Map1[i-1][j-1] + (i - 1) *Map1[i-1][j])%mod;
          }
     }
}
void ds2()
{
   Map2[1][1] = 1;
   for(int i = 2; i < n; i ++ )
   {
       for(int j = 1; j <= i; j ++)
       {
            Map2[i][j] = (Map2[i-1][j -1] + j * Map2[i-1][j] )%mod;
       }
   }
}
 int main()
{
    int t;
    cin >> t;
    ds1();
    ds2();
    while(t--)
    {
        int ob , N , M;
        cin >> ob >> N >> M;
        if(ob == 1)
        {
             cout << Map1[N][M] << endl;
        }
        else if(ob == 2)
        {
            cout << Map2[N][M] << endl;
        }
    }
    return 0;
}
