#include <iostream>
#include <fstream>

using namespace std;

int S1[201][201], S2[201][201];

int stirling1(int n, int m)
{

    if(S1[n][m])
        return S1[n][m];

    if( !n || !m )
        return 0;
    if( n<m )
        return 0;
    if( n==1 && m==1 )
        return 1;

    S1[n][m] = stirling1(n - 1, m - 1) - (n - 1) * stirling1(n - 1, m) % 98999;

    return S1[n][m];

}

int stirling2(int n, int m)
{
    if(S2[n][m])
        return S2[n][m];
    if( !n || !m )
        return 0;
    if( n<m )
        return 0;
    if( n==1 && m==1 )
        return 1;
    S2[n][m] = stirling2(n - 1, m - 1) + m * stirling2(n - 1, m) % 98999;
    return S2[n][m];
}

int main()
{

    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    int T, x, n, m;

    scanf("%d", &T);

    //cout<<T;

    for(int i=1;i<=T;++i)
    {
        scanf("%d %d %d", &x, &n, &m);

        if(x == 1)
            cout<<stirling1(n, m)<<"\n";
        else if(x == 2)
            cout<<stirling2(n, m)<<"\n";
    }
    return 0;
}
