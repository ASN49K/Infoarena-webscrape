#include<cstdio>
#include<algorithm>
using namespace std;
struct numar{int a,b,poz;};
numar a1[210],a2[210];
int s1[210],s2[210],n2,n1,t,sol[210];
inline bool cmp(numar x,numar y)
{
    if (x.a<y.a) return true;
    if (x.a>y.a) return false;
    if (x.a==y.a){
                  if (x.b>y.b) return false;
                            else return true;
                    }
}
inline void schimb(int n)
{
    int i;
    for (i=1;i<=n;i++)
        s1[i]=s2[i];
    return;
}
inline void stirling1(int n)
{
    int i,x,y,k;
    for (i=0;i<=n;i++)
    {
        s1[i]=0;
        s2[i]=0;
    }
    k=1;
    s1[0]=1;
    for (x=1;x<=n;x++)
    {
        for (y=1;y<=x;y++)
        {
            s2[y]=s1[y-1]-(x-1)*s1[y];
            if (x==a1[k].a && y==a1[k].b) {
                                          sol[a1[k].poz]=s2[y];
                                          k++;
                                          }
        }
        s1[0]=0;
        schimb(x);
    }
    return;
}
inline void stirling2(int n)
{
    int i,x,y,k;
    for (i=0;i<=n;i++)
    {
        s1[i]=0;
        s2[i]=0;
    }
    k=1;
    s1[0]=1;
    for (x=1;x<=n;x++)
    {
        for (y=1;y<=x;y++)
        {
            s2[y]=s1[y-1]+y*s1[y];
            if (x==a2[k].a && y==a2[k].b) {
                                           sol[a2[k].poz]=s2[y];
                                           k++;
                                          }
        }
        s1[0]=0;
        schimb(x);
    }
    return;
}
inline void afis()
{
    int i;
    for(i=1;i<=t;i++)
        printf("%d\n",sol[i]);
    return;
}
inline void citire()
{
    int k,x,y,l1=0,l2=0,i;
    scanf("%d",&t);
    for (i=1;i<=t;i++)
    {
        scanf("%d",&k);
        if (k==1) {
                    scanf("%d%d",&x,&y);
                    l1++;
                    a1[l1].a=x;
                    a1[l1].b=y;
                    a1[l1].poz=i;
                    if (x>n1) n1=x;
                  }
                else {
                        scanf("%d%d",&x,&y);
                         l2++;
                        a2[l2].a=x;
                        a2[l2].b=y;
                        a2[l2].poz=i;
                        if (x>n2) n2=x;
                    }
    }
    sort(a1+1,a1+l1+1,cmp);
    sort(a2+1,a2+l2+1,cmp);
    return;
}
int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    citire();
    stirling1(n1);
    stirling2(n2);
    afis();
    fclose(stdin);
    fclose(stdout);
    return 0;
}
