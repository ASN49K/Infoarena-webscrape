#include <fstream>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

const int DM = 2e3 + 5, MOD = 98999;

int t,x,n,m;
int speta1[DM][DM], speta2[DM][DM], N;

void s1()
{
    speta1[1][1] = 1;
    for(int i = 2; i <= N; i++)
        for(int j = 1; j <= i; j++)
            speta1[i][j] = (speta1[i - 1][j - 1] - (i - 1) * speta1[i - 1][j]) % MOD;
}

void s2()
{
    speta2[1][1] = 1;
    for(int i = 2; i <= N; i++)
        for(int j = 1; j <= i; j++)
            speta2[i][j] = (speta2[i - 1][j - 1] + j * speta2[i - 1][j]) % MOD;
}

int main()
{
    N = 202;
    s1(); s2();
    
    fin >> t;
    for(int i = 1; i <= t; i++)
    {
        fin >> x >> n >> m;
        if(x == 1) fout << speta1[n][m] << '\n';
        else fout << speta2[n][m] << '\n';
    }
}
