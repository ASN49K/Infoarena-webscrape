#include <bits/stdc++.h>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

const int N=201, MOD=98999;

int s[N][N], S[N][N];



int factorial(int x){
    if(x==0)
        return 1;
    int p=1;
    for(int i=x; i>=2; i--)
        p*=i;
    return p;
}


void Preproces(){
    s[1][1]=1;
    for(int i=1; i<N; i++)
        for(int j=1; j<=i; j++)
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
    S[1][1]=1;

    for( int i=2 ; i<N ; i++ )
		for( int j=1 ; j<=i ; j++ )
			S[i][j]= ( S[i-1][j-1] + j*S[i-1][j] )%MOD;

}

int ss(int n, int m){
    if(n==0 && m==0)
        return 1;
    if(n==0 || m==0)
        return 0;
    return ss(n-1, m-1)-(n-1)*ss(n-1, m);

}

int Ss(int n, int m){

    if(n==m || m==1)
        return 1;
    if(n==0 || m==0)
        return 0;

    return Ss(n-1, m-1)+m*Ss(n-1, m);
    /*double s=0;
    for(int i=0; i<=m; i++){
        int minus1=pow(-1, m-i);
        int ilan=pow(i,n);
        int a=minus1*ilan;

        int fact1 = factorial(m-i);
        int fact2 = factorial(i);
        int b =fact1*fact2;

        s+=a*1./b;
    }
    return int(s);*/

}

int main()
{
    int t, n, m, c;
    f>>t;
    Preproces();
    for(int i=1; i<=t; i++){
        f>>c>>n>>m;
        if(c==1)
            g<<s[n][m];
        else
            g<<S[n][m];


    }
    return 0;
}
