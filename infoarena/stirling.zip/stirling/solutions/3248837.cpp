#include <fstream>

using namespace std;

const int NMAX = 201,
          MOD = 98999;

int s[NMAX][NMAX], S[NMAX][NMAX];

ifstream fin("stirling.in");
ofstream fout("stirling.out");

void generares()
{
    s[1][1] = 1;
    for(int i = 2; i < NMAX; ++i)
        for(int j = 1; j <= i; ++j)
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
}

void generareS()
{
    S[1][1] = 1;
    for(int i = 2; i < NMAX; ++i)
        for(int j = 1; j <= i; ++j)
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
}

int main()
{
    int t, c, n, m;
    generares();
    generareS();
    fin >> t;
    while(t--)
    {
        fin >> c >> n >> m;
        if(c & 1) fout << s[n][m] << '\n';
        else fout << S[n][m] << '\n';
    }
    return 0;
}
