#include <bits/stdc++.h>

using namespace std;

#define ll long long
#define MOD 98999

ll S[210][210],s[210][210];
int t,i,j,x,y,p;

int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    scanf("%d",&t);
    //speta 1
    for (i=1;i<=200;i++){
        s[i][i]=1;
        s[i][1]=i-1;
    }
    s[1][1]=1;
    for (i=1;i<=200;i++)
        for (j=1;j<i;j++)
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j]%MOD)%MOD;
    //speta 2
    for (i=1;i<=200;i++){
        S[i][i]=1;
    }
    for (i=1;i<=200;i++)
        for (j=1;j<i;j++)
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j]%MOD)%MOD;

    while (t){
        t--;
        scanf("%d%d%d",&p,&x,&y);
        if (p==1)
            printf("%lld\n",s[x][y]);
        else printf("%lld\n",S[x][y]);
    }
    return 0;
}
