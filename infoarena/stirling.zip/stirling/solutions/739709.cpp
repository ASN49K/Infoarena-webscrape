
#include <fstream>
using namespace std;

#define NMAX 201
#define MODULO 98999

const char infile[] = "stirling.in";
const char outfile[] = "stirling.out";

typedef int matrix[NMAX][NMAX];

matrix speta1;
matrix speta2;

void precalculate()
{
	speta1[1][1] = 1;
	speta2[1][1] = 1;
	for(int i = 2 ; i < NMAX; i++)
	{
		for(int j = 1 ; j <= i; j++)
		{
			speta1[i][j] = speta1[i - 1][j - 1] - (i - 1) * speta1[i - 1][j] % MODULO;
			speta2[i][j] = speta2[i - 1][j - 1] + j * speta2[i - 1][j] % MODULO;
		}
	}
}

void answer()
{
	int questionCount;
	int type;
	int n;
	int m;

	matrix *p[2];
	p[0] = &speta1;
	p[1] = &speta2;

	fstream fin(infile, ios::in);
	fstream fout(outfile, ios::out);

	fin >> questionCount;

	for(int i = 0 ; i < questionCount; i++)
	{

		fin >> type
			>> n
			>> m;

		fout << (*p[type -1])[n][m] << "\n";
	}

	fin.close();
	fout.close();

}


int main(int argc, char* argv[])
{
	precalculate();
	answer();
}