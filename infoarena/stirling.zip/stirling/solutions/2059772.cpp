#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
int x,m,n,t,s[201][201],S[201][201],maxn1,maxn2,maxm1,maxm2;
int main()
{
    fin>>t;
    for(int i=0;i<=200;i++)
            for(int j=0;j<=201;j++)
                s[i][j]=1,S[i][j]=1;
    for(int l=1;l<=t;l++)
    {
        fin>>n>>m>>x;
        if(x==1)
        {
            if(n>maxn1||m>maxm1)
            {
                maxn1=max(maxn1,n);
                maxm1=max(maxm1,m);
                for(int i=1;i<=maxn1;i++)
                {
                    for(int j=1;j<=maxm1;j++)
                    {
                        s[i][m]=s[i-1][j-1]-(s[i-1][j]*n);
                    }
                }
            }
            fout<<s[n][m]<<"\n";
        }
        if(x==2)
        {
            if(n>maxn2||m>maxm2)
            {
                maxn2=max(maxn2,n);
                maxm2=max(maxm2,m);
                for(int i=1;i<=maxn1;i++)
                {
                    for(int j=1;j<=maxm1;j++)
                    {
                        S[i][m]=S[i-1][j-1]+(s[i-1][j]*n);
                    }
                }
            }
            fout<<S[n][m]<<"\n";
        }
    }
    return 0;
}
