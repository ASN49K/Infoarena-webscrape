#include <bits/stdc++.h>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int n,i,j,x,m,t;
int stir1[205][205];
int stir2[205][205];

int stirling1(int n, int k)
{
    int i,j;
    stir1[0][0] = 1;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= min(i, k); j++)
            stir1[i][j] = stir1[i - 1][j - 1] - (i - 1) * stir1[i - 1][j],stir1[i][j]=stir1[i][j]%98999;
    return stir1[n][k];
}

int stirling2(int n, int k)
{
    int i,j;
    stir2[0][0] = 1;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= min(i, k); j++)
            stir2[i][j] = stir2[i - 1][j - 1] + j* stir2[i - 1][j],stir2[i][j]=stir2[i][j]%98999;
    return stir2[n][k];
}

int main()
{
    f>>t;
    stirling1(200,200);
    stirling2(200,200);
    for(i=1;i<=t;i++)
    {
        f>>x>>n>>m;
        if(x==1)
        {
            g<<stir1[n][m]<<'\n';
        }
        else
        {
            g<<stir2[n][m]<<'\n';
        }
    }


    return 0;
}
