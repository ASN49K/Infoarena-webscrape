#include<bits/stdc++.h>
using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

const int MOD=98999;
const int NMAX=205;

int t,x,n,k,dp[NMAX][NMAX],dp1[NMAX][NMAX];

int main()
{
    int i,j;
    dp1[0][0]=1;
    for (i=1;i<NMAX;i++) dp[i][1]=dp[i][i]=1;
    //speta II
    for (i=2;i<NMAX;i++)
        for (j=2;j<i;j++)
            dp[i][j]=(dp[i-1][j-1]+j*dp[i-1][j])%MOD;
    //speta I
    for (i=1;i<NMAX;i++)
        for (j=1;j<NMAX;j++)
            dp1[i][j]=(dp1[i-1][j-1]-(i-1)*dp1[i-1][j])%MOD;
    fin>>t;
    while (t--)
        {
            fin>>x>>n>>k;
            if (x==1) fout<<dp1[n][k]<<"\n";
            else fout<<dp[n][k]<<"\n";
        }
    return 0;
}
