#include <iostream>
using namespace std;

int s[202][202],S[202][202],t;
const int MOD = 98999;
void preprocess(int n){
	for(int i = 2; i <= n; i++){
		for(int j = 1; j <= i; j++)
		s[i][j] = (s[i - 1][j - 1] - (i - 1) *  s[i - 1][j]) % MOD;
	}
	for(int i = 2; i <= n; i++){
		for(int j = 1; j <= i; j++)
		S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
	}
}
int main(){
	freopen("stirling.in","r",stdin);
	freopen("stirling.out","w",stdout);
	scanf("%d",&t);
	s[1][1] = 1;
	S[1][1] = 1;
	preprocess(200);
	for(int i = 0; i < t; i++){
		int x,n,m;
		scanf("%d%d%d",&x,&n,&m);
		if(x == 1)
			printf("%d\n",s[n][m]);
		else
			printf("%d\n",S[n][m]);
	}
	return 0;
}