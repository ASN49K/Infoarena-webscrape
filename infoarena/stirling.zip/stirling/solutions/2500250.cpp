// Se definesc numerele lui Stirling de speţa I, s(n,m), ca fiind coeficienţii dezvoltării
// x(x-1)...(x-n+1). Similar, se definesc numerele lui Stirling de speţa a II-a, S(n,m),
// ca fiind numărul de partiţionări ale unei mulţimi de n elemente în m submulţimi nevide.
// Pentru n şi m date, să se calculeze una dintre cele 2 funcţii, s(n,m) sau S(n,m).
// CAIET: Numerele lui Stirling

#include <iostream>
#include <fstream>

using namespace std;

ifstream fin ("stirling.in");
ofstream fout ("stirling.out");

const int MAX = 205, MOD = 98999;
int T;
int s[MAX][MAX], S[MAX][MAX];

void precalculare() { // construim matricea triunghiulara
    int i, j;

    s[1][1] = S[1][1] = 1;

    for (i = 2; i <= 200; i++)
        for (j = 1; j <= i; j++) {
            s[i][j] = (s[i - 1][j - 1] - s[i - 1][j] * (i - 1)) % MOD;
            S[i][j] = (S[i - 1][j - 1] + S[i - 1][j] * j) % MOD;
        }
}

int main() {
    int i, x, n, m;

    precalculare();

    fin >> T;
    for (i = 1; i <= T; i++) {
        fin >> x >> n >> m;
        if (x == 1)
            fout << s[n][m] << '\n';
        else
            fout << S[n][m] << '\n';
    }

    fin.close();
    fout.close();

    return 0;
}
