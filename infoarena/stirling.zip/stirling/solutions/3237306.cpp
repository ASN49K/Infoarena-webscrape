#include<fstream>
using namespace std;
ifstream F("stirling.in");
ofstream G("stirling.out");
int n=98999,i,j,k,s[2][201][201];
int main()
{
    for(s[0][0][0]=s[1][0][0]=i=1;i<201;++i)
        for(j=1;j<201;s[0][i][j]=(s[0][i-1][j-1]-(i-1)*s[0][i-1][j])%n,s[1][i][j]=(s[1][i-1][j-1]+j*s[1][i-1][j])%n,++j);
    for(F>>i;F>>i>>j>>k;G<<s[i-1][j][k]<<'\n');
    return 0;
}
