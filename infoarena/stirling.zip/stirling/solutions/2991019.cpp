#include <fstream>
#define ll long long
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
ll n,m,t,x,y,z;
const ll mod=98999;
ll s[202][202],S[202][202];
int main()
{
    f>>t;
    s[1][1]=S[1][1]=1;
    for(int i=2;i<=200;i++)
        for(int j=1;j<=i;j++)
        {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%mod;
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%mod;
        }
    while(t--)
    {
        f>>x>>y>>z;
        if(x==1)
            g<<s[y][z];
        else
            g<<S[y][z];
        g<<'\n';
    }
    return 0;
}
