#include <bits/stdc++.h>
#define MOD 98999

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int T,n,m;
int s[205][205],S[205][205];

void Speta_1()
{
    int i,j;
    s[1][1]=1;
    for(i=2;i<=200;i++)
        for(j=1;j<=i;j++)
            s[i][j]=(1LL*s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
}

void Speta_2()
{
    int i,j;
    S[1][1]=1;
    for(i=2;i<=200;i++)
        for(j=1;j<=i;j++)
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
}


int main()
{
    int speta;
    fin>>T;
    Speta_1();
    Speta_2();

    while(T--)
    {
        fin>>speta>>n>>m;
        if(speta==1)fout<<s[n][m]<<"\n";
        else fout<<S[n][m]<<"\n";
    }
    return 0;
}
