#define MOD 98999
#define MAX_SZ 200

#include <fstream>
using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

// I[i][j] = i paranteze, coeficientul lui x^j
int I[MAX_SZ + 1][MAX_SZ + 1];

// S[i][j] = i elemente, j submultimi nevide care formeaza o partitie
int S[MAX_SZ + 1][MAX_SZ + 1];

int main()
{
	I[1][0] = 0;
	
	I[1][1] = 1 % MOD;
	
	for (int i = 2; i < (MAX_SZ + 1); ++i)
	{
		I[i][0] = 0;
		
		for (int j = 1; j < i; ++j)
		{
			I[i][j] = (I[i - 1][j - 1] - I[i - 1][j] * (i - 1)) % MOD;
		}
		
		I[i][i] = 1 % MOD;
	} 
	
	S[1][1] = 1 % MOD;
	
	
	for (int i = 2; i < (MAX_SZ + 1); ++i)
	{
		S[i][1] = 1 % MOD;
		
		for (int j = 2; j < i; ++j)
		{
			S[i][j] = 0;
			
			for (int k = 0; (i - k) >= (j - 1); ++k)
			{
				S[i][j] += S[i - k][j - 1];
				
				S[i][j] %= MOD;
			}
		}
		
		S[i][i] = 1 % MOD;
	}
	
	int T;
	
	fin >> T;
	
	while ((--T) >= 0)
	{
		int x, n, m;
		
		fin >> x >> n >> m;
		
		if (x == 1)
		{
			fout << I[n][m] << '\n';
		}
		
		if (x == 2)
		{
			fout << S[n][m] << '\n';
		}
	}
	
	fin.close();
	fout.close();
	return 0;
}
