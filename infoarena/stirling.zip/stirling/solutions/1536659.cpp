#include <fstream>

using namespace std;

ifstream InF ("stirling.in");
ofstream OutF ("stirling.out");

const int N = 201;
const int MOD = 98999;

int s[N][N], S[N][N];
int t, x, n, m;

int i, j;

void solve1 ()
{
    s[1][1] = 1;
    for (i=2; i<N; ++i)
        for (j=1; j<=i; ++j)
            s[i][j] = (s[i-1][j-1] - (i-1)*s[i-1][j]) % MOD;
}

void solve2 ()
{
    S[1][1] = 1;
    for (i=2; i<N; ++i)
        for (j=1; j<=i; ++j)
            S[i][j] = (S[i-1][j-1] + j*S[i-1][j]) % MOD;
}

int main()
{
    solve1 ();
    solve2 ();
    InF >> t;
    while (t--)
    {
        InF >> x >> n >> m;
        if (x == 1)
            OutF << s[n][m] << "\n";
        if (x == 2)
            OutF << S[n][m] << "\n";
    }
    return 0;
}
