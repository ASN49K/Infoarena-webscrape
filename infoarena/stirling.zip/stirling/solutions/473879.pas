program p5;
var n,i,m,x,t:longint;f,g:text;
function s1(n,m:longint):longint;
begin
    if (m=1)or(n=m) then s1:=1
                    else s1:=s1(n-1,m-1)-(n-1)*s1(n-1,m);
    end;
function s2(n,m:longint):longint;
begin
    if (m=1)or(n=m) then s2:=1
                    else s2:=s2(n-1,m-1)+m*s2(n-1,m);
    end;
begin
   assign(f,'stirling.in');reset(f);
   assign(g,'stirling.out');rewrite(g);
     readln(f,t);
     for i:=1 to t do begin
      readln(f,x,n,m);
       if x=1 then writeln(g,s1(n,m))
              else writeln(g,s2(n,m));
    end;
     close(f);close(g);
   end.
