#include <stdio.h>
#include <stdlib.h>

#define N 201

void det_s(int **s)
{
	int i, j;
	s[1][1] = 1;
	for (i = 2; i < N; i++)
		for (j = 1; j <= i; j++)
			s[i][j] = s[i - 1][j - 1] - (i - 1) * s[i - 1][j];
}

void det_S(int **S)
{
	int i, j;
	S[1][1] = 1;
	for (i = 2; i < N; i++)
		for (j = 1; j <= i; j++)
			S[i][j] = S[i - 1][j - 1] + j * S[i - 1][j];
}

int main()
{
	int t, n, m, i, x;
	FILE *f, *g;

	int **s = (int **)malloc(sizeof(int *) * N);
	for (i = 0; i < N; i++)
		s[i] = (int *)malloc(sizeof(int) * N);

	det_s(s);

	int **S = (int **)malloc(sizeof(int *) * N);
	for (i = 0; i < N; i++)
		S[i] = (int *)malloc(sizeof(int) * N);
	
	det_S(S);

	f = fopen("stirling.in", "r");
	g = fopen("stirling.out", "w");

	fscanf(f, "%d", &t);
	for (i = 0; i < t; i++)
	{
		fscanf(f, "%d %d %d", &x, &n, &m);
		if (x == 1) fprintf(g, "%d\n", s[n][m]);
		else fprintf(g, "%d\n", S[n][m]);
	}

	fclose(f);
	fclose(g);

	return 0;
}

