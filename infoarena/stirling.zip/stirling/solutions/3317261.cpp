/*
          _____                            _____                           _______
         /\    \                          /\    \                         /::\    \
        /::\____\                        /::\    \                       /::::\    \
       /:::/    /                       /::::\    \                     /::::::\    \
      /:::/    /                       /::::::\    \                   /::::::::\    \
     /:::/    /                       /:::/\:::\    \                 /:::/~~\:::\    \
    /:::/    /                       /:::/__\:::\    \               /:::/    \:::\    \
   /:::/    /                       /::::\   \:::\    \             /:::/    / \:::\    \
  /:::/    /      _____            /::::::\   \:::\    \           /:::/____/   \:::\____\
 /:::/____/      /\    \          /:::/\:::\   \:::\    \         :::    |     |:::|    |
|:::|    /      /::\____\        /:::/  \:::\   \:::\____\        |:::|____|     |:::|    |
|:::|____\     /:::/    /        \::/    \:::\  /:::/    /         \:::\    \   /:::/    /
 \:::\    \   /:::/    /          \/____/ \:::\/:::/    /           \:::\    \ /:::/    /
  \:::\    \ /:::/    /                    \::::::/    /             \:::\    /:::/    /
   \:::\    /:::/    /                      \::::/    /               \:::\__/:::/    /
    \:::\__/:::/    /                       /:::/    /                 \::::::::/    /
     \::::::::/    /                       /:::/    /                   \::::::/    /
      \::::::/    /                       /:::/    /                     \::::/    /
       \::::/    /                       /:::/    /                       \::/____/
        \::/____/                        \::/    /                         ~~
         ~~                               \/____/

*/
#include <bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define ins(x) insert(x)
#define mp(x,y) make_pair(x,y)
#define pb(x) push_back(x)
#define fast_ios ios_base::sync_with_stdio(0),cin.tie(nullptr),cout.tie(nullptr);
#define all(v) (v).begin() , (v).end()

using namespace std;

ifstream fin ( "stirling.in" ) ;
ofstream fout ( "stirling.out" ) ;

ll nxt()
{
ll x;
fin >> x ;
return x;
}
void close_files()
{
fin.close();
fout.close();
}

ll s[205][205];
ll S[205][205];

signed main()
{
    fast_ios
    ll p;
    fin >> p ;
    s[0][0]=S[0][0]=1;
    for ( ll i = 1 ; i <= 200 ; ++ i )
        for ( ll j = 1 ; j <= i ; ++ j )
        {
        S[i][j] = S[i-1][j-1] + 1LL*j*s[i-1][j];
        s[i][j] = s[i-1][j-1] - 1LL*( i - 1 ) * s[i-1][j];
        }

    while ( p -- )
    {
    ll x , n , m ;
    fin >> x >> n >> m;
    if ( x == 1 )
        fout << s[n][m] << '\n';
    else
        fout << S[n][m] << '\n';

    }

    close_files();
    return 0;
}
