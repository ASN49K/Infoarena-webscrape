#include <fstream>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

const int mod = 98999;
int N, i;
int type, n, m;
int s[201][201], S[201][201];

void genereaza()
{
    int i, j;
    S[1][1] = s[1][1] = 1;
    for (i = 2; i <= 200; i++)
        for (j = 1; j <= i; j++)
            s[i][j] = (s[i-1][j-1] - (i-1) * s[i-1][j])%mod;

    for (i = 2; i <= 200; i++)
        for (j = 1; j <= i; j++)
            S[i][j] = (S[i-1][j-1] + j * S[i-1][j])%mod;
}

int main()
{
    genereaza();
    f >> N;
    for (i = 1; i <= N; i++)
    {
        f >> type >> n >> m;
        if (type == 1)
            g << s[n][m] << "\n";
        else
            g << S[n][m] << "\n";
    }

    return 0;
}
