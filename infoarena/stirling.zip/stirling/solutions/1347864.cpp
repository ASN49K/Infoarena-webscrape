#include <fstream>
#define NMax 201

using namespace std;

const int mod = 98999;

ifstream in("stirling.in");
ofstream out("stirling.out");

int s[NMax][NMax],S[NMax][NMax];

int main()
{
    int n, m, i, j,a ,b ,c;

    in >> n;

    s[0][0] = 1;

    for(i = 1; i < NMax; i ++)
        for(j = 1; j < NMax; j ++)
            s[i][j] = (s[i-1][j-1] + j*s[i-1][j]) % mod;

    S[0][0] = 1;

    for(i = 1; i < NMax; i ++)
        for(j = 1; j < NMax; j ++)
            S[i][j] = (S[i-1][j-1] - (i-1) * S[i-1][j] % mod) % mod;

    while(n --)
    {
        in >> a >> b >> c;

        if(a == 1)
        {
            out << S[b][c];
        }
        else
        {
            out << s[b][c];
        }
        out << endl;
    }
    return 0;
}
