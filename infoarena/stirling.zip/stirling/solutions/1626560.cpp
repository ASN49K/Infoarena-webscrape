#include<fstream>
using namespace std;

ifstream in("stirling.in");
ofstream out("stirling.out");
int N;
int s[210][210], S[210][210];
int T;
int main()
{
	s[1][1] = 1;
	for (int i = 2;i <= 201;++i)
		for (int j = 1;j <= i;++j)
			s[i][j] = (s[i - 1][j - 1] - (i - 1)*s[i-1][j])% 98999;
	S[1][1] = 1;
	for (int i = 2;i <= 201;++i)
		for (int j = 1;j <= i;++j)
			S[i][j] = (S[i - 1][j - 1] + j*S[i-1][j])%98999;

	in >> T;

	while (T--)
	{
		int x, a, b;
		in >> x >> a >> b;
		if (x == 1)
			out << s[a][b] << '\n';
		else
			out << S[a][b] << '\n';
	}



	return 0;
}