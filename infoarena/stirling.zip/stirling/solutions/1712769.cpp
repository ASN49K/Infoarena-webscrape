#include <fstream>
#define MOD 98999
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int i,j,k,t,s[210][210],S[210][210];
int main()
{
    S[0][0]=s[0][0]=S[1][1]=s[1][1]=1;
    for(i=2;i<=200;i++)
    {
        S[i][1]=1;
        s[i][1]=(s[i-1][1]*(1-i))%MOD;
        for(j=2;j<=i;j++)
        {
            S[i][j]=(s[i-1][j-1]+j*S[i-1][j])%MOD;
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
        }


    }
    f>>t;
    for(;t;t--)
    {
        f>>k>>i>>j;
        if(k==1)
            g<<s[i][j]<<'\n';
        else
            g<<S[i][j]<<'\n';
    }
    return 0;
}
