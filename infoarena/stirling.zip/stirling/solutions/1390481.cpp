#include <fstream>
#define DIM 205
#define MOD 98999

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int s[DIM][DIM], S[DIM][DIM];
int t, n, m, x;

void preprocessKindOne(){
    s[1][1] = 1;

    for(int i = 2; i <= DIM - 4; i ++)
    {
        for(int j = 1; j <= i; j ++)
        {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
        }
    }

}

void preprocessKindTwo(){
    S[1][1] = 1;

    for(int i = 2; i <= DIM - 4; i ++)
    {
        for(int j = 1; j <= i; j ++)
        {
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
        }
    }

}

int main()
{
    fin >> t;
    preprocessKindOne();
    preprocessKindTwo();
    while(t--)
    {
        fin >> x >> n >> m;

        if(x == 1)
        {
            fout << s[n][m] << '\n';
        }
        else
        {
            fout << S[n][m] << '\n';
        }
    }
    return 0;
}

