#include<fstream>
using namespace std;

ifstream in("stirling.in");
ofstream out("stirling.out");

const int NMax = 1000;

int T, x, n, m, DPS[NMax+5][NMax+5], DPs[NMax+5][NMax+5];

int S(int n, int m) {
    if (n < 0 || m < 0)
        return 0;
    if (DPS[n][m])
        return DPS[n][m];
    DPS[n][m] = (S(n-1,m-1) + m*S(n-1,m));
        return DPS[n][m];
}

int s(int n, int m) {
    if (n < 0 || m < 0)
        return 0;
    if (DPs[n][m])
        return DPs[n][m];
    DPs[n][m] = (s(n-1,m-1) - (n-1)*s(n-1,m));
        return DPs[n][m];
}

int main() {
    in >> T;

    DPS[0][0] = 1;
    DPs[0][0] = 1;
    while (T--) {
        in >> x >> n >> m;
        switch(x) {
            case 1: out << s(n,m) << '\n';break;
            case 2: out << S(n,m) << '\n';break;
        }
    }
}
