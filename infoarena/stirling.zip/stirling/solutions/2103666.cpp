#include<fstream>
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
const int NMAX = 201, MODULE = 98999;
int s[NMAX][NMAX], S[NMAX][NMAX];

inline void getStirling(){

    s[0][0] = S[0][0] = 1;

    int n, m;
    for(n = 1; n < NMAX; ++n)
        for(m = 1; m <= n; ++m){
            s[n][m] = (s[n-1][m-1] - (n - 1) * s[n-1][m]) % MODULE;
            S[n][m] = (S[n-1][m-1] + m * S[n-1][m]) % MODULE;
        }

}

inline void solve(){

    int n, m, kind, nrQuestions;

    fin >> nrQuestions;
    while(nrQuestions--){

        fin >> kind >> n >> m;
        if(kind == 1)
            fout << s[n][m] << '\n';
        else
            fout << S[n][m] << '\n';
    }
}
int main(){
    getStirling();
    solve();
}
