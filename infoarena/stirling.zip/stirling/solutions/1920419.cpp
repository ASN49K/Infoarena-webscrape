#include <iostream>
#include <fstream>

#define mod 98999

using namespace std;

long long v[205][205];
long long v1[205][205];

void speta1()
{
    for(int i=0; i<=201; ++i)
        v[i][i]=1;

    for(int i=1; i<=201; ++i)
        for(int j=1; j<=201; ++j)
            v[i][j]=((1-i)*v[i-1][j]+v[i-1][j-1])%mod;

}

void speta2()
{
    for(int i=0; i<=201; ++i)
    {
        v1[i][i]=i;
        v1[1][i]=1;
    }

    for(int i=2; i<=201; ++i)
        for(int j=2; j<=201; ++j)
            v1[i][j]=(v1[i-1][j]*v1[i-2][j-1]+v1[i-1][j-1])%mod;


}

int main()
{
    ifstream f("stirling.in");
    ofstream g("stirling.out");

    int T, x, n, m;

    f>>T;

    speta1();
    speta2();

    while(T)
    {
        f>>x>>n>>m;

        if(x==1)
        {
            g<<v[n][m]<<"\n";
        }

        else
        {
            g<<v1[n][m]<<"\n";

        }

        T--;
    }

    return 0;
}
