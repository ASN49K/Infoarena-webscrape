#include <fstream>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");


int speta1(int n,int m)
{
    if(n==0 || m==0 || n<m) return 0;
    if(n==1 && m==1) return 1;
    return speta1(n-1,m-1)-(n-1)*speta1(n-1,m);
}

int speta2(int n, int m)
{
    if(n==0 || m==0 || n<m) return 0;
    if(n==1 && m==1) return 1;
    return speta2(n-1,m-1)+m*speta2(n-1,m);
}

int main()
{
    int x,n,m;
    short int t;
    f>>t;
    while(t)
    {
        f>>x>>n>>m;
        if(x==1) g<<speta1(n,m);
        else g<<speta2(n,m);
        if(t>1) g<<'\n';
        t--;
    }
    return 0;
}
