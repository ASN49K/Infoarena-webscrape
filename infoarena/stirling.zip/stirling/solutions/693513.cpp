#include <fstream>

using namespace std;

const char InFile[]="stirling.in";
const char OutFile[]="stirling.out";
const int MaxN=202;
const int MOD=98999;

ifstream fin(InFile);
ofstream fout(OutFile);

int T,s[MaxN][MaxN],S[MaxN][MaxN],ts,n,m;

int main()
{
	s[1][1]=1;
	S[1][1]=1;
	for(register int i=2;i<MaxN;++i)
	{
		for(register int j=1;j<MaxN;++j)
		{
			s[i][j]=s[i-1][j-1]-s[i-1][j]*(i-1);
			s[i][j]%=MOD;
			S[i][j]=S[i-1][j-1]+S[i-1][j]*j;
			S[i][j]%=MOD;
		}
	}
	
	fin>>T;
	for(register int i=1;i<=T;++i)
	{
		fin>>ts>>n>>m;
		if(ts==1)
		{
			fout<<s[n][m]<<"\n";
		}
		else
		{
			fout<<S[n][m]<<"\n";
		}
	}		
	fin.close();
	fout.close();
	return 0;
}
