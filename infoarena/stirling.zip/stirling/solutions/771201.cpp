#include <stdio.h>
#define MOD 98999
#define int64 long long int

using namespace std;
int64 s2[201][201];
int64 s1[201][201];

void print_(int64 val) {
    printf("%lld\n", val);
}

void read_() {
    int n, op, x, y; 
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d%d%d", &op, &x, &y);
        if (op == 1) {
            print_(s1[x][y]);   
        } else {
            print_(s2[x][y]);       
        }
    }     
}

void init_() {  
    s1[1][1] = 1;
    s2[1][1] = 1;   
    for (int i = 2; i <= 200; i++) {
        for (int j = 1; j <= i; j++) {
            s1[i][j] = (s1[i - 1][j - 1] - (((i - 1) * s1[i - 1][j]) % MOD)) % MOD;
            s2[i][j] = (s2[i - 1][j - 1] + ((j * s2[i - 1][j]) % MOD)) % MOD;
        }
    }    
}

int main() {
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);
    
    init_();
    read_();
    
    return 0;
}
