#include<cstdio>
#define Nmax 201
#define MOD 98999


int T,speta;
int s[Nmax][Nmax],S[Nmax][Nmax];

void Precalculare_s()
{
    s[1][1]=1;
    for(int i=2;i<Nmax;++i)
        for(int j=1;j<=i;++j)
            s[i][j]=(s[i-1][j-1]- (i-1)*s[i-1][j])%MOD;
}

void Precalculare_S()
{
    S[1][1]=1;
    for(int i=2;i<Nmax;++i)
        for(int j=1;j<=i;++j)
            S[i][j]=(S[i-1][j-1] + j*S[i-1][j])%MOD;
}

int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    Precalculare_s();
    Precalculare_S();
    scanf("%d",&T);
    int x,y;
    for(int i=0;i<T;++i)
    {
        scanf("%d %d %d",&speta,&x,&y);
        if(speta==1)
            printf("%d\n",s[x][y]);
        else
            printf("%d\n",S[x][y]);
    }
    return 0;
}
