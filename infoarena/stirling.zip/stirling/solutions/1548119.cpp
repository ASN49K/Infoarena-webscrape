#include <bits/stdc++.h>
#define mod 98999
#define maxN 202
using namespace std;
int n, x, y, z, t;
int s[maxN][maxN], S[maxN][maxN];
void dp()
{
    int i, j;
    s[1][1] = S[1][1] = 1;
    for (i = 2;i <= maxN; ++ i)
    for (j = 1;j <= i; ++ j)
    {
        s[i][j] = (s[i - 1][j -1] - (i - 1) * s[i - 1][j]) % mod;
        S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % mod;
    }
}
void read()
{
    freopen("stirling.in", "r", stdin);
    scanf("%d", &t);
}
void write()
{
    freopen("stirling.out", "w", stdout);
     while (t --)
    {
        scanf("%d %d %d", &x, &y, &z);
        if (x == 1)
            printf("%d\n", s[y][z]);
        else
        printf("%d\n", S[y][z]);
    }
}
int main()
{
    read();
    dp();
    write();
    return 0;
}
