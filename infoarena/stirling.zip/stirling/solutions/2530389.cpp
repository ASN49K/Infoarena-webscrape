#include <iostream>
#include <bits/stdc++.h>
#define ll long long int
#define pb push_back
using namespace std;
int n,m,i,j;
vector<int> v,activ(10,0),ans(12,0);
int s[205][205],S[205][205];
void Construire()
{
    for(i=0;i<=201;i++)
    {
        s[i][0]=S[i][0]=0;
    }
    for(i=1;i<=201;i++)
    {
        s[0][i]=S[0][i]=0;
    }
    s[1][1]=S[1][1]=1;
    for(i=1;i<=201;i++)
        for(j=1;j<=201;j++)
    {
        if(i==1 && j==1)
        {
            continue;
        }
        else if(i<j)
        {
            s[i][j]=S[i][j]=0;
        }
        else
        {
            s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j];
            S[i][j]=S[i-1][j-1]+m*S[i-1][j];
        }
    }
}
int main()
{
    int T,x;
    ifstream fin("stirling.in");
    ofstream fout("stirling.out");
    fin>>T;
    Construire();
    while(T--)
    {
        fin>>x>>n>>m;
        if(x==1)
        {
            fout<<s[n][m];
        }
        else
        {
            fout<<s[n][m];
        }
        fout<<'\n';
    }

    fin.close();
    fout.close();
    return 0;
}

