#include <cstdio>

#define NMAX 205
#define MOD 98999

using namespace std;

int fkind[NMAX][NMAX],skind[NMAX][NMAX];
bool fbool[NMAX][NMAX],sbool[NMAX][NMAX];

void initialize()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    // stirling of first&&second kind
    int i;
    for(i=0;i<=NMAX-5;i++)
        fbool[0][i]=fbool[i][0]=sbool[0][i]=sbool[i][0]=true;
    fkind[0][0]=1;
    skind[0][0]=1;
}

int stirling_first_kind(int n, int k)
{
    if(fbool[n][k]==true) // daca numarul a fost deja calculat
        return fkind[n][k];
    else
        {
            fkind[n][k]=(stirling_first_kind(n-1,k-1)-((n-1)*stirling_first_kind(n-1,k))%MOD)%MOD;
            fbool[n][k]=true;
            return fkind[n][k];
        }
}

int stirling_second_kind(int n, int k)
{
        if(sbool[n][k]==true) // daca numarul a fost deja calculat
        return skind[n][k];
    else
        {
            skind[n][k]=((k*stirling_second_kind(n-1,k))%MOD+stirling_second_kind(n-1,k-1))%MOD;
            sbool[n][k]=true;
            return skind[n][k];
        }
}

int main()
{
    int N,K,T,op;
    initialize();
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d%d%d",&op,&N,&K);
        if(op==1)
            printf("%d\n",stirling_first_kind(N,K));
        else
            printf("%d\n",stirling_second_kind(N,K));
    }
    return 0;
}
