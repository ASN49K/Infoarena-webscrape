#include <iostream>
#include <fstream>

using namespace std;

ifstream in("stirling.in");
ofstream out("stirling.out");

int s1[203][203];
int s2[203][203];
const int MOD = 98999;

int main() {

    s1[1][1] = 1;
    s2[1][1] = 1;

    for(int i = 2; i <= 200; i++) {
        for(int j = 1; j <= i; j++) {
            s1[i][j] = (s1[i-1][j-1] - (i-1)*s1[i-1][j])%MOD;
            s2[i][j] = (s2[i-1][j-1] + j*s2[i-1][j])%MOD;
        }
    }

    int x,y,z;
    int n;
    in >> n;

    for(int i = 1; i <= n; i++) {

        in >> x >> y >> z;

        if(x == 1) {
            out << s1[y][z] << '\n';
        } else {
            out << s2[y][z] << '\n';
        }

    }

    return 0;
}
