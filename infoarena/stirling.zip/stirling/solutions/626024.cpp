#include <fstream>
#define NF 211
using namespace std;
long long m,speta,t,i,j,n,s[NF][NF],S[NF][NF];



void sweat()
    {
        int i,j;
            for (i=2;i<=NF;i++)
                for (j=1;j<=NF;j++) {
                    s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999;
                    S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
            }
    }
int main()
{
    ifstream f("stirling.in");
    ofstream g("stirling.out");
    f>>t;
    s[1][1]=1;
    S[1][1]=1;
    sweat();

    for (i=1;i<=t;i++)  {
        f>>speta>>n>>m;
        if (speta==1) g<<s[n][m];
        else g<<S[n][m];
        g<<'\n';
    }
}
