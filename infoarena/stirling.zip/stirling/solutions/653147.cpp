# include<stdio.h>
int a[210][210],b[210][210],x,y,op,n,i,j;
int main()
{
	freopen("stirling.in","r",stdin);
	freopen("stirling.out","w",stdout);
	scanf("%d\n",&n);
	a[0][0]=1;
	a[1][1]=1;
	b[0][0]=1;
	b[1][1]=1;
	for (i=2; i<=200; ++i)
		for (j=1; j<=i; ++j)
		{
			a[i][j]=(a[i-1][j-1]-(i-1)*a[i-1][j])%98999;
			b[i][j]=(b[i-1][j-1]+j*b[i-1][j])%98999;
		}
	for (i=1; i<=n; i++)
	{
		scanf("%d %d %d\n",&op,&x,&y);
		if (op==1) printf("%d\n",a[x][y]);
		else
			printf("%d\n",b[x][y]);
	}
	return 0;
}