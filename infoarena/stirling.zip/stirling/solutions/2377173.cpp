#include <iostream>
#include <fstream>

using namespace std;

const int MAXN = 2e2, MOD = 98999;

ifstream fin("stiriling.in");
ofstream fout("stiriling.out");

int stiriling1[2 * MAXN + 10][2 * MAXN + 10], stiriling2[2 * MAXN + 10][2 * MAXN + 10];

void preprocess() {
    stiriling1[0][0] = 1;
    stiriling1[1][1] = 1;
    for (int i = 2; i < MAXN / 2; ++i)
        for (int j = 1; j <= i; ++j)
            stiriling1[i][j] = (stiriling1[i - 1][j - 1] - (i - 1) * stiriling1[i - 1][j]) % MOD;
    stiriling2[0][0] = 1;
    stiriling2[1][1] = 1;
    for (int i = 2; i < MAXN / 2; ++i)
        for (int j = 1; j <= i; ++j)
            stiriling2[i][j] = (stiriling2[i - 1][j - 1] + j * stiriling2[i - 1][j]) % MOD;
}

int main() {
    int t, x, y, nr;
    preprocess();
    fin >> t;
    for (int i = 0; i < t; ++i) {
        fin >> nr >> x >> y;
        if (nr == 1)
            fout << stiriling1[x][y] << "\n";
        else
            fout << stiriling2[x][y] << "\n";
    }
    return 0;
}
