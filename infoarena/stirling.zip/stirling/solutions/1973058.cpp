#include<stdio.h>

using namespace std;

const int MOD=98999;
int N,x,n,m;

int speta1(int n,int m){

    if(!m || !n)
        return 0;

    if(n<m)
        return 0;

    if(m==1 && n==1)
        return 1;

    return (speta1(n-1,m-1) + (n-1) * speta1(n-1,m))%MOD;

}

int speta2(int n,int m){

    if(!m || !n)
        return 0;

    if(n<m)
        return 0;

    if(m==1 && n==1)
        return 1;

    return (speta2(n-1,m-1) + m * speta2(n-1,m))%MOD;

}

int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    scanf("%d",&N);

    for(int i=1;i<=N;++i){
        scanf("%d%d%d",&x,&n,&m);

        if(x==1)printf("%d\n",speta1(n,m));
        else printf("%d\n",speta2(n,m));

    }

    return 0;
}
