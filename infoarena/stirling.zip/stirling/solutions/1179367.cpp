#include <fstream>

using namespace std;
int s1[205][205],s2[205][205];
const int mod=98999;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
inline void preprocesare()
{
    int i,j;
    for(i=1;i<=200;i++)
    {
        for(j=1;j<=i;j++)
        {
            s1[i][j]=s1[i-1][j-1]-(i-1)*s1[i-1][j];
            if(j==1||j==i) s2[i][j]=1;
            else s2[i][j]=s2[i-1][j-1]+j*s2[i-1][j];
        }
    }
}
int main()
{
    int n,t,ok,i,k;
    fin>>t;
    s1[0][0]=1;
    preprocesare();
    for(i=0;i<t;i++)
    {
        fin>>ok>>n>>k;
        if(ok==1) fout<<s1[n][k]%mod<<"\n";
        else fout<<s2[n][k]%mod<<"\n";
    }
}
