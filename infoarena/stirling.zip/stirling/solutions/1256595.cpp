#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");

int T,n,m,s[201][201],S[201][201];
int const MOD= 98999;
void stirling1()  //precalculare stirling speta I
{
    int i,j;
    s[1][1]=1;
    for(i=2;i<=200;i++)
        for(j=1;j<=200;j++)
    s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
}

void stirling2()
{
    int i,j;
    S[1][1]=1;
    for(i=2;i<=200;i++)
        for(j=1;j<=200;j++)
    S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
}
int main()
{
    fin>>T;
    int i,x;
    stirling1();
    stirling2();
    for(i=1;i<=T;i++)
    {
        fin>>x;
        fin>>n>>m;
         if(x==1) fout<<s[n][m]<<"\n";
         else fout<<S[n][m]<<"\n";
    }

    return 0;
}
