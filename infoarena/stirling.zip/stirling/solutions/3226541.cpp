#include <bits/stdc++.h>
using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

long part1(int n, int k)
{
    if (n==0 and k==0)
    {
        return 1;
    }
    if (n==0 or k==0)
    {
        return 0;
    }
    return (n-1)*part1(n-1, k)+part1(n-1, k-1);
}
long part2(int n, int k)
{
    if (n==0 and k==0)
    {
        return 1;
    }
    if (n==0 or k==0)
    {
        return 0;
    }
    return k*part2(n-1, k)+part2(n-1, k-1);
}
long long int t, x, y, c, r;

int main()
{
    fin>>t;
    for (int i=1; i<=t; i++)
    {
        fin>>c>>x>>y;
        if (c==1)
        {
            r=part1(x,y);
            if (x>y)
            {
                fout<<r*-1<<'\n';
            }
            else
            {
                fout<<r<<'\n';
            }
        }
        else
        {
            r=part2(x,y);
            if (x>y)
            {
                fout<<r*-1<<'\n';
            }
            else
            {
                fout<<r<<'\n';
            }
        }
    }
    
    
    
    return 0;
}
