#include <iostream>
#include <fstream>
#define MOD 98999
using namespace std;
ifstream in("stirling.in");
ofstream out("stirling.out");
long long s(int n, int m)
{
    if((n<0 || m<0)||(n<m)) return 0;
    if(n==1&&m==1) return 1;
    return s(n-1,m-1)-(n-1)*s(n-1,m) % MOD;
}
long long S(int n, int m)
{
    if((n<0 || m<0)||(n<m)) return 0;
    if(n==1&&m==1) return 1;
    else return S(n-1, m-1) + m*S(n-1,m) % MOD;
}
int T, a, b, c;
int main()
{
    in>>T;
    while(T--)
    {
        in>>a>>b>>c;
        if(a==1)
            out<<s(b, c)<<'\n';
        else
            out<<S(b, c)<<'\n';;
    }
    return 0;
}
