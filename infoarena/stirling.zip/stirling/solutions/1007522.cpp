#include <cstdio>
using namespace std;

#define MOD 98999

FILE *f=fopen ("stirling.in","r");
FILE *g=fopen ("stirling.out","w");

int s[205][205],S[205][205];

int main(){
	int t,tip,x,y;
	
	s[1][1]=1; S[1][1]=1;
	
	for (int i=2;i<=200;++i){
		for (int j=1;j<=200;++j){
			s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
			S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
		}
	}
	
	fscanf (f,"%d",&t);
	
	for (int i=1;i<=t;++i){
		fscanf (f,"%d%d%d",&tip,&x,&y);
		if (tip==1) fprintf (g,"%d\n",s[x][y]);
		else fprintf (g,"%d\n",S[x][y]);
	}
	
	return 0;
}
