#include <cstdio>
#define nmax 209
#define mmax 209
#define mod 98999
using namespace std;
int s[nmax][mmax],S[nmax][mmax];
int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    int t,i,j,n,m,tip;
    s[1][1]=1;
    S[1][1]=1;
    for(i=2;i<=200;i++)
        for(j=1;j<=i;++j)
        {
            s[i][j]=(s[i-1][j]-(i-1)*s[i-1][j-1])%mod;
            S[i][j]=(S[i-1][j]*j+S[i-1][j-1])%mod;
        }
    scanf("%d",&t);
    for(i=1;i<=t;++i)
    {
        scanf("%d%d%d",&tip,&n,&m);
        if(tip==1)
            printf("%d\n",s[n][m]);
        if(tip==2)
            printf("%d\n",S[n][m]);
    }
    return 0;
}
