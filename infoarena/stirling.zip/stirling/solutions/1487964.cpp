#include <iostream>
#include <fstream>
using namespace std;
int a, b, S[202][202], s[202][202], k, p=98999, l, n, m=201, ok;
void generare_s()
{
    s[1][1]=1;
    for(int i=2; i<m; i++)
        for(int q=1; q<=i; q++)
            s[i][q]=(s[i-1][q-1]-(i-1)*s[i-1][q])%p;


}
void generare_S()
{
    S[1][1]=1;
    for(int i=2; i<m; i++)
        for(int q=1; q<=i; q++)
            S[i][q]=(S[i-1][q-1]+q*S[i-1][q])%p;
}
int main()
{
    ifstream fin("stirling.in");
    ofstream fout("stirling.out");
    fin>>n;
    generare_S();
    generare_s();
    for(int i=1; i<=n; i++)
    {
        fin>>k>>a>>b;
        if(k==1) fout<<s[a][b]<<"\n";
        else fout<<S[a][b]<<"\n";
    }
    return 0;
}
