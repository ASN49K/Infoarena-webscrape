#include <fstream>
using namespace std;

ifstream in("stirling.in");
ofstream out("stirling.out");

const int MAXN = 205;
const int MODULO = 98999;

int s[MAXN][MAXN], S[MAXN][MAXN];

/*
    s[1][1] = 1
    S[1][1] = 1
    relatii de recurenta

    s[n][m] = s[n-1][m-1] - (n - 1) * s[n - 1][m]

    S[n][m] = S[n - 1][m - 1] + m * S[n - 1][m]
*/


void precalculare_s()
{
    s[1][1] = 1;
    for (int n = 2;n < MAXN;++n)
        for (int m = 1;m < MAXN;++m)
            s[n][m] = (s[n - 1][m - 1] - (n - 1) * s[n - 1][m]) % MODULO;
}

void precalculare_S()
{
    S[1][1] = 1;
    for (int n = 2;n < MAXN;++n)
        for (int m = 1;m < MAXN;++m)
            S[n][m] = (S[n - 1][m - 1] + m * S[n - 1][m]) % MODULO;
}

void test()
{
    int x,n,m;
    in >> x >> n >> m;
    if (x == 1)
        out << s[n][m];
    else out << S[n][m];
    out << '\n';
}

int main()
{
    int t;
    precalculare_s();
    precalculare_S();
    in >> t;
    while(t > 0)
    {
        test();
        --t;
    }
    return 0;
}
