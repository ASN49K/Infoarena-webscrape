#include <cstdio>

using namespace std;

const int MOD = 98999;
const int maxn = 205;
int t, x, n, m, s[maxn][maxn], S[maxn][maxn];

void calcs()
{
    int i, j;
    s[1][1] = 1;
    for(i = 2; i < maxn; ++i)
        for(j = 1; j <= i; ++j)
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
}

void calcS()
{
    int i, j;
    S[1][1] = 1;
    for(i = 2; i < maxn; ++i)
        for(j = 1; j <= i; ++j)
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
}

int main()
{
    int i;
    freopen ("stirling.in", "r", stdin);
    freopen ("stirling.out", "w", stdout);
    calcs();
    calcS();
    scanf("%d", &t);
    for(i = 1; i <= t; ++i) {
        scanf("%d %d %d", &x, &n, &m);
        if(x == 1)
            printf("%d\n", s[n][m]);
        else
            printf("%d\n", S[n][m]);
    }
    return 0;
}
