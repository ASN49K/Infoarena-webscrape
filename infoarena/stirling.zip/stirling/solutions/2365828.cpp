#include <fstream>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

const int NMax = 200, MOD = 98999;

int T, p, a, b, S1[NMax + 5][NMax + 5], S2[NMax + 5][NMax + 5];

int Speta1(int N, int M)
{
    S1[0][0] = 1;

    for(int i = 1; i <= N; i++)
        for(int j = 1; j <= M; j++)
            S1[i][j] = (S1[i - 1][j - 1] - (i - 1) * S1[i - 1][j] % MOD) % MOD;
}

void Speta2(int N, int M)
{
    S2[0][0] = 1;

    for(int i = 1; i <= N; i++)
        for(int j = 1; j <= M; j++)
            S2[i][j] = (S2[i - 1][j - 1] + j * S2[i - 1][j] % MOD) % MOD;
}

int main()
{
    fin >> T;

    Speta1(NMax, NMax), Speta2(NMax, NMax);

    while(T--)
    {
        fin >> p >> a >> b;

        fout << ((p == 1) ? S1[a][b] : S2[a][b]) << '\n';
    }
    fin.close();
    fout.close();

    return 0;
}
