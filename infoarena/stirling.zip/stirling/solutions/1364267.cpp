#include<cstdio>
#include<string>

using namespace std;

#ifdef HOME
const string inputFile = "input.txt";
const string outputFile = "output.txt";
#else
const string problemName = "stirling";
const string inputFile = problemName + ".in";
const string outputFile = problemName + ".out";
#endif

const int MOD = 98999;

int T;
int s[205][205];
int S[205][205];

int main() {
    int n, m, x;

    freopen(inputFile.c_str(), "r", stdin);
    freopen(outputFile.c_str(), "w", stdout);

    scanf("%d", &T);

    s[0][0] = S[0][0] = 1;

    for(n = 1; n <= 200; n++)
        for(m = 1; m <= 200; m++) {
            s[n][m] = (s[n - 1][m - 1] + (1 - n) * s[n - 1][m]) % MOD;
            S[n][m] = (S[n - 1][m - 1] + m * S[n - 1][m]) % MOD;
        }

    while(T--) {
        scanf("%d%d%d", &x, &n, &m);

        if(x == 1)
            printf("%d\n", s[n][m]);

        if(x == 2)
            printf("%d\n", S[n][m]);
    }

    return 0;
}
