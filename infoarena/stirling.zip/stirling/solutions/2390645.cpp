#include <fstream>
#define mod 98999
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
long long n,m,t,i,j,s[2005][2005],a[2005][2005],c;
int main()
{
    f>>t;
    s[1][1]=1;
    a[1][1]=1;
    for(i=2; i<=200; i++)
        for(j=1; j<=200; j++)
        {
            s[i][j]=(s[i-1][j-1]+s[i-1][j]*j%mod)%mod;
            a[i][j]=(a[i-1][j-1]-a[i-1][j]*(i-1))%mod;
        }
    for(i=1; i<=t; i++)
    {
        f>>c>>n>>m;
        if(c==1) g<<a[n][m]<<'\n';
        else g<<s[n][m]<<'\n';
    }
    return 0;
}
