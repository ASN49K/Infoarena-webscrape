#include <fstream>

using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");

const int mod=98999;
int i,j,t,x,n,m;
int s[205][205],S[205][205];

void Stirling_I()
{
    s[0][0]=1;
    for(i=1;i<=200;i++)
        for(j=1;j<=200;j++)
    {
        s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j];
        s[i][j]%=mod;
    }
}
void Stirling_II()
{
    S[0][0]=1;
    for(i=1;i<=200;i++)
        for(j=1;j<=200;j++)
    {
        S[i][j]=S[i-1][j-1]+j*S[i-1][j];
        S[i][j]%=mod;
    }
}
int main()
{
    Stirling_I();
    Stirling_II();
    f>>t;
    for(i=1;i<=t;i++)
    {
        f>>x>>n>>m;
        if(x==1)
        {
            g<<s[n][m]<<'\n';
        }
        else
        {
            g<<S[n][m]<<'\n';
        }
    }
    return 0;
}
