#include <iostream>
#include <fstream>
#include <deque>
#include <set>
#include <algorithm>
#include <stack>
#include <vector>
#include <iomanip>

#define MOD 98999

using namespace std;

ifstream fin("a.in");
ofstream fout("a.out");

int s[205][205];
int S[205][205];

void prelucrare_s() {
	s[1][1] = 1;
	for (int i = 2; i < 201; ++i)
		for (int j = 1; j <= i; ++j)
			s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
}

void prelucrare_S() {
	S[1][1] = 1;
	for (int i = 2; i < 201; ++i)
		for (int j = 1; j <= i; ++j)
			S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
}

int main() {
	prelucrare_s();
	prelucrare_S();

	int t;
	fin >> t;

	int tip, n, m;
	for (int i = 0; i < t; ++i) {
		fin >> tip >> n >> m;

		if (tip == 1)
			fout << s[n][m] << "\n";
		else
			fout << S[n][m] << "\n";
	}

	return 0;
}