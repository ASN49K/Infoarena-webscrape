#include<cstdio>
#define NMax 205
using namespace std;

int s[NMax][NMax],S[NMax][NMax];

void stirling1 ()
{
    int i,j;
    s[0][0]=1;
    for (i=1; i<=200; i++)
        for (j=1; j<=200; j++)
            s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j];
}

void stirling2 ()
{
    int i,j;
    S[0][0]=1;
    for (i=1; i<=200; i++)
        for (j=1; j<=200; j++)
            S[i][j]=S[i-1][j-1]+(j-1)*S[i-1][j];
}

int main ()
{
    int T,tip,N,K;
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    stirling1();
    stirling2();
    scanf("%d",&T);
    while (T--)
    {
        scanf("%d%d%d",&tip,&N,&K);
        if (tip==1)
            printf("%d\n",s[N][K]);
        else
            printf("%d\n",S[N][K]);
    }
    return 0;
}
