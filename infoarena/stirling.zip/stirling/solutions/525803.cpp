#include<stdio.h>
#include<stdlib.h>
int s1[201][201],s2[201][201],m,n,i,j,k,x,t;
int main()
{
	freopen("stirling.in","r",stdin);
	freopen("stirling.out","w",stdout);
	scanf("%d",&t);
	for(i=0;i<=200;i++) s1[i][i]=1,s2[i][i]=1;
	for(i=1;i<=200;i++)
		for(j=1;j<i;j++)
			s1[i][j] = s1[i-1][j-1]-(i-1)*s1[i-1][j] , s2[i][j] = s2[i-1][j-1]+j*s2[i-1][j];
	while(t)
	{
		t--;
		scanf("%d%d%d",&x,&i,&j);
		switch (x)
		{
		case 1 :
			{
				printf("%d\n",s1[i][j]);
				break;
			}
		case 2 :
			{
				printf("%d\n",s2[i][j]);
				break;
			}
		}
	}
	return 0;
}
