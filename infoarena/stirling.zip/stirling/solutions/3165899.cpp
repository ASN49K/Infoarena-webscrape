
#include <fstream>
#include <vector>
using namespace std;
ifstream cin("stirling.in");
ofstream cout("stirling.out");
int q;
int n,m;
int t;
const int M=98999;
vector<vector<long long>> S1;
vector<vector<long long>> S2;
void formare()
{
    S1.resize(201);
    S2.resize(201);
    S1[0].push_back(1);
    S2[0].push_back(1);
    for(int i=1;i<=200;i++)
    {
        S1[i].resize(i+1);
        S2[i].resize(i+1);
        for(int j=1;j<i;j++)
        {
          S1[i][j]=(S1[i-1][j-1]%M-(i-1)*S1[i-1][j]*1LL%M)%M;
          S2[i][j]=(S2[i-1][j-1]%M+j*S2[i-1][j]*1LL%M)%M;
        }
        S1[i][i]=1;
        S2[i][i]=1;
    }
}
int main()
{
    cin>>q;
    formare();
    for(int i=0;i<q;i++)
    {
        cin>>t;
        cin>>n>>m;
        if(m>n)
        {
            cout<<0<<'\n';
            continue;
        }
        if(t==1)
          cout<<S1[n][m]<<'\n';
        else
          cout<<S2[n][m]<<'\n';
    }

    return 0;
}
