#include <iostream>
#include <fstream>

using namespace std;

const int NMAX = 200;
const int MOD = 98999;

int s[2][NMAX + 1][NMAX + 1];

ifstream fin( "stirling.in" );
ofstream fout( "stirling.out" );

void solve() {
    int n, m, speta;
    fin >> speta >> n >> m;
    fout << s[speta - 1][n][m] << '\n';
}
void dp() {
    s[0][1][1] = s[1][1][1] = 1;
    for ( int n = 2; n <= NMAX; n ++ ) {
        for ( int m = 1; m <= NMAX; m ++ ) {
            s[0][n][m] = ( s[0][n - 1][m - 1] - (n - 1) * s[0][n - 1][m] ) % MOD;
            s[1][n][m] = ( s[1][n - 1][m - 1] + s[1][n - 1][m] * m ) % MOD;
        }
    }
}
int main() {
    int t;
    fin >> t;
    dp();
    while ( t-- ) {
        solve();
    }
    return 0;
}
