#include <bits/stdc++.h>
using namespace std;
int S[3][201][201];
#define MOD 98999
int main(){
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);
    S[1][1][1]=S[2][1][1]=1;
    for(int i=2;i<=200;++i)
        for(int j=1;j<=i;++j){
            S[1][i][j]=(1LL*S[1][i-1][j-1]-1LL*(i-1)*S[1][i-1][j])%MOD;
            S[2][i][j]=(1LL*S[2][i-1][j-1]+1LL*j*S[2][i-1][j])%MOD;
        }
    int n;
    scanf("%d",&n);
    while(n--){
        int sp,i,j;
        scanf("%d %d %d",&sp,&i,&j);
        printf("%d\n",S[sp][i][j]);
    }
}
