#include <cstdio>
#define MOD 98999

int s[201][201], S[201][201];

void StirlingI(){

    s[1][1] = 1;

    for(int i = 2; i < N; i++){
        for(int j = 1; j <= i; j++){
            s[i][j] = (s[i-1][j-1] - (i-1) * s[i-1][j]) % MOD;
        }
    }
}

void StirlingII(){

    S[1][1]= 1;

    for(int i = 2; i < N; i++){
        for(int j = 1; j <= i; j++){
            S[i][j]= (S[i-1][j-1] + j * S[i-1][j]) % MOD;
        }
    }
}

int main(){

    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    int T, speta, N, K;

    StirlingI(); StirlingII();
    scanf("%d", &T);

    while(T--){
        scanf("%d %d %d", &speta, &N, &K);

        if(speta == 1) printf("%d\n", s(N, K));
        if(speta == 2) printf("%d\n", S(N, K));
    }
    return 0;
}
