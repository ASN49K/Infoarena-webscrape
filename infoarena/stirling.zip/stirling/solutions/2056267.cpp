#include <iostream>
#include <cstdio>
#define N 205
#define mod 98999

using namespace std;

int n, m, x, t;
int mat1[N][N], mat2[N][N];

void calcul_sterling()
{
    mat1[0][0]=mat2[0][0]=1;
    for(int i=1;i<=200;i++)
        for(int j=1;j<=i;j++)
        {
            mat1[i][j]=(mat1[i-1][j-1]-((i-1)*mat1[i-1][j])%mod)%mod;
            mat2[i][j]=(mat2[i-1][j-1]+(j*mat2[i-1][j])%mod)%mod;
        }
}

int main()
{
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    scanf("%d\n", &t);
    calcul_sterling();

    for(int i=1;i<=t;i++)
    {
        scanf("%d %d %d\n", &x, &n, &m);
        if(x==1)
            printf("%d\n", mat1[n][m]);
        else
            printf("%d\n", mat2[n][m]);
    }
    return 0;
}
