#include <bits/stdc++.h>
using namespace std;
const int NMAX = 201;
const int MOD = 98999;
ifstream fin ("stirling.in");
ofstream fout ("stirling.out");
int q, n, m, caz, S[NMAX][NMAX], s[NMAX][NMAX], i, j;
void precalcucare_s1 ();
void precalculare_S2 ();
int main()
{
    fin >> q;
    precalcucare_s1 ();
    precalculare_S2 ();
    while (q)
    {
        q--;
        fin >> caz >> n >> m;
        if (caz == 1) fout << s[n][m] << "\n";
        else fout << S[n][m] << "\n";
    }
    return 0;
}
void precalcucare_s1 ()
{
    s[1][1] = 1;
    for (i=2; i<NMAX; i++)
        for (j=1; j<=i; j++)
        s[i][j] = (s[i-1][j-1] - (i - 1) * s[i-1][j]) % MOD;
}
void precalculare_S2 ()
{
    S[1][1] = 1;
    for (i=2; i<NMAX; i++)
        for (j=1; j<=i; j++)
        S[i][j] = (S[i-1][j-1] + j * S[i-1][j]) % MOD;
}
