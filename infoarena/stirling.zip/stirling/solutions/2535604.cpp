#include <iostream>
#include <fstream>
#define MOD 98999

using namespace std;

ifstream f ("stirling.in");
ofstream g ("stirling.out");

int s[202][202],S[202][202];
int n,m,w;
void stirling()
{
    s[1][1]=1;
    S[1][1]=1;
    for(int i=2; i<=201; i++)
    {
        for(int j=1; j<=i; j++)
        {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
        }
    }
}
int main()
{
    stirling();
    f>>w;
    for (int i=1; i<=w; i++)
    {
        int x;
        f>>x>>n>>m;
        if(x==1)g<<s[n][m]<<'\n';
        else g<<S[n][m]<<'\n';
    }
    return 0;
}
