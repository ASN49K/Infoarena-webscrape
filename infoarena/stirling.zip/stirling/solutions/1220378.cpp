# include <fstream>
# define mod 98999
using namespace std;
ifstream fi("stirling.in");
ofstream fo("stirling.out");
int s[2][201][201];
int main(void)
{
    s[0][1][1]=s[1][1][1]=1;
    for (int i=2;i<201;++i)
        for (int j=1;j<=i;++j)
               s[0][i][j]=(s[0][i-1][j-1]-(i-1)*s[0][i-1][j])%mod,
               s[1][i][j]=(s[1][i-1][j-1]+j*s[1][i-1][j])%mod;
    int t;
    fi>>t;
    while (t--)
    {
        int z,x,y;
        fi>>z>>x>>y;
        --z;
        fo<<s[z][x][y]<<"\n";
    }
    fo.close();
    return 0;
}
