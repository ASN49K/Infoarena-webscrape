#include <fstream>
#define MX 201
#define MOD 98999
using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");
int s[MX][MX], S[MX][MX];

void preprocesare()
{
    s[1][1] = S[1][1] = 1;
    int i,j;

    for(i=2; i<MX; i++)
    {
        for(j=1; j<=i; j++)
        {
            s[i][j] = ( s[i-1][j-1] - (i-1)*s[i-1][j] ) % MOD;
            S[i][j] = ( S[i-1][j-1] + j*S[i-1][j] ) % MOD;
        }
    }
}

int main()
{
    int t,x,n,m,i;

    preprocesare();

    fin>>t;

    for(i=1; i<=t; i++)
    {
        fin>>x>>n>>m;
        if(x == 1)
        {
            fout<<s[n][m]<<'\n';
        }
        else
        {
            fout<<S[n][m]<<'\n';
        }
    }

    fin.close(); fout.close();
    return 0;
}
