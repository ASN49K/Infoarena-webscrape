#include <fstream>

using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int mat1[202][202];
int mat2[202][202];
int const n = 201;
int const mod = 98999;
void ds1()
{
    mat1[1][1] = 1;
    for(int i = 2; i < n; i ++)
    {
        for(int j = 1; j <= i; j ++)
        {
            mat1[i][j] = (mat1[i - 1][j - 1] - (i - 1) * mat1[i - 1][j]) % mod;
        }
    }
}
void ds2()
{
    mat2[1][1] = 1;
    for(int i = 2; i < n; i ++)
    {
        for(int j = 1; j <= i; j ++)
        {
            mat2[i][j] = (mat2[i - 1][j - 1] + j * mat2[i - 1][j]) % mod;
        }
    }
}
int main()
{
    int t;
    f >> t;
    ds1();
    ds2();
    while(t--)
    {
        int ob, N, M;
        f >> ob >> N >> M;
        if(ob == 1)
        {
            g << mat1[N][M] << endl;
        }
        else
            if(ob == 2)
            {
                g << mat2[N][M] << endl;
            }
    }
    return 0;
}
