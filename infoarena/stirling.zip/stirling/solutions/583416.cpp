#include<fstream>
#define mod 98999
using namespace std;

int i,j,n,m,a[201][201],t,tip;
int Smare(int n,int m)
{
	int i,j;
	a[0][0]=1;
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
			a[i][j]=a[i-1][j-1]+j*a[i-1][j];
		return a[n][m]%mod;
}
int smic(int n,int m)
{
	int i,j;
	a[0][0]=1;
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
			a[i][j]=a[i-1][j-1]-(i-1)*a[i-1][j];
		return a[n][m]%mod;
}
void init()
{
	int i,j;
	a[0][0]=0;
	for(i=1;i<=n;i++)
		memcpy(a[i],a[0],sizeof(a[0]));
}
int main()
{
	ifstream f("stirling.in");
	ofstream g("stirling.out");
	f>>t;
	while(t--)
	{
		f>>tip>>n>>m;
		if(tip==2)
			g<<Smare(n,m)<<"\n";
			else
				g<<smic(n,m)<<"\n";
			init();
	}
	return 0;
}
			