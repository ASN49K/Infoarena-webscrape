#include <fstream>
#define MOD 98999
using namespace std;
ofstream fout ("stirling.out");
ifstream fin ("stirling.in");
int t,a,b,c,i,j;
long long s[205][205],S[205][205];
int main()
{
    s[ 1 ][ 1 ] = S[ 1 ][ 1 ] = 1;
    for( i = 2 ; i <= 200 ; i++ )
    {
        for( j = 1 ; j <= i ; j++ )
        {
            s[ i ][ j ] = ( s[ i - 1 ][ j - 1 ] - ( ( i - 1 ) * s[ i - 1 ][ j ] ) % MOD ) % MOD;
            S[ i ][ j ] = ( S[ i - 1 ][ j - 1 ] + ( j * s[ i - 1 ][ j ] ) ) % MOD;
        }
    }
    fin>>t;
    while( t-- )
    {
        fin>>a>>b>>c;
        fout<<( a == 1 ? ( s[ b ][ c ] ) : ( S[ b ][ c ] ) )<<'\n';
    }
}
