#include <fstream>
#define mod 98999
using namespace std;
long long int v[201][201];
unsigned long long int c[201][201];
ifstream fin("stirling.in");
ofstream fout("stirling.out");

void s()
{
    int i,j;
    v[1][1]=1;
    for(i=2;i<201;i++)
        for(j=1;j<201;j++)
        {
            v[i][j]=(v[i-1][j-1]-(i-1)*v[i-1][j])%mod;
        }
}
void S()
{
    int i,j;
    c[1][1]=1;
    for(i=2;i<201;i++)
        for(j=1;j<201;j++)
        {
            c[i][j]=(c[i-1][j-1]+j*c[i-1][j])%mod;
        }
}
int main()
{
    s();
    S();
    int i,t,a,b,p;
    fin>>t;
    for(i=0;i<t;i++)
    {
        fin>>p>>a>>b;
        if(p==1)
            fout<<v[a][b]<<'\n';
        else
            fout<<c[a][b]<<'\n';
    }
    return 0;
}
