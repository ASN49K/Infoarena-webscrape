#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

const int MAXN = 202, MOD = 98999;

int t, x, n, m, s[MAXN][MAXN], S[MAXN][MAXN];

void s1()
{
    s[1][1] = 1;
    for(int i = 2; i < MAXN; i++)
        for(int j = 1; j <= i; j++)
            s[i][j] = (s[i-1][j-1] - (i-1)*s[i-1][j]%MOD)%MOD;
}

void s2()
{
    S[1][1] = 1;
    for(int i = 3; i < MAXN; i++)
        for(int j = 1; j <= i; j++)
            S[i][j] = (S[i-1][j-1] + j*S[i-1][j]%MOD)%MOD;
}

int main()
{
    s1();
    s2();
    fin >> t;
    for(int i = 0; i < t; i++)
    {
        fin >> x >> n >> m;
        fout << (x == 1 ? s[n][m] : S[n][m]) << "\n";
    }
    return 0;
}
