#include <fstream>

using namespace std;
ifstream cin("stirling.in");
ofstream cout("stirling.out");
const int Nmax = 201;
const int MOD = 98999;
int stir1[Nmax][Nmax], stir2[Nmax][Nmax];
int n, m, q;
short int c;
int main()
{
    cin >> q;
    while(q--)
    {
        cin >> c >> n >> m;
        if(c == 1)
        {
            stir1[1][1] = 1;
            for(int i=2; i<=n; i++)
                for(int j=1; j<=i; j++)
                    stir1[i][j] = (1LL* stir1[i-1][j-1] - (i-1)*(stir1[i-1][j]) % MOD);
            cout << stir1[n][m] << '\n';
        }
        else
        {
            stir2[1][1] = 1;
            for(int i=2; i<=n; i++)
                for(int j=1; j<=i; j++)
                    stir2[i][j] = (stir2[i-1][j-1] + j * stir2[i-1][j]);

            cout << stir2[n][m] << '\n';
        }

    }
    return 0;
}
