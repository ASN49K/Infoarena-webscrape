#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

#define For(i, a, b) for(i = a; i <= b; i++)

#define NMax 210
#define MOD 98999

int t;

int s1[NMax][NMax], s2[NMax][NMax];

int fs1(int n, int m){
	if(s1[n][m] == -1){
		if(n < m || m == 0)	s1[n][m] = 0;
		else s1[n][m] = fs1(n - 1, m - 1) + fs1(n - 1, m) * (n - 1);
	}
	return s1[n][m];
}

int fs2(int n, int m){
	if(s2[n][m] == -1){
		if(n == m || m == 1) s2[n][m] = 1;
		else s2[n][m] = fs2(n - 1, m - 1) + fs2(n - 1, m) * m;
	}
	return s2[n][m];
}

void init(){
	memset(s1, -1, sizeof(s1));
	s1[0][0] = 1;
	memset(s2, -1, sizeof(s2));
}

int main(){
	int sp, n, m;
	init();
	fin >> t;
	while(t--){
		fin >> sp >> n >> m;
		if(sp == 1) fout << fs1(n, m);
		else fout << fs2(n, m);
		fout << '\n';
	}
}
