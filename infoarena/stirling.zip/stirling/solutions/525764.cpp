#include<stdio.h>

int s[201][201],S[201][201],n,m,t;


void work_s()
{
	s[1][1]=1;
	for(int i=2;i<201;i++)
		for(int j=1;j<=i;j++)s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999;
}

void work_S()
{
	S[1][1]=1;
	for(int i=2;i<201;i++)
		for(int j=1;j<=i;j++)S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
}



int main()
{
	freopen("stirling.in","r",stdin);
	freopen("stirling.out","w",stdout);
	
	scanf("%d\n",&t);
	work_s();
	work_S();
	
	for(int i=0;i<t;i++)
	{
		int c;
		scanf("%d %d %d\n",&c,&n,&m);
		if(c==1)printf("%d\n",s[n][m]);
		else printf("%d\n",S[n][m]);
	}

	
	return 0;
}