#include <iostream>
#include <fstream>
#define MOD 98999
using namespace std;

ifstream in("striling.in");
ofstream out("stirling.out");
int T,x,n,m;
int s[205][205],S[205][205];
int main()
{
    in>>T;
    S[1][1]=1;
    s[1][1]=1;
    for(int i=2; i<=201; i++)
    {
        for(int j=1; j<=i; j++)
        {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
        }
    }
    for(int i=1;i<=T;++i){
        in>>x>>n>>m;
        if(x==1)out<<s[n][m]<<'\n';
        else out<<S[n][m]<<'\n';
    }
    return 0;
}
