#include <fstream>
#define NMAX 210
#define MOD 98999

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int t, x, n, m, s[NMAX][NMAX], S[NMAX][NMAX];

int main()
{
    int i, j;
    n = m = 200;
    s[0][0] = S[0][0] = 1;
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= m; j++)
        {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j] % MOD) % MOD;
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j] % MOD) % MOD;
        }
    }
    fin >> t;
    for (i = 1; i <= t; i++)
    {
        fin >> x >> n >> m;
        if (x == 1)
            fout << s[n][m] << '\n';
        else
            fout << S[n][m] << '\n';
    }
    fout.close();
    return 0;
}
