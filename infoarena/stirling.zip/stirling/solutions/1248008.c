#include <stdio.h>
#define FIN "stirling.in"
#define FOUT "stirling.out"
#define MOD 98999
#define MAX 205

int s[ MAX ][ MAX ],
    S[ MAX ][ MAX ],
    N = 205;

//prototypes
void solve();
void query();
void compute_s();
void compute_S();

int main() {
 
    solve();     
    query();

    return(0); 
};

void query() {

    int T, 
        kind, 
        y, 
        z;

    freopen(FIN, "r", stdin); 

    freopen(FOUT, "w", stdout); 
         
    scanf("%d", &T);

    for(; T; --T) {

          scanf("%d %d %d", &kind, &y, &z);

          switch( kind ) {

                  case 1:
                  printf("%d\n", s[ y ][ z ]);
                  break;

                  case 2:
                  printf("%d\n", S[ y ][ z ]);
                  break;               
          }
    } 

    fclose( stdin );

    fclose( stdout );
}

void solve() {

    compute_s(); 

    compute_S();
};

void compute_s() {

     int i,
         j;

     s[ 1 ][ 1 ] = 1;

     for(i = 2; i < N; i++) {

         for(j = 1; j <= i; j++) {

                 s[ i ][ j ] = (s[ i - 1 ][ j - 1 ] - (i - 1) * s[ i - 1 ][ j ] ) % MOD; 
         }
     } 
};

void compute_S() {

     int i,
         j;

     S[ 1 ][ 1 ] = 1;

     for(i = 2; i < N; i++) {

         for(j = 1; j <= i; j++) {

                 S[ i ][ j ] = (S[ i - 1 ][ j - 1 ] + j * S[ i - 1 ][ j ] ) % MOD; 
         }
     } 
};
