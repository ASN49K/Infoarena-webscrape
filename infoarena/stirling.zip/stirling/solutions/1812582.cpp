#include<iostream>
#include<fstream>
#define NMax 205
#define MOD 98999
using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int Q,N,M,x;
int s[NMax][NMax],S[NMax][NMax];

void Precalc()
{
	s[1][1] = S[1][1] = 1;

	for(int i = 2 ; i < N ; ++i)
		for(int j = 1 ; j <= i ; ++j)
		{
			s[i][j] = (s[i-1][j-1] - (i-1) * s[i-1][j]) % MOD;
			S[i][j] = (S[i-1][j-1] + j * S[i-1][j]) % MOD;
		}
}

int main()
{
	Precalc();

	fin>>Q;

	while(Q--)
	{
		fin>>x>>N>>M;

		switch(x)
		{
			case 1: fout<<s[N][M]<<"\n"; break;
			case 2:	fout<<S[N][M]<<"\n"; break;
		}
	}

	fin.close();
	fout.close();
	return 0;
}
