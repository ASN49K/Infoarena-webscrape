#include <bits/stdc++.h>
#define Nmax 201
#define MOD 98999
using namespace std;
ifstream fin ("stirling.in");
ofstream fout ("stirling.out");
int s[3][Nmax][Nmax], t, n, m, tip;
int main()
{
    s[1][1][1]=s[2][1][1]=1;
    for(int i=2;i<Nmax;i++)
        for(int j=1;j<=i;j++)
        {
            s[1][i][j]=(s[1][i-1][j-1]-(i-1)*s[1][i-1][j])%MOD;
            s[2][i][j]=(s[2][i-1][i-1] + j*s[2][i-1][j])%MOD;
        }

    fin >> t;
    while(t--)
    {
        fin >> tip >> n >> m;
        fout << s[tip][n][m] << '\n';
    }
    return 0;
}
