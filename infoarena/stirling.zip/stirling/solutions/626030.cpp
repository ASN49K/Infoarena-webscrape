#include <fstream>

using namespace std;

long int m1[301][301],m2[301][301],i,x,t,a,b,j;

 inline int stirling1 (int x,int y) {
	return m1[x][y];
}

 inline int stirling2(int x,int y) {
	return m2[x][y];
}

int main()
{
	ifstream f("stirling.in");
	ofstream g("stirling.out");
	m1[1][1]=1;
	m2[1][1]=1;	
	for (i=1;i<=301;i++) {
		m2[i][1]=1;
		m2[i][i]=1;
	}
	
	for (i=2;i<=301;i++)
			for (j=1;j<=i;j++)
			m1[i][j]=(m1[i-1][j-1] - (i-1)*m1[i-1][j])%98999;
			m2[i][j]=(m2[i-1][j-1]+m2[i-1][j]*j) %98999;
	f>>t;
	for (i=1;i<=t;i++) {
		f>>x>>a>>b;
		if (x==1)  g<<stirling1(a,b);
		else
		g<<stirling2(a,b);
		g<<'\n';
	}
	f.close();
	g.close();
	return 0;
}