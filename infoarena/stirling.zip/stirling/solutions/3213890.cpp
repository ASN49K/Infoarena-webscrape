#include <fstream>

using namespace std;
ifstream cin("stirling.in");
ofstream cout("stirling.out");
long long int st1[201][201];
long long int st2[201][201];
int main()
{
    st1[0][0]=1;
    for(int i=1;i<=200;i++)
    {
        for(int j=1;j<i;j++)
        {
            st1[i][j]=((i-1)*st1[i-1][j]+st1[i-1][j-1])%98999;
            //cout<<st1[i][j]<<" ";
        }
        st1[i][i]=1;
        //cout<<"1 \n";
        //st1[i][i]=1;
    }
    st2[0][0]=1;
    for(int i=1;i<=200;i++)
    {
        for(int j=1;j<i;j++)
        {
            st2[i][j]=(j*st2[i-1][j]+st2[i][j-1])%98999;
            //cout<<st2[i][j]<<" ";
        }
        st2[i][i]=1;
        //cout<<'\n';
    }
    int t,x,n,m;
    cin>>t;
    for(int i=0;i<t;i++)
    {
        cin>>x>>n>>m;
        int dif=n-m;
        if(x==1 && dif%2==0)
            cout<<st1[n][m]<<'\n';
        else if(x==1 && dif%2==1)
            cout<<-st1[n][m]<<'\n';
        else
            cout<<st2[n][m]<<'\n';
    }
    return 0;
}
