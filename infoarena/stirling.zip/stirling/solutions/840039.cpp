#include<fstream>
using namespace std;
const int NMAX = 500, MOD = 98999;
int t, n, m, s;
int s1[NMAX][NMAX], s2[NMAX][NMAX];
inline void stirling();
int main()
{
    stirling();
    ifstream fin("stirling.in"); ofstream g("stirling.out");
    fin>>t;
    while(t--)
    {
        fin>>s>>n>>m;
        if(s == 1) g<<s1[n][m]<<"\n";
        else
            g<<s2[n][m]<<'\n';
    }
    g.close();
    return 0;
}
inline void stirling()
{
    s1[1][1] = s2[1][1] = 1;
    for(int i = 2; i <= NMAX; ++i)
        for(int j = 1; j <= i; ++j)
        {
            s1[i][j] = (s1[i -1][j - 1] - (i - 1) * s1[i - 1][j]) % MOD;
            s2[i][j] = (s2[i - 1][j - 1] + j * s2[i -1][j]) % MOD;
        }
}
