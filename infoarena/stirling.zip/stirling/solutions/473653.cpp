#include<fstream>

using namespace std;

#define NMAX 203
#define MOD 98999

ifstream fi("stirling.in");
ofstream fo("stirling.out");

int t,x,n,m;
int s[NMAX][NMAX],S[NMAX][NMAX];

void precalc() {
  int i,j;
  for(i=0;i<NMAX;i++) {
    for(j=1;j<i;j++) s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;
    s[i][i]=1;
  }
  for(i=0;i<NMAX;i++) {
    for(j=1;j<i;j++) S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
    S[i][i]=1;
  }
}

int main() {
  precalc();
  fi>>t;
  while(t--) {
    fi>>x>>n>>m;
    if(x==1) fo<<s[n][m]<<"\n";
    else fo<<S[n][m]<<"\n";
  }
  return 0;
}
