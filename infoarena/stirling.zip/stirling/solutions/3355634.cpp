#include <fstream>

using namespace std;
ifstream fin("stirling.in");
ofstream fout("striling.out");
#define cin fin
#define cout fout
const int mod=98999, nmax=200;
int s1[nmax+1][nmax+1], s2[nmax+1][nmax+1];
int main()
{
    s1[0][0]=s2[0][0]=1;
    for (int n=1; n<=nmax; n++)
    {
        for (int m=1; m<=n; m++)
        {
            s1[n][m]=(s1[n-1][m-1]-1LL*(n-1)*s1[n-1][m])%mod;
            if (s1[n][m]<0) s1[n][m]+=mod;
            s2[n][m]=(s2[n-1][m-1]+1LL*m*s2[n-1][m])%mod;
        }
    }
    int t;
    cin>>t;
    while (t--)
    {
        int x, n, m;
        cin>>x>>n>>m;
        if (x==1) cout<<s1[n][m]<<'\n';
        else cout<<s2[n][m]<<'\n';
    }
    return 0;
}
