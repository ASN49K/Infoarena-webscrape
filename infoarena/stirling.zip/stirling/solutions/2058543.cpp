#include <fstream>

using namespace std;

int speta1[205][205];
int speta2[205][205];

const int mod = 98999;

ifstream f("stirling.in");
ofstream g("stirling.out");

void precalc(){
    speta1[0][0] = speta2[0][0] = 1;
    for(int i = 1; i <= 200; ++i){
        for(int j = 1; j <= i; ++j){
            speta1[i][j] = (speta1[i-1][j-1] - ((i-1)*speta1[i-1][j]%mod))%mod;
            speta2[i][j] = (speta2[i-1][j-1] + (j*speta2[i-1][j]%mod))%mod;
        }
    }
}
int main(){
    int t;
    f >> t;
    precalc();
    while(t--){
        int cd;
        f >> cd;
        int n, m;
        f >> n >> m;

        if(cd == 1) g << speta1[n][m];
        else g << speta2[n][m];
        g << '\n';
    }
    return 0;
}
