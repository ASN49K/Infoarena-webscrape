#include <bits/stdc++.h>

using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");

int s[205][205],S[205][205],i,j,x,n,m,t;
int main()
{
    fin>>t;
    s[1][1]=S[1][1]=1;
    for(i=2;i<=201;++i)
        for(j=1;j<=201;++j)
        {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999;
            S[i][j]=(S[i-1][j-1]+S[i-1][j]*j)%98999;
        }
    for(i=1;i<=t;++i)
    {
        fin>>x>>n>>m;
        if(x==1)
            fout<<s[n][m]<<'\n';
        else
            fout<<S[n][m]<<'\n';

    }
    return 0;
}
