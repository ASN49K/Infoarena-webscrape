#include<cstdio>

int a[205][205];
int b[205][205];
int i,q,n,k,t;

void stirII(){
	
	int i,j;
	a[1][1]=1;
	for(i=2;i<=200;i++)
		for(j=1;j<=i;j++)
			a[i][j]=(a[i-1][j-1]+j*a[i-1][j])%98999;
	
}

void stirI(){
	
	int i,j;
	b[1][1]=1;
	for(i=2;i<=200;i++)
		for(j=1;j<=i;j++)
			b[i][j]=(b[i-1][j-1]-(i-1)*b[i-1][j])%98999;
	
	
}

int main(){
	
	freopen("stirling.in","r",stdin);
	freopen("stirling.out","w",stdout);
	
	scanf("%d",&t);
	
	stirI();
	stirII();
	
	for(i=1;i<=t;i++){
		
		scanf("%d%d%d",&q,&n,&k);
		if(q==1) printf("%d\n",b[n][k]);
		if(q==2) printf("%d\n",a[n][k]);
		
	}
	
	return 0;
	
}