#include <bits/stdc++.h>
#define MOD 98999
#define DIM 205

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int q, ops, n, m;
int S[DIM][DIM], s[DIM][DIM];

void init()
{
    s[1][1] = S[1][1] = 1;
    for(int i = 2; i < DIM; i++)
        for(int j = 1; j <= i; j++)
        {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
        }
}

int main()
{
    f >> q;
    init();
    while(q--)
    {
        f >> ops >> n >> m;
        if(ops == 1)
            g << s[n][m] << "\n";
        if(ops == 2)
            g << S[n][m] << "\n";
    }
    return 0;
}
