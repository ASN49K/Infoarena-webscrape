#include <iostream>
#include <fstream>
#define nmax 205
#define mod 98999
using namespace std;

int n, m, T;
int s[nmax][nmax], S[nmax][nmax];

void prec_s()
{

    s[1][1] = 1;
    for(int i=2; i<nmax; ++i)
    {
        for(int j=1; j<=i; ++j)
            s[i][j] = (s[i-1][j-1] - (i-1)*s[i-1][j]) % mod;
    }
}

void prec_S()
{
    S[1][1] = 1;
    for(int i=2; i<nmax; ++i)
    {
        for(int j=1; j<=i; ++j)
            S[i][j] = (S[i-1][j-1] + j*S[i-1][j]) % mod;
    }
}

void read()
{
    ifstream f("stirling.in");
    ofstream g("stirling.out");
    f >> T;
    for(int x ; T; --T)
    {
        f >> x >> n >> m;
        if(x == 1)
            g << s[n][m] << '\n';
        else
            g << S[n][m] << '\n';
    }
    f.close();
    g.close();
}

int main()
{
    prec_s();
    prec_S();
    read();
    return 0;
}
