#include <bits/stdc++.h>
#define MOD 98999
using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int s[205][205], S[205][205], T, n, m;

int main()
{
    s[1][1] = S[1][1] = 1;

    for(int i = 2; i <= 200; i++)
        for(int j = 1; j <= i; j++)
        {
            s[i][j] = (s[i-1][j-1] - (i-1)*s[i-1][j])%MOD;
            S[i][j] = (S[i-1][j-1] + j*S[i-1][j])%MOD;
        }

    fin >> T;
    for(int i = 1; i <= T; i++)
    {
        int x, n, m;
        fin >> x >> n >> m;
        if(x==1)
            fout << s[n][m] << '\n';
        else
            fout << S[n][m] << '\n';
    }
    return 0;
}
