#include<stdio.h>
int t,n,m,i,j,s[201][201],r[201][201];
int main() {
	freopen("stirling.in","r",stdin),freopen("stirling.out","w",stdout),scanf("%d",&t);
	for(i=1;i<201;i++)
    for(j=1;j<201;j++)
    if(i>j)
        s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999,r[i][j]=(r[i-1][j-1]+j*r[i-1][j])%98999;
    else if(i==j)
        s[i][j]=r[i][j]=1;
	while(t--)
      	scanf("%d%d%d",&i,&n,&m),printf("%d\n",i==1?s[n][m]:r[n][m]);
}
