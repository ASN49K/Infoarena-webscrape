#include <fstream>
#include <cstring>
#define MOD 98999
using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int Stirling[205][205];
int stirling[205][205];

void S(int n, int k)
{
    Stirling[0][0] = 1;
    for(int i = 1; i<=n; ++i)
    {
        Stirling[i][1] = 1;
        Stirling[i][i] = 1;
        for(int j = i-1; j > 1; --j)
        {
            Stirling[i][j] = (j * Stirling[i-1][j] + Stirling[i-1][j-1]) % MOD;
        }
    }
}

void s(int n, int k)
{
    stirling[0][0] = 1;
    for(int i = 1; i<=n; ++i)
    {
        stirling[i][i] = 1;
        for(int j = i-1; j > 0; --j)
        {
            stirling[i][j] = (-(i-1) * stirling[i-1][j] + stirling[i-1][j-1]) % MOD;
        }
    }
}

void solve()
{
    int T;
    f>>T;
    int c, n, k;
    for(int i = 0; i<T; i++)
    {
        f>>c>>n>>k;
        if(c == 1)
            g<<stirling[n][k];
        else
            g<<Stirling[n][k];
        g<<"\n";
    }
}

int main()
{
    s(200, 200);
    S(200, 200);
    solve();
}
