#include <iostream>
#include <fstream>
#include <algorithm>
#include <vector>
#include <unordered_map>
#include <cmath>
#define MOD 98999
#define ll long long
// #define fin cin
// #define gout cout
using namespace std;
ifstream fin("stirling.in");
ofstream gout("stirling.out");
ll s1[201][201],s2[201][201],b[201],c[201];///stirling 1,2 bell catalan
void stirling_speta_1(ll a[201][201])
{
    ll i,j;
    a[0][0]=1;
    for(i=1; i<201; ++i)
    {
        a[0][i]=a[i][0]=0;
        for(j=1; j<=i; ++j)
            a[i][j]=(a[i-1][j-1]-(i-1)*a[i-1][j])%MOD;
    }
}
void stirling_speta_2(ll a[201][201])
{
    a[0][0]=1;
    ll i,j;
    for(i=1; i<201; ++i)
    {
        a[0][i]=a[i][0]=0;
        for(j=1; j<=i; ++j)a[i][j]=(a[i-1][j-1]+j*a[i-1][j])%MOD;
    }
}
int bell(int n)
{
    ll ans=0;
    for(int i=0; i<=n; ++i)ans=ans+s2[n][i];
    return ans;
}
void catalan(ll c[])
{
    c[0]=1;
    ll i,j;
    for(i=1; i<=201; ++i)
    {
        c[i]=0;
        for(j=0; j<i; ++j)c[i]=c[i]+c[j]*c[i-j-1];
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    gout.tie(0);
    ll salut,x,n,m;
    fin>>salut;
    stirling_speta_1(s1);
    stirling_speta_2(s2);
    while(salut--)
    {
        fin>>x>>n>>m;
        if(x==1)gout<<s1[n][m]<<'\n';
        else gout<<s2[n][m]<<'\n';
    }
    return 0;
}
