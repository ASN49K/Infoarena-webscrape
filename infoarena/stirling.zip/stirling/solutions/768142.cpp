#include<fstream>
#define md 98999
#define maxn 201
using namespace std;
int s1[201][201],s2[201][201];

int main(void){
    int i,t,op,n,m;
    ifstream fin("stirling.in");
     ofstream fout("stirling.out");
    fin>>t; 
     s1[1][1]=s2[1][1]=1;
      for( int i=2 ; i<maxn ; ++i )
        for( int j=1 ; j<=i ; ++j ) {
                           s1[i][j]=(s1[i-1][j-1]-(i-1)*s1[i-1][j])%md;
                           s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%md;
                           }
     for (i=1; i<=t; ++i){
         fin>>op>>n>>m;
         if (op==1) fout<<s1[n][m]<<"\n"; else fout<<s2[n][m]<<"\n";
         }
 return(0);
}
