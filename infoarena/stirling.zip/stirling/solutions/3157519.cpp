#include<fstream>
using namespace std;
ifstream fin("partitiimultime.in");
ofstream fout("partitiimultime.out");
int n,m,t,sp1[201][201],sp2[201][201];
int main()
{
    sp1[1][1]=1;
    sp2[1][1]=1;
    for(int i=2;i<=200;i++)
    {
        for(int j=1;j<=i;j++)
        {
            sp1[i][j]=(sp1[i-1][j-1]-(i-1)*sp1[i-1][j])%98999;
        }
    }
    for(int i=2;i<=200;i++)
    {
        for(int j=1;j<=i;j++)
        {
            sp2[i][j]=(sp2[i-1][j-1]+j*sp2[i-1][j])%98999;
        }
    }
    fin>>t;
    int speta;
    for(int i=1;i<=t;i++)
    {
        fin>>speta>>n>>m;
        if(speta==1)
        {
            fout<<sp1[n][m]<<'\n';
        }
        else
        {
            fout<<sp2[n][m]<<'\n';
        }
    }
    fin.close();
    fout.close();
    return 0;
}
