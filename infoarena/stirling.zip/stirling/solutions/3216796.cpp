#include <bits/stdc++.h>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int factorial(int x){
    if(x==0)
        return 1;
    int p=1;
    for(int i=x; i>=2; i--)
        p*=i;
    return p;
}

int s(int n, int m){
    if(n==0 && m==0)
        return 1;
    if(n==0 || m==0)
        return 0;
    return s(n-1, m-1)-(n-1)*s(n-1, m);

}

int S(int n, int m){
    double s=0;
    for(int i=0; i<=m; i++){
        int minus1=pow(-1, m-i);
        int ilan=pow(i,n);
        int a=minus1*ilan;

        int fact1 = factorial(m-i);
        int fact2 = factorial(i);
        int b =fact1*fact2;

        s+=a*1./b;
    }
    return int(s);
}

int main()
{
    int t, n, m, c;
    f>>t;
    for(int i=1; i<=t; i++){
        f>>c>>n>>m;
        if(c==1)
            g<<s(n,m);
        else
            g<<S(n,m);


    }
    return 0;
}
