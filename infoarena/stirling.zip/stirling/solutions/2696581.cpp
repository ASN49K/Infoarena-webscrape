#include <bits/stdc++.h>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

const int MOD=98999;
int stirling1[205][205];
int stirling2[205][205];

void s(int n)
{
    stirling1[0][0]=1;

    for(int i=1;i<=n;i++)
        for(int j=1;j<=i;j++)
            stirling1[i][j]=(stirling1[i-1][j-1]-(i-1)*stirling1[i-1][j])%MOD;
}

void S(int n)
{
    stirling2[0][0]=1;

    for(int i=1;i<=n;i++)
        for(int j=1;j<=i;j++)
            stirling2[i][j]=(j*stirling2[i-1][j]+stirling2[i-1][j-1])%MOD;
}

void solve()
{
    int t,n,k,p;
    fin>>t;
    while(t--)
    {
        fin>>p>>n>>k;

        if(p==1)
            fout<<stirling1[n][k]<<"\n";
        else
            fout<<stirling2[n][k]<<"\n";
    }
}

int main()
{
    s(200);
    S(200);
    solve();
    return 0;
}
