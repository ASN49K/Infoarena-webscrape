#include <iostream>
#include <fstream>
using namespace std;
ifstream in("stirling.in");
ofstream out("stirling.out");
int main()
{
    const long long mod = 98999;
    int t,m,n,x,maxn = 200,maxm= 200;
    long long  s[maxn+1][maxn+1],S[maxn+1][maxn+1];
    for(int i = 0 ; i  <= maxn; i++)
        s[i][i] = S[i][i] = 1;
    for(int i = 1 ; i <= maxn ; i++)
        for(int j = 1 ; j <= i ; j++)
        {
            s[i][j] = (s[i-1][j-1] - (i-1)*s[i-1][j])%mod;
            S[i][j] = (S[i-1][j-1] + j*S[i-1][j])%mod;
        }
    in >> t;
    while(t--)
    {
        in >> x >> n >> m;
        if(x ==1)
            out << s[n][m] <<'\n';
        else
            out << S[n][m] << '\n';
    }
    return 0;
}
