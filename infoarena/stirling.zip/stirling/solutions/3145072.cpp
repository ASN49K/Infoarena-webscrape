#include <fstream>

using namespace std;
const int MOD = 98999;

ifstream in("stirling.in");
ofstream out("stirling.out");

int s[201][201], S[201][201], N;

void precalcul()
{
    S[0][0] = s[0][0] = 1;
    for(int i = 1; i <= 200; i++)
        s[0][i] = s[i][0] = S[0][i] = S[i][0] = 0;
    for(int i = 1; i <= 200; i++)
        for(int j = 1; j <= 200; j++)
        {
            S[i][j] = S[i - 1][j - 1] + j * S[i - 1][j] % MOD;
            s[i][j] = s[i - 1][j - 1] - (i - 1) * s[i - 1][j] % MOD;
        }
}

int main()
{
    precalcul();
    in >> N;
    for(int i = 1; i <= N; i++)
    {
        int c, n, m;
        in >> c >> n >> m;
        if(c == 1)
            out << s[n][m] << '\n';
        else
            out << S[n][m] << '\n';
    }
    in.close();
    out.close();
    return 0;
}