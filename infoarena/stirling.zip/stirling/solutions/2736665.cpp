#include <iostream>
#include <fstream>
#define MOD 98999

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int T;
int x , n , m;
int s1[202][202] , s2[202][202];

void Stirling1(){
    s1[0][0] = 1;
    for(int i = 1 ; i <= 200 ; ++ i)
        for(int j = 0 ; j <= i ; ++j)
            s1[i][j] = (s1[i-1][j-1] - (i-1)*s1[i-1][j]) % MOD;
}
void Stirling2(){
    s2[0][0] = 1;
    for(int i = 1 ; i <= 200 ; ++ i)
        for(int j = 0 ; j <= i ; ++j)
            s2[i][j] = (s2[i-1][j-1] + j*s2[i-1][j]) % MOD;
}

int main(){
    Stirling1();
    Stirling2();
    f >> T;
    for(int t = 1 ; t <= T ; ++t){
        f >> x >> n >> m;
        if(x == 1)
            g << s1[n][m] << endl;
        else g << s2[n][m] << endl;
    }

    return 0;
}
