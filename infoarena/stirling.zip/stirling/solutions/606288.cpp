#include<fstream.h>
#define N 201
int t,n,m,k,i,j,s[N][N],S[N][N];
int main()
{ifstream f("stirling.in");
ofstream g("stirling.out");
f>>t;
for(i=1;i<N;i++)
      for(j=1;j<N;j++)
      if(i>j)
              s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%98999,S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%98999;
      else
              if(i<j)
                       s[i][j]=S[i][j]=0;
              else
                       s[i][j]=S[i][j]=1;
while(t--)
      {f>>k>>n>>m;
      if(k==1)
              g<<s[n][m]<<"\n";
      else
              g<<S[n][m]<<"\n";}
return 0;}
