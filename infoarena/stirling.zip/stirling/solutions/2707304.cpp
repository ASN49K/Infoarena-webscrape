//Ilie Dumitru
#include<cstdio>
#define mod 98999

int N, M, s[201][201], S[201][201];

void comp()
{
    int i, j;
    s[1][1]=S[1][1]=1;
    for(i=2;i<201;++i)
        for(j=1;j<=i;++j)
        {
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%mod;
            S[i][j]=(S[i-1][j-1]+S[i-1][j]*j)%mod;
        }
}

int main()
{
    comp();
    int T, a, b, c;
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);
    scanf("%i", &T);
    while(T--)
    {
        scanf("%i%i%i", &a, &b, &c);
        if(a==1)
        {
            if((b-c)&1)
                printf("-");
            printf("%i\n", s[b][c]);
        }
        else
            printf("%i\n", S[b][c]);
    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}