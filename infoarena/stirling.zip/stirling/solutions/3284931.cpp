﻿#include <fstream>
#define mod 98999
using namespace std;


ifstream fin("stirling.in");
ofstream fout("stirling.out");

int t;
int speta, n, m;
int s[201][201], s2[201][201];

void calc()
{
    for (int i = 2; i <= 200; i++)
    {
        for (int j = 2; j <= i; j++)
        {
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j])%mod;
            s2[i][j] = (s2[i - 1][j - 1] + j * s2[i - 1][j])%mod;
        }
    }
}

int main()
{
    fin >> t;
    for (int i = 1; i <= t; i++)
    {
        fin >> speta >> n >> m;
        if (speta == 1)
        {
            fout << s[n][m]<<"\n";
        }
        else
        {
            fout << s2[n][m]<<"\n";
        }
    }
    return 0;
}