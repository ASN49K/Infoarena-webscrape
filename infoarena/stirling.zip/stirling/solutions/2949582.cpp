#include <fstream>

using namespace std;
const int nmax = 200;
const int mod = 98999;
int dp[2][nmax + 1][nmax + 1];
ifstream fin ( "stirling.in" );
ofstream fout ( "stirling.out" );
int main() {
    dp[0][1][1] = dp[1][1][1] = 1;
    for ( int i = 2; i <= nmax; i++ )
        for ( int j = 1; j <= i; j++ ) {
            dp[0][i][j] = ( dp[0][i - 1][j - 1] - ( i - 1 ) * dp[0][i - 1][j] % mod ) % mod;
            dp[1][i][j] = ( dp[1][i - 1][j] + j * dp[1][i - 1][j] % mod ) % mod;
        }
    int q, s, a, b;
    fin >> q;
    while ( q-- ) {
        fin >> s >> a >> b;
        fout << dp[s - 1][a][b] << '\n';
    }

    return 0;
}
