#include <fstream>
#define DMAX 201

std::ifstream fin("stirling.in");
std::ofstream fout("stirling.out");

long long int s[DMAX][DMAX];
long long int S[DMAX][DMAX];

int main() {
    int t;
    int x, n, k;

    s[0][0] = S[0][0] = 1;
    for (int i = 1; i < DMAX; i++) {
        s[i][i] = S[i][i] = 1;
        for (int j = 1; j < i; j++) {
            s[i][j] = s[i - 1][j - 1] - s[i - 1][j] * (i - 1);
            S[i][j] = S[i - 1][j - 1] + S[i - 1][j] * j;
        }
    }

    fin >> t;
    while (t--) {
        fin >> x >> n >> k;
        fout << (x == 1 ? s[n][k] : S[n][k]) << '\n';
    }

    fout.close();
    return 0;
}
