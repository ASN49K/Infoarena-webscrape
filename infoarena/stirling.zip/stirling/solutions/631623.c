#include <stdio.h>
#define NMAX 201
#define MOD 98999

int s[NMAX][NMAX], S[NMAX][NMAX];
    
void precalc_S()
{
    int i, j;
    S[1][1] = 1;
    for (i=2; i<NMAX; ++i)
	for (j=1; j<=i; ++j)
	    S[i][j] = (S[i-1][j-1] + j*S[i-1][j])%MOD;
}

void precalc_s()
{
    int i, j;
    s[1][1] = 1;
    for (i=2; i<NMAX; ++i)
	for (j=1; j<=i; ++j)
	    s[i][j] = (s[i-1][j-1] - (i-1)*s[i-1][j])%MOD;
}

int main()
{
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);
    int m, n, x, t;
    precalc_S();
    precalc_s();

    scanf("%d", &t);
    while (t--) {
	scanf("%d %d %d", &x, &m, &n);
	if (x == 1)
	    printf("%d\n", s[m][n]);
	else
	    printf("%d\n", S[m][n]);
    }
    return 0;
}
