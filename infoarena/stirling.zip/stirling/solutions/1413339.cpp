#include <fstream>
using namespace std;

const int MAX_N = 202;
const int MOD = 98999;

int T;
int S1[MAX_N][MAX_N], S2[MAX_N][MAX_N];

int computeS1(int n, int m) {
    if(S1[n][m] != -1) {
        return S1[n][m];
    }

    if(n < m || !n || !m) {
        S1[n][m] = 0;

        return S1[n][m];
    }

    if(n == 1 && m == 1) {
        S1[n][m] = 1;

        return S1[n][m];
    }

    S1[n][m] = (computeS1(n - 1, m - 1) - (n - 1) * computeS1(n - 1, m)) % MOD;

    return S1[n][m];
}

int computeS2(int n, int m) {
    if(S2[n][m] != -1) {
        return S2[n][m];
    }

    if(n < m || !n || !m) {
        S2[n][m] = 0;

        return S2[n][m];
    }

    if(n == 1 && m == 1) {
        S2[n][m] = 1;

        return S2[n][m];
    }

    S2[n][m] = (computeS2(n - 1, m - 1) + m * computeS2(n - 1, m)) % MOD;

    return S2[n][m];
}

int main() {
    ifstream f("stirling.in");
    ofstream g("stirling.out");

    for(int i = 0; i < MAX_N; ++i) {
        for(int j = 0; j < MAX_N; ++j) {
            S1[i][j] = S2[i][j] = -1;
        }
    }

    f >> T;
    for(int t = 1; t <= T; ++t) {
        int s, n, m;

        f >> s >> n >> m;

        if(s == 1) {
            g << computeS1(n, m) << "\n";
        }
        else {
            g << computeS2(n, m) << "\n";
        }
    }

    f.close();
    g.close();

    return 0;
}
