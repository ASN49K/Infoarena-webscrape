#include <bits/stdc++.h>
#define moduletz 98999
using namespace std;
const int mx = 205;
ifstream in("stirling.in");
ofstream out("stirling.out");
int s[205][205], S[205][205];
void precalculare_s() {
  s[1][1] = 1;
  for (int i = 2; i < mx; i++) {
    for (int j = 1; j <= i; j++) {
      s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % moduletz;
    }
  }
}
void precalculare_S() {
  S[1][1] = 1;
  for (int i = 2; i < mx; i++) {
    for (int j = 1; j <= i; j++) {
      S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % moduletz;
    }
  }
}
int main() {
  precalculare_s();
  precalculare_S();
  int t;
  in >> t;
  while(t--) {
    int speta, n, k;
    in >> speta >> n >> k;
    if (speta == 1) {
      out << s[n][k] << "\n";
    }
    else {
      out << S[n][k] << "\n";
    }
  }
  return 0;
}
