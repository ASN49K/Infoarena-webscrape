#include <fstream>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

const int mod = 98999;
int n, i, j, s[2][203][203], t;

int main() {
    f >> n;
    s[0][1][1] = s[1][1][1] = 1;
    for (i = 2; i <= 200; i++)
        for (j = 1; j <= i; j++) {
            s[0][i][j] = (s[0][i-1][j-1]-((i-1)*s[0][i-1][j])%mod)%mod;
            s[1][i][j] = (s[1][i-1][j-1]+j*s[1][i-1][j])%mod;
        }

    while (n--) {
        f >> t >> i >> j;
        g << s[t-1][i][j]%mod<<'\n';
    }
    return 0;
}
