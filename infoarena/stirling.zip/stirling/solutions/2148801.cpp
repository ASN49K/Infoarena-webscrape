#include <iostream>
#include <fstream>

using namespace std;

unsigned short int T, V, n, m;
long long int t;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

long long int Stirling1(unsigned short int a, unsigned short int b) {
    if (a == 0 && b == 0) return 1;
    if (a == 0 || b == 0) return 0;
    return (Stirling1(a - 1, b - 1) - ((a - 1) * Stirling1(a - 1, b)));
}

unsigned long long int Stirling2(unsigned short int a, unsigned short int b) {
    if (a == 0 && b == 0) return 1;
    if (a == 0 || b == 0) return 0;
    return (b * Stirling2(a - 1, b) + Stirling2(a - 1, b - 1));
}

int main()
{
    unsigned short int i, j;
    fin >> T;
    for (i = 1; i <= T; i++) {
        fin >> V;
        fin >> n >> m;
        if (V == 1) t = Stirling1(n, m);
        else t = Stirling2(n, m);
        fout << t << "\n";
    }
    return 0;
}
