#include <bits/stdc++.h>

#define MaxN 205
#define MOD  98999
typedef void ((*void_ptr)());

std::ifstream InFile("stirling.in");
std::ofstream OutFile("stirling.out");

int Q;
int Stirling1[MaxN][MaxN],
    Stirling2[MaxN][MaxN];
void_ptr Query[2];

void Precompute() {
    Stirling1[1][1] = Stirling2[1][1] = 1;
    for (int i=2, j; i<MaxN; ++i)
        for (j=1; j<=i; ++j)
            Stirling1[i][j] = (Stirling1[i-1][j-1] - Stirling1[i-1][j]*(i-1)) % MOD,
            Stirling2[i][j] = (Stirling2[i-1][j-1] + Stirling2[i-1][j]*(j)) % MOD;
}

int x, y;
inline void Query1() {
    InFile >> x >> y;
    OutFile << Stirling1[x][y] << '\n';
}
inline void Query2() {
    InFile >> x >> y;
    OutFile << Stirling2[x][y] << '\n';
}

void Citire() {
    InFile >> Q;
}

void Rezolvare() {
    Precompute();
    Query[0] = &Query1;
    Query[1] = &Query2;

    int Type;
    while (Q--)
        InFile >> Type,
        Query[Type-1]();
}

int main()
{
    Citire();
    Rezolvare();

    return 0;
}
