#include <fstream>
#define VMAX 201
#define MOD 98999
using namespace std;
ifstream cin("stirling.in");
ofstream cout("stirling.out");

int stirI[VMAX][VMAX], stirII[VMAX][VMAX], t, stir, n, m;

void preCalcI();
void preCalcII();

int main()
{
    int i;
    preCalcI();
    preCalcII();
    cin >> t;
    for (i=1; i<=t; i++)
    {
        cin >> stir>> n>> m;
        if (stir==1) cout << stirI[n][m]%MOD<< '\n';
            else cout << stirII[n][m]%MOD<< '\n';
    }
    return 0;
}

void preCalcI()
{
    int i, j;
    stirI[1][1]=1;
    for (i=2; i<VMAX; i++)
    {
        for (j=1; j<i; j++) stirI[i][j]=stirI[i-1][j-1]%MOD-((i-1)*(stirI[i-1][j]%MOD))%MOD;
        stirI[i][j]=1;
    }
}

void preCalcII()
{
    int i, j;
    stirII[1][1]=1;
    for (i=2; i<VMAX; i++)
    {
        for (j=1; j<i; j++) stirII[i][j]=stirII[i-1][j-1]%MOD+j*(stirII[i-1][j]%MOD);
        stirII[i][j]=1;
    }
}
