#include <fstream>
#define MOD  98999
using namespace std ;

const int NMAX = 201;


ifstream fin("stirling.in") ;
ofstream fout("stirling.out") ;

int T, N, M, X, s[NMAX][NMAX], S[NMAX][NMAX];

static inline void speta_unu()
{
    s[1][1] = 1 ;

    for(int i = 2 ; i < NMAX ; ++ i)
        for(int j = 1 ; j <= i ; ++ j)
            s[i][j] = (s[i - 1][j - 1] - (i - 1)* s[i - 1 ][j]) % MOD ;

}

static inline void speta_doi()
{
    S[1][1] = 1 ;

     for(int i = 2 ; i < NMAX ; ++ i)
        for(int j = 1 ; j <= i ; ++ j)
            S[i][j] = (S[i - 1][j - 1] + j* S[i - 1 ][j]) % MOD ;
}

int main()
{
    fin >> T ;

    speta_unu() ;
    speta_doi() ;

    while(T --)
    {
            fin >> X >> N >> M ;
            if(X == 1)
               fout << s[N][M] << '\n' ;
            if(X == 2)
                fout << S[N][M] << '\n' ;


    }

    fin.close() ;
    fout.close() ;
    return  0 ;
}
