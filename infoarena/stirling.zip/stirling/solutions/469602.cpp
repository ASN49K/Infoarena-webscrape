#include <cstdio>

#define REST 98999
#define LIM 201
int s[LIM][LIM],S[LIM][LIM];

void sS() {
	int i,j;
	for(i=2; i<LIM; i++)
		for(j=1; j<=i; j++) {
			s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%REST;
			S[i][j]=(S[i-1][j-1]+j*S[i-1][j] )%REST;
		}
}

int main()
{
	int x,y,t,z;
	enum op{nimic,Speta1,Speta2};
	op a;
	freopen("stirling.in","r",stdin);
	freopen("stirling.out","w",stdout);
	s[1][1]=S[1][1]=1;
	sS();
	for(scanf("%d",&t);t--; ) {
		scanf("%d %d %d",&x,&y,&z);
		a=op(x);
		if(a==Speta1) printf("%d\n",s[y][z]);
		else printf("%d\n",S[y][z]);
	}
	return 0;
}
