#include <fstream>

using namespace std;

ifstream fin("stirling.in");
ofstream fout("stirling.out");

int T;
int x, n, m;

int stirling1(int n, int k) {
    if(n == 0 && k == 0) {
        return 1;
    } else if(n == 0 && k > 0) {
        return 0;
    } else if(n > 0 && k == 0) {
        return 0;
    } else {
        return stirling1(n - 1, k - 1) + (n - 1) * stirling1(n - 1, k);
    }
}

int stirling2(int n, int k) {
    if(n == 0 && k == 0) {
        return 1;
    } else if(n == 0 && k > 0) {
        return 0;
    } else if(n > 0 && k == 0) {
        return 0;
    } else {
        return stirling2(n - 1, k - 1) + k * stirling2(n - 1, k);
    }
}

int main() {
    fin >> T;
    for(int i = 1; i <= T; i++) {
        fin >> x >> n >> m;
        switch(x) {
            case 1: {
                fout << stirling1(n, m) % 98999 << endl;
                break;
            }
            case 2: {
                fout << stirling2(n, m) % 98999 << endl;
                break;
            }
        }
    }
    fin.close();
    fout.close();
    return 0;
}