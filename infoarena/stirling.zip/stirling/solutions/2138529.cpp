#include <bits/stdc++.h>
#define INFILE "stirling.in"
#define OUTFILE "stirling.out"
using namespace std;
ifstream in(INFILE);
ofstream out(OUTFILE);
const int NMAX=201;
const int MOD=98999;
typedef pair<int,pair<int,int>> querry;
array<array<int,NMAX>,NMAX> S1;
array<array<int,NMAX>,NMAX> S2;
int T;
int N1,M1,N2,M2;
vector<querry> Querries;
querry CreateQuerry(int tip,int n,int m){
    querry q=make_pair(tip,make_pair(n,m));
    return q;
}

void GenerateS1(int n,int m){
    S1[1][1]=1;
    for(int i=2;i<=n;i++){
        for(int j=1;j<=i&&j<=m;j++){
            S1[i][j]=(-1*(i-1)*S1[i-1][j]+S1[i-1][j-1])%MOD;
        }
    }
}
void GenerateS2(int n,int m){
    S2[0][0]=1;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=i&&j<=m;j++){
            S2[i][j]=(j*S2[i-1][j]+S2[i-1][j-1])%MOD;
        }
    }
}

void Read(){
    in>>T;
    for(int i=1;i<=T;i++){
        int tip,n,m;
        in>>tip>>n>>m;
        Querries.push_back(CreateQuerry(tip,n,m));
        if(tip==1){
            N1=max(N1,n);
            M1=max(M1,m);
        }
        else if(tip==2){
            N2=max(N2,n);
            M2=max(M2,m);
        }
    }
    GenerateS1(N1,M1);
    GenerateS2(N2,M2);
}

void Afisare(){
    for(auto q:Querries){
        if(q.first==1){
            out<<S1[q.second.first][q.second.second]<<"\n";
        }
        else{
            out<<S2[q.second.first][q.second.second]<<"\n";
        }
    }
}

void AfisStriling(){
    cout<<"Speta1\n";
    for(int i=0;i<=N1;i++){
        for(int j=0;j<=min(i,M1);j++){
            cout<<setw(4)<<S1[i][j]<<" ";
        }
        cout<<"\n";
    }
    cout<<"Speta2\n";
    for(int i=0;i<=N2;i++){
        for(int j=0;j<=min(i,M2);j++){
            cout<<setw(4)<<S2[i][j]<<" ";
        }
        cout<<"\n";
    }

}

int main()
{
    Read();
    Afisare();
   // AfisStriling();
    return 0;
}
