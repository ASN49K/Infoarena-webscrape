#include <fstream>
#define MOD 98999
#define LIMIT 200

using namespace std;

int s[205][205], S[205][205];

void stirling1()
{
    s[1][1] = 1;
    for(int i = 2; i <= LIMIT; i++)
    {
        for(int j = 1; j <= i; j++)
        {
            s[i][j] = (s[i-1][j-1] - s[i-1][j] * (i - 1)) % MOD;
        }
    }
}

void stirling2()
{
    S[1][1] = 1;
    for(int i = 2; i <= LIMIT; i++)
    {
        for(int j = 1; j <= i; j++)
        {
            S[i][j] = (S[i-1][j-1] + S[i-1][j] * j) % MOD;
        }
    }
}

int main()
{
    /// stirling de speta I
    /// 1. fara semn
    /// 1.1 in cate moduri pot distribui N persoane in M taxiuri, contand cine dupa cine intra
    /// 1.2 formal nr de permutari cu exact M cicluri (fiecare taxi e un ciclu)
    /// 1.3 recurenta: s[n][m] = s[n-1][m-1] + s[n-1][m] * (n-1)

    /// 2. cu semn
    /// 2.1 speţa I, s(n,m), ca fiind coeficienţii dezvoltării  x(x-1)...(x-n+1) = (suma de la m=0, m<=n) s(n,m) * x^k
    /// 2.2 recurenta s[n][m] = s[n-1][m-1] - s[n-1][m] * (n-1)


    /// stirling de speta II S[n][m] = S[n-1][m-1] + S[n-1][m] * m
    ///in cate moduri pot distribui N persoane in M taxiuri :) (contand doar ce persoane in ce taxiuri sunt la final)
    /// formal speţa a II-a, S(n,m), ca fiind numărul de partiţionări ale unei mulţimi de n elemente în m submulţimi nevide.

    ifstream cin("stirling.in");
    ofstream cout("stirling.out");

    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    stirling1();
    stirling2();

    int T,X,N,M;
    cin>>T;
    while(T--)
    {
        cin>>X>>N>>M;
        if(X == 1)
        {
            cout<<s[N][M]<<'\n';
        }
        else
        {
            cout<<S[N][M]<<'\n';
        }
    }
    return 0;
}
