#include <fstream>

using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int x, n , m, dis1[250][250], dis2[250][250], i, j, t;
int main()
{
    f>>t;
  n=200; m=200;
  dis1[1][1]=1;
  dis2[1][1]=1;
  for(i=2; i<=n; i++)
  {
      for(j=1; j<=i; j++)
      {
          dis1[i][j]=(dis1[i-1][j-1]-dis1[i-1][j]*(i-1))%98999;
          dis2[i][j]=(dis2[i-1][j-1]+dis2[i-1][j]*j)%98999;
      }
  }

  for(i=1; i<=t; i++)
  {
f>>x>>n>>m;
  if(x==1)
    g<<dis1[n][m]<<"\n";
  else
  g<<dis2[n][m]<<"\n";
  }

    return 0;
}
