#include <iostream>
#include <fstream>
#define Mod 98999
#define DM 203

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int dp[DM][DM], dpp[DM][DM], i, j, n, a, m, x;
void sp1()
{
    for(int i=2; i<DM; i++)
    {
        for(int j=1; j<=i; j++)
            dp[i][j]=(dp[i-1][j-1]-(i-1)*dp[i-1][j])%Mod;
    }
}
void sp2()
{
    for(int i=2; i<DM; i++)
    {
        for(iny j=1; j<=i; j++)
        {
            dpp[i][j]=(dpp[i-1][j-1]-(i-1)*dpp[i-1][j])%Mod;
        }
    }
}

int main()
{
    f>>a;
    sp1();
    sp2();
    for(i=1; i<=a; i++)
    {
        f>>x>>n>>m;
        if(x==1)
        {
            g<<dp[n][m]<<'\n';
        }
        else if(x==2)
        {
            g<<dpp[n][m]<<'\n';
        }
    }
    return 0;
}
