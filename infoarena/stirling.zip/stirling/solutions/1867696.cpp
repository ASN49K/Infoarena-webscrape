#include <stdio.h>

using namespace std;
FILE*f=fopen("stirling.in","r");
FILE*g=fopen("stirling.out","w");
int t,a[201][201],n,i,j,s[201][201];
int main()
{fscanf(f,"%d",&t);
for(i=1;i<=200;i++) s[i][1]=s[i][i]=1;
for(i=1;i<=200;i++)
for(j=2;j<=200;j++){

    s[i][j]=(s[i-1][j-1]+j*s[i-1][j])%98999;


}
a[1][1]=1;
    for(i=2;i<=200;i++)
for(j=1;j<=i;j++){
    a[i][j]=(a[i-1][j-1]-(i-1)*a[i-1][j])%98999;


}
for(i=1;i<=t;i++){
  int x,y,z;
  fscanf(f,"%d%d%d",&x,&y,&z);
  if(x==1) fprintf(g,"%d\n",a[y][z]);
    else fprintf(g,"%d\n",s[y][z]);


}
    fclose(f);
    fclose(g);

    return 0;
}
