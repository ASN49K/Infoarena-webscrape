#include <fstream>
#define Xp 98999
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
int i,j,n,nr,m,caz,s[201][201],S[201][201];
int main()
{
    f>>nr;
    s[1][1]=S[1][1]=1;
    for(i=2;i<=200;++i)
        for(j=1;j<=200;++j) s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%Xp;
    for(i=2;i<=200;++i)
        for(j=1;j<=200;++j) S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%Xp;
    while(nr--)
    {
        f>>caz>>n>>m;
        if(caz==1) g<<s[n][m]<<'\n';
            else g<<S[n][m]<<'\n';
    }
    g.close();
    return 0;
}
