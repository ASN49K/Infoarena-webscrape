/// speta 1: s(n,k)=s(n-1, k-1)+(n-1)*s(n-1, k)
///          s(1,1)=1
///          s(n, 0)=0

/// speta 2: s(n,k)=s(n-1,k-1)+k*s(n-1,k)
///          s(0,0)=1
///          s(n,0)=s(0,n)=0
///          s(n,1)=1

#include <iostream>
#include <fstream>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

int s[201][201];

void setare0(int s[][201])
{
    int i, j;
    for(i=1; i<=200; i++)
        for(j=1; j<=200; j++)
            s[i][j]=0;
}

void stirling1(int n, int k)
{
    int i, j;
    s[1][1]=1;
    //for(i=0; i<=n; i++)
        //s[i][0]=0;
    for(i=1; i<=n; i++)
        for(j=1; j<=min(i, k); j++)
            if(s[i][j]==0)
                s[i][j]=s[i-1][j-1]-(i-1)*s[i-1][j];
    cout<<s[n][k]<<'\n';

}

void stirling2(int n, int k)
{
    int i, j;
    s[1][1]=1;
    for(i=0; i<=n; i++)
        s[i][0]=0;
    for(i=1; i<=n; i++)
        for(j=1; j<=min(i, k); j++)
            if(s[i][j]==0)
                s[i][j]=s[i-1][j-1]+j*s[i-1][j];
    cout<<s[n][k]<<'\n';
}

int main()
{
    int i, T, x, n, k;
    cin>>T;
    for(i=1; i<=T; i++)
    {
        cin>>x>>n>>k;
        setare0(s);
        if(x==1)
            stirling1(n, k);
        else
            stirling2(n, k);
    }
    return 0;
}
