#include <bits/stdc++.h>
#define int long long
using namespace std;
ifstream f("stirling.in");
ofstream g("stirling.out");
const int mod=98999;
int dp[209][209], dp2[209][209];
signed main ()
{
    dp[0][0]=1;
    for (int i=0; i<=200; i++)
    {
        for (int j=0; j<=200; j++)
        {
            dp[i+1][j]=(-i*dp[i][j]+dp[i][j-1])%mod;
        }
    }
    //cout << dp[3][2];
    for (int i=0; i<=200; i++)
        dp2[i][i]=1;
    for (int i=0; i<=200; i++)
    {
        for (int j=1; j<=200; j++)
            dp2[i+1][j]=(j*dp2[i][j]+dp2[i][j-1])%mod;
    }
    int q;
    f >> q;
    while (q--)
    {
        int tip;
        f >> tip;
        int x, y;
        f >> x >> y;
        if (tip==1) g << dp[x][y]<<'\n';
        else g << dp2[x][y]<<'\n';
    }
}
