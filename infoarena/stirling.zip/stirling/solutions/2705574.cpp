#include <fstream>
#include <iostream>
using namespace std;

int s[201][201];
int S[201][201];
int n, m;
const int MOD = 98999;

void speta1() {
    int i, j;
    s[1][1] = 1;
    for (i = 2; i <= 200; i++)
        for (j = 1; j <= i; j++)
            s[i][j] = (s[i - 1][j - 1] - (i - 1) * s[i - 1][j]) % MOD;
}

void speta2() {
    int i, j;
    S[1][1] = 1;
    for (i = 2; i <= 200; i++)
        for (j = 1; j <= i; j++)
            S[i][j] = (S[i - 1][j - 1] + j * S[i - 1][j]) % MOD;
}

int main() {
    int t, x, y, sp;

    speta1();
    speta2();

    ifstream f("stirling.in");
    ofstream g("stirling.out");

    f >> t;
    while (t--) {
        f >> sp >> x >> y;
        if (sp == 1)
            g << s[x][y] << '\n';
        else g << S[x][y] << '\n';
    }
    f.close();
    g.close();
    return 0;
}