#include <bits/stdc++.h>
using namespace std;
ifstream in("stirling.in");
ofstream out("stirling.out");
const int N=201,M=98999;
int t,n,x,m,s1[N][N],s2[N][N];

int main()
{
    s1[1][1]=s2[1][1]=1;
    for(int i=2;i<N;++i)
        for(int j=1;j<=i;++j)
            s1[i][j]=(s1[i-1][j-1]-(i-1)*s1[i-1][j])%M,s2[i][j]=(s2[i-1][j-1]+j*s2[i-1][j])%M;
    in>>t;
    for(;t>0;t--)
    {
        in>>x>>n>>m;
        if(x==1)out<<s1[n][m]<<'\n';
        else out<<s2[n][m]<<'\n';
    }

    return 0;
}
