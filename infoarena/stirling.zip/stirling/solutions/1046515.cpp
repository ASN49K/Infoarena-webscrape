#include<cstdio>
using namespace std;
int T,x,n,m,i,j;
int s[205][205];
int S[205][205];
int main()
{
    freopen("stirling.in","r",stdin);
    freopen("stirling.out","w",stdout);

    s[1][1]=S[1][1]=1;
    for(i=2;i<=200;i++)
        for(j=1;j<=i;j++)
        {
            s[i][j]=s[i-1][j-1] - (i-1)*s[i-1][j];
            S[i][j]=S[i-1][j-1] + j*S[i-1][j];
        }

    scanf("%d",&T);
    for(;T;--T)
    {
        scanf("%d%d%d",&x,&n,&m);
        if(x==1) printf("%d\n",s[n][m]);
        if(x==2) printf("%d\n",S[n][m]);
    }
    return 0;
}
