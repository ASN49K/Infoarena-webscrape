#include <bits/stdc++.h>
#define MOD 98999

using namespace std;
ifstream fin("stirling.in");
ofstream fout("stirling.out");
typedef long long ll;

ll s1[205][205], s2[205][205];
int t, n, m;

int main()
{

    s1[1][1] = s2[1][1] = 1LL;

    for(int i = 2; i <= 200; ++i){
        for(int j = 1; j <= i; ++j){
            s1[i][j] = (s1[i - 1][j - 1] - (1LL * (i - 1) * s1[i - 1][j]) % MOD) % MOD;
            s2[i][j] = (s2[i - 1][j - 1] + (1LL * j * s2[i - 1][j]) % MOD) % MOD;
        }
    }

    fin >> t;
    while(t--){
        int type;
        fin >> type >> n >> m;

        fout << (type == 1 ? s1[n][m] : s2[n][m]) << "\n";
    }

    return 0;
}
