#include <cstdio>
#define NMAX 201
#define mod 98999
using namespace std;
FILE *f1=fopen("stirling.in","r"),*f2=fopen("stirling.out","w");
int s[NMAX][NMAX],S[NMAX][NMAX],n,m,t,o;
void calcul()
{
    s[1][1]=1;
    for(int i=2;i<NMAX;i++)
        for(int j=1;j<=i;j++)
    s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%mod;

    S[1][1]=1;
    for(int i=2;i<NMAX;i++)
        for(int j=1;j<=i;j++)
        S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%mod;
}
int main()
{
    calcul();
    fscanf(f1,"%d",&t);
    for(;t;t--)
    {
        fscanf(f1,"%d%d%d",&o,&n,&m);
        if(o==1)fprintf(f2,"%d\n",s[n][m]);
        else fprintf(f2,"%d\n",S[n][m]);
    }
    fclose(f1);
    fclose(f2);
    return 0;
}
