#include <iostream>
#include <vector>

using namespace std;

const int MOD = 98999;
const int MAX_N = 200;

// Function to precompute Stirling numbers of both kinds
void precomputeStirlingNumbers(vector<vector<int>>& s, vector<vector<int>>& S) {
    s[0][0] = 1;
    S[0][0] = 1;

    for (int n = 1; n <= MAX_N; ++n) {
        s[n][0] = 0;
        S[n][0] = 0;
        for (int m = 1; m <= n; ++m) {
            s[n][m] = (s[n-1][m-1] - (n-1) * s[n-1][m] % MOD + MOD) % MOD;
            S[n][m] = (S[n-1][m-1] + m * S[n-1][m] % MOD) % MOD;
        }
    }
}

int main() {
    freopen("stirling.in", "r", stdin);
    freopen("stirling.out", "w", stdout);

    int T;
    cin >> T;

    vector<vector<int>> s(MAX_N + 1, vector<int>(MAX_N + 1, 0));
    vector<vector<int>> S(MAX_N + 1, vector<int>(MAX_N + 1, 0));

    precomputeStirlingNumbers(s, S);

    while (T--) {
        int x, n, m;
        cin >> x >> n >> m;

        if (x == 1) {
            cout << s[n][m] << endl;
        } else {
            cout << S[n][m] << endl;
        }
    }

    return 0;
}
