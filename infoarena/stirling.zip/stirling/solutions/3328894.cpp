#include <bits/stdc++.h>
#define MAX 201
#define MOD 98999
using namespace std;

int s[201][201], S[201][201];

void precalc()
{
    ///s(i, j)
    s[0][0]=1;
    for(int i=1; i<MAX; i++)
        for(int j=1; j<=i; j++)
            s[i][j]=(s[i-1][j-1]-(i-1)*s[i-1][j])%MOD;

    ///S(i, j)
    S[0][0]=1;
    for(int i=1; i<MAX; i++)
        for(int j=1; j<=i; j++)
            S[i][j]=(S[i-1][j-1]+j*S[i-1][j])%MOD;
}

int main()
{
    ifstream fin("stirling.in");
    ofstream fout("stirling.out");
    precalc();
    int t;
    fin >> t;
    while(t--)
    {
        int x, n, m;
        fin >> x >> n >> m;
        if(x==1) fout << s[n][m] << "\n";
        else fout << S[n][m] << "\n";
    }
    fin.close();
    fout.close();
    return 0;
}
