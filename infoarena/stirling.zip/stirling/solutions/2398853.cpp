#include <iostream>
#include <fstream>

using namespace std;

ifstream f("stirling.in");
ofstream g("stirling.out");

long long s[203][203], S[203][203];
int n, m, t, x;

void preprocess() {

    s[0][0] = 1;
    S[0][0] = 1;

    for (int i = 1; i <= 200; i++) {
        s[i][0] = 0;
        s[0][i] = 0;
        s[i][i] = 1;

        S[i][0] = 0;
        S[i][1] = 1;
        S[i][i] = 1;
    }

    for (int i = 1; i <= 200; i++) {
        for (int j = 1; j < i; j++) {
            s[i][j] = s[i - 1][j - 1] - (i - 1) * s[i - 1][j];
            S[i][j] = j * S[i - 1][j] + S[i - 1][j - 1];
        }
    }
}

int main()
{
    preprocess();

    f >> t;
    for (int i = 0; i < t; i++) {
        f >> x >> n >> m;
        if (x == 1) {
            g << s[n][m] << "\n";
        }
        else if (x == 2) {
            g << S[n][m] << "\n";
        }
    }


    f.close();
    g.close();
    return 0;
}

