#include <iostream>
#include <fstream>

#define MAX 201
#define MOD 98999

using namespace std;

int s[MAX][MAX], S[MAX][MAX];

ifstream f("stirling.in");
ofstream g("stirling.out");

void compute_s(){
	s[1][1] = 1;
	for (int i = 2; i < MAX; i++)
		s[i][1] = (-s[i-1][1] * (i - 1)) % MOD;

	for (int i = 1; i < MAX; i++){
		for (int j = 2; j < MAX; j++){
			s[i][j] = (s[i-1][j-1] - (i - 1) * s[i-1][j]) % MOD;
		}
	}
}

void compute_S(){
	for (int i = 1; i < MAX; i++)
		S[i][1] = 1;

	for (int i = 1; i < MAX; i++){
		for (int j = 2; j < MAX; j++){
			S[i][j] = (S[i-1][j-1] + j * S[i-1][j]) % MOD;
		}
	}
}

void stirlingI(int n, int m){
	g << s[n][m] << '\n';
}

void stirlingII(int n, int m){
	g << S[n][m] << '\n';
}

int main() {
	int tests, n, m, type;
	compute_s();
	compute_S();
	f >> tests;
	while (tests > 0){
		f >> type >> n >> m;
		if (type == 1)
			stirlingI(n, m);
		else
			stirlingII(n, m);
		tests--;
	}

	f.close();
	g.close();
	return 0;
}
