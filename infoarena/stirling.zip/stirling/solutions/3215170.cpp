#include <fstream>

using namespace std;

ifstream cin("stirling.in");
ofstream cout("stirling.out");

int a1[205][205], a2[205][205];

int main() {
	int t;
	cin >> t;
	a1[1][1] = a2[1][1] = 1;
	for (int i = 1; i <= 200; i++) {
		for (int j = 1; j <= 200; j++) {
			if (i != 1 || j != 1) {
				a1[i][j] = a1[i - 1][j - 1] - (i - 1) * a1[i - 1][j];
				a2[i][j] = a2[i - 1][j - 1] + j * a2[i - 1][j];
			}
		}
	}
	while (t--) {
		int cer, n, m;
		cin >> cer >> n >> m;
		if (cer == 1)
			cout << a1[n][m] << '\n';
		else cout << a2[n][m] << '\n';
	}
}