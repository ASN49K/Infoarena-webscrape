#include <iostream>
#include <fstream>
#include <cstring>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

const int maxN = 1005, inf = 0x3f3f3f3f;
int cap[maxN][maxN], flux[maxN][maxN], p[maxN];
int n, m, max_flux;
vector <int> G[maxN];
queue <int> q;

bool bfs()
{
    memset(p, 0, sizeof p);
    while(!q.empty())
        q.pop();
    p[1] = 1;
    q.push(1);
    while(!q.empty())
    {
        int nod = q.front();
        q.pop();
        if(nod == n)
            return 1;
        for(int vecin : G[nod])
        {
            if(!p[vecin] && cap[nod][vecin] > flux[nod][vecin])
            {
                p[vecin] = nod;
                q.push(vecin);
            }
        }
    }
    return 0;
}

int main()
{
    fin >> n >> m;
    for(int i = 0; i < m; i++)
    {
        int a, b, c;
        fin >> a >> b >> c;
        cap[a][b] = c;
        G[a].push_back(b);
        G[b].push_back(a);
    }
    while(bfs())
    {
        int min_flux = inf;
        for(int x = n; x != 1; x = p[x])
            min_flux = min(min_flux, cap[p[x]][x] - flux[p[x]][x]);
        for(int x = n; x != 1; x = p[x])
        {
            flux[p[x]][x] += min_flux;
            flux[x][p[x]] -= min_flux;
        }
        max_flux += min_flux;
    }
    fout << max_flux;
    return 0;
}
