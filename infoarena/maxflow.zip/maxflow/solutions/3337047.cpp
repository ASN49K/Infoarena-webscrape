#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
int n, m, cap[1005][1005], flux[1005][1005];
vector<int>adj[1005];

vector<bool>viz(1005);
vector<int>tata(1005);

int bfs()
{
    queue<int>q;
    for(int i = 1; i <= n; i++)
        viz[i] = false;

    q.push(1);
    viz[1] = true;

    while(!q.empty())
    {
        int vf = q.front();
        q.pop();

        for(auto vecin : adj[vf])
        {
            if(!viz[vecin] && cap[vf][vecin] != flux[vf][vecin])
            {
                q.push(vecin);
                viz[vecin] = true;

                tata[vecin] = vf;
                if(vecin == n)
                    return 1;
            }
        }
    }

    return 0;

}
int main()
{
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int x, y, c;
        fin >> x >> y >> c;

        cap[x][y] = c;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    int fluxmaxim = 0;
    int fluxmin;

    while(bfs())
    {
        for(auto vecin : adj[n])
        {
            if(viz[vecin] && cap[vecin][n] != flux[vecin][n])
            {
                tata[n] = vecin;
                fluxmin = 1e9 + 1;
                for(int nod = n; nod != 1; nod = tata[nod])
                {
                    fluxmin = min(fluxmin, cap[tata[nod]][nod] - flux[tata[nod]][nod]);
                }

                for(int nod = n; nod != 1; nod = tata[nod])
                {
                    flux[tata[nod]][nod] += fluxmin;
                    flux[nod][tata[nod]] -= fluxmin;
                }

                fluxmaxim += fluxmin;
            }

        }
    }

    fout << fluxmaxim;
    return 0;
}
