#include <bits/stdc++.h>

using namespace std;

using ll = long long;
#define int ll

const int inf = 1e16;

struct Dinic
{
    struct Edge
    {
        int from, to, cap, prev;
    };
    vector<Edge> edges;
    vector<int> last;
    int n;

    Dinic(int N)
    {
        n = N;
        last.assign(n + 1, -1);
        alr.resize(n + 1, false);
    }

    void baga(int from, int to, int cap)
    {
        edges.push_back({from, to, cap, last[from]});
        last[from] = edges.size() - 1;

        edges.push_back({to, from, 0, last[to]});
        last[to] = edges.size() - 1;
    }

    vector<int> dist, block;
    vector<bool> alr;

    bool bfs(int src, int dest)
    {
        dist.assign(n + 1, inf);
        block = last;
        queue<int> q;
        q.push(src);
        dist[src] = 0;
        while(!q.empty())
        {
            int x = q.front();
            q.pop();
            for(int i = last[x]; i != -1; i = edges[i].prev)
            {
                if(edges[i].cap > 0 && dist[edges[i].to] > dist[x] + 1)
                    dist[edges[i].to] = dist[x] + 1,
                    q.push(edges[i].to);
            }
        }

        return dist[dest] != inf;
    }

    int dfs(int nod, int dest, int push)
    {
        if(push == 0 || alr[nod] == true)
            return 0;
        if(nod == dest)
            return push;

        alr[nod] = true;

        int real = 0;
        for(int i = block[nod]; i != -1; i = edges[i].prev)
        {
            block[nod] = i;
            if(edges[i].cap > 0 && dist[edges[i].to] > dist[nod])
            {
                int ps = dfs(edges[i].to, dest, min(push, edges[i].cap));

                edges[i].cap -= ps;
                edges[i ^ 1].cap += ps;

                push -= ps;
                real += ps;
            }

            if(edges[i].cap != 0)
                break;
        }

        alr[nod] = false;
        return real;
    }

    int maxFlow(int src, int dest)
    {
        int ans = 0;
        while(bfs(src, dest))
            ans += dfs(src, dest, inf);

        /*for(int i = 0; i < edges.size(); i += 4)
            cout << edges[i + 2].cap - edges[i].cap << '\n';*/

        return ans;
    }
};


signed main()
{
    ifstream cin("maxflow.in");
    ofstream cout("maxflow.out");

    int n, m;
    cin >> n >> m;
    Dinic ds(n);
    for(int i = 1; i <= m; i ++)
    {
        int f, t, c;
        cin >> f >> t >> c;
        ds.baga(f, t, c);
        //ds.baga(t, f, c);
    }
    cout << ds.maxFlow(1, n);
}
