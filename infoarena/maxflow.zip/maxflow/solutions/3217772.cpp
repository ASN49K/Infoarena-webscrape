#include <bits/stdc++.h>
//Soltan Cristian
#define fri(a, b) for (int i = (a); i < (b); ++i)
#define frj(a, b) for(int j = a; j < b; j++)
#define frk(a, b) for(int k = a; k < b; k++)
#define frm(a, b, i) for(int i = b; i >= a; i--)
#define ll long long
#define all(x) x.begin(), x.end()
#define mod 1000000007
#define pb push_back
#define st first
#define nd second
#define sz(x) (ll)x.size()
#define rall(x) x.rbegin(), x.rend()
#define ct(x) cout << x
#define cts(x) cout << x << ' '
#define ctn(x) cout << x << '\n'
#define Y cout << "YES" << '\n'
#define N cout << "NO" << '\n'
using namespace std;
using vi = vector<int>;
using vl = vector<ll>;
using vs = vector<string>;
using vb = vector<bool>;
using ml = map<ll, ll>;
using vii = vector<vector<int>>;
using vll = vector<vector<ll>>;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};
template <typename T>void read(T n, vector<T> &a){fri(0, n){cin >> a[i];}}
template<typename T>void print(T n, T m, vector<vector<T>> &dp){fri(0, n){ct('\n');frj(0, m){ct(setw(5));cts(dp[i][j]);}}}
 
 
const int mxa = 2 * 1e5 + 2;
// string __fname = "submultimi";  
// ifstream in(__fname + ".in"); 
// ofstream out (__fname + ".out"); 
// #define cin in 
// #define cout out
int n, m;
struct FlowEdge {
    int u, v;
    long long cap, flow = 0;
};
vector<vector<int>> adj;
vector<FlowEdge> edges;
vector<int> level;
vector<int> ptr;

bool bfs(){
    queue<int> q;
    q.push(1);
    level[1] = 0;
    while(!q.empty()){
        int u = q.front();
        q.pop();
        for(auto id : adj[u]){
            if(level[edges[id].v] == -1 && edges[id].cap - edges[id].flow > 0){
                level[edges[id].v] = level[u] + 1;
                q.push(edges[id].v);
            }
        }
    }
    return level[n] != -1;
}

ll dfs(int u, ll mxf){
    if(mxf == 0){
        return 0;
    }
    if(u == n){
        return mxf;
    }
    for(int& v = ptr[u]; v < sz(adj[u]); v++){
        int id = adj[u][v];
        if(level[edges[id].v] != level[u] + 1 || edges[id].cap - edges[id].flow < 1) continue;
        ll fl = dfs(edges[id].v, min(mxf, edges[id].cap - edges[id].flow));
        if(fl == 0){
            continue;
        }
        edges[id].flow += fl;
        edges[id ^ 1].flow -= fl; 
        return fl;
    }
    return 0;
}



void solve(){
    cin >> n >> m;
    adj.resize(n + 1);
    edges.resize(m * 2 + 1);
    int k = 0;
    for(int i = 0 ; i < m; i++){
        int a, b, c;
        cin >> a >> b >> c;
        adj[a].push_back(k);
        adj[b].push_back(k + 1);
        edges[k].u = a; edges[k].v = b;
        edges[k].cap = c;
        edges[k + 1].u = b; edges[k + 1].v = a;
        edges[k + 1].cap = 0;
        k += 2;

    }
    int rs = 0;
    level.resize(n + 1);
    ptr.resize(n + 1);
    while (true) {
        fill(level.begin(), level.end(), -1);
        if (!bfs())
            break;
        fill(ptr.begin(), ptr.end(), 0);
        while (long long pushed = dfs(1, 1e9)) {
            rs += pushed;
        }
    }
    cout << rs << '\n';
}
 
 
int main()
{   
    // ios_base::sync_with_stdio(0); cin.tie(0); ct(fixed); ct(setprecision(10)); 
    // int t;
    // cin >> t;
    // while(t--)
        solve();
    return 0;
}