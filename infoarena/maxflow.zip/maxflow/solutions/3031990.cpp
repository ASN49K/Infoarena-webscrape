#include <fstream>
#include <cstring>
#include <vector>
#include <deque>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <algorithm>
#include <iomanip>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
using ll = long long;
//#define int ll
using pi = pair<int,int>;
using pll = pair<ll, ll>;

#define pb push_back
#define x first
#define y second

const ll MOD = 1e9+7, INF = 1e18, NMAX = 1005;
ll p[NMAX], cap[NMAX][NMAX], n;
vector<int> v[NMAX];
int bfs(int src, int dest)
{
    int i, u, nod;
    for(i = 1; i <= n; i++)
        p[i] = 0;
    p[src] = src;
    queue<int> q;
    q.push(src);
    while(!q.empty())
    {
        u = q.front();
        q.pop();
        for(i = 0; i < v[u].size(); i++)
        {
            nod = v[u][i];
            if(p[nod] == 0 && cap[u][nod] > 0)
            {
                p[nod] = u;
                q.push(nod);
                if(nod == dest)
                    return 1;
            }
        }
    }
    return 0;
}
void solve()
{
    ll m, i, a, b, c, src, dest, flow, new_flow, u;
    cin >> n >> m;
    for(i = 1; i <= m; i++)
    {
        cin >> a >> b >> c;
        v[a].pb(b);
        v[b].pb(a);
        cap[a][b] += c;
    }
    src = 1;
    dest = n;
    flow = 0;
    while(bfs(src, dest))
    {
        u = dest;
        new_flow = INF;
        while(u != src)
        {
            new_flow = min(new_flow, cap[p[u]][u]);
            u = p[u];
        }
        u = dest;
        while(u != src)
        {
            cap[p[u]][u] -= new_flow;
            cap[u][p[u]] += new_flow;
            u = p[u];
        }
        flow += new_flow;
    }
    cout << flow;
}
int main()
{
    cin.tie(0)->sync_with_stdio(0);
    cin.exceptions(cin.failbit);
    int T;
    T = 1;
    while(T--)
        solve();
    return 0;
}
