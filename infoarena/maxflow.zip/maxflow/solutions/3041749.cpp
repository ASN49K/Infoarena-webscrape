#include<cstdio>
#include<vector>
#include<cstring>
#include<queue>
#include<algorithm>
using namespace std;
FILE*in=fopen("maxflow.in","r");
FILE*out=fopen("maxflow.out","w");
const int NMAX=1005,MMAX=5005,INF=1000000009;
int n,m,i,j,a,b,c;
int flux[NMAX][NMAX],cap[NMAX][NMAX];
bool isin[NMAX][NMAX];
vector<int> adj[NMAX];
bool bo[NMAX];
queue<int> q;
int g;
int dad[NMAX];
int ct,ctt;
void fluxeaza()
{
    int minn=INF;
    int act=n;
    while(act!=1)
    {
        minn=min(minn,cap[dad[act]][act]-flux[dad[act]][act]);
        act=dad[act];
    }
    act=n;
    ct+=minn;
    while(act!=1)
    {
        flux[dad[act]][act]+=minn;
        flux[act][dad[act]]-=minn;
        act=dad[act];
    }
}
void fl()
{
    memset(bo,0,sizeof(bo));
    memset(dad,0,sizeof(dad));
    q.push(1);
    bo[1]=1;
    while(!q.empty())
    {
        g=q.front();
        q.pop();
        for(auto w:adj[g])
        {
            if(w==n&&cap[g][w]-flux[g][w]>0)
            {
                dad[n]=g;
                fluxeaza();
                continue;
            }
            if(bo[w]==0&&cap[g][w]-flux[g][w]>0)
            {
                bo[w]=1;
                dad[w]=g;
                q.push(w);
            }
        }
    }
}
int main()
{
    fscanf(in,"%d%d",&n,&m);
    for(i=1;i<=m;i++)
    {
        fscanf(in,"%d%d%d",&a,&b,&c);
        if(isin[a][b]==0)
        {
            isin[a][b]=1;
            adj[a].push_back(b);
        }
        if(isin[b][a]==0)
        {
            isin[b][a]=1;
            adj[b].push_back(a);
        }
        cap[a][b]=c;
    }
    while(true)
    {
        ctt=ct;
        fl();
        if(ct==ctt)
        {
            break;
        }
    }
    fprintf(out,"%d",ct);
}
