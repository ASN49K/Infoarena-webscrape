#include <fstream>
#include <queue>
#include <vector>
#include <cstring>
using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");
const int INF=110001;
int n,m,cap[1005][1005],maxflow,prevv[1005],mincap;
vector<int> v[1005];
bool bfs()
{
    queue<pair<int,int>> q;
    memset(prevv,0,sizeof(int)*(n+3));
    q.push({1,INF});
    prevv[1]=-1, mincap=INF;
    while(!q.empty())
    {
        int x=q.front().first, y=q.front().second;
        q.pop();
        for(auto i:v[x])
            if(!prevv[i]&&cap[x][i])
        {
            prevv[i]=x;
            if(i==n)
            {
                mincap=min(y,cap[x][i]);
                return true;
            }
            q.push({i,min(y,cap[x][i])});
        }
    }
    return false;
}
int main()
{
    f>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b,c;
        f>>a>>b>>c;
        cap[a][b]=c;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    while(bfs())
    {
        int nod=n;
        while(prevv[nod]!=-1)
        {
            cap[prevv[nod]][nod]-=mincap, cap[nod][prevv[nod]]+=mincap;
            nod=prevv[nod];
        }
        maxflow+=mincap;
    }
    g<<maxflow;
    return 0;
}