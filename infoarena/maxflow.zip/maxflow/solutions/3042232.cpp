#include <stdio.h>
#include <vector>

#define magic_sauce inline __attribute__((always_inline))

magic_sauce int min( int a, int b ){ return a < b ? a : b; }

const int MAXN = 1000;
const int MAXM = 5000;
const int NIL = -1;
const int INF = 2e9;

std::vector<int> adj[MAXN];
int viz[MAXN];
int prev[MAXN];
int rem[MAXN][MAXN];
int n;

int q[MAXN];
int pq, uq;

magic_sauce bool bfs(){
  int u;

  for( u = 0 ; u < n ; u++ )
    viz[u] = false;

  q[0] = 0;
  prev[0] = NIL;
  viz[0] = true;

  pq = 0;
  uq = 1;
  while( pq < uq && q[pq] != 0 ){
    u = q[pq++];

    for( int v : adj[u] ){
      if( !viz[v] && rem[u][v] ){ // nod nevizitat si muchie nesaturata
        viz[v] = true;
        prev[v] = u;
        q[uq++] = v;
      }
    }
  }

  return viz[n - 1];
}

int main(){
  FILE *fin = fopen( "maxflow.in", "r" );
  FILE *fout = fopen( "maxflow.out", "w" );

  int m, i, a, b, aux, flux, delta;

  fscanf( fin, "%d%d", &n, &m );
  for( i = 0 ; i < m ; i++ ){
    fscanf( fin, "%d%d%d", &a, &b, &aux );
    a--;
    b--;

    rem[a][b] = aux;

    adj[a].push_back( b ); // muchia directa
    adj[b].push_back( a ); // muchia reziduala
  }

  flux = 0;
  while( bfs() ){
    delta = +INF;
    for( a = n - 1 ; a ; a = prev[a] ) // nu e ok sa bag for doar ca sincer vreau sa scap de jegul asta
      delta = min( delta, rem[prev[a]][a] );

    flux += delta;

    for( a = n - 1 ; a ; a = prev[a] ){
      rem[prev[a]][a] -= delta;
      rem[a][prev[a]] += delta;
    }
  }

  fprintf( fout, "%d\n", flux );

  fclose( fin );
  fclose( fout );
  return 0;
}
