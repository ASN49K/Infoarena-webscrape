#include <bits/stdc++.h>

using namespace std;

const int N = 1001;
int n, m;
vector<int> adj[N];
bool viz[N];
unordered_map<int, unordered_map<int, int>> c;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

int dfs(int u, int t, int flux)
{
	if (u == t)
	{
		return flux;
	}
	viz[u] = true;
	for (int v : adj[u])
	{
		if (!viz[v] && c[u][v] > 0)
		{
			int fluxcrt = min(flux, c[u][v]);
			int fluxtmp = dfs(v, t, fluxcrt);
			if (fluxtmp > 0)
			{
				c[u][v] -= fluxtmp;
				c[v][u] += fluxtmp;
				return fluxtmp;
			}
		}
	}
	return 0;
}

int main()
{
	fin >> n >> m;
	for (int i = 1; i <= m; ++i)
	{
		int u, v, cost;
		fin >> u >> v >> cost;
		adj[u].push_back(v);
		c[u][v] += cost;
		c[v][u] += 0;
	}

	int fluxmax = 0;
	while (true)
	{
		int flux = dfs(1, n, INT_MAX);
		if (flux == 0)
		{
			break;
		}
		fluxmax += flux;
		for (int i = 1; i <= n; ++i)
		{
			viz[i] = false;
		}
	}
	fout << fluxmax << '\n';
	return 0;
}
