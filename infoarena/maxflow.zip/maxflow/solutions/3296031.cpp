#include <stdio.h>

#include <queue>
#include <vector>
#include <algorithm>

constexpr int INF = 1e9;

namespace Flow {
  const int MAXN = 1000;
  std::vector<int> adj[MAXN];

  int cap[MAXN][MAXN];
  int dist[MAXN];
  int n;

  void init( int N ) { n = N; }
  void push_edge( int from, int to, int _cap ) {
    adj[from].push_back( to );
    adj[to].push_back( from );
    cap[from][to] = _cap;
    cap[to][from] = 0;
  }

  bool bfs( int src, int dest ) {
    for( int i = 0; i < n; i++ )
      dist[i] = +INF;

    std::queue<int> q({ src });
    dist[src] = 0;

    while( !q.empty() ){
      int u = q.front();
      q.pop();

      for( int v : adj[u] )
        if( cap[u][v] && dist[u] + 1 < dist[v] ){
          dist[v] = 1 + dist[u];
          q.push( v );
        }
    }

    return dist[dest] < +INF;
  }

  int search_start[MAXN];
  int dinic( int u, int dest, int push ) {
    if( !push ) return 0;
    if( u == dest ) return push;

    for( int &idx = search_start[u]; idx < (int)adj[u].size(); idx++ ){
      int v = adj[u][idx];
      if( !cap[u][v] ) continue;
      if( dist[u] + 1 != dist[v] ) continue;

      int try_push = dinic( v, dest, std::min( push, cap[u][v] ) );
      if( !try_push ) continue;

      cap[u][v] -= try_push;
      cap[v][u] += try_push;
      return try_push;
    }

    return 0;
  }

  int push_flow( int src, int dest ) {
    int flow = 0;

    while( bfs( src, dest ) ){
      for( int i = 0; i < n; i++ )
        search_start[i] = 0;

      int augment_flow;
      while( (augment_flow = dinic( src, dest, +INF )) )
        flow += augment_flow;
    }

    return flow;
  }
}

int main() {
  FILE *fin = fopen( "maxflow.in", "r" );
  FILE *fout = fopen( "maxflow.out", "w" );

  int n, m;
  fscanf( fin, "%d%d", &n, &m );
  int src = 0, dest = n - 1;

  Flow::init( n );
  for( int i = 0; i < m; i++ ){
    int a, b, cap;
    fscanf( fin, "%d%d %d", &a, &b, &cap );
    Flow::push_edge( --a, --b, cap );
  }

  fprintf( fout, "%d\n", Flow::push_flow( src, dest ) );

  fclose( fin );
  fclose( fout );
  return 0;
}
