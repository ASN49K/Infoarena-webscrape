﻿#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <algorithm>
#include <ctime>
#include <iomanip>
#include <cassert>
#include <random>
#include <chrono>
#include <map>
#include <unordered_map>
#include <complex>
#include <set>
#include <immintrin.h>
#include <cstring>
#define ll long long
#define ld long double
#define pii pair <int, int>
#define x first
#define y second
#pragma GCC optimize("Ofast")

#pragma warning(disable : 4996)

using namespace std;

mt19937_64 gen(chrono::duration_cast<chrono::nanoseconds>(chrono::steady_clock::now().time_since_epoch()).count());
uniform_int_distribution <int> rng;

int n, m, source, sink;
vector<tuple<int, int, int, int>> vs[1005];
// vs[u].emplace_back(v, arc_id, c, +1);
// vs[v].emplace_back(u, arc_id, 0, -1);
int flow[5005];
int visited[1005], iter;

bool dfs(int u, int f) {
    if (u == sink)
        return true;
    else if (visited[u] < iter) {
        visited[u] = iter;
        for (auto [v, a, c, k] : vs[u]) if (c - k * flow[a] >= f && dfs(v, f)) {
            flow[a] += k * f;
            return true;
        }
    }
    return false;
}
int maxflow() {
    int f = 0;
    int df = 1 << 20; // >= cmax
    while (df > 0) {
        iter++;
        if (dfs(source, df))
            f += df;
        else
            df /= 2;
    }
    return f;
}

void solve() {
    cin >> n >> m; source = 1; sink = n;
    for (int i = 1; i <= m; i++) {
        int u, v, c;
        cin >> u >> v >> c;
        vs[u].emplace_back(v, i, c, 1);
        vs[v].emplace_back(u, i, 0, -1);
    }
    cout << maxflow() << "\n";
}

int main() {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#ifdef LOCAL
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#else
    freopen("maxflow.in", "r", stdin);
    freopen("maxflow.out", "w", stdout);
#endif

    int T = 1;
    //cin >> T;
    for (; T; T--) {
        solve();
    }
    return 0;
}