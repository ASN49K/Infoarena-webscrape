#include <bits/stdc++.h>

using namespace std;

ifstream fin( "maxflow.in" );
ofstream fout( "maxflow.out" );

const int DIM = 1005;
const int INF = 1e9;

vector<int> G[DIM];
int cap[DIM][DIM];
int flow[DIM][DIM];
int viz[DIM];

void push_edge( int u, int v, int c ) {
  G[u].push_back(v);
  G[v].push_back(u);
  cap[u][v] += c;
}

int prv[DIM];
 
int bfs( int s, int d ) {
  queue<int> q;
  q.push(s);
  while ( !q.empty() ) {
	int u = q.front();
	q.pop();
	for ( auto v : G[u] ) {
      if ( !prv[v] && cap[u][v] > flow[u][v] ) {
        prv[v] = u;
		q.push(v);
	  }
	}
  }
  return prv[d];
}
 
int main() {
  int n, m, u, v, c;
 
  fin >> n >> m;
  for ( int i = 1; i <= m; ++i ) {
	fin >> u >> v >> c;
	push_edge(u, v, c);
  }
  int res = 0;
  while ( bfs(1, n) ) {
	int win = INF;
	for ( u = n; u != 1; u = prv[u] ) {
	  win = min(win, cap[prv[u]][u] - flow[prv[u]][u]);
	}
    for ( u = n; u != 1; u = prv[u] ) {
	  flow[prv[u]][u] += win;
	  flow[u][prv[u]] -= win;
	}
	res += win;
	for ( int i = 1; i <= n; ++i ) {
	  prv[i] = 0;
	}
  }
  fout << res;
  fin.close();
  fout.close();
  return 0;
}
