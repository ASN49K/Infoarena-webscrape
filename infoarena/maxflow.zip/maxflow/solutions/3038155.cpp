///edmons karp
#include<fstream>
#include<vector>
#include<bitset>

#define inf 1e9

using namespace std;
int const N = 1003;
int n , m , a , b , c;
int f[N][N];
int q[N] , t[N] , fl[N];
vector<int> v[N];
bitset<N> viz;
bool bfs(){
    viz = 0;
    int l = 1 , r = 1;
    q[1] = viz[1] = 1;
    fl[n] = fl[1] = inf;
    while(l <= r){
        int x = q[l++];
        for(int i : v[x]){
            if(f[x][i] > 0 && !viz[i]){
                viz[i] = 1;
                fl[i] = (fl[x] < f[x][i] ? fl[x] : f[x][i]);
                t[i] = x;
                q[++r] = i;
            }
        }
    }
    return viz[n];
}
int maxflow(){
    int flow = 0;
    while(bfs()){
        flow += fl[n];
        int x = n;
        while(t[x]){
            f[t[x]][x] -= fl[n];
            f[x][t[x]] += fl[n];
            x = t[x];
        }
    }
    return flow;
}
int main(){
    freopen("maxflow.in" , "r" , stdin);
    freopen("maxflow.out" , "w" , stdout);
    scanf("%d%d" , &n , &m);
    for(int i = 1 ; i <= m ; ++ i){
        scanf("%d%d%d" , &a , &b , &c);
        f[a][b] = c;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    printf("%d\n" , maxflow());
    return 0;
}
