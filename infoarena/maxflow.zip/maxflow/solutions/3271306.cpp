#include <bits/stdc++.h>
// Edmonds-Karp - O(min(V*E^2, E*Fmax))

using namespace std;

const int NMAX = 1e3;
int capacitate[NMAX + 1][NMAX + 1], flux[NMAX + 1][NMAX + 1];
vector<int> G[NMAX + 1];
int vis[NMAX + 1], p[NMAX + 1];

int bfs(int src, int dest, int n) {
    fill(vis, vis + n + 1, 0);
    fill(p, p + n + 1, 0);

    queue<int> q;
    q.push(src);
    vis[src] = 1;
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        for (auto vecin : G[node]) {
            if (!vis[vecin] && capacitate[node][vecin] - flux[node][vecin] > 0) {
                q.push(vecin);
                vis[vecin] = 1;
                p[vecin] = node;
            }
        }
    }
    if (!vis[dest]) return 0;

    int flow = INT_MAX;
    for (int x = dest; x != src; x = p[x]) {
        flow = min(flow, capacitate[p[x]][x] - flux[p[x]][x]);
    }
    for (int x = dest; x != src; x = p[x]) {
        flux[p[x]][x] += flow;
        flux[x][p[x]] -= flow;
    }
    return flow;
}

int edmonds_karp(int n, int m, vector<tuple<int, int, int>> edges) {
    for (auto &[x, y, c] : edges) {
        capacitate[x][y] = c;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    int maxFlow = 0;
    while (int flow = bfs(1, n, n)) {
        maxFlow += flow;
    }
    return maxFlow;
}

int main() {
    ifstream f("maxflow.in");
    ofstream g("maxflow.out");

    int n, m;
    f >> n >> m;
    vector<tuple<int, int, int>> edges;

    while (m--) {
        int x, y, c;
        f >> x >> y >> c;
        edges.emplace_back(x, y, c);
    }

    g << edmonds_karp(n, m, edges);
    return 0;
}
