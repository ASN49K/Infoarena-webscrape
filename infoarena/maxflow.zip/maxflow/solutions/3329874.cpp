#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

const int NMAX = 1001;
const int HIGH = 1000001;

struct graph
{
    int N, M, flow[NMAX][NMAX], cap[NMAX][NMAX];
    vector<int> A[NMAX];
} G;

struct flow_bfs
{
    bool viz[NMAX];
    int tata[NMAX], sent_flow;

    void clear(int N)
    {
        sent_flow = HIGH;
        for(int i = 1; i <= N; i++)
            viz[i] = false, tata[i] = 0;
    }

    void find_path(graph& G, int s, int t)
    {
        clear(G.N);
        
        queue<int> q;
        q.push(s);
        viz[s] = true;

        while(!q.empty())
        {
            int n = q.front();
            q.pop();

            for(const auto& v : G.A[n])
            {
                if(!viz[v] && G.cap[n][v] - G.flow[n][v] > 0)
                {
                    viz[v] = true;
                    q.push(v);
                    tata[v] = n;
                }
            }
        }
    }

    void run(graph& G, int s, int t)
    {
        if(viz[t] == 0)
            sent_flow = 0;
        else
        {
            vector<int> path;
            while(t != 0)
            {
                path.push_back(t);
                t = tata[t];
            }

            reverse(path.begin(), path.end());

            for(int i = 0; i < path.size() - 1; i++)
            {
                int x = path[i], y = path[i + 1];
                sent_flow = min(sent_flow, G.cap[x][y] - G.flow[x][y]);
            }

            for(int i = 0; i < path.size() - 1; i++)
            {
                int x = path[i], y = path[i + 1];
                G.flow[x][y] += sent_flow;
                G.flow[y][x] -= sent_flow;
            }
        }
    }
};

int edmonds_karp(graph& G)
{
    flow_bfs B;
    int max_flow = 0;
    
    do
    {
        B.find_path(G, 1, G.N);
        B.run(G, 1, G.N);
        max_flow += B.sent_flow;
    }
    while(B.sent_flow > 0);

    return max_flow;
}

int main()
{
    ifstream fin("maxflow.in");
    ofstream fout("maxflow.out");

    fin >> G.N >> G.M;

    for(int i = 1; i <= G.M; i++)
    {
        int x, y, c;
        fin >> x >> y >> c;
        G.cap[x][y] = c; // G.cap[y][x] = 0;
        G.A[x].push_back(y);
        G.A[y].push_back(x);
    }

    fout << edmonds_karp(G);

    fin.close();
    fout.close();

    return 0;
}