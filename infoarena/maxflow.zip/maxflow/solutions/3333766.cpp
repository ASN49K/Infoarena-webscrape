#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
#include <climits>
using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

const int MAXN = 1005;
int n, m;
int cap[MAXN][MAXN];  // cap[u][v] = capacitatea reziduala pe muchia u -> v
int parent[MAXN];     // pentru BFS

// BFS pentru a gasi un drum de augmentare de la sursa (1) la destinatie (n)
bool bfs()
{
    memset(parent, -1, sizeof(parent));
    queue<int> q;
    q.push(1);
    parent[1] = 1;

    while (!q.empty())
    {
        int u = q.front();
        q.pop();

        if (u == n)
            return true;

        for (int v = 1; v <= n; v++)
        {
            if (parent[v] == -1 && cap[u][v] > 0)
            {
                parent[v] = u;
                q.push(v);
            }
        }
    }

    return false;
}

int main()
{
    f >> n >> m;

    memset(cap, 0, sizeof(cap));

    for (int i = 0; i < m; i++)
    {
        int x, y, z;
        f >> x >> y >> z;
        cap[x][y] += z; // += pentru a suporta muchii multiple (desi problema zice ca nu sunt)
    }

    // Algoritmul Edmonds-Karp (Ford-Fulkerson cu BFS)
    long long maxFlow = 0;

    while (bfs())
    {
        // Gasim capacitatea minima pe drumul de augmentare
        int flow = INT_MAX;
        for (int v = n; v != 1; v = parent[v])
        {
            int u = parent[v];
            flow = min(flow, cap[u][v]);
        }

        // Actualizam capacitatile reziduale
        for (int v = n; v != 1; v = parent[v])
        {
            int u = parent[v];
            cap[u][v] -= flow;
            cap[v][u] += flow; // muchie inversa pentru a permite "anularea" fluxului
        }

        maxFlow += flow;
    }

    g << maxFlow << "\n";

    return 0;
}
