#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#define N_MAX 1001
#define INF 999999

using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");


int capacitate_init[N_MAX][N_MAX];//capacitatea initiala
int capacitate_rez[N_MAX][N_MAX];//capacitatea reziduala

vector<pair<int,int>>taietura_min;//Complexitate O(n*m^2)
int n,m;
vector<vector<int>>la;

int bfs(int start,int fin,vector<int>&parinte)

{

    for (int i = 0; i < parinte.size(); i++)
        parinte[i]=-1;

    taietura_min.clear();

    queue<pair<int,int>> q;
    parinte[start]=-2;

    q.push({start,INF});
    while(!q.empty())
    {
        int cur=q.front().first;
        int flow=q.front().second;
        q.pop();
        for(auto el:la[cur])
        {
            if(parinte[el]==-1 && capacitate_rez[cur][el])
            {
                parinte[el]=cur;
                int new_flow=min(flow,capacitate_rez[cur][el]);
                if(el==fin) //daca nodul atins e  fin ret flow maxim pe lant
                    return new_flow;
                q.push({el,new_flow});
            }
            //else if(parinte[el]==-1 && capacitate_rez[cur][el]==0)
            //   taietura_min.push_back({cur,el});
        }
    }
    return 0;
}
int max_flow(int sursa,int sink)// Edmonds-Karp
{
    int maxflow=0;
    vector<int>parinte(n+1);
    int flow;
    while(flow=bfs(sursa,sink,parinte))
    {

        maxflow+=flow;
        int cur=sink;
        while(cur!=sursa)
        {
            int ant=parinte[cur];
            capacitate_rez[cur][ant]+=flow;
            capacitate_rez[ant][cur]-=flow;
            cur=ant;
        }
    }
    return maxflow;
}
void afisare()
{
    for(auto x:taietura_min)
        g<<x.first<<" "<<x.second<<'\n';

}
int main()
{   f>>n>>m;
    la.resize(n+1);
    for(int i=1; i<=m; i++)
    {   int x,y,z;
        f>>x>>y>>z;
        capacitate_rez[x][y]=z;
        capacitate_init[x][y]=z;
        la[x].push_back(y);
        la[y].push_back(x);
    }

   int mx=max_flow(1,n);
    g<<mx<<'\n';
    //afisare();
    return 0;
}
