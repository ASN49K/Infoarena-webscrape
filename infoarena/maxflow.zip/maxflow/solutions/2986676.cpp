#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;
ifstream in("maxflow.in");
ofstream out("maxflow.out");
const int nmax = 1001;

vector<int>g[nmax+1];

int capacity[nmax+1][nmax+1];
int flow[nmax+1][nmax+1];
int dist[nmax+1];
int tata[nmax + 1];
int n,m;
bool bfs(int start)
{
    memset(tata, 0, sizeof tata);
    queue<int>q;

    q.push(start);
    tata[start] = start;

    while(!q.empty())
    {
        int curent = q.front();
        q.pop();

        if(curent == n)
            return true;

        for(int i=0; i<g[curent].size(); i++)
        {
            int vecin = g[curent][i];
            if(tata[vecin] == 0 && capacity[curent][vecin] - flow[curent][vecin] > 0)
            {
                q.push(vecin);
                dist[vecin] = 1;
                tata[vecin] = curent;
            }
        }
    }
    return false;
}
int find_muchie_min()
{
    int node = n;
    int muchiemin = 1e9;
    while(tata[node] != node)
    {
        int parent = tata[node];
        muchiemin = min(muchiemin, capacity[parent][node] - flow[parent][node]);
        node = tata[node];
    }
    return muchiemin;
}
void updateflow(int muchiemin)
{
    int node = n;
    while (tata[node] != node) {
        int parent = tata[node];
        flow[parent][node] += muchiemin;
        flow[node][parent] -= muchiemin;
        node = parent;
    }
}
int main()
{
    in>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x,y,capacitate;
        in>>x>>y>>capacitate;
        g[x].push_back(y);
        g[y].push_back(x);
        capacity[x][y] = capacitate;
        //capacity[y][x] = capacitate;
        //flow[x][y] = 0;
        //flow[y][x] = capacitate;
    }
    int start = 1;
    int ans = 0;
    while(bfs(start))
    {
        int muchiemin = find_muchie_min();//!!!
        updateflow(muchiemin);
        ans += muchiemin;

    }

    out<<ans;
    return 0;
}
