#include <fstream>
#include <vector>
#include <queue>

using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

const int N = 1000, M = 5000;
const int INF = 1e9;
int dist[N + 1];
struct edge{
    int u, v, c;
} e[2*M + 2];
vector<int> mat[N + 1];
queue<int> q;

int src;
int dest;


void add_edge(int u, int v, int c, int ind){
    e[ind * 2] = {u, v, c};
    e[ind * 2 + 1] = {v, u, 0};
    mat[u].push_back(ind * 2);
    mat[v].push_back(ind * 2 + 1);
}

int n, m;

void read(){
    fin>>n>>m;
    src = 1;
    dest = n;
    for(int i = 1; i <= m; i++)
    {
        int u, v, c;
        fin>>u>>v>>c;
        add_edge(u, v, c, i);
    }
}

int bfs_edge[N + 1];

int bfs_reaches(){
    while(!q.empty()) q.pop();
    q.push(src);
    for(int i = 1; i <= n; i++)
        bfs_edge[i] = 0;
    bfs_edge[src] = -1;
    while(!q.empty() && bfs_edge[dest] == 0)
    {
        int u = q.front();
        q.pop();
        for(int ind:mat[u])
        {
            int v = e[ind].v, c = e[ind].c;
            if(!bfs_edge[v] && c)
            {
                bfs_edge[v] = ind;
                q.push(v);
            }
        }
    }
    return (bfs_edge[dest] != 0);
}

int find_path_minimum(){
    int min_cap = INF, u = dest;
    while(u != src)
    {
        int ind = bfs_edge[u];
        if(e[ind].c < min_cap) min_cap = e[ind].c;
        u = e[ind].u;
    }
    return min_cap;
}

void pump_path(int val){
    int u = dest;
    while(u != src)
    {
        int ind = bfs_edge[u];
        e[ind].c -= val;
        e[(ind ^ 1)].c += val;
        u = e[ind].u;
    }
}

int max_flow = 0;

void solve(){
    while(bfs_reaches()){
        int to_pump = find_path_minimum();
        pump_path(to_pump);
        max_flow += to_pump;
    }
}

void print_ans(){
    fout<<max_flow;
}
int main()
{
    read();
    solve();
    print_ans();
    return 0;
}
