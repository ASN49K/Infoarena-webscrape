#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#define ll long long int
using namespace std;
ifstream fin ("maxflow.in");
ofstream fout("maxflow.out");
int n, m;
struct edge{
    int to;
    ll maxf;
    ll used;
    int rev;
};
vector<vector<edge> > v;
vector<int> level, ptr;
void add_edge(int nod1, int nod2, ll cost)
{
    v[nod1].push_back({nod2,cost,0,(int)v[nod2].size()});
    v[nod2].push_back({nod1,0,0,(int)v[nod1].size()-1});
}
bool bfs(int start, int fin)
{
    fill(level.begin(),level.end(),-1);
    queue<int> q;
    q.push(start);
    level[start] = 0;
    while(!q.empty())
    {
       int nod = q.front(); q.pop();
       for(int i = 0; i<v[nod].size(); i++)
       {
           int vecin = v[nod][i].to;
           ll maxf = v[nod][i].maxf;
           ll used = v[nod][i].used;
           if(maxf-used > 0 && level[vecin] == -1)
           {
               level[vecin] = level[nod] + 1;
               q.push(vecin);
           }
       }
    }
    return level[fin] != -1;
}
ll dfs(int nod, int fin, ll flowc)
{
    if(flowc == 0 || nod == fin)
        return flowc;
    for(int &i = ptr[nod]; i<v[nod].size(); i++)
    {
        int vecin = v[nod][i].to;
        ll maxf = v[nod][i].maxf;
        ll used = v[nod][i].used;
        if(maxf - used == 0 || level[vecin] != level[nod] + 1)
            continue;
        ll pushedc = dfs(vecin, fin, min(flowc, maxf - used));
        if(pushedc == 0) continue;
        v[nod][i].used+=pushedc;
        int revind = v[nod][i].rev;
        v[vecin][revind].used-=pushedc;
        return pushedc;
    }
    level[nod] = -1;
    return 0;
}
int main()
{

    fin >> n >> m;
    v.resize(n+1);
    level.resize(n+1);
    ptr.resize(n+1);
    for(int i = 1; i<=m; i++)
    {
        int a, b;
        ll c;
        fin >> a >> b >> c;
        add_edge(a,b,c);
    }
    ll ans = 0;
    while(bfs(1,n))
    {
        fill(ptr.begin(), ptr.end(), 0);
        ll pushed = 0;
        ll inf = 1e18;
        while(pushed = dfs(1,n,inf))
        {
            ans+=pushed;
        }
    }
    fout << ans;
    return 0;
}
