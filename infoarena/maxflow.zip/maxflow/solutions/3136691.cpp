#include <bits/stdc++.h>
using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

const int NMAX = 1005;

int n, m;
int cap[NMAX][NMAX];
int flow[NMAX][NMAX], flowInv[NMAX][NMAX];
vector<int> G[NMAX], invG[NMAX];
int prevNode[NMAX];  // for bfs

// returns whether we reached the end
bool bfs() {
    for (int i = 2; i <= n; i++)
        prevNode[i] = 0;

    queue<int> Q;
    Q.push(1);
    while (!Q.empty()) {
        int vertex = Q.front();
        Q.pop();

        // normal edges
        for (int neigh: G[vertex])
            if (!prevNode[neigh] && flow[vertex][neigh] != cap[vertex][neigh]) {  // unvisited vertex, and unsaturated edge
                prevNode[neigh] = vertex;
                if (neigh == n)
                    return true;
                Q.push(neigh);
            }
        
        // inverse edges
        for (int neigh: invG[vertex])
            if (neigh != 1 && !prevNode[neigh] && flow[vertex][neigh] != 0) {  // we'll remove flow from here
                prevNode[neigh] = -vertex;
                Q.push(neigh);
            }
    }
    return false;
}

int main() {
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int u, v, c;
        fin >> u >> v >> c;
        G[u].push_back(v);
        invG[v].push_back(u);

        cap[u][v] = c;
        flow[u][v] = 0;

        flowInv[u][v] = 0;
    }

    while (bfs()) {
        int curr = n;

        int toAdd = cap[prevNode[n]][n] - flow[prevNode[n]][n];
        while (curr != 1) {
            int a = prevNode[curr], b = curr;
            if (a < 0) {  // inverse edge
                toAdd = min(toAdd, flow[b][a]);
                curr = -a; 
            }
            else {
                toAdd = min(toAdd, cap[a][b] - flow[a][b]);
                curr = a;
            }
        }

        curr = n;
        while (curr != 1) {
            int a = prevNode[curr], b = curr;

            if (a < 0) {
                flow[b][a] -= toAdd;
                curr = -a;
            }
            else {
                flow[a][b] += toAdd;
                curr = a;
            }
        }
    }

    int ans = 0;
    for (int v: G[1])
        ans += flow[1][v];
    fout << ans;

    return 0;
}