#include <iostream>
#include <fstream>
#include <utility>
#include <vector>
#include <queue>
#include <cstring>
#define inf 0x3f3f3f3f
using namespace std;

ifstream in("maxflow.in");
ofstream out("maxflow.out");

vector<int>ls[1005],ls1[1005];
int c[1005][1005], f[1005][1005];
int viz[101],tata[101];

bool bfs(int s,int t)
{
	bool ok = false;
	queue<int> coada;
	memset(viz, 0, sizeof(viz));
	viz[s] = true;
	coada.push(s);
	while (!coada.empty())
	{
		int sursa = coada.front();
		coada.pop();
		for (auto vecin : ls[sursa])
		{
			if (!viz[vecin] && c[sursa][vecin] != f[sursa][vecin])
			{
				viz[vecin] = true;
				coada.push(vecin);
				tata[vecin] = sursa;
				if (vecin == t)
				{
					ok = true;
					break;
				}
			}
		}
	}
	return ok;
}





int main() {
	int n, m;
	in >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int a, b, z;
        in >> a >> b >> z;
        ls[a].push_back(b);
        ls[b].push_back(a);
        c[a][b] += z;
    }
	int s = 1, t = n;
	int total=0;
	for (; bfs(s,t);)
	{
		int mincaprez = inf;
		for (int nod = n; nod != 1; nod = tata[nod])
		{
			mincaprez = min(mincaprez, c[tata[nod]][nod] - f[tata[nod]][nod]);
		}
		for (int nod = n; nod != 1; nod = tata[nod])
		{
			f[tata[nod]][nod] += mincaprez;
			f[nod][tata[nod]] -= mincaprez;
		}
		total += mincaprez;
	}
	out<<total;
	
	
	
}