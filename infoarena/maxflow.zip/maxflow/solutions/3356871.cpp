#include <bits/stdc++.h>

using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
int n,m;
vector<int> v[1003];
int cost[1003][1003];
int dist[1003];
int ptr[1003];
int bfs(int start)
{
    queue<int> q;
    q.push(start);
    dist[start]=1;
    while (!q.empty())
    {
        int nod=q.front();
        q.pop();
        for (auto i:v[nod])
        {
            if (dist[i]==0 && cost[nod][i]>0)
            {
                dist[i]=dist[nod]+1;
                if (i==n) return 1;
                q.push(i);
            }
        }
    }
    return 0;
}
int dfs(int nod,int bottleneck)
{
    if (nod==n) return bottleneck;
    for (int i=ptr[nod];i<v[nod].size();i++)
    {
        int x=v[nod][i];
        if (dist[nod]+1==dist[x] && cost[nod][x]>0)
        {
            int val=dfs(x,min(bottleneck,cost[nod][x]));
            if (val>0)
            {
                cost[nod][x]-=val;
                cost[x][nod]+=val;
                return val;
            }
        }
        ptr[nod]++;
    }
    return 0;
}
int rez;
int main()
{
    fin>>n>>m;
    while (m--)
    {
        int x,y,c;
        fin>>x>>y>>c;
        if (cost[x][y]==0 && cost[y][x]==0)
        {
            v[x].push_back(y);
            v[y].push_back(x);
        }
        cost[x][y]+=c;
    }
    while (bfs(1))
    {
        memset(ptr,0,sizeof(ptr));
        int aux=dfs(1,1e9);
        while(aux!=0)
        {
            rez+=aux;
            aux=dfs(1,1e9);
        }
        memset(dist,0,sizeof(dist));
    }
    fout<<rez;
    return 0;
}
