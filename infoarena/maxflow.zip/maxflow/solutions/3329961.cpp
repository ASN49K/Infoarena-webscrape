#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

const int NMAX = 1001;

vector<vector<int>> edgRezid;
vector<int> tata;
int rezid[NMAX][NMAX];
int n, m;

bool BFS(int s, int t){
    queue<int> q;
    vector<int> viz(n+1, 0);
    tata.resize(n+1, 0);
    q.push(s);
    while(!q.empty()){
        int u = q.front();
        q.pop();
        for(auto &v:edgRezid[u]){
            if(!viz[v] && rezid[u][v]> 0){
                viz[v] = 1;
                q.push(v);
                tata[v] = u;
                if(v == t)
                    return true;
            }
        }

    }
    return false;
}

int capRezid(vector<int> &tata, int s, int t){
    int mn = 200000;
    for(int v = t; v!=s; v = tata[v]){
        mn = min(mn, rezid[tata[v]][v]);

    }
    return mn;
}

void actualizareFlux(vector<int> &tata, int s, int t, int cr){
    for(int v = t; v!=s; v = tata[v]){

            rezid[tata[v]][v] -= cr;

            rezid[v][tata[v]] += cr;

    }
}

int main(){
    fin>>n>>m;
    edgRezid.resize(n+1);
    //edgOut.resize(n+1);
    while(m--){
        int u, v, c;
        fin>>u>>v>>c;
        edgRezid[u].push_back(v);
        edgRezid[v].push_back(u);
        rezid[u][v] = c;
    }
    int fluxmax = 0;
    while(BFS(1, n)){
        int cr = capRezid(tata, 1, n);
        actualizareFlux(tata, 1, n, cr);
        fluxmax += cr;
    }
    fout<<fluxmax;
    return 0;
}
