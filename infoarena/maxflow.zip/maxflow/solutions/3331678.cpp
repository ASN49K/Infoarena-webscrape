#include <fstream>
#include <vector>
#include <queue>
#define nmax 1005
using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
int n,m,x,y,cap,f[nmax][nmax],flow,c[nmax][nmax],t[nmax];
vector<int>v[nmax];
queue<int>q;
bool viz[nmax];
bool bfs(int s,int d){
    for(int i=1;i<=n;i++)
        viz[i]=0,t[i]=0;
    viz[s]=1;
    q.push(s);
    while(!q.empty()){
        int nod=q.front();
        q.pop();
        for(auto i:v[nod])
            if(!viz[i]&&f[nod][i]<c[nod][i]){
                t[i]=nod;
                viz[i]=1;
                q.push(i);
            }
    }
    return viz[d];
}
void add(int d){
    for(int i=1;i<d;i++)
        if(viz[i]&&f[i][d]<c[i][d]){
            int mini=1e9;
            for(int nod=i;nod!=1;nod=t[nod])
                mini=min(c[t[nod]][nod]-f[t[nod]][nod],mini);
            if(mini<=0)
                continue;
            f[i][d]+=mini;
            f[d][i]-=mini;
            for(int nod=i;nod!=1;nod=t[nod]){
                f[t[nod]][nod]+=mini;
                f[nod][t[nod]]-=mini;
            }
            flow+=mini;
        }
}
signed main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y>>cap;
        c[x][y]+=cap;
        v[x].push_back(y);
    }
    while(bfs(1,n))
        add(n);
    cout<<flow;
    return 0;
}
