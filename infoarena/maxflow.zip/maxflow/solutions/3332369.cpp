#include <fstream>
#include <vector>
#include <queue>

using namespace std;
const int nmax = 1000, inf = 1e9;
const string txt = "maxflow";

ifstream f(txt + ".in");
ofstream g(txt + ".out");

int n, m, sour, dest, flow[nmax][nmax], ans, d[nmax], fr[nmax], t[nmax];
vector<int> v[nmax];

bool bfs()
{
	queue<int> q; while (!q.empty()) q.pop();
	for (int i = 1; i <= n; i++) fr[i] = 0;

	q.push(sour); fr[sour] = 1;
	while (!q.empty())
	{
		int node = q.front(); q.pop();
		
		for (auto x : v[node])
			if (!fr[x] && flow[node][x] > 0)
				fr[x] = 1, t[x] = node, q.push(x);
	}

	return fr[dest];
}

void maxflow()
{
	while (bfs())
	{
		int mini = inf;
		for (int i = dest; i != sour; i = t[i])
			mini = min(mini, flow[t[i]][i]);

		ans += mini;

		for (int i = dest; i != sour; i = t[i])
			flow[t[i]][i] -= mini, flow[i][t[i]] += mini;
	}
}

int main()
{
	f >> n >> m; sour = 1; dest = n;
	for (int i = 1; i <= m; i++)
	{
		int x, y, cap;
		f >> x >> y >> cap;
		v[x].push_back(y);
		v[y].push_back(x);
		flow[x][y] = cap;
	}

	maxflow();

	g << ans;
	return 0;
}