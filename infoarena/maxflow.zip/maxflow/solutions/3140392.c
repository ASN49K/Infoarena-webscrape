#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
typedef struct Node{
    unsigned short int neighbour;
    struct Node *next;
}Node;

void AddToFrontList(Node **head,unsigned short int key)
{
    if(NULL==(*head))
    {
        (*head)=(Node *) malloc(sizeof(Node));
        (*head)->neighbour=key;
        (*head)->next=NULL;
        return;
    }

    Node *temp=(Node *) malloc(sizeof(Node));
    temp->neighbour=key;
    temp->next=(*head);
    (*head)=temp;
}
void DeleteAtFront(Node **head)
{
    if(NULL==(*head))
        return;

    Node *temp=(Node *) malloc(sizeof(Node));
    temp=(*head);
    (*head)=(*head)->next;
    temp=NULL;
    free(temp);
}
void PurgeList(Node **head)
{
    while (NULL!=(*head)){
        Node *temp=(*head);
        (*head)=(*head)->next;
        temp=NULL;
        free(temp);
    }
}
bool BFS(int **Flux,int **Capacity,unsigned short int n,Node **AdjList,unsigned short int *TT,bool *visited)
{


    Node *neighbour=NULL;
    unsigned short int curr_node,low=0,high=0;
    unsigned short int *Queue=(unsigned short int *) calloc(n, sizeof(unsigned short int));

    for(unsigned short int i=1;i<n;i++)
        visited[i]=false;

    visited[0]=true;
    Queue[high++]=0;

    while (low<high)
    {
        curr_node=Queue[low++];
        if(curr_node==n-1) continue;

        neighbour=AdjList[curr_node];

        while(NULL!=neighbour){

            if(visited[neighbour->neighbour]==true || Capacity[curr_node][neighbour->neighbour]==Flux[curr_node][neighbour->neighbour]){

                neighbour=neighbour->next;
                continue;
            }

            visited[neighbour->neighbour]=true;
            Queue[high++]=neighbour->neighbour;
            TT[neighbour->neighbour]=curr_node;

            neighbour=neighbour->next;
        }

    }

    return visited[n-1];
}
unsigned int Minimum(unsigned int a,unsigned int b){
    return (a<b) ? a:b;
}
int main() {

    freopen("maxflow.in","r",stdin);
    freopen("maxflow.out","w",stdout);

    unsigned short int n,m,x,y;
    scanf("%hu %hu",&n,&m);
    int **Capacity=(int **) calloc(n, sizeof(int *));
    int **Flux=(int **) calloc(n,sizeof(int *));
    unsigned short int *TT=(unsigned short int *) calloc(n, sizeof(unsigned short int));
    bool *visited=(bool *) calloc(n, sizeof(bool));

    for(unsigned short int i=0;i<n;i++){
        Capacity[i]=(int *) calloc(n, sizeof(int ));
        Flux[i]=(int *) calloc(n, sizeof(int ));
    }

    Node **AdjList=(Node **) calloc(n,sizeof(Node *));

    unsigned int cost;
    for(unsigned short int i=0;i<m;i++){
        scanf("%hu %hu %u",&x,&y,&cost);
        Capacity[x-1][y-1]=cost;
        AddToFrontList(&AdjList[x-1],y-1);
        AddToFrontList(&AdjList[y-1],x-1);
    }

    Node *sink=NULL;
    unsigned int MaxFlow=0,MinFlow;
    unsigned short int node;

    while(BFS(Flux,Capacity,n,AdjList,TT,visited)){


        sink=AdjList[n-1];
        while(NULL!=sink){


            if(Flux[sink->neighbour][n-1]==Capacity[sink->neighbour][n-1] || visited[sink->neighbour]==false){
                sink=sink->next;
                continue;
            }
            TT[n-1]=sink->neighbour;

            MinFlow=(1<<31);
            node=n-1;
            while(0!=node){
               MinFlow= Minimum(MinFlow,Capacity[TT[node]][node]-Flux[TT[node]][node]);
               node=TT[node];
            }

            if(MinFlow==0) {
                sink=sink->next;
                continue;
            }

            node=n-1;
            while(0!=node){
                Flux[TT[node]][node]+=MinFlow;
                Flux[node][TT[node]]-=MinFlow;
                node=TT[node];
            }

            MaxFlow+=MinFlow;
            sink=sink->next;
        }


    }

    printf("%u",MaxFlow);

    for(unsigned short int i=0;i<n;i++){
        free(Capacity[i]);
        free(Flux[i]);
        PurgeList(&AdjList[i]);
    }

    free(TT);
    free(visited);
    free(Capacity);
    free(Flux);
    free(AdjList);

    return 0;
}
