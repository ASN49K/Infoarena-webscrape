///edmons karp
#include<stdlib.h>
#include<stddef.h>
#include<stdio.h>
#define inf 1000000000
#define N 1001
#define M 10001
int n , m , a , b , c , e , i , x , l , r , sz;
char viz[N];
int q[N] , t[N];
int v[M] , vf[M] , nxt[M];
int f[N][N];
char bfs(){
    for(i = 1 ; i <= n ; ++ i)
        viz[i] = 0;
    l = 1 , r = 1;
    q[1] = viz[1] = 1;
    while(l <= r){
        x = q[l++];
        for(e = v[x] ; e ; e = nxt[e]){
            i = vf[e];
            if(f[x][i] > 0 && !viz[i]){
                viz[i] = 1;
                t[i] = x;
                q[++r] = i;
                if(i == n)
                    return 1;
            }
        }
    }
    return 0;
}
int maxflow(){
    int flow = 0;
    while(bfs()){
        int x = n , nf = inf;
        while(t[x]){
            if(f[t[x]][x] < nf)
                nf = f[t[x]][x];
            x = t[x];
        }
        x = n;
        while(t[x]){
            f[t[x]][x] -= nf;
            f[x][t[x]] += nf;
            x = t[x];
        }
        flow += nf;
    }
    return flow;
}
void addl(int n1 , int n2){
    vf[++sz] = n2;
    nxt[sz] = v[n1];
    v[n1] = sz;
}
int main(){
    FILE *fin = fopen("maxflow.in" , "r");
    FILE *fout = fopen("maxflow.out" , "w");
    fscanf(fin , "%d%d" , &n , &m);
    for(i = 1 ; i <= m ; ++ i){
        fscanf(fin , "%d%d%d" , &a , &b , &c);
        f[a][b] = c;
        addl(a , b);
        addl(b , a);
    }
    fprintf(fout , "%d\n" , maxflow());
    return 0;
}
