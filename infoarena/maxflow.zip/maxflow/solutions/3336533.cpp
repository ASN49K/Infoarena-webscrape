#include <bits/stdc++.h>
using namespace std;
const int nmax=1e4+5;
ifstream f("maxflow.in");
ofstream g("maxflow.out");
vector <vector<int>>adj; 
vector<vector<int>> capacity;
vector<int>parent;
int bfs (int s ,int t)
{
    fill(parent.begin(),parent.end(),-1);
    parent[s]=-2;
    queue<pair<int,int>> q;
    q.push({s,INT_MAX});
    while(!q.empty())
    {
        int nod=q.front().first;
        int flow=q.front().second;
        q.pop();
        for(auto it : adj[nod])
        if(parent[it]==-1 && capacity[nod][it])
        {
            parent[it]=nod;
            int new_flow=min(flow,capacity[nod][it]);
            if(it==t)
                return new_flow;
            q.push({it,new_flow});
        }
        
    }
    return 0;
}
int maxflow(int s,int t)
{
    int flow=0;
    int new_flow;
    while(new_flow=bfs(s,t))
    {
        flow+=new_flow;
        int nod =t;
        while(nod!=s)
        {
            int prev=parent[nod];
            capacity[prev][nod]-=new_flow;
            capacity[nod][prev]+=new_flow;
            nod=prev;
        }

    }
    return flow;
}


int main ()
{
    int n ,m;
    f>>n>>m;
    parent.resize(n+5);
    capacity.resize(n+5);
    for(int i=1;i<=n;i++)
        capacity[i].resize(n+5);
    adj.resize(n);
    while(m--)
    {
        int x,y,flow;
        f>>x>>y>>flow;
        adj[x].push_back(y);
        capacity[x][y]=flow;
    }

    g<<maxflow(1,n);

}
