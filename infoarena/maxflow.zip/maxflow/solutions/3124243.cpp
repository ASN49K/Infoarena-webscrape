#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
const int NMAX = 1001;
int n, m, x, y, ans;
vector <int> g[NMAX],back(NMAX);
vector <vector<int>> c,fl;
bool drum(){
    queue <int> q;
    back = vector <int>(NMAX, 0);
    q.push(1),back[1]=-1;
    while (!q.empty()) {
        int nod = q.front();
        q.pop();
        if (nod == n) return 1;
        for (int it : g[nod]) {
            if (back[it]==0 && fl[nod][it] < c[nod][it]) {
                q.push(it), back[it] = nod;
            }
        }
    }
    return 0;
}
int flux_rezidual() {
    int mn = 1e9,ant=n;
    while (ant != 1) {
        mn = min(mn, c[back[ant]][ant] - fl[back[ant]][ant]);
        ant = back[ant];
    }
    return mn;
}
void update(int val) {
    int ant = n;
    while (ant != 1) {
        fl[back[ant]][ant] += val;
        fl[ant][back[ant]] -= val;
        ant = back[ant];
    }
}
int main()
{ 
    fin >> n >> m;
    c = vector <vector<int>>(n + 1, vector<int>(n + 1, 0));
    fl = vector <vector<int>>(n + 1, vector<int>(n + 1, 0));
    int val;
    while (m--) fin >> x >> y >>val , g[x].push_back(y),g[y].push_back(x),c[x][y]=val;
    while (drum()) {
        int flux_rez = flux_rezidual();
        update(flux_rez);
        ans += flux_rez;
    }
    fout << ans;
    return 0;
}