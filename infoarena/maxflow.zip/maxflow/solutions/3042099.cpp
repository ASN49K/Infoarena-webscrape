#include <bits/stdc++.h>
#define NMAX 1008

using namespace std;
ifstream fin ("maxflow.in");
ofstream fout ("maxflow.out");

int n, m, flow;
bool viz[NMAX];
map < pair <int, int>, int> h;
vector <int> G[NMAX];

int DFS(int nod, int minim);

int main()
{
    int x, y, z;
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y >> z;
        G[x].push_back(y);
        h[{x,y}] = z;
        if (!h[{y,x}])
            G[y].push_back(x);
    }

    x = 1;
    while (x)
    {
        for (int i = 1; i <= n; i++) viz[i] = 0;
        x = DFS(1, INT_MAX);
        flow += x;
    }
    fout << flow;
    return 0;
}

int DFS(int nod, int minim)
{
    if (nod == n)
        return minim;

    viz[nod] = 1;
    for (auto el : G[nod])
        if (!viz[el] && h[{nod, el}])
        {
            int x = DFS(el, min(minim, h[{nod ,el}]));
            h[{nod, el}] -= x;
            h[{el, nod}] += x;
            return x;
        }
    return 0;
}
