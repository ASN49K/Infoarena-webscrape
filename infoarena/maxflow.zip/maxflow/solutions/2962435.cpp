#include <bits/stdc++.h>

using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

vector<vector<int>> adj;
int cap[5001][5001], tata[5001], n, s, t;

bool bfs()
{
    queue <int> q;
    vector <bool> vizitat(n+1, false);

    q.push(s);
    vizitat[s] = true;
    tata[s] = -1;

    while(!q.empty())
    {
        int nod = q.front();
        q.pop();
        for(auto vecin : adj[nod])
        {
            if(!vizitat[vecin] && cap[nod][vecin] != 0)
            {
                tata[vecin] = nod;
                if(vecin == t)
                    return true;

                vizitat[vecin] = 1;
                q.push(vecin);
            }
        }
    }
    return false;
}

int maxflow()   //Alg. Edmonds Karp
{
    int maxim = 0;
    while (bfs())
    {
        int b, a = t, flow = INT_MAX;
        while(a != s)
        {
            b = tata[a];

            if(cap[b][a] < flow)
                flow = cap[b][a];

            a = b;
        }

        a = t;
        while(a != s)
        {
            b = tata[a];
            cap[b][a] -= flow;
            cap[a][b] += flow;
            a = b;
        }

        maxim += flow;
    }

    return maxim;
}

int main()
{
    int n, m, a, b, c, i;

    f >> n >> m;
    adj.resize(n+1);

    for(i = 0; i < m; i++){
        f >> a >> b >> c;
        adj[a].push_back(b);
        adj[b].push_back(a);
        cap[a][b] = c;
    }
    s = 1;  //start
    t = n;  //sink
    g << maxflow();
    return 0;

}
