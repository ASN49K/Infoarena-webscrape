#include <bits/stdc++.h>
using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
const int dim = 1002;
int n, flux[dim][dim], capacitate[dim][dim], tata[dim], max_flow;
bool viz[dim];
vector<int> a[dim];
queue<int>coada;

bool bfs (int sursa, int dest)
{
    for (int i = 1; i <= n; i++)
    {
        viz[i] = 0;
        tata[i] = 0;
    }

    coada.push(sursa);
    tata[sursa] = 0;
    viz[sursa] = 1;

    while (!coada.empty())
    {
        int x = coada.front();
        coada.pop();
        for (int y : a[x])
            if (!viz[y] && capacitate[x][y] - flux[x][y] > 0)
            {
                coada.push(y);
                viz[y] = 1;
                tata[y] = x;
            }
    }

    if (!viz[dest])
        return 0; ///nu am gasit drum sursa->dest

    return 1;
}

int main()
{
    int m, x, y, z, ok = 1;
    fin >> n >> m;
    while (m--)
    {
        fin >> x >> y >> z;
        capacitate[x][y]=z;
        a[x].push_back(y);
        a[y].push_back(x);
    }

    do
    {
        ok = bfs(1, n);
        if (ok)
        {
            ///pornesc din nodul dest si ma uit la muchiile inverse din el
            for (auto y : a[n])
            {
                ///drumul meu se termina cu muchia y ---> n
                int flux_minim = capacitate[y][n] - flux[y][n];
                for (int nod = y; nod != 1; nod = tata[nod])
                {
                    ///lucrez acum cu muchia tata[nod] --> nod
                    flux_minim = min(flux_minim, capacitate[tata[nod]][nod] - flux[tata[nod]][nod]);
                }

                ///pompez cu flux_minim pe drumul de crestere gasit
                max_flow += flux_minim;

                flux[y][n] += flux_minim;
                flux[n][y] -= flux_minim;
                for (int nod = y; nod != 1; nod = tata[nod])
                {
                    flux[tata[nod]][nod] += flux_minim;
                    flux[nod][tata[nod]] -= flux_minim;
                }
            }
        }
    }while (ok);

    fout << max_flow;
    return 0;
}
