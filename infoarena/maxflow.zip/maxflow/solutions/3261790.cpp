#include <fstream>
#include <queue>
using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
const int N=1001;
const int inf=1e9;
vector<short>adj[N];
int capacitate[N][N];
int n,m;
void citeste()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b,flux;
        cin>>a>>b>>flux;
        adj[a].push_back(b);
        adj[b].push_back(a);
        capacitate[a][b]=flux;
    }
}
int parent[N];
void init()
{
    for(int i=1;i<=n;i++)
        parent[i]=-1;
    parent[1]=0;
}
struct flow
{
    int nod,capacitate;
};
void tie(int &a ,int &b, flow x)
{
    a=x.nod;
    b=x.capacitate;
}

int size_of=0;
int st[N];
int bfs(short start,short finish)
{
    for(int i=1;i<=size_of;i++)
    {
        parent[st[i]]=-1;
    }
    size_of=0;
    parent[1]=0;
    queue<flow>q;
    int new_flow=inf;
    q.push({start,new_flow});
    while(!q.empty())
    {
        int nod,flux;
        nod=q.front().nod;
        flux=q.front().capacitate;
        q.pop();
        for(auto u:adj[nod])
        {
            if(parent[u]==-1&&capacitate[nod][u])
            {
                size_of++;
                st[size_of]=u;
                flux=min(flux,capacitate[nod][u]);
                q.push({u,flux});
                parent[u]=nod;
                if(u==finish)
                {
                    return flux;
                }
            }
        }
    }
    return -1;
}
void do_flux()
{
    int ans=0;
    int actual_flow=-1;
    bool ok=true;
    init();
    while(ok)
    {
        actual_flow=bfs(1,n);
        if(actual_flow==-1)
            break;
        ans+=actual_flow;
        int cur=n;
        while(cur!=1)
        {
            capacitate[cur][parent[cur]]+=actual_flow;
            capacitate[parent[cur]][cur]-=actual_flow;
            cur=parent[cur];
        }
    }
    cout<<ans;
}
int main()
{
    citeste();
    do_flux();
    return 0;
}
