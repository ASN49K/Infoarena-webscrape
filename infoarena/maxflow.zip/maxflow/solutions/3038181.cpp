///edmons karp
#include<stdc
#include<bitset>

#define inf 1e9

using namespace std;
int const N = 1003;
int n , m , a , b , c;
int f[N][N];
int q[N] , t[N];
vector<int> v[N];
bitset<N> viz;
bool bfs(){
    viz = 0;
    int l = 1 , r = 1;
    q[1] = viz[1] = 1;
    while(l <= r){
        int x = q[l++];
        for(int i : v[x]){
            if(f[x][i] > 0 && !viz[i]){
                viz[i] = 1;
                t[i] = x;
                q[++r] = i;
            }
        }
    }
    return viz[n];
}
int main(){
    freopen("maxflow.in" , "r" , stdin);
    freopen("maxflow.out" , "w" , stdout);
    scanf("%d%d" , &n , &m);
    for(int i = 1 ; i <= m ; ++ i){
        scanf("%d%d%d" , &a , &b , &c);
        f[a][b] = c;
        v[a].push_back(b);
        v[b].push_back(a);
    }
    int ans = 0;
    while(bfs()){
        int nf = inf , x = n;
        while(t[x]){
            nf = min(nf , f[t[x]][x]);
            x = t[x];
        }
        x = n;
        while(t[x]){
            f[t[x]][x] -= nf;
            f[x][t[x]] += nf;
            x = t[x];
        }
        ans += nf;
    }
    printf("%d\n" , ans);
    return 0;
}
