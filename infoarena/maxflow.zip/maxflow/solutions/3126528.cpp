#include <bits/stdc++.h>

using namespace std;

ifstream fin ("maxflow.in");
ofstream fout ("maxflow.out");

struct edge {
  int x, flow, cap, rev;
};
int n, m, S, D;
vector<edge>G[1002];
void add_edge (int x, int y, int f) {
  G[x].push_back({y, 0, f, (int)G[y].size()});
  G[y].push_back({x, 0, 0, (int)G[x].size() - 1});
}

int lvl[1002];
bool bfs(int f) {
  queue<int>q;
  q.push(S);
  for (int i = 1; i <= n; i++)
    lvl[i] = -1;
  lvl[S] = 0;
  while (!q.empty()) {
    auto x = q.front();
    q.pop();
    for (auto it : G[x]) {
      if (lvl[it.x] == -1 && ((it.cap - it.flow) >> (30 - f))) {
        lvl[it.x] = lvl[x] + 1;
        q.push(it.x);
      }
    }
  }
  return (lvl[D] != -1);
}

int dfs (int x, int flow) {
  if (x == D)
    return flow;
  for (int i = 0; i < G[x].size(); i++) {
    edge &it = G[x][i];
    if (lvl[it.x] == lvl[x] + 1) {
      if (int p = dfs(it.x, min(flow, it.cap - it.flow))) {
        it.flow += p;
        G[it.x][it.rev].flow -= p;
        return p;
      }
    }
  }
  return 0;
}

void solve () {
  S = 1, D = n;
  int ans = 0;
  for (int i = 30; i >= 0; i--) {
    while (bfs(i)) {
      while(int p = dfs(S, 1e9))
        ans += p;
    }
  }
  fout<< ans << "\n";
}


int main () 
{
  ios_base::sync_with_stdio(false);
  cin.tie(0); cout.tie(0);
  fin >> n >> m;
  for (int i = 1; i <= m; i++) {
    int x, y, z;
    fin >> x >> y >> z;
    add_edge(x, y, z);
  }
  solve();
  return 0;
}