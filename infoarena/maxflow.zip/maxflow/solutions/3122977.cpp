#include <fstream>
#include <vector>
#include <cstring>
#include <queue>

using namespace std;

const int N = 1000;
const int INF = 1 << 30;

int c[N+1][N+1], fl[N+1][N+1], pred[N+1], s, d, m, n;
vector <int> a[N+1];

bool exista_drum()
{
    memset(pred, 0, (n + 1)*sizeof(int));
    queue <int> q;
    q.push(s);
    pred[s] = -1;
    while (!q.empty())
    {
        int x = q.front();
        q.pop();
        for (auto y: a[x])
        {
            if (pred[y] == 0 && fl[x][y] < c[x][y])
            {
                q.push(y);
                pred[y] = x;
                if (y == d)
                {
                    return true;
                }
            }
        }
    }
    return false;
}

int flux_drum()
{
    int f = INF, x = d;
    while (x != s)
    {
        f = min(f, c[pred[x]][x] - fl[pred[x]][x]);
        x = pred[x];
    }
    return f;
}

void actualizare_drum(int f)
{
    int x = d;
    while (x != s)
    {
        fl[pred[x]][x] += f;
        fl[x][pred[x]] -= f;
        x = pred[x];
    }
}

int flux_maxim()
{
    int f = 0;
    while (exista_drum())
    {
        int fc = flux_drum();
        actualizare_drum(fc);
        f += fc;
    }
    return f;
}

int main()
{
    ifstream in("maxflow.in");
    ofstream out("maxflow.out");
    in >> n >> m;
    for (int i = 0; i < m; i++)
    {
        int x, y;
        in >> x >> y;
        in >> c[x][y];
        a[x].push_back(y);
        a[y].push_back(x);
    }
    s = 1;
    d = n;
    in.close();
    out << flux_maxim() << "\n";
    out.close();
    return 0;
}
