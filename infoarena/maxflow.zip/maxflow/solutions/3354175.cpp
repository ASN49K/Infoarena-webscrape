// https://infoarena.ro/problema/maxflow

//#ifdef _MSC_VER
//	#define _CRT_SECURE_NO_WARNINGS
//#elif  __GNUC__
//	#pragma GCC optimize("Ofast,unroll-loops,inline")
//	#pragma GCC target("avx2,bmi,bmi2,lzcnt,popcnt")
//#endif

//#define _USE_MATH_DEFINES

#include <iostream>
#include <fstream>
#include <utility>
#include <cstdint>
//#include <cstdio>
//#include <algorithm>
#include <vector>
//#include <array>
//#include <list>
//#include <forward_list>
//#include <string>
#include <cstring>
//#include <cmath>
//#include <bitset>
#include <queue>
//#include <stack>
//#include <map>
//#include <set>
//#include <unordered_map>
//#include <unordered_set>
//#include <limits>
#include <climits>
//#include <iomanip>
//#include <tuple>
//#include <numeric>
//#include <chrono>
//#include <memory>

using namespace std;

using int64 = int64_t;
using uint64 = uint64_t;
using int32 = int32_t;
using uint32 = uint32_t;
using int16 = int16_t;
using uint16 = uint16_t;
using pii = pair<int, int>;
using pll = pair<int64, int64>;

#define all(x) (x).begin(), (x).end()
#define allg(x) (x).begin(), (x).end(), greater<int>()
#define sz(x) (int)(x).size()
#define pb push_back
#define eb emplace_back
#define rfor(i, st, dr) for(auto i=(st); i<=(dr); ++i)
#define for0(i,n) for(auto i=0; i<(n); ++i)
#define rfor0(i,n) for(auto i=(n)-1; i>=0; --i)
#define for1(i,n) for(auto i=1; i<=(n); ++i)
#define rfor1(i,n) for(auto i=(n); i>=1; --i)
#define foreach(x,a) for(auto& x : a)
#define cforeach(x,a) for(const auto& x : a)
#define ft first
#define sd second
#define cendl cout << "\n"
#define fendl fout << "\n"
#define FASTIO ios::sync_with_stdio(false); cin.tie(nullptr);

//#define int int64

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

//FILE* fin = fopen("", "r");
//FILE* fout = fopen("", "w");

const int NRMAX = 1000;

int cost[NRMAX + 5][NRMAX + 5]; // matricea de costuri
vector<int> gr[NRMAX + 5]; // graf
int n, leg[NRMAX + 5]; // legatrui

void bfs()
{
	memset(leg, 0, sizeof(leg));
	queue<int> q;

	q.push(1);
	leg[1] = -1;

	while (!q.empty())
	{
		int nod = q.front();
		q.pop();

		cforeach(it, gr[nod])
		{
			if (!leg[it] && cost[nod][it] > 0)
			{
				leg[it] = nod; // dinspre vecin catre nodul vechi
				
				q.push(it);
			}
		}
	}
}

int32 main()
{
	//FASTIO;

	int m, i, x, y, z;
	fin >> n >> m;

	for (i = 0; i < m; ++i)
	{
		fin >> x >> y >> z;

		gr[x].pb(y);
		gr[y].pb(x); // adaug si cealalta directie

		cost[x][y] = z;
	}
	
	int maxflow = 0;

	bfs();
	while (leg[n])
	{
		//cout << maxflow << "\n";

		cforeach(it, gr[n])
		{
			if(!leg[it] || cost[it][n] <= 0)
				continue;
			leg[n] = it;

			int flow = INT_MAX;
			for (int i = n; i != 1; i = leg[i])
				flow = min(flow, cost[leg[i]][i]);

			for (int i = n; i != 1; i = leg[i])
			{
				cost[leg[i]][i] -= flow;
				cost[i][leg[i]] += flow;
			}
			maxflow += flow;
		}

		bfs();
	}

	fout << maxflow << "\n";

	return 0;
}
