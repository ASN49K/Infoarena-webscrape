#include <bits/stdc++.h>
#define N 1004
#define inf 2e9

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

int n, m;
int sursa;
struct muchie{
    int f, c;
    int type;
} M[N][N];
vector<int> g[N];

void Citire()
{
    int i;
    int x, y, c;
    fin >> n >> m;
    sursa = 1;
    for( i=1; i<=m; i++ ){
        fin >> x >> y >> c;
        g[x].push_back(y);  M[x][y] = {0, c, +1};
        g[y].push_back(x);  M[y][x] = {0, c, -1};
    }
}

bool ok;
int Dad[N];
bool viz[N];
queue<pair<int, int>> Q;
int BFS()
{
    while(!Q.empty())Q.pop();
    for( int i=1; i<=n; i++ )
        Dad[i] = 0, viz[i] = 0;
    Dad[sursa] = -1;
    Q.push({sursa, inf});
    while( !Q.empty() )
    {
        int nod = Q.front().first;
        int flux = Q.front().second;
        Q.pop();
        if( nod == n ) ok = 0;
        for( auto next : g[nod] )if( Dad[next] == 0 ){

            if( M[nod][next].c <= 0 ) continue;
            Dad[next] = nod;
            int flux_nou = min(flux, M[nod][next].c);
            if( next == n ){
                return flux_nou;
            }
            Q.push({next, flux_nou});

        }
    }
    return -1;
}

void Revizuire( int x, int flux )
{
    if( x == sursa ) return;
    M[Dad[x]][x].c -= flux;
    M[x][Dad[x]].c += flux;
    Revizuire( Dad[x], flux );
}

void Rezolvare()
{
    ///Ford_Fulkerson
    int F = 0;
    while(true){
        int flux = BFS();
        if( flux == -1 ) break;
        F += flux;
        Revizuire(n, flux);
    }

    fout << F;
}

int main()
{
    Citire();
    Rezolvare();
    return 0;
}
