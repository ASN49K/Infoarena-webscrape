#include <bits/stdc++.h>
using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");
int n,m,i,j,a,b,c,s,t;
struct Dinic{
    struct edge{
        int x;
        int cap;
        int ind;
    };
    vector<edge>V[1004];
    int dist[1004],viz[1004],last[1004];
    void add_edge(int a,int b, int c){
        V[a].push_back({b,c,V[b].size()});
        V[b].push_back({a,0,V[a].size()-1});
    }
    int bfs(int node=s){
        for (int i=1;i<=n;i++){
            dist[i]=2004;
            last[i]=0;
        }
        queue<int>Q;
        dist[node]=0;
        Q.push(node);

        while(!Q.empty()){
            int now=Q.front();
            Q.pop();
            for (auto &[to,c,_]:V[now]){
                if (c&&dist[to]==2004){
                    dist[to]=dist[now]+1;
                    Q.push(to);
                }
            }
        }
        return (dist[t]!=2004);
    }
    int dfs(int node,int flow=1e9){
        if (flow==0){
            return 0;
        }
        if (node==t){
            return flow;
        }
        for (;last[node]<V[node].size();last[node]++){
            int i=last[node];
            auto &it=V[node][i];
            if ((dist[it.x]==dist[node]+1)&&it.cap){
                int f=dfs(it.x,min(flow,it.cap));
                if (f){
                    it.cap-=f;
                    V[it.x][it.ind].cap+=f;
                    return f;
                }
            }
        }
        return 0;
    }
    int solve (){
        int sol=0;
        while(bfs()){
            sol+=dfs(s);

        }
        g<<sol<<'\n';
    }
};
int main()
{   f>>n>>m;
    Dinic dinic;
    for (i=1;i<=m;i++){
        f>>a>>b>>c;
        dinic.add_edge(a,b,c);
    }
    s=1;
    t=n;
    dinic.solve();
    return 0;
}
