#include <bits/stdc++.h>

const int NMAX = 5e5 + 5;

struct flowEdge {
    int u, v, cap;
};

int n, m, f[NMAX], lev[NMAX], ptr[NMAX];

std :: vector < flowEdge > edges;
std :: vector < int > G[NMAX];

int BFS(int node) {
    for (int i = 1; i <= n; ++ i)
        f[i] = false;

    std :: queue < int > Q;

    f[node] = true;
    lev[node] = 1;
    Q.push(node);

    while (!Q.empty()) {
        int u = Q.front();

        for (int i = 0; i < G[u].size(); ++ i) {
            int x = G[u][i];

            if (f[edges[x].v] == false && edges[x].cap > 0) {
                f[edges[x].v] = true;
                lev[edges[x].v] = lev[u] + 1;
                Q.push(edges[x].v);
            }
        }

        Q.pop();
    }

    return (f[n] == true);
}

int DFS(int node, int pushed) {
    if (pushed == 0)
        return 0;

    if (node == n)
        return pushed;

    f[node] = true;

    for (int &i = ptr[node]; i < G[node].size(); ++ i) {
        int x = G[node][i];

        if (f[edges[x].v] == false && edges[x].cap > 0) {
            f[edges[x].v] = true;

            int t = DFS(edges[x].v, std :: min(pushed, edges[x].cap));

            if (t) {
                edges[x].cap -= t;
                edges[x ^ 1].cap += t;

                return t;
            }
        }
    }

    return 0;
}

std :: ifstream fin("maxflow.in");
std :: ofstream fout("maxflow.out");

int main() {
    fin >> n >> m;

    for (int i = 1, u, v, cap; i <= m; ++ i) {
        fin >> u >> v >> cap;

        edges.push_back({u, v, cap});
        G[u].push_back(edges.size() - 1);

        edges.push_back({v, u, 0});
        G[v].push_back(edges.size() - 1);
    }

    int flow = 0;

    while (BFS(1)) {
        for (int i = 1; i <= n; ++ i) {
            ptr[i] = 0;
            f[i] = false;
        }

        int t;

        while (t = DFS(1, 1e9)) flow += t;
    }

    fout << flow;

    return 0;
}
