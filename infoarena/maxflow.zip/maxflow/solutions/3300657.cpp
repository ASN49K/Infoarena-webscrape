#include <bits/stdc++.h>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

vector<vector<int>> cap;
vector<vector<int>> adj;
int n;

vector<int> bfs(int s, int t, vector<int>& p) {
    queue<pair<int, int>> q;
    vector<int> minflows;
    fill(p.begin(), p.end(), -1);

    q.push({s, INT_MAX});

    while(!q.empty()) {
        auto& [nod, minf] = q.front();
        q.pop();

        if (nod == t)
            return minflows;
        for (int neigh : adj[nod])
            if (p[neigh] == -1 && cap[nod][neigh]) {
                p[neigh] = nod;
                
                minf = min(minf, cap[nod][neigh]);
                if (neigh == t)
                    minflows.push_back(minf);

                q.push({neigh, minf});
            }
    }

    return {};
}

int edmonds_karp(int s, int t) {
    int maxflow = 0;
    vector<int> newflow;
    vector<int> p(n + 1);

    while(1) {
        newflow = bfs(s, t, p);
        if (!newflow.size())
            break;
        for (int flow : newflow) {
            int curr = t;
            
            while(curr != s) {
                int prev = p[curr];
                cap[curr][prev] += flow;
                cap[prev][curr] -= flow;
                curr = prev;
            }
            
            maxflow += flow;
        }
    }

    return maxflow;
}

int main() {
    int m;

    fin >> n >> m;
    cap.resize(n + 1, vector<int>(n + 1));
    adj.resize(n + 1);

    for (int i = 1, x, y, w; i <= m; ++i) {
        fin >> x >> y >> w;
        cap[x][y] = w;
        adj[x].push_back(y);
    }

    fout << edmonds_karp(1, n);
}