#include <bits/stdc++.h>

using namespace std;
ifstream in("maxflow.in");
ofstream out("maxflow.out");

int N;
int graf_rezidual[1001][1001];

bool BFS(int s, int t, int tata[]){
    int vizitat[N + 1];
    for(int i = 1; i <= N; i++)
        vizitat[i] = 0;

    queue<int> q;
    q.push(s);
    tata[s] = 0;
    vizitat[s] = 1;

    while(!q.empty()){
        int v = q.front();
        q.pop();

        for(int i = 1; i <= N; i++)
            if(!vizitat[i] && graf_rezidual[v][i] > 0){
                tata[i] = v;

                if(i == t)
                    return true;

                q.push(i);
                vizitat[i] = 1;
            }
    }

    return false;
}

int ford_fulkerson(int s, int t){
    int maxflow = 0;
    int tata[N + 1];

    while(BFS(s, t, tata)){
        int new_found_flow = INT_MAX;

        int v = t;
        while(v != s){
            new_found_flow = min(new_found_flow, graf_rezidual[tata[v]][v]);
            v = tata[v];
        }

        v = t;
        while(v != s){
            graf_rezidual[tata[v]][v] -= new_found_flow;
            graf_rezidual[v][tata[v]] += new_found_flow;
            v = tata[v];
        }

        maxflow += new_found_flow;
    }

    return maxflow;
}

int main()
{
    int M;
    in >> N >> M;

    int x, y, z;
    while(in >> x >> y >> z){
        graf_rezidual[x][y] = z;
        if(!graf_rezidual[y][x])
            graf_rezidual[y][x] = 0;
    }

    int F = ford_fulkerson(1, N);
    out << F;
    return 0;
}
