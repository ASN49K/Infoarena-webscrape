#include <bits/stdc++.h>
#include <fstream>
#define cin fin
#define cout fout
#define Nmax 1008
using namespace std;
ifstream cin ("maxflow.in");
ofstream cout ("maxflow.out");
int frec[Nmax],nvl[Nmax],mat[Nmax][Nmax];
int i,a,b,c,n,dest,sursa,x,ras,m;
vector<int>G[Nmax];
void bfs(int nod)
{
    queue<int>Q;
    for(int i=sursa;i<=dest;i++)
    {
        nvl[i]=-1;
        frec[i]=0;
    }
    nvl[nod]=0;
    Q.push(nod);
    while(!Q.empty())
    {
        nod=Q.front();
        Q.pop();
        for(auto i:G[nod])
        {
            if(nvl[i]==-1 && mat[nod][i]>0)
            {
                nvl[i]=nvl[nod]+1;
                Q.push(i);
            }
        }
    }
}
int dfs(int nod,int minn)
{
    if(nod==dest || minn==0)
        return minn;
    while(frec[nod]<G[nod].size())
    {
        int k=G[nod][frec[nod]];
        if(mat[nod][k]>0 && nvl[nod]+1==nvl[k])
        {
            x=dfs(k,min(minn,mat[nod][k]));
            if(x>0)
            {
                mat[nod][k]-=x;
                mat[k][nod]+=x;
                return x;
            }
            else
            frec[nod]++;
        }
        else
        frec[nod]++;
    }
    return 0;
}
bool flux(int nod)
{
    bfs(nod);
    if(nvl[dest]==-1)
    {
        return 0;
    }
    else
    {
        int val=0;
        while(true)
        {
            x=dfs(1,1e9);
            if(x==0)
                break;
            val+=x;
        }
        ras+=val;
        return (val!=0);
    }
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        cin>>a>>b>>c;
        G[a].push_back(b);
        G[b].push_back(a);
        mat[a][b]=c;
    }
    sursa=1;
    dest=n;
    while(flux(sursa));
    cout<<ras;
    return 0;
}
