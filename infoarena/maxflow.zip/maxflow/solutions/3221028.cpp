#include <bits/stdc++.h>
//Soltan Cristian
#define ll long long
#define pb push_back
#define sz(x) (ll)x.size()
#define all(x) x.begin(), x.end()
#define rall(x) x.begin(), x.end()
#define st first
#define nd second


using namespace std;
string __fname = "maxflow";
ifstream in(__fname + ".in");
ofstream out (__fname + ".out");
#define cin in
#define cout out

const ll MAXN(1001);
const ll MAXX(5001 * 2);
struct Edge{
    int u, v;
    ll cap, flow = 0;
};
vector<vector<int>> adj;
vector<Edge> edges;
vector<int> lvl, ptr;
int n, m;


bool bfs(){
    queue<int> q;
    q.push(1);
    lvl[1] = 0;
    while(!q.empty()){
        int u = q.front();
        q.pop();
        for(auto id : adj[u]){
            if(lvl[edges[id].v] == -1 && edges[id].cap - edges[id].flow > 0){
                lvl[edges[id].v] = lvl[u] + 1;
                q.push(edges[id].v);
            }
        }
    }
    if(lvl[n] == -1){
        return 0;
    }
    return 1;
}

ll dfs(int u, ll mxf){
    if(mxf == 0){
        return 0;
    }
    if(u == n){
        return mxf;
    }
    for(int& id = ptr[u]; id < sz(adj[u]); id++){
        int id1 = adj[u][id];
        if(lvl[edges[id1].v] != lvl[u] + 1 || edges[id1].cap - edges[id1].flow < 1)
            continue;
        ll fl = dfs(edges[id1].v, min(edges[id1].cap - edges[id1].flow, mxf));
        if(fl == 0){
            continue;
        }
        edges[id1].flow += fl;
        edges[id1 ^ 1].flow -= fl;
        return fl;
    }

}







void solve(){
    cin >> n >> m;
    adj.resize(n + 1);
    edges.resize(2 * m  + 1);
    int k = 0;
    for(int i = 0; i < m; i++){
        int a, b, c;
        cin >> a >> b >> c;
        adj[a].pb(k);
        adj[b].pb(k + 1);
        edges[k].u = a; edges[k].v = b; edges[k].cap = c;
        edges[k].u = b; edges[k + 1].v = a; edges[k + 1].cap = 0;
        k += 2;
    }
    lvl.resize(n + 1);
    ptr.resize(n + 1);
    ll rs  = 0;
    while(true){
        fill(all(lvl), -1);
        if(!bfs())
            break;
        fill(all(ptr), 0);
        while(ll pushed = dfs(1, 1e18)){
            rs += pushed;
        }
    }
    cout << rs << '\n';

}

int main()
{
    ios_base::sync_with_stdio(0); cin.tie(0);
//    int t; cin >> t;
//    while(t--)
        solve();
    return 0;
}
