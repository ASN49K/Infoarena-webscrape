#include <bits/stdc++.h>

using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
const int INF=1e9;
int n,m,ans,S,D;
int cap[1005][1005];
vector<int> muchii[1005];
int dist[1005],p[1005];
int dfs(int nod,int c)
{
    if(nod==D||c==0)
        return c;
    while(p[nod]<muchii[nod].size())
    {
        int i=muchii[nod][p[nod]];
        p[nod]++;
        if(cap[nod][i]>0&&dist[i]==dist[nod]+1)
        {
            int x=dfs(i,min(cap[nod][i],c));
            if(x>0)
            {
                cap[nod][i]-=x;
                cap[i][nod]+=x;
                return x;
            }
        }
    }
    return 0;
}
bool flux()
{
    for(int i=1;i<=n;i++)
    {
        dist[i]=INF;
        p[i]=0;
    }
    dist[S]=0;
    queue<int> coada;
    coada.push(S);
    while(!coada.empty())
    {
        int nod=coada.front();
        coada.pop();
        for(int i:muchii[nod])
            if(cap[nod][i]>0&&dist[i]>dist[nod]+1)
            {
                dist[i]=dist[nod]+1;
                coada.push(i);
            }
    }
    if(dist[D]==INF)
        return 0;
    int val=0;
    while(true)
    {
        int x=dfs(S,INF);
        if(x==0)
            break;
        val+=x;
    }
    ans+=val;
    if(val==0)
        return 0;
    return 1;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    S=1;
    D=n;
    for(int i=1;i<=m;i++)
    {
        int a,b,c;
        fin>>a>>b>>c;
        muchii[a].push_back(b);
        muchii[b].push_back(a);
        cap[a][b]=c;
    }
    while(flux());
    fout<<ans;
    return 0;
}
