#include<fstream>
#include<vector>
#include<queue>
#include<algorithm>
using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

class Graph
{
private:

    const int INF = 1 << 30;
    struct muchie
    {
        int to,ind,flow,cap;
    };

    vector<vector<muchie>> vecini;

    vector<int> dist,rem;

    int n,s,t;

    bool bfs()
    {
        fill(dist.begin(),dist.end(),INF);
        dist[s] = 0;

        queue<int> q; q.push(s);
        while(!q.empty())
            {
                int v = q.front(); q.pop();
                for(auto &it : vecini[v])
                    {
                        if(it.cap <= it.flow || dist[it.to] != INF) continue;
                        dist[it.to] = dist[v] + 1;
                        q.push(it.to);
                    }
            }

        return (dist[t] != INF);
    }

    int dfs(int nod,int f)
    {
        if(nod == t) return f;
        for(int &h = rem[nod] ; h < vecini[nod].size() ; h++)
            {
                muchie &care = vecini[nod][h];
                if(dist[nod] + 1 != dist[care.to] || care.flow >= care.cap) continue;

                int exp = dfs(care.to,min(f,care.cap - care.flow));
                if(exp)
                    {
                        care.flow += exp;
                        vecini[care.to][care.ind].flow -= exp;

                        return exp;
                    }

            }

        return 0;
    }

public :

    Graph(int _n,int _s,int _t)
    {
        vecini.resize(_n + 1);
        dist.resize(_n + 1);
        rem.resize(_n + 1);

        n = _n,s = _s,t = _t;
    }

    void add(int a,int b,int c)
    {
        vecini[a].push_back({b,vecini[b].size(),0,c});
        vecini[b].push_back({a,vecini[a].size() - 1,0,0});
    }

    int maxflow()
    {
        int ans = 0;
        while(bfs())
            {
                fill(rem.begin(),rem.end(),0);
                int delta = dfs(s,INF);
                while(delta > 0)
                    {
                        ans += delta;
                        delta = dfs(s,INF);
                    }

            }

        return ans;
    }
};

int main()
{
    int n,m,a,b,c; fin >> n >> m;
    Graph graph(n,1,n);

    while(m--)
        {
            fin >> a >> b >> c;
            graph.add(a,b,c);
        }

    fout << graph.maxflow();
}
