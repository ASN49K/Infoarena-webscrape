#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cstring>

#define MAX_N 1000
#define MAX_M 5000

std::ifstream in("maxflow.in");
std::ofstream out("maxflow.out");

int n, m;
int c[MAX_N + 1][MAX_N + 1], f[MAX_N + 1][MAX_N + 1], t[MAX_N + 1], flow;
bool vis[MAX_N + 1], inv[MAX_N + 1][MAX_N + 1];
std::vector<int> adj[MAX_N + 1];
std::queue<int> q;

void read()
{
    in>>n>>m;
    int x, y, z;
    for(int i = 0;i < m;i++)
    {
        in>>x>>y>>z;
        adj[x].push_back(y);
        adj[y].push_back(x);
        c[x][y] = z;
    }
}

bool bfs()
{
    memset(vis, 0, sizeof(vis));
    q.push(1);
    vis[1] = true;

    while(!q.empty())
    {
        int curr = q.front();
        q.pop();
        if(curr == n) continue;
        for(const auto& it : adj[curr])
        {
            if(!vis[it] && f[curr][it] != c[curr][it])
            {
                q.push(it);
                vis[it] = true;
                t[it] = curr;
            }
        }
    }

    return vis[n];
}

void solve()
{
    int fmin;
    while(bfs())
    {
        for (const auto &it: adj[n])
        {
            int nod = it;
            if (vis[nod] && c[nod][n] != f[nod][n])
            {
                t[n] = nod;
                fmin = 1e9;
                for (int i = n; i != 1; i = t[i])
                    fmin = std::min(fmin, c[t[i]][i] - f[t[i]][i]);

                for (int i = n; i != 1; i = t[i])
                {
                    f[t[i]][i] += fmin;
                    f[i][t[i]] -= fmin;
                }
                flow += fmin;
            }
        }
    }
    out<<flow<<'\n';
}

int main()
{
    read();
    solve();
    return 0;
}