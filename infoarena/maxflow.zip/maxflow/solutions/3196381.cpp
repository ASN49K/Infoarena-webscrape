#include <iostream>
#include <fstream>
#include <utility>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;
ifstream in("maxflow.in");
ofstream out("maxflow.out");

vector<int>ls[101],ls1[101];
int c[101][101], f[101][101];
int fluxin[101], fluxout[101];
int viz[101],tata[101];

int bfs_lant(int s, int t) {
	int ok = 0;
	queue<int>q;
	memset(viz, 0, sizeof(viz));
	viz[s] = 1;
	q.push(1);
	while (!q.empty()) {
		int x = q.front();
		q.pop();
		for (auto y : ls[x]) {
			if (viz[y] == 0 && c[x][y] != f[x][y]) {
				viz[y] = 1;
				q.push(y);
				tata[y] = x;
				if (y == t) {
					ok = 1;
					break;
				}
			}
		}
	}
	return ok;
}



int edmondsKarp(int s, int t) {
	int total=0;
	while (bfs_lant(s, t)) {
		int flux_min = 999999999;
		for (int nod = t; nod != s; nod = tata[nod]) {
			flux_min = min(flux_min, c[tata[nod]][nod] - f[tata[nod]][nod]);
		}
		for (int nod = t; nod != s; nod = tata[nod]) {
			f[tata[nod]][nod] += flux_min;
			f[nod][tata[nod]] -= flux_min;
		}
		total += flux_min;
	}
	return total;
}

int main() {
	int n, s, t;
	in >> n;
	int m;
	in >> m;
	s = 1;
	t = n;
	while (m--) {
		int a, b, capacitate, flux=0;
		in >> a >> b >> capacitate ;
		ls[a].push_back(b);
		ls1[a].push_back(b);
		ls[b].push_back(a);
		c[a][b] = capacitate;
		c[b][a] = capacitate;
		f[a][b] = flux;
		f[b][a] = capacitate - flux;
		fluxin[b] += flux;
		fluxout[a] += flux;
	}
	
	
	out << edmondsKarp(s, t);
	
}