#include<bits/stdc++.h>
#define int long long
#define INF 1000000000000000000
using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");

int n,m,a[1005][1005],s,d,sol=0,tata[1005],viz[1005],mindist[1005];
vector<int>v[1005];
queue<int>q;

int bfs()
{
    int i;
    for(i=1;i<=n;i++)
        viz[i]=0,tata[i]=0;
    viz[s]=1;
    q.push(s);
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(auto it:v[nod])
        {
            if(viz[it]==0 && a[nod][it]>0)
            {
                viz[it]=1;
                tata[it]=nod;
                q.push(it);
            }
        }
    }
    if(viz[d]==1)
        return 1;
    return 0;
}

void flux()
{
    int nr,flow;
    while(bfs()!=0)
    {
        for(auto it:v[d])
        {
            if(a[it][d]>0 && (tata[it]>0 || it==s))
            {
                flow=a[it][d];
                nr=it;
                for(nr=it;nr!=s;nr=tata[nr])
                {
                    flow=min(flow,a[tata[nr]][nr]);
                    if(flow==0)
                        break;
                }
                if(flow!=0)
                {
                    a[it][d]-=flow;
                    a[d][it]+=flow;
                    for(nr=it;nr!=s;nr=tata[nr])
                    {
                        a[tata[nr]][nr]-=flow;
                        a[nr][tata[nr]]+=flow;
                    }
                    sol+=flow;
                }
            }
        }
    }
}

signed main()
{
    int i,x,y,z;
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>z;
        v[x].push_back(y);
        v[y].push_back(x);
        a[x][y]+=z;
        a[y][x]=0;
    }
    s=1;
    d=n;
    flux();
    g<<sol;
    return 0;
}
