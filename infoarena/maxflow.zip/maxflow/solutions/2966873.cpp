#include<fstream>
#include<vector>
#include<algorithm>
#include<queue>
using namespace std;

class Graph
{
private:
    const int INF = 1 << 30;
    struct muchie
    {
        int to,ind,cap,flow;
    };

    vector<vector<muchie>> vecini;
    vector<int> dist,rem;
    int n,s,t;

    bool bfs()
    {
        fill(dist.begin(),dist.end(),INF);
        queue<int> q; q.push(s);

        dist[s] = 0;

        while(!q.empty())
            {
                int v = q.front(); q.pop();
                for(auto it : vecini[v])
                    {
                        if(dist[it.to] != INF || it.flow >= it.cap) continue;
                        dist[it.to] = dist[v] + 1;
                        q.push(it.to);
                    }
            }

        return (dist[t] != INF);

    }

    int dfs(int nod,int flow)
    {
        if(nod == t)
            return flow;

        for(int &h = rem[nod] ; h < vecini[nod].size() ; h++)
            {
                muchie &m = vecini[nod][h];
                if(dist[m.to] != dist[nod] + 1 || m.flow >= m.cap) continue;
                int rez = dfs(m.to,min(flow,m.cap - m.flow));
                if(rez)
                    {
                        m.flow += rez;
                        vecini[m.to][m.ind].flow -= rez;
                        return rez;
                    }
            }

        return 0;

    }

public:

    Graph (int _n,int _s,int _t)
    {
        n = _n,s = _s,t = _t;
        vecini.resize(n + 1);
        dist.resize(n + 1);
        rem.resize(n + 1);
    }

    void add(int a,int b,int c)
    {
        vecini[a].push_back({b,vecini[b].size(),c,0});
        vecini[b].push_back({a,vecini[a].size() - 1,0,0});
    }

    int maxflow()
    {
        int ans = 0;
        while(bfs())
            {
                fill(rem.begin(),rem.end(),0);
                int delta = dfs(s,INF);
                while(delta)
                    {
                        ans += delta;
                        delta = dfs(s,INF);
                    }
            }

        return ans;
    }


};

int main()
{
    ifstream cin("maxflow.in");
    ofstream cout("maxflow.out");
    int n,m,a,b,c; cin >> n >> m;
    Graph graph(n,1,n);

    while(m--)
        {
            cin >> a >> b >> c;
            graph.add(a,b,c);
        }

    cout << graph.maxflow();
}
