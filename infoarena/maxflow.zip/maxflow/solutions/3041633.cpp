#include <bits/stdc++.h>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

const int NMAX = 1000, MMAX = 5000;

int n, m, ans,
    cap[NMAX + 1][NMAX + 1], flux[NMAX + 1][NMAX + 1],
    t[NMAX + 1];
bool v[NMAX + 1];
vector<int> adj[NMAX + 1];
queue<int> q;

inline bool availablePath() {
    q.push(1);
    memset(v, 0, sizeof(v));
    v[1] = 1;
    t[1] = 0;
    while(!q.empty()) {
        const int crt = q.front();
        q.pop();

        if(crt == n) continue;

        for(const auto &el : adj[crt]) {
            if(!v[el] && flux[crt][el] < cap[crt][el])  {
                v[el] = 1;
                t[el] = crt;
                q.push(el);
            }
        }
    }
    return v[n];
}

void calcFluxMax() {
    while(availablePath()) {
        for(const auto &el : adj[n]) {
            if(!v[el] || flux[el][n] == cap[el][n]) continue;
            t[n] = el;

            int addMax = 2e9;
            for(int nod = n; t[nod]; nod = t[nod])
                addMax = min(addMax, cap[t[nod]][nod] - flux[t[nod]][nod]);

            for(int nod = n; t[nod]; nod = t[nod])
                flux[t[nod]][nod] += addMax,
                flux[nod][t[nod]] -= addMax;
            ans += addMax;
        }
    }
}

int main()
{
    fin >> n >> m;
    for(int i = 1, x, y, c; i <= m; ++i) {
        fin >> x >> y >> c;
        adj[x].push_back(y);
        adj[y].push_back(x);
        cap[x][y] = c;
    }
    calcFluxMax();
    fout << ans;
    return 0;
}
