#include <iostream>
#include <bits/stdc++.h>
using namespace std;



ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

const int nmax=1024,inf=0x3f3f3f3f;
int n,m,x,y,z,nod,nod2;
vector<vector<int> > graf;
int c[nmax][nmax],TT[nmax],f[nmax][nmax];
bitset<nmax> vas;
queue<int> cd;

int bf(){
while(!cd.empty())
    cd.pop();

cd.push(1);
vas.reset();
vas[1]=1;
while(!cd.empty()){
    nod2=cd.front();
    cd.pop();
    if(nod2==n)continue;
    for(int i:graf[nod2]){
        if(!vas[i]&&c[nod2][i]>f[nod2][i]){
            cd.push(i);
            vas[i]=1;
            TT[i]=nod2;
        }
    }
}
if(vas[n]==1)return 1;
return 0;
}

int df(int nod){
    vas[nod]=1;
    for(int i:graf[nod]){
        if(!vas[i]&&c[nod][i]>f[nod][i]){
            //cout<<c[nod][i]<<" "<<f[nod][i]<<" ";
            TT[i]=nod;
            df(i);
        }
    }
    return vas[n];
}





int main()
{
    int flow,fmin;
    fin>>n>>m;
    graf.assign(n+1,vector<int>());
    for(int i=0;i<m;i++){
        fin>>x>>y>>z;
        c[x][y]+=z;
        graf[x].push_back(y);
        graf[y].push_back(x);
    }
    //cout<<df(1);
    for(flow=0;df(1);){
        for(int i:graf[n]){
        fmin=inf;
        if (f[i][n]==c[i][n]||!vas[i]) continue;
        TT[n]=i;
        for(nod=n;nod!=1;nod=TT[nod]){
            fmin=min(fmin,c[TT[nod]][nod]-f[TT[nod]][nod]);
        }
        for(nod=n;nod!=1;nod=TT[nod]){
            f[TT[nod]][nod]+=fmin;
            f[nod][TT[nod]]-=fmin;
        }
        flow+=fmin;
        }
        vas.reset();
    }
    fout<<flow;
    return 0;
}
