#include <bits/stdc++.h>
#define MOD 1000000007
#define int long long
using namespace std;
int i,n,m,a,b,c,cost[1008][1008],dest,surs,frec[1008],niv[1008];
vector<int>G[1008];
void bfs(int nod)
{
    queue<int>Q;
    Q.push(nod);
    for(i=1;i<=n;i++)
    {
        niv[i]=-1;
        frec[i]=0;
    }
    niv[nod]=1;
    while(!Q.empty())
    {
        nod=Q.front();
        Q.pop();
        for(auto i:G[nod])
        {
            if(niv[i]==-1 && cost[nod][i]>0)
            {
                Q.push(i);
                niv[i]=niv[nod]+1;
            }
        }
    }
}
int dfs(int nod,int minn)
{
    if(nod==dest || minn==0)
        return minn;
    while(frec[nod]<G[nod].size())
    {
        int i=G[nod][frec[nod]];
        if(niv[i]==niv[nod]+1 && cost[nod][i]>0)
        {
            int aux=dfs(i,min(minn,cost[nod][i]));
            if(aux>0)
            {
                cost[nod][i]-=aux;
                cost[i][nod]+=aux;
                return aux;
            }
            else
                frec[nod]++;
        }
        else
        {
            frec[nod]++;
        }
    }
    return 0;
}
int flux()
{
    int ras=0;
    bfs(surs);
    if(niv[dest]==-1)
        return ras;
    while(true)
    {
        int aux=dfs(surs,1e9);
        if(aux==0)
            break;
        ras+=aux;
    }
    return ras;
}
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>a>>b>>c;
        G[a].push_back(b);
        G[b].push_back(a);
        cost[a][b]=c;
    }
    surs=1;
    dest=n;
    long long rez=0;
    while(long long ax=flux())rez+=ax;
    cout<<rez;
    return 0;
}
