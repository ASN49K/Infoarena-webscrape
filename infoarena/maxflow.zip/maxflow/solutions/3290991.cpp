// 70 Puncte
#include <bits/stdc++.h>

using namespace std;

ifstream fin ("maxflow.in");
ofstream fout ("maxflow.out");

vector <int> g[1005];
int cap[1005][1005];
int flux[1005][1005];
bool viz[1005];
int n, m;
int tt[1005];
vector <int> vecini_radacina;
// bool dfs (int nod)
// {
//     bool main_status = false;
//     viz[nod]=1;
//     for (int vecin : g[nod]) {
//         if (!viz[vecin]) {
//             int fv = flux[nod][vecin];
//             int cp = cap[nod][vecin];
//             if (cp-fv>0) {
//                 if (vecin==n) {
//                     vecini_radacina.push_back(nod);
//                     return true;
//                 } else {
//                     bool status = dfs(vecin);
//                     if (status) {
//                         main_status = true;
//                         tt[vecin]=nod;
//                     }
//                 }
//             }
//         }
//     }
//     return main_status;
// }
void bfs (int nod)
{
    queue <int> q;
    q.push(nod);
    viz[nod]=1;
    while (!q.empty()) {
        nod = q.front();
        q.pop();
        for (int vecin : g[nod]) {
            if (!viz[vecin]) {
                int fv = flux[nod][vecin];
                int cp = cap[nod][vecin];
                if (cp-fv>0) {
                    if (vecin==n) {
                        vecini_radacina.push_back(nod);
                    } else {
                        tt[vecin] = nod;
                        viz[vecin]=1;
                        q.push(vecin);
                    }
                }
            }
        }
    }
}

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    fin>>n>>m;
    for (int i=1; i<=m; i++) {
        int x, y, c;
        fin>>x>>y>>c;
        g[x].push_back(y);
        g[y].push_back(x);
        cap[x][y]=c;
    }
    int max_flow = 0, mai_merge = 0;
    do {
        mai_merge = 0;
        memset(viz, 0, sizeof(viz));
        vecini_radacina.clear();
        //dfs(1);
        bfs(1);
        for (int nod : vecini_radacina) {
            int copy_nod = nod;
            int min_flow = cap[nod][n]-flux[nod][n]; // Fluxul e capacitatea - fluxul curent
            while (tt[nod]!=0) {
                int tata = tt[nod];
                int fx = flux[tata][nod];
                int cp = cap[tata][nod];
                int flow = cp-fx;
                min_flow = min(flow, min_flow);
                nod = tata;
            }
            mai_merge = max(mai_merge, min_flow);
            nod = copy_nod;
            flux[nod][n]+=min_flow;
            flux[n][nod]-=min_flow;
            while (tt[nod]!=0) {
                int tata = tt[nod];
                flux[tata][nod]+=min_flow;
                flux[nod][tata]-=min_flow;
                nod = tata;
            }
            max_flow+=min_flow;
        }
    } while (mai_merge);
    fout<<max_flow;
    return 0;
}