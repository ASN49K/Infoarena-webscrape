#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

int n, m, max_flow;
vector<vector<int>> adjacence_list;
vector <vector <int>> cap;
vector <int> root;


bool bfs() {
    root.assign(n + 1, 0);
    queue <int> q;

    q.push(1);

    while (!q.empty()) {
        int nod = q.front();
        q.pop();

        if (nod == n) {
            return true;
        }
        for (auto vecin : adjacence_list[nod]) {
            int current_cap = cap[nod][vecin];

            if (current_cap > 0 && root[vecin] == 0) {
                root[vecin] = nod;
                q.push(vecin);
            }
        }
    }

    return false;
}



int main() {
    f >> n >> m;
    adjacence_list = vector<vector<int>>(n + 1);
    root.resize(n + 1, 0);
    cap.resize(n + 1, vector <int>(n + 1, 0));

    int x, y, z;
    for (int i = 0; i < m; ++i) {
        f >> x >> y >> z;

        adjacence_list[x].push_back(y);
        adjacence_list[y].push_back(x);

        cap[x][y] = z;
    }


    // edmonds-karp
    while (bfs()) {
        for (auto node : adjacence_list[n]) {
            if (root[node]) { // daca nodul are parinte dupa trecerea prin bfs
                root[n] = node; // il setam ca parintele destinatiei

                int currentFlow = INT_MAX;
                int i = n;
                while (i != 1) {
                    currentFlow = min(currentFlow, cap[root[i]][i]);
                    i = root[i];
                }

                i = n;
                while (i != 1) {
                    cap[root[i]][i] -= currentFlow;
                    cap[i][root[i]] += currentFlow;
                    i = root[i];
                }

                max_flow += currentFlow;
            }
        }
    }

    g << max_flow << '\n';





    //    // b) Min-Cut
    //    g << "\nMin-cut:\n";
    //
    //    queue <int> q;
    //    vector <bool> visited(n + 1, false);
    //
    //    visited[1] = true;
    //    q.push(1);
    //
    //    while (!q.empty()) {
    //        int nod = q.front();
    //        q.pop();
    //
    //        if (nod == n) {
    //            break;
    //        }
    //
    //        for (auto vecin: adjacence_list[nod]) {
    //            int currentcap = cap[nod][vecin];
    //
    //            if (currentcap > 0 && !visited[vecin]) {
    //                q.push(vecin);
    //                visited[vecin] = true;
    //            }
    //        }
    //    }
    //
    //    for (int i = 1; i <= n; i++) {
    //        for (auto vecin: adjacence_list[i]) {
    //            if (visited[i] && !visited[vecin]) { // daca putem ajunge in i din sursa, dar in vecinul lui nu
    //                g << i << " " << vecin << '\n';
    //            }
    //        }
    //    }


    f.close();
    g.close();
    return 0;
}