#include <iostream>
#include <fstream>
#include <utility>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;

ifstream in("maxflow.in");
ofstream out("maxflow.out");


#define nmax 1005
using namespace std;
vector<int>ls[nmax];
int n, m, c[nmax][nmax], f[nmax][nmax], maxflow, tata[nmax];
int viz[nmax];

int bfs(int s,int t)
{
	int ok = 0;
	queue<int> coada;
	memset(viz, 0, sizeof(viz));
	viz[s] = 1;
	coada.push(s);
	while (!coada.empty())
	{
		int x = coada.front();
		coada.pop();
		for (auto y : ls[x])
		{
			if (viz[y]==0 && c[x][y] != f[x][y])
			{
				viz[y] = 1;
				coada.push(y);
				tata[y] = x;
				if (y == t)
				{
					ok = 1;
					break;
				}
			}
		}
	}
	return ok;
}


int edmondsKarp(int s, int t) {
	int total = 0;
	for (; bfs(s, t);)
	{
		int flux_min = 99999999;
		for (int nod = n; nod != 1; nod = tata[nod])
		{
			flux_min = min(flux_min, c[tata[nod]][nod] - f[tata[nod]][nod]);
		}
		for (int nod = n; nod != 1; nod = tata[nod])
		{
			f[tata[nod]][nod] += flux_min;
			f[nod][tata[nod]] -= flux_min;
		}
		total += flux_min;
	}
	return total;
}


int main() {
	in >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int a, b, z;
        in >> a >> b >> z;
        ls[a].push_back(b);
        ls[b].push_back(a);
        c[a][b] = z;
    }
	int s = 1, t = n;
	out << edmondsKarp(1, n);
	
	
	
}