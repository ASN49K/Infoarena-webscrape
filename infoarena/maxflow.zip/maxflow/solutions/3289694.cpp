#include <bits/stdc++.h>

using namespace std;

ifstream fin ("maxflow.in");
ofstream fout ("maxflow.out");

vector <int> g[1005];
int cap[1005][1005];
int flux[1005][1005];
bool viz[1005];
int n, m;
int tt[1005];
bool found_dest;
void dfs (int nod)
{
    // cout<<nod<<' ';
    viz[nod]=1;
    if (nod==n) {
        found_dest=true;
        // cout<<endl;
        return;
    }
    for (int vecin : g[nod]) {
        if (!viz[vecin]) {
            int fv = flux[nod][vecin];
            int cp = cap[nod][vecin];
            if (cp-fv>0) {
                dfs(vecin);
                if (found_dest) {
                    tt[vecin]=nod;
                    return;
                }
            }
        }
    }
}

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    fin>>n>>m;
    for (int i=1; i<=m; i++) {
        int x, y, c;
        fin>>x>>y>>c;
        g[x].push_back(y);
        g[y].push_back(x);
        cap[x][y]=c;
    }
    int max_flow = 0;
    do {
        found_dest = 0;
        memset(viz, 0, sizeof(viz));
        memset(tt, 0, sizeof(tt));
        dfs(1);
        int nod = n;
        int min_flow=INT_MAX;
        while (tt[nod]!=0) {
            int tata = tt[nod];
            int fx = flux[tata][nod];
            int cp = cap[tata][nod];
            int flow = cp-fx;
            min_flow = min(flow, min_flow);
            nod = tata;
        }
        if (min_flow==INT_MAX) min_flow=0;
        nod = n;
        while (tt[nod]!=0) {
            int tata = tt[nod];
            flux[tata][nod]+=min_flow;
            flux[nod][tata]-=min_flow;
            nod = tata;
        }
        max_flow+=min_flow;
    } while (found_dest);
    fout<<max_flow;
    return 0;
}