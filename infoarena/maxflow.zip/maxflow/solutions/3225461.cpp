#include <bits/stdc++.h>
#define MAX 1005

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

int cap[MAX][MAX];
int flux[MAX][MAX];
bool viz[MAX];
int tata[MAX];
vector<int>vec[MAX];
int n,m;

bool bfs()
{
    int i;
    for(i=2;i<=n;++i)
        viz[i]=0;
    viz[1]=1;
    queue<int>q;
    q.push(1);
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(i=0;i<vec[nod].size();++i)
            if(!viz[vec[nod][i]] && cap[nod][vec[nod][i]]>flux[nod][vec[nod][i]])
            {
                viz[vec[nod][i]]=1;
                if(vec[nod][i]==n)
                    continue;
                q.push(vec[nod][i]);
                tata[vec[nod][i]]=nod;
            }
    }
    return viz[n];
}

int main()
{
    fin>>n>>m;
    while(m--)
    {
        int x,y,c;
        fin>>x>>y>>c;
        vec[x].push_back(y);
        vec[y].push_back(x);
        cap[x][y]=c;
    }
    int fluxtot=0;
    int i;
    while(bfs())
    {
        for(i=0;i<vec[n].size();++i)
            if(viz[vec[n][i]] && cap[vec[n][i]][n]>flux[vec[n][i]][n])
            {
                tata[n]=vec[n][i];
                int minn=1e9;
                int nod=n;
                while(nod>1)
                {
                    minn=min(minn,cap[tata[nod]][nod]-flux[tata[nod]][nod]);
                    nod=tata[nod];
                }
                if(minn)
                {
                    nod=n;
                    while(nod>1)
                    {
                        flux[tata[nod]][nod]+=minn;
                        flux[nod][tata[nod]]-=minn;
                        nod=tata[nod];
                    }
                    fluxtot+=minn;
                }
            }
    }
    fout<<fluxtot;
    return 0;
}
