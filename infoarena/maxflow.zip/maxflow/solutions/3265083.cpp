//#pragma GCC optimize("O3")
#include <bits/stdc++.h>
#define ll long long
#define pii pair<int, int>
#define ff first
#define ss second
#define FOR(i, a, b) for(int i = a; i <= b; ++i)
#define FORR(i, a, b) for(int i = a; i >= b; --i)
#define vi vector<int>
#define vvi vector<vi>
#define pb push_back
using namespace std;
const string TASK("maxflow");
ifstream fin(TASK + ".in");
ofstream fout(TASK + ".out");
//#define cin fin
//#define cout fout

const int N = 1e3 + 9, LG = 20;

int n, m;
vvi G(N);

struct edge
{
    int from, to, cap, flow;

    edge(int from = 0, int to = 0, int cap = 0) : from(from), to(to), cap(cap), flow(0) {}
};

vector<edge> edges;

inline void add_edge(int x, int y, int c)
{
    G[x].pb(edges.size());
    edges.pb({x, y, c});
    G[y].pb(edges.size());
    edges.pb({y, x, 0});
}

bitset<N> v;
queue<int> q;
int t[N];
inline bool Bfs()
{
    v.reset();
    q.push(1);
    t[1] = -1;
    v[1] = true;
    while(!q.empty())
    {
        int x = q.front();
        q.pop();

        for(auto id : G[x])
        {
            auto e = edges[id];
            if(e.flow < e.cap && !v[e.to])
            {
                q.push(e.to);
                t[e.to] = id;
                v[e.to] = true;
            }
        }
    }

    return v[n];
}

inline int Augment()
{
    int tot = 0;
    for(auto id : G[n])
    {
        int inv = id ^ 1;
        if(v[edges[inv].from] && edges[inv].flow < edges[inv].cap)
        {
            int ret = INT_MAX;

            for(int i = inv; i != -1; i = t[edges[i].from])
                ret = min(ret, edges[i].cap - edges[i].flow);

            if(!ret)continue;

            for(int i = inv; i != -1; i = t[edges[i].from])
            {
                edges[i].flow += ret;
                edges[i ^ 1].flow -= ret;
            }

            tot += ret;
        }
    }

    return tot;
}

int main()
{
    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    cin >> n >> m;

    int x, y, c;
    FOR(i, 1, m)
    {
        cin >> x >> y >> c;
        add_edge(x, y, c);
    }


    int max_flow = 0;
    for(; Bfs(); max_flow += Augment());

    cout << max_flow << '\n';
    return 0;
}
