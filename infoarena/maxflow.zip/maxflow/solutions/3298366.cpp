#include <iostream>
#include <vector>
#include <algorithm>
#include <cassert>
#include <queue>

const int INF = +1e9;

struct Dinic {
  struct Edge {
      int u, v, cap;
  };

  std::vector<std::vector<int>> g;
  std::vector<Edge> e;
  std::vector<int> dist;

  void init(int n) {
    g.resize(n + 1);
    dist.resize(n + 1);
  }

  void add_edge(int u, int v, int cap) {
    g[u].push_back((int) e.size());
    e.push_back({u, v, cap});
    g[v].push_back((int) e.size());
    e.push_back({v, u, 0});
  }

  bool can_bfs(int S, int T, int F) {
    std::queue<int> q;
    dist.assign((int) dist.size(), INF);
    dist[S] = 0;
    q.push(S);
    while (!q.empty()) {
      int u = q.front();
      q.pop();
      for (const auto &id : g[u]) {
        auto [uu, v, cap] = e[id];
        if (cap >= F && dist[u] + 1 < dist[v]) {
          dist[v] = 1 + dist[u];
          q.push(v);
        }
      }
    }
    return dist[T] != INF;
  }

  int push_flow(int u, int T, int F) {
    if (F == 0 || u == T) {
      return F;
    }
    int ret = 0;
    for (const auto &id : g[u]) {
      auto [uu, v, cap] = e[id];
      if (dist[u] + 1 == dist[v] && cap >= F) {
        int push = push_flow(v, T, F);
        ret += push;
        e[id].cap -= push;
        e[id ^ 1].cap += push;
      }
    }
    return ret;
  }

  int max_flow(int S, int T) {
    int ret = 0;
    for (int jump = (1 << 16); jump > 0; jump >>= 1) {
      while (can_bfs(S, T, jump)) {
        ret += push_flow(S, T, jump);
      }
    }
    return ret;
  }
};

int main() {
  #ifndef LOCAL
freopen("maxflow.in", "r", stdin);
freopen("maxflow.out", "w", stdout);
  #endif

  int n, m;
  std::cin >> n >> m;

  Dinic F;
  F.init(n);

  for (int i = 0; i < m; i++) {
    int u, v, c;
    std::cin >> u >> v >> c;
    F.add_edge(u, v, c);
  }

  std::cout << F.max_flow(1, n);

  return 0;
}
