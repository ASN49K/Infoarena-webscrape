#include <bits/stdc++.h>
using namespace std;

const int NMAX = 1007;

int n, m;
int cap[NMAX][NMAX];
vector<int> adj[NMAX];
int par[NMAX];

bool bfs() {

  fill(par + 1, par + n + 1, -1);

  queue<int> q;
  q.push(1);

  while (!q.empty()) {
    int u = q.front();
    q.pop();
    for (int v : adj[u]) {
      if (par[v] == -1 && cap[u][v] > 0) {
        par[v] = u;
        q.push(v);
      }
    }
  }

  return par[n] == -1;

}

void solve() {

  cin >> n >> m;

  for (int i = 0; i < m; i++) {
    int u, v, c;
    cin >> u >> v >> c;
    adj[u].push_back(v);
    adj[v].push_back(u);
    cap[u][v] = c;
  }

  long long total_flow = 0;

  for (;;) {

    if (bfs()) break;

    int add_flow = INT_MAX;

    for (int u = n; u != 1; u = par[u]) {
      add_flow = min(add_flow, cap[par[u]][u]);
    }

    for (int u = n; u != 1; u = par[u]) {
      cap[par[u]][u] -= add_flow;
      cap[u][par[u]] += add_flow;
    }

    total_flow += add_flow;

  }

  cout << total_flow << '\n';

}


int main() {

  #ifdef LOCAL
  freopen("file.in", "r", stdin);
  #else
  freopen("maxflow.in", "r", stdin);
  freopen("maxflow.out", "w", stdout);
  #endif

  ios_base::sync_with_stdio(false), cin.tie(NULL);

  solve();
}
