#include <bits/stdc++.h>

using namespace std;

struct Dinic
{
    struct Edge
    {
        int from, to, cap, prev;
    };
    int n;
    const int inf = 1e9;
    vector<Edge> edge;
    vector<int> dist, prec;
    Dinic(int N)
    {
        n = N;
        dist.resize(n + 1, 0);
        prec.resize(n + 1, -1);
    }
    void baga(int from, int to, int cap)
    {
        edge.push_back({from, to, cap, prec[from]});
        prec[from] = edge.size() - 1;
        edge.push_back({to, from, 0, prec[to]});
        prec[to] = edge.size() - 1;
    }
    bool bfs(int s, int d)
    {
        dist.assign(n + 1, inf);
        dist[s] = 0;
        queue<int> q;
        q.push(s);
        while(!q.empty())
        {
            int x = q.front();
            q.pop();
            for(int i = prec[x]; i != -1; i = edge[i].prev)
            {
                if(dist[edge[i].to] == inf && edge[i].cap > 0)
                {
                    dist[edge[i].to] = dist[x] + 1;
                    q.push(edge[i].to);
                }
            }
        }
        return dist[d] != inf;
    }
    int dfs(int x, int d, int push)
    {
        if(push == 0)
            return 0;
        if(x == d)
            return push;
        int ret = 0;
        for(int i = prec[x]; i != -1; i = edge[i].prev)
        {
            if(dist[edge[i].to] == dist[x] + 1)
            {
                int y = dfs(edge[i].to, d, min(push, edge[i].cap));

                ret += y;
                push -= y;

                edge[i].cap -= y;
                edge[i ^ 1].cap += y;
            }
        }
        return ret;
    }
    int maxFlow(int s, int d)
    {
        int ans = 0;
        while(bfs(s, d))
            ans += dfs(s, d, inf);
        return ans;
    }
};

int main()
{
    ifstream cin("maxflow.in");
    ofstream cout("maxflow.out");
    int n, m;
    cin >> n >> m;
    Dinic g(n);
    for(int i = 0; i < m; i ++)
    {
        int u, v, cap;
        cin >> u >> v >> cap;
        g.baga(u, v, cap);
    }
    cout << g.maxFlow(1, n);
}
