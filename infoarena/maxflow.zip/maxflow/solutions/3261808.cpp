#include <bits/stdc++.h>
#pragma GCC optimize("O3")
using namespace std;

#define flow first
#define capacity second
pair<int, int> claudel[1010][1010];

int N, M;
vector<int> adj[1010];
int daddy[1010], visited[1010];

inline bool bfs(int source) {
    #pragma ivdep
    for (int i = 0; i < 1010; i++) {
            visited[i] = 0;
            daddy[i]=0;
    }

    deque<int> dq;
    dq.emplace_back(source);
    daddy[source] = 0;
    visited[source] = 1;

    while (!dq.empty()) {
        int node = dq.front(); dq.pop_front();
        for (auto neigh : adj[node]) {
            if (!visited[neigh] && claudel[node][neigh].flow < claudel[node][neigh].capacity) {
                if(neigh!=N)
                    dq.emplace_back(neigh);
                daddy[neigh] = node;
                visited[neigh] = 1;
            }
        }
    }

    return visited[N];
}

inline int findMin(int node) {
    int ans = INT_MAX;
    while (daddy[node]) {
        ans = min(ans, claudel[daddy[node]][node].capacity - claudel[daddy[node]][node].flow);
        node = daddy[node];
    }

    assert(ans != INT_MAX);
    return ans;
}

int sum = 0;
inline void updateFlow(int value, int node = N) {
    sum += value;
    while (daddy[node]) {
        claudel[daddy[node]][node].flow += value;
        claudel[node][daddy[node]].flow -= value;
        node = daddy[node];
    }
}

int main()
{
#ifndef OFFLINE
    freopen("maxflow.in", "r", stdin);
    freopen("maxflow.out", "w", stdout);
#endif // OFFLINE
    cin.tie(0)->sync_with_stdio(0);
    srand(time(0));

    cin >> N >> M ;
    for (int i = 1; i <= M; i++) {
        int x, y, z; cin >> x >> y >> z;
        claudel[x][y].capacity = z;
        adj[x].emplace_back(y);
        adj[y].emplace_back(x);
    }

    int nr=0;
    while (bfs(1)) {
        ++nr;
        int mn = INT_MAX;
        for (auto child : adj[N]) {
            if(daddy[child]==0) continue;
            daddy[N] = child;
            mn = findMin(N);
            updateFlow(mn, N);
        }
    }
    cout << sum;
}







