#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");
int n,ans,m;
const int N=1005;
int st,dr,X,Y,Z,fr[N],niv[N];
vector<int>a[N];
int d[N][N];
int dfs(int nod,int mn)
{
    if(nod==dr||mn==0)
        return mn;
    while(fr[nod]<a[nod].size())
    {
        int next=a[nod][fr[nod]];
        fr[nod]++;
        if(d[nod][next]>0&&niv[next]==niv[nod]+1)
        {
            int x=dfs(next,min(d[nod][next],mn));
            if(x>0)
            {

                d[nod][next]-=x;
                d[next][nod]+=x;
                return x;
            }
        }
    }
    return 0;
}
void bfs(int nod)
{
    for(int i=1; i<=n; i++)
        niv[i]=-1,fr[i]=0;
    niv[nod]=0;
    queue<int>q;
    q.push(nod);
    while(!q.empty())
    {
        int next=q.front();
        q.pop();
        for(auto i : a[next])
            if(niv[i]==-1&&d[next][i]>0)
            {
                niv[i]=niv[next]+1;
                q.push(i);
            }
    }
}
bool flux(int st)
{
    bfs(st);
    if(niv[dr]==-1)
        return 0;
    else
    {
        int val=0;
        bool ok=true;
        while(ok)
        {
            int x=dfs(st,1e9);
            if(x<=0)
                ok=false;
            else
                val+=x;
        }
        ans+=val;
        if(val!=0)
            return true;
        return false;
    }
    return 0;
}
int main()
{
    f>>n>>m;
    for(int i=1; i<=m; i++)
    {
        f>>X>>Y>>Z;
        a[X].push_back(Y);
        d[X][Y]=Z;
        a[Y].push_back(X);
    }
    st=1;
    dr=n;
    while(flux(st));
    g<<ans;
    return 0;
}
