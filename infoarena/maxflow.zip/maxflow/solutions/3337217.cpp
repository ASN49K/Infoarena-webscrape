#include <bits/stdc++.h>

using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

int n, m, c[1001][1001], tata[1001];
vector <int> vecini[1001];

bool bfs (int s, int t)
{
    for (int i=1; i<=n; i++)
        tata[i] = -1;

    queue <int> q;
    tata[s] = 0;
    q.push(s);

    while (!q.empty())
    {
        int i = q.front();
        q.pop();

        for (auto j : vecini[i])
            if (c[i][j] > 0 and tata[j] == -1)
            {
                tata[j] = i;

                if (j == t)
                    return true;

                q.push(j);
            }
    }
    return false;
}

int EdmondsKarp (int s, int t)
{
    int totalFlux = 0;

    while (bfs(s, t))
    {
        int fluxCurent = INT_MAX;

        for (int j = t; tata[j]; j = tata[j])
        {
            int i = tata[j];
            fluxCurent = min(fluxCurent, c[i][j]);
        }

        for (int j = t; tata[j]; j = tata[j])
        {
            int i = tata[j];
            c[i][j] -= fluxCurent;
            c[j][i] += fluxCurent;
        }

        totalFlux += fluxCurent;
    }
    return totalFlux;
}

int main()
{
    f>>n>>m;
    for (int i=1; i<=m; i++)
    {
        int x, y, cap;
        f>>x>>y>>cap;
        vecini[x].push_back(y);
        vecini[y].push_back(x);
        c[x][y] = cap;
    }

    g<<EdmondsKarp(1, n);
}
