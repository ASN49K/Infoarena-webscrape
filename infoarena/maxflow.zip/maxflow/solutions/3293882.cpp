#include <bits/stdc++.h>
using namespace std;

const int kNil = -1;
const int kInf = 1e9;

struct edge_t {
	int to, cap;
	edge_t() {}
	edge_t(int to, int cap) : to(to), cap(cap) {}
};

struct dinic {
	int n;
	vector<vector<int>> adj;
	vector<edge_t> edges;
	vector<int> dist, ptr;
	queue<int> q;
	dinic() {}
	dinic(int n) : n(n), adj(n), dist(n), ptr(n) {}
	void add_edge(int u, int v, int cap) {
		int m = edges.size();
		edges.emplace_back(v, cap);
		edges.emplace_back(u, 0);
		adj[u].emplace_back(m);
		adj[v].emplace_back(m + 1);
	}
	bool bfs(int s, int d) {
		fill(dist.begin(), dist.end(), kNil);
		q.emplace(s);
		dist[s] = 0;
		while(!q.empty()) {
			int u = q.front();
			q.pop();
			for(const auto &it : adj[u]) {
				auto [to, cap] = edges[it];
				if(!cap || dist[to] != kNil) {
					continue;
				}
				dist[to] = dist[u] + 1;
				q.emplace(to);
			}
		}
		return dist[d] != kNil;
	}
	int dfs(int u, int d, int pushed) {
		if(!pushed) {
			return 0;
		}
		if(u == d) {
			return pushed;
		}
		for(int &i = ptr[u]; i < (int)adj[u].size(); i++) {
			int it = adj[u][i];
			auto [to, cap] = edges[it];
			if(dist[to] != dist[u] + 1) {
				continue;
			}
			int pushing = dfs(to, d, min(pushed, cap));
			if(pushing) {
				edges[it].cap -= pushing;
				edges[it ^ 1].cap += pushing;
				return pushing;
			}
 		}
 		return 0;
	}
	int max_flow(int s, int d) {
		int flow = 0;
		while(bfs(s, d)) {
			fill(ptr.begin(), ptr.end(), 0);
			int pushed = 0;
			while(pushed = dfs(s, d, kInf)) {
				flow += pushed;
			}
		}
		return flow;
	}
};

int main() {
	cin.tie(nullptr)->sync_with_stdio(false);
#ifdef INFOARENA
	freopen("maxflow.in", "r", stdin);
	freopen("maxflow.out", "w", stdout);
#endif
	int n, m;
	cin >> n >> m;
	dinic graph(n);
	for(int i = 0; i < m; i++) {
		int u, v, c;
		cin >> u >> v >> c;
		u--;
		v--;
		graph.add_edge(u, v, c);
	}
	cout << graph.max_flow(0, n - 1) << '\n';
	return 0;
}