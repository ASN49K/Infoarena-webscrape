#include <bits/stdc++.h>
#define NMAX 1002
#define INF INT_MAX

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

int N,M,a,b;
int c[NMAX][NMAX];
int f[NMAX][NMAX];
vector <pair<int,int>> V;
char vizitat[NMAX];
int Prev[NMAX];
int ans;

bool can_travel(int a,int b)
{
    if(a==b || vizitat[b]==1) return 0;
    return (c[a][b]-f[a][b]>0);
}

int free(int a,int b)
{
    return (c[a][b]-f[a][b]);
}

bool dfs(int nod)
{
    if(nod==N){
        return true;
    }
    vizitat[nod]=1;
    for(int i=1;i<=N;i++){
        if(can_travel(nod,i)){
            Prev[i]=nod;
            if(dfs(i)){
                return true;
            }
        }
    }
    return false;
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    fin >> N >> M;
    for(int i=1;i<=M;i++){
        int nc;
        fin >> a >> b >> nc;
        V.push_back({a,b});
        c[b][a]+=nc;
        c[a][b]+=nc;
    }
    ///max_flow
    while(dfs(1)){
        int curr=N;
        int min_free=INF;
        while(Prev[curr]>0){
            min_free=min(min_free,free(Prev[curr],curr));
            curr=Prev[curr];
        }
        curr=N;
        ans+=min_free*(min_free!=INF);
        while(Prev[curr]>0){
            f[Prev[curr]][curr]+=min_free;
            f[curr][Prev[curr]]-=min_free;
            curr=Prev[curr];
        }
        memset(vizitat,0,sizeof(vizitat));
        memset(Prev,0,sizeof(Prev));
    }
    fout << ans << "\n";
}


