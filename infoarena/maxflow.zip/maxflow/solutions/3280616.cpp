#include <bits/stdc++.h>
using namespace std;
ifstream fin ("maxflow.in");
ofstream fout ("maxflow.out");
#define cin fin
#define cout fout

const int MAXN=1003;
const int INF=1e9;


int n,m;
int cap[MAXN][MAXN];
int flux[MAXN][MAXN];
int tata[MAXN];
int source,dest;

vector<int> g[MAXN];

inline bool have_road(int source,int dest){
    queue<int> q;
    vector<int> viz(MAXN,0);
    viz[source]=1;
    q.push(source);
    while(!q.empty()){
        int node = q.front();
        q.pop();
        for(auto x:g[node]){
            if(cap[node][x]-flux[node][x]>0 && viz[x]==0){
                q.push(x);
                tata[x]=node;
                viz[x]=1;
            }
        }
        if (viz[dest]) break;
    }
    return viz[dest];
}
inline int calculateFlow(){
    int minimumFlow = INF;
    int node = dest;
    while(node!=source){
        minimumFlow = min(minimumFlow,cap[tata[node]][node]-flux[tata[node]][node]);
        node = tata[node];
    }
    node = dest;
    while(node != source){
        flux[tata[node]][node] += minimumFlow;
        flux[node][tata[node]] -= minimumFlow;
        node = tata[node];
    }
    return minimumFlow;
}

inline void add_edge (int x, int y, int z){
    g[x].push_back (y);
    g[y].push_back (x);
    cap[x][y]=z;
}

inline int get_flow (){
    int flow = 0;
    while(have_road(source,dest)){
        flow += calculateFlow();
    }
    return flow;
}

int main()
{
    cin >>n>>m;
    source=1,dest=n;
    for (int i=1;i<=m;++i){
        int x,y,z;
        cin >>x>>y>>z;
        add_edge (x,y,z);
    }
    cout <<get_flow ();
    return 0;
}

