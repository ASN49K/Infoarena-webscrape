#include <bits/stdc++.h>

using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
int n,m;
vector<int> v[1003];
int cost[1003][1003];
int viz[1003];
int rez;
int timp=1;
int dfs(int nod,int bottleneck)
{
    if (nod==n) return bottleneck;
    viz[nod]=timp;
    for (auto i:v[nod])
    {
        if (viz[i]!=timp && cost[nod][i]>0)
        {
            int val=dfs(i,min(bottleneck,cost[nod][i]));
            if (val>0)
            {
                cost[nod][i]-=val;
                cost[i][nod]+=val;
                return val;
            }
        }
    }
    return 0;
}
int main()
{
    fin>>n>>m;
    while (m--)
    {
        int x,y,c;
        fin>>x>>y>>c;
        if (cost[x][y]==cost[y][x] && cost[x][y]==0)
        {
            v[x].push_back(y);
            v[y].push_back(x);
        }
        cost[x][y]+=c;
    }
    int aux=dfs(1,1e9);
    while (aux!=0)
    {
        rez+=aux;
        timp++;
        aux=dfs(1,1e9);
    }
    fout<<rez;
    return 0;
}
