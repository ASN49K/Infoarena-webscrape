#include <bits/stdc++.h>

using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");

int n,m,nr;
struct muchie
{
    int x,y,cap;
};
vector<muchie> edges;
vector<int> v[1005];//nodurile retin idurile muchiilor
bitset<1005> used;//pentru noduri
int t[1005];//vectorul de tati pentru noduri cu muchii(retine id ul muchiei)
queue<int> q;

int bfs(int nod)//targetul e sa ajungem in nodul n cat mai repede
{
    int i,u,k;
    //resetam
    for(i=1;i<=n;i++)
        t[i]=-1;
    used=0;
    used[nod]=1;
    q.push(nod);
    while(q.empty()==0)
    {
        k=q.front();//nodul curent
        for(i=0;i<v[k].size();i++)
        {
            u=v[k][i];
            if(used[edges[u].y]==0 and edges[u].cap>0)
            {
                used[edges[u].y]=1;
                t[edges[u].y]=u;
                q.push(edges[u].y);
            }
        }
        q.pop();

    }
    //daca nu s-a ajuns la nodul de sosire
    if(t[n]==-1)
        return 0;
    return 1;
}

int main()
{
    int i,x,y,cap;
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>cap;
        edges.push_back({x,y,cap});
        v[x].push_back(edges.size()-1);
        //punem si muchia inversa (virtuala)
        edges.push_back({x,y,0});
        v[y].push_back(edges.size()-1);
    }
    int flow=0,minim;
    while(bfs(1))// bfs din start
    {
        minim=1e9;
        i=n;
        while(t[i]!=-1)//cautam minimul pe acest lant de la sfarsit la inceput
        {
            minim=min(minim,edges[t[i]].cap);
            i=edges[t[i]].x;
        }
        i=n;
        while(t[i]!=-1)//scadem din fiecare minimul si adaugam la muchia virtuala
        {
            edges[t[i]].cap-=minim;
            edges[t[i]^1].cap+=minim;
            i=edges[t[i]].x;
        }
        flow=flow+minim;
    }
    //cand nu se va mai putea adauga flow, va iesi din while
    g<<flow;
    return 0;
}
