#include <fstream>
#include <cstring>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
const int nmax = 1e3 + 1;
const int sflow = 1e9;
struct edge
{
    int y , cap , flow, ridx;
};
vector <edge> g[nmax];
int n , m , a , b , c , sz[nmax], level[nmax] , ef[nmax] , total;
bool viz[nmax];
bool bfs()
{
    queue<int>q;
    memset(level,0,sizeof(level));
    memset(viz,0,sizeof(viz));
    memset(ef,0,sizeof(ef));
    level[1] = 1;
    q.push(1);
    while(!q.empty())
    {
        a = q.front();
        q.pop();
        for(auto &it : g[a])
        {
            if(!level[it.y] && it.cap - it.flow > 0)
            {
                level[it.y] = level[a] + 1;
                q.push(it.y);
            }
        }
    }
    return (level[n]!=0);
}
int aug(int x, int flow)
{
    if(x == n)
    {
        return flow;
    }
    for(; ef[x] < sz[x] ; ef[x]++)
    {
        edge it = g[x][ef[x]];
        if(level[it.y] == level[x]+1 && it.cap-it.flow > 0)
        {
            int nf = aug(it.y,min(flow,it.cap-it.flow));
            g[x][ef[x]].flow += nf;
            g[it.y][g[x][ef[x]].ridx].flow -= nf;
            return nf;
        }
    }
    return 0;
}
int main()
{
    cin >> n >> m;
    for(int i = 1 ; i <= m ; i++)
    {
        cin >> a >> b >> c;
        g[a].push_back({b,c,0,sz[b]});
        g[b].push_back({a,0,0,sz[a]});
        sz[a]++;
        sz[b]++;
    }
    while(bfs())
    {
        while(true)
        {
            int val = aug(1,sflow);
            if(!val) break;
            total += val;
        }
    }
    cout << total ;
    return 0;
}
