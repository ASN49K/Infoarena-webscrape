#include <bits/stdc++.h>
#define MAX 1005
using namespace std;
map<pair<int,int>,int>mapp;
vector<int>G[MAX],dead_ends;
int n,prag,nvl[MAX];
bool dead_end[MAX];
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
int m,i,x,y,z,ras=0;
void nivelare(int nod)
{
    queue<int>q;
    int maxx;
    q.push(nod);
    for(i=1;i<=n;i++)
    {
        dead_end[i]=0;
        nvl[i]=0;
    }
    nvl[nod]=1;
    while(!q.empty())
    {
        nod=q.front();
        q.pop();
        for(auto i:G[nod])
        {
            if(nvl[i]==0 && mapp[{nod,i}]>0)
            {
                maxx=max(maxx,mapp[{nod,i}]);
                nvl[i]=nvl[nod]+1;
                q.push(i);
            }

        }
    }
    prag=(1<<int(log2(maxx)));
}
int dfs(int nod,int minn)
{
    if(nod==n)
        return minn;
    for(auto i:G[nod])
    {
        if(nvl[i]==nvl[i+1] && mapp[{nod,i}]>0 && dead_end[i]==0)
        {
            x=dfs(i,min(minn,mapp[{nod,i}]));
            if(x>0)
            {
                mapp[{nod,i}]-=x;
                mapp[{i,nod}]=x;
                return x;
            }
            else
            {
                dead_end[i]=1;
                dead_ends.push_back(i);
            }
        }
    }
}
int main()
{
    ifstream cin("maxflow.in");
    ofstream cout("maxflow.out");

    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>x>>y>>z;
        G[x].push_back(y);
        mapp[{x,y}]=z;
        if(mapp[{y,x}]==0)
            G[y].push_back(x);
    }
    nivelare(1);
    while(nvl[n]!=0)
    {
        while(prag!=0)
        {
            x=dfs(1,1e9);
            if(x!=0)
            {
                ras+=x;
            }
            else
            {
                prag/=2;
                for(auto i:dead_ends)
                {
                    dead_end[i]=0;
                }
                dead_ends.clear();
            }
        }
        nivelare(1);
    }
    cout<<ras;
}
