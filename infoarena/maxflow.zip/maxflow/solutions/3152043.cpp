#include <bits/stdc++.h>

using namespace std;
ifstream in("maxflow.in");
ofstream out("maxflow.out");
int n, m, x, y, cap, total;
vector<int> adj[1005];
int f[1005][1005];
int c[1005][1005];
int p[1005];

void bfs(int node) {
    queue<int> q;
    q.push(node);

    while (!q.empty()) {
        int nod = q.front();
        q.pop();

        for (auto it : adj[nod]) {
            if (c[nod][it] - f[nod][it] > 0 && p[it] == -1) {
                p[it] = nod;
                q.push(it);
            }
        }
    }

}

int main()
{
    in >> n >> m;
    for (int i = 1; i <= m; i++) {
        in >> x >> y >> cap;
        adj[x].push_back(y);
        adj[y].push_back(x);
        c[x][y] = cap;
    }

    while (1) {
        memset(p, -1, sizeof(p));

        bfs(1);
        if (p[n] == -1)
            break;

        int rc = 1e9;

        int nod = n;
        do {
            rc = min(rc, c[p[nod]][nod] - f[p[nod]][nod]);
            nod = p[nod];
        } while (nod != 1);

        nod = n;
        do {
            f[nod][p[nod]] -= rc;
            f[p[nod]][nod] += rc;
            nod = p[nod];
        } while (nod != 1);

        total += rc;
    }

    out << total << '\n';

    return 0;
}
