#include <fstream>
#include <climits>
#include <vector>
#include <queue>
#include <map>

#define NMAX 1005
#define INF INT_MAX

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

int n, m;
int x, y, c;
vector<int> l[NMAX];
map<pair<int, int>, int> cap;
int src, dest;
int ans;
int niv[NMAX], f[NMAX];
int i, j;

bool flux(int);
int dfs(int, int);
void bfs(int);

int main()
{
    fin >>n>>m;
    for (i = 1; i <= m; ++i)
    {
        fin >>x>>y>>c;

        l[x].push_back(y);
        cap[{x, y}] = c;

        l[y].push_back(x);
        cap[{y, x}] = 0;
    }

    src = 1; dest = n;
    while (flux(src));

    fout <<ans<<'\n';
    fout.close();
    return 0;
}

bool flux(int nod)
{
    bfs(nod);

    if (niv[dest] == -1)
        return 0;

    int anscrt = 0;
    while(1)
    {
        int x = dfs(1, INF);
        if (!x)
            break;
        anscrt += x;
    }
    ans += anscrt;
    return (anscrt != 0);
}

int dfs(int vf, int minim)
{
    if (vf == dest || minim == 0)
        return minim;

    while (f[vf] < l[vf].size())
    {
        int vfnou = l[vf][f[vf]];
        if (cap[{vf, vfnou}] && niv[vf]+1 == niv[vfnou])
        {
            int x = dfs(vfnou, min(minim, cap[{vf, vfnou}]));
            if (x)
            {
                cap[{vf, vfnou}] -= x;
                cap[{vfnou, vf}] += x;
                return x;
            }
            else
                f[vf] ++;
        }
        else
            f[vf] ++;
    }

    return 0;
}

void bfs(int nod)
{
    for (i = 1; i <= n; ++i)
        niv[i] = -1, f[i] = 0;

    queue<int> q;
    niv[nod] = 0; q.push(nod);
    while (!q.empty())
    {
        int vf = q.front(); q.pop();
        for (auto vfnou: l[vf])
            if (niv[vfnou] == -1 && cap[{vf, vfnou}])
            {
                niv[vfnou] = niv[vf] + 1;
                q.push(vfnou);
            }
    }
}
