#include <fstream>
#include <queue>
using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
const int N=1001;
const int inf=1e9;
vector<int>adj[N];
int capacitate[N][N];
int n,m;
int parent[N];
void init()
{
    for(int i=1; i<=n; i++)
        parent[i]=-1;
    parent[1]=0;
}
struct flow
{
    int nod,capacitate;
};
int size_of=0;
int st[N];
flow q[10005];
int marime=0;
int bfs()
{
    for(int i=1; i<=size_of; i++)
    {
        parent[st[i]]=-1;
    }
    size_of=0;
    parent[1]=0;
    q[1]={1,inf};
    marime=1;
    for(int i=1;i<=marime;i++)
    {
        int nod,flux;
        nod=q[i].nod;
        flux=q[i].capacitate;
        for(auto u:adj[nod])
        {
            if(parent[u]==-1&&capacitate[nod][u])
            {
                size_of++;
                st[size_of]=u;
                flux=min(flux,capacitate[nod][u]);
                parent[u]=nod;
                if(u==n)
                {
                    return flux;
                }
                marime++;
                q[marime]={u,flux};
            }
        }
    }
    return 0;
}
int main()
{
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int a,b,flux;
        cin>>a>>b>>flux;
        if(capacitate[a][b]==0)
        {
            adj[a].push_back(b);
            adj[b].push_back(a);
        }
        capacitate[a][b]+=flux;
    }
    int ans=0;
    int actual_flow;
    init();
    while(actual_flow=bfs())
    {
        ans+=actual_flow;
        int cur=n;
        while(cur!=1)
        {
            int prev=parent[cur];
            capacitate[cur][prev]+=actual_flow;
            capacitate[prev][cur]-=actual_flow;
            cur=prev;
        }
    }
    cout<<ans;
    cin.close();
    cout.close();
    return 0;
}
