#include <fstream>
#include <bits/stdc++.h>
using namespace std;

ifstream fin("flux.in");
ofstream fout("flux.out");
int N,M;
int cap[1005][1005];
int flux[1005][1005];
int tata[1005];
int source,dest;
vector<int> adj[1005];
bool have_road(int source,int dest){
  queue<int> q;
  vector<int> viz(N+5,0);
  viz[source]=1;
  q.push(source);
  while(!q.empty()){
    int node = q.front();
    q.pop();
    for(auto x:adj[node]){
        if(cap[node][x]-flux[node][x]>0 && viz[x]==0){
            q.push(x);
            tata[x]=node;
            viz[x]=1;
        }
    }
  }
  return viz[dest];
}
int calculateFlow(){
    int minimumFlow = 1e9;
    int node = dest;
    while(node!=source){
        minimumFlow = min(minimumFlow,cap[tata[node]][node]-flux[tata[node]][node]);
        node = tata[node];
    }
    node = dest;
    while(node != source){
        flux[tata[node]][node] += minimumFlow;
        flux[node][tata[node]] -= minimumFlow;
        node = tata[node];
    }
    return minimumFlow;

}
int main() {
    fin>>N>>M;
    source = 1,dest = N;
    for(int i=1;i<=M;i++){
        int x,y,z;
        fin>>x>>y>>z;
        adj[x].push_back(y);
        adj[y].push_back(x);
        cap[x][y]=z;
    }
    int flow = 0;
    while(have_road(source,dest)){
        flow += calculateFlow();
    }
    
    fout<<flow;
    return 0;
}