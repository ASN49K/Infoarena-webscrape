#include <iostream>
#include <bits/stdc++.h>
#include <fstream>
#include <vector>
#include <queue>

#define oo 0x3f3f3f3f

using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

int n, m;
vector<bool> viz;
vector<int> pre;
vector<vector<int>> cost, flux;
vector<vector<int>> graph;

void read() {
    f>>n>>m;
    viz.resize(n + 1, false);
    pre.resize(n + 1, 0);
    cost.resize(n + 1, vector<int>(n + 1, 0));
    flux.resize(n + 1, vector<int>(n + 1, 0));
    graph.resize(n + 1, vector<int>());
    int nodeX, nodeY, capacity;

    for(int i = 0;i < m;++i) {
        f>>nodeX>>nodeY>>cost[nodeX][nodeY];
        graph[nodeX].push_back(nodeY);
        graph[nodeY].push_back(nodeX);
    }
}

bool bfs() {
    viz.assign(n + 1, false);
    queue<int> bfsQueue;

    bfsQueue.push(1);
    viz[1] = true;

    while(!bfsQueue.empty()) {
        int currentNode = bfsQueue.front();
        bfsQueue.pop();

        if(currentNode == n) {
            continue;
        }

        for(const int& neighbour : graph[currentNode]) {
            if(viz[neighbour] || flux[currentNode][neighbour] == cost[currentNode][neighbour]) { 
                continue;
            }
            viz[neighbour] = true;
            pre[neighbour] = currentNode;
            bfsQueue.push(neighbour);
        }
    }

    return viz[n];
}

void solve() {
    int flow = 0;
    while(bfs()) {
        for(const int& node : graph[n]) {
            if(!viz[node] || cost[node][n] == flux[node][n]) {
                continue;
            }

            int minFlow = oo;
            pre[n] = node;
            for(int prevNode = n;prevNode != 1;prevNode = pre[prevNode]) {
                minFlow = min(minFlow, cost[pre[prevNode]][prevNode] - flux[pre[prevNode]][prevNode]);
            }

            if(minFlow == oo) {
                continue;
            }
            for(int prevNode = n;prevNode != 1;prevNode = pre[prevNode]) {
                flux[prevNode][pre[prevNode]] -= minFlow;
                flux[pre[prevNode]][prevNode] += minFlow;
            }
            flow += minFlow;
        }
    }

    g<<flow;
}

int main() {
    read();
    solve();
    return 0;
}