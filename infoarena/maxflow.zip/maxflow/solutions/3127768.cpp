#include <cmath>
#include <functional>
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <set>
#include <map>
#include <list>
#include <time.h>
#include <math.h>
#include <random>
#include <deque>
#include <cassert>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <iomanip>
#include <bitset>
#include <sstream>
#include <stack>
#include <chrono>
#include <cstring>
#include <numeric>
using namespace std;
const int INF = (int) 1e9 + 7;
struct Flow {
  int n;
  struct Edge {
    int to, cap;
  };
  vector<vector<int>> g;
  vector<int> level, q, ptr;
  vector<Edge> edges;
  int flow;
  Flow(int nn) :
    n(nn),
    flow(0),
    g(nn) {
    assert(nn >= 1);
  }
  void addedge(int a, int b, int c) {
    assert(0 <= a && a < n);
    assert(0 <= b && b < n);
    assert(a != b);
    edges.push_back({b, c});
    edges.push_back({a, 0});
    g[a].push_back((int) edges.size() - 2);
    g[b].push_back((int) edges.size() - 1);
  }
  int dfs(int a, int cur) {
    if (a == n - 1 || cur == 0) {
      return cur;
    }
    while (ptr[a] < (int) g[a].size()) {
      int i = g[a][ptr[a]++];
      if (edges[i].cap > 0 && level[edges[i].to] == 1 + level[a]) {
        int x = dfs(edges[i].to, min(cur, edges[i].cap));
        if (x) {
          edges[i].cap -= x;
          edges[i ^ 1].cap += x;
          ///ptr[a]--;
          return x;
        }
      }
    }
    return 0;
  }
  int get() {
    while (1) {
      level.clear();
      level.resize(n, -1);
      q.clear();
      auto push = [&] (int a, int nwlvl) {
        if (level[a] == -1) {
          level[a] = nwlvl;
          q.push_back(a);
        }
      };
      push(0, 0);
      for (int _ = 0; _ < (int) q.size(); _++) {
        int a = q[_];
        for (auto &i : g[a]) {
          if (edges[i].cap) {
            push(edges[i].to, level[a] + 1);
          }
        }
      }
      if (level[n - 1] == -1) {
        break;
      }
      ptr.clear();
      ptr.resize(n, 0);
      while (1) {
        int cur = dfs(0, INF);
        if (cur == 0) {
          break;
        }
        flow += cur;
      }
    }
    return flow;
  }
};
signed main() {
#ifdef ONPC
	freopen("input.txt", "r", stdin);
#else
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	freopen ("maxflow.in", "r", stdin);
	freopen ("maxflow.out", "w", stdout);
#endif
  int n, m;
  cin >> n >> m;
  Flow flow(n);
  for (int i = 0; i < m; i++) {
    int a, b, c;
    cin >> a >> b >> c;
    flow.addedge(a - 1, b - 1, c);
  }
  cout << flow.get() << "\n";
	return 0;
}
