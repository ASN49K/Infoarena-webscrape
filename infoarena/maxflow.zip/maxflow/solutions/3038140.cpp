///edmons karp
#include<fstream>

#define inf 1e9

using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
int const N = 1001;
int n , m , a , b;
int f[N][N];
int q[N] , t[N] , lv[N] , fl[N];
bool bfs(){
    fill(lv , lv + 1 + n , inf);
    fill(fl , fl + 1 + n , inf);
    int l = 1 , r = 1;
    q[1] = 1 , lv[1] = 0;
    while(l <= r){
        int x = q[l++];
        for(int i = 1 ; i <= n ; ++ i){
            if(f[x][i] > 0 && lv[i] == inf){
                lv[i] = 1 + lv[x];
                fl[i] = min(fl[x] , f[x][i]);
                t[i] = x;
                q[++r] = i;
            }
        }
    }
    return lv[n] < inf;
}
int maxflow(){
    int flow = 0;
    while(bfs()){
        flow += fl[n];
        int x = n;
        while(t[x]){
            f[t[x]][x] -= fl[n];
            f[x][t[x]] += fl[n];
            x = t[x];
        }
    }
    return flow;
}
int main(){
    fin >> n >> m;
    for(int i = 1 ; i <= m ; ++ i)
        fin >> a >> b >> f[a][b];
    fout << maxflow() << '\n';
    return 0;
}
