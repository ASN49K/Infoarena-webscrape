#include <fstream>
#include <vector>
#include <queue>

std::ifstream in("maxflow.in");
std::ofstream out("maxflow.out");

const int N = 1005;
int n, m, maxFlow, flow, capacity[N][N];
std::vector<std::vector<int>> list(N);
std::vector<int> repr(N, 0);
std::vector<bool> vis(N, false);

bool BFS()
{
    std::fill(vis.begin(), vis.end(), false);
    vis[1] = true;

    std::queue<int> Q;
    Q.push(1);

    while (Q.size())
    {
        int x = Q.front();
        Q.pop();

        for (int v : list[x])
        {
            if (vis[v] || !capacity[x][v])
                continue;
            Q.push(v);
            vis[v] = true;
            repr[v] = x;
            if (v == n)
                return true;
        }
    }
    return false;
}

int main()
{
    in >> n >> m;
    while (m--)
    {
        int x, y, z;
        in >> x >> y >> z;
        list[x].push_back(y);
        list[y].push_back(x);
        capacity[x][y] = z;
    }
    /*for (int i = 1; i <= n; i++)
    {
        out << "List[" << i << "]: ";
        for (int v : list[i])
            out << v << ' ';
        out << '\n';
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
            out << capacity[i][j] << ' ';
        out << '\n';
    }*/

    while (BFS())
        for (int x : list[n])
        {
            if (!vis[x])
                continue;
            // out << x << ' ';
            flow = 1e+7;
            repr[n] = x;
            int curr = n;

            while (curr != 1)
            {
                flow = std::min(flow, capacity[repr[curr]][curr]);
                curr = repr[curr];
            }
            if (!flow)
                continue;

            curr = n;
            while (curr != 1)
            {
                capacity[repr[curr]][curr] -= flow;
                capacity[curr][repr[curr]] += flow;
                curr = repr[curr];
            }
            maxFlow += flow;
        }
    out << maxFlow;
    return 0;
}