#include <fstream>
#include <queue>
#include <bitset>
#include <cstring>

using namespace std;

ifstream cin("maxflow.in");
ofstream cout("maxflow.out");

const int NMAX = 1e3;
const int inf = 2e9;

int flux[NMAX + 1][NMAX + 1], c[NMAX + 1][NMAX + 1], pred[NMAX + 1], s, d, n, m;
vector <int> g[NMAX + 1];

bool exista_drum(){

    memset(pred, 0, (n + 1) * sizeof(int));
    queue <int> q;

    q.push(s);
    pred[s] = -1;

    while(!q.empty()){

        int x = q.front();
        q.pop();

        if(x == d)
            return true;

        for(auto &y : g[x]){

            if(pred[y] == 0 && flux[x][y] < c[x][y]){

                pred[y] = x;
                q.push(y);

            }

        }

    }

    return false;

}

int flux_drum(){

    int ans = inf, x = d;
    while(x != s){

        ans = min(ans, c[pred[x]][x] - flux[pred[x]][x]);
        x = pred[x];

    }

    return ans;
}

void actualizare(int mini){

    int x = d;
    while(x != s){

        flux[pred[x]][x] += mini;
        flux[x][pred[x]] -= mini;

        x = pred[x];

    }

}

int flux_maxim(){

    // caut fluxul minim ramas

    int ans = 0;
    while(exista_drum()){

        int mini = flux_drum();
        actualizare(mini);
        ans += mini;

    }

    return ans;
}

int main(){

    cin >> n >> m;
    for(int i = 0; i < m; i++){

        int x = 0, y = 0, cap = 0;
        cin >> x >> y >> cap;

        c[x][y] = cap;
        g[x].push_back(y);
        g[y].push_back(x);

    }

    s = 1, d = n;
    cout << flux_maxim();

    cin.close();
    cout.close();

    return 0;
}
