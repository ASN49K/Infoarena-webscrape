#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

const int NMAX=1005;

vector<vector<int>> edgIn, edgOut;
int capacitate[NMAX][NMAX], flux[NMAX][NMAX];
int n,m;
vector<int> tata;

static inline bool BFS(int sursa, int target){
    queue<int> q;
    vector<bool> visited(n+1, false);
    tata.resize(n+1, 0);

    q.push(sursa);
    while (!q.empty()){
        int u=q.front();
        q.pop();

        for (auto &v : edgOut[u]){
            if (!visited[v] && capacitate[u][v]-flux[u][v]>0){
                visited[v]=true;
                tata[v]=u;
                q.push(v);
                if (v==target) return true;
            }
        }

        for (auto &v : edgIn[u]){
            if (!visited[v] && flux[v][u]>0){
                visited[v]=true;
                tata[v]=-u;
                q.push(v);
                if (v==target) return true;
            }
        }
    }
    return false;
}

static inline int capacitateReziduala(vector<int> &tata, int sursa, int target){
    int capacitateMinima=1e9;
    int nodCurent=target;

    while (nodCurent!=sursa){
        int t=tata[nodCurent];
        if (t>0){
            capacitateMinima=min(capacitateMinima, capacitate[t][nodCurent]-flux[t][nodCurent]);
            nodCurent=t;
        }
        else{
            t=-t;
            capacitateMinima=min(capacitateMinima, flux[nodCurent][t]);
            nodCurent=-t;
        }
    }
    return capacitateMinima;
}

static inline void actualizeazaFlux(vector<int> &tata, int sursa, int target, int capacitateMinima){
    int nodCurent=target;

    while (nodCurent!=sursa){
        int t=tata[nodCurent];
        if (t>0){
            flux[t][nodCurent]+=capacitateMinima;
            nodCurent=t;
        }
        else{
            t=-t;
            flux[nodCurent][t]-=capacitateMinima;
            nodCurent=-t;
        }
    }
}

int main(){
    f.tie(nullptr);

    f>>n>>m;
    edgIn.resize(n+1);
    edgOut.resize(n+1);
    while (m--){
        int u,v,c;
        f>>u>>v>>c;
        edgOut[u].push_back(v);
        edgIn[v].push_back(u);
        capacitate[u][v]=c;
    }

    int fluxMaxim=0;
    while (BFS(1, n)){
        int capacitateReziduala=capacitateReziduala(tata, 1, n);
        actualizeazaFlux(tata, 1, n, capacitateReziduala);
        fluxMaxim+=capacitateReziduala;
    }

    g<<fluxMaxim<<"\n";
    return 0;
}
