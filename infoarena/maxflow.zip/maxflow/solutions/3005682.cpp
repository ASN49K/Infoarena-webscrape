#include <cstdio>
#include <vector>

using namespace std;

#define file_in "maxflow.in"
#define file_out "maxflow.out"

#define Nmax 1111

int C[Nmax][Nmax];
int F[Nmax][Nmax];
int n,m,viz[Nmax];



int bfs()
{
	int q[Nmax],i,x,p,u;
	memset(viz,0,sizeof(viz));
	q[0]=1;
	viz[1]=-1;
	p=u=0;

	while(p<=u)
	{
		x=q[p];
		for (i=1;i<=n;++i){
		      if (!viz[i] && C[x][i]>F[x][i])
			  {
				  viz[i]=x;
				  q[++u]=i;
				  if (i==n)
					  return 1;
			  }
		}
		p++;
	}

	return 0;
}

int flow()
{
	int v,i,j,maxflow=0;

	for(;bfs();)
	{
		for (i=1;i<=n;++i)
        {
			if (viz[i]<=0 || C[i][n]<=F[i][n]) continue;
        v=C[i][n]-F[i][n];
		for (j=i;j!=1;j=viz[j])
 	         v=min(v,C[viz[j]][j]-F[viz[j]][j]);
        if (v==0)
			continue;
		F[i][n]+=v;
		F[n][i]-=v;

		for (j=i;j!=1;j=viz[j])
		{
			F[viz[j]][j]+=v;
			F[j][viz[j]]-=v;
		}
		maxflow+=v;
		}
	}

	return maxflow;
}


int main()
{
	int i,a,b,c;
	freopen(file_in,"r",stdin);
	freopen(file_out,"w",stdout);

	scanf("%d %d", &n, &m);
	for (i=1;i<=m;++i)
	{
		scanf("%d %d %d", &a, &b, &c);
		C[a][b]=c;
	}

	printf("%d\n", flow());

	fclose(stdin);
	fclose(stdout);


	return 0;

}
