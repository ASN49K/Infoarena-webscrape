#include <bits/stdc++.h>
using namespace std;
ifstream fin ("maxflow.in");
ofstream fout ("maxflow.out");
int const lmax=1007;
int const inf=1e9+7;
int n,m,s,t;
int ind[lmax];
int c[lmax][lmax];
vector<int>G[lmax];
int dist[lmax];
int rez=0;
void bfs()
{
    for(int i=1;i<=n;i++)
    {
        ind[i]=0;
        dist[i]=-1;
    }
    dist[s]=0;
    queue<int>q;
    q.push(s);
    while(q.empty()==false)
    {
        int crtnode=q.front();
        q.pop();
        for(auto vec:G[crtnode])
        {
            if(dist[vec]==-1 and c[crtnode][vec]!=0)
            {
                dist[vec]=dist[crtnode]+1;
                q.push(vec);
            }
        }
    }
}
int dfs(int node, int minm)
{
    if(node==t or minm==0)
    {
        return minm;
    }
    while(ind[node]<G[node].size())
    {
        int vec=G[node][ind[node]];
        if(dist[vec]==dist[node]+1)
        {
            int x=dfs(vec,min(minm,c[node][vec]));
            if(x==0)///nu ma ajuta, elimin
            {
                ind[node]++;
            }
            else///trebuie modificate muchiile
            {
                c[node][vec]-=x;
                c[vec][node]+=x;
                return x;///am ajuns deja pana la t fara ca x sa fie 0, deci asta e un drum valid
            }
        }
        else ind[node]++;
    }
    return 0;
}
bool flux()
{
    ///bfs pentru distante
    bfs();
    if(dist[t]==-1)return 0;
    int rasp=0;
    while(true)
    {
        int val=dfs(s,inf);
        rasp+=val;
        if(val==0)break;
    }
    rez+=rasp;
    return (rasp!=0);
}
int main()
{
    fin>>n>>m;
    for(int i=0;i<m;i++)
    {
        int a,b,cap;
        fin>>a>>b>>cap;
        G[a].push_back(b);
        G[b].push_back(a);
        c[a][b]=cap;
        c[b][a]=0;
    }
    s=1,t=n;
    while(flux());
    fout<<rez;
    fin.close();
    fout.close();
    return 0;
}
