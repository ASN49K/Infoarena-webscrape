#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e3 + 2;
string __fname = "maxflow"; ifstream in (__fname + ".in"); ofstream out (__fname + ".out"); 
#define cin in 
#define cout out
int cap[maxn][maxn];
vector <int> ad [maxn];
int dad [maxn];
int vis [maxn];

int getflow (int s, int d) {
    for (int i = 0; i < maxn; i++) dad[i] = vis[i] = 0;
    queue <pair <int, int> > q;
    q.push({s, 1e9});
    while (!q.empty()) {
        int u = q.front().first;
        int flow = q.front().second;
        if (u == d) return flow;
        q.pop();
        for (int v: ad[u]) {
            if (!cap[u][v] || vis[v]) continue;
            vis[v] = 1;
            q.push({v, min(flow, cap[u][v])});
            dad[v] = u;
        }
    }
    return 0;
}

int main() {
    int n,m;
    cin >> n >> m;
    for (int i = 0; i < m; i++){
        int x,y,c;
        cin >> x >> y >> c;
        ad[x].push_back(y);
        ad[y].push_back(x);
        cap[x][y] = c;
    }
    int ans = 0;
    while (int flow = getflow(1, n)) {
        ans+=flow;
        for (int u = n; u != 1; u = dad[u]) {
            int v = dad[u];
            cap[v][u]-=flow;
            cap[u][v]+=flow;
        }
    }
    cout << ans;
    return 0;
}