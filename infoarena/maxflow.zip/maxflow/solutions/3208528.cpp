#include <bits/stdc++.h>
#include <cstring>
#include <cstdio>
#pragma GCC optimize ("O3")
#define din cin
#define dout out
#define pi 3.14159265359
#define sw(x,y) x^=y,y^=x,x^=y
#define bmin(a,b)((a<b)?(a):(b))
#define bmax(a,b)((a>b)?(a):(b))
#define bminify(a,b)a=bmin(a,b)
#define bmaxify(a,b)a=bmax(a,b)
#define forq(i,ii,n)for(i=ii;i<n;i++)
#define f first
#define s second
#define mod 1000000007ll
#define nmax 300002
#define lim 1001
using namespace std;
typedef long long ll;
ifstream in("maxflow.in");
ofstream out("maxflow.out");
//FILE *fin=fopen("infasuratoare.in","r");
//FILE *fout=fopen("infasuratoare.out","w");
int n,m,s2,s1,c0[lim][lim],c1[lim][lim],d[lim],e[lim],c[lim*lim],v[lim][lim],i,j,k,l,u,f[lim],s;
vector<int>g[lim];
int main()
{
in>>n>>m;s1=1,s2=n;
while(m--)in>>i>>j,in>>v[i][j],g[i].emplace_back(j),g[j].emplace_back(i);
while(true){
    fill(f,f+lim,0);
    c[0]=s1,l=1,u=0,f[1]=1;
    while(u!=l){
        i=c[u++];
        if(i==s2)break;
        for(auto j:g[i])if(v[i][j]!=c1[i][j]&&f[j]==0)f[j]=i,c[l++]=j;
    }
    if(f[s2]){
        for(auto u:g[n])
            if(c1[u][n]!=v[u][n]&&f[u]){
                f[n]=u,k=INT_MAX;
                for(i=s2;i!=s1;i=f[i])bminify(k,v[f[i]][i]-c1[f[i]][i]);
                for(i=s2;i!=s1;i=f[i])c1[f[i]][i]+=k,c1[i][f[i]]-=k;
                s+=k;
        }
    }
    else break;
}
out<<s;
}
