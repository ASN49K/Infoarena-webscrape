#include <bits/stdc++.h>
#pragma GCC optimize("Ofast,unroll-loops")
#pragma GCC target("sse,avx,fma,avx2,bmi,bmi2,lzcnt,popcnt")

using namespace std;

class EdmondsKarp {

private:
	int n;
	const int INF = 1e9;
	vector<vector<int>> adj_matrix;
	vector<vector<int>> adj_list;

	vector<int> pi; 
	bool bfs(int source, int sink) {
		vector<bool> visited (n, false);
		queue<int> q; q.push(source), visited[source] = true;

		while(!q.empty()) {
			int u = q.front();
			q.pop();

			for (int v : adj_list[u])
				if (!visited[v] && adj_matrix[u][v] > 0)
					visited[v] = true, q.push(v), pi[v] = u;
		}

		return visited[sink];
	}

	int get_flow(int source, int node) {
		if (node == source)
			return INF;

		int flow = min(get_flow(source, pi[node]), adj_matrix[pi[node]][node]);
		adj_matrix[pi[node]][node] -= flow, adj_matrix[node][pi[node]] += flow;
		return flow;
	}

public:
	EdmondsKarp(int _n) {
		n = _n;
		adj_matrix = vector<vector<int>> (n, vector<int> (n, 0));
		adj_list.resize(n);
		pi.resize(n);
	}

	void insert_edge(int x, int y, int c) {
		adj_list[x].push_back(y);
		adj_list[y].push_back(x);
		adj_matrix[x][y] += c;
	}

	int get_max_flow(int source, int sink) {
		int max_flow = 0;
		while(bfs(source, sink))
			for (int neigh : adj_list[sink])
				max_flow += get_flow(source, neigh);

		return max_flow;
	}
};

int main()
{
	freopen("maxflow.in", "r", stdin);
	freopen("maxflow.out", "w", stdout);

	int n, m;
	cin >> n >> m;

	EdmondsKarp solver(n);
	for (int edge = 0, x, y, c; edge < m; ++edge) {
		cin >> x >> y >> c;
		--x, --y;
		solver.insert_edge(x, y, c);
	}

	cout << solver.get_max_flow(0, n - 1) << endl;
	return 0;
}
