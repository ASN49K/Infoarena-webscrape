#include <bits/stdc++.h>
using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");
#define cin f
#define cout g

int n, m;
vector<int> parent;
vector<vector<int>> capacity;
vector<vector<int>> adj;

int bfs(int s, int t, vector<int>& parent) {
    fill(parent.begin(), parent.end(), -1);
    parent[s] = -2;
    queue<pair<int, int>> q;
    q.push({s, INT_MAX});

    while (!q.empty()) {
        int cur = q.front().first;
        int flow = q.front().second;
        q.pop();

        for (int next : adj[cur]) {
            if (parent[next] == -1 && capacity[cur][next]) {
                parent[next] = cur;
                int new_flow = min(flow, capacity[cur][next]);
                if (next == t)
                    return new_flow;
                q.push({next, new_flow});
            }
        }
    }
    return 0;
}

int maxflow(int s, int t) {
    int flow = 0;
    int new_flow;

    while (new_flow = bfs(s, t, parent)) {
        flow += new_flow;
        int cur = t;
        while (cur != s) {
            int prev = parent[cur];
            capacity[prev][cur] -= new_flow;
            capacity[cur][prev] += new_flow;
            cur = prev;
        }
    }

    return flow;
}

int main() {
	cin >> n >> m;
	parent.resize(n+1);
	capacity.resize(n+1, vector<int>(n+1));
	adj.resize(n+1);

	for(int i = 1; i <= m; i ++) {
		int a, b, c;
		cin >> a >> b >> c;
		adj[a].push_back(b);
		adj[b].push_back(a);
		capacity[a][b] = c;
		capacity[b][a] = 0;
	}

	cout << maxflow(1, n) << '\n';
	return 0;
}


// Edmonds-Karp algorithm O(VE^2):