#include <bits/stdc++.h>
using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

const int inf = 1e9;
int n, m, x, y, c, total_flow;
int level[1005], ptr[1005];

struct Edge {
    int to, cap, flow, rev;
};

vector <Edge> v[1005];
queue <int> q;

bool bfs() {
    while (!q.empty()) q.pop();
    
    memset(level, -1, sizeof(level));
    level[1] = 0;
    q.push(1);
    
    while (!q.empty()) {
        int nod_curent = q.front();
        q.pop();
        
        for (auto &edge : v[nod_curent]) {
            if (edge.cap - edge.flow > 0 && level[edge.to] == -1) {
                level[edge.to] = level[nod_curent] + 1;
                q.push(edge.to);
            }
        }
    }
    return level[n] != -1;
}

int dfs(int nod, int pushed) {
    if (pushed == 0 || nod == n) return pushed;
    
    for (int &cid = ptr[nod]; cid < v[nod].size(); ++cid) {
        auto &edge = v[nod][cid];
        
        if (level[nod] + 1 != level[edge.to] || edge.cap - edge.flow == 0) continue;
        
        int tr = dfs(edge.to, min(pushed, edge.cap - edge.flow));
        if (tr == 0) continue;
        
        edge.flow += tr;
        v[edge.to][edge.rev].flow -= tr;
        
        return tr;
    }
    return 0;
}

void dinic() {
    while (bfs()) {
        memset(ptr, 0, sizeof(ptr));
        
        while (int pushed = dfs(1, inf)) {
            total_flow += pushed;
        }
    }
}

int main()
{
    f >> n >> m;
    
    for (int i = 1; i <= m; ++i) {
        f >> x >> y >> c;
        
        Edge a = {y, c, 0, (int)v[y].size()};
        Edge b = {x, 0, 0, (int)v[x].size()};
        
        v[x].push_back(a);
        v[y].push_back(b);
    }
    
    dinic();
    
    g << total_flow;
    
    return 0;
}