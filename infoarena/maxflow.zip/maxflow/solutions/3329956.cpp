#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

const int NMAX = 1001;

vector<vector<int>> edgIn, edgOut;
vector<int> tata;
int cap[NMAX][NMAX], flux[NMAX][NMAX];
int n, m;

bool BFS(int s, int t){
    queue<int> q;
    vector<int> viz(n+1, 0);
    tata.resize(n+1, 0);
    q.push(s);
    while(!q.empty()){
        int u = q.front();
        q.pop();
        for(auto &v:edgOut[u]){
            if(!viz[v] && cap[u][v] - flux[u][v] > 0){
                viz[v] = 1;
                q.push(v);
                tata[v] = u;
                if(v == t)
                    return true;
            }
        }
        for(auto &v:edgIn[u]){
            if(!viz[v] && flux[v][u] > 0){
                viz[v] = 1;
                q.push(v);
                tata[v] = -u;
                if(v == t)
                    return true;
            }
        }
    }
    return false;
}

int capRezid(vector<int> &tata, int s, int t){
    int mn = 200000;
    for(int v = t; v!=s; v = abs(tata[v])){
        if(tata[v] > 0){
            mn = min(mn, cap[tata[v]][v] - flux[tata[v]][v]);
        }
        else{
            mn = min(mn, flux[v][-tata[v]]);
        }
    }
    return mn;
}

void actualizareFlux(vector<int> &tata, int s, int t, int cr){
    for(int v = t; v!=s; v = abs(tata[v])){
        if(tata[v] > 0){
            flux[tata[v]][v] += cr;
        }
        else{
            flux[v][-tata[v]] -= cr;
        }
    }
}

int main(){
    fin>>n>>m;
    edgIn.resize(n+1);
    edgOut.resize(n+1);
    while(m--){
        int u, v, c;
        fin>>u>>v>>c;
        edgOut[u].push_back(v);
        edgIn[v].push_back(u);
        cap[u][v] = c;
    }
    int fluxmax = 0;
    while(BFS(1, n)){
        int cr = capRezid(tata, 1, n);
        actualizareFlux(tata, 1, n, cr);
        fluxmax += cr;
    }
    fout<<fluxmax;
    return 0;
}
