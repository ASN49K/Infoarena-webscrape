#include <bits/stdc++.h>
using namespace std;
//Soltan Cristian
#define ll long long
#define all(x) x.begin(), x.end()
#define mod 1000000007
#define pb push_back
#define st first
#define nd second
#define sz(x) (ll)x.size()
#define rall(x) x.rbegin(), x.rend()

const int dx[] = {-1, 0, 1, 0};
const int dy[] = {0, 1, 0, -1};

const ll INF = 110001;
const int mxa = 1 * 1e3 + 1;
string __fname = "maxflow";  
ifstream in(__fname + ".in"); 
ofstream out (__fname + ".out"); 
#define cin in 
#define cout out


int n, m;
vector<vector<int>> adj(mxa), capacity(mxa, vector<int>(mxa));


int bfs(int s, int t, vector<int>& parent){
  fill(all(parent), -1);
  queue<pair<int, int>> q;
  parent[s] = -2;
  q.push({s, INF});
  while(!q.empty()){
    int cur = q.front().st;
    int flow = q.front().nd;
    q.pop();
    for(auto i : adj[cur]){
      if(parent[i] == -1 && capacity[cur][i] > 0){
        flow = min(flow, capacity[cur][i]);
        parent[i] = cur;
        if(i == t){
          return flow;
        }
        q.push({i, flow});
      }
    }
  }
  return 0;
}


int flow(int s, int t){
  int maxFlow = 0;
  vector<int> parent(n + 1);
  int newFlow = 0;
  while(newFlow = bfs(s, t, parent)){
    maxFlow += newFlow;
    int node = t;
    while(node != s){
      int prev = parent[node];
      capacity[prev][node] -= newFlow; 
      capacity[node][prev] += newFlow;
      node = prev;
    }
  }
  
  return maxFlow;
}

void solve(){
  cin >> n >> m;
  for(int i = 0; i < m; i++){
    int a, b, c;
    cin >> a >> b >> c;
    adj[a].pb(b);
    adj[b].pb(a);
    capacity[a][b] = c;
  }
  cout << flow(1, n) << '\n';

  
}
 
 
int main()
{   
    ios_base::sync_with_stdio(0); cin.tie(0); cout << fixed  << (setprecision(6)); 
    // int t;
    // cin >> t;
    // while(t--)
        solve();
    return 0;
}