#include <bits/stdc++.h>

const int NMAX = 5e5 + 5;

struct flowEdge {
    int u, v, cap;
};

int n, m, f[NMAX], t[NMAX];

std :: vector < flowEdge > edges;
std :: vector < int > G[NMAX];

std :: ifstream fin("maxflow.in");
std :: ofstream fout("maxflow.out");

void BFS(int node) {
    std :: queue < int > Q;

    Q.push(node);
    f[node] = true;

    while (!Q.empty()) {
        int u = Q.front();

        for (int i = 0; i < G[u].size(); ++ i) {
            int x = G[u][i];

            if (f[edges[x].v] == false && edges[x].cap > 0) {
                t[edges[x].v] = x;
                Q.push(edges[x].v);
                f[edges[x].v] = true;
            }
        }

        Q.pop();
    }

    return;
}

void DFSUtil(int node) {
    f[node] = true;

    for (int i = 0; i < G[node].size(); ++ i) {
        int u = G[node][i];

        if (f[edges[u].v] == false && edges[u].cap > 0)
            DFSUtil(edges[u].v);
    }

    return;
}

int main() {
    fin >> n >> m;

    for (int i = 0, u, v, cap; i < m; ++ i) {
        fin >> u >> v >> cap;

        edges.push_back({u, v, cap});
        G[u].push_back(edges.size() - 1);

        edges.push_back({v, u, 0});
        G[v].push_back(edges.size() - 1);
    }

    int flow = 0;

    while (1) {
        for (int i = 0; i <= n; ++ i) {
            t[i] = -1;
            f[i] = false;
        }

        BFS(1);

        if (t[n] == -1)
            break;

        int x = n, Min = 1e9;

        while (t[x] != -1) {
            Min = std :: min(Min, edges[t[x]].cap);

            x = edges[t[x]].u;
        }

        x = n;

        while (t[x] != -1) {
            edges[t[x]].cap -= Min;
            edges[t[x] ^ 1].cap += Min;

            x = edges[t[x]].u;
        }

        flow += Min;
    }

    fout << flow << "\n";

    /** for (int i = 1; i <= n; ++ i)
        f[i] = false;

    DFSUtil(1);

    for (int i = 0; i < edges.size(); ++ i)
        if (f[edges[i].u] == true && f[edges[i].v] == false)
            fout << edges[i].u << " " << edges[i].v << "\n"; **/

    return 0;
}
