#include <fstream>
#include <vector>
#include <climits>
#include <queue>

using namespace std;

ifstream in("maxflow.in");
ofstream out("maxflow.out");

int c[1001][1001], tata[1001];
vector<int> adj[1001], viz(1001);
queue<int> coada;
int n, src, dest;

bool bfs(int src){
    for(int i = 1; i <= n; i++){
        viz[i] = 0;
    }
    coada = queue<int>();
    viz = vector<int>(1001);
    coada.push(src);
    viz[src] = 1;
    tata[src] = -1;

    while(!coada.empty()){
        int nod = coada.front();
        coada.pop();
        for(auto vec: adj[nod]){
            if(c[nod][vec] > 0 && !viz[vec]){
                tata[vec] = nod;
                if(vec == dest)
                    return true;
                viz[vec] = 1;
                coada.push(vec);
            }
        }
    }

    return false;
}

int main()
{
    int m, x, y, z;
    in >> n >> m;
    for(int  i = 0; i < m; i++){
        in >> x >> y >> z;
        c[x][y] = z;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    src = 1;
    dest = n;
    long long cap_max = 0;

    while(bfs(src)){
        int cap = INT_MAX, nod = dest;
        while(nod != src){
            cap = min(cap, c[tata[nod]][nod]);
            nod = tata[nod];
        }

        nod = dest;
        while(nod != src){
            c[tata[nod]][nod] -= cap;
            c[nod][tata[nod]] += cap;
            nod = tata[nod];
        }

        cap_max += cap;
    }

    out << cap_max;

    return 0;
}
