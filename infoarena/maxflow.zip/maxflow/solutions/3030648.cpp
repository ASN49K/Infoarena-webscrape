#include <fstream>
#include <vector>
#include <bitset>
#include <queue>
using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");

const int N = 1009,Inf = 0x3f3f3f3f;
int n,m,a,b,c,C[N][N],t[N];
vector<vector<int>> G;
bitset<N> v;
queue<int> q;

bool Bfs(int source,int sink)
{
    v.reset();
    q.push(source);
    v[source] = 1;

    while(!q.empty())
    {
        int x = q.front();
        q.pop();

        for(auto i : G[x])
            if(C[x][i] > 0 && !v[i])
            {
                v[i] = 1;
                t[i] = x;
                q.push(i);
            }
    }

    return v[sink];
}

int MaxFlow(int source,int sink)
{
    int maxflow = 0, fmin;
    while(Bfs(source,sink))
    {
        fmin = Inf;
        for(int i = sink; i != source; i = t[i])
            fmin = min(fmin,C[t[i]][i]);

        if(!fmin)continue;

        for(int i = sink; i != source; i = t[i])
        {
            C[t[i]][i] -= fmin;
            C[i][t[i]] += fmin;
        }

        maxflow += fmin;
    }
    return maxflow;
}

int main()
{
    cin>>n>>m;
    G = vector<vector<int>>(n+1);
    while(m--)
    {
        cin>>a>>b>>c;
        G[a].push_back(b);
        G[b].push_back(a);
        C[a][b] += c;
    }

    cout<<MaxFlow(1,n);
    return 0;
}
