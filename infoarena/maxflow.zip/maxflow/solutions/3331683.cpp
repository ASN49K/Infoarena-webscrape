#include <fstream>
#include <vector>
#include <queue>
#define inf 1e9
#define nmax 1005
using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
int n,m,x,y,cap,f[nmax][nmax],flow,dist[nmax],c[nmax][nmax];
vector<int>v[nmax];
queue<int>q;
bool bfs(int s,int d){
    for(int i=1;i<=n;i++)
        dist[i]=inf;
    dist[s]=0;
    q.push(s);
    while(!q.empty()){
        int nod=q.front();
        q.pop();
        for(auto i:v[nod])
            if(dist[i]>dist[nod]+1&&f[nod][i]<c[nod][i]){
                dist[i]=dist[nod]+1;
                q.push(i);
            }
    }
    return dist[d]!=inf;
}
int dinic(int nod,int d,int val){
    if(val==0)/// nu avem de ce continua
        return 0;
    if(nod==d)/// am gasit un drum
        return val;
    int total=0;
    for(auto i:v[nod])
        if(dist[i]==dist[nod]+1){
            int add=dinic(i,d,min(c[nod][i]-f[nod][i],val-total));
            f[nod][i]+=add;
            f[i][nod]-=add;
            total+=add;
        }
    return total;
}
signed main()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>x>>y>>cap;
        c[x][y]+=cap;
        v[x].push_back(y);
        v[y].push_back(x);
    }
    while(bfs(1,n))
        flow+=dinic(1,n,inf);
    cout<<flow;
    return 0;
}
