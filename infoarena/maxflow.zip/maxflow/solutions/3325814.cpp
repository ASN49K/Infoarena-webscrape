#include <bits/stdc++.h>

using namespace std;

ifstream fin ("maxflow.in");
ofstream fout ("maxflow.out");

vector <int> g[1005];

int n, m, rez;

int cap[1005][1005], flow[1005][1005];

int dist[1005];

bool bfs (int source, int destination)
{
    for (int i = 1; i <= n; i++)
        dist[i] = INT_MAX;
    dist[source] = 0;
    queue <int> q;
    q.push (source);
    while (!q.empty ())
    {
        int node = q.front ();
        q.pop ();
        for (auto x : g[node])
        {
            if (cap[node][x] > flow[node][x] && dist[x] > dist[node] + 1)
            {
                dist[x] = dist[node] + 1;
                q.push (x);
            }
        }
    }
    return dist[destination] != INT_MAX;
}

int max_flow (int node, int destination, int maxflow)
{
    if (maxflow == 0)
        return 0;
    if (node == destination)
        return maxflow;
    int tflow = 0;
    for (auto x : g[node])
    {
        if (dist[x] != dist[node] + 1)
            continue;
        int cflow = max_flow (x, destination, min (maxflow - tflow, cap[node][x] - flow[node][x]));
        flow[node][x] += cflow;
        flow[x][node] -= cflow;
        tflow += cflow;
    }
    return tflow;
}

void compute_flow ()
{
    while (bfs (1, n))
        rez += max_flow (1, n, INT_MAX);
}

int main ()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y, c;
        fin >> x >> y >> c;
        g[x].push_back (y);
        g[y].push_back (x);
        cap[x][y] = c;
    }
    compute_flow ();
    fout << rez;
    return 0;
}
