#include <fstream>
#include <vector>
#include <queue>
#include <bitset>

struct edge {
  int pos;
  int flux;
  int maxf;
	int inv_id;
};

struct node {
	int last_node;
	int back_id;
	int flux_val;
  std::vector<edge> edges;
};

struct que_node {
	int pos;
	int max_add;
};

#define MAXN 1005
#define INF 1000000005

node web[MAXN];

int FindPath(int start, int stop) {
	std::bitset <MAXN> viz;
	std::queue <que_node> next;
	que_node now;
	next.push({start, INF});
	viz[0] = true;
	while (!next.empty()) {
		now = next.front();
		next.pop();
		if (now.pos == stop) {
			return now.max_add;
		}
		for (int i = 0; i < web[now.pos].edges.size(); i++) {
			edge &chd = web[now.pos].edges[i];
			if (chd.flux < chd.maxf && !viz[chd.pos]) {
				viz[chd.pos] = true;
				web[chd.pos].last_node = now.pos;
				web[chd.pos].back_id = i;
				next.push({chd.pos, std::min(now.max_add, chd.maxf - chd.flux)});
			}
		}
	}
	return 0;
}
void PumpPath(int start, int stop, int add) {
	int pos = stop, last;
	int pos_id, last_id;
	while(pos != start) {
		web[pos].flux_val += add;
		last = web[pos].last_node;
		pos_id = web[pos].back_id;
		web[last].edges[pos_id].flux += add;
		last_id = web[last].edges[pos_id].inv_id;
		web[pos].edges[last_id].flux -= add;
		pos = last;
	}
	web[start].flux_val += add;
}
int FluxCalc(int start, int stop) {
	int sum = 0, add;
	sum += add = FindPath(start, stop);
  while (add) {
		PumpPath(start, stop, add);
		sum += add = FindPath(start, stop);
	}
	return sum;
}

std::ifstream fin("maxflow.in");
std::ofstream fout("maxflow.out");

int main() {
	int n, m;
  int a, b, c;
  int i;

  fin >> n >> m;
  for (i = 0; i < m; i++) {
    fin >> a >> b >> c;
		a--;
		b--;
    web[a].edges.push_back({b, 0, c, (int)web[b].edges.size()});
    web[b].edges.push_back({a, 0, 0, (int)web[a].edges.size() - 1});
  }
	fout << FluxCalc(0, n - 1);
	//fout << web[0].flux_val;
}
