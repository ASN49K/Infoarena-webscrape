#include <bits/stdc++.h>

using namespace std;
ifstream fin ("maxflow.in");
ofstream fout ("maxflow.out");

const int N_MAX = 1e3;
const int myINF = 2e9;

struct maxFlow {
    int source, sink;
    int flow[1 + N_MAX][1 + N_MAX], cap[1 + N_MAX][1 + N_MAX];
    void add_edge (int u, int v, int c) {
        cap[u][v] = c;
    }

    int pr[1 + N_MAX];
    bool bfs (void) {
       queue<int> q; q.push (source);
       pr[source] = source;

       while (!q.empty ()) {
          int root = q.front (); q.pop ();
          for (int node = 1; node <= sink; node ++) {
             if (!pr[node] && flow[root][node] < cap[root][node]) {
                pr[node] = root;
                q.push (node);
                if (node == sink)
                  return true;
             }
          }
       }
       return false;
    }

    int totalFlow = 0;
    void addFlow (void) {
       while (bfs ()) {
          for (int node = 1; node <= sink; node ++) {
             if (pr[node] && flow[node][sink] < cap[node][sink]) {
                pr[sink] = node;

                int neck = myINF;
                for (int x = sink; x != source; x = pr[x]) neck = min (neck, cap[pr[x]][x] - flow[pr[x]][x]);
                for (int x = sink; x != source; x = pr[x]) {
                   flow[pr[x]][x] += neck;
                   flow[x][pr[x]] -= neck;
                }
                totalFlow += neck;
             }
          }
          for (int node = 1; node <= sink; node ++) pr[node] = 0;
       }
    }
} F;

int main()
{
   int N, M; fin >> N >> M;
   F.source = 1, F.sink = N;
   for (int i = 1; i <= M; i ++) {
      int u, v, c; fin >> u >> v >> c;
      F.add_edge (u, v, c);
   }
   F.addFlow ();
   fout << F.totalFlow;

    return 0;
}
