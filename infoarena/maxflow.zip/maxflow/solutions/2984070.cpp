#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cstring>

using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

const int INF = 0x3f3f3f3f;
const int SIZE = 1005;

vector <int> G[SIZE];
int n, m, capacity[SIZE][SIZE], parent[SIZE];

bool bfs(int source, int sink)
{
    memset(parent, 0, sizeof(parent));
    queue <int> Q;
    Q.push(source);
    while(!Q.empty())
    {
        int x = Q.front();
        Q.pop();
        for (auto y : G[x])
        {
            if (parent[y] == 0 && capacity[x][y] > 0)
            {
                parent[y] = x;
                Q.push(y);
            }
        }
    }
    return parent[sink];
}

int MaxFlow(int source, int sink)
{
    int maxFlow = 0, fmin;

    while (bfs(source, sink))
        for (auto x : G[sink])
        {
            if (parent[x] == 0 || capacity[x][sink] <= 0)
                continue;
            parent[sink] = x;
            fmin = INF;
            for (int i = sink; i != source; i = parent[i])
                fmin = min (fmin, capacity[parent[i]][i]);
            for (int i = sink; i != source; i = parent[i])
            {
                capacity[parent[i]][i] -= fmin;
                capacity[i][parent[i]] += fmin;
            }
            maxFlow += fmin;
        }

    return maxFlow;
}

int main()
{
    f >> n >> m;

    for (int i = 1; i <= m; ++i)
    {
        int x, y, z;
        f >> x >> y >> z;
        G[x].push_back(y);
        G[y].push_back(x);
        capacity[x][y] += z;
    }

    g << MaxFlow(1, n);

    return 0;
}
