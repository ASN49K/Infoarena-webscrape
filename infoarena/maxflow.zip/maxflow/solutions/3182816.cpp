#include <iostream>
#include <algorithm>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>
#include <climits>
#include <set>
#include <string>
using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
vector<int> v[1005];
int cap[1005][1005], flow[1005][1005];
queue<int> q;
int n, m;
int viz[1005], parent[1005];
bool bfs(int nod) {
	for (int i = 1; i <= n; i++) {
		viz[i] = 0;
		parent[i] = 0;
	}
	viz[nod] = 1;
	q.push(nod);
	while (!q.empty()) {
		int cr = q.front();
		q.pop();
		if (cr == n) continue;
		for (auto el : v[cr]) {
			if (!viz[el] && flow[cr][el] < cap[cr][el]) {
				viz[el] = 1;
				q.push(el);
				parent[el] = cr;
			}
		}
	}
	if (viz[n]) return true;
	return false;
}
int main() {
	fin >> n >> m;
	for (int i = 1; i <= m; i++) {
		int x, y, f;
		fin >> x >> y >> f;
		v[x].push_back(y);
		v[y].push_back(x);
		cap[x][y] += f;
	}
	int flux = 0;
	while (bfs(1)) {
		for (auto el : v[n]) {
			if (flow[el][n] < cap[el][n] && viz[el]) {
				int fluxmin = cap[el][n] - flow[el][n];
				int nod = el;
				while (nod != 1) {
					fluxmin = min(fluxmin, cap[parent[nod]][nod] - flow[parent[nod]][nod]);
					nod = parent[nod];
				}
				flux += fluxmin;
				nod = el;
				while (nod != 1) {
					flow[parent[nod]][nod] += fluxmin;
					flow[nod][parent[nod]] -= fluxmin;
					nod = parent[nod];
				}
				flow[el][n] += fluxmin;
				flow[n][el] -= fluxmin;
			}
		}
	}
	fout << flux;
}