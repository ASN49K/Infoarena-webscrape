#include <iostream>
#include <fstream>

#include <cstring>

#include <vector>
#include <queue>

#define INFINITY (1<<31)
#define NMAX 1000

std::ifstream fin;
std::ofstream fout;


bool pump(int s, int d, int n, std::pair<int, int> cap[][NMAX], int par[])
{
    std::queue<int> q;

    q.push(s);

    while (!q.empty()) {
        auto node = q.front();
        q.pop();

        for (int neigh = 0; neigh < n; ++neigh) {
            auto &capacity = cap[node][neigh];

            if (capacity.second != -1
                && capacity.second > capacity.first
                && par[neigh] == -1) {

                par[neigh] = node;

                if (neigh == d)
                    return true;

                q.push(neigh);
            }
        }
    }

    return false;
}

int main()
{
    int n, m, source, drain;
    std::pair<int, int> adjcap[NMAX][NMAX];
    long long max_flow = 0;
    int parent[NMAX];

    fin.open("maxflow.in");
    fout.open("maxflow.out");

    fin >> n >> m;

    source = 0;
    drain = n - 1;
    memset(adjcap, -1, sizeof(adjcap));

    for (int src, dest, cap, i = 0; i < m; ++i) {
        fin >> src >> dest >> cap;
        adjcap[src - 1][dest - 1] =  {0, cap};
        adjcap[dest - 1][src - 1] = {0, 0};
    }


    while (memset(parent, -1, sizeof(parent)),
           pump(source, drain, n, adjcap, parent)) {

        long long pumped_flow = INFINITY;

        for (int node = drain; node != source; node = parent[node])
            pumped_flow = std::min(pumped_flow, (long long)(adjcap[parent[node]][node].second - adjcap[parent[node]][node].first));

        for (int node = drain; node != source; node = parent[node]) {
            adjcap[parent[node]][node].first += pumped_flow;
            adjcap[node][parent[node]].first -= pumped_flow;
        }

        max_flow += pumped_flow;
    }


    fout << max_flow;

    fin.close();
    fout.close();

    return 0;
}
