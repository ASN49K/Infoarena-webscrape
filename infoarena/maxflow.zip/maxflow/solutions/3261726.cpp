#include <bits/stdc++.h>
using namespace std;

ifstream in("maxflow.in");
ofstream out("maxflow.out");
const int NMAX = (int)1e3 * 5;
const int inf = (int)1e9;
int N,M,capacitate[1005][1005],flux_trimis[1005][1005],ans;
vector<int>ad[NMAX];
bool ok = true,b[1005];
static const inline void dfs (int node,int& mn) {
    //cout << node << ' ';
    b[node] = true;
    if (node == N) {
        //cout << mn << '\n';
        ans += mn;
        b[node] = 0;
        ok = true;
        return;
    }
    for (int i : ad[node])
        if ((capacitate[node][i] - flux_trimis[node][i] > 0) && b[i] == false) {
            int d = capacitate[node][i] - flux_trimis[node][i];
            mn = min(mn,d);
            dfs(i,mn);
            if (ok) {
                flux_trimis[i][node] += -mn;
                flux_trimis[node][i] += mn;
                b[node] = 0;
                return;
            }
        }
}
int main(){
    in >> N >> M;
    while (M--) {
        int u,v,c; in >> u >> v >> c;
        ad[u].push_back(v);
        ad[v].push_back(u);
        capacitate[u][v] = c;
    }
    while (ok) {
        ok = false;
        int mn = inf;
        dfs(1,mn);
    }
    out << ans;
    return 0;
}
