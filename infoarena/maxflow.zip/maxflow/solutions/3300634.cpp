#include <bits/stdc++.h>
using namespace std;

int main() {
    ifstream fin("maxflow.in");
    ofstream fout("maxflow.out");

    int n, m;
    fin >> n >> m;
    
    vector<vector<int>> c(n + 1, vector<int>(n + 1));
    vector<vector<int>> adj(n + 1);
    for (int i = 1, u, v, capacity; i <= m; ++i) {
        fin >> u >> v >> capacity;

        adj[u].push_back(v);
        adj[v].push_back(u);
        c[u][v] = capacity;
    }

    int flow = 0, new_flow;
    int s = 1, t = n;
    vector<int> parent(n + 1);

    function<int()> bfs = [&]() -> int {
        fill(parent.begin(), parent.end(), -1);
        parent[s] = -2;
        queue<pair<int, int>> q;

        int minn = INT_MAX;
        q.emplace(s, minn);
        while (!q.empty()) {
            auto [nod, curr] = q.front(); q.pop();

            for (int vec : adj[nod]) {
                // am capacitate reziduala
                if (parent[vec] == -1 && c[nod][vec]) {
                    curr = min(curr, c[nod][vec]);
                    parent[vec] = nod;
                    if (vec == t)
                        return curr;
                    q.emplace(vec, curr);
                }
            }
        }
        return 0;
    };

    while (new_flow = bfs()) {
        flow += new_flow;
        int nod = t;
        while (nod != s) {
            int prev = parent[nod];
            c[prev][nod] -= new_flow;
            c[nod][prev] += new_flow;
            nod = prev;
        }
    }

    fout << flow << '\n';

    return 0;
}
