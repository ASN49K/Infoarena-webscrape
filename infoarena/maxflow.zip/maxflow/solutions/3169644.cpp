#include <fstream>
#include <vector>
#include <climits>
#include <queue>

#define pb push_back

using namespace std;
ifstream in("maxflow.in");
ofstream out("maxflow.out");
const int N = 1005;

struct muchie {
    int nxt, flux, cap, inv;
};

int n, m, level[N], start[N];
vector<muchie> g[N];

bool BFS() {
    for(int i=1; i<=n; i++)
        level[i] = -1;
    level[1] = 0;

    queue<int> que;
    que.push(1);
    while(!que.empty()) {
        int nod = que.front();
        que.pop();

        for(auto mc : g[nod])
            if(level[mc.nxt] < 0 && mc.flux < mc.cap) {
                level[mc.nxt] = level[nod] + 1;
                que.push(mc.nxt);
            }
    }

    if(level[n] >= 0)
        return 1;
    else return 0;
}

int sendflow(int nod, int flow) {
    if(nod == n)
        return flow;

    for(; start[nod] < g[nod].size(); start[nod]++) {
        int nxt = g[nod][start[nod]].nxt;
        if(level[nod] + 1 == level[nxt] && g[nod][start[nod]].flux < g[nod][start[nod]].cap) {
            int nxt = g[nod][start[nod]].nxt;
            int flow_now = min(flow, g[nod][start[nod]].cap - g[nod][start[nod]].flux);
            int nxt_flow = sendflow(nxt, flow_now);
            if(nxt_flow) {
                g[nod][start[nod]].flux += nxt_flow;
                g[nxt][g[nod][start[nod]].inv].flux -= nxt_flow;
                return nxt_flow;
            }
        }
    }

    return 0;
}

int dinic() {
    int ans = 0;

    while(BFS()) {
        for(int i=1; i<=n; i++)
            start[i] = 0;

        int rez;
        while(rez = sendflow(1, INT_MAX))
            ans += rez;
    }

    return ans;
}

int main()
{
    in >> n >> m;
    for(int i=1; i<=m; i++) {
        int x, y, c;
        in >> x >> y >> c;
        muchie m1 = {y, 0, c, g[y].size()};
        muchie m2 = {x, 0, 0, g[x].size()};
        g[x].pb(m1);
        g[y].pb(m2);
    }

    out << dinic();
    return 0;
}
