#include <bits/stdc++.h>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
const int MAX = 1e9;
struct Muchie {
    int x, y;
    int flux;
};
int n, m, nrMuchii, i, j, niv[5002], destGlob;
vector<Muchie> muchii;
vector<int> gr[5002];

static inline bool BFS(int surs, int dest) {
    memset(niv, 0, sizeof(niv));
    queue<int> q;

    q.push(surs);
    niv[surs] = 1;
    while(!q.empty()) {
        int nod = q.front();
        q.pop();

        for(int urm : gr[nod]) {
            int nodUrm = muchii[urm].y;
            if(niv[nodUrm] != 0 || muchii[urm].flux <= 0) continue;
            niv[nodUrm] = niv[nod] + 1;
            q.push(nodUrm);
        }
    }
    return (niv[dest] != 0);
}

static inline int Flux(int nod, int flMa) {
    if(flMa <= 0) return 0;
    if(nod == destGlob) return max(flMa, 0);
    int sum = 0;

    for(int urm : gr[nod]) {
        if(niv[muchii[urm].y] == niv[nod] + 1) {
            int flCur = Flux(muchii[urm].y, min(flMa, muchii[urm].flux));
            sum += flCur;
            muchii[urm    ].flux -= flCur;
            muchii[urm ^ 1].flux += flCur;
            flMa -= flCur;
        }
    }
    return sum;
}

static inline int Dinic(int surs, int dest) {
    destGlob = dest;
    int rasp = 0;
    while(BFS(surs, dest))
        rasp += Flux(surs, MAX);
    return rasp;
}

int main() {
    //ios_base::sync_with_stdio(false);
    fin.tie(nullptr);
    fout.tie(nullptr);

    fin >> n >> m;
    for(i = 1; i <= m; i++) {
        int x, y, c;
        fin >> x >> y >> c;
        gr[x].push_back(muchii.size());
        muchii.push_back(Muchie{x, y, c});
        gr[y].push_back(muchii.size());
        muchii.push_back(Muchie{y, x, 0});
    }
    fout << Dinic(1, n);

    return 0;
}
