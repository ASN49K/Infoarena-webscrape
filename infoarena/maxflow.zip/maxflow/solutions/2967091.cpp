#include <fstream>
#include <bits/stdc++.h>
using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");
int n, m, s, t;
vector <vector<int>> graf, capacitate;
vector<int> parinte;

bool bfs() {
    parinte.assign(n+1,0);
    queue<int> q;
    q.push(s);
    parinte[s] = -2;
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        if (node == n) {
            return true;
        }
        for(auto const &neighbor : graf[node]){
            int cc = capacitate[node][neighbor];
            if(parinte[neighbor] == -1 && cc > 0) {
                parinte[neighbor] = node;
                q.push(neighbor);
            }
        }
    }
    return false;
}

int max_flow() {
    int maxFlow = 0;
    while (bfs()) {
        for (auto const &node: graf[n]) {
            if (capacitate[node][n] > 0 && parinte[node] != -1) {
                int minFlow = capacitate[node][n];
                int i = node;
                while (parinte[i]) {
                    minFlow = min(minFlow, capacitate[parinte[i]][i]);
                    i = parinte[i];
                }
                i = node;
                capacitate[node][n] += minFlow;
                capacitate[n][node] -= minFlow;
                while (parinte[i]) {
                    capacitate[parinte[i]][i] += minFlow;
                    capacitate[i][parinte[i]] -= minFlow;
                    i = parinte[i];
                }
                maxFlow += minFlow;
            }
        }
    }
    return maxFlow;
}

int main() {
    f >> n >> m;
    graf.resize(n+1);
    parinte.resize(n+1);
    capacitate.resize(n+1,vector<int>(n+1,0));
    s = 1;
    t = n;
    for (int i = 0; i < m; i++) {
        int u, v, c;
        f >> u >> v >> c;
        graf[u].push_back(v);
        graf[v].push_back(u);
        capacitate[u][v] = c;
    }
    g << max_flow() << endl;
    return 0;
}

