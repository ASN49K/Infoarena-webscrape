#include <algorithm>
#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <stack>

using namespace std;

#define pii pair <int, int>

string filename = "maxflow";

#ifdef LOCAL
    ifstream fin("input.in");
    ofstream fout("output.out");
#else
    ifstream fin(filename + ".in");
    ofstream fout(filename + ".out");
#endif

const int NMAX = 1000;
const int INF = 1e9 + 1;

vector <int> adj[NMAX + 1];

int flow[NMAX + 1][NMAX + 1];

int par[NMAX + 1];
bool viz[NMAX + 1];

int n, m;

bool BFS(){
    for(int i = 1; i <= n; i++){
        par[i] = viz[i] = 0;
    }

    queue <int> Q;
    viz[1] = true;
    Q.push(1);

    while(!Q.empty()){
        int node = Q.front();
        Q.pop();

        if(node == n){
            return true;
        }

        for(int vec : adj[node]){
            if(!viz[vec] && flow[node][vec] > 0){
                viz[vec] = true;
                par[vec] = node;
                Q.push(vec);
            }
        }
    }

    return false;
}

int main(){

    fin >> n >> m;

    for(int i = 1; i <= m; i++){
        int a, b, c;
        fin >> a >> b >> c;
        adj[a].push_back(b);
        adj[b].push_back(a);
        flow[a][b] = c;
    }

    int maxFlow = 0;
    while(BFS()){
        for(int vec : adj[n]){
            if(flow[vec][n] <= 0 || !viz[vec]){
                continue;
            }

            par[n] = vec;

            int node = n, mini = INF;
            while(node != 1){
                mini = min(mini, flow[par[node]][node]);
                node = par[node];
            }

            if(mini == 0){
                continue;
            }

            node = n;
            while(node != 1){
                flow[par[node]][node] -= mini;
                flow[node][par[node]] += mini;
                node = par[node];
            }

            maxFlow += mini;
        }
    }

    fout << maxFlow << '\n';

    return 0;
}
