#include <bits/stdc++.h>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

void usain_bolt() {
  ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
}

void bfs(int n, vector<vector<int>>& flow, vector<vector<int>>& c, vector<vector<int>>& g, vector<int>& parent, vector<int>& seen) {
  queue<int> q;
  fill(seen.begin(), seen.end(), 0);
  fill(parent.begin(), parent.end(), -1);
  seen[1] = true;
  q.push(1);
  while (!q.empty()) {
    int node = q.front();
    q.pop();
    if (node == n) {
        continue;
    }
    for (auto neigh : g[node]) {
      if (seen[neigh] || flow[node][neigh] == c[node][neigh]) {
          continue;
      }
      seen[neigh] = true;
      q.push(neigh);
      parent[neigh] = node;
    }
  }

  return;
};

void solve()
{
  int n, m;
  fin >> n >> m;
  vector<vector<int>> g(n + 1);
  vector<vector<int>> c(n + 1, vector<int>(n + 1, 0));
  for (int i = 0; i < m; ++i) {
    int x, y, w;
    fin >> x >> y >> w;
    c[x][y] += w;
    g[x].emplace_back(y);
    g[y].emplace_back(x);
  }
  vector<vector<int>> flow(n + 1, vector<int>(n + 1, 0));
  vector<int> parents(n + 1);
  vector<int> seen(n + 1);
  int sol = 0;
  while (1) {
    bfs(n, flow, c, g, parents, seen);
    if (!seen[n]) {
        break;
    }
    for (auto neigh : g[n]) {
      if (flow[neigh][n] == c[neigh][n] || !seen[neigh]) {
        continue;
      }
      int cnt = c[neigh][n] - flow[neigh][n];
      int node = n;
      while (node != 1) {
        int parent = parents[node];
        cnt = min(cnt, c[parent][node] - flow[parent][node]);
        node = parent;
      }
      if (cnt == 0) {
        continue;
      }
      sol += cnt;
      node = n;
      while (node != 1) {
        int parent = parents[node];
        flow[parent][node] += cnt;
        flow[node][parent] -= cnt;
        node = parent;
      }
    }
  }
  fout << sol << '\n';

  return;
}

int main()
{
  usain_bolt();
  int tt;
  // cin >> tt;
  tt = 1;
  while (tt--) {
    solve();
  }

  return 0;
}