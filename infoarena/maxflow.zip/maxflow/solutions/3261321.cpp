#include <bits/stdc++.h>
using namespace std;

const int NMAX = 1000;
vector<int> G[NMAX + 1];
int capacitate[NMAX + 1][NMAX + 1], flux[NMAX + 1][NMAX + 1];
int n, m;

int bfs(int s, int d) {
    queue<int> q;
    int vis[NMAX + 1], p[NMAX + 1];
    for(int i = 1; i <= n; i++) {
        vis[i] = 0;
        p[i] = 0;
    }
    vis[s] = 1;
    q.push(s);
    while(!q.empty()) {
        int node = q.front();
        q.pop();
        for(auto vecin : G[node]) {
            if(!vis[vecin]) {
                if(capacitate[node][vecin] - flux[node][vecin] > 0) {
                    q.push(vecin);
                    vis[vecin] = 1;
                    p[vecin] = node;
                }
            }
        }
    }
    if(!vis[d]) {
        return -1;
    }
    vector<int> path;
    while(d != 1) {
        path.push_back(d);
        d = p[d];
    }
    reverse(path.begin(), path.end()); //nu e obligatoriu sa facem asta
    int mn = 1e9;
    for(int i = 0; i < (int)path.size() - 1; i++) {
        int x = path[i];
        int y = path[i + 1];
        mn = min(mn, capacitate[x][y] - flux[x][y]);
    }
    for(int i = 0; i < (int)path.size() - 1; i++) {
        int x = path[i];
        int y = path[i + 1];
        flux[x][y] += mn;
        flux[y][x] -= mn;
    }
    return mn;
}

int main() {
    ifstream f("maxflow.in");
    ofstream g("maxflow.out");
    f >> n >> m;
    for(int i = 1; i <= m; i++) {
        int x, y, c;
        f >> x >> y >> c;
        capacitate[x][y] = c;
        capacitate[y][x] = 0;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    int maxFlow = 0;
    while(true) {
        int flow = bfs(1, n);
        if(flow == -1) {
            break;
        }
        maxFlow += flow;
    }
    g << maxFlow;
    return 0;
}