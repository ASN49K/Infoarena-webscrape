#include <bits/stdc++.h>
using namespace std;

struct Edge {
    int to, rev;
    long long cap;
};

struct Dinic {
    int n, s, t;
    vector<vector<Edge>> g;
    vector<int> level, it;

    Dinic(int n, int s, int t) : n(n), s(s), t(t), g(n+1), level(n+1), it(n+1) {}

    void add_edge(int u, int v, long long c) {
        Edge a{v, (int)g[v].size(), c};
        Edge b{u, (int)g[u].size(), 0};
        g[u].push_back(a);
        g[v].push_back(b);
    }

    bool bfs() {
        fill(level.begin(), level.end(), -1);
        queue<int> q;
        level[s] = 0;
        q.push(s);
        while (!q.empty()) {
            int u = q.front(); q.pop();
            for (const auto &e : g[u]) {
                if (level[e.to] < 0 && e.cap > 0) {
                    level[e.to] = level[u] + 1;
                    q.push(e.to);
                }
            }
        }
        return level[t] >= 0;
    }

    long long dfs(int u, long long f) {
        if (u == t || f == 0) return f;
        for (int &i = it[u]; i < (int)g[u].size(); ++i) {
            Edge &e = g[u][i];
            if (level[e.to] == level[u] + 1 && e.cap > 0) {
                long long pushed = dfs(e.to, min(f, e.cap));
                if (pushed > 0) {
                    e.cap -= pushed;
                    g[e.to][e.rev].cap += pushed;
                    return pushed;
                }
            }
        }
        return 0;
    }

    long long maxflow() {
        long long flow = 0;
        while (bfs()) {
            fill(it.begin(), it.end(), 0);
            while (true) {
                long long pushed = dfs(s, LLONG_MAX);
                if (pushed == 0) break;
                flow += pushed;
            }
        }
        return flow;
    }
};

int main() {
    // Redirecționăm intrarea și ieșirea către fișiere
    freopen("maxflow.in", "r", stdin);
    freopen("maxflow.out", "w", stdout);

    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M;
    cin >> N >> M;
    int S = 1, T = N;

    Dinic dinic(N, S, T);
    for (int i = 0; i < M; ++i) {
        int x, y;
        long long z;
        cin >> x >> y >> z;
        dinic.add_edge(x, y, z);
    }

    cout << dinic.maxflow() << "\n";
    return 0;
}
