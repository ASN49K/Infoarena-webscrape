#include <bits/stdc++.h>
using namespace std;
ifstream in("maxflow.in");
ofstream out("maxflow.out");
vector <int> v[1005];
int t[1005];
int viz[1005];
int c[1005][1005];
int z[1005][1005];
int n, m;
queue <int> q;
int f()
{
    q.push(1);
    viz[1] = 1;
    while(!q.empty())
    {
        int x = q.front();
        q.pop();
        for(auto it:v[x])
        {
            if(viz[it] == 0 && c[x][it] != z[x][it])
            {
                q.push(it);
                viz[it] = 1;
                t[it] = x;
                if(it == n)
                {
                    while(!q.empty())
                        q.pop();
                    return 1;
                }
            }
        }
    }
    return 0;
}

int main()
{
    in >> n >> m;
    for(int i = 1; i <= m; i ++)
    {
        int a, b, cost;
        in >> a >> b >> cost;
        v[a].push_back(b);
        v[b].push_back(a);
        c[a][b] = cost;
    }
    int s = 0;
    while(f())
    {
        for(int i = 1; i <= 1000; i ++)
            viz[i] = 0;
        int mn = (1 << 30);
        for(int i = n; i != 1; i = i)
        {
            mn = min(mn, c[t[i]][i] - z[t[i]][i]);
            i = t[i];
        }
        for(int i = n; i != 1; i = i)
        {
            z[t[i]][i] += mn;
            z[i][t[i]] -= mn;
            i = t[i];
        }
        s += mn;
    }
    out << s;
    return 0;
}
