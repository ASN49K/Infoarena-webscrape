#include<bits/stdc++.h>
#define int long long
#define INF 1000000000000000000
using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");

int n,m,a[1005][1005],s,d,sol=0,tata[1005],viz[1005],mindist[1005];
vector<int>v[1005];
queue<int>q;

int bfs()
{
    int i;
    for(i=1;i<=n;i++)
        viz[i]=0,mindist[i]=INF,tata[i]=0;
    viz[s]=1;
    q.push(s);
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(auto it:v[nod])
        {
            if(viz[it]==0 && a[nod][it]>0)
            {
                viz[it]=1;
                tata[it]=nod;
                q.push(it);
                mindist[it]=min(mindist[nod],a[nod][it]);
            }
        }
    }
    if(viz[d]==1)
        return 1;
    return 0;
}

void flux()
{
    while(bfs()!=0)
    {
        for(auto it:v[d])
        {
            if(a[it][d]>0 && (tata[it]!=0 || it==s))
            {
                if(mindist[it]!=0)
                {
                    int flow=mindist[it],nr=it;
                    a[it][d]-=flow;
                    a[d][it]+=flow;
                    while(tata[nr]!=0)
                    {
                        a[tata[it]][it]-=flow;
                        a[it][tata[it]]+=flow;
                        sol+=flow;
                        nr=tata[nr];
                    }
                }
            }
        }
    }
}

signed main()
{
    int i,x,y,z;
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>x>>y>>z;
        v[x].push_back(y);
        v[y].push_back(x);
        a[x][y]=z;
        a[y][x]=0;
    }
    s=1;
    d=n;
    flux();
    g<<sol;
    return 0;
}
