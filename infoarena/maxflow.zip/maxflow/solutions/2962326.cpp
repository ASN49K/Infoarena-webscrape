/**
 * Folosim Edmonds Karp cu BFS
 *
 * La citire cream un graf orientat in care muchia dintre nod1 si nod2 reprezinta o legatura si in matricea capacitate stocam
 * capacitatea traficului, dar adaugam si legatura nod2 spre nod1 in care muchia apartine grafului rezidual.
 *
 * Pentru determinarea flowului maxim, vom aplica Edmonds Karp si vom verifica pentru fiecare pas daca putem face o parcurgere BFS.
 * Pentru fiecare parcurgere vom porni de la sink si vom identifica bottleneck-ul, urmand apoi sa actualizam capacitatea si graful rezidual.
 *
 * Rezultatul final va fi dat de flowul determinat in fiecare iteratie a algoritmului Edmonds Karp.
 *
 * Deoarece folosim Edmonds Karp cu BFS stiind de la inceput startul si sinkul, complexitatea este de O(V*E^2), unde V = nr noduri, iar E = nr muchii
 */

#include <bits/stdc++.h>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

int n, m, a, b, c, maxfl, fl, start, sink;
queue<int> q;
vector<int> graph[1001];
int tata[1001];
int capacitate[5001][5001];

bool bfs() {
    queue<int> q;
    int viz[n+1];

    for (int i = 1; i <= n; ++i) {
        q.push(start);
        tata[start] = -1;
        viz[start] = 1;


        while (!q.empty()) {
            a = q.front();
            q.pop();
            for (int vecin: graph[a]) {
                if (!viz[vecin] && capacitate[a][vecin] != 0) {
                    tata[vecin] = a;

                    if (vecin == sink)
                        return true;

                    viz[vecin] = 1;
                    q.push(vecin);
                }
            }
        }
    }

    return false;
}

void maxflow() {
    while (bfs()) {
        a = sink;
        fl = INT_MAX;

        while (a != start) {
            if (capacitate[tata[a]][a] < fl)
                fl = capacitate[tata[a]][a];

            a = tata[a];
        }

        a = sink;

        while (a != start) {
            capacitate[a][tata[a]] += fl;
            capacitate[tata[a]][a] -= fl;

            a = tata[a];
        }

        maxfl += fl;

    }
}

int main() {
    fin >> n >> m;

    start = 1;
    sink = n;

//    graph.resize(n + 1);
//    tata.resize(n + 1);

    for (int i = 0; i < m; ++i) {
        fin >> a >> b >> c;
        graph[a].push_back(b);
        graph[b].push_back(a);
        capacitate[a][b] = c;
    }

//    fin.close();

    maxflow();

    fout << maxfl;
//    fout.close();

    return 0;
}