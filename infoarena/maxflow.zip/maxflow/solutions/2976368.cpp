#include <bits/stdc++.h>
#include <fstream>
#define cin fin
#define cout fout
using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
map<pair<int,int>,int>mapp;
vector<int>G[1008],dead_ends;
int n,prag,nvl[1008];
bool dead_end[1008];
int m,i,x,ras=0,b,a,c;
void nivelare(int nod)
{
    for(i=1; i<=n; i++)
    {
        nvl[i]=0;
        dead_end[i]=0;
    }
    int maxx=0;
    queue<int>Q;
    Q.push(nod);
    nvl[nod]=1;
    while(!Q.empty())
    {
        nod=Q.front();
        Q.pop();
        for(auto i:G[nod])
        {
            if(nvl[i]==0 && mapp[ {nod,i}]>0)
            {
                nvl[i]=nvl[nod]+1;
                maxx=max(maxx,mapp[ {nod,i}]);
                Q.push(i);
            }
        }
    }
    prag=(1<<(int)(log2(maxx)));
}
int dfs(int nod,int minn)
{
    if(nod==n)
        return minn;
    for(auto i:G[nod])
    {
        if(nvl[nod]+1==nvl[i] && mapp[ {nod,i}]>=prag && dead_end[i]==0)
        {
            x=dfs(i,min(minn,mapp[{nod,i}]));
            if(x>0)
            {
                mapp[{nod,i}]-=x;
                mapp[{i,nod}]+=x;
                return x;
            }
            else
            {
                dead_end[i]=1;
                dead_ends.push_back(i);
            }
        }
    }
    return 0;
}
int main()
{
    cin>>n>>m;
    for(i=1; i<=m; i++)
    {
        cin>>a>>b>>c;
        G[a].push_back(b);
        mapp[ {a,b}]=c;
        if(mapp[ {b,a}]==0)
            G[b].push_back(a);
    }
    nivelare(1);
    while(nvl[n]!=0)
    {
        while(prag!=0)
        {
            x=dfs(1,1e9);
            if(x>0)
            {
                ras+=x;
            }
            else
            {
                prag/=2;
                for(auto i:dead_ends)
                    dead_end[i]=0;
                dead_ends.clear();
            }
        }
        nivelare(1);
    }
    cout<<ras;
    return 0;
}
