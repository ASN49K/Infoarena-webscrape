#include<cstdio>
#include<queue>
#include<cstring>
#include<vector>
#include<iostream>
#include<fstream>

using namespace std;

ifstream f("maxflow.in");
ofstream o("maxflow.out");
int c[10000][10000];
int flowPassed[10000][10000];
vector<int> g[10000];
int parList[10000];
int currentPathC[10000];

int bfs(int sNode, int eNode) {
   memset(parList, -1, sizeof(parList));
   memset(currentPathC, 0, sizeof(currentPathC));
   queue<int> q;
   q.push(sNode);
   parList[sNode] = -1;
   currentPathC[sNode] = 999;
   while(!q.empty()) {
      int currNode = q.front();
      q.pop();
      for(int i=0; i<g[currNode].size(); i++) {
         int to = g[currNode][i];
         if(parList[to] == -1) {
            if(c[currNode][to] - flowPassed[currNode][to] > 0) {
               parList[to] = currNode;
               currentPathC[to] = min(currentPathC[currNode],
               c[currNode][to] - flowPassed[currNode][to]);
               if(to == eNode) return currentPathC[eNode];
               q.push(to);
            }
         }
      }
   }
   return 0;
}
int edmondsKarp(int sNode, int eNode) {
    int maxFlow = 0;
    while(true){
      int flow = bfs(sNode, eNode);
      if (flow == 0) break;
      maxFlow += flow;
      int currNode = eNode;
      while(currNode != sNode) {
         int prevNode = parList[currNode];
         flowPassed[prevNode][currNode] += flow;
         flowPassed[currNode][prevNode] -= flow;
         currNode = prevNode;
      }
    }
    return maxFlow;
}
int main() {
   int nodCount, edCount;
   f>>nodCount>>edCount;
   int source, sink;
   source = 1;
   sink = nodCount;
   for(int ed = 0; ed < edCount; ed++) {
      int from, to, cap;
      f>>from>>to>>cap;
      c[from][to] = cap;
      g[from].push_back(to);
      g[to].push_back(from);
   }
   int maxFlow = edmondsKarp(source, sink);
   o<<maxFlow;
}
