#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <climits>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

int n, m, x, y, z, s,t;
int parent[5001];
int grafrez[5001][5001];
queue <int> q;

//retinem graful sub forma de lista de adiacenta; grafrez e pt capacitatea deja ocupata a unei muchii
vector<vector<int>> graf;


void read(){

    fin>>n>>m;

    graf.resize(n+1);

    for(int i=1; i<=m; i++)
    {
        fin >> x >> y >> z;
        graf[x].push_back(y);
        graf[y].push_back(x);
        grafrez[x][y]= z;
    }

    s=1;
    t=n;
}

int bfs()
{
    queue <int> q;
    int vizitat[n+1];

    for (int i=1; i<=n; i++)
        vizitat[i] = 0;

    q.push(s);
    vizitat[s] = 1;
    parent[s] = -1;

    // bfs

    while (!q.empty())
    {
        auto nod = q.front();
        q.pop();

        for (int i=1; i<=n; i++)
        {
            if (vizitat[i]==0 and graf[nod][i] != 0)
            {
                parent[i] = nod; //retinem drumul in vectorul parent
                if (t == nod) return true;

                vizitat[i]=1;
                q.push(i);
            }
        }
    }
    return false;
}


void ffluxmax()
{
    int fluxmax = 0;
    while (bfs())
    { //cat timp mai exista drumuri
        int nod, i=t, flux = INT_MAX;

            //pornesc de la ultimul nod
            while(i!=s)
            {
                nod = parent[i];

                if(grafrez[nod][i] < flux)
                    flux = grafrez[nod][i];

                i = parent[i];
            }

            i = t;

            while(i != s)
            {
                nod= parent[i];
                grafrez[nod][i] -= flux;
                grafrez[nod][i] += flux;
                i = parent[i];
            }

                fluxmax += flux;

        }

    fout << fluxmax;
}

int main()
{
    read();
    ffluxmax();
    fin.close();
    fout.close();
    return 0;
}