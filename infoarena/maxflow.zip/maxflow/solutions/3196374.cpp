#include <iostream>
#include <fstream>
#include <queue>
#include <cstring>
#include <utility>
#include <vector>
using namespace std;
ifstream in("date.in");

vector<int>ls[101],ls1[101];
int c[101][101], f[101][101];
int tata[101],viz[101];

int bfs_lant(int s, int t) {
	memset(tata, 0, sizeof tata);
	tata[s] = -1;
	queue<pair<int, int>>q;
	q.push({ s,9999999 });
	while (!q.empty()) {
		int x = q.front().first;
		int flux = q.front().second;
		for (auto y : ls[x]) {
			if (tata[y] == 0 && (c[x][y] - f[x][y]) > 0) {
				tata[y] = x;
				int flux_nou = min(flux, c[x][y] - f[x][y]);
				if (y == t) {
					return flux_nou;
				}
				q.push({ y,flux_nou });
			}
		}

		q.pop();
	}

	return -1;
}

int edmondsKarp(int s, int t) {
	int total = 0;
	while (true) {
		int flux_nou = bfs_lant(s, t);
		if (flux_nou == -1)
			break;
		int nod = t;
		total += flux_nou;
		while (nod != s) {
			f[tata[nod]][nod] += flux_nou;
			f[nod][tata[nod]] -= flux_nou;
			nod = tata[nod];
		}
	}
	return total;
}
int bfs(int s,int t,int k) {
	queue<int>q;
	viz[s] = 1;
	q.push(s);
	while (!q.empty()) {
		int x = q.front();
		q.pop();
		for (auto y : ls1[x]) {
			if (viz[y] == 0 && c[x][y] >= k)
			{
				viz[y] = 1;
				q.push(y);
			}
		}
	}

	return viz[t];
}


int main() {
	int n, m,capMax=0;
	in >> n >> m;
	for (int i = 1; i <= n; i++) {
		int grad;
		int a, capacitate;
		in >> grad;
		while (grad--) {
			in >> a >> capacitate;
			if (capacitate > capMax)
				capMax = capacitate;
			ls[i].push_back(a);
			ls1[i].push_back(a);
			ls[a].push_back(i);
			c[i][a] = capacitate;
			c[a][i] = capacitate;
			f[i][a] = 0;
			f[a][i] = capacitate;
		}
	}
	int s, t,k;
	in >> s >> t;
	int fluxMax = edmondsKarp(s, t);
	cout << fluxMax;
	for (int i = fluxMax; i >= 0; i--) {
		int nr_div = 2;
		for (int j = 2; j <= i / 2; j++) {
			if (i % j == 0) {
				nr_div++;
			}
		}
		if (nr_div == 2)
		{
			k = i;
			cout << i << "\n";
			break;
		}
	}
	int l = bfs(s, t, k);
	if (l) {
		cout << "Nu";

	}
	else {
		cout << "Da";
	}
}