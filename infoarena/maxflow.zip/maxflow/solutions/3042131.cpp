#include <bits/stdc++.h>

#define NMAX 1024

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

vector <int> G[NMAX];
map <pair <int, int>, int> capacity;

int n;

int level[NMAX];
bool used[NMAX], dead_end[NMAX];

void Leveling() {
    queue <int> Q;

    for(int i = 1; i <= n; i ++) dead_end[i] = false, used[i] = false;
    level[1] = 0;
    used[1] = true;
    Q.push(1);

    while(!Q.empty()) {
        int node = Q.front();used[node] = true;
        Q.pop();

        for(auto x : G[node])
            if(!used[x] && capacity[{node, x}]) {
                level[x] = level[node] + 1;
                
                Q.push(x);
            }
    }
}

int DFS(int node, int minimumflow) {
    if(node == n) return minimumflow;

    for(auto x : G[node])
        if(!dead_end[x] && level[x] == level[node] + 1 && capacity[{node, x}]) {
            int newflow = DFS(x, min(minimumflow, capacity[{node, x}]));
            if(newflow > 0) {
                capacity[{node, x}] -= newflow;
                capacity[{x, node}] += newflow;
                return newflow;
            } else dead_end[x] = true;
        }

    return 0;
}

int main() {
    int m; fin >> n >> m;
    for(int i = 1; i <= m; i ++) {
        int x, y, cost; fin >> x >> y >> cost;
        G[x].push_back(y);
        capacity[{x, y}] = cost;
        if(!capacity[{y, x}]) G[y].push_back(x);
    }

    int maxflow = 0;

    Leveling();
    while(1) {
        bool found = false;
        int newflow = 1;
        while(newflow) {
            // for(int i = 1; i <= n; i ++) used[i] = false;
            newflow = DFS(1, INT_MAX);

            if(newflow) found = true;
            maxflow += newflow;
        }
        if(!found) break;
        Leveling();
    }

    fout << maxflow << '\n';

    return 0;
}