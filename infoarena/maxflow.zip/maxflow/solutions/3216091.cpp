#include <bits/stdc++.h>
#define pii pair<int, int>
#define ff first
#define ss second
#define vi vector<int>
#define vvi vector<vi>
#define pb push_back
#define eb emplace_back


using namespace std;
const string TASK("maxflow");
ifstream fin(TASK + ".in");
ofstream fout(TASK + ".out");
#define cin fin
#define cout fout

const int N = 1009;

int n, m;
vvi G(N);

struct edge
{
    int from, to, capacity, flow;

    edge(int from = 0, int to = 0, int capacity = 0, int flow = 0) :
        from(from), to(to), capacity(capacity), flow(flow) {}
};
vector<edge> edges;

void add_edge(int x, int y, int c)
{
    G[x].pb(edges.size());
    edges.pb({x, y, c, 0});
    G[y].pb(edges.size());
    edges.pb({y, x, 0, 0});
}

bitset<N> viz;
queue<int> q;
int t[N];
bool Bfs(int src, int dst)
{
    viz.reset();
    t[src] = -1;
    viz[src] = true;
    q.push(src);

    while(!q.empty())
    {
        int x = q.front();
        q.pop();

        if(x == dst)return true;

        for(auto id : G[x])
        {
            auto e = edges[id];
            if(!viz[e.to] && e.capacity - e.flow > 0)
            {
                viz[e.to] = true;
                t[e.to] = id;
                q.push(e.to);
            }
        }
    }

    return false;
}

int Augment(int src, int dst)
{
    int mflow = INT_MAX;

    for(int i = t[dst]; i != -1; i = t[edges[i].from])
        mflow = min(mflow, edges[i].capacity - edges[i].flow);

    for(int i = t[dst]; i != -1; i = t[edges[i].from])
    {
        edges[i].flow += mflow;
        edges[i ^ 1].flow -= mflow;
    }

    return mflow;
}

int MaxFlow(int src, int dst)
{
    int ret = 0;
    for(; Bfs(src, dst); ret += Augment(src, dst));
    return ret;
}

int main()
{
    ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);

    cin >> n >> m;

    int x, y, c;
    for(int i = 1; i <= m; ++i)
    {
        cin >> x >> y >> c;
        add_edge(x, y, c);
    }

    cout << MaxFlow(1, n) << '\n';
    return 0;
}
