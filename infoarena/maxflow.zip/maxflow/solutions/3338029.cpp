#include <bits/stdc++.h>
using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

int i,start=1,finish,n,m,ras,niv[1010],fr[1010],mat[1010][1010],a,b,c,x;
vector <int> v[1010];
queue <int> q;
void bfs(int nod)
{
    for(i=1; i<=n; i++)
    {
        niv[i]=-1;
        fr[i]=0;
    }
    niv[start]=0;
    q.push(nod);
    while(!q.empty())
    {
        int p=q.front();
        q.pop();
        for(auto it : v[p])
        {
            if(niv[it]==-1 && mat[p][it]>0)
            {
                niv[it]=niv[p]+1;
                q.push(it);
            }
        }
    }
}

int dfs(int nod,int mini)
{
    if(nod==finish || mini==0)
        return mini;
    while(fr[nod]<v[nod].size())
    {
        int p=v[nod][fr[nod]];
        if(mat[nod][p]>0 && niv[p]==niv[nod]+1)
        {
            int x=dfs(p,min(mini,mat[nod][p]));
            if(x>0)
            {
                mat[nod][p]-=x;
                mat[p][nod]+=x;
                return x;
            }
            else
                fr[nod]++;
        }
        else
            fr[nod]++;
    }
    return 0;
}

bool flux(int nod)
{
    bfs(nod);
    if(niv[finish]==-1)
        return 0;
    int val=0;
    while(1)
    {
        x=dfs(start,1e9);
        if(x==0)
            break;
        val+=x;
    }
    ras+=val;
    return (val!=0);
}

int main()
{
    fin>>n>>m;
    finish=n;
    for(i=1; i<=m; i++)
    {
        fin>>a>>b>>c;
        v[a].push_back(b);
        v[b].push_back(a);
        mat[a][b]=c;
    }
    while(flux(start));
    fout<<ras;
    return 0;
}
