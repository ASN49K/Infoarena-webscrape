#include <bits/stdc++.h>
using namespace std;
const int N = 1e3 + 1;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
#define cin fin
#define cout fout
int n, m;
vector<int> liste[N];
int c[N][N], f[N][N];
vector<int> t(N);
int bfs(){
    queue<int> q;
    
    q.push(1);
    t.assign(n + 1, -1);
    while(q.size()){
        int nod = q.front();
        q.pop();
        if(nod == n) continue;
        for(auto i : liste[nod]){
            if(t[i] == -1 && f[nod][i] < c[nod][i]){
                t[i] = nod;
                q.push(i);
            }
        }
    }
    if(t[n] < 0) return 0;
    return 1;
}
int maxflow(){
    int maxfloww = 0;
    while(bfs()){
        for(auto i : liste[n]){
           if(f[i][n] == c[i][n] || t[i] == -1) continue;
           t[n] = i;
           int minim = 1e9;
            for(int j = n; j != 1; j = t[j]){
                minim = min(minim, c[t[j]][j] - f[t[j]][j]);
            }
            for(int j = n; j != 1; j = t[j]){
                f[t[j]][j] += minim;
                f[j][t[j]] -= minim;
            }
            maxfloww += minim;
        }
    }
    return maxfloww;
}
int main(){
    cin.tie(0)->sync_with_stdio(0);
    cin >> n >> m;
    for(int i = 1; i <= m; i++){
        int u, v, ca;
        cin >> u >> v;
        liste[u].push_back(v);
        liste[v].push_back(u);
        c[u][v] = ca;
        c[v][u] = 0;
    }
    cout << maxflow();
}