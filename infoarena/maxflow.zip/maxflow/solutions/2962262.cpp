#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream in("maxflow.in");
ofstream out("maxflow.out");

vector<int> tata;
vector<vector<int>> adj, c;
int n;

bool bfs(int src, int dest){
    queue<int> coada;
    vector<bool> viz(n+1);

    coada.push(src);
    viz[src] = true;
    tata[src] = -1;

    while(!coada.empty()){
        int nod = coada.front();
        coada.pop();
        for(auto vec: adj[nod]){
            if(c[nod][vec] > 0 && !viz[vec]){
                tata[vec] = nod;
                if(vec == dest)
                    return true;
                viz[vec] = true;
                coada.push(vec);
            }
        }
    }

    return false;
}

int main()
{
    int m, x, y, z;
    in >> n >> m;
    adj.resize(n+1);
    c.resize(n+1, vector<int>(n+1));
    while(m--){
        in >> x >> y >> z;
        c[x][y] = z;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }
    tata.resize(n+1);
    int src = 1;
    long long cap_max = 0;
    while(bfs(src, n)){
        int nod = n;
        int cap = c[tata[nod]][nod];
        while(nod != src){
            cap = min(cap, c[tata[nod]][nod]);
            nod = tata[nod];
        }

        nod = n;
        while(nod != src){
            c[tata[nod]][nod] -= cap;
            c[nod][tata[nod]] += cap;
            nod = tata[nod];
        }

        cap_max += cap;
    }

    out << cap_max;

    return 0;
}
