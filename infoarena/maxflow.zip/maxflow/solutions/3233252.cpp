#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
#include <fstream>
#include <algorithm>

using namespace std;

const int MAXN = 1005; // Numărul maxim de noduri
const int INF = 1000000000; // O valoare mare pentru a reprezenta infinitul

int capacity[MAXN][MAXN]; // Capacitatea muchiilor
vector<int> adj[MAXN]; // Lista de adiacență
int parent[MAXN]; // Vector pentru a ține evidența părinților în timpul BFS

// Funcția BFS pentru a găsi un drum augmentant
bool bfs(int s, int t) {
    fill(parent, parent + MAXN, -1);
    parent[s] = s;
    queue<pair<int, int>> q;
    q.push({s, INF});

    while (!q.empty()) {
        int cur = q.front().first;
        int flow = q.front().second;
        q.pop();

        for (int next : adj[cur]) {
            if (parent[next] == -1 && capacity[cur][next] > 0) { // Dacă nodul next nu a fost vizitat și capacitatea nu este zero
                parent[next] = cur;
                int new_flow = min(flow, capacity[cur][next]);
                if (next == t) {
                    return true;
                }
                q.push({next, new_flow});
            }
        }
    }

    return false;
}

// Funcția pentru a calcula fluxul maxim folosind algoritmul Edmonds-Karp
int edmondsKarp(int s, int t) {
    int flow = 0;

    while (bfs(s, t)) {
        int cur = t;
        int bottleneck = INF;
        while (cur != s) {
            int prev = parent[cur];
            bottleneck = min(bottleneck, capacity[prev][cur]);
            cur = prev;
        }

        flow += bottleneck;
        cur = t;
        while (cur != s) {
            int prev = parent[cur];
            capacity[prev][cur] -= bottleneck;
            capacity[cur][prev] += bottleneck;
            cur = prev;
        }
    }

    return flow;
}

int main() {
    ifstream infile("maxflow.in");
    ofstream outfile("maxflow.out");

    int N, M;
    infile >> N >> M;

    for (int i = 0; i < M; ++i) {
        int u, v, c;
        infile >> u >> v >> c;
        adj[u].push_back(v);
        adj[v].push_back(u);
        capacity[u][v] += c;
    }

    int source = 1, sink = N; // Nodul sursă și nodul destinație
    int maxFlow = edmondsKarp(source, sink);
    outfile << maxFlow << endl;

    infile.close();
    outfile.close();

    return 0;
}
