#include <bits/stdc++.h>
using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");
#define cout g
bitset<1000>viz;
const int INF = 1e9;
int n, m;
vector<vector<int>> capacity; //matrix de capacitate valabila
vector<vector<pair<int,int>>> v;

int bfs(int src, int fin, vector<int>&papa)
{
    fill(papa.begin(), papa.end(), -1);
    queue<pair<int,int>> q;
    q.push({src, INF});
    while(!q.empty())
    {
        int nod,fl;
        tie(nod,fl)=q.front();
        q.pop();

        for(auto vc : v[nod])
        {
            if(papa[vc.first]==-1 && capacity[nod][vc.first]>0)
            {
                papa[vc.first]=nod;
                int new_f = min(fl, capacity[nod][vc.first]);
                if(vc.first == fin)
                    return new_f;
                q.push({vc.first,new_f});
            }
        }
    }
    return 0;
}

int maxFlow(int src, int fin)
{
    int tf = 0;
    vector<int> papa(n+1);

    while(int new_f = bfs(src,fin,papa))
    {
        //pentru fiecare flux nou gasit adaugam la total
        tf+=new_f;
        int cur = fin;
        while(cur!=src)
        {
            int t = papa[cur];
            capacity[t][cur]-=new_f;
            capacity[cur][t]+=new_f;
            cur=t;
        }
    }
    return tf;
}

int main()
{
    //algoritmul se bazeaza pe algoritmul bfs cu plecare din nodul de intrare la
    //fiecare pas al BFS-ului marcandu-se pentru nodul curent tatal lui
    //dupa se face parcurgerea inapoi pe vectorii de tati, si determinam capacitatea
    //minima, si scadem din capacitatea nodurilor prin care am trecut minimul.
    //facem acest lucru pana nu mai gasim un drum in care minimul diferit de 0
    f >> n >> m;
    v.assign(n+1, vector<pair<int,int>>());
    capacity.assign(n+1, vector<int>(n+1,0));
    queue<int> q;
    vector<int> p(n+1);
    for(int i=1; i<=m; i++)
    {
        int x,y,c;
        f >> x >> y >> c;
        v[x].push_back({y,c});
        v[y].push_back({x,0});
        capacity[x][y]+=c;
    }
    int src = 1, fin = n;
    cout << maxFlow(src,fin) << '\n';
    return 0;
}
