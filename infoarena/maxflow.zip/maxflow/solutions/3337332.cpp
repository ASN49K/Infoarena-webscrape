#include<bits/stdc++.h>
#define M 5000
using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

int n, m;
vector<pair<int,int>> g[1005];
int dp[1005];
int c[2 * M + 1];
vector<pair<int,int>> t(1005);
queue<int> q;

bool bfs(int sursa, int dest)
{
    for(int i = 1; i <= n; i++)
        t[i] = {0, 0}, dp[i] = 0;
    q.push(sursa);
    dp[sursa] = 1e9;
    while(!q.empty())
    {
        int nod = q.front();
        q.pop();
        for(auto [y, pos] : g[nod])
        {
            if(dp[y] == 0 && c[pos])
            {
                t[y] = {nod, pos};
                dp[y] = min(c[pos], dp[nod]);
                q.push(y);
            }
        }
    }
    return dp[dest];
}

void add_flux(int flux, int sursa, int dest)
{
    int nod = dest;
    while(nod != sursa)
    {
        c[t[nod].second] -= flux;
        c[t[nod].second ^ 1] += flux;
        nod = t[nod].first;
    }
}

int main()
{
    int x, y, cap;
    fin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        fin >> x >> y >> cap;
        g[x].push_back({y, 2 * i});
        g[y].push_back({x, 2 * i + 1});
        c[2 * i] = cap; c[2 * i + 1] = 0;
    }
    int sursa = 1, dest = n;
    int sol = 0;
    while(bfs(sursa, dest))
    {
        int flux = dp[n];
        add_flux(flux, sursa, dest);
        sol += flux;
    }
    fout << sol;
    return 0;
}