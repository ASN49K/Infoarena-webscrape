#include <bits/stdc++.h>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

int n, m, c[1024][1024], f[1024][1024], t[1024], v[1024];
vector<int> g[1024];

int bfs() {
    for(int i = 1; i <= n; i++) v[i] = 0;

    queue<int> q;
    q.push(1);
    v[1] = 1;
    while(!q.empty()) {
        int x = q.front();
        q.pop();


        for(int next: g[x]) {
            if(!v[next] && c[x][next] > f[x][next]) {
                t[next] = x;
                v[next] = 1;
                if(next == n) return 1;
                q.push(next);
            }
        }
    }
    return 0;
}

int main() {
    fin >> n >> m;
    while(m--) {
        int x, y, z;
        fin >> x >> y >> z;
        g[x].push_back(y);
        g[y].push_back(x);
        c[x][y] = z;
    }

    int ans = 0, curr;
    while(bfs()) {
        for(int next: g[n]) {
            if(!v[next] || c[next][n] <= f[next][n]) continue;
            t[n] = next;

            curr = 2e9;
            for(int i = n; i != 1; i = t[i]) {
                curr = min(curr, c[t[i]][i] - f[t[i]][i]);
            }
            for(int i = n; i != 1; i = t[i]) {
                f[t[i]][i] += curr;
                c[t[i]][i] -= curr;
            }
            ans += curr;
        }
    }

    fout << ans << '\n';
}