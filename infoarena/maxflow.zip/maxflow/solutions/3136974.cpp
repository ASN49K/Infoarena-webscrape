#include <bits/stdc++.h>
using namespace std;

struct Edmonds_Karp{
    struct Edge{
        int from, to, cap, ult;
    };
    vector <Edge> edges;
    vector <int> dist, last;
    queue <int> coada;
    int n;
    Edmonds_Karp(int n){
        last.assign(n + 1, -1);
        this->n = n;
    }
    void baga(int from, int to, int cap){
        edges.push_back({from, to, cap, last[from]});
        last[from] = edges.size() - 1;
        edges.push_back({to, from, 0, last[to]});
        last[to] = edges.size() - 1;
    }
    bool bfs(int s, int t)
    {
        dist.assign(n + 1, 1e9);
        dist[s] = 0;
        coada.push(s);
        while(coada.size())
        {
            int x = coada.front();
            coada.pop();
            for(int y = last[x]; y != -1; y = edges[y].ult)
                if(edges[y].cap > 0 && dist[edges[y].to] == 1e9)
                {
                    dist[edges[y].to] = dist[x] + 1;
                    coada.push(edges[y].to);
                }
        }
        return (dist[t] != 1e9);
    }
    int dfs(int s, int t, int flux)
    {
        if(s == t)
            return flux;
        int rez = 0;
        for(int y = last[s]; y != -1; y = edges[y].ult)
            if(edges[y].cap > 0 && dist[edges[y].to] == dist[s] + 1)
            {
                int trimis = dfs(edges[y].to, t, min(flux, edges[y].cap));
                rez += trimis;
                flux -= trimis;
                edges[y].cap -= trimis;
                edges[y ^ 1].cap += trimis;
            }
        return rez;
    }
    int fluxmax(int s, int t)
    {
        int rez = 0;
        while(bfs(s, t))
            rez += dfs(s, t, 1e9);
        return rez;
    }
};

int main()
{
    freopen("maxflow.in", "r", stdin);
    freopen("maxflow.out", "w", stdout);
    int n, m, from, to, cap;
    cin >> n >> m;
    Edmonds_Karp g(n);
    for(int i = 1; i <= m; i++)
    {
        cin >> from >> to >> cap;
        g.baga(from, to, cap);
    }
    cout << g.fluxmax(1, n);
    return 0;
}
