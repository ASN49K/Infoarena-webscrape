#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
queue<int>q;
vector<vector<int>>flux,gr,capacitate;
vector<int>tata;

int n,m,nod1,nod2,cap,S,T,rasp=0;
const int inf=1e9;

int bfs(){
    int val=0;

    for(int i=1;i<=n;i++){
        tata[i]=0;
    }
    tata[S]=S;
    q.push(S);

    while(!q.empty()){

        int nod_curent=q.front();
        q.pop();

        if(nod_curent==T){
   
            continue;
        }
        for(auto&vecin:gr[nod_curent]){

            if(!tata[vecin] && capacitate[nod_curent][vecin]-flux[nod_curent][vecin]>0){
                tata[vecin]=nod_curent;
                q.push(vecin);
            }
        }
    }

       
        for(auto& vecin:gr[T]){

             if(!tata[vecin]){
                continue;
             }
             tata[T]=vecin;
             int nod_curent=T;
             int minn=inf;

             while(nod_curent!=S){
                minn=min(minn,capacitate[tata[nod_curent]][nod_curent]-flux[tata[nod_curent]][nod_curent]);
                nod_curent=tata[nod_curent];
             }
             nod_curent=T;

             while(nod_curent!=S){
                flux[tata[nod_curent]][nod_curent]+=minn;
                flux[nod_curent][tata[nod_curent]]-=minn;
                nod_curent=tata[nod_curent];
             }
             val+=minn;
        }        

    return val;
}
int main(){

    cin>>n>>m;

    S=1;
    T=n;

    gr.resize(n+1);
    tata.resize(n+1,0);
    capacitate.resize(n+1,vector<int>(n+1));
    flux.resize(n+1,vector<int>(n+1));

    for(int i=1;i<=m;i++){
        cin>>nod1>>nod2>>cap;

        gr[nod1].push_back(nod2);
        gr[nod2].push_back(nod1);
        capacitate[nod1][nod2]=cap;
    }

    int flx;

    bool ok=true;
    while(ok){
        flx=bfs();
        if(flx==0){
            ok=false;
        }
        rasp+=flx;
    }
    cout<<rasp;
    return 0;
}
