#include <bits/stdc++.h>
using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
const int NMAX = 1001, INF = 1e9;
int n, m;

struct Flow
{
    struct edge { int u, v, capacity, flow; };
    vector<edge> edges;
    vector<int> adj[NMAX];
    int level[NMAX];
    bool blocked[NMAX];

    void add_edge(int u, int v, int capacity)
    {
        edges.push_back({u, v, capacity, 0});
        adj[u].push_back(edges.size() - 1);
        edges.push_back({v, u, 0, 0});
        adj[v].push_back(edges.size() - 1);
    }

    bool bfs(int sursa, int dest)
    {
        fill(level, level + NMAX, INF);
        level[sursa] = 0;
        queue<int> q;
        q.push(sursa);
        while(!q.empty())
        {
            int node = q.front();
            q.pop();
            for(int idx : adj[node])
            {
                auto &muchie = edges[idx];
                if(muchie.flow < muchie.capacity && level[muchie.v] == INF)
                {
                    level[muchie.v] = level[node] + 1;
                    q.push(muchie.v);
                }
            }
        }
        return (level[dest] != INF);
    }

    int dfs(int sursa, int dest, int flow)
    {
        if(sursa == dest)
            return flow;
        int total_pushed = 0;
        bool all_blocked = true;
        for(int idx : adj[sursa])
        {
            auto &muchie = edges[idx];
            if(muchie.flow < muchie.capacity && level[muchie.v] == level[sursa] + 1 && !blocked[muchie.v])
            {
                int pushed = dfs(muchie.v, dest, min(flow, muchie.capacity - muchie.flow));
                if(pushed > 0)
                {
                    muchie.flow += pushed;
                    edges[idx ^ 1].flow -= pushed;
                    total_pushed += pushed;
                    all_blocked = false;
                    flow -= pushed;
                    if(flow == 0)
                        break;
                }
            }
        }
        if(all_blocked || total_pushed == 0)
            blocked[sursa] = true;
        return total_pushed;
    }

    int push_flow(int sursa, int dest)
    {
        int flow = 0;
        while(bfs(sursa, dest))
        {
            memset(blocked, false, sizeof(blocked));
            flow += dfs(sursa, dest, INF);
        }
        return flow;
    }
};
Flow flow;

int main()
{
    fin >> n >> m;
    while(m--)
    {
        int u, v, capacity;
        fin >> u >> v >> capacity;
        flow.add_edge(u, v, capacity);
    }
    fout << flow.push_flow(1, n);

    fin.close();
    fout.close();
    return 0;
}
