#include <bits/stdc++.h>

using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

vector<vector<int>> adj;
int cap[1001][1001], tata[1001], n, m, s = 1, t;

bool bfs()
{
    queue <int> q;
    vector <bool> vizitat(n + 1, false);

    q.push(s);
    vizitat[s] = true;

    while(!q.empty())
    {
        int nod = q.front();
        q.pop();
        for(auto vecin : adj[nod])
        {
            if(!vizitat[vecin] && cap[nod][vecin] != 0)
            {
                tata[vecin] = nod;
                if(vecin == t)
                    return true;

                vizitat[vecin] = true;
                q.push(vecin);
            }
        }
    }
    return false;
}

int maxflow() //Edmonds Karp
{
    int maxim = 0;
    while (bfs())
    {
        int b, a = t, flow = INT_MAX;
        while(a != s)
        {
            b = tata[a];

            if(cap[b][a] < flow)
                flow = cap[b][a];

            a = b;
        }

        a = t;
        while(a != s)
        {
            b = tata[a];
            cap[b][a] -= flow;
            cap[a][b] += flow;
            a = b;
        }

        maxim += flow;
    }

    return maxim;
}

int main()
{
    int a, b, c, i;

    tata[s] = -1;

    f >> n >> m;
    t = n;  //sink
    adj.resize(n+1);

    for(i = 0; i < m; i++)
    {
        f >> a >> b >> c;
        adj[a].push_back(b);
        adj[b].push_back(a);
        cap[a][b] = c;
    }
    g << maxflow();

    return 0;
}