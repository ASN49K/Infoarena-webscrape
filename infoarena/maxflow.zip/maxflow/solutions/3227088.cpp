#include <bits/stdc++.h>
using namespace std;

///----------TOGGLES
#define FIO
#define LONGER
//#define TESTS

///---------

#ifdef LONGER
    #define int long long
#endif // LONGER

#ifdef FIO
    const string fname="maxflow";
    ifstream in(fname+".in");
    ofstream out(fname+".out");
    #define cin in
    #define cout out
#endif // FIO

///--------

#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

///-------STL++-----
#define all(x) x.begin(), x.end()
#define rall(x) x.rbegin(), x.rend()
#define sz(x) x.size()
#define pb(x,y) x.push_back(y)
#define mp(x,y) make_pair(x,y)
#define fr(i,n) for(int i=1;i<=n;i++)
using ll = long long;
using ld = long double;
using pii = pair<int,int>;
using pdd = pair<double, double>;
using veci = vector<int>;
using vecp = vector<pii>;
template<typename T> using PQ = priority_queue<T, vector<T>, greater<T> >;

///-----CODE GOES HERE-----

const int maxn = 1005;
const int maxval = 1e9+7;

int n,m;
veci fg[maxn];
int cap[maxn][maxn];
int vis[maxn], tata[maxn];
int s,f;

int fluxBfs()
{
    fill(vis+1, vis+n+1, 0);
    fill(tata+1, tata+n+1, -1);

    vis[s]=1;
    queue<int> q;
    q.push(s);
    while(!q.empty())
    {
        int t=q.front();
        q.pop();
        for(auto e:fg[t])
        {
            if(cap[t][e]<=0) continue;
            if(vis[e]) continue;
            vis[e]=1;
            tata[e]=t;
            q.push(e);
        }
    }

    if(tata[f]==-1) return 0;

    int add=maxval;
    int j=f;
    while(j!=s)
    {
        add=min(add, cap[tata[j]][j]);
        j=tata[j];
    }

    j=f;
    while(j!=s)
    {
        cap[tata[j]][j]-=add;
        cap[j][tata[j]]+=add;
        j=tata[j];
    }

    return add;
}

int doFlux()
{
    int ans=0, oldans=-1;
    while(ans!=oldans) oldans=ans, ans+=fluxBfs();
    return ans;
}


void solve()
{
    {
        cin>>n>>m;
        int a,b,c;
        for(int i=1;i<=m;i++)
        {
            cin>>a>>b>>c;
            pb(fg[a],b);
            pb(fg[b],a);
            cap[a][b]=c;
        }
        s=1;
        f=n;
    }

    cout<<doFlux()<<'\n';
}

///---MAIN FUNC-------

int32_t main()
{
    IOS;
    int t=1;
    #ifdef TESTS
        cin>>t;
    #endif // TESTS
    while(t--)
    {
        solve();
    }
    return 0;
}
