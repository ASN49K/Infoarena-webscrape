#include <bits/stdc++.h>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
int SURS, DEST;   /// as fi facut const

vector<int> gr[1002];

int n, m, i, tata[1002], fluxMax;

int cap[1002][1002];
int flux[1002][1002];

static inline bool Bfs(int start = SURS) {
    memset(tata, 0, sizeof(tata));

    queue<int> q;
    q.push(start);

    tata[start] = -1;

    bool ok = false;
    while(!q.empty()) {
        int nod = q.front();
        q.pop();

        for(int urm : gr[nod]) {
            if(tata[urm] == 0 && cap[nod][urm] > flux[nod][urm])

            if(urm != DEST) {
                tata[urm] = nod;
                q.push(urm);
            }
            else ok = true;
        }
    }

    return ok;
}

static inline void Dinic() {
    bool bfs = Bfs();

    while(bfs) {
        for(int ant : gr[DEST]) {
            if(tata[ant] && cap[ant][DEST] > flux[ant][DEST]) {
                tata[DEST] = ant;

                int mi = INT_MAX;

                int nod = DEST;
                while(nod != SURS) {
                    mi = min(mi, cap[tata[nod]][nod] - flux[tata[nod]][nod]);
                    nod = tata[nod];
                }

                if(mi < 0) continue;

                fluxMax += mi;

                nod = DEST;
                while(nod != SURS) {
                    flux[tata[nod]][nod] += mi;
                    flux[nod][tata[nod]] -= mi;

                    nod = tata[nod];
                }
            }
        }

        bfs = Bfs();
    }
}

int main() {
    fin >> n >> m;
    for(i = 1; i <= m; i++) {
        int x, y;
        fin >> x >> y;
        fin >> cap[x][y];
        gr[x].push_back(y);
        gr[y].push_back(x);
    }

    SURS = 1;
    DEST = n;

    Dinic();

    fout << fluxMax;

    return 0;
}
