#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
const int N=1001;
vector<short>adj[N];
int n,m,capacitate[N][N];
void citeste()
{
    cin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b,flux;
        cin>>a>>b>>flux;
        if(capacitate[a][b]==0)
        {
            adj[a].push_back(b);
            adj[b].push_back(a);
        }
        capacitate[a][b]+=flux;
    }
}
int parent[N];
void init()
{
    for(int i=1;i<=n;i++)
        parent[i]=0;
        parent[1]=-1;
}
bool bfs()
{
    queue<int>q;
    init();
    q.push(1);
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(auto u:adj[nod])
        {
            if(parent[u]==0&&capacitate[nod][u])
            {
                parent[u]=nod;
                if(u!=n)
                    q.push(u);
            }
        }
    }
    return bool(parent[n]!=0);
}
void find_flow()
{
    int max_flow=0;
    while(bfs())
    {
        for(auto u:adj[n])
        {
            int fmin=1e9;
            int act=u;
            if(capacitate[u][n]==0)
                continue;
            fmin=min(fmin,capacitate[u][n]);
            while(act!=1&&act!=0)
            {
                fmin=min(fmin,capacitate[parent[act]][act]);
                act=parent[act];
            }
            if(fmin==0)
                continue;
            act=u;
            capacitate[u][n]-=fmin;
            while(act!=1)
            {
                capacitate[parent[act]][act]-=fmin;
                capacitate[act][parent[act]]+=fmin;
                act=parent[act];
            }
            max_flow+=fmin;
        }
    }
    cout<<max_flow;
}
int main()
{
    citeste();
    find_flow();
    return 0;
}
