#include <bits/stdc++.h>

using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

int n,m,x,y,z,c[1200][1200],viz[1200],flow[1200][1200],tata[1200],rez;
queue <int> q;
vector <int> edges[1200];

bool bfs()
{
    memset(viz,0,sizeof(viz));
    while(!q.empty())
        q.pop();
    viz[1]=1, q.push(1);
    while(!q.empty())
    {
        int x=q.front();
        q.pop();
        if(x!=n)
        {
            for(auto y:edges[x])
                if(viz[y]==0 and flow[x][y]!=c[x][y])
                    tata[y]=x, viz[y]=1, q.push(y);
        }
    }
    return viz[n];
}

int main()
{
    f>>n>>m;
    for(int i=1; i<=m; i++)
        f>>x>>y>>z, edges[x].push_back(y), edges[y].push_back(x), c[x][y]=z;
    while(bfs())
    {
        for(auto y:edges[n])
            if(flow[y][n]!=c[y][n] and viz[y]==1)
            {
                tata[n]=y;
                int minim=INT_MAX;
                for(int x=n; x!=1; x=tata[x])
                    minim=min(minim,c[tata[x]][x]-flow[tata[x]][x]);
                for(int x=n; x!=1; x=tata[x])
                    flow[tata[x]][x]+=minim, flow[x][tata[x]]-=minim;
                rez+=minim;
            }
    }
    g<<rez;
    return 0;
}
