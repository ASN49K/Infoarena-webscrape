#include <bits/stdc++.h>
#define inf 1e9
using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
vector <int> G[1002];
int t[1002];
int n;
int cap[1002][1002];
queue < pair <int, int> > q;
int bfs(){
    while(!q.empty()) q.pop();
    memset(t,0,sizeof t);
    q.push({1,inf});
    t[1] = -1;
    while(!q.empty()){
        for(auto x : G[q.front().first]){
            if(!t[x] && cap[q.front().first][x]){
                t[x] = q.front().first;
                int new_flow = min(q.front().second, cap[q.front().first][x]);
                if(x == n) return new_flow;
                q.push({x, new_flow});
            }
        }
        q.pop();
    }
    return 0;
}
int edmonds_karp(){
    int flow = 0, new_flow;
    while(new_flow = bfs()){
        flow += new_flow;
        int e = n;
        while(e != -1){
            cap[t[e]][e] -= new_flow;
            cap[e][t[e]] += new_flow;
            e = t[e];
        }
    }
    return flow;
}

int main()
{
    int i,m,u,v,c;
    fin >> n >> m;
    for(i = 1; i <= m; i++){
        fin >> u >> v >> c;
        G[u].push_back(v);
        G[v].push_back(u);
        cap[u][v] = c;
    }
    fout << edmonds_karp();
    return 0;
}
