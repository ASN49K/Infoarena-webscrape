#include <bits/stdc++.h>

using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
const int INF=1e9;
int n,m,cap[1005][1005],ans,S,D,dist[1005],p[1005];
vector<int> muchii[1005];
int dfs(int nod,int c)
{
    if(nod==D||c==0)
        return c;
    while(p[nod]<muchii[nod].size())
    {
        int i=muchii[nod][p[nod]];
        p[nod]++;
        if(dist[i]==dist[nod]+1&&cap[nod][i]!=0)
        {
            int x=dfs(i,min(c,cap[nod][i]));
            if(x!=0)
            {
                cap[nod][i]-=x;
                cap[i][nod]+=x;
                return x;
            }
        }
    }
}
bool flux()
{
    for(int i=1;i<=n;i++)
    {
        dist[i]=-1;
        p[i]=0;
    }
    dist[S]=0;
    queue<int> coada;
    coada.push(S);
    while(!coada.empty())
    {
        int nod=coada.front();
        coada.pop();
        for(int i:muchii[nod])
            if(dist[i]==-1&&cap[nod][i]>0)
            {
                dist[i]=dist[nod]+1;
                coada.push(i);
            }
    }
    if(dist[D]==-1)
        return 0;
    int val=0;
    while(true)
    {
        int x=dfs(S,INF);
        if(x==0)
            break;
        val+=x;
    }
    if(val==0)
        return 0;
    ans+=val;
    return 1;
}
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0);
    fin>>n>>m;
    S=1;
    D=n;
    for(int i=1;i<=m;i++)
    {
        int a,b,c;
        fin>>a>>b>>c;
        muchii[a].push_back(b);
        muchii[b].push_back(a);
        cap[a][b]=c;
    }
    while(flux());
    fout<<ans;
    return 0;
}
