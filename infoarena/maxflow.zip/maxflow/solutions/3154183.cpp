#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

vector<int> gf[1001];
int n, m, capacitate[1001][1001], tata[1001], fluxmax;
bool viz[1001];
const int inf = 2e9;

bool bfs() {
    for (int i = 1; i <= n; i++)
        viz[i] = 0;
    queue<pair<int, int>> q;
    viz[1] = 1;
    tata[1] = 1;
    q.push({ 1, inf });

    while (!q.empty()) {
        int nod = q.front().first;
        int nflux = q.front().second;
        q.pop();
        for (int v : gf[nod])
            if (!viz[v] && capacitate[nod][v]) {
                tata[v] = nod;
                if (v == n)
                    return true;
                viz[v] = 1;
                int nodnou = min(nflux, capacitate[nod][v]);
                q.push({ v, nodnou });
            }
    }
    return false;
}

int main()
{
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int x, y, c;
        fin >> x >> y >> c;
        gf[x].push_back(y);
        gf[y].push_back(x);
        capacitate[x][y] = c;
    }

    while (bfs()) {
        int fluxnou = inf;
        for (int i = n; i != 1; i = tata[i])
            fluxnou = min(fluxnou, capacitate[tata[i]][i]);
        for (int i = n; i != 1; i = tata[i]) {
            capacitate[i][tata[i]] += fluxnou;
            capacitate[tata[i]][i] -= fluxnou;
        }
        fluxmax += fluxnou;
    }
    fout << fluxmax;
    return 0;
}
