#include <bits/stdc++.h>

#define NMAX 1005

using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");

int N, M, x, y, z;
int C[NMAX][NMAX], F[NMAX][NMAX];
int cd[NMAX], viz[NMAX], TT[NMAX];
int flow;

vector <int> G[NMAX];

int BFS()
{
    memset(viz, 0, sizeof(viz));
    cd[0] = cd[1] = 1;
    viz[1] = 1;
    for(int i = 1; i <= cd[0]; i ++)
    {
        int nod = cd[i];
        if(nod == N) continue;
        for(int j = 0; j < G[nod].size(); j ++)
        {
            int V = G[nod][j];
            if(C[nod][V] == F[nod][V] || viz[V]) continue;
            viz[V] = 1;
            TT[V] = nod;
            cd[ ++ cd[0] ] = V;
        }
    }
    return viz[N];
}

int main()
{
    f >> N >> M;
    for(int i = 1; i <= M; i ++)
    {
        f >> x >> y >> z;
        C[x][y] = z;
        G[x].push_back(y);
        G[y].push_back(x);
    }

    while( BFS() )
    {
        for(int i = 0; i < G[N].size(); i ++)
            if(viz[ G[N][i] ])
            {
                int fmin = 111111;
                TT[N] = G[N][i];
                for(int j = N; j != 1; j = TT[j])
                    fmin = min(fmin, C[ TT[j] ][j] - F[ TT[j] ][j]);
                if(fmin == 0) continue;
                for(int j = N; j != 1; j = TT[j])
                {
                    F[ TT[j] ][j] += fmin;
                    F[j][ TT[j] ] -= fmin;
                }
                flow += fmin;
            }
    }
    g << flow;
    return 0;
}
