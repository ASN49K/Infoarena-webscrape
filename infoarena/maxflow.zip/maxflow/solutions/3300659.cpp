#include <bits/stdc++.h>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

vector<vector<int>> cap;
vector<vector<int>> adj;
int n;

int bfs(int s, int t, vector<int>& p) {
    queue<pair<int, int>> q;
    fill(p.begin(), p.end(), -1);

    q.push({s, INT_MAX});

    while(!q.empty()) {
        auto& [nod, minf] = q.front();
        q.pop();

        for (int neigh : adj[nod])
            if (p[neigh] == -1 && cap[nod][neigh]) {
                p[neigh] = nod;
                int new_minf = min(minf, cap[nod][neigh]);
                if (neigh == t)
                    return new_minf;
                q.push({neigh, new_minf});
            }
    }

    return 0;
}

int edmonds_karp(int s, int t) {
    int maxflow = 0, newflow;
    vector<int> p(n + 1);

    while(newflow = bfs(s, t, p)) {
        maxflow += newflow;
        int curr = t;
        
        while(curr != s) {
            int prev = p[curr];
            cap[curr][prev] += newflow;
            cap[prev][curr] -= newflow;
            curr = prev;
        }
    }

    return maxflow;
}

int main() {
    int m;

    fin >> n >> m;
    cap.resize(n + 1, vector<int>(n + 1));
    adj.resize(n + 1);

    for (int i = 1, x, y, w; i <= m; ++i) {
        fin >> x >> y >> w;
        cap[x][y] = w;
        adj[x].push_back(y);
        adj[y].push_back(x);
    }

    fout << edmonds_karp(1, n);
}