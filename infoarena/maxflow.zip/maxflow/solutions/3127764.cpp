#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;
/// #define int ll

const int N = (int) 1e5 + 7;
const int A = 7000 + 7;

int n, q;
bitset<A> b[N];

signed main() {
  ios::sync_with_stdio(0); cin.tie(0);
  freopen ("input", "r", stdin);
  string ret;
  cin >> n >> q;
  while (q--) {
    int tp;
    cin >> tp;
    if (tp == 1) {
      int x, v;
      cin >> x >> v;
      b[x] = 0;
      b[x][v] = 1;
      continue;
    }
    if (tp == 2) {
      int x, y, z;
      cin >> x >> y >> z;
      b[x] = b[y] ^ b[z];
      continue;
    }
    if (tp == 3) {
      int x, y, z;
      cin >> x >> y >> z;
      b[x] = 0;
      for (int k = 1; k < A; k++) {
        for (int i = k; i < A; i += k) {
          if (b[y][i]) b[x][k] = !b[x][k];
          if (b[z][i]) b[x][k] = !b[x][k];
        }
      }
      for (int k = A - 1; k >= 1; k--) {
        for (int i = 2 * k; i < A; i += k) {
          if (b[x][i]) b[x][k] = !b[x][k];
        }
      }
      continue;
    }
    if (tp == 4) {
      int x, i;
      cin >> x >> i;
      ret += (char) ('0' + b[x][i]);
      continue;
    }
  }
  cout << ret << "\n";
}
