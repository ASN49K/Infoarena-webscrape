#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream in("maxflow.in");
ofstream out("maxflow.out");

#define inf 1e9

vector<int> Tata;
vector<bool> Visited;

bool Find_BFS(int nod, int dest, auto &vecini_rezid, auto& cap_rezid) {

    Visited.assign(vecini_rezid.size(), false);
    //Tata.assign(vecini.size(), -1);
    queue<int> Q;

    Visited[nod] = true;
    Q.push(nod);

    while (!Q.empty()) {
        nod = Q.front();
        Q.pop();

        for (int v : vecini_rezid[nod]) {
            if (Visited[v]) continue;
            if (cap_rezid[nod][v]  <= 0) continue;

            Tata[v] = nod;
            Visited[v] = true;
            Q.push(v);

            if (v == dest)
                return true;
        }

    }
    return false;
}
int Min_Cap_Lant(int sursa, int dest, auto& cap_rezid) {
    int c = dest, cap_min = inf;
    while (c != sursa) {
        int tc = Tata[c];
        cap_min = min(cap_min, cap_rezid[tc][c] );
        c = tc;
    }

    return cap_min;
}
void Upd_Flux_Lant(int sursa, int dest, int cap_min, auto& cap_rezid) {
    int c = dest;

    while (c != sursa) {
        int tc = Tata[c];
        cap_rezid[tc][c] -= cap_min; //trimit flux -> scade capac reziduala
        cap_rezid[c][tc] += cap_min;
        c = tc;
    }
}

int main()
{
    int n, m;
    in >> n >> m;

    vector<vector<int>> vecini_rezid;
    vector<vector<int>> capac_rezid;
    Tata.assign(n, 0);
    vecini_rezid = vector<vector<int>> (n);
    capac_rezid = vector<vector<int>> (n, vector<int> (n, 0));

    for (int i = 0; i < m; i++) {
        int x, y, cap;
        in >> x >> y >> cap;
        x--; y--;

        capac_rezid[x][y] = cap;
        vecini_rezid[x].push_back(y);
        vecini_rezid[y].push_back(x);
    }

    /*
        Cat timp bfs-ul din surs in destinatie gaseste un drum
        Determinam capacitatea minima (vectorul de tati) -> min
        Pe acelasi drum modificam fluxul cu min
    */
    int sursa = 0, dest = n - 1, flux_max = 0;

    while (Find_BFS(sursa, dest, vecini_rezid,capac_rezid)) {
        int cap_min = Min_Cap_Lant(sursa, dest, capac_rezid);
        Upd_Flux_Lant(sursa, dest, cap_min, capac_rezid);

        flux_max += cap_min;
    }

    out << flux_max << "\n";





    return 0;
}
