#include <bits/stdc++.h>
using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");
vector<int>tata;
vector<vector<int> > cap,cap_d;
int n,m,t,s;
bool bfs()
{
    vector<bool> viz(n+1);
    queue<int> que;
    que.push(s);
    viz[s] = true;
    tata[s] = -1;
    while(!que.empty())
    {
        int a = que.front();
        que.pop();
        for(auto b:cap_d[a])
        {
            if(cap[a][b]!=0&&viz[b]==false)
            {
                tata[b] = a;
                if(b == t)
                    return true;
                viz[b] = true;
                que.push(b);
            }
        }
    }
    return false;
}

int EdmondsKarp()
{
    long cap_max=0;
    while(bfs()==true)
    {
        int a,b=t;
        int cap_l=INT_MAX;
        while(b!=s)
        {
            a=tata[b];
            if(cap[a][b]<cap_l)
                cap_l=cap[a][b];
            b=tata[b];
        }
        b=t;
        while(b!=s)
        {
            a=tata[b];
            cap[a][b]-=cap_l;
            cap[b][a]+=cap_l;
            b=tata[b];
        }
        cap_max+=cap_l;
    }
    return cap_max;
}
int main()
{
    int a,b;
    long c;
    f>>n>>m;
    s=1;
    t=n;
    tata.resize(n+1);
    cap_d.resize(n+1);
    cap.resize(n+1, vector<int>(n+1));
    for(int i=1; i<=m; i++)
    {
        f>>a>>b>>c;
        cap_d[a].push_back(b);
        cap_d[b].push_back(a);
        cap[a][b]=c;
    }
    g << EdmondsKarp();
    return 0;
}
