#include <bits/stdc++.h>

using namespace std;

ifstream fin( "maxflow.in" );
ofstream fout( "maxflow.out" );

const int MAXN = 1001;
const int INF = 1e9;

vector<int> G[MAXN];
int r[MAXN][MAXN];
int n, m;

int from[MAXN];

bool bfs() {
  for ( int u = 1; u <= n; ++u ) from[u] = 0;
  queue<int> q;
  from[1] = -1;
  q.push(1);
  while ( !q.empty() ) {
    int u = q.front();
    q.pop();
    for ( auto v : G[u] ) {
      if ( r[u][v] > 0 && !from[v] ) {
        q.push(v);
        from[v] = u;
      }
    }
  }
  return (from[n] != 0);
}

int main() {
  int u, v, c;
  
  fin >> n >> m;
  while ( m-- ) {
	fin >> u >> v >> c;
	G[u].push_back(v);
	G[v].push_back(u);
    r[u][v] += c;
  }
  int maxFlow = 0;
  while ( bfs() ) {
    int flow = INF;
    u = n;
	while ( u != 1 ) {
      flow = min(flow, r[from[u]][u]);
      u = from[u];
    }
    u = n;
	while ( u != 1 ) {
      r[from[u]][u] -= flow;
      r[u][from[u]] += flow;
      u = from[u];
    }
    maxFlow += flow;
  }
  fout << maxFlow;
  fin.close();
  fout.close();
  return 0;
}

