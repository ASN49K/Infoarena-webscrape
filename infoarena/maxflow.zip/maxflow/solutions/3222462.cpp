#include <bits/stdc++.h>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

const int NMAX = 1000;

struct edge {
    int to, cap, flow, rid;
};

int n, m;
vector<edge> g[NMAX + 1];
int dist[NMAX + 1];
int ptr[NMAX + 1];

void add_edge(int u, int v, int c) {
    int r1 = g[v].size();
    int r2 = g[u].size();
    g[u].push_back({v, c, 0, r1});
    g[v].push_back({u, 0, 0, r2});
}

bool bfs(int s, int t) {
    queue<int> q;
    q.push(s);
    for (int i = 1; i <= n; i++)
        dist[i] = -1;
    dist[s] = 0;
    while (!q.empty()) {
        int node = q.front();
        q.pop();
        for (auto it: g[node]) {
            if (dist[it.to] != -1) continue;
            if (it.flow == it.cap) continue;
            dist[it.to] = dist[node] + 1;
            q.push(it.to);
        }
    }
    return dist[t] > -1;
}

int dfs(int node, int t, int flow) {
    if (node == t)
        return flow;

    for (; ptr[node] < g[node].size(); ptr[node]++) {
        auto &it = g[node][ptr[node]];

        if (it.flow == it.cap) continue;
        if (dist[it.to] != dist[node] + 1) continue;

        int curFlow = min(flow, it.cap - it.flow);
        curFlow = dfs(it.to, t, curFlow);

        if (curFlow > 0) {
            it.flow += curFlow;
            g[it.to][it.rid].flow -= curFlow;
            return curFlow;
        }

    }

    return 0;
}

int flow(int s, int t) {
    int ans = 0;
    while (bfs(s, t)) {
        for (int i = 1; i <= n; i++)
            ptr[i] = 0;
        int f = dfs(s, t, 1e9);
        while (f > 0) {
            ans += f;
            f = dfs(s, t, 1e9);
        }
    }
    return ans;
}

void Read() {
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int u, v, c;
        fin >> u >> v >> c;
        add_edge(u, v, c);
    }
}

void Solve() {
    fout << flow(1, n) << '\n';
}

int main() {
    Read();
    Solve();
    return 0;
}
