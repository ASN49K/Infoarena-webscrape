#include <fstream>
#include <iostream>
#include <vector>
#include <utility>
#include <queue>
using namespace std;
vector<vector<int>> adj,flow,cap,gr;
int n,m,i,j,a,b,c;
bool bfs(vector<int>& tata)
{
    queue<int> q;
    q.push(1);
    fill(tata.begin(), tata.end(), 0);
    vector<int>viz(n+1,0);
    viz[1]=1;
    tata[1]=1;
    while(!q.empty())
    {
        int u = q.front();
        q.pop();
        for(int v: gr[u])
        {
            if(viz[v]==0 && cap[u][v]-flow[u][v]>0)
            {
                q.push(v);
                viz[v]=1;
                tata[v]=u;
            }
        }
    }
    return viz[n];
}
int flux(int s)
{
    vector<int> tata(n+1,0);
    int flowtot = 0;
    while(bfs(tata)==1)
    {
        int mini = 999999999;
        int v = n,u;
        while(v!=tata[v])
        {
            u = tata[v];
            if(cap[u][v]-flow[u][v]<mini)
            {
                mini = cap[u][v]-flow[u][v];
                
            }
            v = tata[v];
        }
        flowtot += mini;
        v = n;
        while(v!=tata[v])
        {
            u = tata[v];
            flow[u][v]+= mini;
            flow[v][u]-=mini;
            v = tata[v];
        }
    }
    return flowtot;
}
int main()
{
    ifstream fin("maxflow.in");
    ofstream fout("maxflow.out");
    fin>>n>>m;
    adj.assign(n+1,{});
    gr.assign(n+1,{});
    flow.assign(n+1,vector<int>(n+1,0));
    cap.assign(n+1,vector<int>(n+1,0));
    for(i=1;i<=m;i++)
    {
        fin>>a>>b>>c;
        adj[a].push_back(b);
        gr[a].push_back(b);
        gr[b].push_back(a);
        cap[a][b]=c;
    }
    fout<<flux(1);
}