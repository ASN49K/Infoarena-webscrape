#include <iostream>
#include <vector>
#include <queue>
#include <fstream>
using namespace std;
const int nmax = 1001;
const int inf = 1e9;
queue <int> q;
vector <int> parent, minn;
struct info{
    int adj, max_flow, cur_flow, i;
};
vector <info> edges[nmax];
int ans;
bool bfs( int S, int D, int n ) {
    int vf;
    //init
    while( !q.empty() )
        q.pop();
    parent.clear();
    parent.resize(n + 1 );
    minn.clear();
    minn.resize(n + 1 );
    minn[S] = inf;

    q.push( S );

    while( !q.empty() ) {
        vf = q.front();
        q.pop();
        if( vf == D )
            return true;
        for( info aux: edges[vf] ) {
            if( aux.cur_flow == aux.max_flow || parent[aux.adj] != 0 )
                continue;
            parent[aux.adj] = vf;
            minn[aux.adj] = min( minn[vf], aux.max_flow - aux.cur_flow );
            q.push(aux.adj );
        }
    }
    return false;
}

void solve( int S, int D, int n ) {
    int vf, flow;
    int pasiii = 0;
    while( bfs( S, D, n) && pasiii < 9 ) {
        vf = D;
        flow = minn[D];
        ans += flow;
        int pasi = 0;
        while( vf != S && pasi < 10 ) {
            // din muchia parent[vf] si vf, adaug flow
            for( int i = 0; i < edges[parent[vf]].size(); i++ ) {
                if( edges[parent[vf]][i].adj == vf )
                    edges[parent[vf]][i].cur_flow += flow;
            }
            for( int i = 0; i < edges[vf].size(); i++ ) {
                if( edges[vf][i].adj == parent[vf] )
                    edges[vf][i].cur_flow -= flow;
            }
            vf = parent[vf];
            pasi++;
        }
        pasiii++;
    }
}

int main() {
    ifstream cin("maxflow.in");
    ofstream cout("maxflow.out");
    int n, m, x, y, c;
    info aux;
    cin >> n >> m;
    for( int i = 0; i < m; i++ ) {
        cin >> x >> y >> c;
        aux.adj = y;
        aux.cur_flow = 0;
        aux.max_flow = c;
        aux.i = edges[y].size();
        edges[x].push_back(aux);
        aux.adj = x;
        aux.cur_flow = 0;
        aux.max_flow = 0;
        aux.i = edges[x].size() - 1;
        edges[y].push_back(aux);
    }
    solve( 1, n, n );
    cout << ans << "\n";
}