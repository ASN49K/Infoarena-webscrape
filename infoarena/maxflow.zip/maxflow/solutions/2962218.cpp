#include <bits/stdc++.h>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

int n, m, x, y, flow, g[1001][1001], maxflow;
queue <int> q;
bool viz[1001];
int parent[1001];

void read()
{
    fin >> n >> m;
    for(int i=0; i<m; i++)
    {
        fin >> x >> y >> flow;
        g[x][y] = flow;
    }
}

int bfs()
{
    /// folosim bfs pentru a verifica daca mai este un drum de la s la t
    /// folosim vectorul parent pentru a putea reconstrui drumul
    
    /// reinitializam tot
    while (!q.empty())
        q.pop();

    for (int i=0; i<=n; i++)
    {
        parent[i] = 0;
        viz[i] = false;
    }
    q.push(1);
    viz[1] = 1;
    
    /// bfs
    while (!q.empty())
    {
        auto nod = q.front();
        q.pop();
        /// n reprezinta destinatia deci returnam true deoarece am gasit drum
        if (nod == n) return true;

        for (int i=1; i<=n; i++)
            if (!viz[i] && g[nod][i] > 0)
            {
                q.push(i);
                parent[i] = nod;
                viz[i] = true;
            }
    }
    return false;
}

inline int flux()
{
    /// cat timp avem drumuri
    while (bfs())
    {
        for (int i=1; i<n; i++)
        {
            if (g[i][n] > 0 && viz[i])
            {
                int leaf = i;
                /// construim drumul
                vector <int> path;
                path.push_back(n);
                path.push_back(leaf);

                int nod = parent[leaf];

                if (nod == 1)
                    path.push_back(nod);
                else
                {
                    while (nod != 1)
                    {
                        path.push_back(nod);
                        nod = parent[nod];
                    }
                    path.push_back(1);
                }

                reverse(path.begin(), path.end());

                /// dupa ce am gasit drumul, vedem care este flow-ul minim si adaugam la rezultatul final

                int flow_minim = INT_MAX;

                for(int j=0; j<path.size()-1; j++)
                    flow_minim = min(flow_minim, g[path[j]][path[j+1]]);

                maxflow += flow_minim;

                /// pt reconstruirea flow-ului
                /// scadem flow_minim din muchiile inspre destinatie si adunam pe muchiile in directie opusa
                for(int j=0; j<path.size()-1; j++)
                {
                    g[path[j]][path[j+1]] -= flow_minim;
                    g[path[j+1]][path[j]] += flow_minim;
                }
            }
        }
    }

    return maxflow;
}

int main()
{
    read();
    fout << flux();
    return 0;
}