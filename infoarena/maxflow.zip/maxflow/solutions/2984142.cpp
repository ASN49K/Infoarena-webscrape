#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cstring>

using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

const int INF = 0x3f3f3f3f;
const int SIZE = 1005;

vector <int> G[SIZE];
int n, m, capacity[SIZE][SIZE], parent[SIZE];

bool bfs(int source, int sink)
{
    memset(parent, 0, sizeof(parent));
    queue <int> Q;
    Q.push(source);
    while(!Q.empty())
    {
        int x = Q.front();
        Q.pop();
//        if (x == sink)
//            continue;
        for (auto y : G[x])
        {
            if (parent[y] == 0 && capacity[x][y] > 0)
            {
                parent[y] = x;
                Q.push(y);

                if (y == sink)
                {
                    return true;
                }
            }
        }
    }

    return false;
}

int MaxFlow(int source, int sink)
{
    int maxFlow = 0, fmin;

    while (bfs(source, sink))
        for (auto x : G[sink])
        {
            if (parent[x] == 0 || capacity[x][sink] <= 0)
                continue;
            parent[sink] = x;

            fmin = INF;

            int node = sink;
            while (node != source)
            {
                int par = parent[node];
                fmin = min(fmin, capacity[par][node]);
                node = par;
            }


            node = sink;
            while (node != source)
            {
                int par = parent[node];
                capacity[par][node] -= fmin;
                capacity[node][par] += fmin;
                node = par;
            }

            maxFlow += fmin;
        }

    return maxFlow;
}

int main()
{
    f >> n >> m;

    for (int i = 1; i <= m; ++i)
    {
        int x, y, z;
        f >> x >> y >> z;
        G[x].push_back(y);
        G[y].push_back(x);
        capacity[x][y] += z;
    }

    g << MaxFlow(1, n);

    return 0;
}
