#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>
#include <queue>
#include <climits>
using namespace std;
ifstream in("maxflow.in");
ofstream out("maxflow.out");
const int NMAX=1005;
vector<int>graf[NMAX];
queue<int> q;
int C[NMAX][NMAX],F[NMAX][NMAX];
int parent[NMAX];
bool visited[NMAX];
int n,m;
bool bfs(int nod)
{
    memset(parent,-1,sizeof(parent));
    memset(visited,0,sizeof(visited));

    while(!q.empty())
        q.pop();

    q.push(nod);
    visited[nod]=1;

    int x,y;
    while(!q.empty())
    {
        x=q.front();
        q.pop();
        for(unsigned int i=0; i<graf[x].size(); i++)
        {
            y=graf[x][i];
            if(visited[y]==0 && F[x][y]!=C[x][y])
            {
                parent[y]=x;
                visited[y]=1;
                q.push(y);
                if(y==n)
                    return 1;

            }
        }

    }
    return 0;



}
int main()
{
    in>>n>>m;
    int x,y,cost;
    for(int i=1; i<=m; i++)
    {
        in>>x>>y>>cost;
        graf[x].push_back(y);
        graf[y].push_back(x);
        C[x][y]+=cost;

    }

    int nod;
    int f_min;
    int maxflow=0;
    while(bfs(1))
    {
        f_min=INT_MAX;

        nod=n;
        while(nod!=1)
        {
         f_min=min(f_min, C[parent[nod]][nod]-F[parent[nod]][nod]);
         nod=parent[nod];
        }

        nod=n;
        while(nod!=1)
        {
            F[parent[nod]][nod]+=f_min;
            F[nod][parent[nod]]-=f_min;
            nod=parent[nod];
        }
        maxflow+=f_min;
        //cout<<f_min<<" ";

    }
    out<<maxflow;


    return 0;
}
