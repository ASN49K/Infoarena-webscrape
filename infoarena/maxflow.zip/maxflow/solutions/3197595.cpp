#include <fstream>
#include <vector>
#include <queue>
const int NMAX=1005;

using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

vector <int> v[NMAX];
int cap[NMAX][NMAX], niv[NMAX], cnt[NMAX];
int n, m, mf, s, d;
queue <int> c;

bool flow();
int dfs(int, int);
void bfs(int);
void init();

int main()
{
    int a, b, c, i;
    fin>>n>>m;
    for(i=1; i<=m; i++)
    {
        fin>>a>>b>>c;
        v[a].push_back(b);
        v[b].push_back(a);
        cap[a][b]=c;
    }
    s=1; d=n;
    while(flow());
    fout<<mf<<'\n';
    return 0;
}

void init()
{
    int i;
    for(i=1; i<=n; i++)
    {
        niv[i]=1e9;
        cnt[i]=0;
    }
}

void bfs(int nod)
{
    int p;
    c.push(nod);
    niv[nod]=0;
    while(!c.empty())
    {
        p=c.front();
        c.pop();
        for(auto i:v[p])
        {
            if(niv[i]>(niv[p]+1) && cap[p][i]>0)
            {
                niv[i]=niv[p]+1;
                c.push(i);
            }
        }
    }
}

int dfs(int nod, int fl)
{
    if(nod==d || fl==0) return fl;
    while(cnt[nod]<int(v[nod].size()))
    {
        int nod1=v[nod][cnt[nod]];
        if(cap[nod][nod1]<=0 || niv[nod1]!=(niv[nod]+1)) cnt[nod]++;
        else
        {
            int val=dfs(nod1, min(fl, cap[nod][nod1]));
            if(val<=0) cnt[nod]++;
            else
            {
                cap[nod][nod1]-=val;
                cap[nod1][nod]+=val;
                return val;
            }
        }
    }
    return 0;
}

bool flow()
{
    int pls=0;
    init();
    bfs(s);
    if(niv[d]==1e9) return false;
    while(true)
    {
        int val=dfs(s, 1e9);
        if(val==0) break;
        pls+=val;
    }
    mf+=pls;
    return (pls!=0);
}
