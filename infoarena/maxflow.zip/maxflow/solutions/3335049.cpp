#include <fstream>
#include <vector>
using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
int n,m,ok,cap[1005],tt[1005],c[1005][1005];
long long s;
vector <int> v[1005];
void bfs(int x)
{
    if(c[x][n]) return ;
    for(int i=0; i<v[x].size(); i++)
    {
        int y=v[x][i];
        if(c[x][y]&&cap[y]==0)
        {
            cap[y]=min(cap[x],c[x][y]);
            tt[y]=x;
            bfs(y);
        }
    }
}
int bfs2(int x)
{
    if(c[x][n])
    {
        int aux;
        aux=min(c[x][n],cap[x]);
        c[x][n]-=aux;
        c[n][x]+=aux;
        return aux;
    }
    long long sum=0;
    for(int i=0; i<v[x].size(); i++)
    {
        int y=v[x][i];
        if(tt[y]==x)
        {
            int aux=bfs2(y);
            if(aux>0)
            {
                c[x][y]-=aux;
                c[y][x]+=aux;
                sum+=aux;
                if(x!=1) return sum;
            }
        }
    }
    return sum;
}
int main()
{
    cin>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x,y;
        cin>>x>>y;
        cin>>c[x][y];
        v[x].push_back(y);
        v[y].push_back(x);
    }
    do{
        ok=0;
        cap[1]=10000000005;
        bfs(1);
        for(int i=2; i<n; i++)
        {
            if(cap[i]>0&&c[i][n]) ok=1;
        }
        s+=bfs2(1);
        for(int i=1; i<=n; i++)
        {
            cap[i]=0;
            tt[i]=0;
        }
    }while(ok);
    cout<<s<<'\n';
	return 0;
}
