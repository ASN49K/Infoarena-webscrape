#include <bits/stdc++.h>
using namespace std;
int i,j,m,n,nvl[1008],frec[1008],cap[1008][1008],a,b,c,surs,dest,ras;
vector<int>G[1008];
void bfs(int nod)
{
   for(int i=1;i<=n;i++)
   {
       nvl[i]=-1;
       frec[i]=0;
   }
   nvl[nod]=0;
   queue<int>Q;
   Q.push(nod);
   while(!Q.empty())
   {
      int nod=Q.front();
      Q.pop();
      for(auto i:G[nod])
      {
          if(nvl[i]==-1 && cap[nod][i]>0)
          {
              nvl[i]=nvl[nod]+1;
              Q.push(i);
          }
      }
   }
}
int dfs(int nod,int maxx)
{
    if(maxx==0 || nod==dest)
    {
        return maxx;
    }
    while(frec[nod]<G[nod].size())
    {
        int aux=G[nod][frec[nod]];
        if(cap[nod][aux]>0 && nvl[aux]==nvl[nod]+1)
        {
            int x=dfs(aux,min(maxx,cap[nod][aux]));
            if(x>0)
            {
                cap[nod][aux]-=x;
                cap[aux][nod]+=x;
                return x;
            }
        }
        frec[nod]++;
    }
    return 0;
}
int flux(int nod)
{
    bfs(nod);
    if(nvl[dest]==-1)
    {
        return 0;
    }
    int val=0;
    while(true)
    {
        int x=dfs(surs,1e9);
        if(x==0)
            break;
        val+=x;
    }
    ras+=val;
    return val;
}
int main()
{
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>a>>b>>c;
        G[a].push_back(b);
        G[b].push_back(a);
        cap[a][b]+=c;
    }
    surs=1;
    dest=n;
    while(flux(surs));
    cout<<ras;
    return 0;
}
