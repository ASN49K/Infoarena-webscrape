#include <fstream>
#include <vector>
#include <queue>

using namespace std;

struct flow_edge {
    int v, u;
    long long cap, flow = 0;
    flow_edge(int v, int u, long long cap) : v(v), u(u), cap(cap) {}
};

struct dinic {
    const long long flow_inf = 1e18;
    vector<vector<int>> adj;
    vector<flow_edge> edges;
    vector<int> level, ptr;
    int n, m = 0;
    int s, t;
    queue<int> q;

    dinic(int n, int s, int t) : n(n), s(s), t(t) {
        adj.resize(n);
        level.resize(n);
        ptr.resize(n);
    }

    void add_edge(int v, int u, long long cap) {
        edges.emplace_back(v, u, cap);
        edges.emplace_back(u, v, 0);
        adj[v].push_back(m);
        adj[u].push_back(m + 1);
        m += 2;
    }

    bool bfs() {
        while (!q.empty()) {
            int v = q.front();
            q.pop();
            for (int id : adj[v]) {
                if (edges[id].cap == edges[id].flow) {
                    continue;
                }
                if (level[edges[id].u] != -1) {
                    continue;
                }
                level[edges[id].u] = level[v] + 1;
                q.push(edges[id].u);
            }
        }

        return level[t] != -1;
    }

    long long dfs(int v, long long pushed) {
        if (pushed == 0) {
            return 0;
        }
        if (v == t) {
            return pushed;
        }
        for (int &cid = ptr[v]; cid < (int)adj[v].size(); cid++) {
            int id = adj[v][cid];
            int u = edges[id].u;
            if (level[v] + 1 != level[u]) {
                continue;
            }
            long long tr = dfs(u, min(pushed, edges[id].cap - edges[id].flow));
            if (tr == 0) {
                continue;
            }
            edges[id].flow += tr;
            edges[id ^ 1].flow -= tr;
            return tr;
        }

        return 0;
    }

    long long flow() {
        long long f = 0;
        while (true) {
            fill(level.begin(), level.end(), -1);
            level[s] = 0;
            q.push(s);
            if (!bfs()) {
                break;
            }

            fill(ptr.begin(), ptr.end(), 0);
            while (long long pushed = dfs(s, flow_inf)) {
                f += pushed;
            }
        }
        return f;
    }
};

int main() {
    ifstream fin("grader_test9.in");
    ofstream fout("maxflow.out");
    int n, m;
    fin >> n >> m;
    dinic d(n + 1, 1, n);

    for (int i = 0; i < m; ++i) {
        int u, v, cap;
        fin >> u >> v >> cap;
        d.add_edge(u, v, cap);
    }

    fout << d.flow() << '\n';
    return 0;
}
