#include <bits/stdc++.h>
using namespace std;

const int NMAX = (int)1e3 * 5;
const int inf = (int)1e9;
int N,M,capacitate[1005][1005],flux_trimis[1005][1005],ans,mn,from[NMAX];
vector<int>ad[NMAX];
bool ok = true,b[1005];
int main(){
    ios::sync_with_stdio(false);
	cin.tie(nullptr);

	freopen("maxflow.in", "r", stdin);
	freopen("maxflow.out", "w", stdout);
    cin >> N >> M;
    while (M--) {
        int u,v,c; cin >> u >> v >> c;
        ad[u].push_back(v);
        ad[v].push_back(u);
        capacitate[u][v] = c;
    }
    while (ok) {
        ok = false;
        int mn = inf;
        stack<int>q,been;
        q.push(1);
        while (q.size()) {
            int node = q.top();
            q.pop();
            b[node] = true;
            if (node == N) {
                ok = true;
                ans += mn;
                while (node != 0) {
                    int i = from[node];
                    flux_trimis[i][node] += mn;
                    flux_trimis[node][i] -= mn;
                    node = i;
                }
                break;
            }
            for (int i : ad[node])
                if ((capacitate[node][i] - flux_trimis[node][i] > 0) && b[i] == false) {
                    int d = capacitate[node][i] - flux_trimis[node][i];
                    mn = min(mn,d);
                    from[i] = node;
                    q.push(i);
                    been.push(i);
                }

        }
        while (been.size()) {
            int node = been.top();
            b[node] = 0;
            been.pop();
        }
    }
    cout << ans;
    return 0;
}
