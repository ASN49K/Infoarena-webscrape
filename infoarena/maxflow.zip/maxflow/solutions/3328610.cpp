
// pt a transforma o problema intr-o problema de flux: 
// 1. adaugam o sursa 
// edmond karp algorithm

#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
#include <fstream>

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

//#include <bits/stdc++.h>
using namespace std;

const int NMAX = 1e3;
int capacitate[NMAX + 1][NMAX + 1]; // matrice de capacitate
int flux[NMAX + 1][NMAX + 1]; // matrice de flux
vector<int> G[NMAX + 1];

int n, m;
int vis[NMAX + 1];
int p[NMAX + 1];

int bfs(int s, int d) {
	for (int i = 1; i <= n; i++) {
		vis[i] = 0;
	}
	queue<int> q;
	q.push(s);
	vis[s] = 1;
	while (!q.empty()) {
		int nod = q.front();
		q.pop();
		for (auto vecin : G[nod]) {
			if (!vis[vecin] && capacitate[nod][vecin] - flux[nod][vecin] > 0) {
				vis[vecin] = 1;
				p[vecin] = nod;
				q.push(vecin);
			}
		}
	}
	if (!vis[d]) {
		return 0;
	}
	vector<int> path; 
	int x = d;
	while (x != 0) {
		path.push_back(x);
		x = p[x];
	}
	reverse(path.begin(), path.end());

	int flow = 1e9;

	for (int i = 0; i < path.size(); i++) {
		int a = path[i];
		int b = path[i + 1];
		flow = min(flow, capacitate[a][b] - flux[a][b]);
	}
	for (int i = 0; i < path.size(); i++) {
		int a = path[i];
		int b = path[i + 1];
		flux[a][b] += flow;
		flux[a][b] -= flow;
	}

	return flow;
}

int main()
{
	
	fin >> n >> m;
	for (int i = 1; i <= m; i++) {
		int x, y, c;
		fin >> x >> y >> c;
		capacitate[x][y] = c;
		G[x].push_back(y);
		G[y].push_back(x);
	}
	int maxflow = 0;
	while (true) {
		int flow = bfs(1, n);
		if (flow == 0) {
			break;
		}
		maxflow += flow;
	}
	fout << maxflow;

}

