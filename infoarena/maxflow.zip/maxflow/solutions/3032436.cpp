#include <fstream>
#include <queue>
#include <vector>
using namespace std;
ifstream f("maxflow.in");
ofstream g("maxflow.out");
int n,X,Y,sum,Z,m;
vector<int>a[1005];
int niv[1005],p[1005],d[1005][1005];
void bfs()
{
    for(int i=1;i<=n;i++)
        niv[i]=-1,p[i]=0;
    queue<int>q;
    q.push(1);
    niv[1]=0;
    while(!q.empty())
    {
        int nod=q.front();
        q.pop();
        for(auto x: a[nod])
        {
            if(d[nod][x]>0&&niv[x]==-1)
            {
                q.push(x);
                niv[x]=niv[nod]+1;
                if(x==n)
                    return;
            }
        }
    }
}
int dfs(int nod,int mn)
{
    if(nod==n||mn==0)
        return mn;
    for(auto x: a[nod])
        if(niv[x]==niv[nod]+1&&d[nod][x]>0)
        {
            int y=dfs(x,min(mn,d[nod][x]));
            if(y>0)
            {
                d[nod][x]-=y;
                d[x][nod]+=y;
                return y;
            }
        }
    return 0;
}
bool flux()
{
    bfs();
    if(niv[n]==-1)
        return 0;
    else
    {
        int ans=0;
        while(true)
        {
            int val=dfs(1,1e9);
            if(val==0)
                break;
            else
                ans+=val;
        }
        sum+=ans;
        if(ans!=0)
            return true;
    }
    return false;

}
int main()
{
    f>>n>>m;
    for(int i=1;i<=m;i++)
    {
        f>>X>>Y>>Z;
        a[X].push_back(Y);
        a[Y].push_back(X);
        d[X][Y]=Z;
    }
    while(flux());
    g<<sum;
    return 0;
}
