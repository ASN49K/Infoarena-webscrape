#include <iostream>
#include <vector>
#include <queue>
#include <fstream>

using namespace std;

ifstream fin("maxflow.in");
ofstream fout("maxflow.out");

//ifstream fin("critice.in");
//ofstream fout("critice.out");

int n, m, capacitate[1005][1005], flow[1005][1005], parent[1005], fr[1005][1005], rez2[1005], flux;
pair<int,int> muchii[1005];
vector<int> v[1005];
queue<int> q;
bool viz[1005];

void bfs_max(int nod) {
    for (int i = 1; i <= n; i++) {
        viz[i] = 0;
        parent[i] = 0;
    }
    viz[nod] = 1;
    q.push(nod);
    while (!q.empty()) {
        int cr = q.front();
        q.pop();
        if (cr == n) continue;
        for (auto el : v[cr]) {
            if (!viz[el] && capacitate[cr][el] != flow[cr][el]) {
                viz[el] = 1;
                parent[el] = cr;
                q.push(el);
            }
        }
    }
}

/*void dfs1(int nod) {
    viz[nod] = 1;
    for (auto el : v[nod]) {
        if (!viz[el] && capacitate[nod][el] != flow[nod][el]) dfs1(el);
        else if (capacitate[nod][el] == flow[nod][el]) fr[nod][el]++;
    }
}

void dfs2(int nod) {
    viz[nod] = 1;
    for (auto el : v[nod]) {
        if (!viz[el] && capacitate[el][nod] != flow[el][nod]) dfs2(el);
        else if (capacitate[el][nod] == flow[el][nod]) fr[nod][el]++;
    }
}*/

int main(){
    fin >> n >> m;
    for (int i = 1; i <= m; i++) {
        int x, y, c;
        fin >> x >> y >> c;
        v[x].push_back(y);
        v[y].push_back(x);
        muchii[i] = { x, y };
        capacitate[x][y] = c;
    }
    while (1) {
        bfs_max(1);
        if (!viz[n]) break;
        for (auto el : v[n]) {
            if (!viz[el]) continue;
            parent[n] = el;
            int cr = n, mn = 1e9;
            while (cr != 1) {
                mn = min(mn, capacitate[parent[cr]][cr] - flow[parent[cr]][cr]);
                if (mn == 0) break;
                cr = parent[cr];
            }
            if (mn == 0) continue;
            flux += mn;
            cr = n;
            while (cr != 1) {
                flow[parent[cr]][cr] += mn;
                flow[cr][parent[cr]] -= mn;
                cr = parent[cr];
            }
        }
    }   
    fout << flux;
    /*for (int i = 1; i <= n; i++) viz[i] = 0;
    dfs1(1);
    dfs2(n);
    int rez = 0;
    for (int i = 1; i <= m; i++) {
        if (fr[muchii[i].first][muchii[i].second] >= 1 && fr[muchii[i].second][muchii[i].first] >= 1) {
            rez2[++rez] = i;
        }
    }
    fout << rez << "\n";
    for (int i = 1; i <= rez; i++)
        fout << rez2[i] << "\n";*/
}


