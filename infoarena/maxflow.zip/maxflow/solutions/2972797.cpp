#include <bits/stdc++.h>
#define FILES freopen("maxflow.in" , "r" , stdin) , freopen("maxflow.out" , "w" , stdout)
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(false) , cout.tie(false)
#define pb push_back

using namespace std;

const int N = 1e2 + 10;

int n , m;


struct MaxFlow
{
    #define N (int) 1e3 + 10

    int source , sink , n;
    int lvl[N] , ptr[N];
    struct edge {int x , y , cap;};
    vector < edge > edg;
    vector < int > G[N];
    int m = 0;
    queue < int > q;

    MaxFlow(int source , int sink , int n)
    {
        this -> source = source;
        this -> sink = sink;
        this -> n = n;
    }

    void addEdge(int x , int y , int c)
    {
        edg.pb({x , y , c});
        G[x].pb(m++);
        edg.pb({y , x , 0});
        G[y].pb(m++);
    }

    bool bfs()
    {
        for(int i = 1 ; i <= n ; i++)
            lvl[i] = 0;

        lvl[source] = 1;
        q.push(source);

        while(!q.empty())
        {
            int node = q.front();
            q.pop();

            for(auto i : G[node])
            {
                int to = edg[i].x ^ edg[i].y ^ node;
                int c = edg[i].cap;

                if(c && !lvl[to])
                {
                    lvl[to] = lvl[node] + 1;
                    q.push(to);
                }
            }
        }

        return lvl[sink] > 0;
    }

    int dfs(int node , int pushed_flow)
    {
        if(node == sink)
            return pushed_flow;

        for(int &i = ptr[node] ; i < G[node].size() ; i++)
        {
            int ind = G[node][i];
            int to = edg[ind].x ^ edg[ind].y ^ node;
            int cap = edg[ind].cap;

            if(lvl[to] == lvl[node] + 1 && cap)
            {
                int f = dfs(to , min(pushed_flow , cap));

                if(f == 0)
                    continue;

                edg[ind].cap -= f;
                edg[ind ^ 1].cap += f;

                return f;
            }
        }
    }

    int maxflow()
    {
        int flow = 0;

        while(bfs())
        {
            for(int i = 1 ; i <= n ; i++)
                ptr[i] = 0;

            while(int f = dfs(source , INT_MAX))
                flow += f;
        }

        return flow;
    }
};

signed main()
{
//    #ifndef ONLINE_JUDGE
        FILES , FastIO;
    //#endif // ONLINE_JUDGE

    int i , j , t;

    cin >> n >> m;

    MaxFlow F(1 , n , n);

    while(m--)
    {
        int x , y , c;

        cin >> x >> y >> c;
        F.addEdge(x , y , c);
    }

    cout << F.maxflow();

    return 0;
}
