#include <bits/stdc++.h>
#include <fstream>
#define cin fin
#define cout fout
using namespace std;
ifstream cin ("maxflow.in");
ofstream cout ("maxflow.out");
int frec[1008],nvl[1008],mat[1008][1008],i,a,b,c,n,finn,sur,x,ras,m;
vector<int>G[1008];
void bfs(int nod)
{
    for(i=1;i<=n;i++)
    {
        nvl[i]=-1;
        frec[i]=0;
    }
    nvl[nod]=0;
    queue<int>Q;
    Q.push(nod);
    while(!Q.empty())
    {
        nod=Q.front();
        Q.pop();
        for(auto i:G[nod])
        {
            if(nvl[i]==-1 && mat[nod][i]>0)
            {
                nvl[i]=nvl[nod]+1;
                Q.push(i);
            }
        }
    }
}
int dfs(int nod,int minn)
{
    if(nod==finn || minn==0)
        return minn;
    while(frec[nod]<G[nod].size())
    {
        int k=G[nod][frec[nod]++];
        if(mat[nod][k]>0 && nvl[nod]+1==nvl[k])
        {
            x=dfs(k,min(minn,mat[nod][k]));
            if(x>0)
            {
                mat[nod][k]-=x;
                mat[k][nod]+=x;
                return x;
            }
        }
    }
    return 0;
}
bool flux(int nod)
{
    bfs(nod);
    if(nvl[finn]==-1)
    {
        return 0;
    }
    else
    {
        int val=0;
        while(true)
        {
            x=dfs(1,1e9);
            if(x==0)
                break;
            val+=x;
        }
        ras+=val;
        return (val!=0);
    }
}
int main()
{
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        cin>>a>>b>>c;
        G[a].push_back(b);
        mat[a][b]=c;
        G[b].push_back(a);
    }
    sur=1;
    finn=n;
    while(flux(sur));
    cout<<ras;
    return 0;
}
