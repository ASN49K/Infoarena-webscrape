#include <bits/stdc++.h>

using namespace std;
const int N = 1e5 + 5;
using ll = long long;
struct edge {
    int from, to, cap;
};
vector <edge> e;
vector <int> g[N];
int lvl[N], rem[N], s, t, n;
void add_edge(int u, int v, int c) {
    g[u].push_back(e.size());
    e.push_back({u, v, c});
    g[v].push_back(e.size());
    e.push_back({v, u, 0});
}
bool bfs() {
    queue <int> q;
    q.push(s);
    fill(lvl, lvl + n + 1, 0);
    lvl[s] = 1;
    while(!q.empty()) {
        int u = q.front();
        q.pop();
        for(int id : g[u]) {
            int v = e[id].to;
            if(!lvl[v] && e[id].cap) {
                lvl[v] = lvl[u] + 1;
                q.push(v);
            }
        }
    }
    return lvl[t];
}
int dfs(int u, int flow) {
    if(!flow || u == t) return flow;
    for(int& cid = rem[u]; cid < (int)g[u].size(); cid++) {
        int id = g[u][cid];
        int v = e[id].to;
        if(lvl[v] != lvl[u] + 1 || !e[id].cap) continue;
        int f = dfs(v, min(flow, e[id].cap));
        if(!f) continue;
        e[id].cap -= f;
        e[id^1].cap += f;
        return f;
    }
    return 0;
}

int main()
{
#ifndef HOME
    ifstream cin("maxflow.in");
    ofstream cout("maxflow.out");
#else
    ios_base :: sync_with_stdio(false); cin.tie(0);
#endif
    int m;
    cin >> n >> m;
    s = 1, t = n;
    for(int i = 0, u, v, w; i < m; i++)
        cin >> u >> v >> w,
        add_edge(u, v, w);
    long long flow = 0;
    while(bfs()) {
        fill(rem, rem + n + 1, 0);
        while(int f = dfs(s, 1e9))
            flow += f;
    }
    cout << flow;
    return 0;
}
