#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <cstring>
#define inf 0x3f3f3f3f
#define nmax 1005
using namespace std;
vector<int> V[nmax];
int n,m,c[nmax][nmax],f[nmax][nmax],maxflow,tata[nmax];
bool viz[nmax];
bool bfs()
{
    bool ok=false;
    queue<int> coada;
    memset(viz,0,sizeof(viz));
    viz[1]=true;
    coada.push(1);
    while(!coada.empty())
    {
        int sursa=coada.front();
        coada.pop();
        for(auto vecin:V[sursa])
        {
            if(!viz[vecin]&&c[sursa][vecin]!=f[sursa][vecin])
            {
                viz[vecin]=true;
                coada.push(vecin);
                tata[vecin]=sursa;
                if(vecin==n)
                {
                    ok=true;
                    break;
                }
            }
        }
    }
    return ok;
}
int main()
{
    ifstream fin("maxflow.in");
    ofstream fout("maxflow.out");
    fin>>n>>m;
    for(int i=1;i<=m;i++)
    {
        int a,b,z;
        fin>>a>>b>>z;
        V[a].push_back(b);
        V[b].push_back(a);
        c[a][b]+=z;
    }
    for(;bfs();)
    {
        int mincaprez=inf;
        for(int nod=n;nod!=1;nod=tata[nod])
        {
            mincaprez=min(mincaprez,c[tata[nod]][nod]-f[tata[nod]][nod]);
        }
        for(int nod=n;nod!=1;nod=tata[nod])
        {
            f[tata[nod]][nod]+=mincaprez;
            f[nod][tata[nod]]-=mincaprez;
        }
        maxflow+=mincaprez;
    }
    fout<<maxflow;
    return 0;
}