#include <fstream>
#include <vector>
#include <queue>
using namespace std;

ifstream cin("maxflow.in");
ofstream cout("maxflow.out");

const int MAX = 1e3 + 1;

int n , m , x , y , cap , sz[MAX] , ind;

struct pipe{

    int f , c , ind;
};

vector <int> g[MAX];
vector <pipe> ad[MAX];

struct dinic{

    int source , sink , ef[MAX] , level[MAX];

    bool viz[MAX];

    void seteaza( int a , int b ){

        source = a;
        sink = b;
    }

    bool bfs(){

        for(int i = 1 ; i <= n ; i++){

            viz[i] = 0;
            ef[i] = 0;
            level[i] = 0;
        }

        level[source] = 1;
        queue <int> q;
        q.push(source);
        while(!q.empty()){

            x = q.front();
            q.pop();

            int ind = -1;

            for(auto it : g[x]){

                ind++;

                if(!level[it] && ad[x][ind].c - ad[x][ind].f > 0){

                    level[it] = level[x]+1;
                    if(it == sink) return 1;
                    q.push(it);
                }
            }
        }

        return 0;
    }

    int dfs(int x , int flow = 1e9 + 1){

        viz[x] = 1;

        if( x == sink ){

            return flow;
        }

        for(; ef[x] < sz[x] ;){

            int it = g[x][ef[x]];

            if(viz[it]){

                ef[x]++;
                continue;

            }

            if(level[it] != level[x] + 1){

                ef[x]++;
                continue;
            }

            if(ad[x][ef[x]].c - ad[x][ef[x]].f<=0){

                ef[x]++;
                continue;
            }


            int new_flow = dfs(it,min(flow,ad[x][ef[x]].c - ad[x][ef[x]].f));

            if(!new_flow){

                ef[x]++;
                continue;
            }

            ad[x][ef[x]].f += new_flow;
            ad[it][ad[x][ef[x]].ind].f -= new_flow;

            ef[x]++;
            return new_flow;
        }

        return 0;
    }
}d;

signed main(){

    cin >> n >> m;

    while(m--){

        cin >> x >> y >> cap;

        g[x].push_back(y);
        g[y].push_back(x);
        ad[x].push_back({0,cap,sz[y]});
        ad[y].push_back({0,0,sz[x]});
        sz[x]++;
        sz[y]++;
    }

    d.seteaza(1,n);

    int flow_delicios = 0;

    while(d.bfs()){

        int new_flow = 0;

        while(1){

            int val = d.dfs(1);

            if(!val) break;

            new_flow += val;
        }

        if(!new_flow) break;

        flow_delicios += new_flow;
    }

    cout << flow_delicios;

    return 0;
}
