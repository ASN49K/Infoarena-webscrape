#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int INF = 1 << 30;

struct Edge {
    int to, cap, rev;
};

vector<Edge> graph[1005];
int level[1005];
int iter[1005];

void add_edge(int from, int to, int cap) {
    graph[from].push_back({to, cap, (int)graph[to].size()});
    graph[to].push_back({from, 0, (int)graph[from].size() - 1});
}

bool bfs(int s, int t, int n) {
    for (int i = 1; i <= n; ++i) level[i] = -1;
    queue<int> q;
    level[s] = 0;
    q.push(s);
    while (!q.empty()) {
        int v = q.front(); q.pop();
        for (auto& e : graph[v]) {
            if (e.cap > 0 && level[e.to] < 0) {
                level[e.to] = level[v] + 1;
                q.push(e.to);
            }
        }
    }
    return level[t] >= 0;
}

int dfs(int v, int t, int f) {
    if (v == t) return f;
    for (int& i = iter[v]; i < graph[v].size(); i++) {
        Edge& e = graph[v][i];
        if (e.cap > 0 && level[v] < level[e.to]) {
            int d = dfs(e.to, t, min(f, e.cap));
            if (d > 0) {
                e.cap -= d;
                graph[e.to][e.rev].cap += d;
                return d;
            }
        }
    }
    return 0;
}

int max_flow(int s, int t, int n) {
    int flow = 0;
    while (bfs(s, t, n)) {
        for (int i = 1; i <= n; ++i) iter[i] = 0;
        int f;
        while ((f = dfs(s, t, INF)) > 0) {
            flow += f;
        }
    }
    return flow;
}

int main() {
    ifstream fin("maxflow.in");
    ofstream fout("maxflow.out");
    
    int n, m;
    fin >> n >> m;
    for (int i = 0; i < m; i++) {
        int x, y, z;
        fin >> x >> y >> z;
        add_edge(x, y, z);
    }
    
    fout << max_flow(1, n, n);
    
    return 0;
}