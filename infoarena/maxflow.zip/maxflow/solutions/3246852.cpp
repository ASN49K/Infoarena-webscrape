#include <bits/stdc++.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

#define oo 0x3f3f3f3f

using namespace std;

ifstream f("maxflow.in");
ofstream g("maxflow.out");

int n, m, C[1005][1005], F[1005][1005], max_flow, t[1005];
bool viz[1005];
vector<int> graph[1005];

void read() {
    f>>n>>m;
    int x, y;
    for(int i = 1;i <= m;++i) {
        f>>x>>y>>C[x][y];
        graph[x].push_back(y);
        graph[y].push_back(x);
    }
    f.close();
}

bool bfs() {
    memset(viz, false, sizeof(bool) * (n  + 1));
    viz[1] = true;
    queue<int> q;
    q.push(1);

    while(!q.empty()) {
        int node = q.front();
        q.pop();

        if(node == n) {
            continue;
        }

        for(const auto& ngh : graph[node]) {
            if(viz[ngh] || F[node][ngh] == C[node][ngh]) {
                continue;
            }
            q.push(ngh);
            viz[ngh] = true;
            t[ngh] = node;
        }
    }

    return viz[n];
}

void solve() {
    while(bfs()) {
        for(const auto& node : graph[n]) {
            if(!viz[node] || C[node][n] == F[node][n]) {
                continue;
            }

            t[n] = node;
            int flow = oo;
            for(int no = n;no != 1;no = t[no]) {
                flow = min(flow, C[t[no]][no] - F[t[no]][no]);
            }
            if(flow == oo) {
                continue;
            }
            max_flow += flow;
            for(int no = n;no != 1;no = t[no]) {
                F[t[no]][no] += flow;
                F[no][t[no]] -= flow;
            }

        }
    }
    g<<max_flow;
    g.close();
}

int main() {
    read();
    solve();
    return 0;
}