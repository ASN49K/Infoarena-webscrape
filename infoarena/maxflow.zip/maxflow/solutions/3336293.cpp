// algoritm optimizat
// satureaza mai multe drumuri deodata
#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <map>
#include <unordered_map>

using namespace std;
ifstream fin("maxflow.in");
ofstream fout("maxflow.out");
int N,M;
vector<int> G[1001];
//nod_start (u) : {nod_destinatie (v): capacitate u-v}
unordered_map<int, unordered_map<int, int> > capacity, flow; // memorie O(E)
bool bfs(int source, int sink, vector<int>& parent, vector<bool>& visited) {
    fill(visited.begin(),visited.end(), false);
    fill(parent.begin(), parent.end(), -1);
    queue<int> q;
    q.push(source);
    visited[source] = true;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        if (u == sink) continue; // nu ma opresc la destinatie continui sa caut drumuri

        for (int v : G[u]) {
            if (!visited[v] && capacity[u][v] - flow[u][v] > 0) {
                visited[v] = true;
                parent[v] = u;
                q.push(v);
            }
        }
    }
    return visited[sink];
}

int EdmondsKarp(int source, int sink) {
    int maxflow = 0;
    vector<int> parent(N+1);
    vector<bool> visited(N+1);
    // while exista macar un drum in graful rezidual
    while (bfs(source, sink, parent, visited)) {
        //verific toti vecinii destinatiei
        for (int v : G[sink]) {
            if (!visited[v]) continue;
            if (capacity[v][sink] - flow[v][sink] <= 0) continue;

            parent[sink] = v; // setez parintele destinatiei
            int add = INT_MAX;
            // parcurg drumul invers si caut flow-ul care mai poate fi adaugat pe acest traseu
            for (int u = sink; u != source; u = parent[u]) {
                int p = parent[u];
                add = min(add, capacity[p][u] - flow[p][u]);
            }
            if (add == 0) continue;
            // daca add > 0, modific fluxul pe fiecare teava
            for (int u = sink; u != source; u = parent[u]) {
                int p = parent[u];
                flow[p][u] += add;
                flow[u][p] -= add;
            }
            maxflow += add;
        }
    }
    return maxflow;
}
int main() {
    fin >> N >> M;
    for (int i = 0; i < M; i++) {
        int x,y,c;
        fin >> x >> y >> c;
        G[x].push_back(y);
        G[y].push_back(x); // reverse edges
        capacity[x][y] += c;
        capacity[y][x] += 0;
    }
    fout << EdmondsKarp(1,N);
    return 0;
}