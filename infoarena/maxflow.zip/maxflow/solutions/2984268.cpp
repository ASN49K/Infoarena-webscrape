#include <bits/stdc++.h>
using namespace std;
int n, m;
const int NMAX = 1e3 + 1;
vector<vector<int>> graph(NMAX, vector<int>(NMAX, 0));
int bfs(int s, int t, vector<int> &parent)
{
    fill(parent.begin(), parent.end(), -1);

    parent[s] = -2;

    queue<pair<int, int>> q;

    q.push({s, 1e9});

    while (!q.empty())
    {
        int u = q.front().first;
        int cap = q.front().second;
        q.pop();

        for (int v = 1; v <= n; v++)
        {
            if (u != v && graph[u][v] > 0 && parent[v] == -1)
            {

                parent[v] = u;

                int min_cap = min(cap, graph[u][v]);

                if (v == t)
                {
                    return min_cap;
                }
                q.push({v, min_cap});
            }
        }
    }
    return 0;
}

int Ford_Fulkerson(int s, int t)
{
    vector<int> parent(n, -1);
    int max_flow = 0;
    int min_cap = 0;
    while (min_cap = bfs(s, t, parent))
    {
        max_flow += min_cap;
        int v = t;
        while (v != s)
        {
            int u = parent[v];
            graph[u][v] -= min_cap;
            graph[v][u] += min_cap;
            v = u;
        }
    }
    return max_flow;
}
int main()
{   
    ifstream fin("maxflow.in");
    ofstream fout("maxflow.out");
    fin >> n >> m;
    int x, y, c;
    n ++;
    for (int i = 0; i < m; i++)
    {
        fin >> x >> y >> c;
        graph[x][y] = c;
    }
    fout << Ford_Fulkerson(1, n - 1);
    return 0;
}