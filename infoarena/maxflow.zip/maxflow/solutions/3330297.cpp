#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
using namespace std;
ifstream in("maxflow.in");
ofstream out("maxflow.out");

#define inf 1e9

vector<int> Tata;
vector<bool> Visited;

bool Find_BFS(int nod, int dest, auto &vecini, auto &vecini_rev, auto& flux, auto& capacity) {

    Visited.assign(vecini.size(), false);
    //Tata.assign(vecini.size(), -1);
    queue<int> Q;

    Visited[nod] = true;
    Q.push(nod);

    while (!Q.empty()) {
        nod = Q.front();
        Q.pop();

        for (int v : vecini[nod]) {
            if (Visited[v]) continue;
            if (capacity[nod][v] - flux[nod][v] <= 0) continue;

            Tata[v] = nod;
            Visited[v] = true;
            Q.push(v);

            if (v == dest)
                return true;
        }

        for (int vr : vecini_rev[nod]) {
            if (Visited[vr]) continue;
            if (flux[vr][nod] <= 0) continue;

            Tata[vr] = -nod;
            Visited[vr] = true;
            Q.push(vr);

            if (vr == dest)
                return true;
        }
    }
    return false;
}
int Min_Cap_Lant(int sursa, int dest, auto& capacity, auto& flux) {
    int c = dest, cap_min = inf;
    while (c != sursa) {
        int tc = Tata[c];
        if (tc >= 0) {
            cap_min = min(cap_min, capacity[tc][c] - flux[tc][c]);
        }
        else {
            cap_min = min(cap_min, flux[c][abs(tc)]);
        }

        c = abs(tc);
    }

    return cap_min;
}
void Upd_Flux_Lant(int sursa, int dest, int cap_min, auto& flux) {
    int c = dest;

    while (c != sursa) {
        int tc = Tata[c];

        if (tc >= 0) {
            flux[tc][c] += cap_min;
        }
        else {
            flux[c][abs(tc)] -= cap_min;
        }

        c = abs(tc);
    }
}

int main()
{
    int n, m;
    in >> n >> m;

    vector<vector<int>> vecini, vecini_rev;
    vector<vector<int>> flux, capacitate;
    vecini = vecini_rev = vector<vector<int>> (n);
    flux = capacitate = vector<vector<int>> (n, vector<int> (n, 0));

    for (int i = 0; i < m; i++) {
        int x, y, cap;
        in >> x >> y >> cap;
        x--; y--;

        capacitate[x][y] = cap;
        vecini[x].push_back(y);
        vecini_rev[y].push_back(x);
    }

    /*
        Cat timp bfs-ul din surs in destinatie gaseste un drum
        Determinam capacitatea minima (vectorul de tati) -> min
        Pe acelasi drum modificam fluxul cu min
    */
    int sursa = 0, dest = n - 1, flux_max = 0;

    while (Find_BFS(sursa, dest, vecini, vecini_rev, flux, capacitate)) {
        int cap_min = Min_Cap_Lant(sursa, dest, capacitate, flux);
        Upd_Flux_Lant(sursa, dest, cap_min, flux);

        flux_max += cap_min;
    }

    out << flux_max << "\n";





    return 0;
}
