#include <bits/stdc++.h>
using namespace std;
ifstream input("maxflow.in");
ofstream output("maxflow.out");
const int nMax = 1005, INF = 0x3f3f3f3f;
int n, m, u, v, cost;
vector<int> adj[nMax];
bool viz[nMax];
int c[nMax][nMax], f[nMax][nMax];
int flow;
int tat[nMax];
queue <int> q;


bool bfs(int start)
{
    q.push(start);
    memset(viz, 0, sizeof(viz));
    viz[start] = 1;

    while(!q.empty())
    {
        int node = q.front();
        q.pop();

        for(auto it: adj[node])
        {
            if(viz[it] || c[node][it] == f[node][it])
                continue;
            viz[it] = 1;
            q.push(it);
            tat[it] = node;
        }
    }
    return viz[n];
}

int main()
{
    input >> n >> m;
    while(m--)
        input >> u >> v >> cost,
        adj[u].push_back(v),
        adj[v].push_back(u),
        c[u][v] += cost;
    while(bfs(1))
    {
        for(auto it: adj[n])
        {
            if(!viz[it] || c[it][n] == f[it][n])
                continue;
            tat[n] = it;
            int fmin = INF;

            for(int node = n; node != 1; node = tat[node])
            {
                fmin = min(fmin, c[tat[node]][node] - f[tat[node]][node]);
            }
            if(fmin == 0)
                continue;
            for(int node = n; node !=1; node =tat[node])
            {
                f[tat[node]][node] += fmin;
                f[node][tat[node]] -= fmin;
            }
            flow += fmin;
        }
    }

    output << flow;
}
