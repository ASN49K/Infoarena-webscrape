#include <bits/stdc++.h>

using namespace std;

ifstream in("maxflow.in");
ofstream out("maxflow.out");

const int d = 1005;

int n,m, srs, dest;
vector<int> vec[d];
queue<int> q;
int viz[d], tata[d];
long long int g[d][d];

int BFS(){
    for(int i = 1; i <= n; i++){
        viz[i] = 0;
    }
    viz[srs] = 1;
    q.push(srs);
    tata[srs] = -1;

    while(!q.empty()){
        int x = q.front();
        q.pop();
        if(x == dest)
        {
            continue;
        }
        for(auto y:vec[x]){
            if (g[x][y] > 0 && !viz[y]) {
                viz[y] = 1;
                tata[y] = x;
                q.push(y);
            }
        }
    }
    return viz[dest];
}

int main() {
    in >> n >> m;
    int x, y, c;
    srs = 1;
    dest = n;
    while (m--) {
        in >> x >> y >> c;
        vec[x].push_back(y);
        vec[y].push_back(x);
        g[x][y] = c;
    }
    long long int mf = 0;
    long long int minim = LONG_LONG_MAX;
    while (BFS()){

        for(auto y:vec[dest]){
            minim = LONG_LONG_MAX;
            tata[dest] = y;
            for(int j = dest; j != srs; j = tata[j]){
                minim = min(minim, g[tata[j]][j]);
            }

            mf += minim;

            for(int j = dest; j != srs; j = tata[j]){
                g[tata[j]][j] -= minim;
                g[j][tata[j]] += minim;
            }
        }
    }
    out << mf;
    return 0;
}