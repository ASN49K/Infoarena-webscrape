#include <cmath>
#include <functional>
#include <fstream>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <set>
#include <map>
#include <list>
#include <time.h>
#include <math.h>
#include <random>
#include <deque>
#include <cassert>
#include <queue>
#include <unordered_map>
#include <unordered_set>
#include <iomanip>
#include <bitset>
#include <sstream>
#include <stack>
#include <chrono>
#include <cstring>
#include <numeric>
using namespace std;
const int INF = (int)1e9 + 7;
struct Flow {
	struct Edge {
		int to, cap, nex;
	};
	int n;
	int flow;
	vector<int> firsts;
	vector<int> ptr;
	vector<Edge> edges;
	vector<int> level;
	vector<int> q;
	void init(int nn) {
		n = nn;
		firsts.clear();
		firsts.resize(n, -1);
		edges.clear();
		flow = 0;
	}
	void addedge(int a, int b, int c) {
		a--;
		b--;
		assert(0 <= a && a < n);
		assert(0 <= b && b < n);
		edges.push_back({ b, c, firsts[a] });
		edges.push_back({ a, 0, firsts[b] });
		firsts[a] = (int)edges.size() - 2;
		firsts[b] = (int)edges.size() - 1;
	}
	int dfs(int a, int cap) {
		if (cap == 0 || a == n - 1) {
			return cap;
		}
		while (ptr[a] != -1) {
			int i = ptr[a];
			int b = edges[i].to;
			if (edges[i].cap > 0 && level[b] == 1 + level[a]) {
				int x = dfs(b, min(cap, edges[i].cap));
				if (x) {
					edges[i].cap -= x;
					edges[i ^ 1].cap += x;
					return x;
				}
			}
			ptr[a] = edges[ptr[a]].nex;
		}
		return 0;
	}
	bool pump() {
		level.clear();
		level.resize(n, -1);
		level[0] = 0;
		q.clear();
		q.push_back(0);
		for (int iter = 0; iter < (int)q.size(); iter++) {
			int a = q[iter];
			for (int i = firsts[a]; i != -1; i = edges[i].nex) {
				int b = edges[i].to;
				if (edges[i].cap > 0 && level[b] == -1) {
					level[b] = 1 + level[a];
					q.push_back(b);
				}
			}
		}
		if (level[n - 1] == -1) {
			return 0;
		}
		ptr.clear();
		ptr.resize(n);
		for (int i = 0; i < n; i++) {
			ptr[i] = firsts[i];
		}
		int gain;
		do {
			gain = dfs(0, INF);
			flow += gain;
		} while (gain > 0);
		return 1;
	}
};
signed main() {
#ifdef ONPC
	FILE* stream;
	freopen_s(&stream, "input.txt", "r", stdin);
#else
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	freopen("maxflow.in", "r", stdin);
	freopen("maxflow.out", "w", stdout);
#endif
	Flow f;
	int n, m;
	cin >> n >> m;
	f.init(n);
	for (int i = 1; i <= m; i++) {
		int a, b, c;
		cin >> a >> b >> c;
		f.addedge(a, b, c);
	}
	do {} while (f.pump());
	cout << f.flow << "\n";
	return 0;
}