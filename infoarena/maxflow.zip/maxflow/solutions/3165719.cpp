#include <fstream>
#include <queue>
#include <cstring>

using namespace std;
const int NMAX = 1002;
const int INF = 2e9 + 2;

ifstream cin("maxflow.in");
ofstream cout("maxflow.out");

int v[NMAX][NMAX], n; ///matricea de adicenta
int d[NMAX];          ///dist nodului de la sursa
int last[NMAX];       ///ultimul "copil" (vecin actually) prin care am trecut ult data

bool bfs()
{
    ///de fapt, in bfs ce facem e ca refacem tot traseul distantelor de fiecare
    ///data cand mai parcurgem tot
    for(int i = 1; i <= n; i++) ///dam reset ca o luam de la capat
    {
        last[i] = 1;    ///initial, lastul fiecarui nr e 1 ca incep toate de la sursa
        d[i] = 0;
    }
    queue < int > q; ///ca in bfs-ul clasic, cu o coada
    q.push(1); ///incepem cu sursa

    while(!q.empty())
    {
        int u = q.front(); ///toti vecinii lui
        q.pop();
        if(u == n) ///dc am ajuns la dest
            continue;
        for(int i = 2; i <= n; i++) ///accesam toti vecinii
        {
            if(d[i] == 0 && v[u][i] > 0) ///dc nu am mai accesat cat de departe e pana acm si avem un vecin
            {
                d[i] = d[u] + 1; ///atunci updatam dist
                q.push(i); ///si bagam ca sa accesam si vecinii, la randul LUI
            }
        }
    }
    return d[n];
}

int dfs(int nr, int flow)
{
    if(nr == n) ///am ajuns la dest
        return flow;
    while(last[nr] <= n) ///cat timp ult copil NU e dest
    {
        int u = last[nr]; ///il accesam
        if(v[nr][u] > 0 && d[u] == d[nr] + 1) ///dc avem un vecin cu capacitate valida si coincid si dist cu felul de l-am verificat in bfs
        {
            int sol = dfs(u, min(flow, v[nr][u])); ///pusham cat putem
            if(sol != 0) ///dc, CHIAR am gasit cv, updatam
            {
                v[nr][u] -= sol;    ///scadem din cel original
                v[u][nr] += sol;    ///si adunam in vectorul rezidual
                return sol;         ///returnam ca am gasit cv
            }
        }
        last[nr]++; ///il tot crestem ca sa gasim un rasp valid
    }
    return 0;
}
int main()
{
    int m, a, b, c, maxx = 0;
    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        cin >> a >> b >> c;
        v[a][b] = c;
    }
    while(bfs()) ///cat timp mai gasim un mod != 0 pana la destinatie, de fapt
    {
        while(1)
        {
            int x = dfs(1, INF);
            if(x != 0)
                maxx += x;
            else
                break;
        }
    }
    cout << maxx;
    return 0;
}
