#include<bits/stdc++.h>
using namespace std;
ifstream F("maxflow.in");
ofstream G("maxflow.out");
#define N 1001
vector<int> g[N];
int i,j,n,y,l,k,e[N][N],b[N],c[N],t;
int main()
{
    for(F>>n>>k;F>>i>>j>>l;g[i].push_back(j),g[j].push_back(i),e[i][j]=l);
    for(;;) {
        for(memset(b,0,sizeof b),j=c[0]=c[1]=1;j<=c[0]&&!b[n];++j)
        	for(k=c[j],t=g[k].size(),i=0;i<t;++i)
        		if(!b[g[k][i]]&&e[k][g[k][i]])
            		b[c[++c[0]]=g[k][i]]=k;
        if(!b[n])
            return G<<y,0;
        for(t=g[n].size(),i=0;i<t;++i)
        	if(b[g[n][i]]&&e[g[n][i]][n]) {
            	for(l=2e5,b[n]=j=k=g[n][i];j>1;l=min(l,e[b[j]][j]),j=b[j]);
            	for(l=min(l,e[k][n]),y+=l,j=n;j>1;e[b[j]][j]-=l,e[j][b[j]]+=l,j=b[j]);
        	}
    }
}
