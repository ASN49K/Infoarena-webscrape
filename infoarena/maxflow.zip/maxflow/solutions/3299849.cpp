#include <iostream>
#include <vector>

using namespace std;

vector<pair<int,int> > flux[1000];
vector<pair<int,int> > cap[1000];

int cnt;

bool drum(int s,int t)
{
    queue<int> Q;
    Q.push(s);
    while(Q.empty()!=1)///fac un bfs de la s la t
    {
        int pct=Q.top();
        if(pct==t)///daca am gasit drum return 1;
        {
            ///aduag minimul
            return 1;
        }

        Q.pop();
    }

    /// altfel, dupa ce incerc tot, return 0;
    return 0;
}

int main()
{
    int n,m,a,b,c;
    cin>>n>>m;
    for(int i=0; i<m; i++)
    {
        cin>>a>>b>>c;
        fluxp[a].push_back({b,0});
        fluxn[b].push_back({a,0});
        cap[a].push_back({b,c});
    }
    ///de la nodu unu la nodu n
    while(drum(1,n)==1);

    cout<<sum;
    return 0;
}
