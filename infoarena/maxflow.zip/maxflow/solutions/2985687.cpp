#include <fstream>
#include <bits/stdc++.h>
#define cin fin
#define cout fout
using namespace std;
ifstream cin("maxflow.in");
ofstream cout("maxflow.out");
vector<int>G[1008];
map<pair<int,int>,int>mapp;
int n,m,i,a,b,c,x,nvl[1008],sur,finn,ras;
void bfs(int nod)
{
    for(i=1;i<=n;i++)
    {
        nvl[i]=-1;
    }
    queue<int>Q;
    Q.push(nod);
    nvl[nod]=1;
    while(!Q.empty())
    {
        int k=Q.front();
        Q.pop();
        for(auto i:G[k])
        {
            if(nvl[i]==-1 && mapp[{k,i}]>0)
            {
                nvl[i]=nvl[k]+1;
                Q.push(i);
            }
        }
    }
}
int dfs(int nod, int minn)
{
    if(nod==finn || minn==0)
        return minn;
    for(auto i:G[nod])
    {
        if(mapp[{nod,i}]>0 && nvl[nod]+1==nvl[i])
        {
             x=dfs(i,min(minn,mapp[{nod,i}]));
             if(x>0)
             {
                 mapp[{nod,i}]-=x;
                 mapp[{i,nod}]+x;
                 return x;
             }
        }
    }
    return 0;
}
bool flux()
{
    bfs(sur);
    if(nvl[finn]==-1)
    {
        return 0;
    }
    else
    {
        int val=0;
        while(true)
        {
            x=dfs(1,1e9);
            if(x==0)
                break;
            val+=x;
        }
        ras+=val;
        return (val!=0);
    }
}
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cin>>n;
    cin>>m;
    for(i=1;i<=m;i++)
    {
        cin>>a>>b>>c;
        G[a].push_back(b);
        mapp[{a,b}]=c;
        if(mapp[{a,b}]==0)
            G[b].push_back(a);
    }
    sur=1;
    finn=n;
    while(flux());
    cout<<ras;
    return 0;
}
