// Ilie Dumitru
#include<cstdio>
#include<vector>
#include<bitset>
const int NMAX=1005, MAXPUSH=110000;

struct edge
{
	int node, left, idxOther;
};

int N, M;
std::vector<edge> G[NMAX];
int ans;
std::bitset<NMAX> vis;

void addEdge(int u, int v, int w)
{
	G[u].push_back({v, w, (int)G[v].size()});
	G[v].push_back({u, 0, (int)G[u].size()-1});
}

void useEdge(edge& e, int flow)
{
	e.left-=flow;
	G[e.node][e.idxOther].left+=flow;
}

int dfs(int node, int target, int maxPush=MAXPUSH)
{
	if(node==target)
		return maxPush;

	int i, x;

	vis[node]=1;
	for(i=0;i<(int)G[node].size();++i)
	{
		if(!vis[G[node][i].node] && G[node][i].left)
		{
			x=dfs(G[node][i].node, target, std::min(maxPush, G[node][i].left));
			if(x)
			{
				useEdge(G[node][i], x);
				vis[node]=0;
				return x;
			}
		}
	}
	vis[node]=0;

	return 0;
}

bool fordFulkerson(int source, int target)
{
	int x=dfs(source, target);

	ans+=x;
	return x;
}

int main()
{
	FILE* f=fopen("maxflow.in", "r"), *g=fopen("maxflow.out", "w");
	int i, a, b, c;

	fscanf(f, "%d%d", &N, &M);
	for(i=0;i<M;++i)
	{
		fscanf(f, "%d%d%d", &a, &b, &c);
		addEdge(a-1, b-1, c);
	}

	while(fordFulkerson(0, N-1));

    fprintf(g, "%d\n", ans);

	fclose(f);
	fclose(g);
	return 0;
}