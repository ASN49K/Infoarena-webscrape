#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>
#include <queue>

using namespace std;
ifstream in("maxflow.in");
ofstream out("maxflow.out");

int n, m, x, y, cap, total;
vector<int> adj[1001];
int f[1001][1001];
int c[1001][1001];
int p[1001];
bool vis[1001];

void bfs() {
    memset(vis, false, sizeof(vis));

    queue<int> q;
    vis[1] = 1;
    q.push(1);

    while (!q.empty()) {
        int nod = q.front();
        q.pop();
        if (nod == n)
            continue;

        for (auto it : adj[nod]) {
            if (c[nod][it] != f[nod][it] && vis[it] == 0) {
                p[it] = nod;
                vis[it] = 1;
                q.push(it);
            }
        }
    }

}

int main()
{
    in >> n >> m;
    for (int i = 1; i <= m; i++) {
        in >> x >> y >> cap;
        adj[x].push_back(y);
        adj[y].push_back(x);
        c[x][y] = cap;
    }

    while (1) {

        bfs();
        if (vis[n] == 0)
            break;

        for (auto it : adj[n]) {
            if (vis[it] == 0 || f[it][n] == c[it][n])
                continue;

            int rc = 1e9;

            int nod = n;
            do {
                rc = min(rc, c[p[nod]][nod] - f[p[nod]][nod]);
                nod = p[nod];
            } while (nod != 1);

            if (!rc)
                continue;

            nod = n;
            do {
                f[nod][p[nod]] -= rc;
                f[p[nod]][nod] += rc;
                nod = p[nod];
            } while (nod != 1);

            total += rc;
        }
    }

    out << total << '\n';

    return 0;
}
