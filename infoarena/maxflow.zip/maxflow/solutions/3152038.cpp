#include <bits/stdc++.h>

using namespace std;
ifstream in("maxflow.in");
ofstream out("maxflow.out");
int n, m, x, y, cap, total;
vector<int> adj[1005];
int f[1005][1005];
int c[1005][1005];

vector<int> bfs(int node, int n) {
    queue<int> q;
    vector<int> ans;

    vector<int> d(n + 1, 1e9);
    vector<int> p(n + 1, -1);
    d[node] = 0;
    q.push(node);

    while (!q.empty()) {
        int nod = q.front();
        q.pop();

        for (auto it : adj[nod]) {
            if (c[nod][it] - f[nod][it] > 0 && d[it] > d[nod] + 1) {
                d[it] = d[nod] + 1;
                p[it] = nod;
                q.push(it);
            }
        }
    }
    if (d[n] == 1e9)
        return ans;

    int nod = n;
    do {
        ans.push_back(nod);
        nod = p[nod];
    } while (nod != -1);

    reverse(ans.begin(), ans.end());

    return ans;
}

int main()
{
    in >> n >> m;
    for (int i = 1; i <= m; i++) {
        in >> x >> y >> cap;
        adj[x].push_back(y);
        adj[y].push_back(x);
        c[x][y] = cap;
        c[y][x] = -cap;
    }

    while (1) {
        vector<int> path = bfs(1, n);
        if (path.size() == 0)
            break;

        int sz = path.size();
        int rc = 1e9;

        for (int i = 0; i < sz - 1; i++)
            rc = min(rc, c[path[i]][path[i + 1]] - f[path[i]][path[i + 1]]);

        for (int i = 0; i < sz - 1; i++) {
            f[path[i]][path[i + 1]] += rc;
            f[path[i + 1]][path[i]] -= rc;
        }

        total += rc;
    }

    out << total << '\n';

    return 0;
}
