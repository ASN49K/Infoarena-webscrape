#include <fstream>
#include <queue>

using namespace std;

priority_queue <int> q[101];


int main() {
	ifstream f("mergeheap.in");
	ofstream g("mergeheap.out");
	int n, op, x, nr = 0, mul, totMul;
	f >> totMul >> n;
	while(n--) {
		f >> op >> mul;
		if (op == 1) {
			f >> x;
			q[mul].push(x);
		}
		else {
			if (op == 2) {
				g << q[mul].top() << "\n";
				q[mul].pop();
			}
			else {
				f >> x;
				while (!q[x].empty()) {
					q[mul].push(q[x].top());
					q[x].pop();
				}
			}
		}
	}

	
	f.close();
	g.close();
	return 0;
}