#include <fstream>
#include <queue>
using namespace std;
ifstream f("mergeheap.in");
ofstream g("mergeheap.out");
priority_queue <int> q[101];
int n,m,C,i,x,y;
int main()
{
    f>>n>>m;
    for(i=1;i<=m;i++)
    {
        f>>C;
        if(C==1)
        {
            f>>x>>y;
            q[x].push(y);
        }
        else
        if(C==2)
        {
            f>>x;
            g<<q[x].top()<<'\n';
            q[x].pop();
        }
        else
        {
            if(q[y].size()>q[x].size())
                swap(q[x],q[y]);
            while(q[y].empty()==false)
            {
                q[x].push(q[y].top());
                q[y].pop();
            }
        }
    }
    return 0;
}
