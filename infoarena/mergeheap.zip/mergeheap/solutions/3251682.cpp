
#pragma region TEMPLATES

#include <bits/stdc++.h>
using namespace std;
typedef long long i64;
typedef unsigned long long u64;

const string file = "mergeheap";
void init() {
#ifdef DEBUG
    freopen( "in.txt",  "r", stdin);
#elif LOCAL
    freopen( "in.txt", "r", stdin);
    freopen("out.txt", "w", stdout);
#else
    cin.tie(0)->sync_with_stdio(0);
    if (!file.empty()) {
        freopen((file +  ".in").c_str(), "r", stdin);
        freopen((file + ".out").c_str(), "w", stdout);
    }
#endif
}

#ifndef LOCAL
    #define debug(...) 69420
    #define init_test(...) 69420
#else
void init_test(int t) {
    cerr << "\nTEST #" << t << "\n";
}
template<typename T>
void debug(T n) {
    cerr << n << "\n";
}
template<typename T, typename... Args>
void debug(T n, Args... args) {
    cerr << n << " ";
    debug(args...);
}
template<typename T>
void debug(const vector<T> &v) {
    for (const auto &it : v) {
        cerr << it << " ";
    }
    cerr << "\n";
}
#endif

void solve();
int main() {
    init();
    int t = 1;
    // cin >> t;
    for (int i = 1; i <= t; ++i) {
        init_test(i);
        solve();
    }
}

#pragma endregion TEMPLATES

void solve() {
    int N, Q;
    priority_queue<int> pq[105];

    cin >> N >> Q;
    while (Q--) {
        int t;
        cin >> t;
        if (t == 1) {
            int m, x;
            cin >> m >> x;
            pq[m].push(x);
        }
        else if (t == 2) {
            int m;
            cin >> m;
            cout << pq[m].top() << "\n";
            pq[m].pop();
        }
        else {
            int a, b;
            cin >> a >> b;
            if (pq[a].size() < pq[b].size()) {
                swap(pq[a], pq[b]);
            }
            while (!pq[b].empty()) {
                pq[a].push(pq[b].top());
                pq[b].pop();
            }
        }
    }
}