#include <fstream>
#include <iostream>
// biblioteca pt heap-uri mai smechere
#include <ext/pb_ds/priority_queue.hpp>

using namespace std;
using namespace __gnu_pbds;

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

typedef __gnu_pbds::priority_queue<int, less<int>, pairing_heap_tag> Heap;

Heap H[105]; 

int n, q;
int c, a, b;

int main() {
    fin >> n >> q;
    for(; q; --q) {
        fin >> c;
        if(c == 1) {
            fin >> a >> b;
            H[a].push(b);
        } else if (c == 2) {
            fin >> a;
            fout << H[a].top() << '\n';
            H[a].pop();
        } else {
            fin >> a >> b;
            H[a].join(H[b]); 
        }
    }
    fin.close();
    return 0;
}