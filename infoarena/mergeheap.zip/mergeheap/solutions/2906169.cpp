#include <iostream>
#include <fstream>
#include <queue>
using namespace std;
ifstream f("mergeheap.in");
ofstream g("mergeheap.out");
priority_queue<int> h[105];
int N,Q,operatie,a,b,i;
int main()
{
    f>>N>>Q;
    for(i=1; i<=Q; ++i)
    {
        f>>operatie;
        if(operatie==1)
        {
            f>>a>>b;
            h[a].push(b);
            break;
        }
        if(operatie==2)
        {
            f>>a;
            g<<h[a].top()<<'\n';
            h[a].pop();
            break;
        }
        if(operatie==3)
        {
            f>>a>>b;
            if(h[a].size()>h[b].size())
                swap(h[b],h[a]);
            while(!h[b].empty())
            {
                h[a].push(h[b].top());
                h[b].pop();
            }
        }
    }


return 0;
}
