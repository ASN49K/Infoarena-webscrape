#include <fstream>
#include <ext/pb_ds/priority_queue.hpp>

using namespace std;
const int nmax = 100;

__gnu_pbds::priority_queue < int, less < int >, __gnu_pbds::pairing_heap_tag > pq[nmax];

ifstream fin ( "mergeheap.in" );
ofstream fout ( "mergeheap.out" );

int main() {
    int q, tip, m, x, a, b;

    fin >> q;
    fin >> q;

    for ( int i = 0; i < q; i++ ) {
        fin >> tip;
        if ( tip == 1 ) {
            fin >> m >> x; m--;
            pq[m].push ( x );
        } else if ( tip == 2 ) {
            fin >> m; m--;
            fout << pq[m].top () << '\n';
            pq[m].pop ();
        } else {
            fin >> a >> b;
            a--, b--;
            pq[a].join ( pq[b] );
            pq[b].clear ();
        }
    }

    return 0;
}
