package org.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        try (Scanner scan = new Scanner(Files.newInputStream(Path.of("mergeheap.in"))); PrintWriter pw = new PrintWriter("mergeheap.out")) {
            List<PriorityQueue<Integer>> pq = new ArrayList<>();

            int N = scan.nextInt();

            for (int i = 0; i <= N; i++) {
                pq.add(new PriorityQueue<>(Collections.reverseOrder()));
            }
            int Q = scan.nextInt();

            for (int i = 0; i < Q; ++i) {
                int t = scan.nextInt();
                switch (t) {
                    case 1 -> {
                        int m = scan.nextInt();
                        int x = scan.nextInt();
                        pq.get(m).add(x);
                    }
                    case 2 -> {
                        int m = scan.nextInt();
                        pw.write(pq.get(m).poll() + "\n");
                    }
                    case 3 -> {
                        int a = scan.nextInt();
                        int b = scan.nextInt();
                        if (pq.get(a).size() < pq.get(b).size()) {
                            Collections.swap(pq, a, b);
                        }
                        while (!pq.get(b).isEmpty()) {
                            pq.get(a).add(pq.get(b).poll());
                            pq.get(b).poll();
                        }
                    }
                }
            }
        }
    }
}