#include <iostream>
#include <fstream>
#include <bits/stdc++.h>

using namespace std;

ifstream f ("mergeheap.in");
ofstream g ("mergeheap.out");

int main()
{

    int n,k;

    f >> n >> k;
    vector<priority_queue<int>> heaps(n+1, priority_queue<int>());
    for (int i = 0; i < k; i++)
    {
        int tip;
        f >> tip;
        switch (tip)
        {
            case 1:
            {
                int index;
                int val;
                f >> index >> val;

                heaps[index].push(val);
                break;
            }
            case 2:
                {
                    int index;
                    f >> index;

                    g << heaps[index].top() << '\n';
                    heaps[index].pop();
                    break;                }
            case 3:
                {
                    int i1, i2;
                    f >> i1, i2;

                    while(heaps[i2].size())
                    {
                        heaps[i1].push(heaps[i2].top());
                        heaps[i2].pop();
                    }
                    break;
                }
        }
    }

    return 0;
}
