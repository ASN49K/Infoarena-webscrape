#include<iostream>
#include <cstring>
#include <fstream>

using namespace std;

ifstream fin ("mergeheap.in");
ofstream fout("mergeheap.out");

class nod{
public:
    int cheie;
    nod *copil, *frate;

    nod(int val) : cheie(val), copil(NULL), frate(NULL){}
  //  ~nod(){}

};

class pairingHeap{
public:
    nod *radacina;

    nod *mergeHeap(nod *heap1, nod *heap2){
        if (!heap1){
            heap1 = heap2;
            return heap1;
        }
        if (!heap2){
            return heap1;
        }

        if (heap1->cheie < heap2->cheie){
            swap(heap1, heap2);
        }

        heap2->frate = heap1->copil;
        heap1->copil = heap2;

        return heap1;
    }

    nod *two_pass_merge(nod *nodd){
        if (!nodd or !nodd->frate){
            return nodd;
        }

        nod *heap1, *heap2, *heap_urm;
        heap1 = nodd;
        heap2 = nodd->frate;
        heap_urm = heap2->frate;
        heap1->frate = heap2->frate = NULL;

        return mergeHeap(mergeHeap(heap1, heap2), two_pass_merge(heap_urm));

    }

    pairingHeap() : radacina(NULL){}
    pairingHeap(int cheie){
        radacina = new nod(cheie);
    }
    pairingHeap(nod *nodd) : radacina(nodd){}

    int top(){
        return radacina->cheie;
    }

    void mergeHeap(pairingHeap heap){
        if (!radacina){
            radacina = heap.radacina;
            return;
        }
        if (!heap.radacina) return;

        if (radacina->cheie < heap.radacina->cheie){
            swap(radacina, heap.radacina);
        }

        heap.radacina->frate = radacina->copil;
        radacina->copil = heap.radacina;
        heap.radacina = NULL;


    }

    void push(int cheie){
        mergeHeap(pairingHeap(cheie));
    }
    void pop(){
        nod *buff = radacina;
        radacina = two_pass_merge(radacina->copil);

        delete buff;
    }
    void heap_union(pairingHeap &heap){
        mergeHeap(heap);
        heap.radacina = NULL;
    }
};

pairingHeap heaps[101];

int main()
{
    int n, m;
    fin>>n>>m;

    int cerinta, h, x, h1, h2;
    for (int i = 1; i <= m; i++){
        fin>>cerinta;

        if (cerinta == 1){
            fin>>h>>x;
            heaps[h].push(x);
        }
        else if (cerinta == 2){
            cin>>h;
            fout<<heaps[h].top()<<endl;
            heaps[h].pop();
        }
        else{
            fin>>h1>>h2;
            heaps[h1].heap_union(heaps[h2]);
        }
    }
}
