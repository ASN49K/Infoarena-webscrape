#include <fstream>
#include <queue>

using namespace std;

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

priority_queue<int> heap[101];
int n, q, op, i, a, b;

int main() {
    fin >> n >> q;

    for(i = 1; i <= q; ++i){
        fin >> op;
        switch(op){
            case 1:{
                fin >> a >> b;
                heap[a].push(b);
                break;
            }
            case 2:{
                fin >> a;
                fout << heap[a].top() << "\n";
                heap[a].pop();
                break;
            }
            case 3:{
                fin >> a >> b;
                if(heap[b].size() > heap[a].size()){
                    swap(heap[a], heap[b]);
                }

                while(heap[b].empty() == false){
                    heap[a].push(heap[b].top());
                    heap[b].pop();
                }
            }
        }
    }

    return 0;
}