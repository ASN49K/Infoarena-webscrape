#include <stdio.h>
#include <ext/pb_ds/priority_queue.hpp>

using namespace std;
const int nmax = 100;

__gnu_pbds::priority_queue < int, less < int >, __gnu_pbds::pairing_heap_tag > pq[nmax];

#define MAXLOG10 10
#define BUFSIZE (1 << 15)

FILE *fin, *fout;

int p10[MAXLOG10 + 1] = { 0, 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000 };
int rpos; char rbuf[BUFSIZE];
int wpos; char wbuf[BUFSIZE];

static inline void init_read () {
    rpos = BUFSIZE - 1;
}

static inline char get_char () {
    if ( ! ( rpos = ( rpos + 1 ) & ( BUFSIZE - 1 ) ) )
        fread ( rbuf, 1, BUFSIZE, fin );
    return rbuf[rpos];
}

int get_int () {
    int ch, nr = 0;
    while ( isspace( ch = get_char () ) );
    do
        nr = 10 * nr + ch - '0';
    while ( isdigit( ch = get_char () ) );

    return nr;
}

static inline void init_write () {
    wpos = 0;
}

static inline void print_char ( char ch ) {
    fputc ( ch, fout );
    return;
    wbuf[wpos] = ch;
    if ( ! ( wpos = ( wpos + 1 ) & ( BUFSIZE - 1 ) ) )
        fwrite ( wbuf, 1, BUFSIZE, fout );
}

void print_int ( int x ) {
    int i = MAXLOG10, cf;
    while ( p10[i] > x )
        i--;
    do {
        cf = '0';
        while ( p10[i] <= x ) {
            x -= p10[i];
            cf++;
        }
        print_char ( cf );
    } while ( --i > 0 );
}

static inline void print_last () {
    fwrite( wbuf, 1, wpos, fout );
}

int main() {

    int q, tip, m, x, a, b;

    fin = fopen ( "mergeheap.in", "r" );
    init_read ();

    fout = fopen ( "mergeheap.out", "w" );
    init_write ();

    get_int ();
    q = get_int ();

    for ( int i = 0; i < q; i++ ) {
        tip = get_int ();
        if ( tip == 1 ) {
            m = get_int () - 1, x = get_int ();
            pq[m].push ( x );
        } else if ( tip == 2 ) {
            m = get_int () - 1;
            print_int ( pq[m].top () );
            print_char ( '\n' );
            pq[m].pop ();
        } else {
            a = get_int () - 1, b = get_int () - 1;
            pq[a].join ( pq[b] );
            pq[b].clear ();
        }
    }

    print_last ();

    fclose ( fin );
    fclose ( fout );

    return 0;
}
