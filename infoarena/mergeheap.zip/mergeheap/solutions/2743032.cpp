#include <bits/stdc++.h>
#include <ext/pb_ds/priority_queue.hpp>
using namespace std;
using namespace __gnu_pbds;

int main() {
	ifstream cin("mergeheap.in");
	ofstream cout("mergeheap.out");
	int n, q, x, y, z;
	cin >> n >> q;
	vector<__gnu_pbds::priority_queue<int, less<int>, pairing_heap_tag, allocator<char>>> Q(n + 1);
	while (q--) {
		cin >> x >> y;
		if (x == 1) {
			cin >> z;
			Q[y].push(z);
		}
		else if (x == 2) {
			cout << Q[y].top() << '\n';
			Q[y].pop();
		}
		else {
			cin >> z;
			Q[y].join(Q[z]);
		}
	}
}