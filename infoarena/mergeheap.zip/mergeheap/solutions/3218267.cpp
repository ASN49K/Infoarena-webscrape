#include <bits/stdc++.h>
using namespace std;
#define ll                 long long 
#define all(v)             v.begin(), v.end()
ll ceil2(ll a, ll b) {
return (a + b - 1) / b;
}
// #include <ext/pb_ds/assoc_container.hpp> 
// #include <ext/pb_ds/tree_policy.hpp> 
// using namespace __gnu_pbds; 
// #define ordered_set tree<int, null_type,less<int>, rb_tree_tag,tree_order_statistics_node_update> 

#define mod 1000000001;



void solve(){
    ll n, q;cin>>n>>q;
    vector< multiset<ll, greater<>> > v(n+1);
    while(q--){
        ll a, b;cin>>a>>b;
        if(a==1){
            ll x;cin>>x;
            v[b].insert(x);
        }
        else if(a==2){
            cout<<*v[b].begin()<<"\n";
            v[b].erase(v[b].begin());
            // for(auto x:v[b]){
            //     cout<<x<<" ";
            // }
        }
        else{
            ll x;cin>>x;
            v[b].insert(v[x].begin(), v[x].end());
            v[x].clear();
        }

    }
}


int main(){
    freopen("mergeheap.in", "rt", stdin);
	freopen("mergeheap.out", "wt", stdout);
   ios_base::sync_with_stdio(false); cin.tie(NULL);
//    ll t;cin>>t;while(t--){solve();cout<<endl;}
    solve();
}