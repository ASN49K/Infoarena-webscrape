#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

const int MAXN = 105;

struct Node {
    vector<int> vals;
    bool operator <(const Node& other) const {
        return vals[0] < other.vals[0];
    }
};

struct MergeHeap {
    priority_queue<Node> q;
    int size;

    void insert(int x) {
        Node node;
        node.vals.push_back(x);
        q.push(node);
        size++;
    }

    void merge(MergeHeap& other) {
        while (!other.q.empty()) {
            Node node = other.q.top();
            q.push(node);
            other.q.pop();
        }
        size += other.size;
    }

    int getMax() {
        Node node = q.top();
        int res = node.vals[0];
        node.vals.erase(node.vals.begin());
        if (node.vals.empty()) {
            q.pop();
        } else {
            q.pop();
            q.push(node);
        }
        size--;
        return res;
    }
};

int main() {
    ifstream fin("mergeheap.in");
    ofstream fout("mergeheap.out");

    int n, q;
    fin >> n >> q;
    MergeHeap heaps[MAXN];

    for (int i = 1; i <= q; i++) {
        int type, val1, val2;
        fin >> type;
        if (type == 1) {
            fin >> val1 >> val2;
            heaps[val1].insert(val2);
        } else if (type == 2) {
            fin >> val1;
            int res = heaps[val1].getMax();
            fout << res << "\n";
        } else {
            fin >> val1 >> val2;
            heaps[val1].merge(heaps[val2]);
        }
    }

    fin.close();
    fout.close();
    return 0;
}
