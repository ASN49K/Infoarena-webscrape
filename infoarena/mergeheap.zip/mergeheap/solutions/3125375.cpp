#include <iostream>
#include<fstream>

using namespace std;

ifstream f("mergeheap.in");
ofstream g("mergeheap.out");

struct Nod
{
    int valoare;
    Nod* copil;
    Nod* frate;
};

Nod* inserare(Nod* a, int x)
{
    if(a == NULL){
        a = new Nod;
        a->valoare = x;
        a->copil = NULL;
        a->frate = NULL;
        return a;
    }

    else{
        Nod* b = new Nod;
        b->valoare = x;
        b->copil = NULL;
        b->frate = NULL;
        if(a->valoare > b->valoare){
            b->frate = a->copil;
            a->copil = b;
            return a;
        }
        else{
            b->copil = a;
            return b;
        }
    }
}

Nod* reuniune(Nod* a, Nod* b)
{
    if(a == NULL)
        return b;
    else if(b == NULL)
        return a;
    else if(a->valoare > b->valoare){
        b->frate = a->copil;
        a->copil = b;
        return a;
    }
    else{
        a->frate = b->copil;
        b->copil = a;
        return b;
    }
}

int stergere_max(Nod* &a)
{
    int maxim = a->valoare;
    Nod* rez = a->copil;
    Nod* b = rez->frate;
    Nod* aux = new Nod;
    while(b != NULL){
        aux->valoare = b->valoare;
        aux->copil = b->copil;
        aux->frate = b->frate;
        rez = reuniune(rez, aux);
        b = b->frate;
        }
    a = rez;
    return maxim;
}

int main()
{
    Nod* a[1000];
    int n, q;
    f>>n>>q;
    for(int i=1; i<=n; i++)
        a[i] = NULL;
    for(int i=0; i<q; i++){
        //cout<<"a"<<endl;
        int j, k, m;
        f>>j;
        if(j == 2){
            f>>k;
            g<<stergere_max(a[k])<<endl;
        }
        else{
            f>>k>>m;
            if(j == 1)
                a[k] = inserare(a[k], m);
            else a[k] = reuniune(a[k], a[m]);
        }
    }
//    Nod* a = NULL;
//    Nod* b = NULL;
//    a = inserare(a, 122);
//    a = inserare(a, 42);
//    a = inserare(a, 53);
//    b = inserare(b, 1);
//    b = inserare(b, 16);
//    a = reuniune(a, b);

//    cout<<a->valoare<<endl;
//    cout<<stergere_max(a)<<endl;
//    cout<<a->valoare;

    return 0;
}
