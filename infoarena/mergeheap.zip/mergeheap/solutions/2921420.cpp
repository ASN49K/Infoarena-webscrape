#include <bits/stdc++.h>
#pragma GCC optimize("Ofast")
using namespace std;
ifstream in("mergeheap.in");
ofstream out("mergeheap.out");
priority_queue <int> s[101]; 
int reali[101];
int main()
{
    int n,m,i,t,a,b;
    in>>n>>m;
    for(i=1;i<=n;i++)
        reali[i]=i;
    for(i=1;i<=m;i++)
    {
        in>>t;
        if(t==1)
        {
            in>>a>>b;
            s[reali[a]].push(b);
        }
        else if(t==2)
        {
            in>>a;
            out<<s[reali[a]].top()<<'\n';
            s[reali[a]].pop();
        }
        else
        {
            in>>a>>b;
            if(s[reali[a]].size()<s[reali[b]].size())
                swap(reali[a],reali[b]);
            while(s[reali[b]].size())
                {
                    s[reali[a]].push(s[reali[b]].top());
                    s[reali[b]].pop();
                }
        }
    }
    return 0;
}