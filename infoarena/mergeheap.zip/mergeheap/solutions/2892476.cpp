#include <bits/stdc++.h>

#define MAX_N 100

using namespace std;

priority_queue <int> pq[MAX_N];

int main() {
    ifstream cin( "mergeheap.in" );
    ofstream cout( "mergeheap.out" );

    int n, m, tip, p, q, x;

    cin >> n >> m;
    while ( m-- ) {
        cin >> tip;

        if ( tip == 1 ) {
            cin >> p >> x;
            p--;
            pq[p].push( x );
        } else if ( tip == 2 ) {
            cin >> p;
            p--;
            cout << pq[p].top() << "\n";
            pq[p].pop();
        } else {
            cin >> p >> q;
            p--;
            q--;

            while ( !pq[q].empty() ) {
                pq[p].push( pq[q].top() );
                pq[q].pop();
            }
        }
    }

    return 0;
}
