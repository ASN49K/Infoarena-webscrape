// curiozitate: swap cu random???
#include <iostream>
#include <fstream>
#include <queue>

#include <random>
#include <time.h>
#include <chrono>

using namespace std;

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

const int NMAX = 100;

priority_queue <int> pq[NMAX + 1];

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int main(){

    int n, q;
    fin >> n >> q;

    while(q--){
        int type;
        fin >> type;

        if(type == 1){
            int m, x;
            fin >> m >> x;
            pq[m].push(x);
        }else if(type == 2){
            int m;
            fin >> m;
            fout << pq[m].top() << '\n';
            pq[m].pop();
        }else{
            int a, b;
            fin >> a >> b;
            
            if((int)pq[a].size() < (int)pq[b].size()){
                swap(pq[a], pq[b])
            }

            while(!pq[b].empty()){
                pq[a].push(pq[b].top());
                pq[b].pop();
            }
        }
    }

    return 0;
}