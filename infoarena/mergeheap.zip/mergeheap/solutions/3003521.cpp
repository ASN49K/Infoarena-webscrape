#include <iostream>
#include <set>
#include <fstream>

using namespace std;

ifstream f ("mergeheap.in");
ofstream g ("mergeheap.out");
multiset <int> s[105];
multiset <int> :: iterator it;

int n , q , c , i , m , x , m1 , m2;

int main()
{
    f >> n >> q;
    for (int i = 1 ; i <= q ; i++)
    {
        f >> c;
        if (c == 1)
        {
            f >> m >> x;
            s[m].insert (x);
        }
        else
            if (c == 2)
        {
            f >> m;
            it = s[m].end();
            it--;
            g << *it << '\n';
            s[m].erase (it);
        }
        else
        {
            f >> m1 >> m2;
            it = s[m2].begin();
            while (it != s[m2].end())
            {
                s[m1].insert (*it);
                ++it;
            }
            s[m2].clear();
        }
    }
    return 0;
}
