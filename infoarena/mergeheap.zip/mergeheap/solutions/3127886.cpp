#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;
ifstream f("mergeheap.in");
ofstream g("mergeheap.out");

class node
{
public:
	int val;
	node* copil;
	node* frate;
	node()
	{
		val = -1;
		copil = NULL;
		frate = NULL;
	}
	node(int val1)
	{
		val = val1;
		copil = NULL;
		frate = NULL;
	}
};
class PairingHeap
{
	node* root;
public:
	PairingHeap()
	{
		root = NULL;
	}
	PairingHeap(int val1)
	{
		root = new node(val1);
	}
	int get_max()
	{
		return root->val;
	}
	node* merge(node* nod1, node* nod2)
	{
		if (nod2 == nullptr)
		{
			return nod1;
		}
		if (nod1 == nullptr)
		{
			nod1 = nod2;			return nod2;
		}
		if (nod2->val > nod1->val)
		{
			swap(nod1, nod2);
		}
		nod2->frate = nod1->copil;
		nod1->copil = nod2;
		return nod1;
	}
	node* twopasi(node* nod)
	{
		if (nod != NULL && nod->frate!=NULL)
		{
			node* nod1, * nod2, * helpernode;
			nod1 = nod;
			nod2 = nod->frate;
			helpernode = nod2->frate;
			nod1->frate = NULL;
			nod2->frate = NULL;
			return merge(merge(nod1, nod2), twopasi(helpernode));
		}
		return NULL;
	}
	void merge(PairingHeap h)
	{
		if (root->val < h.root->val)
			swap(root, h.root);
		if (h.root == NULL)
			return;
		if (root == NULL)
		{		root = h.root;
		return;
	}
		h.root->frate = root->copil;
		root->copil = h.root;
		h.root = NULL;
	}
	void insert(int val1)
	{
		merge(PairingHeap(val1));
	}
	void delete_root()
	{
		root = twopasi(root->copil);
	}
	void reuniune(PairingHeap *h)
	{
		root = merge(root, h->root);
		h->root = NULL;
	}
};

int main()
{
	int n, q;
	f >> n;
	PairingHeap h[101];
	f >> q;
	for (int i = 1;i <= q;i++)
	{
		int operatie, m, x, y;
		f >> operatie;
		if (operatie == 1)
		{
			f >> m >> x;
			h[m].insert(x);
		}
		if (operatie == 2)
		{
			f >> m;
			cout<< h[m].get_max() << endl;
			g << h[m].get_max() << endl;
			h[m].delete_root();
		}
		if (operatie == 3)
		{
			f >> x >> y;
			h[x].reuniune(&h[y]);
		}
	}
	return 0;
}