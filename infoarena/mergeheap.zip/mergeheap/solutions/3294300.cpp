#include <bits/stdc++.h>
#define VMAX 102
#define INF 2000000000
using namespace std;
ifstream fin ("mergeheap.in");
ofstream fout ("mergeheap.out");

priority_queue<int> pq[VMAX];

int main()
{
    int n,m,i,j,k,t,q,nr,minim,maxim,suma;
    fin>>n>>t;
    for(q=1;q<=t;q++)
    {
        fin>>i>>j;
        if(i==1)
        {
            fin>>k;
            pq[j].push(k);
        }
        else if(i==2)
        {
            fout<<pq[j].top()<<'\n';
            pq[j].pop();
        }
        else
        {
            fin>>k;
            if(pq[k].size()>pq[j].size())
                swap(pq[j],pq[k]);
            while(!pq[k].empty())
            {
                pq[j].push(pq[k].top());
                pq[k].pop();
            }
        }
    }


    return 0;
}
