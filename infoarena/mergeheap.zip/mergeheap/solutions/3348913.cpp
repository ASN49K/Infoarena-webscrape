#include <queue>
#include <fstream>
#include <set>
#include <vector>
using namespace std;

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

priority_queue<int> pq[101];



int main () {
    int n, q;
    fin >> n >> q;
    for(int i {1}; i <= q; ++i) {
        int caz;
        fin >> caz;
        switch(caz) {
            case 1:
                int x, m;
                fin >> m >> x;
                pq[m].push(x);
                break;
            case 2:
                int f;
                fin >> f;
                fout << pq[f].top() << '\n';
                pq[f].pop();
                break;
                
            case 3:
                int a,b;
                fin >> a >> b;
                if(pq[a].size() < pq[b].size()){
                    swap(pq[a], pq[b]);
                }
                
                while(!pq[b].empty()) {
                    pq[a].push(pq[b].top());
                    pq[b].pop();
                    
                }
                break;
           
            
        }
            
    }
    
    
    
    
    

    
    
}





