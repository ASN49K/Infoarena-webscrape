#include <fstream>
#include <queue>

using namespace std;

ifstream in("mergeheap.in");
ofstream out("mergeheap.out");
int n, q;
priority_queue<int> pq[105];

int main()
{
    in>>n>>q;

    int a, b, c;
    while(q--)
    {
        in>>a;

        if(a == 1)
        {
            in>>b>>c;

            pq[b].push(c);
        }
        else if(a == 2)
        {
            in>>b;

            out<<pq[b].top()<<'\n';
            pq[b].pop();
        }
        else
        {
            in>>b>>c;

            if(pq[c].size() <= pq[b].size())
            {
                while(!pq[c].empty())
                {
                    pq[b].push(pq[c].top());
                    pq[c].pop();
                }
            }
            else
            {
                while(!pq[b].empty())
                {
                    pq[c].push(pq[b].top());
                    pq[b].pop();
                }

                pq[b] = pq[c];

                while(!pq[c].empty())
                {
                    pq[c].pop();
                }
            }
        }
    }

    return 0;
}
