#include<iostream>
#include<fstream>
#include<vector>

using namespace std;

ifstream in("mergeheap.in");
ofstream out("mergeheap.out");


struct node {
    int value;
    node *next_sibling, *left_child;

    explicit node(int _value) : value(_value), next_sibling(nullptr), left_child(nullptr) {

    }

    void insert(node *other) {
        if (left_child == nullptr) {
            left_child = other;
        } else {
            other->next_sibling = left_child;
            left_child = other;
        }
    }
};

node *merge(node *a, node *b) {
    if (a == nullptr) {
        return b;
    }
    if (b == nullptr) {
        return a;
    }
    if (a->value > b->value) {
        a->insert(b);
        return a;
    } else {
        b->insert(a);
        return b;
    }
}

node *two_pass_merge(node *x) {
    if (x == nullptr || x->next_sibling == nullptr) {
        return x;
    } else {
        node *a = x;
        node *b = x->next_sibling;
        node *c = x->next_sibling->next_sibling;
        a->next_sibling = nullptr;
        b->next_sibling = nullptr;
        return merge(merge(a, b), two_pass_merge(c));
    }
}

node *delete_max(node *x) {
    return two_pass_merge(x->left_child);
}

int n, q;
vector<node *> sets;

void read() {
    in >> n >> q;
    sets.resize(n + 1, nullptr);
}


void query_insert(int set, int value) {
    node *new_node = new node(value);
    sets[set] = merge(sets[set], new_node);
}

void query_max(int set) {
    out << sets[set]->value << '\n';
    sets[set] = delete_max(sets[set]);
}

void query_merge(int set_a, int set_b) {
    sets[set_a] = merge(sets[set_a], sets[set_b]);
    sets[set_b] = nullptr;
}

void solve() {
    int a, b, c;
    while (q--) {
        in >> a;
        if (a == 1) {
            in >> b >> c;
            query_insert(b, c);
        } else if (a == 2) {
            in >> b;
            query_max(b);
        } else {
            in >> b >> c;
            query_merge(b, c);
        }
    }
}


int main() {
    read();
    solve();
    return 0;
}