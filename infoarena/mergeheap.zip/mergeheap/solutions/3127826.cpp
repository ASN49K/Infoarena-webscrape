#include <iostream>
#include <algorithm>
#include <vector>
#include <fstream>
using namespace std;
ifstream f("mergeheap.in");
ofstream g("mergeheap.out");

class node
{
public:
	int val;
	node* copil;
	node* frate;
	node()
	{
		val = -1;
		copil = NULL;
		frate = NULL;
	}
	node(int val1)
	{
		val = val1;
		copil = NULL;
		frate = NULL;
	}
	void add_copil(node* copil1)
	{
		if (copil1 != NULL)
		{
			copil1->frate = copil;
			copil = copil1;
		}
		else
			copil = copil1;
	}
};
node* merge_nodes(node* nod1, node* nod2)
{
	if (nod1 == nullptr)
		return nod1;
	if (nod2 == nullptr)
		return nod2;
	if (nod1->val > nod2->val)
	{
		nod1->add_copil(nod2);
		return nod1;
	}
	else
	{
		nod2->add_copil(nod1);
		return nod2;
	}
	return NULL;
}
node* insertnd(node* nod, int val1)
{
	return merge_nodes(nod, new node(val1));
}
node* twopasi(node* nod)
{
	if (nod == NULL || nod->frate == NULL)
		return nod;
	else
	{
		node* nod1, * nod2, * helpernode;
		nod1 = nod;
		nod2 = nod->frate;
		helpernode = nod2->frate;
		nod1->frate = NULL;
		nod2->frate = NULL;
		return merge_nodes(merge_nodes(nod1, nod2), twopasi(helpernode));
	}
	return NULL;
}
node* del_max(node* nod)
{
	return twopasi(nod->copil);
}
class PairingHeap
{
public:
	node* root;
	PairingHeap()
	{
		root = NULL;
	}
	void insert(int val1)
	{
		root = insertnd(root, val1);
	}
	int get_max()
	{
		return root->val;
	}
	void del()
	{
		root = del_max(root);
	}
	void merge_heap(PairingHeap h2)
	{
		root = merge_nodes(root, h2.root);
	}
};


int main()
{
	int n, q;
	f >> n;
	PairingHeap h[101];
	f >> q;
	for (int i = 1;i <= q;i++)
	{
		int operatie, m, x, y;
		f >> operatie;
		if (operatie == 1)
		{
			f >> m >> x;
			h[m].insert(x);
		}
		if (operatie == 2)
		{
			f >> m;
			g << h[m].get_max() << endl;
		}
		if (operatie == 3)
		{
			f >> x >> y;
			h[x].merge_heap(h[y]);
		}
	}

	return 0;
}