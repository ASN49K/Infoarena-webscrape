#include <iostream>
#include <fstream>
#include <queue>
using namespace std;
ifstream f("mergeheap.in");
ofstream g("mergeheap.out");
priority_queue<int> h[102];
int N,Q,operatie,a,b,i;
int main()
{
    f>>N>>Q;
    for(i=0; i<Q; ++i)
    {
        f>>operatie;
        if(operatie==1)
        {
            f>>a>>b;
            h[a].push(b);
        }
        else if(operatie==2)
        {
            f>>a;
            g<<h[a].top()<<'\n';
            h[a].pop();
        }
       else
        {
            f>>a>>b;
            if(h[b].size()>h[a].size())
                swap(h[a],h[b]);
            while(!h[b].empty())
            {
                h[a].push(h[b].top());
                h[b].pop();
            }
        }

    }

    return 0;
}
