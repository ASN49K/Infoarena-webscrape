#include <bits/stdc++.h>

using namespace std;

const int NMAX = 1e5;

priority_queue <int> pq[NMAX + 1];

int main() {
    ifstream fin( "mergeheap.in" );
    ofstream fout( "mergeheap.out" );
    int n, q;
    fin >> n >> q;
    for ( int i = 0; i < q; i ++ ) {
        int tip, m, x;
        fin >> tip;
        if ( tip == 1 ) {
            fin >> m >> x;
            pq[m].push( x );
        } else if ( tip == 2 ) {
            fin >> m;
            fout << pq[m].top() << '\n';
            pq[m].pop();
        } else {
            fin >> m >> x;
            if ( pq[x].size() < pq[m].size() )
                swap( pq[m], pq[x] );
            while ( !pq[x].empty() ) {
                pq[m].push( pq[x].top() );
                pq[x].pop();
            }
        }
    }
    return 0;
}
