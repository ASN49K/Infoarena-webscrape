class Node:
    def __init__(self, value):
        self.value = value
        self.child = None
        self.next_sibling = None
        self.rank = 0


class PairingHeap:
    def __init__(self):
        self.root = None
        # self.max_node = None

    def insert(self, value):
        new_node = Node(value)
        self.root = self._merge(self.root, new_node)

    def merge(self, other_heap):
        self.root = self._merge(self.root, other_heap.root)

    def find_max(self):
        if self.root is None:
            return None
        max_node = self.root
        curr_node = max_node.next_sibling
        while curr_node is not None:
            if curr_node.value > max_node.value:
                max_node = curr_node
            curr_node = curr_node.next_sibling
        return max_node.value

    def delete_max(self):
        if self.root is None:
            return None
        max_value = self.root.value
        if self.root.child is None:
            self.root = None
        else:
            new_root = self._combine_pairs(self.root.child)
            self.root = new_root
        return max_value

    def _merge(self, node1, node2):
        if node1 is None:
            return node2
        if node2 is None:
            return node1
        if node1.value < node2.value:
            node2.next_sibling = node1.child
            node1.child = node2
            return node1
        else:
            node1.next_sibling = node2.child
            node2.child = node1
            return node2

    def _combine_pairs(self, first_node):
        if first_node is None or first_node.next_sibling is None:
            return first_node
        else:
            a = first_node
            b = first_node.next_sibling
            c = b.next_sibling
            a.next_sibling = None
            b.next_sibling = None
            c = self._combine_pairs(c)
            return self._merge(self._merge(a, b), c)


heap1 = PairingHeap()
heap1.insert(3)


heap2 = PairingHeap()
heap2.insert(5)
heap2.insert(2)

heap3 = PairingHeap()
heap3.insert(7)
heap3.insert(4)




print(heap2.find_max())
heap2.delete_max()
heap2.merge(heap1)


print(heap2.find_max())
heap3.delete_max()

heap3.merge(heap2)

print(heap3.find_max())
heap3.delete_max()


