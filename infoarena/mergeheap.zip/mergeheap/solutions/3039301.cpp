#include <bits/stdc++.h>
#define debug(x) cerr << #x << " " << x << "\n"
#define debugs(x) cerr << #x << " " << x << " "
#pragma GCC optimize("Ofast")

using namespace std;
typedef long long ll;
typedef pair <int, int> pii;

const ll NMAX = 1000001;
const ll INF = (1LL << 60);
const ll nrbits = 17;
const ll MOD = 9973;

priority_queue <int> pq[101];

int main() {
//#ifdef HOME
    ifstream cin("mergeheap.in");
    ofstream cout("mergeheap.out");
//#endif // HOME
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n, q;
    cin >> n >> q;
    while(q--){
        int t;
        cin >> t;
        if(t == 1){
            int a, b;
            cin >> a >> b;
            pq[a].push(b);
        }else if(t == 2){
            int a;
            cin >> a;
            cout << pq[a].top() << "\n";
            pq[a].pop();
        }else{
            int a, b;
            cin >> a >> b;
            if(pq[a].size() < pq[b].size()){
                swap(pq[a], pq[b]);
            }
            while(pq[b].size()){
                pq[a].push(pq[b].top());
                pq[b].pop();
            }
        }
    }
}
