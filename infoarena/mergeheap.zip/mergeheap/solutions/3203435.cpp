#include <fstream>
#include <set>
#include <vector>
using namespace std;

ifstream cin("mergeheap.in");
ofstream cout("mergeheap.out");

int n,m,x,c;
vector<multiset<int, greater<>>> v(n+1);
int nr;
int main()
{
	cin >> n >> m;
	int mult;
	for (int i = 1; i <= m; i++)
	{
		cin >> c >> mult;
		if (c == 1)
		{
			cin >> x;
			v[mult].insert(x);
		}
		if (c == 2)
		{
			cout << *v[mult].begin() << '\n';
			v[mult].erase(v[mult].begin());
		}
		if (c == 3)
		{
				int mult1;
				cin >> mult1;
				if(v[mult].size() < v[mult1].size())
					swap(v[mult], v[mult1]);
				v[mult].insert(v[mult1].begin(), v[mult1].end());
				v[mult1].clear();
		}
	}
    return 0;
}
