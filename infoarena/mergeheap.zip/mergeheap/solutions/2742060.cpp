#include <bits/stdc++.h>

using namespace std;

ifstream fin( "mergeheaps.in" );
ofstream fout( "mergeheaps.out" );

int N, M;
vector <priority_queue<int> > Q(101);

int main()
{
    fin >> N >> M;

    for( int i = 1; i <= M; ++i ) {
        int tip, x, y;

        fin >> tip;
        if( tip != 2 ) fin >> x >> y;
        else fin >> x;

        if( tip == 1 )
            Q[x].push( y );
        if( tip == 2 )  {
            fout << Q[x].top() << '\n';
            Q[x].pop();
        }
        if( tip == 3 ) {
            while( Q[y].size() > 0 ) {
                Q[x].push( Q[y].top() );
                Q[y].pop();
            }
        }
    }

    return 0;
}
