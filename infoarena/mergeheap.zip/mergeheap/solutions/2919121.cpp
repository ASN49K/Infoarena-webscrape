// This program was written by Mircea Rebengiuc
// for problem mergeheap
// on 15.08.2022

#include <stdio.h>
#include <ctype.h>

#include <set>

#define magic_sauce inline __attribute__((always_inline))

FILE *fin, *fout;

magic_sauce int fgetint(){
  int n = 0, ch;

  while( !isdigit( ch = fgetc( fin ) ) );
  do
    n = n * 10 + ch - '0';
  while( isdigit( ch = fgetc( fin ) ) );

  return n;
}

#define MAXN 100

std::set<int> *heaps[MAXN];

int main(){
  fin = fopen( "mergeheap.in", "r" );
  fout = fopen( "mergeheap.out", "w" );

  int n, q, i, a, b;

  n = fgetint();
  q = fgetint();

  for( i = 0 ; i < n ; i++ )
    heaps[i] = new std::set<int>();

  for( ; q-- ; ){
    switch( fgetint() ){
    case 1:
      i = fgetint() - 1;
      heaps[i]->insert( -fgetint() );
      break;

    case 2:
      fprintf( fout, "%d\n", -(*heaps[i = fgetint() - 1]->begin()) );
      heaps[i]->erase( heaps[i]->begin() );
      break;

    case 3:
      a = fgetint() - 1;
      b = fgetint() - 1;

      if( heaps[b]->size() > heaps[a]->size() ){
        auto aux = heaps[b];
        heaps[b] = heaps[a];
        heaps[a] = aux;
      }

      for( int x : *heaps[b] )
        heaps[a]->insert( x );
      heaps[b]->clear();
      break;
    }
  }

  for( i = 0 ; i < n ; i++ )
    delete heaps[i];


  fclose( fin );
  fclose( fout );
  return 0;
}