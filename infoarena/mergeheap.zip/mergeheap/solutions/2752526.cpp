#include <iostream>
#include <deque>

using namespace std;

struct PairHeap
{
    int val;
    deque<PairHeap*> children;
};

PairHeap *v[105];

void insert(int m, int val)
{
    PairHeap *newHeap = (PairHeap *)malloc(sizeof(PairHeap));
    newHeap->val = val;
    newHeap->children = deque<PairHeap*>();
    if (v[m - 1] != NULL && v[m - 1]->val > val)
        v[m - 1]->children.push_back(newHeap);
    else if (v[m - 1] != NULL)
    {
        newHeap->val = v[m - 1]->val;
        v[m - 1]->val = val;
        v[m - 1]->children.push_back(newHeap);
    }
    else
        v[m - 1] = newHeap;
}

void merge(PairHeap **a, PairHeap *b)
{
    if (*a == NULL)
    {
        *a = b;
        return;
    }
    if ((*a)->val > b->val)
        (*a)->children.push_back(b);
    else
    {
        PairHeap aux = **a;
        **a = *b;
        *b = aux;
        (*a)->children.push_back(b);
    }
}

void pop(int m)
{
    printf("%d\n", v[m - 1]->val);
    PairHeap *newRoot = v[m - 1]->children.front();
    v[m - 1]->children.pop_front();
    while (!v[m - 1]->children.empty())
    {
        merge(&newRoot, v[m - 1]->children.front());
        v[m - 1]->children.pop_front();
    }
    v[m - 1] = newRoot;
}

void mergeIndexes(int a, int b)
{
    merge(&v[a - 1], v[b - 1]);
    v[b - 1] = NULL;
}

int main()
{
    freopen("mergeheap.in", "r", stdin);
    freopen("mergeheap.out", "w", stdout);
    int n, q;
    scanf("%d %d", &n, &q);
    while (q--)
    {
        int tip;
        scanf("%d", &tip);
        if (tip == 1)
        {
            int m, x;
            scanf("%d %d", &m, &x);
            insert(m, x);
        }
        else if (tip == 2)
        {
            int m;
            scanf("%d", &m);
            pop(m);
        }
        else
        {
            int a, b;
            scanf("%d %d", &a, &b);
            mergeIndexes(a, b);
        }
    }
}