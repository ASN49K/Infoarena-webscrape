
#include <fstream>
#include <queue>
using namespace std;
ifstream cin("mergeheap.in");
ofstream cout("mergeheap.out");
struct cmp{
    bool operator () (const int a,const int b)
    {
        return a<b;
    }
};
vector<priority_queue<int,vector<int>,cmp>> A;
int n,q,t;
int m,x;
int a,b;
int main()
{
    cin>>n>>q;
    A.resize(n+1);
    for(int i=0;i<q;i++)
    {
        cin>>t;
        switch (t)
        {
            case 1:
            {
                cin>>m>>x;
                A[m].push(x);
                break;
            }
            case 2:
            {
                cin>>m;
                cout<<A[m].top()<<'\n';
                A[m].pop();
                break;
            }
            case 3:
            {
                cin>>a>>b;
                while(!A[b].empty())
                {
                    A[a].push(A[b].top());
                    A[b].pop();
                }
            }
        }
    }
    return 0;
}
