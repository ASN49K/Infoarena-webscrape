﻿#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    ifstream fin("mergeheap.in");   // Deschide fișierul de intrare
    ofstream fout("mergeheap.out"); // Deschide fișierul de ieșire

    int N, Q;
    fin >> N >> Q; // Citeste numărul de mulțimi (N) și numărul de operații (Q)

    vector<priority_queue<int>> heaps(N + 1);  // Vectorul de heap-uri pentru mulțimi

    for (int i = 0; i < Q; i++) {
        int option;
        fin >> option; // Citeste tipul operației

        if (option == 1) { // Operația de tip 1: inserare într-o mulțime
            int m, x;
            fin >> m >> x; // Citeste numărul mulțimii (m) și elementul de inserat (x)
            heaps[m].push(x); // Adaugă elementul în heap-ul corespunzător
        }
        else if (option == 2) { // Operația de tip 2: afișare și eliminare a elementului maxim
            int m;
            fin >> m; // Citeste numărul mulțimii (m)
            int maxValue = heaps[m].top(); // Obține valoarea maximă din heap-ul corespunzător
            heaps[m].pop(); // Elimină elementul maxim din heap
            fout << maxValue << "\n"; // Scrie valoarea maximă în fișierul de ieșire
        }
        else if (option == 3) { // Operația de tip 3: reunirea a două mulțimi
            int a, b;
            fin >> a >> b; // Citeste numerele mulțimilor (a și b)
            while (!heaps[b].empty()) { // Transferă toate elementele din heap-ul b în heap-ul a
                int element = heaps[b].top();
                heaps[b].pop();
                heaps[a].push(element);
            }
        }
    }

    fin.close(); // Închide fișierul de intrare
    fout.close(); // Închide fișierul de ieșire

    return 0;
}
