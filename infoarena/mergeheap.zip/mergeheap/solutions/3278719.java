import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scan = new Scanner(new FileReader("mergeheap.in"));
        PrintWriter pw = new PrintWriter("mergeheap.out");

        try {
            List<PriorityQueue<Integer>> pq = new ArrayList<>();

            int N = scan.nextInt();

            for (int i = 0; i < N; i++) {
                pq.add(new PriorityQueue<>(Collections.reverseOrder()));
            }
            int Q = scan.nextInt();

            for (int i = 0; i < Q; ++i) {
                int t = scan.nextInt();
                if (t == 1) {
                    int m = scan.nextInt();
                    int x = scan.nextInt();
                    --m;
                    pq.get(m).add(x);
                } else if (t == 2) {
                    int m = scan.nextInt();
                    --m;
                    pw.write(pq.get(m).peek() + "\n");
                    pq.get(m).remove();
                } else if (t == 3) {
                    int a = scan.nextInt();
                    int b = scan.nextInt();
                    --a; --b;
                    if (pq.get(a).size() < pq.get(b).size()) {
                        Collections.swap(pq, a, b);
                    }
                    while (!pq.get(b).isEmpty()) {
                        pq.get(a).add(pq.get(b).peek());
                        pq.get(b).remove();
                    }
                }
            }
        } finally {
            pw.close();
            scan.close();
        }
    }
}