#include <bits/stdc++.h>
using namespace std;

ifstream f("mergeheap.in");
ofstream g("mergeheap.out");

const int dim = 102;

int n, q;
priority_queue<int> Q[dim];

int main()
{
    f >> n >> q;

    for(int i = 1; i <= q; i++)
    {
        int c;
        f >> c;

        if(c == 1)
        {
            int m, x;
            f >> m >> x;
            Q[m].push(x);
        }

        if(c == 2)
        {
            int m;
            f >> m;
            g << Q[m].top() << '\n';
            Q[m].pop();
        }

        if(c == 3)
        {
            int a, b;
            f >> a >> b;

            if(Q[a].size() < Q[b].size())
            {
                swap(Q[a],Q[b]);
            }

            while(!Q[b].empty())
            {
                Q[a].push(Q[b].top());
                Q[b].pop();
            }
        }
    }
    return 0;
}
