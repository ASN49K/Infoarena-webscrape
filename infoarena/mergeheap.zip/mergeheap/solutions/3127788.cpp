#include <iostream>
#include <algorithm>
#include <vector>
#include <fstream>
using namespace std;
ifstream f("date.in");
ofstream g("date.out");

class node
{
public:
	int val;
	node* copil;
	node* frate;
	node()
	{
		val = -1;
		copil = NULL;
		frate = NULL;
	}
	node(int val1)
	{
		val = val1;
		copil = NULL;
		frate = NULL;
	}
	int get_val()
	{
		return val;
	}
	node* get_copil()
	{
		return copil;
	}
	node* get_frate()
	{
		return frate;
	}
	int set_val(int val1)
	{
		val = val1;
	}
	node* set_copil(node* copil1)
	{
		copil = copil1;
	}
	node* set_frate(node* frate1)
	{
		frate = frate1;
	}
	void add_copil(node* copil1)
	{
		if (copil1 != NULL)
		{
			copil1->frate = copil;
			copil = copil1;
		}
		else
			copil = copil1;
	}
};
class PairingHeap
{
	node* root;
public:
	PairingHeap()
	{
		root = NULL;
	}
	PairingHeap(int val1)
	{
		root->val = val1;
	}
	PairingHeap(node* nod)
	{
		root = nod;
	}
	void insert(int val1)
	{
		node* helpernode = new node(val1);
		if (root == NULL)
			root->val = val1;
		if (root->val < val1)
			swap(root, helpernode);
		helpernode->frate = root->copil;
		root->copil = helpernode;
	}
	int get_max()
	{
		return root->val;
	}
	void merge(PairingHeap* h2)
	{
		if (h2->root == NULL)
			return;
		if (root == NULL)
		{
			swap(root, h2->root);
			return;
		}
		if (root->val > h2->root->val)
			swap(root, h2->root);
		h2->root->frate = root->copil;
		root->copil = h2->root;
		h2->root = NULL;
	}
	node* twopasi(node* nod1)
	{
		if (nod1 == NULL || nod1->frate == NULL)
			return nod1;
		node* nod2;
		PairingHeap* ph1;
		PairingHeap* ph2;
		ph1->root = nod1;
		ph2->root = nod1->frate;
		ph1->merge(ph2);
		PairingHeap* final_heap;
		final_heap->root = twopasi(nod2);
		ph1->merge(final_heap);
		return ph1->root;
	}
};


int main()
{
	int n, q;
	f >> n;
	PairingHeap *h[101];
	f >> q;
	for (int i = 1;i <= q;i++)
	{
		int operatie, m, x, y;
		f >> operatie;
		if (operatie == 1)
		{
			f >> m >> x;
			h[m - 1]->insert(x);
		}
		if (operatie == 2)
		{
			f >> m;
			g << h[m - 1]->get_max() << endl;
		}
		if (operatie == 3)
		{
			f >> x >> y;
			h[x - 1]->merge(h[y - 1]);
		}
	}

	return 0;
}