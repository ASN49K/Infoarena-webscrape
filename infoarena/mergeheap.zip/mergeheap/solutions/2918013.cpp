#include <bits/stdc++.h>
#include <bits/extc++.h>

using namespace std;
using namespace __gnu_pbds;
using namespace __gnu_cxx;

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

const int NMAX = 100;

int n, q;
__gnu_pbds :: priority_queue<int, less<int>, pairing_heap_tag> pq[NMAX + 1];

int main() {
	fin >> n >> q;

	for(int i = 1; i <= q; i++) {
		int task;
		fin >> task;

		if(task == 1) {
			int m, x;
			fin >> m >> x;

			pq[m].push(x);
		} else if(task == 2) {
			int m;
			fin >> m;

			fout << pq[m].top() << '\n';
			pq[m].pop();
		} else {
			int a, b;
			fin >> a >> b;

			if(pq[a].size() < pq[b].size()) {
				pq[a].swap(pq[b]);
			}

			pq[a].join(pq[b]);
			pq[b].clear();
		}
	}
	return 0;
}