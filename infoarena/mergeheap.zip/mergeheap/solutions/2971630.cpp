#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pi;
#define pb push_back
#define mp make_pair
#define f first
#define s second
 
void solve(){
    int n, q;
    cin >> n >> q;
    vector<set<int>> a(n+1);
    for(int i = 0; i < q; i++){
        int t;
        cin >> t;
        if(t == 1){
            int m, x;
            cin >> m >> x;
            a[m].insert(-x);
        } else if(t == 2){
            int m;
            cin >> m;
            cout << *a[m].begin() * -1 << '\n';
            a[m].erase(a[m].begin());
        } else {
            int x, y;
            cin >> x >> y;
            a[x].insert(a[y].begin(), a[y].end());
        }
    }
}  
 
int main(){
    freopen("mergeheap.in", "r", stdin);
    freopen("mergeheap.out", "w", stdout);
    ios::sync_with_stdio(0); cin.tie(0);
    int t = 1;
    //cin >> t;
    while(t--){
        solve();
    }
}