#include <fstream>
#include <set>
#include <vector>

int main() {
    std::ifstream input("mergeheap.in");
    std::ofstream output("mergeheap.out");
    int n, q;

    input >> n >> q;
    std::vector<std::set<int, std::greater<>>> sets(n + 1);

    while (q--) {
        int op;
        input >> op;
        if (op == 1) {
            int m, x;
            input >> m >> x;
            sets[m].insert(x);
        } else if (op == 2) {
            int m;
            input >> m;
            output << *sets[m].begin() << '\n';
            sets[m].erase(sets[m].begin());
        } else if (op == 3) {
            int a, b;
            input >> a >> b;
            if (sets[b].size() > sets[a].size()) std::swap(a, b);
            for (const auto &x: sets[b]) sets[a].insert(x);
            sets[b].clear();
        }
    }

    return 0;
}
