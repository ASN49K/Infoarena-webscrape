#include <bits/stdc++.h>

using namespace std;
ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");
int n,q;
priority_queue<int> v[103];
int op,x,y;
int main()
{
    fin>>n>>q;
    while (q--)
    {
        fin>>op;
        if (op==1)
        {
            fin>>x>>y;
            v[x].push(y);
        }
        else if (op==2)
        {
            fin>>x;
            fout<<v[x].top()<<'\n';
            v[x].pop();
        }
        else
        {
            fin>>x>>y;
            if (v[x].size()>v[y].size()) swap(v[x],v[y]);
            while (!v[y].empty())
            {
                v[x].push(v[y].top());
                v[y].pop();
            }
        }
    }
    return 0;
}
