#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("mergeheap.in");
ofstream out("mergeheap.out");

struct Nod
{
    int val;
    Nod* tata;
    Nod* fiu;
    Nod* frate;

    Nod()
    {
        fiu = frate = NULL;
    }
};

Nod* New(int val)
{
    Nod* tmp = new Nod;
    tmp->val = val;
    tmp->frate = tmp->fiu = NULL;
    return tmp;
}

int Maxi(Nod* n)
{
    if (n != NULL) return n->val;
}

Nod* Merge(Nod* a, Nod* b)
{
    if (a == NULL) return b;
    if (b == NULL) return a;

    if (b->val > a->val) swap(a,b);

    if (a->fiu == NULL)
    {
        a->fiu = b;
        return a;
    }
    else
    {
        b->frate = a->fiu;
        a->fiu = b;
        return a;
    }
    return NULL;
}

Nod* Insert(int val, Nod* heap)
{
    Nod* tmp = New(val);
    heap = Merge(tmp, heap);
    return heap;
}

Nod* Stergere(Nod* heap)
{
    if (heap == NULL || heap->frate == NULL) return heap;
    else
    {
        Nod* A,*B,*NXT;
        A = heap;
        B = heap->frate;
        NXT = heap->frate->frate;
        A->frate = NULL;
        B->frate = NULL;
        return Merge( Merge(A,B), Stergere(NXT));
    }
    return NULL;
}

Nod* Delete_Max(Nod* heap)
{
    out << heap->val << "\n";
    return Stergere(heap->fiu);
}

int n,m,op,a,b;
Nod* multimi[105];

int main()
{
    in >> n >> m;
    while (m--)
    {
        in >> op;
        if (op == 1)
        {
            in >> a >> b;
            multimi[a] = Insert(b, multimi[a]);
        }
        else if (op == 2)
        {
            in >> a;
            multimi[a] = Delete_Max(multimi[a]);
        }
        else
        {
            in >> a >> b;
            multimi[a] = Merge(multimi[a], multimi[b]);
            multimi[b] = NULL;
        }

    }
    return 0;
}
