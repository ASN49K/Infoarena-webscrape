#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("mergeheaps.in");
ofstream fout("mergeheaps.out");

const int MAXN =  102;
int N, Q;

struct nod {

	int val;
	nod* child, *sibling;
	
	nod(int x) : val(x), child(NULL), sibling(NULL){}
};

class pairingheap {
	nod* radacina;

	nod* mergeheaps(nod* n1, nod* n2)
	{
		if (n1 == NULL)
		{
			n1 = n2;
			return n1;
		}

		else if (n2 == NULL)
		{
			return n1;
		}

		if (n1->val < n2->val)
			swap(n1, n2);

		n2->sibling = n1->child;
		n1->child = n2;

		return n1;
	}

	nod* TwoPassMerge(nod* _nod_) {
		if (_nod_->sibling == NULL || _nod_ == NULL)
			return _nod_;

		nod* heap1, * heap2, * next_heap;
		heap1 = _nod_;
		heap2 = _nod_->sibling;
		next_heap = _nod_->sibling->sibling;
		heap1->sibling = heap2->sibling = NULL;
		return mergeheaps(mergeheaps(heap1, heap2), TwoPassMerge(next_heap));

	}
public:
	pairingheap(): radacina ( NULL ){}
		pairingheap(int valoare) {
		radacina = new nod(valoare);
	}
		pairingheap(nod* _nod_) : radacina(_nod_) {}


		int val_max() {
			return radacina->val;
		}

		void push(int valoare) {
			mergeheaps(pairingheap(valoare));
		}
		void eliminate() {
			nod* radacina_temp = radacina;
			radacina = TwoPassMerge(radacina->child);
			delete radacina_temp;
		}

		void heap_unification(pairingheap& H)
		{
			mergeheaps(H);
			H.radacina = NULL;
		}


		void mergeheaps(pairingheap H) {
			if (radacina == NULL)
			{
				radacina = H.radacina;
				return;
			}
			if (H.radacina = NULL)
				return;
			if (radacina->val < H.radacina ->val)
				swap(radacina, H.radacina);
		  
			H.radacina->sibling = radacina->child;
			radacina->child = H.radacina;
			H.radacina = NULL;
		}

		
};

pairingheap Heap[MAXN];

int main()
{
	fin >> N >> Q; 

	int cerinta, id_heap, valoare, heap_1, heap_2, i;

	for (i = 0; i < Q; i++)
	{
		fin >> cerinta;
		if (cerinta == 1) {
			fin >> id_heap >> valoare;
			Heap[id_heap].push(valoare);
		}
		if (cerinta == 2) {
			fin >> id_heap;
			fout << Heap[id_heap].val_max() << '\n';
			Heap[id_heap].eliminate();
		}
		if (cerinta == 3) {
			fin >> heap_1 >> heap_2;
			Heap[heap_1].heap_unification(Heap[heap_2]);
		}
	}
	fin.close();
	fout.close();
	return 0;
}
