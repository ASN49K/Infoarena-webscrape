#include <bits/stdc++.h>
using namespace std;
ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");
const int NMAX = 101;
int n, q;
priority_queue<int> pq[NMAX];

void merge_heaps(priority_queue<int> &H1, priority_queue<int> &H2)
{
    if(H1.size() < H2.size())
        swap(H1, H2);
    while(!H2.empty())
    {
        H1.push(H2.top());
        H2.pop();
    }
}

int main()
{
    fin >> n >> q;
    while(q--)
    {
        int cer;
        fin >> cer;
        if(cer == 1)
        {
            int m, x;
            fin >> m >> x;
            pq[m].push(x);
        }
        else if(cer == 2)
        {
            int m;
            fin >> m;
            fout << pq[m].top() << "\n";
            pq[m].pop();
        }
        else
        {
            int a, b;
            fin >> a >> b;
            merge_heaps(pq[a], pq[b]);
        }
    }

    fin.close();
    fout.close();
    return 0;
}
