#include <bits/stdc++.h>
#include <cassert>

std::priority_queue<int> queues[101];
size_t lookup[101];

#pragma region ops

template <typename T>
constexpr void mergeHeaps(const size_t& first, const size_t& second) {
    if (queues[lookup[first]].size() < queues[lookup[second]].size()) {
        std::swap(lookup[first], lookup[second]);
    } else {
        while (queues[lookup[second]].size()) {
            queues[lookup[first]].emplace(queues[lookup[second]].top());
            queues[lookup[second]].pop();
        }
    }
}

#pragma endregion
auto main(int argc, char** argv) -> int {
// #ifdef NDEBUG
    freopen("mergeheap.in","r", stdin);
    freopen("mergeheap.out", "w", stdout);
// #endif

    unsigned int n;
    unsigned int q;

    std::cin >> n >> q;

    // Populate vector
    for (decltype(n) i = 0; i < n; i++) {
        lookup[i] = i;
    }

    for (decltype(q) i = 0; i < q; i++) {
        int op;
        std::cin >> op;

        switch (op) {
            case 3:
            {
                size_t idx1, idx2;
                std::cin >> idx1 >> idx2;
                mergeHeaps<int>(idx1-1, idx2-1);
                break;
            }

            case 1:
            {
                size_t idx;
                int elem;
                std::cin >> idx >> elem;
                queues[lookup[idx-1]].push(elem);
                break;
            }

            case 2:
            {
                size_t idx;
                std::cin >> idx;
                std::cout << queues[lookup[idx-1]].top() << "\n";
                queues[lookup[idx-1]].pop();
                break;
            }
        }
    }

    return 0;
}