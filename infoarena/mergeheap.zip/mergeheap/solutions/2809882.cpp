#include<fstream>
#include<iostream>
#include<vector>
#include<cstring>
#include<algorithm>
using namespace std;

struct pheap {
  int v;
  pheap* sub_heap;
  pheap* next;

  pheap(int val) {
    v = val;
    sub_heap = nullptr;
    next = nullptr;
  }
};

pheap* merge(pheap* ph1, pheap* ph2) {
  if (ph1 == nullptr) return ph2;
  if (ph2 == nullptr) return ph1;
  if (ph1->v > ph2->v) {
    ph2->next = ph1->sub_heap;
    ph1->sub_heap = ph2;
    return ph1;
  } else {
    ph1->next = ph2->sub_heap;
    ph2->sub_heap = ph1;
    return ph2;
  }
}

pheap* insert(pheap* ph, int val) {
  return merge(new pheap(val), ph);
}

pheap* mergePairs(pheap* ph) {
  if (ph == nullptr || ph->next == nullptr) return ph;
  while (ph->next != nullptr) {
    pheap* np = ph->next->next;
    ph = merge(ph, ph->next);
    ph->next = np;
  }
  return ph;
  //return merge(merge(ph, ph->next), mergePairs(ph->next->next));
}

pheap* removeMax(pheap* ph) {
  if (ph == nullptr) return ph;
  return mergePairs(ph->sub_heap);
}

int n,q,op,x,y;
pheap* h[105];

int main(){
  //ifstream cin("/usr/local/google/home/catavlas/ClionProjects/cf_training/subsecvente.in");
  ifstream cin("mergeheap.in");
  ofstream cout("mergeheap.out");

  cin>>n>>q;
  for (; q; --q) {
    cin>>op;
    if (op == 1) {
      cin>>x>>y;
      h[x] = insert(h[x], y);
    } else if (op == 3) {
      cin>>x>>y;
      h[x] = merge(h[x], h[y]);
      h[y] = nullptr;
    } else {
      cin>>x;
      cout<<h[x]->v<<"\n";
      h[x] = removeMax(h[x]);
    }
  }

  return 0;
}