#include <cstdio>
#include <iostream>

using namespace std;

__attribute__((always_inline)) void read(int &num) {
  static char inBuffer[0x30D40];
  static unsigned int p = 0x30D3F;
  num = 0x0;
  while(inBuffer[p] < 0x30 | inBuffer[p] > 0x39) {
    ++p != 0x30D40 || (fread(inBuffer, 0x1, 0x30D40, stdin), p = 0x0);
  }
  while(inBuffer[p] > 0x2F & inBuffer[p] < 0x3A) {
    num = num * 0xA + inBuffer[p] - 0x30;
    ++p != 0x30D40 || (fread(inBuffer, 0x1, 0x30D40, stdin), p = 0x0);
  }
}

char outBuffer[0x61A80];
unsigned int p;

__attribute__((always_inline)) void write(unsigned int x) {
  unsigned int digits = x > 0x3B9AC9FF ? 0xA :
                        x > 0x5F5E0FF  ? 0x9 :
                        x > 0x98967F   ? 0x8 :
                        x > 0xF423F    ? 0x7 :
                        x > 0x1869F    ? 0x6 :
                        x > 0x270F     ? 0x5 :
                        x > 0x3E7      ? 0x4 :
                        x > 0x63       ? 0x3 :
                        x > 0x9        ? 0x2 : 0x1;
  for(unsigned int i = ~-digits; ~i; --i) {
    outBuffer[p + i] = x % 0xA + 0x30;
    x = x / 0xA;
  }
  p = p + digits;
  outBuffer[p++] = 0x20;
}

struct node {
  int x;
  node* kid;
  node* nxt;
  node() {
    x = 0;
    kid = 0;
    nxt = 0;
  }
};

node* root[123];
node* nothing;

node* join(node* a, node* b) {
  if (!a) {
    return b;
  }
  if (!b) {
    return a;
  }
  if (a->x < b->x) {
    swap(a, b);
  }
  b->nxt = a->kid;
  a->kid = b;
  return a;
}


node* tupac(node* a) {
  if (!a) {
    return a;
  }
  if (!a->nxt) {
    return a;
  }
  if (!a->nxt->nxt) {
    return join(a, a->nxt);
  }
  return join(join(a, join(a->nxt, a->nxt->nxt)), tupac(a->nxt->nxt->nxt));
}

node* del(node* a) {
  return tupac(a->kid);
}

node* ins(node* a, int x) {
  node* b = new node;
  b->x = x;
  return join(a, b);
}


int main() {
  freopen ("mergeheap.in", "r", stdin);
  freopen ("mergeheap.out", "w", stdout);

  int n, q;
  bool first = 1;
  read(n);
  read(q);
  while (q--) {
    int tp;
    read(tp);
    if (tp == 1) {
      int i, x;
      read(i);
      read(x);
      root[i] = ins(root[i], x);
    }
    if (tp == 2) {
      int i;
      read(i);
      if (!first) {
        outBuffer[p++] = 10;
      }
      first = 0;
      write(root[i]->x);
      root[i] = del(root[i]);
    }
    if (tp == 3) {
      int i, j;
      read(i);
      read(j);
      root[i] = join(root[i], root[j]);
      root[j] = nothing;
    }
  }
  puts(outBuffer);
}
