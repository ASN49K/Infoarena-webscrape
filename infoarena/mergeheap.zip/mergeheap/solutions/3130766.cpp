#include <iostream>
#include <fstream>

struct NODE{

    int KEY;
    NODE* CHILD;
    NODE* NEXT; //sib
    NODE* PREV; // prev sib or parent

    explicit NODE(int KEY) : KEY(KEY){
        CHILD = nullptr;
        NEXT = nullptr;
        PREV = nullptr;
    }
};

class PAIRING_HEAP{
private:
    NODE* MERGE(NODE* A, NODE* B)
    {
        if(A == nullptr)
            return B;
        if(B == nullptr)
            return A;

        if(A -> KEY >= B -> KEY)
        {
            B -> PREV = A;
            B -> NEXT = A -> CHILD;
            A -> CHILD = B;
            return A;

        }else // if(B -> KEY <= A -> KEY)
        {
            A -> PREV = B;
            A -> NEXT = B -> CHILD;
            B -> CHILD = A;
            return B;
        }
    }

    NODE* MELD(NODE* FIRST)
    {
        if (FIRST != nullptr && FIRST->NEXT!= nullptr)
        {
            NODE* NODE1;
            NODE* NODE2;
            NODE* NODE3;
            NODE1 = FIRST;
            NODE2 = FIRST->NEXT;
            NODE3 = NODE2 -> NEXT;
            NODE1 -> NEXT = nullptr;
            NODE2 -> NEXT = nullptr;
            return MERGE(MERGE(NODE1, NODE2), MELD(NODE3));
        }
        return FIRST;
    }

    void merge(PAIRING_HEAP h)
    {
        if (ROOT->KEY < h.ROOT->KEY)
            std::swap(ROOT, h.ROOT);
        h.ROOT->NEXT = ROOT->CHILD;
        ROOT->CHILD = h.ROOT;
    }

public:
    NODE* ROOT;

    PAIRING_HEAP() : ROOT(nullptr){}

    PAIRING_HEAP(int KEY)
    {
        ROOT = new NODE(KEY);
    }

    bool EMPTY()
    {
        return ROOT == nullptr;
    }

    int MIN()
    {
        return ROOT -> KEY;
    }

    void INSERT(int KEY)
    {
        if(ROOT == nullptr)
        {
            ROOT = new NODE(KEY);
        }
//        auto* NEW_NODE = new NODE; //  NODE<T>* NEW_NODE
//        NEW_NODE -> KEY = KEY;
//        NEW_NODE ->  NEXT = nullptr;
//        NEW_NODE -> PREV = nullptr;
//        NEW_NODE -> CHILD = nullptr;
//
//        ROOT = MERGE(ROOT, NEW_NODE);

        merge(PAIRING_HEAP(KEY));

    }

    void DELETE_ROOT()
    {
        NODE* PREV_ROOT = ROOT;
        ROOT = MELD(ROOT -> CHILD);
        delete PREV_ROOT;
    }

    NODE* FIND_NODE(NODE* NODE, int KEY) {
        if (NODE == nullptr) {
            return nullptr;
        }
        if (NODE->KEY == KEY) {
            return NODE;
        }
        auto CHILD_RE = FIND_NODE(NODE->CHILD, KEY);
        if (CHILD_RE != nullptr) {
            return CHILD_RE;
        }
        return FIND_NODE(NODE->NEXT, KEY);
    }

    void OP3(PAIRING_HEAP& H)
    {
        ROOT = MERGE(ROOT, H.ROOT);
        H.ROOT = nullptr;
    }
};

int main()
{
    std::ifstream fin("mergeheap.in");
    std::ofstream fout("mergeheap.out");
    int n , a, b, c, d;
    PAIRING_HEAP h[101];

    fin>>n>>a;
    int OPERATION;

    for(int i = 1; i <= a; i++){
        fin>>OPERATION;
        std::cin>>OPERATION;
        if(OPERATION == 1)
        {
            fin>> b>> c;

            h[b].INSERT(c);

        }
        else if(OPERATION == 2)
        {
            fin>> b;
            fout<<h[b].MIN()<<std::endl;
            h[b].DELETE_ROOT();

        }
        else if(OPERATION == 2)
        {
            fin >> c >> d;
            h[c].OP3(h[d]);

        }
    }

    return 0;

}



