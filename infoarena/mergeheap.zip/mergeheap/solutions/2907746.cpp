#include <bits/stdc++.h>
#include <ext/pb_ds/priority_queue.hpp>

using namespace std;

#ifndef LOCAL

ifstream in("mergeheap.in");
ofstream out("mergeheap.out");
#define cin in
#define cout out

#endif // LOCAL

template < typename DATA >
struct MergeableHeap {
    __gnu_pbds::priority_queue< DATA, less<DATA>, __gnu_pbds::rc_binomial_heap_tag > heap;

    void pop() { heap.pop(); }
    DATA top() const { return heap.top(); }

    void push(const DATA& d) { heap.push(d); }

    void merge(MergeableHeap& oth) { heap.join(oth.heap); }
    void clear() { heap.clear(); }
};

MergeableHeap<int> v[107];

int main() {
    int n, q; cin >> n >> q;
    for(int qry = 0; qry < q; qry++) {
        char t; cin >> t;

        if(t == '1') { // Insert
            int m, x; cin >> m >> x;
            v[m].push(x);
        }
        if(t == '2') { // Pop
            int m; cin >> m;
            #ifdef LOCAL
                cerr << string("\t", 2);
            #endif // LOCAL
            cout << v[m].top() << '\n';
            v[m].pop();
        }
        if(t == '3') { // Merge
            int x, y; cin >> x >> y;
            v[x].merge(v[y]); v[y].clear();
        }
    }

    return 0;
}
