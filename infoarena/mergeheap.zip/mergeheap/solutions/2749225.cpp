#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/priority_queue.hpp>

using namespace std;
using namespace __gnu_pbds;

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

int n, t, x, y, z;

int main()
{
	cin >> n >> t;
	vector<__gnu_pbds::priority_queue<int,less<int>, pairing_heap_tag> > q(n + 1);
	while(t--)
	{
		fin >> x >> y;
		if(z == 1)
		{
			fin >> z;
			q[y].push(z);
		}
		else if(x == 2)
		{
			fout << q[y].top() << "\n";
			q[y].pop();
		}
		else
		{
			fin >> z;
			q[y].join(q[z]);
		}
	}
	return 0;
}