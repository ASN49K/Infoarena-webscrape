#include <bits/stdc++.h>
//#pragma GCC optimize ("03")
#define FastIO ios_base::sync_with_stdio(false) , cin.tie(0) , cout.tie(0)
#define FILES freopen("mergeheap.in" , "r" , stdin) , freopen("mergeheap.out" , "w" , stdout)
#define ll long long
#define ull unsigned long long
#define ld long double
#define eb emplace_back
#define pb push_back
#define qwerty1 first
#define qwerty2 second
#define qwerty3 -> first
#define qwerty4 -> second
#define umap unordered_map
#define uset unordered_set
#define pii pair < int , int >
#define pq priority_queue
#define dbg(x) cerr << #x << ": " << x << '\n'

namespace FastRead
{
    char __buff[5000];int __lg = 0 , __p = 0;
    char nc()
    {
        if(__lg == __p){__lg = fread(__buff , 1 , 5000 , stdin);__p = 0;if(!__lg) return EOF;}
        return __buff[__p++];
    }
    template<class T>void read(T&__x)
    {
        T __sgn = 1; char __c;while(!isdigit(__c = nc()))if(__c == '-')__sgn = -1;
        __x = __c - '0';while(isdigit(__c = nc()))__x = __x * 10 + __c - '0';__x *= __sgn;
    }
}

using namespace FastRead;
using namespace std;

const int N = 1e5 + 10;
const int M = 1e9 + 7;
const ld PI = acos(-1);
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int n , q , type , A , B;

struct Heap
{
    Heap *children[2];
    int key;

    Heap(int x)
    {
        children[0] = children[1] = NULL;
        key = x;
    }

    void add(Heap *node)
    {
        if(!children[0])
            children[0] = node;
        else
        {
            node -> children[1] = children[0];
            children[0] = node;
        }
    }
};

Heap *merge(Heap *a , Heap *b)
{
    if(a == NULL) return b;
    if(b == NULL) return a;

    if(a -> key > b -> key)
    {
        a -> add(b);
        return a;
    }
    else
    {
        b -> add(a);
        return b;
    }
}

Heap *del(Heap *a)
{
    if(a == NULL || a -> children[1] == NULL)
        return a;
    else
    {
        Heap *A = a;
        Heap *B = a -> children[1];
        Heap *C = B -> children[1];

        A -> children[1] = NULL;
        B -> children[1] = NULL;

        return merge(merge(A , B) , del(C));
    }
}

struct PairHeap
{
    Heap *R;

    int top()
    {
        return R -> key;
    }

    void insert(int x)
    {
        R = merge(R , new Heap(x));
    }

    void pop()
    {
        R = del(R -> children[0]);
    }

    void meld(Heap *A)
    {
        R = merge(A , R);
    }
}H[N];

signed main()
{
	#ifndef ONLINE_JUDGE
		FastIO , FILES;
	#endif

    cin >> n >> q;

    while(q--)
    {
        cin >> type;

        if(type == 1)
        {
            cin >> A >> B;
            H[A].insert(B);
        }
        else if(type == 2)
        {
            cin >> A;
            cout << H[A].top() << '\n';
            H[A].pop();
        }
        else
        {
            cin >> A >> B;
            H[A].meld(H[B].R);
        }
    }

    return 0;
}
