#include <iostream>
#include <fstream>
#include <queue>
using namespace std;
ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

const int MAX=100;
int n,i,q,idx,val,idx2,type;
priority_queue <int> pq[MAX+5];
int main()
{
    ios_base::sync_with_stdio(false);
    fin.tie(0); fout.tie(0);

    fin>>n>>q;
    while (q--)
    {
        fin>>type;

        if (type==1)
        {
            fin>>idx>>val;
            pq[idx].push(val);
        }
        else
        if (type==2)
        {
            fin>>idx;
            fout<<pq[idx].top()<<"\n";
            pq[idx].pop();
        }
        else
        if (type==3)
        {
            fin>>idx>>idx2;
            while (!pq[idx2].empty())
            {
                pq[idx].push(pq[idx2].top());
                pq[idx2].pop();
            }
        }
    }
    return 0;
}
