#include<fstream>
#include <vector>
#include <iostream>
using namespace std;
ifstream f("mergeheap.in");
ofstream g("mergeheap.out");
class Heap {
    vector<long long> heap;
public:
    void del_heap(){heap.clear();}
    void urca(long long poz) {
        while (poz) {
            if (heap[(poz - 1) / 2] < heap[poz]) {
                swap(heap[poz], heap[(poz - 1) / 2]);
                poz = (poz - 1) / 2;
            } else
                break;
        }
    }

    void coboara(long long poz) {
        while (poz * 2 + 1 < heap.size()) {
            if (poz * 2 + 2 < heap.size()) {
                if (heap[poz * 2 + 2] > heap[poz * 2 + 1]) {
                    if(heap[poz*2+2]>heap[poz]) {
                        swap(heap[poz * 2 + 2], heap[poz]);
                        poz = poz * 2 + 2;
                    }
                }
                else  if(heap[poz*2+1]>heap[poz]){
                    swap(heap[poz * 2 + 1], heap[poz]);
                    poz = poz * 2 + 1;
                }
            } else if (heap[poz * 2 + 1] > heap[poz]) {
                swap(heap[poz * 2 + 1], heap[poz]);
                poz = poz * 2 + 1;
            } else break;
        }
    }
    long long get_max() const{return heap[0];}
    long long get_size() {return heap.size()-1;}
    void baga(long long x)
    {
        heap.push_back(x);
        urca(get_size());
    }
    void scoate()
    {
        heap[0] = heap[get_size()];
        heap.pop_back();
        coboara(0);
    }
    vector<long long > get_heap(){return heap;}
    void heapify(long long i,long long size)
    {
        if(i>size)
            return;
        long long tata = i;
        if(2*i+1<size && heap[2*i+1]>heap[tata])
            tata = 2*i+1;
        if(2*i+2<size && heap[2*i+2]>heap[tata])
            tata = 2*i+2;
        if(tata != i)
        {
            swap(heap[i],heap[tata]);
            heapify(tata,size);
        }

    }
    void merge(Heap h,long long s1,long long s2)
    {
      for(auto i = 0;i<h.get_size()+1;i++)
          heap.push_back(h.get_heap()[i]);
      long long not_frunza = (h.get_size()+ 2 + this->get_size())/2-1;
      for(auto i = not_frunza;i>=0;i--)
          heapify(i,h.get_size() + this->get_size()+2);
    }
};
int main()
{
    long long n,q,op,m,x,a,b;
   f>>n>>q;
   Heap v[n+1];
   vector<long long >sol;
   for(auto i = 0;i<q;i++) {
       f >> op;
       switch (op) {
           case 1: {
               f >> m >> x;
               v[m].baga(x);
               break;
           }
           case 2:
           {
               f>>m;
               sol.push_back(v[m].get_max());
               g<<v[m].get_max()<<'\n';
               v[m].scoate();
               break;
           }
           case 3:
           {
               f>>a>>b;
               v[a].merge(v[b],v[a].get_size()+1,v[b].get_size()+1);
               v[b].del_heap();
               break;
           }
       }
   }
//   for(auto i = 0;i<sol.size();i++)
//       g<<sol[i]<<'\n';
   f.close();g.close();
    return 0;

}
