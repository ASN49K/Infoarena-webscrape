#include <bits/stdc++.h>
std::priority_queue <int> p[101];main() {std::ifstream f( "mergeheap.in" );std::ofstream g( "mergeheap.out" );int q,t,m,x;f>>t>>q;while(q--){f>>t>>m;if(t==1){f>>x;p[m].push(x);}if(t==2){g<<p[m].top()<<'\n';p[m].pop();}if(t==3){f>>x;if(p[x].size()>p[m].size())swap(p[m],p[x]);while(!p[x].empty()){p[m].push(p[x].top());p[x].pop();}}}}
