#include <bits/stdc++.h>
using namespace std;
ifstream f("mergeheap.in");
ofstream g("mergeheap.out");
// #define f cin
// #define g cout
int main() {
  int N, Q;
  priority_queue<int> pq[105];

  f >> N >> Q;
  while (Q--) {
    int t;
    f >> t;
    if (t == 1) {
      int m, x;
      f >> m >> x;
      pq[m].push(x);
    } else if (t == 2) {
      int m;
      f >> m;
      g << pq[m].top() << "\n";
      pq[m].pop();
    } else {
      int a, b;
      f >> a >> b;
      if (pq[a].size() < pq[b].size()) {
        swap(pq[a], pq[b]);
      }
      while (!pq[b].empty()) {
        pq[a].push(pq[b].top());
        pq[b].pop();
      }
    }
  }

  return 0;
}
