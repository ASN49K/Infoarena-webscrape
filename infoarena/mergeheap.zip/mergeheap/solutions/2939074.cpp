#include <bits/stdc++.h>

using namespace std;

priority_queue <int> h[101];
ifstream fin("mergeheap.in");
ofstream gout("mergeheap.out");



int main()
{int n,q,cer,x,a,b,m,i,idx[101];
    fin >> n >> q;
    for(i=1;i<=n;i++)
    {
        idx[i]=i;
    }
    for(i=1;i<=q;i++)
    {
        fin >> cer;
        if(cer==1)
        {
          fin >> m >> x;
          h[idx[m]].push(x);

        }
        if(cer==2)
        {
            fin >> m;
            gout << h[idx[m]].top() << endl;
            h[idx[m]].pop();
        }
        if(cer==3)
        {
            fin >> a >> b;
            if(h[a].size()>h[b].size())
            {
                swap(idx[a],idx[b]);

            }
             while(h[idx[b]].size()>0)
            {
                h[idx[a]].push(h[idx[b]].top());
                h[idx[b]].pop();
            }
         }
    }

    return 0;
}
