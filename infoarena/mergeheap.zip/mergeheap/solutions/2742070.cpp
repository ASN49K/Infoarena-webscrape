#include <iostream>
#include <fstream>
#include <queue>

using namespace std;

const int NMAX = 500001;

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

priority_queue < int > Q[NMAX];

int N, M;

int main()
{

    fin >> N >> M;

    int task, h, x, h1, h2;
    for( int i = 1; i <= M; ++i ){
        fin >> task;

        if( task == 1 ){
            fin >> h >> x;
            Q[h].push( x );
        }
        if( task == 2 ){
            fin >> h;
            fout << Q[h].top() << '\n';
            Q[h].pop();
        }
        if( task == 3 ){
            fin >> h1 >> h2;
            while( !Q[h2].empty() ){
                Q[h1].push( Q[h2].top() );
                Q[h2].pop();
            }
        }
    }

    return 0;
}
