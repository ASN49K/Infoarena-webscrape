#include <iostream>
#include <fstream>

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

using namespace std;

class Node {
    int data;
    Node* child;
    Node* prev;
    Node* next;
public:
    Node(int data) {
        this->data = data;
        child = nullptr;
        prev = nullptr;
        next = nullptr;
    }
    void setChild(Node* child) {
        this->child = child;
    }
    void setPrev(Node* prev) {
        this->prev = prev;
    }
    void setNext(Node* next) {
        this->next = next;
    }
    int getData() {
        return data;
    }
    Node* getChild() {
        return child;
    }
    Node* getPrev() {
        return prev;
    }
    Node* getNext() {
        return next;
    }
};

class PairingHeap {
    Node* root;
public:
    PairingHeap() {
        root = nullptr;
    }
    void insert(int data) {
        Node* node = new Node(data);
        if (root == nullptr) {
            root = node;
        } else {
            root = merge(root, node);
        }
    }
    Node* merge(Node* node1, Node* node2) {
        if (node1 == nullptr) {
            return node2;
        }
        if (node2 == nullptr) {
            return node1;
        }
        if (node1->getData() < node2->getData()) {
            Node* temp = node1;
            node1 = node2;
            node2 = temp;
        }
        Node* child = node1->getChild();
        if (child == nullptr) {
            node1->setChild(node2);
            node2->setPrev(node1);
        } else {
            while (child->getNext() != nullptr) {
                child = child->getNext();
            }
            child->setNext(node2);
            node2->setPrev(child);
        }
        return node1;
    }
    int getMax() {
        return root->getData();
    }
    void deleteMax() {
        Node* child = root->getChild();
        Node* prev = nullptr;
        Node* next = nullptr;
        while (child != nullptr) {
            next = child->getNext();
            child->setNext(nullptr);
            child->setPrev(nullptr);
            if (prev == nullptr) {
                prev = child;
            } else {
                prev = merge(prev, child);
            }
            child = next;
        }
        delete root;
        root = prev;
    }
    PairingHeap meld(PairingHeap heap1, PairingHeap heap2) {
        PairingHeap heap;
        heap.root = merge(heap1.root, heap2.root);
        return heap;
    }
};

int main() {
    int n, q;
    fin>>n;
    PairingHeap heap[n+1];
    fin>>q;
    for(int i=0;i<q;i++){
        int a,b,c;
        fin>>a;
        if(a==1){
            fin>>b>>c;
            heap[b].insert(c);
        }
        else if(a==2){
            fin>>b;
            fout<<heap[b].getMax()<<endl;
            heap[b].deleteMax();
        }
        else if(a==3){
            fin>>b>>c;
            heap[b]=heap[b].meld(heap[b],heap[c]);
        }
        }
    return 0;
    }
    