#include <fstream>
#include <set>

using namespace std;
set<int>s[101];
int n,q;
ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");
int main(){
     fin>>n>>q;
    while(q--){
        int t; fin>>t;
        if(t==1){
            int m,x; fin>>m>>x;
            s[m].insert(x);
        }
        else if(t==2){
            int m; fin>>m;
            fout<<*s[m].rbegin()<<'\n';
            s[m].erase(*s[m].rbegin());
        }
        else{
            int a,b;
            fin>>a>>b;
           while(!s[b].empty()){
            s[a].insert(*s[b].begin());
            s[b].erase(*s[b].begin());

            }
        }
    }

    return 0;
}
