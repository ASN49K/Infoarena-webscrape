#include <iostream>
#include <bits/stdc++.h>
using namespace std;

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

struct node
{
    node *st, *dr, *fiu, *tata;
    int key;
    int grad;
    bool ok;
};

class Fb
{
    node* heap;
    public:
    Fb()
    {
        heap= empty();
    }
    ~Fb()
    {
        if(heap)
        del(heap);
    }

    node* insert(int key)
    {
        node* elem=Singleton(key);
        heap= lin(heap, elem);
        return elem;
    }
    void lin(Fb& other)
    {
        heap=lin(heap, other.heap);
        other.heap= empty();
    }
     bool isEmpty()
    {
        return heap == NULL;
    }
     int getMaxim() {
        return heap->key;
    }
    int remoteMaxim()
    {
        node* old = heap;
        heap = remoteMaxim(heap);
        int elem = old->key;
        delete old;
        return elem;
    }

private:

    node* empty() {return NULL;}

    node* Singleton(int key)
    {
        node* n = new node;
        n->key = key;
        n->st = n->dr = n;
        n->grad = 0;
        n->ok = false;
        n->fiu = NULL;
        n->tata = NULL;
        return n;
    }

    node* lin(node* a,node* b)
    {
        if(a == NULL) return b;
        if(b == NULL) return a;
        if(a->key>b->key)
        {
            node* temp = a;
            a = b;
            b = temp;
        }
        node* an = a->dr;
        node* bp = b->st;
        a->dr = b;
        b->st = a;
        an->st = bp;
        bp->dr = an;
        return a;
    }

    void del(node* n)
    {
        if(n != NULL)
        {
            node* c = n;
            do
            {   node* d = c;
                c = c->dr;
                del(d->fiu);
                delete d;
            } while(c != n);
        }
    }

     void addfiu(node* tata,node* fiu)
     {
        fiu->st = fiu->dr = fiu;
        fiu->tata = tata;
        tata->grad++;
        tata->fiu = lin(tata->fiu,fiu);
    }
    void deb(node* n)
    {
        if(n == NULL)
            return;
        node* c = n;
        do
        {   c->ok = false;
            c->tata = NULL;
            c = c->dr;
        } while(c != n);
    }


    node* remoteMaxim(node* n)
     {
        deb(n->fiu);
        if(n->dr == n) {n = n->fiu;}
        else
        {
            n->dr->st = n->st;
            n->st->dr = n->dr;
            n = lin(n->dr,n->fiu);
        }
        if(n == NULL)
            return n;

        node* trees[64] =  {NULL};

        while(true)
        {
            if(trees[n->grad] != NULL)
            {
                node* t = trees[n->grad];
                if(t == n)
                    break;
                trees[n->grad] = NULL;
                if(n->key<t->key)
                {
                    t->st->dr = t->dr;
                    t->dr->st = t->st;
                    addfiu(n,t);
                }
                else
                {
                    t->st->dr = t->dr;
                    t->dr->st = t->st;
                    if(n->dr == n)
                    {
                        t->dr = t->st = t;
                        addfiu(t,n);
                        n = t;
                    }
                    else
                    {
                        n->st->dr = t;
                        n->dr->st = t;
                        t->dr = n->dr;
                        t->st = n->st;
                        addfiu(t,n);
                        n = t;
                    }
                }
                continue;
            }
            else
            {
                trees[n->grad] = n;
            }
            n = n->dr;
        }
        node* Max = n;
        node* start = n;
        do
        {   if(n->key<Max->key){Max = n;}
            n = n->dr;
        } while(n != start);
        return Max;
    }

};
int main()
{
    int N, T;
    fin >> N >> T;
    Fb H[N + 1];
    while(T--) {
        int c;
        fin >> c;
        if(c  ==  1)
        {
            int m, x;
            fin >> m >> x;
            H[m].insert(-x);
        }
        else if(c ==  2)
        {
            int m;
            fin >> m;
            fout << -H[m].getMaxim() << '\n';
            H[m].remoteMaxim();
        }
        else
        {
            int a, b;
            fin >> a >> b;
            H[a].lin(H[b]);
        }
    }
    return 0;
}
