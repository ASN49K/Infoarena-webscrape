#include <bits/stdc++.h>
using namespace std;

ifstream f("mergeheap.in");
ofstream g("mergeheap.out");

priority_queue < int > pq[105];
int n,q;
int op,a,b,m,x;

void insertion() {
    f >> m >> x;
    pq[m].push(x);
}

void maximum() {
    f >> m;
    g << pq[m].top() << '\n';
    pq[m].pop();
}

void reunion() {
    f >> a >> b;
    while (!pq[b].empty()) {
        pq[a].push(pq[b].top());
        pq[b].pop();
    }
}

void solve() {
    f >> n >> q;
    for (int i=1;i<=q;i++) {
        f >> op;
        if (op==1) {
            insertion();
        }
        else if (op==2) {
            maximum();
        }
        else {
            reunion();
        }
    }
}

int main()
{
    solve();
    return 0;
}
