#include <bits/stdc++.h>
#include <ext/pb_ds/priority_queue.hpp>

using namespace std;
using namespace __gnu_pbds;

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

void TestCase() {
  int n, q;
  fin >> n >> q;
  vector<__gnu_pbds::priority_queue<int, less<int>, pairing_heap_tag>> pq(n);
  for (int i = 1; i <= q; ++i) {
    int op, x;
    fin >> op >> x;
    --x;
    if (op == 1) {
      int y;
      fin >> y;
      pq[x].push(y);
    } else if (op == 2) {
      fout << pq[x].top() << '\n';
      pq[x].pop();
    } else {
      int y;
      fin >> y;
      --y;
      pq[x].join(pq[y]);
    }
  }
}

int main() {
  int tests = 1;
  for (int tc = 1; tc <= tests; ++tc) {
    TestCase();
  }
  fin.close();
  fout.close();
  return 0;
}
