#include <bits/stdc++.h>
using namespace std;
ifstream f("mergeheap.in");
ofstream g("mergeheap.out");
char s[32001];
int k;
inline void inc(){k++;if(k==32000){fread(s,1,32000,stdin);k=0;}}
inline void Int(int &x){while(!isdigit(s[k]))inc();x=0;while(isdigit(s[k])){x=10*x+s[k]-'0';inc();}}
struct nod;
typedef nod* pNod;
struct nod
{
    int val;
    pNod fiu,frate;
    nod(){val=0;fiu=frate=NULL;}
    nod(int _val){val=_val;fiu=frate=NULL;}
};
inline pNod unite(pNod A,pNod B)
{
    if(B==NULL)return A;
    if(A==NULL){A=B;return A;}
    if(A->val<B->val)swap(A,B);
    B->frate=A->fiu;A->fiu=B;return A;
}
inline pNod toHeap(pNod A){return (A==NULL||A->frate==NULL)?A:unite(unite(A,A->frate),toHeap(A->frate->frate));}
inline pNod addVal(pNod A,int x){pNod B=new nod(x);return unite(A,B);}
inline pNod query(pNod A){printf("%d\n",A->val);pNod B=A->fiu;delete A;return toHeap(B);}
int n,q;
pNod H[101];
int main()
{
    freopen("mergeheap.in","r",stdin);
    freopen("mergeheap.out","w",stdout);
    Int(n);Int(q);
    for(;q;q--)
    {
        int t,i,j;Int(t);Int(i);if(t&1)Int(j);
        if(t==1)H[i]=addVal(H[i],j);
        else if(t==2) H[i]=query(H[i]);
        else{H[i]=unite(H[i],H[j]);H[j]=NULL;}
    }
    return 0;
}
