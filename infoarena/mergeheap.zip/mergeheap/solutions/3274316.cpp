#include <bits/stdc++.h>
#include <cstring>
#include <cstdio>
#pragma GCC optimize ("O3")
#define din cin
#define dout out
#define pi 3.14159265359
#define sw(x,y) x^=y,y^=x,x^=y
#define bmin(a,b)((a<b)?(a):(b))
#define bmax(a,b)((a>b)?(a):(b))
#define bminify(a,b)a=bmin(a,b)
#define bmaxify(a,b)a=bmax(a,b)
#define fto(i,ii,n)for(i=ii;i<n;i++)
#define f first
#define s second
//#define mod 2000003ll
#define nmax 100006
#define lim 351
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace __gnu_pbds;
//typedef tree<int,null_type,rb_tree_tag,tree_order_statistics_node_update>ordered_set;
//functions: x.find_by_order(k), x.order_of_key(t)
using namespace std;
typedef long long ll;
ifstream in("mergeheap.in");
ofstream out("mergeheap.out");
//FILE *fin=fopen("infasuratoare.in","r");
//FILE *fout=fopen("infasuratoare.out","w");
int n,m,i,j,k,l;
struct nod{int v;nod*f,*d;}d[300001],*a[301],*c[300001];
nod*mer(nod*a,nod*b)
{
    if(a&&b)
        if(a->v>b->v)
            {b->d=a->f,a->f=b;return a;}
            else{a->d=b->f,b->f=a;return b;}
        else return a?a:b;
}
int main()
{
in>>n>>m;
while(m--){
    in>>i>>j;
    switch(i){
    case 1:
        in>>d[m].v;
        a[j]=mer(a[j],d+m);
        //cout<<a[j]->v<<j<<"C";
        break;
    case 3:
        //cout<<"b";
        in>>k,a[j]=mer(a[j],a[k]),a[k]=0;
        //cout<<a[j]->v<<j<<"B";
        break;
    default:
        out<<a[j]->v<<'\n';c[0]=a[j]->f,k=0;
        if(c[0]==0)goto ww;
        while(c[k]&&c[k]->d)c[k+1]=c[k]->d->d,c[k]->d->d=0,c[k]=mer(c[k]->d,c[k]),c[k]->d=0,k++;
        while(k>0)k--,c[k]=mer(c[k],c[k+1]);
        ww:a[j]=c[k];
    }
}
}
