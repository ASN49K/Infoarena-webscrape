#include <fstream>
#include <set>
#include <vector>
using namespace std;

ifstream cin("mergeheap.in");
ofstream cout("mergeheap.out");

int n,m,x,c;
vector<multiset<int>> v;
int nr;
int main()
{
	cin >> n >> m;
	v = vector<multiset<int>>(n+1);
	int mult;
	for (int i = 1; i <= m; i++)
	{
		cin >> c >> mult;
		if (c == 1)
		{
			cin >> x;
			v[mult].insert(x);
		}
		if (c == 2)
		{
			auto it = v[mult].end();
			if (it != v[mult].begin()) {
				--it;
				cout << *it << '\n';
				v[mult].erase(*it);
			}
		}
		if (c == 3)
		{
				int mult1;
				cin >> mult1;
				v[mult].insert(v[mult1].begin(), v[mult1].end());
				v[mult1].clear();
		}
	}
    return 0;
}
