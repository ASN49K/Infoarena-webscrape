#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

/*class PairingHeap{
    class Node{
    public:
        int data;
        Node* child;
        Node* next;
        Node(int data){
            this->data = data;
            child = nullptr;
            next = nullptr;
        }
    };
    Node* root;
    public:
    PairingHeap(){
        root = nullptr;
    }
    void insert(int data){
        Node* node = new Node(data);
        if(root == nullptr){
            root = node;
        }else{
            root = merge(root, node);
        }
    }
    Node* merge(Node* node1, Node* node2){
        if(node1 == nullptr){
            return node2;
        }
        if(node2 == nullptr){
            return node1;
        }
        if(node1->data < node2->data){
            Node* temp = node1;
            node1 = node2;
            node2 = temp;
        }
        Node* child = node1->child;
        if (child == nullptr) {
            node1->child = node2;
        } else {
            while (child->next != nullptr) {
                child = child->next;
            }
            child->next = node2;
        }
        return node1;
    }
    int getMax(){
        return root->data;
    }
    void extractMax(){
        Node* current = root->child;
            root = nullptr;
            while(current!=nullptr)
            {
                Node* next = current->next;
                current->next = nullptr;
                root = merge(root,current);
                current = next;
            }
    }
    PairingHeap merge(PairingHeap heap1, PairingHeap heap2){
        PairingHeap heap;
        heap.root = merge(heap1.root, heap2.root);
        return heap;
    }
};
*/
class Node {
public:
    int key;
    Node *leftChild, *nextSibling, *prev;

    Node(int k) {
        key = k;
        leftChild = nextSibling = prev = nullptr;
    }
};

// Max pairing heap class
class MaxPairingHeap {
public:
    MaxPairingHeap() {
        root = nullptr;
    }

    bool isEmpty() {
        return root == nullptr;
    }

    Node* insert(int key) {
        Node *node = new Node(key);
        root = merge(node, root);
        return node;
    }

    int findMax() {
        if (isEmpty()) {
            cout << "Heap is empty" << endl;
            return -1;
        }
        return root->key;
    }

    Node* deleteMax() {
        Node *maxNode = root;
        if (maxNode == nullptr) {
            cout << "Heap is empty" << endl;
            return nullptr;
        }
        root = mergePairs(root->leftChild);
        return maxNode;
    }
    MaxPairingHeap merge(MaxPairingHeap heap1, MaxPairingHeap heap2){
        MaxPairingHeap heap;
        heap.root = merge(heap1.root, heap2.root);
        return heap;
    }
private:
    Node *root;

    Node* merge(Node *x, Node *y) {
        if (x == nullptr) {
            return y;
        }
        if (y == nullptr) {
            return x;
        }
        if (x->key < y->key) {
            x->prev = y;
            x->nextSibling = y->leftChild;
            if (y->leftChild != nullptr) {
                y->leftChild->prev = x;
            }
            y->leftChild = x;
            return y;
        } else {
            y->prev = x;
            y->nextSibling = x->leftChild;
            if (x->leftChild != nullptr) {
                x->leftChild->prev = y;
            }
            x->leftChild = y;
            return x;
        }
    }

    Node* mergePairs(Node *startNode) {
        if (startNode == nullptr || startNode->nextSibling == nullptr) {
            return startNode;
        }
        Node *nextPair = startNode->nextSibling->nextSibling;
        Node *merged = merge(startNode, startNode->nextSibling);
        merged->nextSibling = mergePairs(nextPair);
        if (merged->nextSibling != nullptr) {
            merged->nextSibling->prev = merged;
        }
        merged->prev = nullptr;
        return merged;
    }
};

int main() {
    int n, q;
    fin>>n;
    MaxPairingHeap heap[101];
    fin>>q;
    for(int i=0;i<q;i++){
        int a,b,c;
        fin>>a;
        if(a==1){
            fin>>b>>c;
            heap[b].insert(c);
        }
        else if(a==2){
            fin>>b;
            fout<<heap[b].findMax()<<endl;
            heap[b].deleteMax();
        }
        else if(a==3){
            fin>>b>>c;
            heap[b]=heap[b].merge(heap[b],heap[c]);
        }
        }
    return 0;
    }