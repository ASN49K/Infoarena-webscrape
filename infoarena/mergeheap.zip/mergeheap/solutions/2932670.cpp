﻿#include <bits/stdc++.h>
using namespace std;
  
class input {

private:

    FILE* fin;
    const int sz = 10000;
    char* buff, c;
    int p;

    char read()
    {
        if (p == sz)
        {
            fread(buff, 1, sz, fin);
            p = 0;
            return buff[p++];
        }
        else
            return buff[p++];
    }

public:
    
    input(const char* name)
    {
        c = '-';
        buff = new char[sz];
        p = sz;
        fin = fopen(name, "r");
    }

    void close()
    {
        fclose(fin);
    }

    void open(const char* name)
    {
        c = '-';
        p = sz;
        fin = fopen(name, "r");
    }

    input& operator >> (int& n)
    {
        c = read();

        while (c == ' ' || c == '\n')
            c = read();

        n = 0;
        int sng = 1;

        if (c == '-')
            sng = -1, c = read();

        while (isdigit(c))
            n = n * 10 + (c - '0'), c = read();

        n *= sng;

        return *this;
    }

    input& operator >> (long long& n)
    {
        c = read();

        while (c == ' ' || c == '\n')
            c = read();

        n = 0;
        int sng = 1;

        if (c == '-')
            sng = -1, c = read();

        while (isdigit(c))
            n = n * 10 + (c - '0'), c = read();

        n *= sng;

        return *this;
    }

    input& operator >> (unsigned long long& n)
    {
        c = read();

        while (c == ' ' || c == '\n')
            c = read();

        n = 0;
        int sng = 1;

        if (c == '-')
            sng = -1, c = read();

        while (isdigit(c))
            n = n * 10 + (c - '0'), c = read();

        n *= sng;

        return *this;
    }

    input& operator >> (char& ch)
    {
        c = read();

        while (c == ' ' || c == '\n')
            c = read();

        ch = c;

        return *this;
    }

    input& operator >> (string& n)
    {
        c = read();

        while (c == ' ' || c == '\n')
            c = read();

        n = "";

        while (c != ' ' && c != '\n' && c != '\0')
            n += c, c = read();

        return *this;
    }

    input& operator >> (double& n)
    {
        c = read();

        while (c == ' ' || c == '\n')
            c = read();

        n = 0;

        while (isdigit(c))
            n = n * 10 + (c - '0'), c = read();

        if (c != '.')
            return *this;

        c = read();

        double p10 = 10;

        while (isdigit(c))
            n = n + double(c - '0') / p10, c = read(), p10 *= 10;

        return *this;
    }

    input& operator >> (char* s)
    {
        c = read();

        while (c == ' ' || c == '\n')
            c = read();

        while (c != ' ' && c != '\n')
            *s = c, s++, c = read();

        *s = '\0';

        return *this;
    }

    void getline(string& s)
    {
        s = "";

        c = read();

        while (c == ' ')
            c = read();

        while (c != '\n')
            s += c, c = read();
    }
};
class output {

private:
    FILE* fout;
    const int sz = 10000;
    char* buff;
    int p;

    void write(char ch)
    {
        if (p == sz)
        {
            fwrite(buff, 1, sz, fout);
            p = 0;
            buff[p++] = ch;
        }
        else
            buff[p++] = ch;
    }

public:

    output(const char* name)
    {
        buff = new char[sz];
        p = 0;
        fout = fopen(name, "w");
    }

    ~output()
    {
        fwrite(buff, 1, p, fout);
    }

    output& operator << (int n)
    {
        if (n < 0)
            write('-'), n *= -1;

        if (n == 0)
        {
            write(n + '0');
            return *this;
        }

        if (n / 10 != 0)
            *this << (n / 10);

        write(('0' + (n % 10)));

        return *this;
    }

    output& operator << (long long n)
    {
        if (n < 0)
        {
            write('-');
            n *= -1;
        }

        if (n < 10)
        {
            write(n + '0');
            return *this;
        }

        *this << (n / 10);
        write((n % 10) + '0');

        return *this;
    }

    output& operator << (unsigned long long n)
    {
        if (n < 0)
        {
            write('-');
            n *= -1;
        }

        if (n < 10)
        {
            write(n + '0');
            return *this;
        }

        *this << (n / 10);
        write((n % 10) + '0');

        return *this;
    }

    output& operator << (char c)
    {
        write(c);
        return *this;
    }

    void precision(double n, int x)
    {
        *this << int(n);

        if (!x)
            return;

        write('.');

        n -= int(n);
        n *= 10;

        for (int i = 1; i <= x; i++)
        {
            *this << int(n);
            n -= int(n);
            n *= 10;
        }
    }

    output& operator << (string n)
    {
        for (auto i : n)
            write(i);
        return *this;
    }
};

input fin("mergeheap.in");
output fout("mergeheap.out");

struct nod {
    int val;

    nod* down, * next;

    nod(int x)
    {
        val = x;
        down = next = NULL;
    }
};

class heap {
private:

    nod * root;
    int sz;

    nod* merge(nod * a, nod * b)
    {
        if (a == NULL)
            return b;
        else if (b == NULL)
            return a;

        if (a->val < b->val)
            swap(a, b);

        b->next = a->down;
        a->down = b;

        return a;
    }

    nod* sub(nod * a)
    {
        if (a == NULL || a->next == NULL)
            return a;

        nod* b = a->next;
        nod* next = a->next->next;

        return merge(merge(a, b), sub(next));
    }

public:

    heap () 
    {
        root = NULL;
        sz = 0;
    }

    void merge(heap H)
    {
        sz += H.sz;
        root = merge(root, H.root);
    }

    void add(int x)
    {
        sz++;
        if (root == NULL)
        {
            root = new nod(x);
            return;
        }

        nod* p = new nod(x);
        root = merge(root, p);
    }

    void pop()
    {
        sz--;

        if (!sz)
        {
            root = NULL;
            return;
        }

        root = sub(root->down);
    }

    int top()
    {
        return root->val;
    }

    void clear()
    {
        root = NULL;
    }
};

heap H[101];
int n, q;

int main()
{
    heap h;
    h.add(1);
    h.pop();

    return 0;

    fin >> n >> q;

    for (int i = 1; i <= q; i++)
    {
        int caz;
        fin >> caz;

        if (caz == 1)
        {
            int m, x;
            fin >> m >> x;
            H[m].add(x);
        }
        else if (caz == 2)
        {
            int m;
            fin >> m;
            fout << H[m].top() << '\n';
            H[m].pop();
        }
        else
        {
            int a, b;
            fin >> a >> b;

            H[a].merge(H[b]);
            H[b].clear();
        }
    }

    return 0;
}