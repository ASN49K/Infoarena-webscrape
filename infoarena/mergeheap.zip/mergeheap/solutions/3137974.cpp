#include <bits/stdc++.h>
using namespace std;
ifstream f("mergeheap.in");
ofstream g("mergeheap.out");
struct nod;
typedef nod* pNod;
struct nod
{
    int val;
    pNod fiu,frate;
    nod(){val=0;fiu=frate=NULL;}
    nod(int _val){val=_val;fiu=frate=NULL;}
};
inline pNod unite(pNod A,pNod B)
{
    if(B==NULL)return A;
    if(A==NULL){A=B;return A;}
    if(A->val<B->val)swap(A,B);
    B->frate=A->fiu;A->fiu=B;return A;
}
inline pNod toHeap(pNod A){return (A==NULL||A->frate==NULL)?A:unite(unite(A,A->frate),toHeap(A->frate->frate));}
inline pNod addVal(pNod A,int x){pNod B=new nod(x);return unite(A,B);}
inline pNod query(pNod A){g<<A->val<<'\n';pNod B=A->fiu;delete A;return toHeap(B);}
int n,q;
pNod H[101];
int main()
{

    f >> n >> q;
    for(;q;q--)
    {
        int tip,i,j;f>>tip>>i;if(tip&1)f>>j;
        if(tip==1)H[i]=addVal(H[i],j);
        else if(tip==2) H[i]=query(H[i]);
        else{H[i]=unite(H[i],H[j]);H[j]=NULL;}
    }
    return 0;
}
