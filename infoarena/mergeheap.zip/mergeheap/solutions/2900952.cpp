#include <bits/stdc++.h>
#pragma GCC optimize ("O3")

using namespace std;

const int NMAX = 100;

priority_queue <int> pq[NMAX + 1];

class InParser {
private:
	FILE *fin;
	char *buff;
	int sp;

	char read_ch() {
		++sp;

		if (sp == 8192) {
			sp = 0;
			fread(buff, 1, 8192, fin);
		}
		return buff[sp];
	}

public:
	InParser(const char* nume) {
		fin = fopen(nume, "r");
		buff = new char[8192]();
		sp = 8192 - 1;
	}

	InParser& operator >> (int &n) {
		char c;
		while (!isdigit(c = read_ch()) && c != '-');
		int sgn = 1;
		if (c == '-') {
			n = 0;
			sgn = -1;
		} else {
			n = c - '0';
		}
		while (isdigit(c = read_ch())) {
			n = 10 * n + c - '0';
		}
		n *= sgn;
		return *this;
	}

};
class OutParser {
private:
    FILE *fout;
    char *buff;
    int sp;

    void write_ch(char ch) {
        if (sp == 10000) {
            fwrite(buff, 1, 10000, fout);
            sp = 0;
        }
        buff[sp++] = ch;
    }


public:
    OutParser(const char* name) {
        fout = fopen(name, "w");
        buff = new char[10000]();
        sp = 0;
    }
    ~OutParser() {
        fwrite(buff, 1, sp, fout);
        fclose(fout);
    }

    OutParser& operator << (int vu32) {
        if (vu32 <= 9) {
            write_ch(vu32 + '0');
        } else {
            (*this) << (vu32 / 10);
            write_ch(vu32 % 10 + '0');
        }
        return *this;
    }
    OutParser& operator << (char ch) {
        write_ch(ch);
        return *this;
    }
    OutParser& operator << (const char *ch) {
        while (*ch) {
            write_ch(*ch);
            ++ch;
        }
        return *this;
    }
};

int main() {
    InParser fin( "mergeheap.in" );
    OutParser fout( "mergeheap.out" );
    int n, q, tip, m, x;
    fin >> n >> q;
    while ( q-- ) {
        fin >> tip >> m;
        if ( tip == 1 ) {
            fin >> x;
            pq[m].push( x );
        } else if ( tip == 2 ) {
            fout << pq[m].top() << '\n';
            pq[m].pop();
        } else {
            fin >> x;
            if ( pq[x].size() > pq[m].size() )
                swap( pq[m], pq[x] );
            while ( !pq[x].empty() ) {
                pq[m].push( pq[x].top() );
                pq[x].pop();
            }
        }
    }
    return 0;
}
