#include <fstream>
using namespace std;

ifstream cin ("mergeheap.in");
ofstream cout ("mergeheap.out");

struct Nod {
    int valoare;
    Nod *frate , *fiu;
    Nod () : valoare(0) , frate(NULL) , fiu(NULL)
        { }
    Nod (const int _valoare) : valoare(_valoare)
        { }
} *multime[101];

Nod* Unire (Nod *rezultat , Nod *termen)
{
    if (termen == NULL)
        { return rezultat; }
    if (rezultat == NULL)
        { return (rezultat = termen); }
    if (rezultat -> valoare < termen -> valoare)
        { swap(rezultat , termen); }
    termen -> frate = rezultat -> fiu;
    rezultat -> fiu = termen;
    return rezultat;
}

Nod* toHeap (Nod *nod_actual)
{
    return (nod_actual == NULL || nod_actual -> frate == NULL ? nod_actual : Unire(Unire(nod_actual , nod_actual -> frate) , toHeap(nod_actual -> frate -> frate)));
}

int main ()
{
    int numar_operatii;
    for (cin >> numar_operatii >> numar_operatii ; numar_operatii-- ; )
    {
        int8_t tip;
        cin >> tip;

        if (tip == '1')
        {
            int indice , valoare;
            cin >> indice >> valoare;
            Nod *temporar = new Nod; temporar -> valoare = valoare;
            multime[indice] = Unire(multime[indice] , temporar);
        }
        else
            if (tip == '2')
            {
                int indice;
                cin >> indice;
                cout << multime[indice] -> valoare << '\n';

                Nod *anterior = multime[indice];
                multime[indice] = toHeap(multime[indice] -> fiu); 
                delete anterior;
            }
        else
        {
            int indice_1 , indice_2;
            cin >> indice_1 >> indice_2;
            multime[indice_1] = Unire(multime[indice_1] , multime[indice_2]);
        }
    }

    cout.close(); cin.close();
    return 0;
}