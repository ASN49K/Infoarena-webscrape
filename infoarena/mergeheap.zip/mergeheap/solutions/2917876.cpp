// solutie okish, cu small-to-large (va lua aproximativ 70p)
#include <bits/stdc++.h>

#pragma GCC optimize("Ofast,unroll-loops")

using namespace std;

ifstream fin("mergeheap.in");
ofstream fout("mergeheap.out");

const int NMAX = 100;

int n, q;
multiset<int, greater<int>> pq[NMAX + 1];

int main() {
	fin >> n >> q;

	for(int i = 1; i <= q; i++) {
		int task;
		fin >> task;

		if(task == 1) {
			int m, x;
			fin >> m >> x;

			pq[m].insert(x);
		} else if(task == 2) {
			int m;
			fin >> m;

			fout << *pq[m].begin() << '\n';
			pq[m].erase(pq[m].begin());
		} else {
			int a, b;
			fin >> a >> b;

			if(pq[a].size() < pq[b].size()) {
				pq[a].swap(pq[b]);
			}

			pq[a].insert(pq[b].begin(), pq[b].end());
			pq[b].clear();
		}
	}
	return 0;
}