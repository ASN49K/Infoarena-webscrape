#include<bits/stdc++.h>

using namespace std;

ifstream in ("mergeheap.in");
ofstream out ("mergeheap.out");

struct nod
{
    int val;
    nod *copil_st,*urm_copil;

    nod(){copil_st = nullptr;urm_copil = nullptr;}

    nod(int k, nod *cs, nod *uc){val = k; copil_st = cs; urm_copil = uc;}

    void adauga_fiu(nod *n)
    {
        if(copil_st == nullptr)   copil_st = n;

        else
        {
            n->urm_copil = copil_st;
            copil_st = n;
        }
    }
};

nod *merging(nod *A, nod *B)
{
    if(A == nullptr) return B;
    if(B == nullptr) return A;

    if(A->val < B->val)
    {
        A->adauga_fiu(B);
        return A;
    }
    else
    {
        B->adauga_fiu(A);
        return B;
    }

    return nullptr;
}

nod *reconstruire(nod *n)
{
    if(n == nullptr || n->urm_copil == nullptr)   return n;

    nod *A, *B, *nod_nou;
    A = n;
    B = n->urm_copil;
    nod_nou = n->urm_copil->urm_copil;

    A->urm_copil = nullptr;
    B->urm_copil = nullptr;

    return merging(merging(A, B), reconstruire(nod_nou));

    return nullptr;
}

struct pairingheap
{
    nod *rad;

    pairingheap(){rad = nullptr;}

    bool Empty()
    {
        return rad==nullptr;
    }

    int Top()
    {
        return rad->val;
    }

    void Insert(int val)
    {
        rad = merging(rad, new nod(val, nullptr, nullptr));
    }

    void Delete()
    {
        rad = reconstruire(rad->copil_st);
    }

    void Join(pairingheap celalalt_heap)
    {
        rad = merging(rad, celalalt_heap.rad);
    }
};

int main()
{
    int n,q,opcode,m,x,a,b;

    in>>n>>q;

    pairingheap heapuri[105];

    for (int i = 0; i < q; i++)
    {
        in>>opcode;

        switch (opcode)
        {
            case 1:
                in>>m>>x;
                heapuri[m].Insert(x);
            case 2:
                in>>m;
                out<<heapuri[m].Top()<<"\n";
                heapuri[m].Delete();
            case 3:
                in>>a>>b;
                heapuri[a].Join(heapuri[b]);
                heapuri[b].rad = nullptr;
        }
    }


    return 0;
}
