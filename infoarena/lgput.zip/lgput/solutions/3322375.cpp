#include <bits/stdc++.h>
#define ll long long

using namespace std;
ifstream fin ("lqput.in");
ofstream fout ("lgput.out");

const int MOD = 1999999973;

ll n, p;
ll fastexp(ll a, ll b){
    if(b == 0) return 1;
    else{
        ll e = fastexp(a, b / 2);
        if(b % 2 == 0) return (e * e) % MOD;
        else return ((e * e) % MOD * a % MOD) % MOD;
    }
}

int main()
{
    fin >> n >> p;
    fout << fastexp(n, p);
    return 0;
}
