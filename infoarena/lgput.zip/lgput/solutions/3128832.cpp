#include <iostream>
#include <fstream>

using namespace std;
ifstream in("fisier.in");
ofstream out("fisier.out");
constexpr long long mod = 1999999973;
long long pow(int a, int p)
{
    long long r = 1;
    while(p)
    {
        if ( p & 1 )
            r *= a%mod, r%=mod;
        a*=a%mod;
        a%=mod;
        p>>=1;
    }
    return r;
}
int main()
{
    int a, b;
    in >> a >> b;
    out << pow(a, b);

    return 0;
}
