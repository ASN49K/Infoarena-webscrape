#include <fstream>

using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long a, b, k=1999999973;

long long rad(long long a, long long b)
{
    if(b==0) return 1;
    else
    if(b%2==0)
    {
        return (rad(a%k, b/2)*rad(a%k, b/2))%k;
    }
    else
    if(b%2==1)
    {
        return (rad(a%k, b-1)*a%k)%k;
    }
}

int main()
{
    fin>>a>>b;
    fout<<rad(a, b);
    return 0;
}
