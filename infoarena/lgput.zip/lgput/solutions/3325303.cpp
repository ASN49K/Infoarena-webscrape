#include<fstream>
#include<iostream>
using namespace std;

int main() {
	ifstream fin("lgput.in");
	ofstream fout("lgput.out");

#define mod 1999999973
	unsigned long long n, p;
	fin >> n >> p;
	n %= mod;
	p %= mod;
	while (p) {
		if (p % 2) {
			n *= p, n %= mod, p--;
		}
		else {
			n %= mod;
			n *= n;
			n %= mod;
			p /= 2;
		}
	}
	fout << n;
	return 0;
}