#include<fstream>
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
const int N=2e9-27;
int main()
{
    int n,p,r=1;
    for(cin>>n>>p;p;n=1LL*n*n%N,p>>=1)
        if(p&1)
            r=1LL*r*n%N;
    return cout<<r,0;
}
