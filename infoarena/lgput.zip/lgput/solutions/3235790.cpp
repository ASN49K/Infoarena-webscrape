#include <fstream>

using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
const int mod= 1999999973;
long long lgpow(long long b,int exp)
{
    if(exp==0)
        return 1;
    if(exp%2==0)
    {
        return lgpow(b*b%mod,exp/2);
    }
    return b*lgpow(b,exp-1)%mod;
}
int main()
{
    long long n;
    int p;
    fin>>n>>p;
    fout<<lgpow(n,p)%mod;
    return 0;
}
