#include <iostream>
#include <fstream>
#define int long long
using namespace std;

int32_t main()
{
    ifstream cin("lgput.in");
    ofstream cout("lgput.out");
    int a,b,rez=1;
    cin>>a>>b;
    while(b>0)
    {
        if(b%2==1)
            rez*=a;
        a*=a;
        b/=2;
    }
    cout<<rez;

    return 0;
}
