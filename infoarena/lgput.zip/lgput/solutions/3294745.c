#include <stdio.h>

#define MOD 1999999973

long long ridicareLaPutere(long long n, long long p) {
    if(p == 0) {
        return 1;
    }

    long long x = ridicareLaPutere(n, p / 2) % MOD;

    if(p % 2 == 0) {
        return (x * x) % MOD;
    } else {
        return n * x * x % MOD;
    }
}

int main() {
    FILE *input = fopen("lgput.in", "r");
    FILE *output = fopen("lgput.out", "w");

    long long n, p;
    n %= MOD;
    fscanf(input, "%lld %lld", &n, &p);
    fprintf(output, "%lld\n", ridicareLaPutere(n, p));

    fclose(input);
    fclose(output);

    return 0;
}