#include <fstream>
#define mod 1999999973
using namespace std;
ifstream fin ("lgput.in");
ofstream fout ("lgput.out");
long long a,b,p;
int main()
{
    fin>>a>>b;
    p=1;
    while (b!=0)
    {
        if (b%2!=0)
            p=p*a;
        a=a*a%mod;
        p=p%mod;
        b=b/2;
    }
    fout<<p;
    return 0;
}
