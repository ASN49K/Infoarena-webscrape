#include <bits/stdc++.h>

using namespace std;

int64_t const MOD = 1999999973;
int const inf = 2e9;

int64_t n , p;

int64_t expo(int64_t a , int64_t b){
int64_t r = 1;
while(b){
    if(b & 1)r = r * a % MOD;
    b >>= 1;
    a = a * a % MOD;
}
return r;
}

int main()
{
    freopen("lgput.in" , "r" , stdin);
    freopen("lgput.out" , "w" , stdout);
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);
    cin >> n >> p;
    cout << expo(n , p);
}
