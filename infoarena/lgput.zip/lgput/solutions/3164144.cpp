#include <iostream>
#include <fstream>
using namespace std;

//ifstream cin("lgput.in");
//ofstream cout("lgput.out");

const long long mod = 1999999973;

long long power(long long a, long long n)
{
    long long p = 1;
    while(n)
    {
        if(n%2 == 1)
            p *= a, p %= mod;
        a *= a;
        a %= mod;
        n /= 2;
    }

    return p % mod;
}

int main()
{
    long long n, p;
    cin>>n>>p;

    cout<<power(n, p);

    return 0;
}


