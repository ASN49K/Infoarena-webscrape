#include <stdio.h>
#define Mod 1999999973
int Putere(int A, int n)
{
    unsigned long long res = 1;
    while (n > 0)
    {
        if (n % 2 == 1)
        {
            res = (1LL * res * A) % Mod;
        }
        A = (1LL * A * A) % Mod;
        n = n / 2;
    }
    return res;
}
int main()
{
    unsigned int n, p;
    long long int res = 0;
    freopen("lgput.in", "r", stdin);
    freopen("lgput.out", "w", stdout);
    scanf("%d %d", &n, &p);
    res = Putere(n, p);
    printf("%lld", res);
    return 0;
}