#include <iostream>
#include <fstream>

using namespace std;
ifstream fcin("lgput.in");
ofstream fout("lgput.out");

long long n, p;

int main()
{
    fcin>>n>>p;
    long long rez=1;
    n=n%1999999973;
    for (; p; p>>=1)
    {
        if (p & 1)
        {
            rez=rez*n;
            rez=rez%1999999973;
        }
        n=n*n;
        n=n%1999999973;
    }

    fout<<rez;
}
