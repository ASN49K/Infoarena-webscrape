#include<fstream>

using namespace std;


ifstream cin("Igput.in");
ofstream cout("Igput.out");

#define MOD 1999999973


long long fastEXP(long long a, long long b)
{
  if(b==0)
    return 1;
  else if(b%2==1)
    return (a* fastEXP((a*a)%MOD, (b-1)/2))%MOD;
  else
    return fastEXP((a*a)%MOD , b/2);
}


int main()
{
  long long a, b;

  cin>>a>>b;
  
  cout<<fastEXP(a, b)%MOD;

  return 0;
}
