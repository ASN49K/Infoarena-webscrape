#include <fstream>

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

long long lgput(long long base, long long exp) {
    if (exp == 0) return 1;

    long long half = lgput(base, exp / 2);
    if (exp % 2 == 0) {
        return half * half;
    } else {
        return base * half * half;
    }
}

int main() {
    int a, b; cin >> a >> b;
    cout << lgput(a, b);
    return 0;
}
