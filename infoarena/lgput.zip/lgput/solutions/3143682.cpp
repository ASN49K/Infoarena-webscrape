#include <iostream>
#include <vector>
#include <map>
#include <cstring>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include <queue>
#include <cmath>
#include <set>
#include <unordered_map>
#include <stack>
#include <iomanip>
#include <random>
#include <climits>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const int long MAX = 1999999973;

long long power(long long a, long long b) {
    if (b == 0) {
        return 1;
    }
    if (b % 2 == 0) {
        return power(a, b / 2) % MAX * power(a, b / 2) % MAX;
    }
    return a % MAX * power(a, b - 1) % MAX;
}

int main() {
    long long a, b;
    fin >> a >> b;

    fout << power(a, b);

    return 0;
}