#include <bits/stdc++.h>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

#define cin fin
#define cout fout
#define qwe 1999999973

long long a,b;

long long putere(long long a, long long b)
{
    if(b==0) return 1;
    long long x=putere(a,b/2);
    if(b%2==0) return x*x%qwe;
    else return x*x%qwe*a%qwe;
}

int main()
{
   cin>>a>>b;
   cout<<putere(a,b);
    return 0;
}
