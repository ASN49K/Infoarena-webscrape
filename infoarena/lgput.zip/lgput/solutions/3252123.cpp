#include<fstream>
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

int mod = 1999999973;

long long fast_exp(long long a, int b)
{
    long long ans = 1;
    while(b)
    {
        if(b%2)
            ans = (ans*a)%mod;
        a = (a*a)%mod;
        b /= 2;
    }
    return ans;
}

int main()
{
    long long n, p;
    fin>> n>> p;

    fout<< fast_exp(n%mod, p);

    fin.close();
    fout.close();
    return 0;
}
