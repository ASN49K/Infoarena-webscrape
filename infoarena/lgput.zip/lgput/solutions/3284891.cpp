#include <bits/stdc++.h>

using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
#define int long long
const int MOD = 1999999973;

inline int expRapida(int A, int n) {
    ///returneaza A^n
    int p = 1;
    while(n) {
        if(n % 2 == 1) p = (1LL * p * A) % MOD;
        A = (1LL * A * A) % MOD, n /= 2;
    }
    return p;
}

signed main()
{
    int a, b; fin >> a >> b;
    fout << expRapida(a, b);

    return 0;
}
