#include<bits/stdc++.h>
#pragma GCC optimize("Ofast,unroll-loops,inline")
#define fast ios_base::sync_with_stdio(0);f.tie(0);g.tie(0);
using namespace std;
const string file="lgput";
ifstream f(file+".in");
ofstream g(file+".out");
//#define f cin
//#define g cout
#define ll long long
#define mod 1999999973
ll n,p;
ll lgpow(ll b, ll exp){
    ll r=1;
    while(exp){
        if(exp&1) r=1LL*r*b%mod;
        b=1LL*b*b%mod;
        exp>>=1;
    }
    return r;
}
int main(){
    f>>n>>p;
    g<<lgpow(n,p)%mod;
    return 0;
}
