#include <fstream>
using namespace std;
ifstream f("lgput.in");
ofstream g("lgput.out");
#define MOD 1999999973
long long calc(long long n, long long p){
  if(p==0){
    return 1;
  }
  if(p%2==0){
    return calc(((n%MOD)*(n%MOD))%MOD, p/2); 
  }
  return n%MOD * calc(((n%MOD)*(n%MOD))%MOD, (p-1)/2);
}
int main(){
  long long n,p;
  f>>n>>p;
  g<<calc(n,p);

  f.close();
  g.close();
  return 0;
}