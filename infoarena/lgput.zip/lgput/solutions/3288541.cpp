#include <bits/stdc++.h>
using namespace std;
const long long MOD = 1999999973;
long long pownt(long long n, long long p)
{
    if(p == 0)
    {
        return 1;
    }
    if((p & 1))
    {
        return (n * pownt(n, p - 1)) % MOD; 
    }
    else
    {
        long long x = pownt(n, (p >> 1));
        return (x * x) % MOD;
    }
}
int main()
{
    freopen("lgput.in", "r", stdin);
    freopen("lgput.out", "w", stdout);
    cin.tie(nullptr)->sync_with_stdio(false);
    long long n, p;
    cin >> n >> p;
    cout << pownt(n, p);
}