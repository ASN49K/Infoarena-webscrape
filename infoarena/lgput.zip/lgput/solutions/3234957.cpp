#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long power_log(long long a, long long b, long long MOD) {
    long long ans = 1;
    while (b) {
        if (b & 1) {
            ans = ans * a;
            if (ans >= MOD) {
                ans %= MOD;
            }
        }
        a = a * a;
        if (a >= MOD) {
            a %= MOD;
        }
        b >>= 1;
    }
    return ans;
}

int main() {

    long long N, P;
    fin >> N >> P;
    fout << power_log(N, P, 1999999973) << '\n';
    return 0;
}