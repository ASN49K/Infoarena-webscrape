#include <bits/stdc++.h>
#define mod 1999999973
#define t long long
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

t n, p;

t Putere(t a, t x)
{
    t p = 1;
    while(x != 0)
    {
        if(x % 2 == 1) p = p * a % mod;
        a = a * a % mod;
        x /= 2;
    }
    return p;
}

int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    fin >> n >> p;
    fout << Putere(n, p) << " ";
    fin.close();
    fout.close();
    return 0;
}
