#include <iostream>
#include <fstream>
#define int unsigned long long
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
const int ma = 1999999973;
int putere(int a, int b)
{
    int ans = 1;
    while(b)
    {
        if(b%2 == 1)
        {
            ans =(ans%ma* a)%ma;
        }
        a= (a%ma*a)%ma;
        b /= 2;
    }
    return ans;
}
signed main()
{
    int a, b;
    fin >> a >> b;
    fout << putere(a, b);
    return 0;
}
