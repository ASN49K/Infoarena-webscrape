#include <iostream>
#include <fstream>

using namespace std;

int mod = 1999999973;

int exp(int a, int n) {
    if (n == 1) return a;
    if (n == 0) return 1;

    if (n % 2 == 0) {
        long long int aux = exp(a, n / 2);
        return (aux * aux) % mod;
    } else if (n % 2 == 1) {
        long long int aux = exp(a, n / 2);
        return (((aux * aux) % mod) * a) % mod;
    }
}

int main() {
    ifstream cin("lgput.in");
    ofstream cout("lgput.out");

    int a, b;

    cin >> a >> b;

    cout << exp(a, b) << endl;

    return 0;
}