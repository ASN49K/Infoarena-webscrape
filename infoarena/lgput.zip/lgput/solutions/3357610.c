#include <stdio.h>

#define MOD 1999999973LL

long long lgput(long long n, long long p) {
    long long r = 1;
    while (p > 0) {
        if (p % 2 == 1) {
            r = (r * n) % MOD;
        }
        n = (n * n) % MOD;
        p = p / 2;
    }
    return r;
}

int main() {
    FILE *fin = fopen("lgput.in", "r");
    FILE *fout = fopen("lgput.out", "w");
    
    long long n, p;
    fscanf(fin, "%lld %lld", &n, &p);
    fprintf(fout, "%lld\n", lgput(n, p));
    
    fclose(fin);
    fclose(fout);
    return 0;
}