#include <stdio.h>
const long long mod = 1999999973LL;
long long explog(unsigned int x, unsigned int n) {
  long long sol = 1, cop = x;
  if (n == 0)
    return 1;
  for (unsigned int i = 0; (1 << i) <= n; ++i) {

    if (((1 << i) & n) > 0)
      sol = (sol*cop) % mod;
    cop = (cop*cop)%mod;
  }
  return sol;
}

int main(void) {

  FILE *in = fopen("lgput.in", "r");
  FILE *out = fopen("lgput.out", "w");
  unsigned int n, p; 
  fscanf(in, "%d %d", &n, &p);

  fprintf(out, "%lld", (explog(n, p)));
  return 0;
}