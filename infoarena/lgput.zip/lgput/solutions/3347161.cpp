#include <fstream>
using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

int putere(int n, int p)
{
    int P = 1;
    while(p > 0)
    {
        if (p % 2 == 1) P = P * n;
        n = n * n;
        p /= 2;
    }
    return P;
}

int main()
{
    int n, p;
    long long temp;
    cin >> n >> p;
    temp = putere(n, p);
    if (temp < 1999999973) cout << temp;
    else cout << temp % 1999999973;
}