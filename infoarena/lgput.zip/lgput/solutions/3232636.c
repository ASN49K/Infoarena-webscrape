#include <stdio.h>
#include <stdlib.h>

#define MOD 1999999973
#define FILE_IN "lgput.in"
#define FILE_OUT "lgput.out"

long long int exponentiate(long long int x, long long int n) {
    if(n == 0) return 1;
    if(n < 0) {
        x = 1 / x;
        n = -n;
    }
    long long int y = 1;
    while(n > 1) {
        if(n % 2) {
            y = y * x;
            y = y % MOD;
            n--;
        }
        x = x * x;
        x = x % MOD;
        n = n / 2;
    }

    return y * x;
}

int main()
{
    FILE *fileIn = fopen(FILE_IN, "r"),
         *fileOut = fopen(FILE_OUT, "w");
    long long int n, p;

    fscanf(fileIn, "%lld%lld", &n, &p);

    long long int result = exponentiate(n, p);
    fprintf(fileOut, "%lld\n", result);

    fclose(fileIn);
    fclose(fileOut);

    return 0;
}
