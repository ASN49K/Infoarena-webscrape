#include <fstream>
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const int MOD = 1999999973;


int lgput(int b, int e, int mod){
    int p = 1;

    while (e>0){
        if (e%2){
            p=(1LL*p*b)%mod;
        }
        b=(1LL*b*b)%mod;
        e/=2;

    }

    return p;

}

int main(){
    int b,e;
    fin>>b>>e;

    fout<<lgput(b, e, MOD);
}
