#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const int MOD = 1999999973;

long long powlg(long long x, long long y)
{
	long long val = 1, a = x % MOD;
	while(y)
	{
		if(y % 2 != 0)
		{
			val = val * a % MOD;
		}
		a = a * a % MOD;
		y /= 2;
	}
	return val;
}
int main()
{
	long long N, P;
	fin >> N >> P;
	fout << powlg(N,P);
	fin.close();
	fout.close();
	return 0;
}
