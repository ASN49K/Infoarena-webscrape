#include <fstream>

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

long long Putere(long long A , long long n)
{
    long long P = 1;
    for(long long k = 1 ; k <= n ; k <<= 1)
    {
        if((n & k))
            P *= A;
        A = A * A;
    }
    return P%1999999973;
}

int main()
{
    long long n,m;
    cin>>n>>m;
    cout<<Putere(n,m);
    return 0;
}
