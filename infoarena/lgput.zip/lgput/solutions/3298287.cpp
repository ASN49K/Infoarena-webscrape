#include <iostream>
using namespace std;

int main()
{
    int n,p;
    cin>>n>>p;
    int s = 1;
    for(int i = 0;i<p;i++){
        s = s * n;
    }
    cout<<(s % 1999999973);

    return 0;
}