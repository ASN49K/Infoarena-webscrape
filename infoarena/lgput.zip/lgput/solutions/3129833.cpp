#include <fstream>
using namespace std;
ifstream f("lgput.in");
ofstream g("lgput.out");
int mod=1999999973;
long long calcul(long long a, long long b)
{
    if(b==0)
        return 1;
    else
    {
        long long crt=calcul(a, b/2);
        if(b%2==0)
            return crt*crt%mod;
        else
            return crt*crt%mod*a%mod;
    }
}
long long n, m;
int main()
{
    f>>n>>m;
    g<<calcul(n, m);
}
