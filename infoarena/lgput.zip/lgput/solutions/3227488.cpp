#include <iostream>
#include <fstream>
using namespace std;

ifstream in("lgput.in");
ofstream out("lgput.out");

long long lgpow(long long base,long long exp)
{
    if(exp==0)
        return 1;
    if(exp%2==0)
    {
        long long half=lgpow(base,exp/2);
        return half*half%1999999973;
    }
    return base*lgpow(base,exp-1)%1999999973;
}

int main()
{
    long long n,p;
    in>>n>>p;
    long long putere=lgpow(n,p)%1999999973;
    out<<putere;
    return 0;
}
