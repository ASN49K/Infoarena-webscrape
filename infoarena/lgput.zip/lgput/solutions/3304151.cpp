#include <fstream>

using namespace std;
ifstream cin ("lgput.in");
ofstream cout ("lgput.out");
int main()
{
    unsigned long long n, p, prod = 1;
    cin >> n >> p;
    while(p > 0)
    {
        if (p % 2 == 1)
        {
            prod = prod * n % 1999999973;
        }
        n = (n * n) % 1999999973;
        p = p / 2;
    }
    //cout << prod << endl;
    cout << prod;
    return 0;
}
