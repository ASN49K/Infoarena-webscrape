#include <fstream>

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

const int MOD = 1999999973;

int lgput(int n, int p){
    int rez = 1;
    while(p){
        if(p % 2 == 1)
            rez *= n;
        n *= n;
        p /= 2;
    }
    return rez;
}

int main() {
    int n, p;
    cin >> n >> p;
    cout << lgput(n, p) % MOD;
    return 0;
}
