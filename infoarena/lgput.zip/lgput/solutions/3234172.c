#include <stdio.h>
#include <stdlib.h>

long long int power(long long int n, long long int p, long long int m){ 
    long long int sol = 1; 
    n = n % m;
    if(n == 0) 
    	return 0;
    while(p > 0){  
        if (p & 1) 
            sol = (sol*n) % m;  
        p = p>>1; 
        n = (n*n) % m; 
    } 
    return sol; 
} 
 
int main() 
{ 
	long long int n,p,sol;
	long long int m=1999999973;
	FILE *f,*g;
	if((f=fopen("lgput.in","r"))==NULL){
		printf("eroare fisier\n");
		exit(1);
	}
	if((g=fopen("lgput.out","w"))==NULL){
		printf("eroare fisier\n");
		exit(1);
	}
	fscanf(f,"%lld",&n);
	fscanf(f,"%lld",&p);
	sol=power(n,p,m);
	fprintf(g,"%lld",sol);
	fclose(f);
	fclose(g);
} 
