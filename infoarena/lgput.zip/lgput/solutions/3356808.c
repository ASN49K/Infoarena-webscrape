#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define MOD 1999999973ULL

uint64_t fast_pow(uint64_t n, uint64_t p, uint64_t mod){
  uint64_t result = 1;
  n = n % mod;

  while(p > 0){
    if(p & 1){
      result = (result * n) % mod;
    }
    n = (n * n) % mod;
    p >>= 1;
  }

  return result;
}

int main(void){
  FILE* fin  = NULL;
  FILE* fout = NULL;

  fin = fopen("lgput.in", "r");
  if(fin == NULL){
    perror("lgput.in");
    return 1;
  }

  fout = fopen("lgput.out", "w");
  if(fout == NULL){
    perror("lgput.out");
    fclose(fin);
    return 1;
  }

  uint64_t n = 0, p = 0;
  fscanf(fin, "%lu %lu", &n, &p);

  uint64_t result = fast_pow(n, p, MOD);
  fprintf(fout, "%lu\n", result);

  fclose(fin);
  fclose(fout);
  return 0;
}
