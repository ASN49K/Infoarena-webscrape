#include <bits/stdc++.h>

using namespace std;

#define INFILE "lgput.in"
#define OUTFILE "lgput.out"

typedef long long ll;

const int MOD = 1999999973;

ll ridicare(int baza, int putere, int mod){
    baza %= mod;
    ll ans = 1;
    while(putere > 0){
        if(putere & 1) ans = ans * baza % mod;
        baza = baza * baza % mod;
        putere >>= 1;
    }
    return ans;
}

void solve(){

    ll nr1, nr2; cin >> nr1 >> nr2;

    cout << ridicare(nr1, nr2, MOD) << '\n';

}

int main(){
    ios_base::sync_with_stdio(false);
    freopen(INFILE, "r", stdin);
    freopen(OUTFILE, "w", stdout);
    cin.tie(0), cout.tie(0);
    solve();
    return 0;
}
