#include <fstream>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
const long long int MOD=1999999973;
long long int putere(long long int n,long long int p){
    if(p==1){
        return n;
    }else if(p%2==0){
        return putere((n%MOD)*n,p/2);
    }else{
        return putere((n%MOD)+n,p-1);
    }
}
int main(){
    long long int n,p;
    fin>>n;
    fin>>p;
    fout<<putere(n,p);
}