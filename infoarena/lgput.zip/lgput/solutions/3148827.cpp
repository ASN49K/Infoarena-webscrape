#include <fstream>
#include <vector>
#include <algorithm>
#include <cstring>
#include <unordered_map>
#include <stack>
//#define CONSOLE /// daca ai in consola
#define int long long
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");
 
#ifdef CONSOLE
    #include <iostream>
    #define fin cin 
    #define fout cout 
#endif
int lgpow(int n,int x){
    if(n==0) return 1;
    if(n%2) return x*lgpow((n-1)/2,x*x)%1999999973;
    return lgpow(n/2,x*x)%1999999973;
}
signed main() {
    int n,x;
    fin>>n;
    fin>>x;
    fout<<lgpow(n,x);
    return 0;
}