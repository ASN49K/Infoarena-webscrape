#include <stdio.h>

const int MOD = 1999999973;

int ridicareLaPutere(int N, int P) {
    int r = 1;
    while(P) {
        if(P % 2 == 1) {
            r = (1LL * r * N) % MOD;
        }
        N = (1LL * N * N) % MOD;
        P = P / 2;
    }
    return r;
}

int main() {
    FILE *intrare = fopen("lgput.in", "r");
    FILE *iesire = fopen("lgput.out", "w");
    if(intrare == NULL || iesire == NULL) {
        return 1;
    }
    int N, P;
    fscanf(intrare, "%d %d", &N, &P);
    int rezultat = ridicareLaPutere(N, P);
    fprintf(iesire, "%d\n", rezultat);
    fclose(intrare);
    fclose(iesire);
    return 0;
}