#include <iostream>
#include <fstream>
using namespace std;
const int MOD = 1999999973;
ifstream f("lgput.in");
ofstream g("lgput.out");
long long put3(long long x, long long n)
{
    long long val = 1, a = x % MOD;
    while(n > 0)
    {
        if(n & 1)
            val *= a % MOD ;
        a *= a;
        n >>= 1 % MOD;
    }
    return val;
}
int main()
{
   long long n, p;
   f >> n >> p;
   g << put3(n, p);
}
