#include <stdio.h>

#define MOD 1999999973ULL

int main()
{
    FILE *fin = fopen("lgput.in", "r");
    FILE *fout = fopen("lgput.out", "w");

    unsigned long n, p, rez = 1;

    fscanf(fin, "%lu %lu", &n, &p);

    n %= MOD;

    while(p > 0)
    {
        if(p & 1)
        {
            rez = (rez * n) % MOD;
        }

        n = (n * n) % MOD;
        p >>= 1;
    }

    fprintf(fout, "%lu\n", rez);

    fclose(fin);
    fclose(fout);

    return 0;
}