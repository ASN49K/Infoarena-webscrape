#include <fstream>

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");
long long n, p;
long long MOD = 1999999973;

int main()
{
    cin>>n>>p;

    long long rez = 1;
    for(int i = 1; i<=p; i++)
    {
        rez = (rez * n) % MOD;
    }

    cout<<rez;

    return 0;
}
