#include <fstream>

using namespace std;
const int MOD = 1999999973;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long powlg(long long a, long long p)
{
    long long val = 1, x = a % MOD;
    while(p > 0)
    {
        if(p % 2 != 0)
            val = val * x % MOD;
        x = x * x % MOD;
        p /= 2;
    }
    return val;
}

int main()
{
    long long N, P;
    fin >> N >> P;
    fout << powlg(N, P);
    fin.close();
    fout.close();
    return 0;
}
