#include <iostream>
#include<fstream>
using namespace std;

int main()
{
ifstream cin("lgput.in");
ofstream cout("lgput.out");
    long long  a, n;
  cin>>a>>n;
  int p = 1;
  while (n > 0) {
    if (n % 2 == 1)
        p = p * a%1999999973;
    a = a * a%1999999973;
    n = n / 2;
  }
 cout<<p;
    return 0;
}
