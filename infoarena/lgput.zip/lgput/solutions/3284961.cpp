#include<bits/stdc++.h>

using namespace std;

int n , a;
long long p;
const long long MOD=1999999973;

int main()
{
    cin >> a >> n;
    p=1;
    while(n)
    {
        if(n % 2 == 1)
        {
            p = p * a;
        }
        a = a * a;
        n /= 2;
    }
    cout<<p%MOD;
}
