#include <fstream>

using namespace std;
ifstream fcin("lgput.in");
ofstream fout("lgput.out");
long long x,y,p,c,n;
int main()
{
    fcin>>x>>y;
    p=1;
    while(y!=0)
    {
        c=y%2;
        if(c==1)
        {
            p=(p*x)%1999999973;
        }
      y=y/2;
      x=(x*x)%1999999973;
    }
    fout<<p%1999999973;
    return 0;
}
