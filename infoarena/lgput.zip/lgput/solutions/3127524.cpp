#include <fstream>

using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
const int mod=1999999973;
long long func(int a, int b) {
    
    if(b==0) return 1;
    long long half = func(a,b/2);
    long long integer = (1LL * half*half)%mod;
    if(b%2 ==0)
        return integer;
    else
       return (1LL * integer*a)%mod;
}

int main(){
    
    int a,b;
    cin >> a>>b;
    cout << func(a,b);
}