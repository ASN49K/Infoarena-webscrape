#include <bits/stdc++.h>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
const long mod=1999999973;

int main()
{
    long a, n;  //a^n
    cin>>a>>n;
    long out=1;
    while(n>0){
        if(n%2==1) out=(out*a)%mod;
        a=(a*a)%mod;
        n/=2;
    }
    cout<<out;
    return 0;
}
