#include <bits/stdc++.h>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

#define cin fin
#define cout fout
#define mod 1999999973

long long power(long long a, long long b) {
    long long s = 1;
    a = a % mod;
    while(b > 0) {
        if (b%2==1) {
            s = (s * a)%mod;
        }
        b /= 2;
        a = (a * a)%mod;
    }
    return s;
}

int main()
{
    long long n, p;
    cin >> n >> p;
    cout << power(n, p);
    return 0;
}
