#include <stdio.h>
#include <math.h>

long long unsigned exp_log_rec(unsigned n, unsigned p){
 if(p < 0) return exp_log_rec(1 / n, -p);
 if(p == 0) return 1;
 if(p % 2 == 0) return exp_log_rec(n*n, p/2);
 if(p % 2 == 1) return n * exp_log_rec(n*n, p/2);

 return 0;
}

int main(){
    unsigned n;
    unsigned p;
    freopen("lgput.in" , "r" , stdin);
    freopen("lgput.out" , "w" , stdout);
    if(scanf("%d %d" , &n , &p) == 2){
        printf("%lld" , exp_log_rec(n,p)%1999999973);
        //printf("%ld" , sizeof(unsigned long));
    }
    return 0;
}