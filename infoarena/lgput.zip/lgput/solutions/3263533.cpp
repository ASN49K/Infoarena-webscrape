#include <iostream>
#include <math.h>
#include <fstream>

std::ifstream in("lgput.in");
std::ofstream out("lgput.out");

long long M = 1999999973;

void fpow(long long N, long long P){
  long long int result = 1;
  long long  int aux = N % M;
  while(P > 0){
    if(P % 2 == 1){
      result = (result % M) * (aux % M) ;
      P--;
      continue;
    }
    P/=2;
    aux = (aux % M) * (aux % M); 
   } 
  out  << result % M << std::endl;
}

int main(){
  if(!in.is_open()) throw std::runtime_error("File is not opened");
  if(!out.is_open()) throw std::runtime_error("File is not opened");

  long long N, P;
  
  in >> N >> P;

  fpow(N, P);

}
