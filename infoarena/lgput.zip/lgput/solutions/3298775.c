#include <stdio.h>

#define MODUL 1999999973

int main()
{
    int baza, exponent;
    FILE *fisier_in = fopen("lgput.in", "r");
    FILE *fisier_out = fopen("lgput.out", "w");
    
    if(fisier_in == NULL || fisier_out == NULL)
    {
        return 1;
    }
    
    fscanf(fisier_in, "%d %d", &baza, &exponent);

    long long valoare_curenta = baza;
    long long rezultat = 1;
    while(exponent)
    {
        if(exponent & 1)
        {
            rezultat = (rezultat * valoare_curenta) % MODUL;
        }
        
        valoare_curenta = (valoare_curenta * valoare_curenta) % MODUL;
        exponent >>= 1;
    }

    fprintf(fisier_out, "%lld", rezultat);

    fclose(fisier_in);
    fclose(fisier_out);
    return 0;
}