#include <iostream>
#include <fstream>

using namespace std;

ifstream f("lgput.in");
ofstream g("lgput.out");

const int mod=1999999973;

int main()
{
    long long n, x, rez=1;
    f>> n >> x;
    while(x>0){
        if(x%2==1){
            rez=(rez*n)%mod;
        }
        n=(n*n)%mod; x/=2;
    }
    g<< rez;

    return 0;
}
