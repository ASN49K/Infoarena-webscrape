#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const int DIVISOR = 1999999973;

long long power(int a, int b) {
    if (b == 0) {
        return 1;
    }
    long long num = power(a, b / 2);
    if (b % 2 == 0) {
        return num * num % DIVISOR;
    }
    return ((long long) (num % DIVISOR) * (num % DIVISOR) % DIVISOR) * (a % DIVISOR) % DIVISOR;
}

int main() {
    int n, p;
    fin >> n >> p;
    fout << power(n, p);
    return 0;
}
