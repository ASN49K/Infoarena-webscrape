//#include <iostream>
#include <fstream>
using namespace std;

ifstream cin("lgput.in"); ofstream cout("lgput.out");

#define mod 1999999973;

int alab(int a, int b) {
	int p = 1;
	for(int k = 1; k <= b; k <<= 1) {
		if((b & k)) {
			p = (p * a) % mod;
		}
		a = (a * a) % mod;
	}
	return p;
}

int main() {
    int a, b;
    cin >> a >> b;
    cout << alab(a, b) % mod;
}