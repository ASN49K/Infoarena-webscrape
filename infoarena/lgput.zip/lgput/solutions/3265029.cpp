#include <bits/stdc++.h>
#define cnst const int
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

int b, e;
cnst m = 1999999973;

int main()
{
    fin >> b >> e;
    long long ans = 1;
    while(e > 0)
    {
        if(e % 2 == 1)
            ans=ans*b%m;
        b = b*b%m;
        e/=2;
    }
    fout << ans%m;
    return 0;
}