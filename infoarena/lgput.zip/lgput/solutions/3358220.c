#include <stdio.h>

#define MOD 1999999973LL

long long power(long long base, long long exp, long long mod) {
    long long result = 1;
    base %= mod;
    while (exp > 0) {
        if (exp % 2 == 1)
            result = result * base % mod;
        base = base * base % mod;
        exp /= 2;
    }
    return result;
}

int main() {
    FILE *fin  = fopen("lgput.in",  "r");
    FILE *fout = fopen("lgput.out", "w");

    long long n, p;
    fscanf(fin, "%lld %lld", &n, &p);
    fprintf(fout, "%lld\n", power(n, p, MOD));

    fclose(fin);
    fclose(fout);
    return 0;
}