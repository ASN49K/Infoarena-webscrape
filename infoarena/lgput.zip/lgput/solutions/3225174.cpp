#include <iostream>
#include <fstream>

#define mod 1999999973
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");



long long recursiv(long long baza,int exp)
{
    int p=1;
    while(exp)
    {
        if(exp%2==1)
            p=(p*baza)%mod;
        baza = (baza*baza)%mod;
        exp=exp/2;
    }
    return p;
}


int main()
{
    long long P=1;
    long long baza,exp;
    fin>>baza>>exp;
    fout<<recursiv(baza,exp);

    return 0;
}
