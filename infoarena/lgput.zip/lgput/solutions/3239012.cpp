#include <iostream>
#include <fstream>


unsigned long long hatvany(unsigned int a, unsigned int b){
	/*if(b == 0)
		return 1;*/
	if(b == 1)
		return a;
	/*if(b == 2)
		return a*a;*/
	if(b % 2 == 0)
		return hatvany(a, b/2) * hatvany(a, b/2) % 1999999973;
	else
		return hatvany(a, b/2 + 1) * hatvany(a, b/2) % 1999999973;
}

int main(){
	unsigned int n, p;
	std::ifstream bem("lgput.in");

	bem >> n >> p;
	bem.close();

	std::ofstream kim("lgput.out");
	kim << hatvany(n, p) << "\n";
	kim.close();
	return 0;
}
