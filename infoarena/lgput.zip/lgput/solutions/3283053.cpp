#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

constexpr long long MOD = 1999999973;

long long lgput(long long a, long long b) {
    long long ans = 1;
    while (b > 0) {
        if (b % 2 == 1) ans = ans * a % MOD;
        a = a * a % MOD;
        b /= 2;
    }

    return ans;
}

int main() {
    long long a, b;
    fin >> a >> b;

    fout << lgput(a, b);
}