#include <fstream>

using namespace std;

#define MOD 1999999973

int putere(int a, int n){
    int p = 1;
    while (a > 0){
        if (a % 2 == 1)
            p *= n % MOD;
        n *= n % MOD;
        a /= 2;
    }
    return p % MOD;
}

int main()
{
    ifstream cin ("lgput.in");
    ofstream cout ("lgput.out");

    int n, put;

    cin >> n >> put;

    cout << putere(put, n) << '\n';

    return 0;
}
