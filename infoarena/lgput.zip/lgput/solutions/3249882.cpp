/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <fstream>
using namespace std;
int main()
{
    int n, p, rez = 1;
    ifstream f("lgput.in");
    ofstream g("lgput.out");
    f>>n>>p;
    while(p>0)
    {
        if(p%2!=0)
        {
            p--;
            rez *=n;
        }
        p /=2;
        n *= n;
    }
    g<<rez;

    return 0;
}