#include <iostream>
#include <fstream>
using namespace std;

#ifdef LOCAL
#define fin cin
#define fout cout
#else
ifstream fin("lgput.in");
ofstream fout("lgput.out");
#endif

const int MOD = 1999999973;

long long int exp(int b, long long int p) {
	if (p == 0) return 1;
	int squared = exp(b, p / 2);
	if (p % 2 == 0) return squared * squared % MOD;
	else return 1LL * b * squared * squared % MOD;
}

int main() {
	long long int n, p;
	fin >> n >> p;
	fout << exp(n % MOD, p);
}
