#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
ifstream in("lgput.in");
ofstream out("lgput.out");

int main()
{
    int N,P,x,y,c=1999999973;
    in>>N>>P;
    x=pow(N,P);
    y=x%c;
    out<<y;
    return 0;
}
