#include <bits/stdc++.h>
using namespace std;
ifstream f("lgput.in");
ofstream g("lgput.out");
int MOD=1999999973;
long long fast_exp(long long a,long long b)
{
    if(b==0)
        return 1;
    else
    {
        long long p=fast_exp(a,b/2)%MOD;
        if(b%2!=0)
            return (((p*p)%MOD)*a)%MOD;
        else
            return (p*p)%MOD;
    }
}
int main()
{
    long long a,b;
    f>>a>>b;
    g<<fast_exp(a%MOD,b);
    return 0;
}
