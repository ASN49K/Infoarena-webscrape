#include <fstream>

using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
long long p=1, n, a;
int main()
{
    fin>>n>>a;
    while(n!=0)
    {
        if(n%2==1)
            p=(p*a)%1999999973;
        a=(a*a)%1999999973;
        n=n/2;
    }
    fout<<p;
    return 0;
}
