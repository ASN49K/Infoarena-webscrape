#include <fstream>

using namespace std;
ifstream cin ("lgput.in");
ofstream cout ("lgput.out");
const int mod=1999999973;
int put (int baza, int putere)
{
    int p=1;
    while(putere)
    {
        if(putere%2)
            p=(1LL*p*baza)%mod;
        baza=(1LL*baza*baza)%mod;
        putere/=2;
    }
    return p;
}
int main()
{
    int a,b;
    cin>>a>>b;
    cout<<put(a,b);
    return 0;
}
