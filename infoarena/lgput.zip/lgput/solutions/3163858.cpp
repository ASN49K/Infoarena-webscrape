#include<bits/stdc++.h>

#define MOD  1999999973

using namespace std;

ifstream fin("lgput.in");

ofstream fout("lgput.out");

int p,n;

long long putere(int x,int a)
{
    if(a==0)
    return 1;
    else {
        int d=putere(x,a/2);
        if(a%2==0)
        return (1LL*d*d)%MOD;
        else return ((1LL*d*d)%MOD*x)%MOD;
    }
}

int main()
{fin>>p>>n;
fout<<putere(p,n);
}