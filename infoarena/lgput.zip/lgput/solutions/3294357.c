#include <stdio.h>

long long putere(long long A, long long n)
{
	long long P = 1;
	n %= 1999999973;
	while(n)
	{
		if(n%2 == 1)
			P = (P*A)%1999999973;
		A = (A*A)%1999999973;
		n = (n/2)%1999999973;
	}
	return P;
}

int main()
{
	freopen("lgput.in", "r", stdin);
	freopen("lgput.out", "w", stdout);
	
	long long n, p;
	scanf("%lld%lld", &n, &p);
	long long put = putere(n, p);
	printf("%lld", put);
}