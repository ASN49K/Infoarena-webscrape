#include <fstream>
#include <iostream>
#define mod 1999999973
using namespace std;
long long int put=1;
void alg(long long n,long long p)
{
  while(p>0)
  {
    if(p%2==1)
      put=(put*n)%mod;
    n=(n*n)%mod;
    p/=2;
  }
  cout<<put%mod;
}
int main()
{
  ifstream cin("lgput.in");
  ofstream cout("lgput.out");
long long int n,p;
cin>>n>>p;
alg(n,p);
    return 0;
}
