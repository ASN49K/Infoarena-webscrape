#include<bits/stdc++.h>
using namespace std;
const int modul= 1999999973;
int putere(int N,int P)
{
    int rest=1;
    while(P)
    {
        if(P%2!=0)
            rest=(1LL*rest*N)%modul;
        N=(1LL*N*N)%modul;
        P=P/2;
    }
    return rest;
}
int main()
{
    ifstream f("lgput.in");
    ofstream g("lgput.out");
    int N,P;
    f>>N>>P;
    g<<putere(N,P);

}
