#include <fstream>

using namespace std;

#define MOD 1999999973

int putere(int n, int a){
    int p = 1;
    while (n > 0){
        if (n % 2 == 1)
            p *= a % MOD;
        a *= a % MOD;
        n /= 2;
    }
    return p % MOD;
}

int main()
{
    ifstream cin ("lgput.in");
    ofstream cout ("lgput.out");

    int n, put;

    cin >> n >> put;

    cout << putere(n, put) << '\n';

    return 0;
}
