#include <fstream>
#include <string>

using namespace std;

ifstream cin ("rezerv.in");
ofstream cout ("rezerv.out");

int a[300][300];

int main()
{
    int n, m, k;
    cin >> n >> m;
    string s;
    cin >> s;

    int x = 1, y = 1;
    for (int i = 0; i < s.length(); ++i){
        if (s[i] == 'S'){
            a[x][y - 1] = 1;
            ++x;
        }
        else if (s[i] == 'E'){
            ++y;
        }
        else if (s[i] == 'N'){
            a[x - 1][y - 1] = 1;
            --x;
        }
        else
            --y;
    }

    for (int i = 1; i <= n; ++i){
        for (int j = 1; j <= m; ++j){
            a[i][j] += a[i][j - 1];
        }
    }

    cin >> k;
    int nk = 1;
    int v[k + 1];
    for (int i = 1; i <= k; ++i){
        cin >> x >> y;
        if (a[x][y - 1] % 2 == 1){
            v[nk++] = i;
        }
    }

    --nk;
    cout << nk << '\n';
    for (int i = 1; i <= nk; ++i){
        cout << v[i] << ' ';
    }

    return 0;
}
