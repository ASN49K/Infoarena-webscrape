#include <bits/stdc++.h>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

int n, e;
const int MOD = 1999999973;

int Quick(int n, int e)
{
    int p = 1;
    while (e > 0)
    {
        if (e % 2 == 1)
            p = 1ll * p * n % MOD;
        n = 1ll * n * n % MOD;
        e /= 2;
    }
    return p;
}

int main()
{
    int a, b;
    fin >> a >> b;
    fout << Quick(a, b);

    return 0;
}
