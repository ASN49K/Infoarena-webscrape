#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const long long mod = 1999999973;

int putere(long long a, long long n) {
    if (n == 0)
        return 1;
    long long rez = putere(a, n / 2);
    if (n % 2 == 0)
        return rez * rez % mod;
    else
        return rez * rez % mod * a % mod;
}

int main()
{
    long long a, n;
    fin >> a >> n;
    fout << putere(a, n);
    return 0;
}
