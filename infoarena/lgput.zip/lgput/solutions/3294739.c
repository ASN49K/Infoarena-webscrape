#include <stdio.h>

#define MOD 1999999973

int ridicareLaPutere(int n, int p) {
    if(p == 0) {
        return 1;
    }
    int x = ridicareLaPutere(n, p / 2);
    if(p % 2 == 0) {
        return (x * x) % MOD;
    } else {
        return n * x * x % MOD;
    }
}

int main() {
    int n, p;
    scanf("%d %d", &n, &p);
    printf("%d\n",ridicareLaPutere(n, p));
    return 0;
}