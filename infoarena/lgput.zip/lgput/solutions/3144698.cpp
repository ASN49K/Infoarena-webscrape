#include <iostream>
using namespace std;
long long logpower (long long n, long long exponent){
    if (exponent == 0){
        return 1;
    }
    if (exponent % 2 == 0)
        return (logpower(n, exponent/2) * logpower(n, exponent/2)) % 1999999973;
    else
        return (n * logpower(n, exponent - 1)) % 1999999973;
}
int main(){
    int n, exponent;
    cin >> n >> exponent;
    cout << logpower(n, exponent);
}