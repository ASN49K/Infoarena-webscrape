#include <bits/stdc++.h>
using namespace  std;
#define MOD 1999999973
#define int long long 

int lgput(int a, int b){
    int put = 1;
    while(b != 0){
        if(b % 2 == 1){
            put = put * a;
            put %= MOD;
        }
        a = a * a;
        b/=2;
        a %= MOD;
    }
    return put;
}

int32_t main(void){
    ofstream cout("lgput.out");
    ifstream cin ("lgput.in");

    int n,m;
    cin >>  n >>  m;
    cout << lgput(n,m);
}