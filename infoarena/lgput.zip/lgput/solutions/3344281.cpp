#include <fstream>

using namespace std;
ifstream cin ("lgput.in");
ofstream cout ("lgput.out");
int n,m,x,a,b,tip;

long long int exp(long long int baza, long long int putere)
{
    long long int rez=1;
    while (putere)
    {
        if (putere%2==1)
            rez=rez*baza;
        putere/=2;
        baza=baza*baza;
    }
    return rez;
}

int main()
{
    cin>>n>>m;
    cout<<exp(n,m);
    return 0;
}
