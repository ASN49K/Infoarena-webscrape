#include <fstream>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

long long n, p, x, y, c;
const long long mod=1999999973;

int putere(int n, int p)
{
    int sol=1;
    for(int i=0; (1<<i)<=p;i++)
    {
        if(((1<<i) & p)>0)
           sol=(sol*n)%mod;
        n=(n*n)%mod;
    }
    return sol;
}

int main()
{
    cin>>n>>p;
    long long sol=1;
    for(int i=0; (1<<i)<=p;i++)
    {
        if(((1<<i) & p)>0)
           sol=(sol*n)%mod;
        n=(n*n)%mod;
    }
    cout<<sol;
}

