#include <stdio.h>

unsigned test(unsigned N, unsigned P) {
    if (P == 0)
        return 1;

    if (P % 2)
        return N * test(N * N, (P - 1) / 2);
    else
        return test(N * N, P / 2);
}

int main() {
    FILE *input = fopen("lgput.in", "r");
    FILE *output = fopen("lgput.out", "w");

    unsigned N, P;
    fscanf(input, "%d %d", &N, &P);

    fprintf(output, "%d", test(N, P));
 }
