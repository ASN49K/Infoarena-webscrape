#include <fstream>
#define mod 1999999973
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
long long n,p;
long long power(long long a,long long b)
{
    if(b==0)
        return 1;
    else
    {
        long long x=power(a,b/2);
        if(b%2==0)
            return x*x%mod;
        else
            return x*x%mod*a%mod;
    }
}
int main()
{
    cin>>n>>p;
    cout<<power(n,p);
    return 0;
}
