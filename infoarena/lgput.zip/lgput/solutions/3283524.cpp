#include <bits/stdc++.h>

using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
int p;
int Mod=1999999973;
long long n;
inline long long putere(long long a,int e)
{
    long long rez=1;
    while (e)
    {
        if (e&1)
        {
            rez=rez*a;
            rez%=Mod;
        }
        a=a*a;
        a%=Mod;
        e=(e>>1);
    }
    return rez;
}
int main()
{
    fin>>n>>p;
    fout<<putere(n,p);
    return 0;
}
