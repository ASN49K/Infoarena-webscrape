#include <iostream>
#include <fstream>
using namespace std;
ifstream fcin("lgput.in");
ofstream fcout("lgput.out");
long long n, p, a;
int c;
int main()
{
    fcin>>n>>a;
    p=1;
    while(n>0)
    {
        c=n%2;
        if(c==1)p=p*a;
        n=n/2;
        a=a*a;
    }
    fcout<<p%1999999973;
    return 0;
}

