#include <fstream>
#include <cmath>
#include <string>
using namespace std;
const int m=100003;
ifstream cin ("spion.in");
ofstream cout ("spion.out");
int main()
{
    int p;
    cin>>p;
    cin.get();
    string s;
    cin>>s;
    int nrv=1;
    for(int i=0;i<s.size();i++)
        if(s[i]=='V')
            nrv++;
    if(p==1)
        cout<<nrv;
    else
    {
        long long x=1,y=1;
        nrv--;
        for(int i=1;i<nrv;i++){
            x=pow(i*x,(m-2))%m;
            y=pow((s.size()-nrv+i-1)*y,(m-2))%m;
        }
        cout<<(y/x)%m;

    }
    return 0;
}
