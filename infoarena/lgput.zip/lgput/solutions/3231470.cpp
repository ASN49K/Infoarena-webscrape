#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

unsigned int modExp(unsigned int n, unsigned int p, unsigned int q)
{
    unsigned int b = n % q;
    unsigned long long r = 1;

    if (p != 0)
    {
        while (p > 0)
        {
            if (p % 2)
            {
                r = (r * b) % q;
            }
            b = (b * b) % q;
            p /= 2;
        }
    }

    return r;
}

int main()
{
    unsigned int x, n, q = 1999999973;
    fin >> x >> n;

    fout << modExp(x, n, q);

    fin.close();
    fout.close();
    return 0;
}