#include <bits/stdc++.h>

using namespace std;

ifstream in("lgput.in");
ofstream out("lgput.out");

typedef unsigned long long ull;
typedef long long ll;
typedef pair<int, int> pii;
#define fi first
#define se second

#define NMAX 100005
#define MOD 1999999973
#define INF 0x3f3f3f3f

ull n, p;

void read()
{
    in >> n >> p;
}

ull fastexp(int n, int p)
{
    if (p == 0)
        return 1;
    if (p % 2 == 1)
        return (n * fastexp(n, p - 1)) % MOD;
    int r = fastexp(n, p/2)%MOD; return r*r%MOD;
}

void solve()
{
    out << fastexp(n, p);
}

int main()
{
    read();
    solve();
    return 0;
}