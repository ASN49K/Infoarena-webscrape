﻿#include <fstream>
#include <stack>
#include <queue>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <set>
#include <cstring>
#include <map>
#include <string>
#include <bitset>
#include <unordered_map>
#include <unordered_set>
#define oo 2000000
#define MOD 1999999973
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");
int logput(int a, int b)
{
	int p = 1;
	if (b == 0)return 1;
	while (b)
	{
		if (b % 2 == 1)
		{
			p = 1LL * p * a % MOD;
		}
		b /= 2;
		a = 1LL * a * a % MOD;
	}
	return p;
}
int main()
{
	int x, y;
	fin >> x >> y;
	fout << logput(x, y);
}
