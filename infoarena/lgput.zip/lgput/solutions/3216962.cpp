#include <fstream>

#define mod 1999999973

using namespace std;

ifstream in;
ofstream out;

int putere(int x, int p)
{
    if (p == 1)
        return x;
    if (p == 0)
        return 1;
    int r = 1;
    r *= putere(x, p/2);
    r = 1ll * r * r % mod;
    if (p%2)
        r = 1ll * r * x % mod;
    return r;
}

int main()
{
    in.open("lgput.in");
    out.open("lgput.out");
    int n, p;
    in >> n >> p;
    out << putere(n, p);
}