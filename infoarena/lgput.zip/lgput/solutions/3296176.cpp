//https://infoarena.ro/problema/lgput

#include <iostream>
#include <fstream>

using namespace std;

#define MOD 1999999973

ifstream fin("lgput.in");
ofstream fout("lgput.out");

unsigned exponentiate(unsigned n, unsigned p){ //computes and returns n to the power of p (modulo 1999999973)
    if (p == 0)
        return 1;

    if (p % 2) // p is odd
        return n * exponentiate((n * n) % MOD, (p - 1) / 2) % MOD;
    else // p is even
        return exponentiate((n * n) % MOD, p / 2) % MOD;
} 

int main(){
    unsigned n, p;
    fin>>n>>p;

    fout<<exponentiate(n, p);

    fin.close();
    fout.close();
}