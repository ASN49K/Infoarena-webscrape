#include <bits/stdc++.h>
#define MOD 1999999973
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
long long b,e,p;
int main()
{
    fin>>b>>e;
    p=1;
    while(e){
        if(e%2)
            p = (p*b)%MOD;
        b = (b*b)%MOD;
        e /= 2;
    }
    fout<<p;
    return 0;
}
