#include <bits/stdc++.h>
#define MOD 1999999973

using namespace std;

long long mod_pow(int x, int y)
{
    if(y==0)
        return 1;
    else
        return mod_pow(x*x%MOD,y/2)*(y%2? x:1);
}

int main()
{
    ifstream fin ("lgput.in");
    ofstream fout ("lgput.out");
    int n,p;
    fin>>n>>p;
    fout<<mod_pow(n,p);
    return 0;
}
