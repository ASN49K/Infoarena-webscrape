#include <fstream>
using namespace std;
long long a, b;
ifstream fin ("lgput.in");
ofstream fout("lgput.out");

long long calcul(long long a, long long b) {
    if (b == 0)
        return 1;
    else {
        long long x = calcul(a, b/2);
        if (b%2 == 0)
            return x*x;
        else
            return x*x%c*a;
    }
}

int main (void) {
    fin>>a>>b;
    fout<<calcul(a, b)%1999999973;
}