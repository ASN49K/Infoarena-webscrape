#include <stdio.h>
#include <stdlib.h>

long long putere(x, n)
{
	if(n < 0)
		return putere(1/x, -n);
	else
		if(n == 0)
			return 1;
		else
			if(n % 2 == 0)
				return putere(x*x, n/2);
			else
				return putere(x*x, (n-1)/2);
}

int main(void)
{
	FILE *f, *out;

	if((f = fopen("lgput.in","r")) == NULL)
	{
		perror(NULL);
		exit(-1);
	}

	if((out = fopen("lgput.out","w")) == NULL)
	{
		perror(NULL);
		exit(-1);
	}

	int n, p;
	fscanf(f,"%d %d",&n, &p);
	long long prod = putere(n, p);
	fprintf(out, "%lld", prod);

	if(fclose(f) != 0)
	{
		perror(NULL);
		exit(-1);
	}

	if(fclose(out) != 0)
	{
		perror(NULL);
		exit(-1);
	}
	return 0;
}