#include <bits/stdc++.h>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
int ExpoLog(int a, int n, int mod)
{
    int p = 1;
    while(n > 0)
    {
        if(n % 2 == 1) p = p * a % mod;
        n /= 2;
        a = a * a % mod;
    }
    return p;
}
int main()
{
    ios_base::sync_with_stdio(0);
    fin.tie(0);
    fout.tie(0);
    int n,p;
    fin >> n >> p;
    fout << ExpoLog(n,p, 1999999973);
    return 0;
}
