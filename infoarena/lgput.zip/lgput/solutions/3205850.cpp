#include<bits/stdc++.h>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
unsigned int N, P, i;
long long a, sol=1;
int main()
{
    fin>>N>>P;
    a=N;
    for(i=0;(1<<i)<=P;i++)
    {
        if(((1<<i)&P)>0)
        {
            sol=(sol*a)%1999999973;
        }
        a=(a*a)%1999999973;
    }
    fout<<1LL*sol;
}