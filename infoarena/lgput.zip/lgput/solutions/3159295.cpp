#include <fstream>
#include <iostream>
#include <queue>

using namespace std;
const int mod=1999999973;

int main(){
    ifstream fin("lgput.in");
    ofstream fout("lgput.out");
    long long n, p;
    int ans;
    fin>>n>>p;
    ans=1;
    while(p){
        if(p&1)
            ans=(ans*n)%mod;
        n=(n*n)%mod;
        p>>=1;
    }
    fout<<ans;
    return 0;
}
