#include <bits/stdc++.h>

using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
long long n,p;
int putere(long long a,long long b,long long mod){
    long long rezultat=1;
    a=a%mod;
    while (b>0){
        if (b%2==1)
            rezultat=(rezultat*a)%mod;
        a=(a*a)%mod;
        b/=2;
    }
    return rezultat;
}
int main()
{
    fin >> n >> p;
    fout << putere(n,p,1999999973);
    return 0;
}
