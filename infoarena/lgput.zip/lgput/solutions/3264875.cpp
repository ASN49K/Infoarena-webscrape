#include<fstream>

using namespace std;


ifstream cin("Igput.in");
ofstream cout("Igput.out");

#define MOD 1999999973


int fastEXP(int& a, int& b)
{
  if(b==1)
    return a%MOD;
  else if(b%2==1)
    return ((long long)a%MOD * fastEXP(a, b-1)%MOD)%MOD;
  else
  {
    int p=fastEXP(a, b/2);
    return ((long long)p%MOD*p%MOD)%MOD;
  }
}


int main()
{
  int a, b;

  cin>>a>>b;
  
  cout<<fastEXP(a, b)%MOD;

  return 0;
}
