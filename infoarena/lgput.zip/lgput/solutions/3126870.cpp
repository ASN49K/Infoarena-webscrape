#import<fstream>
main(){long n,a,p=1,m=2e9-27;for(std::ifstream("lgput.in")>>a>>n;n;a=a*a%m,n/=2)if(n&1)p=p*a%m;std::ofstream("lgput.out")<<p;}
