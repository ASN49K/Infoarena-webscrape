#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
#define MOD 1999999973
ll exp_by_squaring(ll n, ll p){
    if(p == 0) return 1;
    else if(p < 0) return exp_by_squaring(1/n, -p);
    else if(p % 2 == 0) return exp_by_squaring(n*n, p/2);
    else return n*exp_by_squaring(n*n, (p-1)/2);
}

int main(){
    ll n,p;
    fin >> n >> p;
    fout << exp_by_squaring(n, p) % MOD ;
    return 0;
}