/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");

int main()
{
    long long n,p;
    fin>>n>>p;
    const long long mod = 1999999973;
    long long int s = 1;
    for(long long int i = 0; i<p;i++){
        s = (s * n) % mod;
    }
    fout<<s;

    return 0;
}
