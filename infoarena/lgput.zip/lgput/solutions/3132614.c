#include <stdio.h>
#define Mod 1999999973
int Putere(unsigned int n, unsigned int p)
{
    unsigned long long res = 1;
    long long int a=1;
    while (p > 0)
    {
        if (p % 2 == 1)
        {
            res = (a * res * n) % Mod;
        }
        n = (a * n * n) % Mod;
        p = p / 2;
    }
    return res;
}
int main()
{
    unsigned int n, p;
    long long int res = 0;
    freopen("lgput.in", "r", stdin);
    freopen("lgput.out", "w", stdout);
    scanf("%d %d", &n, &p);
    res = Putere(n, p);
    printf("%lld", res);
    return 0;
}