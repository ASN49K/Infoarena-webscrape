#include <bits/stdc++.h>

using namespace std;
const int MOD=1999999973;

#define cin fin
#define cout fout

ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long powlg(int a, int p)
{
    long long val=1, x=a%MOD;
    while(p>0)
    {
        if(p%2!=0)
            val=val*x%MOD;
        x=x*x%MOD;
        p/=2;
    }
    return val;
}

int main()
{
    int n,p;
    cin>>n>>p;
    cout<<powlg(n,p);
    return 0;
}
