#include <bits/stdc++.h>
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long int n, po;
int lgput(long long int a, long long int p){
    if(p==1) return a%1999999973;
    if(a%2==0) return lgput((a%1999999973)*(a%1999999973)%1999999973, p/2)%1999999973;
    else return (a%1999999973)*(lgput((a%1999999973)*(a%1999999973)%1999999973, p/2)%1999999973)%1999999973;
}
int main(){
    fin>>n>>po;
    fout<<lgput(n%1999999973, po);
    return 0;
}
