#include <bits/stdc++.h>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
int N, P;
int f(int x, int n)
{
    if(n==0) return 1;
    if(n%2==0) return f(x*x, n/2)%1999999973;
    else return x*f(x*x, (n-1)/2)%1999999973;
}
int main()
{
    fin>>N>>P;
    fout<<f(N, P);
    return 0;   
}
