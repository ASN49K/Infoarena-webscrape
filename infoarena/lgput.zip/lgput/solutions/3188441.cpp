#include <bits/stdc++.h>
#define MOD 1999999973
#define int long long
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

int n, p;

int power(int base, int exp){
    int b=1;
    while(exp){
        if(exp%2){
            b*=base;
            b%=MOD;
        }
        base*=base;
        base%=MOD;
        exp/=2;
    }
    return b%MOD;
}

int32_t main(){
    fin>>n>>p;
    fout<<power(n, p);
}
