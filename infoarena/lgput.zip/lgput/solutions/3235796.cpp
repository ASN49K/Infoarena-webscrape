#include <iostream>

using namespace std;

long long n, p;
int lgpow (long long b, long long exp)
{
    if (exp == 0)
        return 1;

    if (exp % 2 == 0)
        return lgpow((b * b) % 1999999973, exp / 2);

    else
        return ((b % 1999999973) * (lgpow (b, exp - 1) % 1999999973));
}

int main()
{
    cin >> n >> p;
    cout << lgpow(n, p);

    return 0;
}
