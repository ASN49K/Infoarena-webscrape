#include <iostream>
#include<fstream>
using namespace std;

ifstream f("lgput.in");
ofstream fout("lgput.out");

unsigned rp(unsigned n, unsigned p)
{
    unsigned r = 1;
    while (p) {
        if (p % 2 == 1) {
            r = (1LL * r * n) % 1999999973;
        }
        n = (1LL * n * n) % 1999999973;
        p /= 2;
    }

    return r;
}
int main()
{
    unsigned n, p;
    f >> n >> p;
    fout << rp(n, p);
    return 0;
}
