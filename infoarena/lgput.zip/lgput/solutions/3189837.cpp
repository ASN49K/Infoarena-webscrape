#include <iostream>
#include <fstream>

using namespace std;

const int MOD = 1999999973;

int logPow(int n, int p)
{
    if (p == 0)
    {
        return 1;
    }

    int x = logPow(n, p/2);
    int x_p = (1LL * x * x) % MOD;
    if (p % 2 == 0)
    {
        return x_p;
    }
    else
    {
        return (1LL * x_p * n) % MOD;
    }
}

int main()
{
    int n,p;

    ifstream fin("lgput.in");
    ofstream fout("lgput.out");

    fin>>n>>p;
    fout << logPow(n,p);

    fin.close();
    fout.close();
    return 0;
}
