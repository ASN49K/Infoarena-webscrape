#include <fstream>

using namespace std;

ifstream in("lgput.in");
ofstream out("lgput.out");

const int mod = 1999999973;

long long hatvany(long long a, long long b)
{
    /*
    if (b == 0)
    {
        out << b;
    }
    else if (b < 0)
    {
        b = -b;
        a = -a;
    }
    */

    if (b == 0)
        return 1;
    if (b == 1)
        return a;

    long long resz = hatvany(a, b / 2);

    if (b % 2 == 0)
    {
        return resz * resz;
    }
    else
    {
        return resz * resz * a;
    }
}

int main()
{
    long long n, p;
    in >> n >> p;

    out << hatvany(n, p) % mod;

    return 0;
}