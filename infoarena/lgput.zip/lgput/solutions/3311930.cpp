#include <bits/stdc++.h>

using namespace std;

const int MOD = 1999999973;

long long exp(int n, long long base)
{
    long long ans = 1;
    while(n)
    {
        if(n % 2 == 1)
        {
            ans *= base;
            ans %= MOD;
        }
        base *= base;
        base %= MOD;
        n /= 2;
    }
    return ans;
}

int main()
{
    ios_base :: sync_with_stdio(0);
    cin.tie(0);

    freopen("lgput.in", "r", stdin);
    freopen("lgput.out", "w", stdout);

    int n, p;
    cin >> n >> p;
    cout << exp(n, p);
    return 0;
}
