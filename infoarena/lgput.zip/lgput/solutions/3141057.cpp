#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const long long DIVISOR = 1999999973;

int main() {
    int n, p;
    fin >> n >> p;
    int nCopy = n;
    while (p > 1) {
        --p;
        nCopy *= n;
    }
    fout << nCopy % DIVISOR;
    return 0;
}
