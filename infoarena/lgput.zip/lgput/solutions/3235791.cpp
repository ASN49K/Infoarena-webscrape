#include <fstream>
using namespace std;
ifstream in("lgput.in");
ofstream out("lgput.out");

long long int MOD=1999999973;

int lgpow(int n,int p)
{
    if(p==0)
        return 1;
    if(p%2==0)
        return lgpow(n*n%MOD,p/2)%MOD;

    return n*lgpow(n,p-1)%MOD;
}
int main()
{
    int n,p;
    in>>n>>p;

    out<<lgpow(n,p)%MOD;
}
