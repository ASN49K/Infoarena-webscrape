#include <bits/stdc++.h>

using namespace std;

ifstream fin ("lgput.in");
ofstream fout ("lgput.out");

#define MOD 1999999973

int fastexponential(int n, int p){
    if (p == 0)
        return 1;
    if(p % 2){
        return n * fastexponential(n, p - 1);
    }

    int ans = fastexponential(n, p / 2);
    return ans * ans;
}

int main()
{
    int n, p;
    fin >> n >> p;

    int ans1 = fastexponential(n, p) % MOD;

    fout << ans1 ;
    return 0;
}
