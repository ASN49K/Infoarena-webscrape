#include <stdio.h>

int main() {
    FILE *fin, *fout;
    fin=fopen("lgput.in", "r");
    fout=fopen("lgput.out", "w");
    long long n, p;
    fscanf(fin, "%lld%lld", &n, &p);
    fclose(fin);
    long long put;
    put=1;
    while(p>0) {
        if(p%2==1)
            put=put*n;
        n=n*n;
        p=p/2;
    }
    fprintf(fout, "%lld", put);
    fclose(fout);
    return 0;
}
