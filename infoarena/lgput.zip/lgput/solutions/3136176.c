#include <stdio.h>

#define CONSTANT 1999999973

int LogNPower(int N, int P) {
    if(P == 0) {
        return 1;
    }

    if(P % 2 == 0) {
        return LogNPower(N * N, P / 2);
    } else {
        return N * LogNPower(N * N, (P - 1) / 2);
    }
}

int main() {
    int N, P;

    freopen("lgput.in","r",stdin);
    freopen("lgput.out","w",stdout);

    scanf("%d %d", &N, &P);
    printf("%d %d\n", N, P);

    printf("%d", LogNPower(N, P) % CONSTANT);

    return 0;
}