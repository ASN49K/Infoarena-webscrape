#include <iostream>

#define MOD 1999999973
#define ll long long
using namespace std;

ll power(ll a, ll b, ll mod) {
    if (b == 0)
        return 1;
    if (b % 2 == 1)
        return (a * power(a, b - 1, mod)) % mod;

    ll x = power(a, b / 2, mod);
    return (x * x) % mod;
}

int main() {
    ll a, b;
    cin >> a >> b;
    ll ans = power(a, b, MOD);
    cout << ans << '\n';
}
