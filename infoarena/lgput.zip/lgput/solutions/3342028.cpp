#include <iostream>

#define MOD 1999999973U

unsigned int log_pow_mod(unsigned int base, unsigned int exp)
{
    unsigned int product = 1;

    while (exp) {
        if (exp & 1)
            product = (product * base) % MOD;

        base = (base * base) % MOD;
        exp >>= 1;
    }

    return product;
}

int main()
{
    unsigned int base, exp;

    freopen("lgput.in", "r", stdin);
    freopen("lgput.out", "w", stdout);

    std::cin >> base >> exp;

    std::cout << log_pow_mod(base, exp) << "\n";

    return 0;
}
