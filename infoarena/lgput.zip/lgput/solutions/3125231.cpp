#include <bits/stdc++.h>
#define mod 1999999973

using namespace std;

ifstream f ("lgput.in");
ofstream g ("lgput.out");

long long a, b;

int main()
{
    f >> a >> b;
    long long sol = 1;
    while (b)
    {
        if (b % 2)
            sol = sol * a % mod;
        a = a * a % mod;
        b = b / 2;
    }

    g << sol;

    return 0;
}
