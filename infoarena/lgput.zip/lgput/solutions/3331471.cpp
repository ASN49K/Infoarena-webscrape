#include <fstream>
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
int main()
{
    unsigned long long int n, p, r=1;
    cin>>n>>p;
    while (p>1){
        if (p%2==0)
        {
            n=n*n;
            n=n%1999999973;
            p=p/2;
        }
        else
        {
            r=r*n%1999999973;
            n=n*n;
            n=n%1999999973;
            p=p/2;
        }
    }
    cout<<r*n%1999999973;
}