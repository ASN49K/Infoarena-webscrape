#include<fstream>
using namespace std;
ifstream F("lgput.in");
ofstream G("lgput.out");
long long n,p,m=2e9-27,r=1;
int main()
{
    for(F>>n>>p;p;n=n*n%m,p>>=1)
        if(p&1)
            r=r*n%m;
    return G<<r,0;
}
