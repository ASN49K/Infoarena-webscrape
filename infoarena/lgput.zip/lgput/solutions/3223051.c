#include <stdio.h>
#include <stdlib.h>
long long power(int base, int exponent, long long mod) {
    long long result = 1;
    base %= mod;
    while (exponent > 0) {
        if (exponent & 1)
            result = (result * base) % mod;
        exponent >>= 1;
        base = (base * base) % mod;
    }
    return result;
}
int main()
{
    FILE *f1=NULL,*f2=NULL;
    f1=fopen("lgput.in","r");
    f2=fopen("lgput.out","w");
    int n,p;
    long long mod=1999999973;
    fscanf(f1,"%d %d",&n,&p);
    long long rez = power(n, p, mod);
    fprintf(f2,"%lld",rez);
    fclose(f1);
    fclose(f2);

    return 0;
}
