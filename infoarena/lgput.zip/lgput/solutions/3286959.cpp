#include <fstream>
#include <climits>
#include <algorithm>
#include <vector>
#include <queue>

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

long long n, p;
const int MOD = 1999999973;

long long putere(long long n, long long p)
{
	if (p == 1) return n % MOD;
	
	if (p % 2 == 0) return putere((n * n) % MOD, p / 2) % MOD;
	else return (n * (putere((n * n) % MOD, (p - 1) / 2)) % MOD) % MOD;
}

int main()
{
	cin >> n >> p;
	cout << putere(n, p);
}