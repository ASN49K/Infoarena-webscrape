#include <fstream>
using namespace std;
ifstream  fin("lgput.in");
ofstream fout("lgput.out");
long long N,P;
const long long MOD=1999999973;

int fast_exp(long long b, long long e)
{
    long long ans=1;
    while(e)
    {
        if(e%2==1)
        {
            ans=(ans*b)%MOD;
        }

        b=(b*b)%MOD;
        e=e>>1;
    }

    return ans;
}

int main()
{
    fin>>N>>P;

    fout<< fast_exp(N,P) << "\n";

    return 0;
}