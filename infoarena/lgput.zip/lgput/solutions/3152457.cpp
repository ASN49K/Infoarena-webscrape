#include<fstream>
using namespace std;
#define ll long long

ifstream cin("lgput.in");
ofstream cout("lgput.out");



ll pow(ll n, ll m,ll mod) {
	if (m == 1) {
		return n;
	}
	else {
		ll pw = pow(n, m / 2, mod);
		if (m % 2 == 0) {
			return ((pw%mod) * (pw % mod))% mod;
		}
		else {
			return ((n % mod) * (pw%mod) * (pw % mod) % mod)% mod;
		}
	}
}

int main() {

	ll i,a,m,res;

	cin >> a >> m;


	cout << pow(a, m, 1999999973);

	return 0;
}
