#include <iostream>
#include <fstream>
#define int long long
using namespace std;
const int mod=1999999973;
int32_t main()
{
    ifstream cin("lgput.in");
    ofstream cout("lgput.out");
    int a,b,rez=1;
    cin>>a>>b;
    while(b>0)
    {
        if(b%2==1)
            rez=rez*a%mod;
        a=a*a%mod;
        b/=2;
    }
    cout<<rez;

    return 0;
}
