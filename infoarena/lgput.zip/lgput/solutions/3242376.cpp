#include<bits/stdc++.h>

using namespace std;

const int m = 1999999973;

typedef long long ll;

ll solve(ll a, ll b)
{
  ll result = 1;
  while(b)
    {
      if(b%2==1)
        result*=a % m ;
      a*=a % m;
      b/=2;
    }
  return result;
}

int main()
  {
    ios::sync_with_stdio(0);
    cin.tie(0);
    freopen("lgput.in", "r", stdin);
    freopen("lgput.out", "w", stdout);
    ll a, b; cin>>a>>b;
    cout<<solve(a, b);
  }
