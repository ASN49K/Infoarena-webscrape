#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long n,p;
long long calcul(long long n, long long p)
{
    if(p==0)
    {
        return 1;
    }
    else
    {
        long long x=calcul(n,p/2);
        if(p%2==0)
        {
            return x*x%1999999973; 
        }
        else
        {
            return x*x%1999999973*n%1999999973;
        }
    }
}
int main()
{
    fin>>n>>p;
    fout<<calcul(n,p);
    return 0;
}