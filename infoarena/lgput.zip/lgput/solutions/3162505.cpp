#include <fstream>

using namespace std;
#define M 1999999973
ifstream cin("lgput.in");
ofstream cout("lgput.out");

int mod(int a, int b)
{
	int p=1;
	while(b)
	{
		if(b%2==1)
			p=(1LL*(p*a))%M;
		a=(1LL*a*a)%M;
		b/=2;
	}
	return p;
}

int main()
{
    int n,p;
    cin>>n>>p;
    cout<<mod(n,p);
    return 0;
}
