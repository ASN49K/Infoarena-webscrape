#include <fstream> 
#include <vector>
#include <algorithm>
using namespace std; 

ifstream fin("lgput.in"); 
ofstream fout("lgput.out");

const int MOD = 1999999973; 

int N, P;
vector <int> bin; 

vector <int> binary(int num) {
	vector <int> v; 
	int r; 
	while (num) {
		r = num % 2;
		num /= 2;
		v.push_back(r);
	}; 

	reverse(v.begin(), v.end()); 
	return v; 
}

int ridicare_la_putere(int n, int p, vector <int> v) {
	int x = 1, aux; 
	for (int i = 0; i < v.size(); i++) {
		aux = x; 
		if (v[i] == 1)
			x = (1LL * x * n) % MOD; 
		x = (1LL * aux * x) % MOD; 
	}

	return x; 
}

int main() {
	fin >> N >> P; 
	bin = binary(P); 
	int R = ridicare_la_putere(N, P, bin); 
	fout << R << '\n';

	fin.close();
	fout.close(); 

	return 0;
}