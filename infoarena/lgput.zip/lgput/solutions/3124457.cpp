#include <fstream>
#define mod 1999999973
using namespace std;

ifstream fin ("lgput.in");
ofstream fout("lgput.out");

long long a,b;
long long putereRec(long long a,long long b)
{
    if(b==0)
        return 1;
    else
        if(b%2==0)
            return putereRec(a,b/2)*putereRec(a,b/2)%mod;
        else
            return putereRec(a,b/2)*putereRec(a,b/2)%mod*a%mod;
}
int main()
{
    fin>>a>>b;
    fout<<putereRec(a,b);
    return 0;
}
