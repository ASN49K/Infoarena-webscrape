#include <bits/stdc++.h>
#define pb push_back
//#define int long long
using namespace std;
const int N=2e5+5;int mod=1999999973;
int binpow(int n, int e)
{
    int ans=1;
    while(e)
    {
        if(e&1) ans=1ll*ans*n%mod;
        n=1ll*n*n%mod;
        e>>=1;
    }
    return ans;
}
signed main()
{
    ifstream cin("lgput.in");ofstream cout("lgput.out");
    int a,b;
    cin>>a>>b;
    cout<<binpow(a,b);
}
