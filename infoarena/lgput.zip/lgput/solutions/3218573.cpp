#include <fstream>

using namespace std;

ifstream cin ("lgput.in");
ofstream cout ("lgput.out");

enum { MOD = 1999999973 };

int p( int b, int e ) {
  if ( !e )
    return 1;
  if ( e % 2 )
    return (long long)(b * p( ((long long)b * b) % MOD, e / 2 )) % MOD;
  return p( ((long long)b * b) % MOD, e / 2 ) % MOD;
}

int main()
{
    int n,put;
    cin >> n >> put;
    cout << p(n, put) << '\n';
    return 0;
}
