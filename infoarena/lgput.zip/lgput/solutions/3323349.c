#include <stdio.h>
#include <stdlib.h>
#define MOD 1999999973
long long power(long long a, int n){
    long long p = 1;
    while(n > 0){
        if(n%2 == 1)
            p = (p *a) % MOD;
        //printf("%lld %d %lld\n!",p,n,a);
        a = (a*a)%MOD;

        p %=MOD;
        n /= 2;
    }
    return p;
}
int main()
{
    FILE*fin;
    FILE*fout;
    fin = fopen("lgput.in","r");
    fout = fopen("lgput.out","w");
    long long n,p;
    fscanf(fin,"%lld%lld",&n,&p);
    long long put = power(n,p) % MOD;
    fprintf(fout,"%lld",put);
    return 0;
}
