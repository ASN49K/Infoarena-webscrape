#include <bits/stdc++.h>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
long long n,p,m=1999999973,x;
long long putere(long long  p)
{ if(p==0)
     return 1;
  if(p%2==1)
     return (n*putere(p-1))%m;
  else
     return (putere(p/2)*putere(p/2))%m;
}
int main()
{ fin>>n>>p;
  fout<<putere(p);

    return 0;
}
