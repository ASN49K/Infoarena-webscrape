#include<fstream>
using namespace std;
ifstream F("lgput.in");
ofstream G("lgput.out");
long long n,m=2e9-27,p,y=1;
int main()
{
    for(F>>n>>p;p;p&1?y*=n%m:0,n*=n%m,p>>=1);
    return G<<y,0;
}
