#include <iostream>
#include <fstream>

using namespace std;
ifstream f("lgput.in");
ofstream g("lgput.out");
const int MOD = 1999999973;

int powlg(long long N, long long P)
{
    int rez = 1;
    while (P)
    {
        if (P % 2 == 1)
        {
            /// ultimul bit este 1, deci trebuie sa inmultim pe N la rezultat
            rez = rez * N % MOD;
        }
        P /= 2; ///taiem ultimul bit al lui P
        N = N * N % MOD; /// in felul aste ne asiguram ca pentru fiecare bit b, N va fi N^2^b

    }
    return rez;
}

int main()
{
    long long n, p;
    f >> n >> p;
    g << powlg(n, p);
    return 0;
}
