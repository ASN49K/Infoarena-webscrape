/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <bits/stdc++.h>
using namespace std;
const long long mod=1999999973;
ifstream fin ("lgput.in");
ofstream fout ("lgput.out");
long long lgput (long long n, long long p)
{
    long long rez=1;
    n%=mod;
    while(p!=0)
    {
        if (p%2==1)
        {
            rez=(rez*n)%mod;
        }
        n=(n*n)%mod;
        p/=2;
    }
    return rez;
}
int main()
{
    long long int n,p;
    fin >> n >> p;
    fout << lgput (n,p);
    return 0;
}