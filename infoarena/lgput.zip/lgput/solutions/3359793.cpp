#include <fstream>
#define int long long
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
int n, p, a, mod=1999999973;
long long putere(int b, int p)
{
    long long a=1;
    while(p)
    {
        if(p%2==1)
            a=a*b%mod;
        b=b*b%mod;
        p/=2;
    }
    return a;
}
signed main()
{
    fin>>n>>p;
    fout<<putere(n, p);
    return 0;
}
