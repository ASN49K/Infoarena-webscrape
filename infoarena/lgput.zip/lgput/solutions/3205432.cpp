#include <fstream>

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

int n, p;

long long ceva(int n, int p)
{
	if (p == 1) return n;
	if (p % 2 == 0)
		return ceva(n * n, p / 2);
	else
		return n*ceva(n * n, (p - 1) / 2);
}

int main()
{
	cin >> n >> p;
	cout << ceva(n, p);
}