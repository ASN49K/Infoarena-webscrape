#include <iostream>
#include <math.h>
#include <fstream>
#define MAX 1999999973
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long int power(long long n, long long p)
{
    long long int finale;
    if(p==0)
    {
        return 1;
    }
    if(p%2==1)
    {
        return (n*power(n,p-1))%MAX;
    }
    else
        finale= power(n,p/2)%MAX;
    return (finale *finale)*MAX;
}


int main()
{
    long long int n,p,finale;
    fin>>n>>p;
    finale=power(n,p);
    fout << finale;
    return 0;
}
