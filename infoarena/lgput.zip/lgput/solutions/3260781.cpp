#include <bits/stdc++.h>
using namespace std;

const long long MOD = 1999999973;

long long expPow(long long x, long long y) {
    if (y == 0) {
        return 1;
    }
    long long result = expPow(x, y / 2);
    result = (result * result) % MOD;
    if (y % 2) {
        result = (result * x) % MOD;
    }
    return result;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    freopen("lgput.in", "r", stdin);
    freopen("lgput.out", "w", stdout);
    long long x, y;
    cin >> x >> y;
    cout << expPow(x, y);
    return 0;
}
