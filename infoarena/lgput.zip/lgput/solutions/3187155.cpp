#include<bits/stdc++.h>

using namespace std;

int main(){
	int mod = 1999999973;
	int n, p, j = 1;
	ifstream fin("lgput.in");
	ofstream fout("lgput.out");
	fin>>n>>p;
	while(p){ // 4
		if(p%2==1){
			j=(j*n)%mod;
		}
		n=(n*n)%mod; // 16
		p/=2; // 1
	}
	fout<<j;
}
