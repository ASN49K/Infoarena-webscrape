#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
long long n,m;
long long lgput(int base, int pow)
{
    if(pow==1)
    {
        return base;
    }
    if (pow%2==0)
    {
        long long val=lgput(base,pow/2);
        return val*val;

    }
    return lgput(base,pow-1)*base;

}
int main()
{
    long long n,m;
    fin>>n>>m;
    fout<<lgput(n,m);
}
