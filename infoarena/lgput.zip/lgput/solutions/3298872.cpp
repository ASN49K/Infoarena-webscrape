#include <iostream>
#include <fstream>
using namespace std;


long long power(long long a, long long n) {
    long long result = 1;
    while (n > 0) {
        if (n % 2 == 1)
            result *= a;
        a *= a;
        n /= 2;
    }
    return result;
}

int main()
{
      int P,N;
      ifstream f("lgput.in");
      f>>N>>P;
      cout<<N<<" "<<P<<endl;
      ofstream fisier("lgput.out");
      fisier<<power(N,P)%1999999973;

}
