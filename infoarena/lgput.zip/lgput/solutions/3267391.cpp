#include <iostream>
#include <fstream>

using namespace std;

int mod = 1999999973;
int exp(int A, int N) {
    if (N == 1) return A;
    if (N == 0) return 1;

    if (N % 2 == 0) {
        int aux = exp(A, N / 2);
        return (aux * aux) % mod;
    }

    if (N % 2 == 1) {
        int aux = exp(A, N / 2);
        return ((aux * aux) % mod * A) % mod;
    }
}

int main() {
    ifstream cin("lgput.in");
    ofstream cout("lgput.out");

    int a, b;

    cin >> a >> b;

    cout << exp(a, b);

    return 0;
}