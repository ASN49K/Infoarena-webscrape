#include <bits/stdc++.h>
using namespace std;
ifstream f("lgput.in");
ofstream g("lgput.out");
const int MOD = 1999999973;
long long fast_exp(long long a, long long b)
{
    long long ans = 1;
    while (b)
    {
        if (b % 2)
            ans = (ans * a) % MOD;
        a = (a * a) % MOD;
        b /= 2;
    }
    return ans;
}
int main()
{
    long long a, b;
    f >> a >> b;
    g << fast_exp(a, b);
    return 0;
}