#include <iostream>

using namespace std;

long long n, p;

int lgput(int baza, int exp){
    if(exp==0)
        return 1;
    if(exp%2==0)
        return lgput(baza*baza, exp/2);
    else
        return baza*lgput(baza, exp-1);
}

int main()
{
    cin>>n>>p;
    cout<<lgput(n, p)%1999999973;
    return 0;
    
}
