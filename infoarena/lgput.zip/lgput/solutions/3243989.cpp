#include <fstream>
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
const int mod = 1999999973;
long long fp(int num, long long ta)
{
    if(!num) return 1;
    if(num&1) return ta*(fp((num>>=1),ta*ta%mod))%mod;
    else return fp((num>>=1),ta*ta%mod);
}
signed main()
{
    int a,b; cin>>a>>b;
    cout << fp(b,a);
	return 0;
}
