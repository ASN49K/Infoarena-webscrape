#include <bits/stdc++.h>
#define MOD 1999999973
#define int long long
using namespace std;
int lgput( int base , int exp ) {
    int ans;
    ans = 1;
    while( exp ) {
        if( exp & 1 )
            ans = ( ans * base ) % MOD;
        base = ( base * base ) % MOD;
        exp /= 2;
    }
    return ans;
}
signed main() {
    ifstream cin( "lgput.in" );
    ofstream cout( "lgput.out" );
    int n , e;
    cin >> n >> e;
    cout << lgput( n , e );
    return 0;
}
