#include <fstream>
#define MOD 1999999973

typedef unsigned int num;

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

int main()
{
    num a, b, res = 1;
    cin >> a >> b;
    while (b)
    {
        if (b & 1)
            res = (res * a) % MOD;
        a = (a * a) % MOD;
        b >>= 1;
    }
    cout << res;
}