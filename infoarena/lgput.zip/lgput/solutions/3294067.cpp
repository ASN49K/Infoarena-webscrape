// #include<iostream>
#include<fstream>
using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

long long n, p;

long long Putere(long long a, long long N){
    int P = 1;
    while(N){
        if(N%2 == 1)
            P *= a;
        a *= a;
        N /= 2;
    }
    return P;
}

int main(){
    cin >> n >> p;
    cout << Putere(n, p);
}