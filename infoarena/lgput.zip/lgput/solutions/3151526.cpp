#include <bits/stdc++.h>

using namespace std;
ifstream in("lgput.in");
ofstream out("lgput.out");
long long mod = 1999999973;
long long n, p;

long long lgp(long long n, long long p) {
    long long ans = 0;

    while (p) {

        if (p & 1) {
            ans  = (ans + n) % mod;
            p--;
        }

        n = (n * n) % mod;
        p >>= 1;
    }

    return ans;
}
int main()
{
    in >> n >> p;
    out << lgp(n, p);
    return 0;
}
