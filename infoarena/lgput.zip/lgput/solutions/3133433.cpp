#include <fstream>

using namespace std;
const int mod=1999999973;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

int pow(int a, int n)
{
    int p=1;
    while (n)
    {
        if (n%2==1) p=(p*a)%mod;
        a=(a*a)%mod;
        n=(n/2)%mod;
    }
    return p;
}

int main()
{
    int x,y;
    cin>>x>>y;
    cout<<pow(x,y);
}
