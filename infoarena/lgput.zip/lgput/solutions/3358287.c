#include<stdio.h>
#include<stdlib.h>

int putere(int n, int p)
{
    if(p==0)
        return 0;
    if(p==1)
        return n;
    if(n%2==0)
        return putere(n*n,p/2);
    else 
        return n*putere(n*n,p/2);
}

int main(void)
{
    FILE* f,*g;
    int N,P,nr;
    if((f=fopen("lgput.in","r"))==NULL)
    {
        printf("fisierul de intrare nu a putut fi deschis\n");
        exit(EXIT_FAILURE);
    }
    if((g=fopen("lgput.out","w"))==NULL)
    {
        printf("fisierul de iesire nu a putut fi deschis\n");
        exit(EXIT_FAILURE);
    }
    if(fscanf(f,"%d %d",&N,&P)!=2)
    {
        printf("citire din fisier nereusita\n");
        exit(EXIT_FAILURE);
    }
    nr=putere(N,P);
    fprintf(g,"%d\n",nr);
    if(fclose(f)<0)
    {
        printf("fisierul de intrare nu a putut fi inchis\n");
        exit(EXIT_FAILURE);
    }
    if(fclose(g)<0)
    {
        printf("fisierul de iesire nu a putut fi inchis\n");
        exit(EXIT_FAILURE);
    }
    return 0;
}