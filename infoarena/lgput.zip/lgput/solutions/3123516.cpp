#include <iostream>
#include <fstream>

using namespace std;

typedef long long i64;



i64 calcul(i64 baza, i64 exp, int nr){
    if(exp==0) return 1;

    i64 result=calcul(baza, exp/2, nr);

    if(exp%2==0) return result*result%nr;

    return result*result%nr*baza%nr;
}

int main(){
    ifstream fin("lgput.in");
    ofstream fout("lgput.out");

    int N, P, nr=1999999973;
    fin>>N>>P;

    fout<<calcul(N, P, nr);

    return 0;
}
