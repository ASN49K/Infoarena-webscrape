#include <iostream>
#include <fstream>
#define mod 1999999973
using namespace std;
long long n,p;
long long po(long long x,long long exp)
{
    if (exp==1)
        return x;
    if (exp%2==1)
        return x*po(x,exp-1)%mod;
    else
    {
        long long a=po(x,exp/2);
        return a*a%mod;
    }
}
int main()
{
    ifstream f ("lgput.in");
    ofstream g ("lgput.out");
    f>>n>>p;
    n%=mod;
    g<<po(n,p);
}
