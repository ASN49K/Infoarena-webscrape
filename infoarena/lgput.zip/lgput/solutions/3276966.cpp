#include <iostream>
#include <fstream>
#define FIN "lgput.in"
#define FOUT "lgput.out"
using namespace std;

int main(int argc, char const *argv[])
{
	ifstream fin(FIN);
	ofstream fout(FOUT);
	long long a, b;
	fin >> a >> b;
	long long p=1;
	for(int i=1; i<=b; i++)
		p*=a; 
	fout<<p;
	return 0;
}