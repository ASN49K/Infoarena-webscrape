#include<stdio.h>
#include<stdlib.h>

#define mod 1999999973
#define intrare "lgput.in"
#define iesire "lgput.out"

long long ridicare_putere_timp_logaritmic(long long n, long long p)
{
    if(!p)
    {
        return 1;
    }
    
    if(p % 2)
    {
        return (ridicare_putere_timp_logaritmic(n, p-1) * n)% mod;
    }
    
    long long numar = ridicare_putere_timp_logaritmic(n, p / 2);
    
    return (numar * numar) % mod;
}

int main()
{
    FILE *in = NULL, *out = NULL;

    if( (in = fopen(intrare,"r")) == NULL )
    {
        perror(NULL);
        exit(EXIT_FAILURE);
    }
    if( (out = fopen(iesire,"w")) == NULL )
    {
        perror(NULL);
        exit(EXIT_FAILURE);
    }

    long long n = 0, p = 0;

    fscanf(in,"%lld %lld",&n,&p);
    fprintf(out,"%lld",ridicare_putere_timp_logaritmic(n,p));

    if( fclose(in) != 0 )
    {
        perror(NULL);
        exit(EXIT_FAILURE);
    }

    if( fclose(out) != 0 )
    {
        perror(NULL);
        exit(EXIT_FAILURE);
    }

    return 0;
}