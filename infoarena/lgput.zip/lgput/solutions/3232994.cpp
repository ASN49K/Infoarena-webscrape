#include <fstream>

using namespace std;

ifstream f("lgput.in");
ofstream g("lgput.out");

const int MOD=1999999973;

long long put2(int x, int n)
{
    long long val=1,a=x%MOD;
    while(n>0)
    {
        if(n%2!=0)
            val=val*a%MOD;
        a=a*a%MOD;
        n/=2;
    }
    return val;
}

int main()
{
    long long a,b;
    f>>a>>b;
    g<<put2(a,b);
    f.close();
    g.close();
    return 0;
}
