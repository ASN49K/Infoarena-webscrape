#include <fstream>
#include <iostream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

int lgput(int base, int exp) {
    if (exp==0) {
        return 1;
    }
    if (exp%2==0) {
        int half=lgput(base,exp/2);
        return (1LL*half*half)%1999999973;
    }
    return 1LL*base*lgput(base,exp-1)%1999999973;
}

int main() {
    int n,p;
    fin >> n >> p;
    fout << lgput(n,p);
}