#include <iostream>
#include <fstream>

using namespace std;

ifstream in("lgput.in");
ofstream out("lgput.out");

long long int recPow(long long int base, long long int exp)
{
    if (exp < 0)
    {
        base = 1 / base;
        exp = exp * (-1);
    }

    if (exp == 0)
        return 1;

    long long int result = 1;
    base = base % 1999999973;

    while (exp > 0)
    {
        if (exp % 2)
        {
            result = (result * base) % 1999999973;
        }
        base = (base * base) % 1999999973;
        exp = exp / 2;
    }

    return result;
}

int main()
{
    long long int n;
    long long int p;
    long long int pow;

    in >> n >> p;


    out << recPow (n, p);

    return 0;
}
