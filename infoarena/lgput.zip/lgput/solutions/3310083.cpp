#include <bits/stdc++.h>
using namespace std;

#define int long long

constexpr int MOD = 1999999973;

int lgput(int a, int n)
{
	int p = 1;
	for(; n; n >>= 1) {
		if(n & 1)
			p = (p * a) % MOD;
		a = (a * a) % MOD;
	}
	return p % MOD;
}

int32_t main()
{
	ifstream cin("lgput.in");
	ofstream cout("lgput.out");

	int n, p;
	
	cin >> n >> p;
	cin.close();

	cout << lgput(n, p);
    cout.close();
    
	return 0;
}