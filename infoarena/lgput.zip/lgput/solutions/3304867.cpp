#include <iostream>
#include <fstream>
#define MOD 1999999973

using namespace std;

ifstream fin ("lgput.in");
ofstream fout ("lgput.out");

int exponentiere(long long n, long long p);

int main()
{
    int n;
    long long p;
    fin>>n>>p;
    fout<<exponentiere(n,p);
}

int exponentiere(long long n, long long p)
{
    if (p==0)
    {
        return 1;
    }
    if (p%2==0)
    {
        return (1LL*exponentiere(n,p/2)*exponentiere(n,p/2))%MOD;
    }
    return (((1LL*exponentiere(n,p/2)*exponentiere(n,p/2))%MOD)*n)%MOD;
}