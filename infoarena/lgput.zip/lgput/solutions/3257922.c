#include <stdio.h>

#define p 1999999973;

int main(){
    int b, ans, pow;
    FILE *fin, *fout;

    fin = fopen( "lgput.in", "r" );
    fscanf( fin, "%d%d", &b, &pow );
    fclose( fin );
    ans = 1;

    while ( pow > 0 ) {
      if ( pow % 2 == 1 )
        ans = (long long) ans * b % p;
      pow = pow / 2;
      b = b * b;
    }

    fout = fopen( "lgput.out", "w" );
    fprintf( fout, "%d\n", ans );
    fclose( fout );
    return 0;
}
