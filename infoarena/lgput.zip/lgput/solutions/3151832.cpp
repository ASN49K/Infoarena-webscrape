#include <fstream>
#define MOD 1999999973
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
int main()
{
    int n,p,rez=1;
    cin>>n>>p;
    while(p>0)
    {
        if(p%2==0)
        {
            p/=2;
            n=1LL*n*n%MOD;
        }
        else
        {
            p--;
            rez=1LL*rez*n%MOD;
        }
    }
    cout<<rez;
    return 0;
}
