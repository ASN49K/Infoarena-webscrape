#include <bits/stdc++.h>
using namespace std;
std::string file = "lgput";
std::ifstream fin(file + ".in");
std::ofstream fout(file + ".out");
// #define fin std::cin
// #define fout std::cout
const long long MOD = 1999999973;

long long fastExp(long long x, long long n) {
  long long ans = 1;
  while (n) {
    if (n & 1)
      ans = (ans * x) % MOD;
    x = (x * x) % MOD;
    n >>= 1;
  }
  return ans;
}
int32_t main(int32_t argc, char *argv[]) {
  ios_base::sync_with_stdio(false);
  fin.tie(0);
  fout.tie(0);
  long long x, n;
  fin >> x >> n;
  fout << fastExp(x, n);
  return 0;
}
