#include <bits/stdc++.h>

using namespace std;

ifstream fin ("lgput.in");
ofstream fout ("lgput.out");

int main()
{
    int n,p;
    fin >> n >> p;
    while (p>0){
        if (p%2==0){
            n *= n;
            p /= 2;
        }else{
            p -= 1;
            p /= 2;
            n *= n;
        }
    }
    fout << n;
    return 0;
}
