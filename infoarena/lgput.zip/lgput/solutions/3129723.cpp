#include <iostream>
#include <fstream>
#define mod 1999999973
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
unsigned long long b, e;
unsigned long long putere(unsigned long long b, unsigned long long e)
{
    int p=1;
    while(e)
    {
        if(e&1)
            p*=b%mod;
        b*=b;
        e>>=1;
    }
    return p%mod;
}
int main()
{
    cin>>b>>e;
    cout<<putere(b,e)%mod;
    return 0;
}
