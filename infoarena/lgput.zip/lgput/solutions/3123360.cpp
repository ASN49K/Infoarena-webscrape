#include <fstream>
using namespace std;
long long a, b, c, p;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
int main() {
    cin>>a>>b;
    p=1;
    c=1999999973;
    while(b){
        if(b%2){
            p=p*a%c;
        }
        a=a*a%c;
        b/=2;
    }
    cout<<p;
}
