#include <bits/stdc++.h>

std :: ifstream in ("lgput.in");
std :: ofstream out ("lgput.out");

const int mod = 1999999973;

int n;

int p;

int exp(int a, int n)
{
    int p = 1;
    while(n)
    {
        if(n % 2)
        {
            p = (1ll * p * a) % mod;
        }
        a = (1ll * a * a) % mod;
        n /= 2;
    }

    return p;
}

int main()
{

    std :: ios_base :: sync_with_stdio(false);
    in.tie(NULL);

    in >> n >> p;

    out << exp(n,p);

    return 0;
}
