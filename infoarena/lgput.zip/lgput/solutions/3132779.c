#include <stdio.h>
#include <stdint.h>

uint64_t pw(uint64_t n,uint64_t p){
    uint64_t ans = 1;
    uint64_t pwr = n;
    while(p){
        if(p & 1){
            ans *= pwr;
        }
        pwr *= pwr;
        p >>= 1;
    }
    return ans;
}

int main(){
    freopen("lgput.in","r",stdin);
    freopen("lgput.out","w",stdout);

    uint64_t n,p;
    scanf("%llu %llu",&n,&p);
    printf("%llu\n",pw(n,p) % 1999999973);
    return 0;
}