#include <fstream>

using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
long long n,b,p;
int main()
{
    fin>>n>>b;
    p=1;
    while(b!=0)
    {
        if(b%2)
        {
            p=p*n%1999999973;
        }
        n=n*n%1999999973;
        b/=2;
    }
    fout<<p;
    return 0;
}
