#include <fstream>
#define mod 1999999973
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
long long calcul (long long  a,long long b)
{
    if(b==0)
        return 1;
    else
    {
        long long x=calcul(a,b/2);
        if(b%2==0)
            return x*x%mod;
        else
            return x*x%mod*a%mod;
    }

}
long long a,b,p;
int main()
{
   cin>>a>>b;
     cout<<calcul(a,b);
    return 0;
}
