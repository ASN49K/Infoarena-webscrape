#include <iostream>
#include <math.h>
#include <fstream>

std::ifstream in("lgput.in");
std::ofstream out("lgput.out");

unsigned int M = 1999999973;

void fpow(unsigned int N, unsigned int P){
  unsigned int result = 1;
  unsigned int aux = N;
  while(P > 0){
    if(P % 2 == 1){
      result *= (aux % M) ;
      P--;
      continue;
    }
    P/=2;
    aux*=(aux % M);
  }
  out  << result % M << std::endl;
}

int main(){
  if(!in.is_open()) throw std::runtime_error("File is not opened");
  if(!out.is_open()) throw std::runtime_error("File is not opened");

  unsigned int N, P;
  
  in >> N >> P;

  fpow(N, P);

}
