#include <stdio.h>

#define CONSTANT 1999999973

long long int LogNPower(long long int base, long long int exponent) {
    long long int result = 1;

    for(long long int index = 1; index <= exponent; index <<= 1) {
        if(exponent & index) {
            result  = (result * base) % CONSTANT;
        }

        base = (base * base) % CONSTANT;
    }

    return result;
}

int main()
{
    long long int base, exponent;

    freopen("lgput.in","r",stdin);
    freopen("lgput.out","w",stdout);
    scanf("%lld %lld", &base, &exponent);

    printf("%lld", LogNPower(base, exponent));

    return 0;
}

