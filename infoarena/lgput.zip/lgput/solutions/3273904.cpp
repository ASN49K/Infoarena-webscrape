#include <iostream>
#include <bits/stdc++.h>
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const int mo=1999999973;



int expo(int a,int b){
    if(!b)return 1;
    else{
        long long int t=expo(a,b/2);
        if(b%2)return a*((t*t)%mo)%mo;
        else return (t*t)%mo;
    }

}




int main()
{
    int n,p;
    fin>>n>>p;
    fout<<expo(n,p);
}
