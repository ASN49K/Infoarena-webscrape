#include <fstream>
using namespace std;
ifstream f("lgput.in");
ofstream g("lgput.out");
const long long mod = 1999999973;
long long n, p;
long long exponentiere(int n, int p){
    if(p == 0) return 1;
    else{
        long long nr = exponentiere(n, p / 2);
        if(p % 2 == 1){
            return n * nr * nr % mod;
        }
        else return nr * nr % mod;
    }
}
int main(){
    f >> n >> p;
    long long sol = 0;
    sol = exponentiere(n, p);
    g << sol % mod;
}