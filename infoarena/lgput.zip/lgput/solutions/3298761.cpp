#include <bits/stdc++.h>
using namespace std;

ifstream f("lgput.in");
ofstream g("lgput.out");

int main(void) {
    unsigned long long n, p;
    f >> n >> p;

    while (--p)
        n += n;

    g << n % 1999999973;
    return 0;
}