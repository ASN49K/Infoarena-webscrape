#include <fstream>

using namespace std;

ifstream f("lgput.in");
ofstream g("lgput.out");

int lgput(int a, int b){
    if(b==0)
        return 1;
    if(b%2!=0)
        return lgput(a, b - 1) * a;
    int hlf = lgput(a, b / 2);
    return hlf * hlf;
}

int main()
{
    int a,b;
    f>>a>>b;
    g<<(lgput(a,b)%1999999973);
    return 0;
}
