﻿
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio Version 17
VisualStudioVersion = 17.7.34221.43
MinimumVisualStudioVersion = 10.0.40219.1
Project("{8BC9CEB8-8B4A-11D0-8D11-00A0C91BC942}") = "Info_Excelenta_3", "Info_Excelenta_3\Info_Excelenta_3.vcxproj", "{3C862298-D21A-43D3-AFE7-59032FD490A5}"
EndProject
Global
	GlobalSection(SolutionConfigurationPlatforms) = preSolution
		Debug|x64 = Debug|x64
		Debug|x86 = Debug|x86
		Release|x64 = Release|x64
		Release|x86 = Release|x86
	EndGlobalSection
	GlobalSection(ProjectConfigurationPlatforms) = postSolution
		{3C862298-D21A-43D3-AFE7-59032FD490A5}.Debug|x64.ActiveCfg = Debug|x64
		{3C862298-D21A-43D3-AFE7-59032FD490A5}.Debug|x64.Build.0 = Debug|x64
		{3C862298-D21A-43D3-AFE7-59032FD490A5}.Debug|x86.ActiveCfg = Debug|Win32
		{3C862298-D21A-43D3-AFE7-59032FD490A5}.Debug|x86.Build.0 = Debug|Win32
		{3C862298-D21A-43D3-AFE7-59032FD490A5}.Release|x64.ActiveCfg = Release|x64
		{3C862298-D21A-43D3-AFE7-59032FD490A5}.Release|x64.Build.0 = Release|x64
		{3C862298-D21A-43D3-AFE7-59032FD490A5}.Release|x86.ActiveCfg = Release|Win32
		{3C862298-D21A-43D3-AFE7-59032FD490A5}.Release|x86.Build.0 = Release|Win32
	EndGlobalSection
	GlobalSection(SolutionProperties) = preSolution
		HideSolutionNode = FALSE
	EndGlobalSection
	GlobalSection(ExtensibilityGlobals) = postSolution
		SolutionGuid = {0726FB60-8A06-44AD-A296-9E59A68645F9}
	EndGlobalSection
EndGlobal
