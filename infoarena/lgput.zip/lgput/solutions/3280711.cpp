#include <bits/stdc++.h>
#define ll long long

using namespace std;

ifstream fin ("lgput.in");
ofstream fout ("lgput.out");

const int ct = 1999999973;

int main()
{
    fin.tie(0); fin.sync_with_stdio(false);
    ll a, b; fin>>a>>b;
    ll power = 1;
    while (b) {
        if (b%2==1) power*=a; //Neaparat in ordinea asta in while (descompunerea in baza 2)
        a*=a;
        b/=2;
        if (a>=ct) a%=ct;
        if (power>=ct) power%=ct;
    }
    fout<<power;
    return 0;
}
//2^4 = 100
//