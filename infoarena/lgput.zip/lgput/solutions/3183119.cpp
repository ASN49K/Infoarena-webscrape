#include <bits/stdc++.h>

using namespace std;
const int NMAX = 102;
const int MOD = 1999999973;
ifstream fin("lgput.in");
ofstream fout("lgput.out");

int lgput(long long n, long long p) {
    long long aux = 1;
    for(int i = 0; i <= 32; i++)
    {

        if(p & ( 1LL << i ))
            aux = (aux * n) % MOD;
        n = (n * n) % MOD;
    }
    return aux;
}

int main() {
    long long n, p;
    fin >> n >> p;
    fout << lgput(n, p);

    return 0;
}
