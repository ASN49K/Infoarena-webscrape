#include <iostream>
#include <fstream>

using namespace std;

const int mod = 19994993;

long long exp_log_rec(long long x, long long n) {
    if (n == 0) return 1;

    if (n % 2 == 0) {
        return exp_log_rec((x * x) % mod, n / 2) % mod;
    } 
    else {
        return (x * exp_log_rec((x * x) % mod, n / 2)) % mod;
    }
}

int main() {

    ifstream fin("lgput.in");
    ofstream fout("lgput.out");

    long long n, p;
    fin >> n >> p;

    fout << exp_log_rec(n, p) << "\n";

    fin.close();
    fout.close();
    return 0;
}