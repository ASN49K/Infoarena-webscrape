#include <fstream>
#include <algorithm>

#define MOD 1999999973

using namespace std;

long long power(long long n, long long p) {
    if (p == 1)
        return n;
    else if(p == 0)
        return 1;
    long long x = power(n, p / 2);
    if (p % 2 == 0)
        return x * x % MOD;
    else
        return n * x * x % MOD;
}

int main() {
    ifstream cin("lgput.in");
    ofstream cout("lgput.out");

    int n, p;
    cin >> n >> p;
    cout << power(n, p);
    return 0;
}