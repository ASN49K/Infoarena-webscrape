// https://infoarena.ro/problema/lgput
// Dandu-se doua numere naturale N si P, se cere sa se calculeze restul impartirii lui N^P la 1999999973.

#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

const unsigned int MOD = 1999999973;

// Functia calculeaza baza^exponent folosind exponentierea rapida
unsigned int ExponentiereRapida(unsigned int baza, unsigned int exponent)
{
	if (exponent == 0)
	{
		return 1; // Orice numar la puterea 0 este 1
	}

	// Nu tratam cazul exponent < 0 deoarece stim ca N si P sunt naturale

	unsigned int rezultat = 1;
	while (exponent > 0)
	{
		if (exponent % 2 == 1)
		{
			rezultat = (rezultat * baza) % MOD;
		}
		baza = (baza * baza) % MOD;
		exponent = exponent / 2;
	}
	return rezultat;
}

int main()
{
    ifstream fin("lgput.in");
	ofstream fout("lgput.out");

    if (!fin.is_open())
    {
        cerr << "Eroare la deschiderea fisierului de intrare!";
        return 1;
    }

	if (!fout.is_open())
	{
		cerr << "Eroare la deschiderea fisierului de iesire!";
		return 1;
	}


	unsigned int N, P;
	fin >> N >> P;
	if (N < 2 || P > pow(2, 32))
	{
		cerr << "Nu se respecta restrictiile: N <= 2 si P <= 2^32";
		return 1;
	}

	unsigned int rezultat = ExponentiereRapida(N, P);
	
	fout << rezultat << endl;
	
	fin.close();
	fout.close();

	return 0;
}