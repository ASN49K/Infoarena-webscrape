#include <fstream>
#define MOD 1999999973

using namespace std;
ifstream fin("permutari.in");
ofstream fout("permutari.out");
long long n,p;
long long putere(long long a, long long x)
{
    if(x==0)
        return 1;
    long long p=putere(a,x/2);
    if(x%2==0)
        return p*p%MOD;
    else return p*p%MOD*a%MOD;
}
int main()
{
    fin>>n>>p;
    fout<<putere(n,p);
    return 0;
}
