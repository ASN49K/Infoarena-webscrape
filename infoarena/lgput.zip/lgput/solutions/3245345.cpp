#include <bits/stdc++.h>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
int MOD=1999999973;
int fast_exp(long long a,int b){
    long long ans=1;
    while(b){
        if(b%2){
            ans=(ans*a)%MOD;
        }
        a=(a*a)%MOD;
        b/=2;
    }
    return ans;
}
int main(){
    long long a,b;
    fin>>a>>b;
    fout<<fast_exp(a,b);
}
