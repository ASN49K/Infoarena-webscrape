#include <bits/stdc++.h>
#define prim 1999999973
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
int exp(int a, int n){
    if(n == 0){
        return 1;
    }
    if(n % 2 == 1){
        return (long long)exp(a, n - 1) * a % prim;
    }else{
        return exp((long long)a * a % prim, n / 2);
    }
}
int main()
{
    int n, p;
    fin >> n >> p;
    fout << (long long)exp(n, p) % prim;
    return 0;
}
