
#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("lgput.in");
ofstream fout ("lgput.out");
#define MOD 1999999973
long long int n,p;
long long int rez=1;
long long int pw(int n, int p)
{


    while (p>0)
    {
        if(p%2!=0)
            rez=rez*n%MOD;
        n=n*n%MOD;
        p/=2;

    }
    return rez;
   /** if(p==1) return n;
   if(p%2==0)
   {
       return pw(n*n,p/2);
   }
   else{

        return n*pw(n,p--);

   }
    */
}


int main ()
{

    fin>>n>>p;

     fout << pw(n,p);
    return 0;


}
