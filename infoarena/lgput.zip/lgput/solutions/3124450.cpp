#include <fstream>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");

int mod=1999999973;

long long calcul(long long a, long long b)
{
    if(b==0)
    {
        return 1;
    }
    else
    {
        long long crt=calcul(a, b/2);
        if(b%2==0)
        {
            return crt*crt%mod;
        }
        else
        {
            return crt*crt%mod*a%mod;
        }
    }
}

long long n, m;

int main()
{
    fin>>n>>m;
    fout<<calcul(n, m);
}
