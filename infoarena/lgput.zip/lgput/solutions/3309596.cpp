#include<fstream>

using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
long long exp(long long b,long long p){
    if(p==0)
        return 1;
    if(p%2==0){
        long long next=exp(b,p/2)%1999999973;
        return ((next*next)%1999999973);
    }
    else{
        long long next=exp(b,p-1)%1999999973;
        return ((next*(b%1999999973))%1999999973);
    }
}
int main()
{
    long long x,y;
    cin>>x>>y;
    cout<<exp(x,y)%1999999973;
    return 0;
}
