#include <fstream>

using namespace std;

const int MOD = 1999999973;

int lg_put(int a, int n)
{
    if (n == 0)
    {
        return 1;
    }
    int r = lg_put(a, n / 2);
    r = (long long)r * r % MOD;
    if (n % 2 != 0)
    {
        return (long long)r * a % MOD;
    }
    return r;
}

int main()
{
    ifstream in("lgput.in");
    ofstream out("lgput.out");
    int a, n;
    in >> a >> n;
    out << lg_put(a, n) << "\n";
    in.close();
    out.close();
    return 0;
}
