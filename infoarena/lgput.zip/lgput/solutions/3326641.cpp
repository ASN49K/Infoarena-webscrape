#include <fstream>

using namespace std;

const int MOD = 1999999973;

int main()
{
    ifstream in("lgput.in");
    ofstream out("lgput.out");
    int a, n;
    in >> a >> n;
    int p = 1;
    while (n != 0)
    {
        int cif = n % 2;///n & 1
        if (cif != 0)
        {
            p = (long long)p * a % MOD;
        }
        a = (long long)a * a % MOD;
        n /= 2;///n >>= 1
    }
    out << p << "\n";
    in.close();
    out.close();
    return 0;
}
