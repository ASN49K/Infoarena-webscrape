#include <stdio.h>

unsigned exp_by_squaring(unsigned x, unsigned n)
{
    unsigned long long y=1;
    while(n)
    {
        if(n%2==1)
        {
            y=(x*y)%1999999973;
        }
        x=x*x%1999999973;
        n/=2;
    }
    return x*y%1999999973;
}

int main()
{
    FILE *in = fopen("lgput.in", "r");
    FILE *out = fopen("lgput.out", "w");


    unsigned x,n;
    fscanf(in,"%u %u",&x,&n);

    fprintf(out,"%u",exp_by_squaring(x,n));
}