#include <fstream>

using namespace std;
ifstream cin ("lgput.in");
ofstream cout ("lgput.out");
int main()
{
    int n, p, prod = 1;
    cin >> n >> p;
    while(p > 0)
    {
        if (p % 2 == 1)
        {
            prod *= n;
        }
        n *= n;
        p = p / 2;
    }
    //cout << prod << endl;
    cout << prod % 1999999973;
    return 0;
}
