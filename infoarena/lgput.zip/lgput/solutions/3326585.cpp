#include <bits/stdc++.h>
#define ll long long

using namespace std;
const int mod = 1999999973;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
ll n,p;
ll ridicare(ll n, ll p){
    if(p==1)
        return n;
    ll aux = ridicare(n,p/2);
    if(p%2==0){
        return aux*aux%mod;
    } else
        return((( aux*n)%mod)*aux)%mod;
}
int main(){
    fin>>n>>p;
    fout<<ridicare(n,p);
   return 0;
}
