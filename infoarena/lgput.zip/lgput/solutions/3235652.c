#include <stdio.h>
#include <stdlib.h>

#define input "lgput.in"
#define output "lgput.out"

//Ghimpău Mihai-Vladimir

int main(void)
{
    FILE *in, *out;
    in = fopen(input, "r");
    out = fopen(output, "w");

    long long int n, p, m = 1999999973, ans = 1;

    fscanf(in, "%lld %lld", &n, &p);
    n = n % m;
    while(p)
    {
        if(p % 2)
        {
            ans = (ans * n) % m;
            p--;
        }
        else
        {
            n = (n * n) % m;
            p /= 2;
        }
    }
    fprintf(out, "%lld", ans);
    
    fclose(in);
    fclose(out);
    return 0;
}