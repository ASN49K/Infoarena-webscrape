#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#define MODULO 1999999973

uint64_t exponentiere_rapida(uint64_t a, uint64_t b)
{
    uint64_t res = 1;
    a = a % MODULO;  //in caz ca sunt numere prea mari

    while(b >0)
    {
        if (b % 2 == 1)
        {
          res*=a;
            res = res % MODULO; 
        }
        b = b >> 1; 
        a = a * a;
    }

    return res;
}

int main(void)
{
    FILE *fin = fopen("lgput.in", "r");
    FILE *fout = fopen("lgput.out", "w");

    uint64_t a, b;
    // scanf("%lu %lu", &a, &b);
    fscanf(fin, "%lu %lu", &a, &b);
 
    uint64_t res = exponentiere_rapida(a, b);
 
    fprintf(fout, "%lu", res);
    // printf("%lu", res);

    fclose(fin);
    fclose(fout);
    return 0;
}