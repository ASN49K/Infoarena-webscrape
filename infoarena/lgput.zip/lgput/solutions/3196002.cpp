#include <bits/stdc++.h>
#define MOD 1999999973
using namespace std;
ifstream fin ("lgput.in");
ofstream fout ("lgput.out");
long long n,p,i,rez=1;
long long pwr(long long baza, long long putere)
{
    rez=1;
    while(putere!=0)
    {
        if(putere%2!=0)
            rez=rez*baza%MOD;
        baza=baza*baza%MOD;
        putere=putere/2;
    }
    return rez;
}
int main()
{
    fin>>n>>p;
    fout<<pwr(n,p);
    return 0;
}
