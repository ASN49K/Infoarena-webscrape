#include <bits/stdc++.h>

using namespace std;

ifstream in ("lgput.in");
ofstream out ("lgput.out");

#define mod 1999999973

int main()
{
    int a,b;
    in >> a >> b;

    int result=1;

    while (b>0) {
        if (b%2==0) {
            a=(a*a)%mod;
            b/=2;
        } else {
            result=(result*a)%mod;
            b--;
        }
    }
    out << result;
    return 0;
}

