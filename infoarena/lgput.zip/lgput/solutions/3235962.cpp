#include <fstream>
#define MOD 1999999973

typedef unsigned int ex;
typedef unsigned long long num;

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

int main()
{
    unsigned long long a, res = 1;
    unsigned b;
    cin >> a >> b;
    while (b)
    {
        if (b & 1)
            res = (res * a) % MOD;
        a = (a * a) % MOD;
        b >>= 1;
    }
    cout << res;
}