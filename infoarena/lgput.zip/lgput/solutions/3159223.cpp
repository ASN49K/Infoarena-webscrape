#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

const string FILE_NAME = "lgput";
const string input = FILE_NAME + ".in";
const string output = FILE_NAME + ".out";

ifstream fin(input);
ofstream fout(output);

unsigned p(unsigned a, unsigned b, unsigned mod) {
	long long rez = 1;

	while (b) {
		if (b % 2 == 1) {
			a = 1LL * a * a % mod;
		}
		rez *= a;
		b >>= 1;
	}

	while (rez < 0) rez += mod;
	return rez;
}

int main()
{
	unsigned a, b;

	fin >> a >> b;

	fout << p(a, b, 1999999973);

	return 0;
}