#include <iostream>
#include <fstream>
using namespace std;
long long lgput(long long x, long long n)
{
    if (n == 0) return 1;
    if (n % 2 == 0) 
    {
        return  lgput(x, n/2) * lgput(x, n/2) %1999999973;
    }
    else
    {
        return x* lgput(x, (n-1)/2) * lgput(x, (n-1)/2)% 1999999973;
    }
    
}
ifstream fin("lgput.in");
ofstream fout("lgput.out");
int main() 
{
    long long x, y;
    fin >> x >> y;
    fout << lgput(x,y);
    return 0;
}
