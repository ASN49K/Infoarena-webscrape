#include<fstream>
using namespace std;

ifstream f("lgput.in");
ofstream g("lgput.out");

long long x,y;
long long const mod=1999999973;
long long putere(long long a,long long n)
{
    if(n==0)
        return 1;
    else if(n%2==1)
        return (a*putere(a,n-1))%mod;
    int p=putere(a,n/2)%mod;
    return (p*p)%mod;
}

int main()
{
    f>>x>>y;
    g<<putere(x,y)%mod;
}
