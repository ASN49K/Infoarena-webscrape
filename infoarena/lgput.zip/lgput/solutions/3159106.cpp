﻿#include <bits/stdc++.h>
#include <unordered_map>
using namespace std;
#define ll long long 
#define ull unsigned long long 
#define nmax 5000006
#define MOD 1999999973 
#define INF 2123456789
//#define fin cin 
//#define fout cout 

ifstream fin("lgput.in");
ofstream fout("lgput.out");

int n, m;

ll Put(int x, int exp)
{
	if (exp == 0)
		return 1;
	if (exp % 2 != 0)
		return x * Put(x, exp - 1) % MOD;
	ll P = Put(x, exp / 2);
	return P * P % MOD;
}

int main()
{
	fin >> n >> m;
	fout << Put(n, m) << "\n";
	fin.close();
	fout.close();
	return 0;
}