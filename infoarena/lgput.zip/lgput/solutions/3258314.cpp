#include <iostream>

using namespace std;
const int MOD =666013;
int powlg(int a,int b)
{
  int rez = 1;
  while(b!=0)
  {
     if(b%2==0)
     {
        b/=2;
        a = 1LL * a * a % MOD;
     }
     else if(b%2==1)
     {
        b--;
        rez = 1LL * rez * a % MOD;
     }
  }
  return rez;
}
int main()
{
    cout << powlg(3,6);
    return 0;
}
