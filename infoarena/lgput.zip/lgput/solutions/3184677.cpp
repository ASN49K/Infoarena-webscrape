#include <bits/stdc++.h>

using namespace std;

#define int long long int

ifstream fin ("lgput.in");
ofstream fout ("lgput.out");

const int mod = 1999999973;
int a,n;

int lg(int a, int n) {
    if (n == 0)
        return 1;
    else {
        if (n % 2)
            return ((a % mod) * (lg(a, n / 2) % mod)) % mod;
        else {
            int c = lg(a, n / 2);
            return (c % mod * c % mod) % mod;
        }
    }
}


signed main() {
    fin >> a >> n;
    fout << lg(a,n);
    return 0;
}
