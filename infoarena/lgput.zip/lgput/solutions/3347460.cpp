#include <fstream>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
long long a,b,x;
int main()
{
fin>>a>>b;
x = 1;
while(b){
    if(b & 1 == 1){
        x = (1LL * x * a)%1999999973;
    }
    b >>= 1LL;
    a = (1LL * a * a) % 1999999973;
}
fout << x  << endl;
    return 0;
}
