#include <iostream>
#include <fstream>
using namespace std;

const int MOD = 1999999973;

int main()
{
    ifstream fin("lgput.in");
    ofstream fout("lgput.out");

    // n^(2k) = (n^2)^k
    // n^(2k+1) = (n^2)^k  * n

    int alap, kitevo;
    fin >> alap >> kitevo;

    int eredmeny = 1;

    while (kitevo > 0) {
        if (kitevo % 2 == 1)
            eredmeny = ((long long) eredmeny * alap % MOD);

        alap = (long long)alap * alap % MOD;
        kitevo = kitevo / 2;
    }
    // 2^16 -> 4^8 -> 16^4 -> 256^2 -> 65536^1

    fout << eredmeny << endl;
    return 0;
}
