#include <iostream>
#include <fstream>
using namespace std;

#ifdef LOCAL
#define fin cin
#define fout cout
#else
ifstream fin("lgput.in");
ofstream fout("lgput.out");
#endif

const int MOD = 1999999973;

long long int exp(long long int b, long long int p) {
	if (p == 0) return 1;
	if (p % 2 == 0) return (exp(b % MOD, p / 2) * exp(b % MOD, p / 2)) % MOD;
	return ((b % MOD) * exp(b % MOD, p / 2) * exp(b % MOD, p / 2)) % MOD;
}

int main() {
	int n, p;
	fin >> n >> p;
	fout << exp(n, p);
}
