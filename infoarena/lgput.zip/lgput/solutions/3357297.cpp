#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

#define NR 1999999973

long long exp(long long N, long long P){
    if(P < 0) return exp(1.0/N,-P);
    if(P == 0) return 1;
    if(P%2 == 0) return exp(N*N,P/2)%NR;
    return (N * exp(N*N,P/2)%NR)%NR;
}

int main()
{
    long long N,P;
    fin>>N>>P;
    fout<<exp(N,P);
    return 0;
}
