#include <fstream>
#define int long long
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
const int mod=1999999973;
int put(int baza, int exponent)
{
    if(exponent==1)
        return baza%mod;
    if(exponent%2==0)
        return ((put(baza, exponent/2)%mod)*(put(baza, exponent/2)%mod))%mod;
    return (baza*put(baza, exponent-1))%mod;
    
}
signed main()
{
    int n,p;
    cin>>n>>p;
    cout<<put(n,p);

    return 0;
}
