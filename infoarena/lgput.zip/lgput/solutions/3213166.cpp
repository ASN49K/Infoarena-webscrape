#include<bits/stdc++.h>

using namespace std;

const long long MOD = 1999999973;
long long a, b;

long long ridput()
{
    long long ans = 1;
    while(b)
    {
        if(b % 2)
            ans *= a;
        b >>= 1;
        a *= a;
        a %= MOD;
        ans %= MOD;
    }

    return ans;
}

int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    freopen("lgput.in", "r", stdin);
    freopen("lgput.out", "w", stdout);

    cin >> a >> b;

    cout << ridput();
}