#include <iostream>
#include <fstream>
#define k 1999999973
using namespace std;

ifstream in("lgput.in");
ofstream out("lgput.out");

long long int exponent(long long int x,long long int n)
{
    if(n<0)
        return exponent((1/x)%k,-n)%k;
    else if(n==0)
        return 1;
    else if(n%2==1)
        return (x*exponent((x*x)%k,(n-1)/2))%k;
    else if(n%2==0)
        return exponent((x*x)%k,n/2)%k;
}
int main()
{
    long long int x,n;
    in>>x>>n;
    out<<exponent(x,n);
    return 0;
}
