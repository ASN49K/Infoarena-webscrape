#include <iostream>
#include <math.h>
#include <fstream>
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long int power(int n, int p)
{
    long long int finale;
    if(p==0)
    {
        return 1;
    }
    if(p%2==1)
    {
        return n*power(n,p-1);
    }
    else
        final= power(n,p/2);
    return finale *finale;
}


int main()
{
    long long int n,p,finale;
    fin>>n>>p;
    finale=power(n,p);
    fout << finale;
    return 0;
}
