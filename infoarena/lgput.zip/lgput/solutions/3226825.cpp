#include <bits/stdc++.h>
#include <fstream>
#define int long long

using namespace std;
const int mod = 1999999973;
int32_t main()
{
    ifstream cin("lgput.in");
    ofstream cout("lgput.out");
    int n,p,kn=1;
    cin>>n>>p;
    while(p>0)
    {
        if(p%2==1)
            kn*=n%mod;
        n=n*n%mod;
        p/=2;
    }
    cout<<kn%mod;



    return 0;
}
