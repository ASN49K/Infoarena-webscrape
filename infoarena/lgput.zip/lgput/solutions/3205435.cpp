#include <fstream>
#define MOD 1999999973
#define ll long long

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

ll n, p;

ll ceva(ll n, ll p)
{
	if (p == 1) return n;
	if (p % 2 == 0)
		return ceva((n * n) % MOD, p / 2) % MOD;
	else
		return (n*ceva((n * n) % MOD, (p - 1) / 2)) % MOD;
}

int main()
{
	cin >> n >> p;
	cout << ceva(n, p);
}