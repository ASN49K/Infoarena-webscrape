#include <bits/stdc++.h>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const int MOD = 1999999973;

int lgput(int n, int a)
{
  if(a==0)
  {
    return a;
  }

  else if(a%2 == 0)
  {
    int val = lgput(n, a/2);
    return (val*val) % MOD;
  }

  else
  {
    return (n * lgput(n, a - 1)) % MOD;
  }

}


int main()
{
    int n, p;
    fin >> n >> p;
    fout << lgput(n, p);
    return 0;
}
