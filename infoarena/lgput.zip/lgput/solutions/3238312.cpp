#include <iostream>
#include <fstream>

using namespace std;
ifstream in("lgput.in");
ofstream out("lgput.out");

int main(){
  long long  N, P;
  int m = 1999999973;
  in >> N >> P;
  long long result = 1;
  while(P > 0)
  {
    if(P & 1) result = (result % m) * (N % m) % m;
    P = P >> 1;
    N = (N % m)  * (N % m)  % m;
  }
  out << result % m; 
}
