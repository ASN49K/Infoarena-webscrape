#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

#define MOD 1999999973

int quick_exp(int x, int p) {
    if (p == 0) return 1;
    if (p % 2 == 0) {
        int t = quick_exp(x, p / 2) % MOD;
        return t * t % MOD;
    }
    else {
        return x * quick_exp(x, p - 1) % MOD;
    }
}

int main() {
    int n, p;
    fin>>n>>p;
    
    fout<<quick_exp(n, p);
    

    return 0;
}
