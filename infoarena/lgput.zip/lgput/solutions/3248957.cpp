#include <bits/stdc++.h>

using namespace std;

const long long max_size = 1e5 + 20, INF = 2e9 + 1;

void solve ()
{
    int n;
    cin >> n;
    int mx = -INF, poz = 0, dr = 0, st = 0, s = 0;
    for (int i = 1; i <= n; i++)
    {
        int x;
        cin >> x;
        if (s < 0)
        {
            s = 0;
            st = i;
        }
        s += x;
        if (mx < s)
        {
            mx = s;
            poz = st;
            dr = i;
        }
    }
    cout << mx << " " << poz << " " << dr;
    cout << '\n';
}

signed main ()
{
#ifdef LOCAL
    freopen("test.in", "r", stdin);
    freopen("test.out", "w", stdout);
#else
    freopen("ssm.in", "r", stdin);
    freopen("ssm.out", "w", stdout);
#endif // LOCAL
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    long long tt;
    //cin >> tt;
    tt = 1;
    while (tt--)
    {
        solve();
    }
    return 0;
}
