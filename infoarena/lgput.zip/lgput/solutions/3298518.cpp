#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long constanta=1999999973;

long long ridicare_log(long long N,long long P)
{
    if(P==0) return 1;

    long long rez=ridicare_log(N,P/2);
    rez=(rez*rez)%constanta;

    if(P%2==1) rez=(rez*N)%constanta;

    return rez;

}
int main()
{   long long N,P; 
    fin>>N>>P;
    
    long long rez=ridicare_log(N,P);
    fout<<rez<<endl;

    fin.close();
    fout.close();
    return 0;
}