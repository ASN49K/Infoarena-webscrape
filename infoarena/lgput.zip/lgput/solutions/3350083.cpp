#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
#define MOD 1999999973
ll fastexp(ll base, ll exp){
    ll t = 1LL;
    while(exp > 0){
        if(exp % 2 == 1) t = (t*base)%MOD;

        base = (base*base)%MOD;
        exp/=2;
    }

    return t % MOD;
}

int main(){
    ll n,p;
    fin >> n >> p;
    fout << fastexp(n, p) ;
    return 0;
}