#include <iostream>
#include <fstream>

int hatvany(int a, int b){

    if(b == 2){
        return a*a;
    }
    else if(b%2 == 0){
        return hatvany(hatvany(a, b/2), 2);
    }
    else {
        return hatvany(hatvany(a, b/2), 2) * a;
    }
}

int main(){

    std::ifstream input("lgput.in");
    std::ofstream output("lgput.out");

    int a, b, sum;
    input >> a >> b;

    output << hatvany(a, b);

    return 0;
}