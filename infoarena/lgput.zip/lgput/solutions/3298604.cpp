#include <iostream>
#include <fstream>

#define MOD 1999999973

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

uint64_t pow(uint32_t n, uint32_t p)
{
    if (p == 0)
    {
        return 1;
    }
    
    if (p == 1)
    {
        return n;
    }

    if ((p & 1) == 1)
    {
        uint64_t N = pow(n, (p - 1) / 2);
        return (n * N * N);
    }

    uint64_t N = pow(n, p / 2);

    return (N * N);
}

int main()
{
    uint32_t n, p;

    fin >> n >> p;

    uint32_t result = pow(n, p) % MOD;

    fout << result << '\n';

    return 0;
}