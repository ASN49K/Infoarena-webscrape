
#include <iostream>
#include <fstream>
using namespace std;
ifstream fin ("lgput.in");
ofstream fout ("lgput.out");
long long int n,p,rez=1;
long long int pw(int n, int p)
{

   if(!p) return 1;
   if(p%2==0)
   {
       return pw(n*n,p/2);
   }
   else{

        return pw(p--,n)*n;

   }

}
int main ()
{

    fin>>n>>p;
    fout << pw(n,p);


}
