#include <iostream>
#include <fstream>
using namespace std;

long long exp(long long a,long long b) {
	if (a<0)
		return exp(1 / a, -b);
	if (b == 0)return 1;
	else
		if (b == 1)return a;

	if (b % 2 == 0)return exp(a*a, b / 2)%1999999973;
	else return a*exp(a*a, b / 2) % 1999999973;

}

int main() {
	long long n, p;

	ifstream fi("lgput.in");

	fi >> n >> p;
	fi.close();
	ofstream fo("lgput.out");
	fo << exp(n, p);
	fo.close();
}