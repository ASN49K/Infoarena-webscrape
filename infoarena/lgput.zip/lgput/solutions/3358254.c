#include <stdio.h>
#define MOD 1999999973 // modulul din problema

// functia care calculeaza b^e % MOD in timp O(log e)
unsigned long long put_log(unsigned long long b, unsigned long long e)
{
    if (e == 0) // orice numar la puterea 0 este 1
        return 1;

    b = b % MOD; // reducem baza de la inceput pentru a evita overflow-ul

    unsigned long long rez = 1; // rezultatul, initializat cu 1

    while (e > 0)
    {
        if (e % 2 == 1) // daca exponentul curent e impar, inmultim rezultatul cu baza
        {
            rez = rez * b % MOD; // % MOD pentru a evita overflow-ul
        }

        b = b * b % MOD; // ridicam baza la patrat la fiecare pas
        e = e / 2;       // impartim exponentul la 2 (trecem la urmatorul bit)
    }

    return rez;
}

int main()
{
    FILE *fin  = fopen("lgput.in",  "r");
    FILE *fout = fopen("lgput.out", "w");

    if (fin == NULL) // verificam daca fisierul s-a deschis cu succes
    {
        printf("Eroare la deschiderea fisierului\n");
        return 0;
    }

    unsigned long long n, p; // n = baza, p = exponentul, pot fi pana la 2^32
    fscanf(fin, "%llu %llu", &n, &p);

    unsigned long long ans = put_log(n, p); // calculam n^p % MOD

    fprintf(fout, "%llu\n", ans);

    fclose(fin);
    fclose(fout);

    return 0;
}