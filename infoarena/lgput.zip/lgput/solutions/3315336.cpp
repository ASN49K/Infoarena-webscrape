#include <bits/stdc++.h>


#define MOD 1999999973

using namespace std;

ifstream fin ("lgput.in");
ofstream fout ("lgput.out");

long long int n, p;

long long int exp_rapid (long long int n, long long int p);

int main()
{
    fin>>n>>p;
    fout<<exp_rapid(n, p)<<'\n';
    return 0;
}

long long int exp_rapid (long long int n, long long int p)
{
 if(p == 0) return 1;
 if(p % 2 == 1) return ((n % MOD) * (exp_rapid(n, p - 1) % MOD)) % MOD;
 int putere = exp_rapid(n, p / 2) % MOD;
 return (putere * putere) % MOD;
}
