#include <bits/stdc++.h>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
const int mod=1999999973;
int main()
{
    int a,b,p=1;
    fin>>a>>b;
    while(b!=0)
    {
        if(b%2==1)
            p=(p*a)%mod;
        a=(a*a)%mod;
        b=b/2;
    }
    fout<<p;
    return 0;
}
