#include <stdio.h>
#include <stdlib.h>

#define fin "lgput.in"
#define fout "lgput.out"

#define mod 1999999973

long long log_exp(long long y,long long x,int n){
    if(n==0){
        return y;
    }
    if(n%2){
        return log_exp((y*x)%mod,(x*x)%mod,(n-1)/2);
    }
    else{
        return log_exp(y%mod,(x*x)%mod,n/2);
    }
}

int main()
{
    FILE *f,*g;
    f=fopen(fin,"r");
    g=fopen(fout,"w");
    long long n,p;
    fscanf(f,"%lld%lld",&n,&p);
    fprintf(g,"%lld\n",log_exp(1,n,p));
    fclose(f);
    fclose(g);
    return 0;
}
