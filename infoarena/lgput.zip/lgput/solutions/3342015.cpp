#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
const int MOD = 1999999973;
int main()
{
    int n, p, rez = 1;
    cin>>n>>p;

    while (p != 0) {

        if (p % 2 == 1) {

            rez = (rez*n)%MOD;
        }

        n = (n*n)%MOD;
        p /= 2;
    }

    cout<<rez;
    return 0;
}
