#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");
int main()
{
    long long a, n, p=1;
    fin >> a >> n;
    while(n>0)
    {
        if (n%2==1)
            p=p*a%1999999973;
        a=a*a%1999999973;
        n=n/2%1999999973;
    }
    fout << p%1999999973;
    return 0;
}
