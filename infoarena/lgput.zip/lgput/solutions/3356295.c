#include <stdio.h>
#include <stdlib.h>

void citire(long long int *N, long long int *P)
{
    long long int n,p;
    FILE *f;
    if((f=fopen("lgput.in", "r"))==NULL)
    {
        perror("eroare deschidere fisier\n");
        exit(1);
    }
    if(fscanf(f,"%lld %lld", &n, &p)!=2)
    {
        exit(1);
    }
    fclose(f);
    *N=n;
    *P=p;
}

void afisare(long long int exp)
{
    FILE *g;
    if((g=fopen("lgput.out", "w"))==NULL)
    {
        perror("eroare deschidere fisier2\n");
        exit(1);
    }
    fprintf(g, "%lld", exp);
    fclose(g);
}

long long int exp_log(long long int N, long long int P, long long int mod)
{
    N=N%mod;
    long long int exp=1;
    if (P<0)
    {
        N=1.0/N;
        P=(-1)*P;
    }
    else if (P==0)
    {
        return 1;
    }
    else
    {
        while (P>0)
        {
            if(P%2==1)
            {
                exp=exp*N%mod;
            }
            N=N*N%mod;
            P=P/2;
        }
    }
    return exp;
}

int main()
{
    long long int N, P, mod=1999999973;
    citire(&N,&P);
    long long int exp=exp_log(N, P, mod);
    afisare(exp);
    return 0;
}