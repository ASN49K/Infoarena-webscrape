#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");
int main()
{
    int n, p, k = 1, a;
    fin >> n >> p;
    a = n;
    if (p == 0)
    {
        fout << 1;
        return 0;
    }
    while (k < p)
    {
        n *= n;
        k *= 2;
        if (k * 2 > p)
        {
            while (k < p)
            {
                n *= a;
                k++;
            }
            break;
        }
    }
    fout << n; 
}