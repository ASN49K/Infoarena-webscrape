//https://www.infoarena.ro/problema/lgput

#include <cstdio>
#include <cstdint>

const int MOD = 1999999973;

int64_t power_of_manyyy(int64_t b, int64_t e, int64_t modulo)
{
    int64_t rez = 1;

    asm volatile (
        // while (e > 0)
        "start_loop:\n"
        "cmp $0, %[e]\n"
        "je end_loop\n"

        // if (e & 1)
        "test $1, %[e]\n"
        "jz skip_if\n"

        // rez = rez * b % modulo;
        "mov %[rez], %%rax\n"
        "mul %[b]\n"
        "div %[modulo]\n"
        "mov %%rdx, %[rez]\n"

        "skip_if:\n"

        // b = b * b % modulo
        "mov %[b], %%rax\n"
        "mul %[b]\n"
        "div %[modulo]\n"
        "mov %%rdx, %[b]\n"

        // e >>= 1
        "shr $1, %[e]\n"

        "jmp start_loop\n"

        "end_loop:\n"
        : [rez] "+r" (rez), [b] "+r" (b), [e] "+r" (e)
        : [modulo] "r" (modulo)
        : "rax", "rdx"
    );

    return rez;
}

int main()
{
    FILE* fin = fopen("lgput.in", "r");
    FILE* fout = fopen("lgput.out", "w");

    int64_t n, p;

    fscanf(fin, "%lld %lld", &n, &p);

    fprintf(fout, "%lld", power_of_manyyy(n, p, MOD));

    return 0;
}
