#include <iostream>
#include <fstream>

#define MOD 1999999973

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

uint64_t pow(uint64_t n, uint64_t p)
{   
    if (p == 0)
    {
        return 1;
    }

    if (p == 1)
    {
        return n % MOD;
    }

    if ((p & 1) == 1)
    {
        p--;
        uint64_t N = pow(n, p / 2);
        N = N % MOD;
        N = (N * N) % MOD;
        return (n * N);
    }

    uint64_t N = pow(n, p / 2);
    N = N % MOD;
    N = (N * N) % MOD;
    return N;
}

int main()
{
    uint64_t n, p;

    fin >> n >> p;

    uint64_t result = pow(n, p);
    result = result % MOD;

    fout << result << '\n';

    return 0;
}