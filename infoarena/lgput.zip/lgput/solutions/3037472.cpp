#include <fstream>

using namespace std;

int putere(int a, int b, int c = 1999999973) {
    int rest = 0;
    int x = 1;
    if(b <= 2) {
        for(int i = 0; i < b; ++i) {
            x = x * a;
        }
        return x % c;
    }
    if(b % 2 == 0) {
        rest = putere(a, b/2, c) * putere(a, b/2, c);
        rest = rest % c;
    } else {
        rest = a * putere(a, b-1, c);
        rest = rest % c;
    }
    return rest;
}

int main() {
    int n, p;
    ifstream in("lgput.in");
    ofstream out("lgput.out");
    in >> n >> p;
    out << putere(n, p);
}