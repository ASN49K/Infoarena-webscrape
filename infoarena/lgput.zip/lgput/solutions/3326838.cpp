#include <iostream>
#include <cstdint>
#include <fstream>
uint64_t exponentiere(uint64_t x,uint64_t n){
	uint64_t txm=x;
	if (n==1){
		return txm;
	}
	if (n%2==0){
		txm=exponentiere(x,n/2)*exponentiere(x,n/2);
	} else {
		txm=x*exponentiere(x,n/2)*exponentiere(x,n/2);
	}
	return txm;
}


int main(){
	std::ifstream fin("lgput.in");
	std::ofstream fout("lgput.out");
	uint64_t a,b;
	fin>>a>>b;
	fout<<exponentiere(a,b)%1999999973;
	return 0;
}
