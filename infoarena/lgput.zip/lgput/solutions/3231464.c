#include <stdio.h>
#include <stdlib.h>

long long int exponentiereRapida(long long int x, long long int n) {
	long long int p = 1;
	while (n > 0) {
		if (n % 2 == 1) 
			p = p * x % 1999999973;
		x = x * x % 1999999973; // p^2	
		n = n / 2;
	}
	return p;
}int main() {	FILE* file = fopen("moka.in", "r");	FILE* file2 = fopen("moka.out", "w");	long long x, n;	fscanf(file,"%lld %lld", &x ,&n);	fprintf(file2,"%lld", exponentiereRapida(x, n));}