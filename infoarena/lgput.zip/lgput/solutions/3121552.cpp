#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const int MOD = 1999999973;

int main() {
	unsigned int n, p;
	fin >> n >> p;

	unsigned int pow = 1;
	while(p){
		if(p & 1)
			pow = (pow * n) % MOD;
		n = ((long long) n * n) % MOD;
		p >>= 1;
	}

	fout << pow << '\n';

	fin.close();
	fout.close();
	return 0;
}