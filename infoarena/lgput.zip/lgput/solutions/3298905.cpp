#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");


int functie_putere(int N,int P)
{
    int resultat=1;
    while(P!=0)
    {
        if (P%2!=0)
            resultat=(1LL*resultat*N)%1999999973;
        N=(1LL*N*N)%1999999973;
        P=P/2;

    }
    return resultat;
}

int main()
{
    int N,P,i,resultat=1;
    fin>>N>>P;
    fout<<functie_putere(N,P);
    fin.close();
    fout.close();
   return 0;
}
