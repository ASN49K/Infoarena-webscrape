#include<bits/stdc++.h>

using namespace std;

int main(){
	const int mod = 1999999973;
	long long int n, p;
	int j = 1;
	ifstream fin("lgput.in");
	ofstream fout("lgput.out");
	fin>>n>>p;
	while(p){ // 4
		if(p%2==1){
			j=(j*n)%mod;
		}
		n=(n*n)%mod; // 16
		p/=2; // 1
	}
	fout<<j;
}
