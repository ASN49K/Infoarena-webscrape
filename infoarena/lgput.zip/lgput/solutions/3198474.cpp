#include <fstream>

using namespace std;
int mod = 1999999973;
int exp(int x, int y)
{
    if(y == 0)
        return 1;
    if(y % 2 == 1)
        return x * exp(x, y - 1) % mod;
    else
    {
        int pow = exp(x, y / 2);
        return pow * pow % mod;
    }
}
int main()
{
    ifstream cin("lgput.in");
    ofstream cout("lgput.out");
    int n, p;
    cin >> n >> p;
    cout << exp(n, p);
    return 0;
}
