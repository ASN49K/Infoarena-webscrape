#include <fstream>
#include <vector>
#include <queue>
#include <iostream>
using namespace std;

int dx[] = {-1, 1, 0, 0};
int dy[] = {0, 0, 1, -1};

int n, m;
char v[1005][1005];
int d[1005][1005];

ifstream f("acces.in");
ofstream g("acces.out");



int main() {
    int xp, yp;
    f >> n >> m;
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j)  {
            f >> v[i][j];
            if (v[i][j] == '#')
                d[i][j] = -1;
            else
                if (v[i][j] == 'P')
                    d[i][j] = 1, xp = i, yp = j;
        }
    }
    for (int i = 0; i <= n; ++i)
        d[i][0] = d[i][m + 1] = -1;
    for (int j = 0; j <= m; ++j)
        d[0][j] = d[n + 1][j] = -1;

    queue <pair <int, int>> q;
    q.push({xp, yp});

    d[xp][yp] = 1;

    while (!q.empty()) {
        pair <int, int> p = q.front();
        q.pop();
        for (int dir = 0; dir < 4; ++dir) {
            int newx = p.first + dx[dir];
            int newy = p.second + dy[dir];

            if (d[newx][newy] == 0) {
                d[newx][newy] = d[p.first][p.second] + 1;
                q.push({newx, newy});
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= m; ++j) {
            if (d[i][j] != -1)
                d[i][j] -= 1;
            g << d[i][j] << ' ';
        }
        g << '\n';
    }
    return 0;
}
