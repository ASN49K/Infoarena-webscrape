#include <iostream>
#include <fstream>
#include <stdint.h>

const int64_t MOD = 1999999973;

int64_t Pow(int64_t val, int64_t exp) {
	int64_t res = 1;
	for(; exp; exp >>= 1) {
		if(exp & 1)
			res = (res * val) % MOD;
		val = (val * val) % MOD;
	}
	return res;
}

int main() {
	std::ifstream fin("lgput.in");
	std::ofstream fout("lgput.out");

	int64_t n, p;
	fin >> n >> p;
	fout << Pow(n, p);

	fin.close();
	fout.close();

	return 0;
}