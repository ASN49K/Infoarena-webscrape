#include <fstream>
#include <queue>
#include <iostream>
#include <bitset>
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");
const long long mod = 1999999973;
long long lgput(int a, int b)
{
    long long p = 1;
    while (b)
    {
        if (b % 2 == 1)
            p = p * a % mod;
        a = a * a % mod;
        b /= 2;
    }
    return p;
}
int main()
{
    long long a, b;
    fin >> a >> b;
    long long x = lgput(a, b);
    fout << x;
    return 0;
}
