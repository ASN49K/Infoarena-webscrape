#include <bits/stdc++.h>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long MOD=1999999973;

int main()
{
    long long n, p;
    fin >> n >> p;
    long long sol=1;
    while(p>0) {
        if(p%2!=0) {
            sol=(sol*n)%MOD;
            p--;
        } else {
            n=(n*n)%MOD;
            p=p/2;
        }
    }
    fout << sol;
    return 0;
}
