#include <bits/stdc++.h>
using namespace std;
#define ll long long

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    ifstream fin("lgput.in");
    ofstream fout("lgput.out");

const int n_max = 10001;
const int m = 1999999973;

	unsigned int i, n, p;
	long long a, sol = 1;

	fin>>n>>p;
	a = n;
	for (i = 0; (1<<i) <= p; ++ i)
	{
		if ( ((1<<i) & p) > 0)
			sol= (sol * a) % m;

			a=(a * a) % m;
	}
	fout<<sol;
}
