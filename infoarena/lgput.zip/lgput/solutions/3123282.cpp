#include <iostream>
#include <cstdio>
using namespace std;
const int MOD = 1999999973;

long long N, P;

int main() {
    freopen("lgput.in", "r", stdin);
    freopen("lgput.out", "w", stdout);

    cin >> N >> P;
    long long result = 1;
    while (P) {
        if (P & 1) {
            result = (result * N) % MOD;
        }
        N = (N * N) % MOD;
        P >>= 1;
    }
    cout << result << "\n";
    return 0;
}