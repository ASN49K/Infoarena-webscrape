#include <iostream>
#include <fstream>


unsigned long long hatvany(unsigned long long a, unsigned long long b){
	unsigned long long szam;
	if(b == 2){
		return a*a;
	}else if(b % 2 == 0){
		szam = hatvany(a, b/2) * hatvany(a, b/2) % 1999999973;
	}else{
		szam = hatvany(a, b/2 + 1) * hatvany(a, b/2) % 1999999973;
	}
	return szam;
}

int main(){
	unsigned long long n, p;
	std::ifstream bem("lgput.in");
	std::ofstream kim("lgput.out");

	bem >> n >> p;
	kim << hatvany(n, p) << "\n";
	bem.close();
	kim.close();
}
