#include <fstream>
#define ull unsigned long long

using namespace std;

ifstream in;
ofstream out;

ull mod = 1999999973;

ull pow(ull n, ull p)
{
    if (p == 1)
        return n;
    if (p == 2)
        return (n*n)%mod;
    if (p % 2)
    {
        return (pow(pow(n, p/2),2)*n)%mod;
    }
    else
    {
        return pow(pow(n, p/2),2)%mod;
    }
}

int main()
{
    in.open("lgput.in");
    out.open("lgput.out");
    ull n, p;
    in >> n >> p;
    out << pow(n, p);
    return 0;
}
