#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
const long long int MOD = 1999999973;
unsigned long long int n, k, p = 1;

int main()
{
    fin >> n >> k;
    while(k != 0) {
        if(k % 2 == 1) p *= n, p %= MOD;
        n *= n, n %= MOD;
        k /= 2;
    }
    fout << p;

    return 0;
}
