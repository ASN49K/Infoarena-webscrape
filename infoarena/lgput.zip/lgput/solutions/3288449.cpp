#include <bits/stdc++.h>

using namespace std;

long long MOD = 1999999973;

long long exp (long long a, long long b) {
    if (b == 0) {
        return 1;
    }
    if (b % 2 == 0) {
        return exp ((a * a) % MOD, b / 2);
    }
    return a * exp (a, b - 1) % MOD;
}

int main()
{
    freopen ("lgput.in", "r", stdin);
    freopen ("lgput.out", "w", stdout);
    long long n, p;
    cin >> n >> p;
    cout << exp (n, p);
    return 0;
}