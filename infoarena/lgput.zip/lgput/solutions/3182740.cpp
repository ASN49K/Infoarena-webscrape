#include <iostream>
#include <fstream>

using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
long long n,m;
const long long mod=1999993733;
long long lgput(int base, int pow)
{
    if(pow==1)
    {
        return base%mod;
    }
    if (pow%2==0)
    {
        long long val=lgput(base,pow/2);
        return (val*val)%mod;

    }
    return (lgput(base,pow-1)*base)%mod;

}
int main()
{
    long long n,m;
    fin>>n>>m;
    fout<<lgput(n,m);
}
