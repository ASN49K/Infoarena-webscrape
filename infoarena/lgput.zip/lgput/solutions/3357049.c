#include <stdio.h>

float explog(float x, int n) {
  if (n < 0)
    return explog(1 / x, -1 * n);
  else if (n == 0)
    return 1;
  else if (n % 2 == 0)
    return explog(x * x, n / 2);
  else
    return x * explog(x * x, (n - 1) / 2);
}

int main(void) {
  
  FILE *in = fopen("lgput.in", "r");
  FILE *out = fopen("lgput.out", "w");
  float x;
  int n;
  fscanf(in, "%f", &x);
  fscanf(in, "%d", &n);

  fprintf(out,"%f", explog(x, n));
  return 0;
}
