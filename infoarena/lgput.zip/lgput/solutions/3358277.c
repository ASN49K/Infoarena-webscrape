#include <stdlib.h>
#include <stdio.h>

#define MOD 1999999973

long long exp_by_squaring(long long base, long long exp){
    long long result = 1;
    base = base % MOD;

    while(exp > 0){
        if(exp % 2 == 1){
            result = ( result * base ) % MOD;
        }

        base = (base * base) % MOD;
        exp /= 2;
    }
    return result;
}

int main(){
    int N, P;
    FILE* fin = fopen("lgput.in", "r");
    FILE* fout = fopen("lgput.out", "w");

    if (fscanf(fin, "%d %d", &N, &P) == 2) {
    
        long long ans = exp_by_squaring(N, P);
        fprintf(fout, "%lld\n" , ans);
        
    }


    fclose(fin);
    fclose(fout);



    
    
}