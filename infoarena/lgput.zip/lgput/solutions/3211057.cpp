#include <iostream>
using namespace std;

int putere(int x, int y)
{
    if (y == 0) return 1;
    else return x * putere(x, y - 1);
}

int lgput(int x, int n)
{
    if (n == 0) return 1;
    if (n % 2 == 1) return x * putere(putere(x, 2), (n - 1) / 2);
    else return putere(putere(x, 2), n / 2);
}

int main()
{
    cout << lgput(2, 4);
    return 0;
}
