#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const int MOD = 1999999973;

long long pwr(unsigned int a, unsigned int b)
{
    int p = 1;
    while(b > 0)
    {
        if(b % 2 == 0)
            p = 1LL * p * a % MOD;
        a = 1LL * a * a % MOD;
        b /= 2;
    }
    return p;
}

int main()
{
    unsigned int n, p;
    long long sol;
    fin >> n >> p;
    n %= MOD;
    sol = pwr(n, p);
    fout << sol;
    return 0;
}
