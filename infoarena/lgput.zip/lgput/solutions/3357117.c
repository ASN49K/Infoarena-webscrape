#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    FILE *file = fopen("lgput.in", "r");
    if (file == NULL) {
        fprintf(stderr, "Error opening file.\n");
        return 1;
    }
    FILE *output = fopen("lgput.out", "w");
    if (output == NULL) {
        fprintf(stderr, "Error opening output file.\n");
        fclose(file);
        return 1;
    }
    int n, a, p;
    fscanf(file, "%d %d", &n, &p);
    a = n;
    for(int i=1; i<p;i++)
    {
        a=a*n;
    }
    printf("%d\n", a);
    int rezultat=a%1999999973;
    fprintf(output, "%d\n", rezultat);
    fclose(file);
    fclose(output);
    return 0;
}