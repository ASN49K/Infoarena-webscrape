#include <fstream>
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
const long long mod=1999999973;
long long put(int n,int k){
    long long rasp=1;
    while(k){
        if(k%2){
            rasp=((rasp%mod)*(n%mod))%mod;
        }
        n=(n*n)%(mod);
        k/=2;
    }
    return rasp;
}
int main(){
    long long n,k;
    cin>>n>>k;
    long long rasp=put(n,k);
    cout<<rasp;
}