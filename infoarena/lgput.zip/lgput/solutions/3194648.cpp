#include <iostream>
#include <fstream>

using namespace std;

int main()
{

    ifstream in("lgput.in");
    ofstream out("lgput.out");

    int mod = 1999999973;
    long long n, p;
    int i = 1;
    cin >> n >> p;

    while (p > 0)
    {
        if (p % 2 == 0)
        {
            n = (n * n) % mod;
            p /= 2;
        }
        else
        {
            i = i * n % mod;
            p--;
        }
    }

    cout << i;

    return 0;
}