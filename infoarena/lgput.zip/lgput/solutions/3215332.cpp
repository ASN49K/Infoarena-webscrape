#include <fstream>
#define mod 1999999973
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");

long long exp(long long x, long long y)
{
    if(y==0)
        return 1;
    if(y==1)
        return x%mod;
    long long ans=exp(x,y/2)%mod;
    if(y%2==0)
        return (ans%mod*ans%mod)%mod;
    else
        return (ans%mod*ans%mod*x%mod)%mod;
}

int main()
{
    long long a,b;
    cin>>a>>b;
    cout<<exp(a,b)%mod;
}
