#include <iostream>
#include <bits/stdc++.h>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const int MOD=1999999973;
int put(int a, int b){
  if(b==0){
      return 1;
  }
  int s=put(a,b/2);
   if(b%2==1){
    return (s*s*a)%MOD;

       
   }
    else{
        return (s*s)%MOD;
    }

    
}


int main(){
   int n, p;
    fin>>n>>p;
    fout<<put(n,p);
}