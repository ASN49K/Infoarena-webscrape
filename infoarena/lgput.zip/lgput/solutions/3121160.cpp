#include <fstream>

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

long long alab(int a, int b)
{
    if(b == 0)return 1;
        int pow = alab(a,b/2);
    if(b % 2 == 0){
        return pow * pow;
    }
    else return pow * pow * a;
}

int main()
{
    long long a,b;
    cin>>a>>b;
    cout<<alab(a,b)%1999999973;
    return 0;
}
