#include <fstream>
#define MOD 1999999973
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");

int lgput(long long n, long long p)
{
    int r=1;
    while(p)
    {
        if(p%2)
            r=(1ll*r*n)%MOD;
        n=(1ll*n*n)%MOD;
        p/=2;
    }
    return r;
}
int main()
{
    long long n, p;
    fin>>n>>p;
    fout<<lgput(n, p);
    return 0;
}
