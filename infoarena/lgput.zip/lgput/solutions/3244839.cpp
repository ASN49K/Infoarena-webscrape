#include <bits/stdc++.h>

using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
long long Expolog(long long a,long long n,int mod)
{
    long long p=1;
    while(n>0)
    {
        if(n%2==1)p=p*a%mod;
        a=a*a%mod;
        n/=2;
    }
    return p;
}
int main()
{
    long long a,n;
    fin>>a>>n;
    fout<<Expolog(a,n,1999999973);
    return 0;
}

