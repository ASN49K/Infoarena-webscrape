#include <bits/stdc++.h>

using namespace std;

int lgput (int a, int b) {
    int rez = 1;
    while (b) {
        if (b % 2 == 1) {
            rez = rez * a % 1999999973;
        }
            a *= a;
            b /= 2;
    }

    return rez;
}


int main() {
    ifstream cin("lgput.in");
    ofstream cout("lgput.out");
    int a, b;
    cin >> a >> b;
    cout << lgput(a, b);
    return 0;
}
