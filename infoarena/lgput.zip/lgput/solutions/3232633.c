#include <stdio.h>
#include <stdlib.h>

#define MOD 1999999973
#define FILE_IN "lgput.in"
#define FILE_OUT "lgput.out"

int exponentiate(int x, int n) {
    if(n == 0) return 1;
    if(n < 0) {
        x = 1 / x;
        n = -n;
    }
    int y = 1;
    while(n > 1) {
        if(n % 2) {
            y = y * x;
            n--;
        }
        x = x * x;
        n = n / 2;
    }

    return y * x;
}

int main()
{
    FILE *fileIn = fopen(FILE_IN, "r"),
         *fileOut = fopen(FILE_OUT, "w");
    int n, p;

    fscanf(fileIn, "%d%d", &n, &p);

    int result = exponentiate(n, p);
    fprintf(fileOut, "%d\n", result);

    fclose(fileIn);
    fclose(fileOut);

    return 0;
}
