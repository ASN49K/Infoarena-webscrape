#include <stdio.h>
#include <stdint.h>

#define MOD 1999999973ULL
// Dandu-se doua numere naturale N si P, se cere sa se calculeze restul impartirii lui NP la 1999999973.
uint64_t exp_by_sqr(uint64_t x, uint64_t n)
{
    if (n == 0)
        return 1;

    if (n % 2 == 0)
    {
        uint64_t t = exp_by_sqr(x, n / 2);
        return (t * t) % MOD;
    }

    uint64_t t = exp_by_sqr(x, n / 2);
    return (((t * t) % MOD) * x) % MOD;
}

int main()
{
    FILE *input = fopen("lgput.in", "r");
    FILE *output = fopen("lgput.out", "w");

    uint64_t n, p;

    fscanf(input, "%llu %llu", &n, &p);

    fprintf(output, "%llu", exp_by_sqr(n % MOD, p));

    fclose(input);
    fclose(output);

    return 0;
}