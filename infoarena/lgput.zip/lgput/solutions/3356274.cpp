#include <iostream>
#include <fstream>
#include <cstdint>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

unsigned long long exponent_log(int n, int p){
    if(p == 0){
        return 1;
    }
    if(p % 2 == 0){
        return (exponent_log(n * n, p / 2)) % 1999999973;
    }
    if(p % 2 == 1){
        return n * (exponent_log(n * n, p / 2)) % 1999999973;
    }
    return 0;
}

int main (){
    int n, p;
    unsigned long long r = 1;
    fin >> n >> p;
    r = exponent_log(n, p);
    fout << r;
    fin.close();
    fout.close();
    return 0;
}