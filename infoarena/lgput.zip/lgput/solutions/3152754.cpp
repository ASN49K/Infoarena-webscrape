#include <fstream>

using namespace std;

ifstream in("lgput.in");
ofstream out("lgput.out");

long long mod=1999999973;

int main()
{
    long long n,p,rez;
    in>>n>>p;
    rez=1;
    while (p!=0)
    {
        if (p%2==1)
        {
            rez=(rez*n)%mod;
        }
        n=((n*n)%mod;
        p=p/2;
    }
    out<<rez;
    return 0;
}
