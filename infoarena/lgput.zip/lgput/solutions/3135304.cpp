#include <bits/stdc++.h>

using namespace std;

const int nr = 1999999973;

long long lgcalc(long long x, long long n)
{
    if (n == 0)
        return 1;
    if (n % 2 == 0)
        return lgcalc(x * x % nr, n / 2) % nr;

    else
        return (x * lgcalc(x * x % nr, n / 2)) % nr;
}

int main()
{
    ifstream fin("lgput.in");
    ofstream fout("lgput.out");
    long long N, P;
    fin >> N >> P;
    long long rz = lgcalc(N, P);
    fout << rz;
    return 0;
}