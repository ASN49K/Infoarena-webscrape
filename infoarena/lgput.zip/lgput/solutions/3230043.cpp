#include <fstream>

using namespace std;

const int MOD=1999999973;
ifstream f("lgput.in");
ofstream g("lgput.out");

int putere(int n,int p)
{
    int r=1;
    while(p)
    {
        if(p%2==1)
        r=(1LL*r*n)%MOD;
        n=(1LL*n*n)%MOD;
        p/=2;
    }
    return r;
}
int main()
{
    int N,P;
    f>>N>>P;
    g<<putere(N,P);
    f.close();
    g.close();
    return 0;
}
