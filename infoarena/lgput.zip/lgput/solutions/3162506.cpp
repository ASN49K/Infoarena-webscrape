#include <iostream>
#include <fstream>
#define MOD 1999999973
#define int unsigned long long

using namespace std;

int lgput(int n, int p)
{
    int nr = 1;
    while(p > 0)
    {
        if(p % 2 == 1)
        {
            nr = nr * n % MOD;
        }
        p = p / 2;
        n = n * n % MOD;
    }
    return nr;
}

signed main()
{
    ifstream cin("lgput.in");
    ofstream cout("lgput.out");
    int n, p;
    cin >> n >> p;
    cout << lgput(n, p);
    return 0;
}
