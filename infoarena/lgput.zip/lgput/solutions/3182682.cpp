#include <bits/stdc++.h>
#define mod 1999999973
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
inline int exp(int b, int e){
    int p = b,rez = 1;
    while(e){
        if(e & 1) rez = (1LL * rez * p) % mod;
        e >>= 1;
        p = (1LL * p * p) % mod;
    }
    return rez;
}
int main()
{
    int n,p;
    fin >> n >> p;
    fout << exp(n,p);
    return 0;
}
