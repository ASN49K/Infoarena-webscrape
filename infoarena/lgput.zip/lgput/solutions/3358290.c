#include<stdio.h>
#include<stdlib.h>

#define MOD 1999999973

long long putere(long long n, long long p)
{
    if(p==0)
        return 0;
    if(p==1)
        return n;
    if(p%2==0)
        return putere(n*n,p/2);
    else 
        return n*putere(n*n,p/2);
}

int main(void)
{
    FILE* f,*g;
    long long N,P,nr;
    if((f=fopen("lgput.in","r"))==NULL)
    {
        printf("fisierul de intrare nu a putut fi deschis\n");
        exit(EXIT_FAILURE);
    }
    if((g=fopen("lgput.out","w"))==NULL)
    {
        printf("fisierul de iesire nu a putut fi deschis\n");
        exit(EXIT_FAILURE);
    }
    if(fscanf(f,"%lld %lld",&N,&P)!=2)
    {
        printf("citire din fisier nereusita\n");
        exit(EXIT_FAILURE);
    }
    nr=putere(N,P);
    fprintf(g,"%lld\n",nr%MOD);
    if(fclose(f)<0)
    {
        printf("fisierul de intrare nu a putut fi inchis\n");
        exit(EXIT_FAILURE);
    }
    if(fclose(g)<0)
    {
        printf("fisierul de iesire nu a putut fi inchis\n");
        exit(EXIT_FAILURE);
    }
    return 0;
}