#include <iostream>
#include <fstream>
using namespace std;
int lgput(int x, int n)
{
    if (n == 0) return 1;
    if (n % 2 == 0) 
    {
        return x * lgput(x,((n-1)/2)) * lgput(x,((n-1)/2));
    }
    else
    {
        return lgput(x,((n)/2)) * lgput(x,((n)/2));
    }
    
}
ifstream fin("lgput.in");
ofstream fout("lgput.out");
int main() 
{
    int x, y;
    fin >> x >> y;
    fout << lgput(x,y);
    return 0;
}
