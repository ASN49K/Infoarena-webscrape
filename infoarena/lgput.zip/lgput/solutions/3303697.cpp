/*
https://infoarena.ro/problema/lgput
*/
#include <fstream>

using namespace std;

const int MOD = 1999999973;

int main()
{
    ifstream in("lgput.in");
    ofstream out("lgput.out");
    int a, n;
    in >> a >> n;
    int p = 1;
    do
    {
        int cif = n % 2;
        if (cif == 1)
        {
            p = ((long long)p * a) % MOD;
        }
        a = ((long long)a * a) % MOD;
        n /= 2;
    }
    while (n != 0);
    out << p << endl;
    in.close();
    out.close();
    return 0;
}
