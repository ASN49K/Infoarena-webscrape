#include <fstream>

using namespace std;

ifstream f("lgput.in");
ofstream g("lgput.out");

long long put2(int x, int n)
{
    long long val=1,a=x;
    while(n>0)
    {
        if(n%2!=0)
            val*=a;
        a*=a;
        n/=2;
    }
    return val;
}

int main()
{
    int a,b;
    f>>a>>b;
    g<<put2(a,b)%1999999973;
    f.close();
    g.close();
    return 0;
}
