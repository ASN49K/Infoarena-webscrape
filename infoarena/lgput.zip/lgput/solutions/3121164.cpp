#include <fstream>

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

long long alab(long long a, long long b)
{
    if(b == 0)return 1;
    else if(b == 1)return a;
        long long pow = alab(a,b/2);
    if(b % 2 == 0){
        return pow * pow % 1999999973;
    }
    else return pow * pow % 1999999973 * a % 1999999973;
}

int main()
{
    long long a,b;
    cin>>a>>b;
    cout<<alab(a,b);
    return 0;
}
