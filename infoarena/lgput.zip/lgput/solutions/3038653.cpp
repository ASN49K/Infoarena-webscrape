#include <fstream>

using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
int main()
{
    int n,m;
    cin>>n>>m;
    long long nr=1,exp=n;
    while(m>0)
    {
        if(m%2==1)
        {
            nr*=exp%1999999973;
            nr%=1999999973;
        }
        exp*=exp%1999999973;
        exp%=1999999973;
        m/=2;
    }
    cout<<nr;
    return 0;
}
