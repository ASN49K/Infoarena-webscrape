#include <stdio.h>
#include <stdlib.h>

int exponent(int N, int P)
{
  if(P == 0){
    return 1;
  }
  else if(P % 2 == 0){
    return exp(N * N, P / 2);
  }
  else if(P % 2 != 0){
    return N * exp(N * N, (P - 1) / 2);
  }
  return 1;
}

int main(void)
{
  FILE *input = fopen("igput.in", "r");
  FILE *output = fopen("igput.out", "w");
  int N, P;
  fscanf(input, "%d", &N);
  fscanf(input, "%d", &P);
  fprintf(output, "%d", exponent(N, P));
  fclose(input);
  fclose(output);
  return 0;
}
