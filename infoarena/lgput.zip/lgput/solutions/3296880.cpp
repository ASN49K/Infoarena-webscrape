#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("nr.in");
ofstream fout("nr.out");

long long fastExponentiation(long long n,long long p) {
    if (p==0) return 1;
    if (p%2==0) {
        return fastExponentiation(n*n,p/2);
    }
    if (p%2==1) {
        return n*fastExponentiation(n*n,(p-1)/2);
    }
}

int main() {

    long long N,P;
    fin>>N>>P;
    fout<<fastExponentiation(N,P);

    fin.close();
    fout.close();
    return 0;
}