﻿#include <bits/stdc++.h>
#include <unordered_map>
#define nmax 100005
#define MOD 1999999973
#define INF 2012345678
#define ll long long
using namespace std;
//#define fin cin
//#define fout cout

ifstream fin("lgput.in");
ofstream fout("lgput.out");

int n, m;

int PowLog(int x, int expo)
{
    if (expo == 0)
        return 1;
    if (expo % 2 != 0)
        return 1ll * x * PowLog(x, expo - 1) % MOD;
    int P = PowLog(x, expo / 2);
    return 1ll * P * P % MOD;
}

int main()
{
    int i;
    fin >> n >> m;
    fout << PowLog(n, m) << "\n";
    fin.close();
    fout.close();
    return 0;
}