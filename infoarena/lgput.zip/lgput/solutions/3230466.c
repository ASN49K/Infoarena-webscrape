#include <stdio.h>
#include <stdlib.h>

#define modulus 1999999973

unsigned long long exponent(unsigned long long N,unsigned long long P)
{
  unsigned long long rez = 1;
  unsigned long mask = 1;
  for(;mask <= P;mask <<= 1){
    if((mask & P) > 0){
      rez = (rez * N) % modulus;
    }
    N = N * N % modulus;
  }
  return rez;
}

int main(void)
{
  FILE *input = fopen("lgput.in", "r");
  FILE *output = fopen("lgput.out", "w");
  unsigned long long N, P;
  fscanf(input, "%lld", &N);
  fscanf(input, "%lld", &P);
  fprintf(output, "%lld", exponent(N, P));
  fclose(input);
  fclose(output);
  return 0;
}

