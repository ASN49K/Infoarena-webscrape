#include <iostream>
#include <fstream>
using namespace std;
ifstream f("lgput.in");
ofstream g("lgput.out");
long long po(long long n, long long p)
{long long x=1,x2=n*n;
 if(p%2)    //n*(n^2)^((p-1)/2)
 {  for(int i=0;i<(p-1)/2;i++)
     x*=x2;
    x*=n;
 }
 else   {for(int i=0;i<p/2;i++)
            x*=x2;
        }
 return x;
}
int main()
{
    long long n,p;
    f>>n>>p;
    cout<<po(2,4);
    g<<po(n,p)%1999999973;
    return 0;
}
