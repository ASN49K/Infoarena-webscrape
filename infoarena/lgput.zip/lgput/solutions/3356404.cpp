#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

#define NUM 1999999973

long long logpwmod(int n, int p)
{
    if (p == 0) return 1;

    long long aux = logpwmod(n, p / 2);
    aux = (aux * aux) % NUM;

    if (p % 2 == 1) aux = (aux * (n % NUM)) % NUM;

    return aux;
}

int main(void)
{
    unsigned int n, p;
    
    fin >> n >> p;
    fout << logpwmod(n, p) << endl;

    fin.close();
    fout.close();

    return 0;
}