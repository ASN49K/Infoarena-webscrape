#include <fstream>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
long long int putere(long long int a,long long int n,long long int p){
    if(p==1){
        return n;
    }else if(p%2==0){
        return putere(a,n*n%1999999973,p/2);
    }else{
        return putere(a,n*a%1999999973,p-1);
    }
}
int main(){
    long long int n,p;
    fin>>n;
    fin>>p;
    fout<<putere(n,n,p);
}