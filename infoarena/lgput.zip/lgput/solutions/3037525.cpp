#include <fstream>
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
long long i, j, n, m, lg, e, x, y, nr, p;
long long f(long long n, long long p){
    if(p==0){
        return 1;
    }
    if(p%2){
        long long nr=f(n, p/2);
        nr%=1999999973;
        return ((nr*nr)%1999999973*n)%1999999973;
    }
    else{
        nr=f(n, p/2);
        nr%=1999999973;
        return (nr*nr)%1999999973;
    }
}
int main(){
    cin>>n>>p;
    cout<<f(n, p);
}
