#include <bits/stdc++.h>
using namespace std;

#define MOD 1999999973

ifstream in("lgput.in");
ofstream out("lgput.out");
typedef long long ll;
ll exp_log(ll x, int n)
{
    if(n == 0) return 1;
    if(n%2) return x*exp_log(x*x%MOD, n/2)%MOD;
    return exp_log(x*x%MOD, n/2)%MOD;
}

int main()
{
    ll n, p;
    in >> n >> p;
    out << exp_log(n, p);
    return 0;
}
