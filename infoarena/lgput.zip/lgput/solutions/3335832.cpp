#include<fstream>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
long long n, p, prod, c;
int main()
{
    prod=1;
    fin>>n>>p;
    while(n!=0){
        c=n%2;
        if(c==1)
        {
            prod=prod*n;
        }
        n=n/2;
        n=n*n;
    }
    fout<<prod;
    return 0;
}
