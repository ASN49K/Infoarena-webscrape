#include <bits/stdc++.h>

using namespace std;

ifstream fin ("lgput.in");
ofstream fout ("lgput.out");

long long a,b;
long long m=1999999973;
long long putere(long long a,long long b)
{
    if (b==0)
        return 1;
    if (b==1)
        return a;
    long long x=putere(a,b/2);
    if (b%2==0)
        return (x*x)%m;
    else
        return (((x*x)%m)*a)%m;
}
int main()
{
    fin >> a >> b;
    fout << putere(a,b);
    return 0;
}
