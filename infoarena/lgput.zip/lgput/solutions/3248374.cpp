#include <fstream>

using namespace std;


ifstream cin ("lgput.in");
ofstream cout ("lgput.out");

int main()
{
    long long a,b , rez = 1, modul = 1999999973;
    cin >> a >> b;
    while(b>0)
    {
        if(b%2==1)
        {
            rez = (a * rez) % modul;
        }
        a = (a * a) % modul;
        b/=2;
    }
    cout << rez;

}
