//https://www.infoarena.ro/problema/lgput

//#pragma GCC optimize ("Ofast")
//#pragma GCC optimize ("fast-math")
//#pragma GCC optimize ("unroll-loops")
//#define _USE_MATH_DEFINES

//#include <iostream>
#include <fstream>
//#include <vector>
//#include <cstring>
//#include <cmath>
//#include <bitset>
//#include <queue>
//#include <stack>
//#include <utility>
//#include <algorithm>
//#include <string>
//#include <map>
//#include <unordered_map>
//#include <set>
//#include <unordered_set>
//#include <cstdint>
//#include <climits>
//#include <iomanip>
//#include <cstdio>
//#include <tuple>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const int MOD = 1999999973;

int64_t power_of_manyyy(int64_t b, int64_t e, int64_t modulo)
{
    int64_t rez = 1;

    while (e)
    {
        if (e & 1)
            rez *= b;

        b = b * b;
        e >>= 1;
    }

    return rez;
}

int main()
{
    int64_t n, p;

    fin >> n >> p;

    fout << power_of_manyyy(n, p, MOD);

    return 0;
}
