#include <bits/stdc++.h>

using namespace std;

int f(int x, int n) {

if(n==0) return 1;
int m=n/2;
if(n%2==0) return f(x, m)*f(x, m);
return x*f(x, n-1);
}


int main()
{
    int x, n;
    cin>>x>>n;
    cout<<f(x, n);
    return 0;
}
