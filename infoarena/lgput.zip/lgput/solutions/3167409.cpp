#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout ("lgput.out");

void lgput(const unsigned long long a,unsigned long long n,unsigned long long p){
    unsigned long long b=1;
    while(p>0){
        if(p%2==1){
            b*=n%a;
            p--;
        }
        else{
            p=p/2;
            n=n*n%a;
        }
    }
    fout<<b;
}
int main()
{   
    const unsigned long long a=1999999973;
    unsigned long long n,p;
    fin>>n>>p;
    lgput(a,n,p);
    return 0;
}
