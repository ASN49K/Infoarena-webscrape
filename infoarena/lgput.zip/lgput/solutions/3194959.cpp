#include <iostream>
#include <fstream>
using namespace std;
ifstream f("lgput.in");
ofstream g("lgput.out");
long long putrec(long long a,long long b)
{
    if(b==0) return 1;
    if(b==1)return a;
    if(b%2==0)
        return ((putrec(a,b/2)%1999999973)*(putrec(a,b/2)%1999999973))%1999999973;
    else return ((a%1999999973)*(putrec(a,b-1)%1999999973))%1999999973;
}
int main()
{
   long long a,b;
   cin>>a>>b;
   cout<<putrec(a,b);
    return 0;
}
