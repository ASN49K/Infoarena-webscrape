#include <stdio.h>
#define Mod 1999999973
float exp_log_rec(float x, int n)
{
    if (n < 0)
    {
        return exp_log_rec(1 / x, (-1) * n);
    }
    if (n == 0)
        return 1;
    if (n % 2 == 0)
        return exp_log_rec(x * x, n / 2);
    if (n % 2 == 0)
        return exp_log_rec(x * x, n / 2);
}
int main()
{
    FILE *fin;
    FILE *fout;
    int n, p;
    long long int res = 0;
    if ((fin = fopen("lgput.txt", "r")) == NULL)
    {
        printf("Eroare deschidere fisier");
    }
    if ((fout = fopen("lgout.txt", "w")) == NULL)
    {
        printf("Eroare deschidere fisier");
    }
    fscanf(fin, "%u", &n);
    fscanf(fin, "%d", &p);
    res=exp_log_rec(n,p);
    fprintf(fout,"%lld",res  % 1999999973);
    return 0;
}