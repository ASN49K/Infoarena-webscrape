#include <bits/stdc++.h>
using namespace std;

ifstream fin("Igput.in");
ofstream fout("Igput.out");

int put(int n, int m) {
    if(m == 0) return 1;
    if(m % 2 == 1) return n * put(n, m - 1);
    int p = put(n, m / 2);
    return p * p;
}

int main()
{
    int n, m;
    fin >> n >> m;
    long long rez = put(n, m);
    fout << rez;
}