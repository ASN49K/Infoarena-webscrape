#include <stdio.h>
#define M 1999999973

FILE *fin = NULL, *fout = NULL;
long long n , p, rez = 1;

long long ridic(long long n, long long p)
{
    while (p)
    {
        if (p % 2 == 1)
        {
            p--;
            rez = (rez * n) % M;
        }
        n = (n * n) % M;
        p /= 2;
    }
    return rez % M;
}

int main()
{
    fin = fopen("lgput.in","r");
    fout = fopen("lgput.out","w");
    fscanf(fin,"%lld %lld",&n,&p);
    fprintf(fout,"%lld",ridic(n,p));
    fclose(fin);
    fclose(fout);
    return 0;
}