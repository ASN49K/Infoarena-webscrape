#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const int MOD = 1999999973;

long long pwr(long long a, long long p)
{
	long long val = 1;
	a %= MOD;
	while (p > 0) {
		if (p & 1)
			val = val * a % MOD;
		a = a * a % MOD;
		p >>= 1;
	}
	return val;
}

int main() {
	long long N, P;
	fin >> N >> P;
	fout << pwr(N, P);
	
    fin.close();
    fout.close();
    return 0;
}
