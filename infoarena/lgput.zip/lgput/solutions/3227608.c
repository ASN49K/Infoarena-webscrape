#include <stdio.h>
#include <stdlib.h>

long long Ridicare_la_putere_in_timp_logaritmic(FILE *fis,FILE *gis)
{
    int n=0,p=0,i=0;
    long long a=1,sol=1;
    const int m=1999999973;
    fscanf(fis,"%d",&n);
    fscanf(fis,"%d",&p);
    a=n;
    for(i=0;(1<<i)<=p;i++)
    {
        if(((1<<i)&p)!=0)
        {
            sol=(sol*a)%m;
        }
        a=(a*a)%m;
    }
    return sol;
}
int main(void)
{   
    FILE *fis=NULL,*gis=NULL;
    fis=fopen("lgput.in","r");
    if(fis==NULL)
    {
        perror("eroare\n");
        exit(-1);
    }
    gis=fopen("lgput.out","w");
    if(gis==NULL)
    {
        perror("eroare\n");
        exit(-1);
    }
    fprintf(gis,"%lld\n",Ridicare_la_putere_in_timp_logaritmic(fis,gis));
    fclose(fis);
    fclose(gis);
    return 0;
}