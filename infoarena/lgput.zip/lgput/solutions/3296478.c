#include <stdio.h>
#include <stdlib.h>

long putere(int n, int p)
{
	if(p == 1)
		return n;
	else
		return n*putere(n,p-1);
}

int main(void)
{
	FILE *f, *out;

	if((f = fopen("lgput.in","r")) == NULL)
	{
		perror(NULL);
		exit(-1);
	}

	if((out = fopen("lgput.out","w")) == NULL)
	{
		perror(NULL);
		exit(-1);
	}

	int n, p;
	fscanf(f,"%d %d",&n, &p);
	fprintf(out, "%ld", putere(n,p));

	if(fclose(f) != 0)
	{
		perror(NULL);
		exit(-1);
	}

	if(fclose(out) != 0)
	{
		perror(NULL);
		exit(-1);
	}
	return 0;
}