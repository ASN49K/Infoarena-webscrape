#include <iostream>

using namespace std;
int exp(long long int a, long long int p)
{
    long long int rez=1;
    while(p)
    {
        if(p%2==1)
            rez=rez*a;
        a=a*a;
        p/=2;
    }
    return rez;
}
int main()
{
    long long int a,p;
    cin>>a>>p;
    cout<<exp(a,p);
    return 0;
}
