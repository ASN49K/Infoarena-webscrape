#include <stdio.h>
#include <stdlib.h>

#define MOD 1999999973

int main()
{
    FILE *fin, *fout;
    long long num_n, num_p, rez;

    fin = fopen( "lgput.in", "r" );
    fscanf( fin, "%lld%lld", &num_n, &num_p );
    fclose( fin );

    rez = 1;
    while ( num_p > 0 ) {
      if ( num_p % 2 == 1 )
        rez = rez * num_n % MOD;
      num_n = num_n * num_n % MOD;
      num_p = num_p / 2;
    }

    fout = fopen( "lgput.out", "w" );
    fprintf( fout, "%lld\n", rez );
    fclose( fout );
    return 0;
}
