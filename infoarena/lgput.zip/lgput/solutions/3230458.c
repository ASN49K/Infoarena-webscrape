#include <stdio.h>
#include <stdlib.h>

long long exponent(long N, long long P)
{
  if(P == 0){
    return 1;
  }
  else if(P % 2 == 0){
    return exponent(N * N, P / 2);
  }
  else if(P % 2 != 0){
    return N * exponent(N * N, (P - 1) / 2);
  }
  return 1;
}

int main(void)
{
  FILE *input = fopen("lgput.in", "r");
  FILE *output = fopen("lgput.out", "w");
  long long N, P;
  fscanf(input, "%lld", &N);
  fscanf(input, "%lld", &P);
  fprintf(output, "%lld", exponent(N, P) % 1999999973);
  fclose(input);
  fclose(output);
  return 0;
}
