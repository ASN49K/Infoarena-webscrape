#include <bits/stdc++.h>
#define ll long long

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

ll a,b,i,j,sol,mod=1999999973;

ll LogPower(ll b,ll p){
    sol = 1;
    while (p){
        if (p % 2 == 1)sol = (sol*b)%mod;
        b = (b*b)%mod;
        p/=2;
    }
    return sol;
}

int main()
{
    fin >> a >> b;
    fout << LogPower(a,b);
    return 0;
}
