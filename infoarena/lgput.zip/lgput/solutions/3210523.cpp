#include <fstream>
using namespace std;
ifstream cin ("lgput.in");
ofstream cout ("lgput.out");
long long lgput(long long a,long long b)
{
    if(b==0)
        return 1;
    if(b%2==0)
    {
        long long half=lgput(a,b/2);
        return half*half;
    }
    else
    {
        return a*lgput(a,b-1);
    }
}
int main()
{
    long long a,b;
    cin>>a>>b;
    long long x=lgput(a,b)%1999999973;
    cout<<x;
    return 0;
}
