#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");
const int MOD = 1999999973;
int main()
{
    unsigned long long a, b, rez = 1;
    fin>>a>>b;

    while (b != 0) {

        if (b%2 == 1) {

            rez = (rez*a)%MOD;
        }

       a = (a*a)%MOD;
       b /= 2;
    }

    fout<<rez;
    return 0;
}
