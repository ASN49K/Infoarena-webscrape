/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long exp_log(long long x, long long n, int mod) {
    if (n == 0)
        return 1;
    long long p = 1;
    x = x % mod;
    while (n > 0) {
        if (n % 2)
            p = (p * x) % mod;
        x = (x * x) % mod;
        n /= 2;
    }
    return p;
}


int main()
{
    short n;
	long long p;
	fin>>n>>p;
	int mod = 1999999973;
	long long s = exp_log(n, p, mod);
	fout<<s;

	return 0;
}
