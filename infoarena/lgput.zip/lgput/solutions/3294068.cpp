// #include<iostream>
#include<fstream>
#define nmax 1999999973
using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

long long n, p;

long long Putere(long long a, long long N){
    int P = 1;
    N %= nmax;
    while(N){
        if(N%2 == 1)
            P = (P*a)%nmax;
        a = (a*a)%nmax;
        N = (N/2)%nmax;
    }
    return P;
}

int main(){
    cin >> n >> p;
    cout << Putere(n, p);
}