#include <iostream>
#include <fstream>

using namespace std;
const int MOD = 1999999973;

ifstream f("lgput.in");
ofstream g("lgput.out");

long long powlg(long long a, long long p)
{
    long long val = 1, x = a % MOD;
    while(p > 0)
    {
        if(p % 2 != 0)
            val = val * x % MOD;
        x = x * x % MOD;
        p /= 2;
    }
    return val;
}

int main()
{
    long long N, P;
    f >> N >> P;
    g << powlg(N, P);
    f.close();
    g.close();
    return 0;
}
