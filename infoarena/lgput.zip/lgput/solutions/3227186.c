#include <stdio.h>

long fast_exp(int x, int n) {
    if(n < 0) {
        x = 1 / x;
        n = -n;
    }

    if(n == 0) return 1;
    
    int y = 1;
    while(n > 1) {
        if(n % 2 != 0) {
            y = x * y;
            n--;
        }
        x *= x;
        n /= 2;
    }
    return x * y;
}

int main() {
    long N, P;
    FILE *in = fopen("lgput.in", "r");
    FILE *out = fopen("lgput.out", "w");

    fscanf(in, "%ld %ld", &N, &P);
    fclose(in);

    fprintf(out, "%ld", fast_exp(N, P));
    fclose(out);

    return 0;
}