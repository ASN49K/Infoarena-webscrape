#include <fstream>

using namespace std;

ifstream in("lgput.in");
ofstream out("lgput.out");

long long N,P,r=1999999973;

long long ridic(long long N, long long P)
{
    if(P==0)
        return 1;
    if(P%2==0)
        return (ridic(N%r,P/2)*ridic(N%r,P/2))%r;
    if(P%2==1)
        return (ridic(N%r,P-1)*(N%r))%r;
}

int main()
{
    in>>N>>P;
    out<<ridic(N,P);
    return 0;
}
