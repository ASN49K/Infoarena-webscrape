#include <bits/stdc++.h>
#define MOD 1999999973
#define LL long long
using namespace std;
ifstream in("lgput.in");
ofstream out("lgput.out");
LL n, p;

LL exp(LL b, LL e)
{
    LL rez = 1;
    b = b % MOD;
    for(; e > 0; e >>= 1)
    {
        if(e & 1)
            rez = rez * b % MOD;
        b = b * b % MOD;
    }
    return rez;
}

int main()
{
    in >> n >> p;
    out << exp(n, p);
    return 0;
}
