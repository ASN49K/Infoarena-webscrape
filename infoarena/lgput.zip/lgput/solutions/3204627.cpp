#include <fstream>
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
long long put(int n,int k){
    long long rasp=1;
    while(k){
        if(k%2){
            rasp*=n;
        }
        n*=n;
        k/=2;
    }
    return rasp;
}
int main(){
    long long n,k;
    cin>>n>>k;
    long long rasp=put(n,k);
    cout<<rasp;
}