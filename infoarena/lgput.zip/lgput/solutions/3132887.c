#include <stdio.h>
#include <stdlib.h>
#define rest 2345
void closefile(FILE *fin, char *name)
{
    if (fclose(fin))
    {
        printf("Eroare la inchiderea fisierului %s", name);
    }
}

FILE *openfile(char *filename, char *type)
{
    FILE *fin = NULL;
    if ((fin = fopen(filename, type)) == NULL)
    {
        printf("fisierul nu a putut sa fie deschis");
        exit(EXIT_FAILURE);
    }
    return fin;
}

int putere(int x, int n)
{
    if (n == 0)
        return 1;
    if (n % 2 == 0)
        return putere((x * x) % rest, n / 2);
    if (n % 2 == 1)
        return x * putere((x * x) % rest, n / 2);
    return 0;
}
// float puterenorm(float x, int n)
// {
//     if (n == 0)
//         return 1;
//     return x * puterenorm(x, n - 1);
// }
int main()
{
    // printf("%.2f\n", puterenorm(3, 45));
    // printf("%.2f\n", putere(3, 1000));
    FILE *fin = openfile("lgput.in", "r");
    FILE *fout = openfile("lgput.out", "w");
    int N, P;
    fscanf(fin, "%d", &N);
    fscanf(fin, "%d", &P);
    fprintf(fout, "%d", putere(N, P) % rest);
    closefile(fin, "lgput.in");
    closefile(fout, "lgput.out");
}