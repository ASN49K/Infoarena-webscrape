#include <stdio.h>

int explog(int x, int n) {
  if (n == 0)
    return 1;
  else if (n % 2 == 0)
    return explog(x * x, n / 2);
  else
    return x * explog(x * x, (n - 1) / 2);
}

int main(void) {

  FILE *in = fopen("lgput.in", "r");
  FILE *out = fopen("lgput.out", "w");
  int n, p, rst = 1999999973;
  fscanf(in, "%d", &n);
  fscanf(in, "%d", &p);

  fprintf(out, "%d", (explog(n, p)) % rst);
  return 0;
}
