#include <stdio.h>
#define Mod 1999999973
int Putere(int A , int n)
{
    if(n == 0)
        return 1;
    if(n % 2 == 1)
        return A * Putere(A , n - 1);
    int P = Putere(A , n / 2);
    return P * P;
}
/*float exp_log_rec(float x, int n)
{
    if (n < 0)
    {
        return exp_log_rec(1 / x, (-1) * n);
    }
    if (n == 0)
        return 1;
    if (n % 2 == 0)
        return exp_log_rec(x * x, n / 2);
    if (n % 2 == 0)
        return exp_log_rec(x * x, n / 2);
}*/
int main()
{
    FILE *fin;
    FILE *fout;
    int n, p;
    long long int res = 0;
    if ((fin = fopen("lgput.in", "r")) == NULL)
    {
        printf("Eroare deschidere fisier");
    }
    if ((fout = fopen("lgput.out", "w")) == NULL)
    {
        printf("Eroare deschidere fisier");
    }
    fscanf(fin, "%u", &n);
    fscanf(fin, "%d", &p);
    res=Putere(n,p);
    fprintf(fout,"%lld",res  % 1999999973);
    return 0;
}