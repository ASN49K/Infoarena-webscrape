#include <fstream>

using namespace std;

ifstream f("lgput.in");
ofstream g("lgput.out");

const int MOD = 1999999973;
int a, b, sol = 1;

int main()
{
    f >> a >> b;

    a %= MOD;
    while(b)
    {
        if(b % 2 == 0)
            a *= a, a %= MOD;

        else
            sol *= a, sol %= MOD, b --;

        b /= 2;
    }

    g << sol % MOD;
    return 0;
}
