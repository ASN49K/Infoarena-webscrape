#include<fstream>
using namespace std;
#define ll long long

ifstream cin("lgput.in");
ofstream cout("lgput.out");



ll pow(ll n, ll m,ll mod) {
	if (m == 0) {
		return 1;
	}
	else {
		ll pw = pow(n, m / 2, mod);
		if (m % 2 == 0) {
			return (ll)(pw * pw) % mod;
		}
		else {
			return (ll)(n * (pw * pw) % mod) % mod;
		}
	}
}

int main() {
	
	ll i,a,m,res;
	
	cin >> a >> m;

	
	cout << pow(a, m, 1999999973);

	return 0;
}