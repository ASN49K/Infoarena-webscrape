#include <stdio.h>
float exp_log_rec(float x, int n)
{
    if (n < 0)
    {
        return exp_log_rec(1 / x, (-1) * n);
    }
    if (n == 0)
        return 1;
    if (n % 2 == 0)
        return exp_log_rec(x * x, n / 2);
    if (n % 2 == 0)
        return exp_log_rec(x * x, n / 2);
}
int main()
{
    FILE *fin;
    FILE *fout;
    unsigned int n, p;
    float res = 0;
    if ((fin = fopen("lgput.in", "r")) == NULL)
    {
        printf("Eroare deschidere fisier");
    }
    if ((fout = fopen("lgput.out", "w")) == NULL)
    {
        printf("Eroare deschidere fisier");
    }
    fscanf(fin, "%u", &n);
    fscanf(fin, "%d", &p);
    res=exp_log_rec(n,p);
    fprintf(fout,"%f",res);
    return 0;
}