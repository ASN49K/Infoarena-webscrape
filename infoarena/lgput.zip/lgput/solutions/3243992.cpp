#include <fstream>
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
const int mod = 1999999973;
signed main()
{
    long long a,b,ans=1; cin>>a>>b;
    while(b)
    {
        if(b&1) ans = ans*a%mod;
        a=a*a%mod;
        b>>=1;
    }
    cout << ans;
	return 0;
}
