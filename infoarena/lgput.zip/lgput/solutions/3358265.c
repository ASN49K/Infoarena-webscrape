#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#define mod 1999999973
long long exp(long long x, long long n)
{
    x %= mod;
    if(n == 0)
        return 1;
    else if(n % 2 == 0)
        return exp((x * x) % mod, n / 2);
    else
        return (x * exp((x * x) % mod, (n - 1) / 2) % mod);
}
int main(void)
{
    long long x, n;
    scanf("%lld%lld", &x, &n);
    printf("%lld", exp(x, n));
    return 0;
}