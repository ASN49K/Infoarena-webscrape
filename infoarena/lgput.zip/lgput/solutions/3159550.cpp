#include <iostream>
#include <bits/stdc++.h>
#define ll long long
#define mod 1999999973
using namespace std;
ifstream f("lgput.in");
ofstream g("lgput.out");

long long a,n;
long long lgput(long long a , long long n) {
    if (n==0) return 1;
    long long res = lgput(a, n/2);
    if (n%2==0) return (res*res)%mod;
    return ((res*res)%mod*a)%mod;
}

int main()
{
    f >> a >> n;
    g << lgput(a , n);
    return 0;
}
