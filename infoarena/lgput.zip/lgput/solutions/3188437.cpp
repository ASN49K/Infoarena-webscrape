#include <bits/stdc++.h>
#define MOD 1999999973
#define int long long
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

int n, p;

int power(int base, int exp){
    int b=base;
    while(exp){
        if(exp%2){
            base*=b;
            base%=MOD;
        }
        b*=b;
        b%=MOD;
        exp/=2;
    }
    return base%MOD;
}

int32_t main(){
    fin>>n>>p;
    fout<<power(n, p);
}
