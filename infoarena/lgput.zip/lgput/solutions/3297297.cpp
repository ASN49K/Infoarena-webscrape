#include <bits/stdc++.h>

using namespace std;

const int MOD = 1999999973;

int lgput( int a, int b ) {
    int p = 1;
    while ( b ) {
        if ( b % 2 ) {
            p = (long long)p * a % MOD;
        }
        a = (long long)a * a % MOD;
        b /= 2;
    }
    return p;
}
int main() {
    ifstream fin( "lgput.in" );
    ofstream fout( "lgput.out" );

    int a, b;
    fin >> a >> b;
    fout << lgput( a, b ) << '\n';
    return 0;
}