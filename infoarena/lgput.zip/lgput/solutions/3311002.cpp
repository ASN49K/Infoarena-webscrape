#include <fstream>
#define mod 1999999973
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
int fast(int a,int b){
    int p=1;
    while(b!=0){
        if(b%2!=0)
            p=1LL*p*a%mod;
        a=1LL*a*a%mod;
        b/=2;
    }
    return p;
}
int main()
{
    int a,b;
    cin>>a>>b;
    cout<<fast(a,b);
    return 0;
}
