#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
string np = "lgput";
ifstream f(np + ".in");
ofstream g(np + ".out");

// #define f cin
// #define g cout

const ll mod = 1e9 + 7;
ll fast_pow(ll a, ll b, ll mod)
{
    ll rez = 1;
    for (; b; a = (1ll * a * a) % mod, b >>= 1)
        if (b & 1)
            rez = (1ll * rez * a) % mod;
    return rez;
}
int main()
{
    ios_base::sync_with_stdio(false);
    f.tie(nullptr);

    int a, b;
    f >> a >> b;
    g << fast_pow(a, b, mod);

    return 0;
}
