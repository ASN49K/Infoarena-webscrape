#include <bits/stdc++.h>
using namespace std;

#define mod 1999999973

ifstream in("lgput.in");
ofstream out("lgput.out");

long long lgput(long long n, long long p) {
  if (p == 0)
    return 1;
  if (p % 2 == 0) {
    long long jumatate = lgput(n, p / 2);
    return jumatate * jumatate % mod;
  }

  return n * lgput(n, p - 1) % mod;
}

int main() {
  long long n, p;
  in>>n>>p;
  out<<lgput(n, p) % mod;
  return 0;
}
  /*
    https://infoarena.ro/problema/lgput

    https://www.infoarena.ro/problema/bile6
    https://www.pbinfo.ro/probleme/1057/maxp
   */