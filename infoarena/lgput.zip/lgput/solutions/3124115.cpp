/// iterativ
#include <bits/stdc++.h>
#define int long long
using namespace std;
const int MOD = 1999999973;
int n,a;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

signed main()
{
    fin >> n >> a;
    int p = 1;
    while(a){
        if(a&1){
            p = (p*n)%MOD;
        }
        a >>= 1;
        n = (n*n)%MOD;
    }
    fout << p;
    return 0;
}
