#include <bits/stdc++.h>
#define MOD 1999999973
#define ll long long
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");

ll expR(ll x,ll n)
{
    ll p=1;
    while(n)
    {
        if(n%2==1)p=(p*x)%MOD;
        x=(x*x)%MOD;
        n>>=1;
    }
    return p%MOD;
}
int main()
{
    ll x,n;
    fin>>x>>n;
    fout<<expR(x,n);
}
