#include <fstream>
#include<algorithm>
#include<queue>
#include<vector>
#define int long long
using namespace std;
ifstream cin("lgput.in");
ofstream cout("lgput.out");
int n,p;
//cons int mod = 1999999973;
int rid(int n,int p){
    int rez=1,a=n;
    while(p>0){
          int ultb=p%2;
          if(ultb==1){
             rez*=a;
             rez%=1999999973;
          }
          a=a*a;
          a=a*1999999973;
          p/=2;
    }
    return rez;
}
signed main(){
  cin>>n>>p;
  cout<<rid(n,p);
}
