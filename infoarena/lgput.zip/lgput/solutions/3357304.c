#include <stdio.h>
#include <stdlib.h>
const long long MOD = 1999999973;

long long lgput(long long n, long long p) {
    long long res = 1;
    long long base = n % MOD;
    
    while (p > 0) {
        if (p % 2 == 1) {
            res = (res * base) % MOD;
        }
        base = (base * base) % MOD;
        p /= 2;
    }
    
    return res;
}

int main() {
    FILE *fin,*fout;
    fin = fopen("lgput.in","r");
    fout = fopen("lgput.out","w");
    if (!fin) fin = stdin;
    if (!fout) fout = stdout;
    long long n, p;
    
    if (fscanf(fin,"%lld%lld",&n,&p) ==2) {
        fprintf(fout,"%lld",lgput(n,p));
    }
    fclose(fin);
    fclose(fout);
    
    return 0;
}