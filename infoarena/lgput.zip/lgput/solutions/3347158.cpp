#include <fstream>
using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

int putere(int n, int p)
{
    if(p == 0) return 1;
    if(p % 2 == 1) return n * putere(n , p - 1);
    int P = putere(n, p / 2);
    return P * P;
}

int main()
{
    int n, p;
    long long temp;
    cin >> n >> p;
    temp = putere(n, p);
    if (temp < 1999999973) cout << temp;
    else cout << temp % 1999999973;
}