#include <iostream>
using namespace std;

const long long MOD = 1999999973;

int main() {
    freopen("lgput.in", "r", stdin);
    freopen("lgput.out", "w", stdout);

    long long n, p;
    cin >> n >> p;

    long long rez = 1;
    long long acc = n;

    while (p != 0) {
        if (p & 1) {
            rez = (rez * acc) % MOD;
        }

        acc = (acc * acc) % MOD;
        p = p >> 1;
    }

    cout << rez;
}