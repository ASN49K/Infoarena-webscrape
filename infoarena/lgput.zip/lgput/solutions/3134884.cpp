#include <iostream>
#include <fstream>
#define MOD 1999999973


using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long rez=1;

long long ridic(long long n, long long p)
{
    while (p) {
        if (p % 2 == 1)
        {
            p--;
            rez = (rez * n) % MOD;
        }
        n = (n * n) % MOD;
        p /= 2;
    }
    return rez % MOD;
}
int main()
{
    long long n, p;
    fin >> n >> p;
    fout<<ridic(n, p);
    return 0;
}