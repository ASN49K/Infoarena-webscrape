#include <iostream>
#include <fstream>
using namespace std;
int p, rest=1999999973;
long long n;

/* int putere()
{
    long long acc=1;
    for (int i=1;i<=p;i++)
    {
        acc=(acc*n)%rest;
    }

    return acc;
}
*/


int efficient ()
{
    long long rezl=1;
    while (p)
    {
    if(p%2==0)
    {
        p=p/2;
        n=n*n;
        n=n%rest;
    }
    else if(p%2==1)
    {
        p=p-1;
        rezl=rezl*n;
        rezl=rezl%rest;
    }
    }
    return rezl;
}







int main ()
{
    ifstream f("lgput.in");
    ofstream g("lgput.out");
    f>>n>>p;
    //cout<<putere();
    g<<efficient();
    f.close();
    g.close();
    return 0;
}
