#include <fstream>

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");

unsigned long long Putere(unsigned long long A , unsigned long long n)
{
    unsigned long long P = 1;
    for(unsigned long long k = 1 ; k <= n ; k <<= 1)
    {
        if((n & k))
            P *= A %1999999973;
        A = A %1999999973 * A %1999999973;
    }
    return P%1999999973;
}

int main()
{
    unsigned long long n,m;
    cin>>n>>m;
    cout<<Putere(n,m);
    return 0;
}
