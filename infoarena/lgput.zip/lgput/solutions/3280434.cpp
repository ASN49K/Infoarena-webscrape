#include <bits/stdc++.h>
using namespace std;
#define MOD 1999999973
int putere( int x, int e ){
    int a;
    if( e == 0 ){
        return 1;
    }
    a = putere( x, e / 2 );
    if( e % 2 == 0 ){
        return 1ll * a * a % MOD;
    }
    return 1ll * a * a % MOD * x % MOD;
}
int main(){
    unsigned int n, p;
    ifstream fin( "lgput.in" );
    ofstream fout( "lgput.out" );
    fin >> n >> p;
    fout << putere( n, p );
    return 0;
}
