#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

const long long DIVISOR = 1999999973;

long long power(long long a, long long b)  {
    if (b == 0) {
        return 1;
    }
    long long num = power(a, b / 2);
    if (b % 2 == 0) {
        return num * num % DIVISOR;
    }
    return (num % DIVISOR) * ((num * % DIVISOR) % DIVISOR) * (a % DIVISOR) % DIVISOR;
}

int main() {
    int n, p;
    fin >> n >> p;
    fout << power(n, p);
    return 0;
}
