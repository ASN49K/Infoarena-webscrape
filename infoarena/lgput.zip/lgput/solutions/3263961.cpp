#include <bits/stdc++.h>

using namespace std;

long long lgput (long long a, int b) {
    long long rez = 1;
    while (b) {
        if (b % 2 == 1) {
            rez = (long long)rez * a % 1999999973;
        }
            a *= a;
            b /= 2;
    }

    return rez;
}

int main() {
    ifstream cin("lgput.in");
    ofstream cout("lgput.out");
    int a, b, c;
    cin >> a >> b;
    cout << lgput(a, b);
    return 0;
}
