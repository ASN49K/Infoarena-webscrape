#include <iostream>
#define MOD 1999999973

using namespace std;

long long int a,b,rez=1;

int main()
{
    cin>>a>>b;

    while(b)
    {
        if(b%2==1)
            rez=rez*a%MOD;
        a=a*a%MOD;
        b/=2;
    }

    cout<<rez;

}
