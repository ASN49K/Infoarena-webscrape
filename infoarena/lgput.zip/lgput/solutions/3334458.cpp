#include <fstream>

using namespace std;

ifstream cin("lgput.in");
ofstream cout("lgput.out");
long long n, p;
long long MOD = 1999999973;

long long exp(long long n, long long p)
{
    long long rez = 1;

    while(p > 0)
    {
        if(p % 2 == 1)
        {
            rez = (rez * n) % MOD;
        }

        n = (n * n) % MOD;
        p = p / 2;
    }

    return rez;
}

int main()
{
    cin>>n>>p;

    cout<<exp(n, p);

    return 0;
}
