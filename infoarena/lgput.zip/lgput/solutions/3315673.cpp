#include <iostream>
#include <fstream>
using namespace std;

const long long MOD = 1999999973LL;

ifstream f("lgput.in");
ofstream g("lgput.out");

long long powlg(long long a, long long p) {
    long long val = 1;
    long long x = a % MOD;
    while (p > 0) {
        if (p & 1) val = (val * x) % MOD;
        x = (x * x) % MOD;
        p >>= 1;
    }
    return val;
}

int main() {
    long long N, P;
    f >> N >> P;
    g << powlg(N, P) << '\n';
    f.close();
    g.close();
    return 0;
}
