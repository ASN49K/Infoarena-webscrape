#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long mod = 1999999973;

long long p(long long a, long long b){
    if(b == 0)
        return 1;
    long long tmp = p(a, b/2);
    long long res = (tmp%mod*tmp%mod)%mod;
    if(b%2==1)
        res = res*a%mod;
    return res;
}

int main()
{
    long long a, b;
    fin >> a >> b;
    fout << p(a, b);
    
    return 0;
}
