#include<bits/stdc++.h>

using namespace std;

ifstream fin("lgput.in");
ofstream fout("lgput.out");

long long p , n , a;
const int MOD=1999999973;

int main()
{
    fin >> a >> n;
    p=1;
    while(n)
    {
        if(n % 2 == 1)
        {
            p = (1LL *p * a ) % MOD;
        }
        a = (1LL * a * a) % MOD;
        n /= 2;
    }
    fout<<p;
}
