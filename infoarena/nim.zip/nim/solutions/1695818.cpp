#include <iostream>
#include <fstream>
#include <vector>
#include <bitset>
#include <algorithm>
#include <cstring>
#include <cctype>

#define pb push_back
#define mp make_pair
#define MAXN 500001
#define DIM 8192

using namespace std;

class Reader
{
public:
    Reader(const char* filename)
    {
        f.open(filename);
        pos = 0;
        f.read(buffer,DIM);
    }
    inline Reader& operator >>(int& x)
    {
        x=0;
        sgn=1;
        while((buffer[pos]<'0'||buffer[pos]>'9')&&buffer[pos]!='-')
            if(++pos==DIM)
                f.read(buffer,DIM),pos=0;
        if(buffer[pos]=='-')sgn=-1,pos++;
        while(buffer[pos]>='0'&&buffer[pos]<='9')
        {
            x=x*10+buffer[pos]-'0';
            if(++pos==DIM)f.read(buffer,DIM),pos=0;
        }
        x*=sgn;
        return (*this);
    }
    inline Reader& operator >>(char* c)
    {
        aux = 0;
        while(isspace(buffer[pos]))
            if(++pos==DIM)
                f.read(buffer,DIM),pos=0;
        while(!isspace(buffer[pos]))
        {
            c[aux++]=buffer[pos];
            if(++pos==DIM)f.read(buffer,DIM),pos=0;
        }
        return (*this);
    }
    ~Reader()
    {
        f.close();
    }
private:
    ifstream f;
    int pos,aux,sgn;
    char buffer[DIM];
};

class Writer
{
public:
    Writer(const char* filename)
    {
        g.open(filename);
        pos = 0;
    }
    inline Writer& operator <<(int xx)
    {
        aux = 0;
        x = xx;
        if(xx<0)x=-x;
        if(x==0)
            nr[aux++]='0';
        while(x)
        {
            nr[aux++]=x%10+'0';
            x/=10;
        }
        if(xx<0)nr[aux++]='-';
        while(aux>0)
        {
            buffer[pos++]=nr[--aux];
            if(pos==DIM)g.write(buffer,DIM),pos=0;
        }
        return (*this);
    }
    inline Writer& operator <<(const char* c)
    {
        aux = 0;
        while(c[aux])
        {
            buffer[pos++]=c[aux++];
            if(pos==DIM)g.write(buffer,DIM),pos=0;
        }
        return (*this);
    }
    ~Writer()
    {
        g.write(buffer,pos);
        g.close();
    }
private:
    ofstream g;
    int pos,aux,x;
    char buffer[DIM],nr[21];
};

Reader f("nim.in");
Writer g("nim.out");
int t,n,s,x;
int main()
{
    ios_base::sync_with_stdio(false);
    f>>t;
    while(t--)
    {
        f>>n;
        s=0;
        while(n--)
        {
            f>>x;
            s^=x;
        }
        if(s) g<<"DA\n";
        else g<<"NU\n";
    }
    return 0;
}
