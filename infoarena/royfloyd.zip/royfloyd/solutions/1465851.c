#include <stdio.h>

int n, a[105][105], i, j, k;

int main()
{
	FILE *f = freopen("royfloyd.in", "r", stdin);
	FILE *g = freopen("royfloyd.out", "w", stdout);

	//citirea
	scanf("%d", &n);
	for(i = 1; i <= n; ++i)
		for(j = 1; j <= n; ++j)
			scanf("%d", &a[i][j]);

	//rezolvare
	for(k = 1; k <= n; ++k)
		for(i = 1; i <= n; ++i)
			for(j = 1; j <=n; ++j)
			{
				if (a[i][k] && a[k][j] && (a[i][k] + a[k][j] < a[i][j] || !a[i][j]) && i != j)
					a[i][j] = a[i][k] + a[k][j];
			}

	//afisare
	for(i = 1; i <= n; ++i)
	{
		for(j = 1; j <=n; ++j)
		{
			printf("%d ", a[i][j]);
		}
		printf("\n");
	}

	return 0;
}
