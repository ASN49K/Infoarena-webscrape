#include <fstream>
#define min(a, b) a < b ? a : b
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n, a[105][105];

int main()
{
    int i, j, k;

    fin>>n;

    for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
            fin>>a[i][j];

    for(k=1; k<=n; k++)
        for(i=1; i<=n; i++)
            for(j=1; j<=n; j++)
                a[i][j]=min(a[i][j], a[i][k] + a[k][j]);

    for(i=1; i<=n; i++)
        {
            for(j=1; j<=n; j++)
                fout << a[i][j] << ' ';
            fout<<'\n';
        }

    return 0;
}
