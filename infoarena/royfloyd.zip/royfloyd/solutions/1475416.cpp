#include <cstdio>
#include <algorithm>
using namespace std;
const int NMAX = 105;
int n, A[NMAX][NMAX];

int main() {
  freopen("royfloyd.in", "r", stdin);
  freopen("royfloyd.out", "w", stdout);
  
  scanf("%d", &n);
  for (int i = 1; i <= n; i++)
    for (int j = 1; j <= n; j++)
      scanf("%d", &A[i][j]);
  
  for (int k = 1; k <= n; k++)
    for (int i = 1; i <= n; i++)
      for (int j = 1; j <= n; j++)
        A[i][j] = min(A[i][j], A[i][k] + A[k][j]);
        
  for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= n; j++) {
      if (j > 1) printf(" ");
      printf("%d", A[i][j]);
    }
    printf("\n");
  }
  return 0;
}
