#include <stdio.h>
#include <limits.h>

#define MAX_N 100
#define INF INT_MAX/2

using namespace std;

int N, M;
int c[MAX_N + 1][MAX_N + 1];

//void init() {
//    int i, j;
//    for (i = 1; i <= N; i++)
//        for (j = 1; j <= N; j++)
//            if (i != j)
//                c[i][j] = INF;
//}

void RF() {
    int i, j, k;
    for (k = 1; k <= N; k++)
        for (i = 1; i <= N; i++)
            for (j = 1; j <= N; j++) {
                if ( i != j && c[i][j] > c[i][k] + c[k][j]) {
                    c[i][j] = c[i][k] + c[k][j];
                }
            }
}

int main(){
    int i, j;
    int x, y, cost;

    FILE *fin = fopen("royfloyd.in", "r");
    FILE *fout = fopen("royfloyd.out", "w");

    fscanf(fin, "%d", &N);
//    init();
    for (i = 1; i <= N; i++)
        for (j = 1; j <= N; j++)
            fscanf(fin, "%d", &c[i][j]);

    RF();

    for (i = 1; i <= N; i++) {
        for (j = 1; j <= N; j++)
            fprintf(fout, "%d ", c[i][j]);
        fprintf(fout, "\n");
    }

    fclose(fin);
    fclose(fout);
    return 0;
}
