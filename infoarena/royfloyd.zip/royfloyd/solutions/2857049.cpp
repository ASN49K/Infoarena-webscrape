#include <fstream>

using namespace std;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

const int N=101;

int d[N][N];

int main()
{
    int n;
    in>>n;
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            in>>d[i][j];
        }
    }
    for(int k=1; k<=n; k++)
    {
        for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=n; j++)
            {
                if(d[i][k]+d[k][j]<d[i][j])
                {
                    d[i][j]=d[i][k]+d[k][j];
                }
            }
        }
    }
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            out<<d[i][j]<<" ";
        }
        out<<"\n";
    }
    return 0;
}
