#include <fstream>

using namespace std;
ifstream cin("royfloid.in");
ofstream cout("royfloid.out");
int a[1001][1001],k,j,i,n;
int main()
{
    cin>>n;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
        cin>>a[i][j];
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
            {
                if(a[i][k]!=0&&a[k][j]!=0&&(a[i][j]>a[i][k]+a[k][j]||a[i][j]==0)&&i!=j)
                    a[i][j]=a[i][k]+a[k][j];
            }
        }
    }
   for(i=1;i<=n;i++)
   {
       for(j=1;j<=n;j++)
        cout<<a[i][j]<<" ";
       cout<<endl;
   }
   return 0;
}
