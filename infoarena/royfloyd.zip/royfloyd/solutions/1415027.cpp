#include <stdio.h>

#define N 100
#define INF 1001

void use_node(int k, int n, int a[][N])
{
	int i, j;

	for(i = 0; i < n; i++)
		for(j = 0; j < n; j++)
			if(a[i][j] > a[i][k] + a[k][j])
				a[i][j] = a[i][k] + a[k][j];
}

int main(void)
{
	int a[N][N] = {INF};
	int i, j, k;
	int n;

	freopen("royfloyd.in", "r", stdin);
	freopen("royfloyd.out", "w", stdout);

	scanf("%d", &n);

	for(i = 0; i < n; i++)
		for(j = 0; j < n; j++)
			scanf("%d", &a[i][j]);
	
	for(k = 0; k < n; k++)
		use_node(k, n, a);

	for(i = 0; i < n; i++)
	{
		for(j = 0; j < n; j++)
			if(a[i][j] == INF)
				printf("0 ");
			else
				printf("%d ", a[i][j]);
		printf("\n");
	}

	return 0;
}

