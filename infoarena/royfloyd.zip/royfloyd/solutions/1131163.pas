Program royfloyd;
var n,i,j,k : word;
    D : array [1..100,1..100] of longint;
begin
  assign(input,'royfloyd.in'); reset(input);
  assign(output,'royfloyd.out'); rewrite(output);
  readln(n);
  for i:=1 to n do
     for j:=1 to n do read(D[i,j]);

  for k:=1 to n do
     for i:=1 to n do
        for j:=1 to n do
           if (i<>j) and (i<>k) and (k<>j) then
             if D[i,j]>D[i,k]+D[k,j] then
                D[i,j]:=D[i,k]+D[k,j];

   for i:=1 to n do begin
     for j:=1 to n do write(D[i,j],' ');
                          writeln;
                    end;
  close(input);
  close(output);
end.
