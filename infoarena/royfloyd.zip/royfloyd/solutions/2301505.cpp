#include <iostream>
#include <fstream>
#define Nmax 105

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int n;
int a[Nmax][Nmax];

void read()
{
    f >> n;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++) f >> a[i][j];
}

void rf()
{
    for (int k = 1; k <= n; k++)
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++)
                if( (a[i][j] == 0 || a[i][k]+a[k][j]<a[i][j]) && a[i][k]!=0 && a[k][j]!=0 && i!=j)
                    a[i][j]=a[i][k]+a[k][j];
}

void print()
{
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
            g << a[i][j] << " ";
        g << '\n';
    }
}

int main()
{
    read();
    rf();
    print();
    return 0;
}
