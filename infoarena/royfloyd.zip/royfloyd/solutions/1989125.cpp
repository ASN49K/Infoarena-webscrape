#include <iostream>
#include <fstream>

int main() {
    std::ifstream inFile("royfloyd.in");
    std::ofstream outFile("royfloyd.out");

    int nV;
    int **arr;

    inFile >> nV;

    arr = new int*[nV];

    for (int i = 0; i < nV; i++) {
        arr[i] = new int[nV];
        for (int j = 0; j < nV; j++) {
            inFile >> arr[i][j];
        }
    }

    for (int k = 0; k < nV; k++) {
        for (int i = 0; i < nV; i++) {
            for (int j = 0; j < nV; j++) {
                if (!arr[i][k] || !arr[k][j] || i == j) {
                    continue;
                }
                int dist = arr[i][k] + arr[k][j];
                if (dist < arr[i][j] || !arr[i][j]) {
                    arr[i][j] = dist;
                }
            }
        }
    }

    for (int i = 0; i < nV; i++) {
        for (int j = 0; j < nV; j++) {
            outFile << arr[i][j] << ' ';
        }
        outFile << std::endl;
    }

    for (int i = 0; i < nV; i++) {
        delete[] arr[i];
    }
    delete[] arr;

    inFile.close();
    outFile.close();

    return 0;
}
