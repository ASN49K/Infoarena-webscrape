#include<iostream>
#define nmax 105
using namespace std;
int floyd[nmax][nmax];
int n;

void royfloyd()
{
	for (int k = 1; k <= n; k++)
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= n; j++)
				if (i != j && floyd[i][k] && floyd[k][j] && floyd[i][k] + floyd[k][j] < floyd[i][j])
					floyd[i][j] = floyd[i][k] + floyd[k][j];
}

int main()
{
	freopen("royfloyd.in", "r", stdin);
	freopen("royfloyd.out", "w", stdout);
	cin >> n;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++)
			cin >> floyd[i][j];
	royfloyd();

	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
			cout << floyd[i][j] << ' ';
		cout << '\n';
	}

}