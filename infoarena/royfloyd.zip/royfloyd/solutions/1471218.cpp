#include <fstream>
using namespace std;
int n, a[260][260];
const int inf=1<<30;
void roy_floyd()
{
    int i, j, k;
    for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
            if(i!=j && a[i][j]==0) a[i][j]=inf;

    for(k=1; k<=n; k++)
        for(i=1; i<=n; i++)
        {
            if(i==k) continue;
            for(j=1; j<=n; j++)
                if(a[i][j]>a[i][k]+a[k][j])
                    a[i][j]=a[i][k]+a[k][j];
        }
}

int main()
{
    ifstream fin ("royfloyd.in");
    ofstream fout ("royfloyd.out");
    int i, j;
    fin >> n;
    for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
            fin >> a[i][j];
    roy_floyd();
    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++)
        {
            if(a[i][j]==inf) a[i][j]=0;
            fout << a[i][j] << " ";
        }
        fout << "\n";
    }
    fin.close();
    fout.close();
    return 0;
}
