#include <iostream>
#include <fstream>
using namespace std;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");
const int maxn = 105;
int dist[maxn][maxn];
int M[maxn][maxn];
int main()
{
    int n;
    in >> n;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
            in >> M[i][j];
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
            if(i != j)
                dist[i][j] = M[i][j];
    for(int k = 1; k <= n; k++)
        for(int i = 1; i <= n; i++)
            for(int j = 1; j <= n; j++)
                if(dist[i][j] > dist[i][k] + dist[k][j])
                    dist[i][j] = dist[i][k] + dist[k][j];
    for(int i = 1; i <= n; i++, out << "\n")
        for(int j = 1; j <= n; j++)
            out << dist[i][j] << " ";
    return 0;
}
