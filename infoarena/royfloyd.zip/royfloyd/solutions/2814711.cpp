#include <iostream>
#include <fstream>
#include <vector>


using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");


#define Max 100001

class graf{
private:
    int n,m;
public:
    graf(int n);
    void roy_floyd(int matrice[105][105]);
    void royfloyd();
};

graf :: graf(int n)
{
    this->n = n;
}

void graf::roy_floyd(int matrice[105][105]){
    int i ,j ,k;
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            if ( matrice[i][j] == 0 && i != j)
                matrice[i][j]==10001;

    for(k=0;k<n;k++)
        for(i=0;i<n;i++)
            for(j=0;j<n;j++)
                if (matrice[i][k]+matrice[k][j]<matrice[i][j])
                    matrice[i][j]=matrice[i][k]+matrice[k][j];

    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            if ( matrice[i][j] == 10001)
                matrice[i][j]==0;

    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
            g<<matrice[i][j]<<" ";
        g<<endl;
    }
}

void graf::royfloyd(){
    int n,i ,j;
    f>>n;
    int matrice[105][105];
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            f>>matrice[i][j];
    graf G(n);

    G.roy_floyd(matrice);
}
int main()
{
    int n;
    graf G(n);
    G.royfloyd();
    return 0;
}
