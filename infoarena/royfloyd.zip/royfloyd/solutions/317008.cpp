# include <stdio.h>
int a[101][101],i,j,k,x,n;
int main ()
{
freopen ("royfloyd.in","r",stdin);
freopen ("royfloyd.out","w",stdout);
scanf ("%i",&n);
for (i=1;i<=n;i++)
for (j=1;j<=n;j++)
{
scanf ("%i",&x);
if (i!=j && x==0)
a[i][j]=10000;
else
a[i][j]=x;
}
for (k=1;k<=n;k++)
for (i=1;i<=n;i++)
for (j=1;j<=n;j++)
if (i!=j && i!=k && j!=k && a[i][j]>a[i][k]+a[k][j])
a[i][j]=a[i][k]+a[k][j];
for (i=1;i<=n;i++)
{
for (j=1;j<=n;j++)
if (i!=j && a[i][j]==10000)
printf ("0 ");
else
printf ("%i ",a[i][j]);

printf ("\n");
}
return 0;
}
