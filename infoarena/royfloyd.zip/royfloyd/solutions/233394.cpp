#include<stdio.h>

int N,**Costuri;

inline void init()
{
FILE *pin=fopen("royfloyd.in","r");
fscanf(pin,"%d",&N);

Costuri=new int*[N+1];
for(int i=1;i<=N;i++)
  Costuri[i]=new int[N+1];

for(int i=1;i<=N;i++)
  for(int j=1;j<=N;j++)
    fscanf(pin,"%d",&Costuri[i][j]);
fclose(pin);
}

inline void rezolva()
{
for(int k=1;k<=N;k++)
  for(int i=1;i<=N;i++)
    for(int j=1;j<=N;j++)
      if((Costuri[i][k]+Costuri[k][j]<Costuri[i][j] || Costuri[i][j]==0)  && i!=j)
        Costuri[i][j]=Costuri[i][k]+Costuri[k][j];
}

inline void incheie()
{
FILE *pout=fopen("royfloyd.out","w");
for(int i=1;i<=N;i++)
  {
  for(int j=1;j<=N;j++)
    fprintf(pout,"%d ",Costuri[i][j]);
  fprintf(pout,"\n");
  }
fclose(pout);
}

int main()
{
init();
rezolva();
incheie();
}