#include <iostream>
#include <fstream>
using namespace std;
ifstream f ("royfloyd.in");
ofstream g ("royfloyd.out");
int a[100][100], n;
void citire ()
{
    int i, j;
    f>>n;
    for (i=1; i<=n; i++)
    for (j=1; j<=n; j++)
        f>>a[i][j];
}
void RoyFloyd ()
{
    int i, j, k;
    for (k=1; k<=n; k++)
    for (i=1; i<=n; i++)
    for (j=1; j<=n; j++)
        if (a[i][k]+a[k][j]<a[i][j] && i!=j && a[i][k]!=0 && a[k][j]!=0) a[i][j] = a[i][k] + a[k][j];
}
void afisare ()
{
    int i, j;
    for (i=1; i<=n; i++){
        for (j=1; j<=n; j++)
            g<<a[i][j]<<" ";
        g<<"\n";
    }
}
int main()
{
    citire ();
    RoyFloyd ();
    afisare();
    return 0;
}
