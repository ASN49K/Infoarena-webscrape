#include<fstream>
#define nmax 101
using namespace std;

int A[nmax][nmax],N;

void citeste()
{
    ifstream f("royfloyd.in");
    int i,j;

    f>>N;
    for(i=1;i<=N;i++)
     for(j=1;j<=N;j++)
     f>>A[i][j];

     f.close();
}

void royfloyd()
{
    int i,j,k;

    for(k=1;k<=N;k++)
     for(i=1;i<=N;i++)
      for(j=1;j<=N;j++)
       if(i!=j && A[i][k] && A[k][j])
         if(A[i][j]>A[i][k]+A[k][j])
          A[i][j]=A[i][k]+A[k][j];
}

void rezolva()
{
    royfloyd();
}

void scrie()
{
    ofstream g("royfloyd.out");
    int i,j;

    for(i=1;i<=N;i++)
     {
         for(j=1;j<=N;j++)
         g<<A[i][j]<<' ';
         g<<'\n';
     }

     g.close();
}

int main()
{
    citeste();
    rezolva();
    scrie();
    return 0;
}
