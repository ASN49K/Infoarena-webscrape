#include <cstdio>
#define INF 999999999
#define LMAX 102

using namespace std;
FILE *fin=fopen("royfloyd.in","r");
FILE *fout=fopen("royfloyd.out","w");

int a[LMAX][LMAX];
int n;

void citire();
void afisare();
void calculez();

int main()
{
citire();
calculez();
afisare();
return 0;
}

void citire()
    {
     int i ,j;
     fscanf(fin,"%d",&n);
     for (i=1;i<=n;i++)
          for (j=1;j<=n;j++)
               fscanf(fin,"%d",&a[i][j]);
    }

void afisare()
    {
     int i ,j;
     for (i=1;i<=n;i++)
          {for (j=1;j<=n;j++)
               fprintf(fout,"%d ",a[i][j]);
          fprintf(fout,"\n");
          }
    }

void calculez()
    {
     int k, x, y;
     for (k=1;k<=n;k++)
          for (x=1;x<=n;x++)
               for (y=1;y<=n;y++)
                    if (a[x][y]>a[x][k]+a[k][y])
                        a[x][y]=a[x][k]+a[k][y];
    }
