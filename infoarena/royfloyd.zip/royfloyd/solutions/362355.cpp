#include <iostream>
#include <fstream>
#include <cstdlib>
#include <climits>

#define min(a, b) ((a) > (b) ? (b) : (a))

using namespace std;

static const int N = 101, INF = 1000000000;

int main() {
    ifstream cin("royfloyd.in");
    ofstream cout("royfloyd.out");

    int n;
    int edgeCost[N][N];
    int shortestPath[N][N][2];
    int i, j, k, swap1, swap2;

    cin >> n;

    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++) {
            cin >> edgeCost[i][j];
            if (edgeCost[i][j] == 0) {
                edgeCost[i][j] = INF;
            }
            shortestPath[i][j][0] = edgeCost[i][j];
        }
    }

    for (k = 1; k <= n; k++) {
        for (i = 1; i <= n; i++) {
            for (j = 1; j <= n; j++) {
                if (i != j) {
                    swap1 = k % 2;
                    swap2 = (k + 1) % 2;
                    shortestPath[i][j][swap1] = min(shortestPath[i][j][swap2],
                        shortestPath[i][k][swap2] + shortestPath[k][j][swap2]);
                }
            }
        }
    }

    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++) {
            if (shortestPath[i][j][n % 2] < INF) {
                cout << shortestPath[i][j][n % 2] << " ";
            } else {
                cout << "0 ";
            }
        }
        cout << endl;
    }

    cout.close();
    return 0;
}
