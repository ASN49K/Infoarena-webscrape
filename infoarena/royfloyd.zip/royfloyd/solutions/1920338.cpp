#include <cstdio>
#include <algorithm>

using namespace std;

int mat[101][101];
int n;

int main()
{
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);
    scanf("%d", &n);
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            scanf("%d", &mat[i][j]);
    for(int k = 0; k < n; k++)
        for(int i = 0; i < n; i++)
            for(int j = 0; j < n; j++)
                if(mat[i][j] == 0 || mat[i][k] == 0 || mat[k][j] == 0 || i == j) continue;
                else mat[i][j] = min(mat[i][j], mat[i][k] + mat[k][j]);
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
            printf("%d ", mat[i][j]);
        printf("\n");
    }
    return 0;
}
