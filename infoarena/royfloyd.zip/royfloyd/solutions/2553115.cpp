#define INF 0x3f3f3f3f
#define NMAX 105
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

int n, m;
int ED[NMAX][NMAX], P[NMAX][NMAX];

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");


void read()
{
    int x, y;

    f>>n;
    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= n; ++j)
        {
            f>>x;
            if(x == 0)
                ED[i][j] = INF;
            else{
                ED[i][j] = x;
                P[i][j] = i;
            }
        }
}

void roy_warshall()
{
    for(int k = 1; k<=n; ++k)
        for(int i = 1; i <= n ; ++i)
            for(int j = 1; j <= n; ++j)
                if(ED[i][j] > ED[i][k] + ED[k][j])
                {
                    ED[i][j] = ED[i][k] + ED[k][j];
                    P[i][j] = P[k][j];
                }
}

void afisED(int ED[NMAX][NMAX])
{
    for(int i = 1; i <= n; ++i)
    {
        for(int j = 1; j <= n; ++j)
        {
            if(ED[i][j] >= INF || i == j)
                g<<0<<" ";
            else g<<ED[i][j]<<" ";
        }
        g<<'\n';
    }
}

void drum(int i, int j)
{
    if(i == j)
    {
        g<<i<<" ";
        return;
    }
    drum(i, P[i][j]);
    g<<j<<" ";
}


int main()
{
    read();
    roy_warshall();
    afisED(ED);
    //afisED(P);

    return 0;
}
