#include <cstring>
#include <cstdio>
#include <cmath>

int n;
int a[101][101];

int main() {
	FILE * in = fopen("royfloyd.in", "rt");
	FILE * out = fopen("royfloyd.out", "wt");

	fscanf(in, "%d", &n);
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			fscanf(in, "%d", &a[i][j]);
		}
	}

	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			for (int k = 0; k < n; ++k) {
				if (a[i][k] && a[k][j]) {
					if (a[i][k] + a[k][j] < a[i][j]) {
						a[i][j] = a[i][k] + a[k][j];
					}
				}
			}
		}
	}

	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			fprintf(out, "%d ", a[i][j]);
		}
		fprintf(out, "\n");
	}

	fclose(in);
	fclose(out);
}
