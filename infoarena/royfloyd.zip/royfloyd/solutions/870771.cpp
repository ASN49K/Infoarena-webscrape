# include<stdio.h>
int a[50][50],n,i,j,k;
FILE *in,*out;
int main(void)
{
    in=fopen("roy.in","rt");
    out=fopen("roy.out","wt");
    fscanf(in,"%d",&n);
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            fscanf(in,"%d",&a[i][j]);

    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if(a[i][k] + a[k][j] < a[i][j] && i!=j)
                    a[i][j]=a[i][k]+a[k][j];

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
            fprintf(out,"%d ",a[i][j]);
        fprintf(out,"\n");
    }
    fclose(in);
    fclose(out);
    return 0;
}
