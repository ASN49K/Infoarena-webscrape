#include <fstream>
#include <iomanip>
#include <string>
#include <stdio.h>
#include <vector>
#include <algorithm>
#include <math.h>
#include <set>
#include <map>
#include <string.h>
#include <queue>
#include <stack>

#define INF 0x3f3f3f3f

using namespace std;

#ifdef DEBUG
string name = "data";
#else
string name = "royfloyd";
#endif

ifstream fin(name + ".in");
ofstream fout(name + ".out");

#define MAXN 260

int n;
int a[MAXN][MAXN];
int d[MAXN][MAXN];
//int length[MAXN][MAXN];

int main() {

    memset(d, 0x3f, sizeof(a));
    
    fin >> n;
    
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            fin >> a[i][j];
            if (i == j) {
                d[i][j] = 0;
            } else {
                d[i][j] = a[i][j];
                if (d[i][j] == 0) {
                    d[i][j] = INF;
                }
            }
        }
    }
    
    for (int k = 1; k <= n; ++k) {
        for (int i = 1; i <= n; ++i) {
            for (int j = 1; j <= n; ++j) {
                if (i == j) {
                    continue;
                }
                if (d[i][k] == 0 || d[k][j] == 0) {
                    continue;
                }
                
                if (d[i][k] + d[k][j] <= d[i][j]) {
                    d[i][j] = d[i][k] + d[k][j];
//                    length[i][j] = max(length[i][j], length[i][k] + length[k][j]);
                }
            }
        }
    }
    
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            fout << d[i][j] << " ";
        }
        fout << "\n";
    }
    
//    for (int i = 1; i <= n; ++i) {
//        for (int j = 1; j <= n; ++j) {
//            fout << length[i][j] << " ";
//        }
//        fout << "\n";
//    }
    
    return 0;
}
