#include <bits/stdc++.h>

using namespace std;
ifstream f("roy-floyd.in");
ofstream g("roy-floyd.out");
const int N=102;
const int INF=1000000;
int n,m,a[N][N];
int main()
{
    f>>n>>m;
    for(int i=1; i<=m; i++)
    {
        int x,y,c;
        f>>x>>y>>c;
        a[x][y]=c;
    }
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            if(a[i][j]==0)
                a[i][j]=INF;
    for(int k=1; k<=n; k++)
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++)
                if(k!=i && k!=j && i!=j)
                    a[i][j]=min(a[i][j],a[i][k]+a[k][j]);
    for(int i=1;i<=n;i++)
        a[i][i]=0;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            if(a[i][j]==INF)
                a[i][j]=-1;
            g<<a[i][j]<<' ';
        }
        g<<'\n';
    }

    return 0;
}
