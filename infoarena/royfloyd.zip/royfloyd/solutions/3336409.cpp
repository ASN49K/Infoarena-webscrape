#include <fstream>

using namespace std;

ifstream fin("royfloid.in");
ofstream fout("royfloid.out");

const int MAX_N = 100;

int n;

int cost[MAX_N][MAX_N];

void read() {
    fin >> n;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            fin >> cost[i][j];
        }
    }
}

void roy_floid() {
    for (int k = 0; k < n; ++k) {
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                if (cost[i][k] && cost[k][j] && (!cost[i][j] || cost[i][j] > cost[i][k] + cost[k][j])) {
                    cost[i][j] = cost[i][k] + cost[k][j];
                }
            }
        }
    }
}

void write() {
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            fout << cost[i][j] << ' ';
        }
        fout << '\n';
    }
}

int main() {
    read();
    roy_floid();
    write();
    return 0;
}
