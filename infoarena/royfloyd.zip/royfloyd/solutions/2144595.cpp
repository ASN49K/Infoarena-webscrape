#include<bits/stdc++.h>
using namespace std;

int n,i,j,a[102][102];

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

void royfloyd()
{
    int i,j,k;
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            if(a[i][k]!=0 && a[k][j]!=0 && (a[i][j]>a[i][k]+a[k][j] || a[i][j]==0) && i!=j)
                a[i][j]=a[i][k]+a[k][j];
}

int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
        fin>>a[i][j];

    royfloyd();

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
            fout<<a[i][j]<<" ";
        fout<<"\n";
    }

    fin.close();
    fout.close();
    return 0;
}
