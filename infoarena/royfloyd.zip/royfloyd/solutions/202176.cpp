#include <fstream>
#define MAX 1000001
using namespace std;

ifstream fin ("royfloyd.in");
ofstream fout ("royfloyd.out");

int a[105][105],n;

void citire()
{
    fin>>n;
    for (int i=0;i<n;i++)
        for (int j=0;j<n;j++)
        {
                fin>>a[i][j];
                if (i!=j && a[i][j]==0)
                    a[i][j]=MAX;
        }
}

void roy_floyd()
{

    for (int k=0;k<n;k++)
        for (int i=0;i<n;i++)
            for (int j=0;j<n;j++)
                if (a[i][k]+a[k][j]<a[i][j])
                    a[i][j]=a[i][k]+a[k][j];
}

void afisare()
{
    for (int i=0;i<n;i++)
    {
        for (int j=0;j<n;j++)
            fout<<(a[i][j]==MAX?0:a[i][j])<<" ";
        fout<<"\n";
    }
}


int main ()
{
    citire();
    roy_floyd();
    afisare();
    return 0;
}
