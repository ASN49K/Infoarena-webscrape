program roy_floyd;
var f,g:text;
    n,i,j,k:integer;
    a:array[1..100,1..100] of longint;

begin
 assign (f,'royfloyd.in'); reset (f);
 assign (g,'royfloyd.out'); rewrite (G);
 readln (f,n);
 for i:=1 to n do
 begin
  for j:=1 to n do
   read (f,a[i,j]);
  readln (f);
 end;
 for i:=1 to n do
  for j:=1 to n do
   if (i<>j) and (a[i,j]=0) then
   a[i,j]:=maxint;
 for k:=1 to n do
  for i:=1 to n do
   for j:=1 to n do
    if a[i,j]>a[i,k]+a[k,j] then
     a[i,j]:=a[i,k]+a[k,j];
  for i:=1 to n do
  begin
   for j:=1 to n do
   begin
    if a[i,j]=maxint then
     a[i,j]:=0;
    write (g,a[i,j],' ');
   end;
   writeln (g);
  end;
 close (F); close(G);
end.
