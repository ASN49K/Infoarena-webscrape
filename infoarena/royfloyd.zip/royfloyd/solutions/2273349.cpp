#include <fstream>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int a[101][101],n;
void citire()
{
    f>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            f>>a[i][j];
}

void roy_floyd()
{
    for(int k=1;k<=n;k++)
    {
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                if(a[i][k]+a[k][j]<a[i][j])
                    a[i][j]=a[i][k]+a[k][j];
            }
        }
    }
}

void afisare()
{
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            g<<a[i][j]<<" ";
        g<<endl;
    }
}
int main()
{
    citire();
    roy_floyd();
    afisare();
    return 0;
}
