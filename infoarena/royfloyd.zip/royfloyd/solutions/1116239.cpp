//Infoarena. Arhiva Educationala. Floyd-Warshall/Roy-Floyd.
#include<iostream>
#include<fstream>
using namespace std;

int main(){
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);

    int N,P[103][103],C[103][103];
    cin>>N;

    for(int i=1;i<=N;i++)
        for(int j=1;j<=N;j++){
            cin>>P[i][j];
            C[i][j]=P[i][j];
        }
/*
    for(int i=1;i<=N;i++){
        for(int j=1;j<=N;j++)
            cout<<P[i][j]<<" ";
            cout<<"\n";
    }
    */
    int dist;
    for(int k=1;k<=N;k++)
        for(int i=1;i<=N;i++)
            for(int j=1;j<=N;j++){
                if(i==j) continue;
                else if(P[i][k]&&P[k][j]){
                    dist=P[i][k]+P[k][j];
                    if(P[i][j]==0 || P[i][j]>dist) P[i][j]=dist;
                }
            }



    for(int i=1;i<=N;i++){
        for(int j=1;j<=N;j++)
            cout<<P[i][j]<<" ";
            cout<<"\n";
        }

}
