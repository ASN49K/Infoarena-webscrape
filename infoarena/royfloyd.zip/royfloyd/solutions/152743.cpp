#include<stdio.h>
int n,i,j,k,a[101][101]	;
int main()
{

freopen("royfloyd.in","r",stdin);
freopen("royfloyd.out","w",stdout);

scanf("%ld",&n);

for(i=1;i<=n;i++)
for(j=1;j<=n;j++) scanf("%ld",&a[i][j]);


for(i=1;i<=n;i++)
 for(j=1;j<=n;j++)
  for(k=1;k<=n;k++)
          
if (a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j)a[i][j] = a[i][k] + a[k][j];   
    //   if(a[i][k]+a[k][j]<a[i][j] && i!=j) a[i][j]=a[i][k]+a[k][j];

for(i=1;i<=n;i++){
 for(j=1;j<=n;j++)printf("%ld ",a[i][j]);
  printf("\n");
  }

return 0;
}
