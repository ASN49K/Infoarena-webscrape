#include <bits/stdc++.h>
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
int a[110][110],n;
int rez[110][110];
int main()
{int i,j,k;
    fin>>n;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            {fin>>a[i][j];
            if(i!=j&&a[i][j]==0)
            rez[i][j]=INT_MAX/2;
            else
            rez[i][j]=a[i][j];
}
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            for(k=1;k<=n;k++)
                if(rez[k][i]+rez[i][j]<rez[k][j]&&k!=j)
                rez[k][j]=rez[k][i]+rez[i][j];
    for(i=1;i<=n;i++)
    {for(j=1;j<=n;j++)
        fout<<rez[i][j]<<' ';
    fout<<'\n';}
    return 0;
}
