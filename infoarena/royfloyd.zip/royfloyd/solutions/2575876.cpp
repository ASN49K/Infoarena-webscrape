#include <bits/stdc++.h>
using namespace std;
const int N = 102;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n, a[N][N];
int main()
{
    f >> n;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
            f >> a[i][j];
    for(int k = 1; k <= n; k++)
        for(int i = 1; i <= n; i++)
            for(int j = 1; j <= n; j++)
                if(i != j && i!=k && j !=k)
                    a[i][j] = min(a[i][j], a[i][k] + a[k][j]);
    for(int i = 1; i <= n; i++, g << '\n')
        for(int j = 1; j <= n; j++)
            g << a[i][j] << ' ';
    return 0;
}
