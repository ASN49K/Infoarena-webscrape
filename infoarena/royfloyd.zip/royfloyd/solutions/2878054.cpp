#include <fstream>
using namespace std;

ifstream cin("royfloyd.in");
ofstream cout("royfloyd.out");

int n, A[101][101];

int main() {
  cin >> n;
  for (int i = 1; i <= n; ++i)
    for (int j = 1; j <= n; ++j)
      cin >> A[i][j];
    
  for (int k = 1; k <= n; ++k)
    for (int i = 1; i <= n; ++i)
      for (int j = 1; j <= n; ++j)
        if (A[i][j] > A[i][k] + A[k][j])
          A[i][j] = A[i][k] + A[k][j];
    
  for (int i = 1; i <= n; ++i, cout << "\n")
    for (int j = 1; j <= n; ++j)
      cout << A[i][j] << " ";
    
  cin.close();
  cout.close();
  return 0;
}
