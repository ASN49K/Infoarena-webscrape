#include <iostream>
#include <fstream>
using namespace std;
int n, a[105][105];
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
void citire()
{
	int i, j;
	f >> n;
	for (i = 1; i <= n; i++)
		for (j = 1; j <= n; j++)
			f >> a[i][j];
}

void roy_floyd()
{
	int i, j, k;
	for (k = 1; k <= n; k++)
		for (i = 1; i <= n; i++)
			for (j = 1; j <= n; j++)
				if (a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j)
					a[i][j] = a[i][k] + a[k][j];
}

void afis()
{
	int i, j;
	for (i = 1; i <= n; i++)
	{
		for (j = 1; j <= n; j++)
			g << a[i][j] << " ";
		g << "\n";
	}
}

int main()
{
	citire();
	roy_floyd();
	afis();
	return 0;
}