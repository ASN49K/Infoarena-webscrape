#include <stdio.h>
#define N 100
int n, a[N+1][N+1];
inline void citeste()
{
	freopen("royfloyd.in","r",stdin);
	scanf("%d\n",&n);
	int i,j;
	for(i=1;i<=n;++i) for(j=1;j<=n;++j) scanf("%d",&a[i][j]);
	fclose(stdin);
}
inline void floyd_warshall()
{
	int i,j,k;
	for(k=1;k<=n;++k)
		for(i=1;i<=n;++i)
			for(j=1;j<=n;++j)
				if(a[i][k] && a[k][j] && (a[i][j]>a[i][k]+a[k][j] || !a[i][j]) && (i!=j))
					a[i][j]=a[i][k]+a[k][j];
}
inline void scrie()
{
	freopen("royfloyd.out","w",stdout);
	int i,j;
	for(i=1;i<=n;++i)
	{
		for(j=1;j<=n;++j) printf("%d ",a[i][j]);
		printf("\n");
	}
	fclose(stdout);
}
int main()
{
	citeste();
	floyd_warshall();
	scrie();
	return 0;
}
