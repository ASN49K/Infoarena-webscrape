#include<cstdio>

int graph[101][101],n,din[101][101];

int main()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    scanf("%d",&n);
    for(int i=0;i<n;++i)
        for(int j=0;j<n;++j)
        {
            scanf("%d",&graph[i][j]);
            din[i][j]=graph[i][j];
        }
     for(int k=0;k<n;++k)
        for(int i=0;i<n;++i)
            for(int j=0;j<n;++j)
                if(din[i][k]&&din[k][j]&&din[i][j]>din[i][k]+din[k][j])
                    din[i][j]=din[i][k]+din[k][j];

     for(int i=0;i<n;++i)
     {
        for(int j=0;j<n;++j)printf("%d ",din[i][j]);
        printf("\n");
     }
     return 0;
}
