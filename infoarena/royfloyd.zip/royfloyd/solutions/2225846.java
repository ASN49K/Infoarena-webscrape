import java.io.*;
import java.util.StringTokenizer;

public class Main {

    public static void main(String[] args) throws IOException {
        InputStream inputStream = new FileInputStream("royfloyd.in");
        FileWriter fileWriter = new FileWriter("royfloyd.out");

        try (InputReader inputReader = new InputReader(inputStream);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
            new Solver(inputReader, bufferedWriter).solve();
        }
    }

    static class Solver {

        private static final int INF = Integer.MAX_VALUE >> 1;

        private int[][] bestPath;

        private int N;

        private InputReader inputReader;

        private BufferedWriter bufferedWriter;

        public Solver(InputReader inputReader, BufferedWriter bufferedWriter) {
            this.inputReader = inputReader;
            this.bufferedWriter = bufferedWriter;
        }

        public void solve() throws IOException {
            N = inputReader.nextInt();
            bestPath = new int[N + 1][N + 1];
            for (int i = 1; i <= N; i++) {
                for (int j = 1; j <= N; j++) {
                    int cost = inputReader.nextInt();
                    bestPath[i][j] = (cost == 0) ? INF : cost;
                }
            }

            for (int k = 1; k <= N; k++) {
                for (int i = 1; i <= N; i++) {
                    for (int j = 1; j <= N; j++) {
                        if (i != j) {
                            bestPath[i][j] = Math.min(bestPath[i][j], bestPath[i][k] + bestPath[k][j]);
                        }
                    }
                }
            }

            for (int i = 1; i <= N; i++) {
                for (int j = 1; j <= N; j++) {
                    bufferedWriter.write((bestPath[i][j] == INF ? 0 : bestPath[i][j]) + " ");
                }
                bufferedWriter.newLine();
            }
        }
    }

    static class InputReader implements AutoCloseable {

        private BufferedReader bufferedReader;

        private StringTokenizer stringTokenizer;

        public InputReader(InputStream inputStream) {
            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            stringTokenizer = null;
        }

        private String nextToken() {
            if (stringTokenizer == null || !stringTokenizer.hasMoreTokens()) {
                try {
                    stringTokenizer = new StringTokenizer(bufferedReader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }

            return stringTokenizer.nextToken();
        }

        private int nextInt() {
            return Integer.parseInt(nextToken());
        }

        @Override
        public void close() throws IOException {
            bufferedReader.close();
        }
    }
}
