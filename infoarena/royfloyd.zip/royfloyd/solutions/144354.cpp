#include<fstream>
using namespace std;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");
void citire(int&,int[100][100]);
void royfloyd(int,int[100][100]);
void afisare(int,int[100][100]);
int main()
{
	int n,mat[100][100];
	citire(n,mat);
	royfloyd(n,mat);
	afisare(n,mat);
return 0;
}
void citire(int &n,int mat[100][100])
{int i,j;
 in>>n;
  for (i=0;i<n;i++)
	  for (j=0;j<n;j++)
		  in>>mat[i][j];
 }
void royfloyd(int n,int mat[100][100])
{int i,j,k;
  for (k=0;k<n;k++)
	  for (i=0;i<n;i++)
		  for (j=0;j<n;j++)
			  if (mat[i][j]>mat[i][k]+mat[k][j])
				  mat[i][j]=mat[i][k]+mat[k][j];
 
}
void afisare(int n,int mat[100][100])
{int i,j; 
	for (i=0;i<n;i++)
     {for (j=0;j<n;j++)
		  out<<mat[i][j]<<" ";
      out<<endl;
     }
}