#include <bits/stdc++.h>
#define Nmax 105
#define INF 1e9
using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int N, dp[Nmax][Nmax];
int main()
{
    f >> N;
    for (int i = 1; i <= N; ++i)
    for (int j = 1; j <= N; ++j) {
      f >> dp[i][j];
      if (dp[i][j] == 0) dp[i][j] = INF;
    }

    for (int k = 1; k <= N; ++k)
    for (int i = 1; i <= N; ++i)
    for (int j = 1; j <= N; ++j)
      if ((i != j && j != k) && i != k)
         dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j]);

    for (int i = 1; i <= N; ++i) {
        for (int j = 1; j <= N; ++j)
            if (dp[i][j] != INF) g << dp[i][j] << " ";
            else g << "0 ";
        g << '\n';
    }

    return 0;
}
