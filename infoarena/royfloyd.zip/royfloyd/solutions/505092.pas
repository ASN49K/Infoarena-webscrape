type meret = 1..100;

var a:array[1..100,1..100] of longint;
    i,j,k,n:meret;
    f,g:text;

Begin
assign(f,'royfloyd.in');
reset(f);
readln(f,n);

 for i := 1 to n do
  for j := 1 to n do
  read(f,a[i,j]);

close(f);

 {ROY-FLOYD}
 for k := 1 to n do
  for i := 1 to n do
   for j := 1 to n do
    if (i<>j) and (k<>j) and (a[i,j]>a[i,k]+a[k,j]) then a[i,j] := a[i,k]+a[k,j];

assign(g,'royfloyd.out');
rewrite(g);

  for i := 1 to n do begin
   for j := 1 to n do
    write(g,a[i,j],' ');
   writeln(g);
  end;

close(g);
End.
