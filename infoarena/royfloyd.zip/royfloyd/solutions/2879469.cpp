#include <iostream>
#include <fstream>

using namespace std;

ifstream f ("royfloyd.in");
ofstream g ("royfloyd.out");

const int SIZE = 101;
const int INF = 0x3f3f3f3f;

int n;
int mat[SIZE][SIZE];

void Read()
{
    f >> n;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            f >> mat[i][j];
            if (mat[i][j] == 0 && i != j)
            {
                mat[i][j] = INF;
            }
        }
    }
}

void RoyFloyd()
{
    for (int k = 1; k <= n; k++)
    {
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                if (mat[i][j] > mat[i][k] + mat[k][j])
                {
                    mat[i][j] = mat[i][k] + mat[k][j];
                }
            }
        }
    }
}

void Print()
{
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            g << mat[i][j] << " ";
        }
        g << "\n";
    }
}

int main()
{
    Read();
    RoyFloyd();
    Print();
}
