#include <fstream>
#define maxn 105
#define inf 1<<30

using namespace std;

int m[maxn][maxn];
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

void royfloyd(int n) {
    for(int k = 0; k < n; k++)
        for(int i = 0; i < n; i++)
            for(int j = 0; j < n; j++) {
                if(i == j)
                    continue;

                if((m[i][j] > m[i][k] + m[k][j]) || m[i][j] == 0)
                    m[i][j] = m[i][k] + m[k][j];
            }

}

int main() {
    int n;
    in>>n;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            in>>m[i][j];


    royfloyd(n);

    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            out<<m[i][j]<<" ";
        }
        out<<"\n";
    }

    return 0;
}