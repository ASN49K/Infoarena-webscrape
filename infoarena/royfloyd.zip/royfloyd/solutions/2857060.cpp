#include <fstream>
#define V 101

using namespace std;

int d[V][V];

ifstream in ("royfloyd.in");
ofstream out ("royfloyd.out");

int main()
{
    int n;
    in >> n;
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            in >> d[i][j];
        }
    }
    for(int k=1; k<=n; k++)
    {
        for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=n; j++)
            {
                if(i!=j && k!=j && d[i][k] && d[k][j])
                {
                    if(d[i][j]==0 || d[i][j]>d[i][k]+d[k][j])
                    {
                        d[i][j]=d[i][k]+ d[k][j];
                    }
                }
            }
        }
    }
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            out << d[i][j] << " ";
            ;
        }
        out << "\n";
    }
    return 0;
}
