# include <fstream>
# define DIM 105
# define INF 1000000000
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
int d[DIM][DIM],n,i,j,k;
int main () {
    fin>>n;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++){
            fin>>d[i][j];
            if(d[i][j]==0)
                d[i][j]=INF;
        }
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if(i!=j&&i!=k&&j!=k&&d[i][j]>d[i][k]+d[k][j])
                    d[i][j]=d[i][k]+d[k][j];
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++){
            if(d[i][j]==INF)
                d[i][j]=0;
            fout<<d[i][j]<<" ";
        }
        fout<<"\n";
    }
    return 0;
}
