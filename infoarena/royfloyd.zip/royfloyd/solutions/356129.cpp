#include <cstdio>
#include <cstring>

#define FIN "royfloyd.in"
#define FOUT "royfloyd.out"
#define MAX_N 105

int G[MAX_N][MAX_N], A[MAX_N][MAX_N];

int N;

    int main ()
    {
        freopen (FIN, "r", stdin);
        freopen (FOUT, "w", stdout);
        
        scanf ("%d", &N);
        int i, j, k;
        
        for (i = 1; i <= N; ++i)
            for (j = 1; j <= N; ++j)
                scanf ("%d", A[i] + j);
                
        for (k = 1; k <= N; ++k)
            for (i = 1; i <= N; ++i)
                for (j = 1; j <= N; ++j)
                    if (i != j && (A[i][k] && A[k][j]))
                       if (!A[i][j] || A[i][j] > A[i][k] + A[k][j])
                          A[i][j] = A[i][k] + A[k][j];
                          
        for (i = 1; i <= N; ++i)
        {
            for (j = 1; j <= N; ++j)
                printf ("%d ", A[i][j]);
            printf ("\n");
        }
        
        return 0;
    }
