/*
    Look at me!
    Look at me!
    The monster inside me has grown this big!
*/

#include<fstream>
#include<iostream>
#include<cstdio>
#include<map>
#include<set>
#define FIT(a,b) for(vector<pair<int,int> >::iterator a=b.begin();a!=b.end();a++)
#define RIT(a,b) for(vector<int>::reverse_iterator a=b.end();a!=b.begin();++a)
#include<stack>
#define ROF(a,b,c) for(int a=b;a>=c;--a)
#include<vector>
#include<algorithm>
#define FOR(a,b,c) for(int a=b;a<=c;++a)
#define REP(a,b) for(register int a=0;a<b;++a)
#include<cstring>
#include<bitset>
#include<cmath>
#include<iomanip>
#include<queue>
#define debug cerr<<"OK";
#define pii pair<int,int>
#define mp make_pair
#define pb push_back
#define fi first
#define se second
#define ll long long
#define ull unsigned long long
#define eps 1.e-6
#define N 1050
using namespace std;
/*int dx[]={0,0,0,1,-1};
int dy[]={0,1,-1,0,0};*/
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int a[N][N],n;
int main ()
{
	f>>n;
	FOR(i,1,n)
	FOR(j,1,n)
	f>>a[i][j];
	FOR(k,1,n)
	FOR(i,1,n)
	FOR(j,1,n)
	a[i][j]=min(a[i][j],a[i][k]+a[k][j]);
	FOR(i,1,n)
	{
		FOR(j,1,n)
		g<<a[i][j]<<" ";
		g<<"\n";
	}
	return 0;
}
