#include <fstream>

using namespace std;

#define DIM 105

int A[DIM][DIM];

ifstream  inFile("royfloyd.in");
ofstream outFile("royfloyd.out");

int main()
{
	int N;
	inFile >> N;

	for(int i = 1; i <= N; i++){
		for(int j = 1; j <= N; j++){
			inFile >> A[i][j];
		}
	}

	for(int k = 1; k <= N; k++){
		for(int i = 1; i <= N; i++){
			for(int j = 1; j <= N; j++){
				if(i == j) continue;
				if(A[i][k] && A[k][j]){
					A[i][j] = ( ( A[i][k]+A[k][j] ) < A[i][j] )?( A[i][k]+A[k][j] ):A[i][j];
				}
			}
		}
	}

	for(int i = 1; i <= N; i++){
		for(int j = 1; j <= N; j++){
			outFile << A[i][j] << " ";
		}
		outFile << "\n";
	}
}
