#include <fstream>
#include <vector>
#include <climits>

using namespace std;

ifstream be("royfloyd.in");
ofstream ki("royfloyd.out");

int main()
{
    int n;
    be >> n;

    vector<vector<int>> v(n, vector<int>(n));

    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            be >> v[i][j];

            if(i != j && v[i][j] == 0)
            {
                v[i][j] = INT_MAX;
            }
        }
    }

    for(int k = 0; k < n; k++)
    {
        for(int i = 0; i < n; i++)
        {
            for(int j = 0; j < n; j++)
            {
                if(v[i][j] > v[i][k] + v[k][j])
                {
                    v[i][j] = v[i][k] + v[k][j];
                }
            }
        }
    }

    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
        {
            ki << v[i][j] << " ";
        }
        ki << "\n";
    }

    return 0;
}