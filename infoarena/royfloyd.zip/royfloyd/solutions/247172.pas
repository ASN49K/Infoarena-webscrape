var n,m,i,j,k,c:integer;
    a:array[1..100,1..100] of word;


begin
assign(input,'royfloyd.in');reset(input);
 readln(n);
 for i:=1 to n do
     begin
     for j:=1 to n do
         read(a[i,j]);
     readln;
     end;
 close(input);

 for k:=1 to n do
     for i:=1 to n do
         if (i<>k) and (a[i,k]<>0)then
            for j:=1 to n do
                if (i<>j) and (j<>k) and (a[k,j]<>0) and ((a[i,j]>a[i,k]+a[k,j]) or (a[i,j] = 0)) then
                   a[i,j]:=a[i,k]+a[k,j];

assign(output,'royfloyd.out'); rewrite(output);
for i:=1 to n do
    begin
    for j:=1 to n do
        	write(a[i,j],' ');
    writeln;
    end;
close(output);
end.