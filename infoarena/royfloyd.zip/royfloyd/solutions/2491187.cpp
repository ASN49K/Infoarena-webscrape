#include <bits/stdc++.h>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n,i,j,k,matrice[110][110];
int main()
{
    f>>n;
    for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
            f>>matrice[i][j];
    for(k=1; k<=n; k++)
        for(i=1; i<=n; i++)
            for(j=1; j<=n; j++)
                if(matrice[i][k]!=0 && matrice[k][j]!=0 && (matrice[i][j]>matrice[i][k]+matrice[k][j] || matrice[i][j]==0) && i!=j)
                    matrice[i][j]=matrice[i][k]+matrice[k][j];
    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++)
            g<<matrice[i][j]<<' ';
        g<<'\n' ;
    }
    return 0;
}
