#include <iostream>

using namespace std;
int n,i,j,k,a[105][105];
int main()
{
    cin>>n;
    for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
            cin>>a[i][j];
    for(k=1; k<=n; k++)
        for(i=1; i<=n; i++)
            for(j=1; j<=n; j++)
                if(a[i][k] && a[k][j] && a[i][k]+a[k][j]<a[i][j])
                    a[i][j]=a[i][k]+a[k][j];
     for(i=1;i<=n;i++)
     {
         for(j=1;j<=n;j++)
            cout<<a[i][j]<<' ';
         cout<<'\n';
     }
    return 0;
}
