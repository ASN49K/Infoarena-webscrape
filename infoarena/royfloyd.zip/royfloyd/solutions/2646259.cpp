#include<bits/stdc++.h>
using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

const int NMAX=105;

int d[NMAX][NMAX];
int g[NMAX][NMAX];

int main(){
    int n;
    fin>>n;
    for(int i=1;i<=n;++i){
        for(int j=1;j<=n;++j){
            fin>>g[i][j];
            d[i][j]=g[i][j];
        }
    }
    // for(int i=1;i<=n;++i){
    //     d[i][i]=0;
    // }
    for(int k=1;k<=n;++k)
        for(int i=1;i<=n;++i)
            for(int j=1;j<=n;++j)
                if(d[i][k] and d[k][j] and i!=j)
                    d[i][j]=min(
                        d[i][j]?d[i][k]+d[k][j]:0,
                        d[i][j]
                    );
    for(int i=1;i<=n;++i){
        for(int j=1;j<=n;++j){
            fout<<d[i][j]<<" ";
        }
        fout<<"\n";
    }
}
