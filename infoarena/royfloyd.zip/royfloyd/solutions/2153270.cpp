#include <bits/stdc++.h>
#define inf 10000005

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int n,c[105][105],d[105][105];

void rf() {
    int i,j,k;
    for (k=1;k<=n;k++)
        for (i=1;i<=n;i++)
            for (j=1;j<=n;j++)
                if (c[i][k]+c[k][j]<c[i][j]) {
                    c[i][j]=c[i][k]+c[k][j];
                    d[i][j]=d[k][j];
                }
}

int main() {
    int i,j;
    f>>n;
    for (i=1;i<=n;i++)
        for (j=1;j<=n;j++) {
            f>>c[i][j];
            if (i!=j && !c[i][j])
                c[i][j]=inf;
        }
    for (i=1;i<=n;i++)
        for (j=1;j<=n;j++)
            if (c[i][j]==inf || i==j)
                d[i][j]=0;
            else d[i][j]=i;
    rf();
    for (i=1;i<=n;i++) {
        for (j=1;j<=n;j++)
            g<<c[i][j]<<' ';
        g<<'\n';
    }
    return 0;
}
