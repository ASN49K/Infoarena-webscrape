#include <cstdio>
#define N 101

using namespace std;

short n;
int v[N][N];

int main(){

    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    scanf("%hd",&n);
    for(short i=1; i<=n; ++i)
        for(short j=1; j<=n; ++j)
            scanf("%d",&v[i][j]);

    for(short k=1; k<=n; ++k)
        for(short i=1; i<=n; ++i)
            for(short j=1; j<=n; ++j)
                if(v[i][k] != 0 && v[k][j] !=0 && (v[i][j] > v[i][k] + v[k][j]))
                    v[i][j] = v[i][k] + v[k][j];

    for(int i=1; i<=n; ++i)
    {
        for(int j=1; j<=n; ++j)
            printf("%d ",v[i][j]);
        printf("\n");
    }

    return 0;
}
