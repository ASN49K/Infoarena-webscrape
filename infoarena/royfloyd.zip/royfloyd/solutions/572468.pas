program royfloyd;

var a:array[1..100,1..100] of word;
    i,j,k,n:byte;
    f:text;

begin
  assign(f,'royfloyd.in');
  reset(f);
  readln(f,n);
  for i:=1 to n do
    begin
      for j:=1 to n do
        read(f,a[i,j]);
      readln(f);
    end;
  close(f);
  for i:=1 to n do
    for j:=1 to n do
      for k:=1 to n do
        if (i<>j) and (a[i,k] + a[k,j] < a[i,j]) then
          a[i,j]:=a[i,k] + a[k,j];
  assign(f,'royfloyd.out');
  rewrite(f);
  for i:=1 to n do
    begin
      for j:=1 to n do
        write(f,a[i,j],' ');
      writeln(f);
    end;
  close(f);
end.