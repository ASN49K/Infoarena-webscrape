#include<fstream>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int a[10000][10000];
int n;
int i,j,k;
int main()
{
    f>>n;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            f>>a[i][j];
        }
    }
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
            {
                if((a[i][j]==0||a[i][j]>a[i][k]+a[k][j])&&i!=j&&a[i][k]!=0&&a[k][j]!=0)
                {
                    a[i][j]=a[i][k]+a[k][j];
                }
            }
        }
    }
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            g<<a[i][j]<<" ";
        }
        g<<"\n";
    }
    return 0;
}
