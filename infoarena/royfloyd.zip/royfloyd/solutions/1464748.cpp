#include <iostream>
using namespace std;

int N,ponderi[101][101]={0},i,j,k;

int main()
{
//	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);

	cin>>N;
	
	for (i=0;i<N;++i)
		for (j=0;j<N;++j)
			cin>>ponderi[i][j];
	
	for	(k=0;k<N;++k)
		for (i=0;i<N;++i)
			for (j=0;j<N;++j)
			 //if( a[i][k]>0 && a[k][j]>0 && (a[i][j]==0 || a[i][j]>a[i][k]+a[k][j]) && i!=j)
			
				if ((ponderi[i][j]>ponderi[i][k]+ponderi[k][j] || ponderi[i][j]==0) && ponderi[i][k]>0 && ponderi[k][j] && i!=j)
					ponderi[i][j]=ponderi[i][k]+ponderi[k][j];
				
	for (i=0;i<N;++i)
	{
		for (j=0;j<N;++j)
			cout<<ponderi[i][j]<<" ";
		cout<<endl;
	}

}
