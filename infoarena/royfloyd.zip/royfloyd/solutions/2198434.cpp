#include <iostream>
#include <stdlib.h>
#include <fstream>

using namespace std;

int main() {
	int n;
	int a[101][101];
	ifstream f("royfloyd.in");
	f >> n;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			f >> a[i][j];
		}
	}

	for (int k = 0 ; k < n; k++){
		for (int i = 0; i < n; i++){
			for (int j = 0; j < n; j++)
				a[i][j] = min (a[i][j], a[i][k] + a[k][j]);
		}
	}

	ofstream g("royfloyd.out");
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			g << a[i][j] << " ";
		}
		g << endl;
	}
}