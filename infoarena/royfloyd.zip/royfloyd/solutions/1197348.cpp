#include <iostream>
#include <fstream>

#define max 101
using namespace std;
int n;
int a[max][max];
void read()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            scanf("%d ",&a[i][j]);
}
void solve()
{
   for (int k=1; k<=n; k++)
      for (int i=1; i<=n; i++)
         for (int j=1; j<=n; j++)
            if (a[i][k]+a[k][j]<a[i][j])
               a[i][j]=a[i][k]+a[k][j];
}
void print()
{
    for(int i=1;i<=n;i++)
        {for(int j=1;j<=n;j++)
            printf("%d ",a[i][j]);
        printf("\n");}
}
int main()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    read();
    solve();
    print();
    return 0;
}
