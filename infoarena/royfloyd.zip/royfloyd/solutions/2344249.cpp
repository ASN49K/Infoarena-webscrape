#include <fstream>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n,a[102][102];

int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            fin>>a[i][j];
    for(int k=1;k<=n;++k)
        for(int i=1;i<=n;++i)
            for(int j=1;j<=n;++j)
                if((a[i][j]>a[i][k]+a[k][j] || !a[i][j]) &&  i!=j && a[i][k] && a[k][j])
                    a[i][j]=a[i][k]+a[k][j];
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            fout<<a[i][j]<<" ";
        fout<<endl;
    }
}
