#include <fstream>
using namespace std;
ifstream cin("royfloyd.in");
ofstream cout("royfloyd.out");
const int N = 101 , NMAX = 1000001;
int cost[N][N];
int main()
{
    int i, j, k, n;
    cin >> n;
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n; j++)
        {
            cin >> cost[i][j];
        }
    }
    for (k = 1; k <= n; k++)
    {
        for (i = 1; i <= n; i++)
        {
            for (j = 1; j <= n; j++)
            {
                if (cost[i][j] > cost[i][k] + cost[k][j])
                {
                    cost[i][j] = cost[i][k] + cost[k][j];
                }
            }
        }
    }
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n; j++)
        {
            cout << cost[i][j] << ' ';
        }
        cout << "\n";
    }
   
    return 0;
}
