#include<fstream>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
#define NMAX 110
int a[NMAX][NMAX],n,i,j,k;
int main()
{
	f>>n;
	for(i=1;i<=n;++i)
		for(j=1;j<=n;++j)
			f>>a[i][j];
	for(k=1;k<=n;k++)
		for(i=1;i<=n;++i)
			if(i!=k)
				for(j=1;j<=n;++j)
					if(j!=k && i!=j)
						if(a[i][k]+a[k][j]<a[i][j])
							a[i][j]=a[i][k]+a[k][j];
	for(i=1;i<=n;++i){
		for(j=1;j<=n;++j)
			g<<a[i][j]<<' ';
		g<<'\n';
	}
	return 0;
}