#include <cstdio>
#define min(a, b) (a < b ? a : b)
#define NMAX 105

using namespace std;

int v[NMAX][NMAX];
int n;


int main()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    scanf("%d",&n);
    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= n; ++j) scanf("%d",&v[i][j]);

    for(int k = 1; k <= n; ++k)
        for(int i = 1; i <= n; ++i)
            for(int j = 1; j <= n; ++j)
            {
                if (i != j)
                {
                    if (v[i][k] !=0 && v[k][j] !=0)
                    {
                        if (v[i][j] != 0 ) v[i][j] = min(v[i][j],v[i][k]+v[k][j]);
                            else v[i][j]=v[i][k]+v[k][j];
                    }
                }
            }

    for(int i = 1; i <= n; ++i)
    {
        for(int j = 1; j <= n; ++j)
            printf("%d ",v[i][j]);
        printf("\n");
    }
    return 0;
}
