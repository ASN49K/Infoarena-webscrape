#include <bits/stdc++.h>
using namespace std;
#define ll long long
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
const int MAXN = 104;
const int MOD = 9917;
int matrix[MAXN][MAXN];
int main(){
    ios::sync_with_stdio(false);
    fin.tie(0);fout.tie(0);
    int n; fin >> n;
    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= n; ++j){
            fin >> matrix[i][j];
        }
    }
    for(int k = 1; k <= n; ++k){
        for(int i = 1; i <= n; ++i){
            for(int j = 1; j <= n; ++j){
                if(!matrix[i][k] or !matrix[j][k]) continue;
                if((!matrix[i][j] or matrix[i][j] > matrix[i][k] + matrix[k][j]) and i != j)
                    matrix[i][j] = matrix[i][k] + matrix[k][j];
            }
        }
    }
    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= n; ++j){
            fout << matrix[i][j] << " " ;
        }
        fout << '\n';
    }
    return 0;
}
