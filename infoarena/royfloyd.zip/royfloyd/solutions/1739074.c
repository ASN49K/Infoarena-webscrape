#include <stdio.h>
 
int n,k,i,j,a[1009][1009];
 
int main()
{
  FILE * in  = fopen("royfloyd.in","r");
  FILE * out = fopen("royfloyd.out","w");
 
   fscanf(in,"%d",&n); 
   for (i=0;i<n;i++)
     for (j=0;j<n;j++)
        fscanf(in,"%d",&a[i][j]);
 
     for (k=0;k<n;k++)
        for (i=0;i<n;i++)
           for (j=0;j<n;j++)
             if (a[i][k] && a[k][j] && i!=j && (a[i][k]+a[k][j]<a[i][j] || a[i][j]==0))
                 a[i][j]=a[i][k]+a[k][j];
 
    for (i=0;i<n;i++)
    {
        for (j=0;j<n;j++)
            fprintf(out,"%d ",a[i][j]);
        fprintf(out,"\n");
    }
  fclose(in);fclose(out);
    return 0;
}