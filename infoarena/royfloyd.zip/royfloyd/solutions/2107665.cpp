#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int main()
{
    int n, v[101][101];
    fin >> n;

    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            fin >> v[i][j];

    for(int k=1; k<=n; k++)
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++)
                if(i!=j&&v[i][k]&&v[k][j]&&(v[i][k]+v[k][j]<v[i][j]||!v[i][j]))
                    v[i][j]=v[i][k]+v[k][j];

    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
            fout << v[i][j] << " ";

        fout << "\n";
    }

    return 0;
}
