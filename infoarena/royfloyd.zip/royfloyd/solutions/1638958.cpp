#include <bits/stdc++.h>
using namespace std;

int n,mat[102][102];
void citire()
{
    scanf("%d",&n);
    for (int i=1;i<=n;++i)
        for (int j=1;j<=n;++j)
        scanf("%d",&mat[i][j]);
}

int main()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    citire();
    for (int k=1;k<=n;++k)
        for (int i=1;i<=n;++i)
            if (i!=k)
                for (int j=1;j<=n;++j)
                    if (i!=j && k!=j && mat[i][k] && mat[k][j] && (mat[i][k]+mat[k][j]<mat[i][j] || !mat[i][j]))
                        mat[i][j]=mat[i][k]+mat[k][j];
    for (int i=1;i<=n;++i)
    {
        for (int j=1;j<=n;++j)
            printf("%d ",mat[i][j]);
        printf("\n");
    }
    return 0;
}
