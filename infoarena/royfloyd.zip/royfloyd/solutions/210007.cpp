#include<fstream>
#include<values>
using namespace std;
int n,a[106][106];
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
void citire(){
	fin>>n;
	for(int i=0;i<n;i++)
		for(int j=0;j<n;j++){
			fin>>a[i][j];
			if(a[i][j]==0&&i!=j)
				a[i][j]=MAXINT;
}
void royfloyd(){
	for(int k=0;k<n;k++)
		for(int i=0;i<n;i++)
			for(int j=0;j<n;j++){
				int x=a[i][k]+a[k][j];
				if(a[i][j]>x)
					a[i][j]=x;
			}
}
void afisare(){
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++)
			if(a[i][j]==MAXINT)
				fout<<0<<" ";
			else
				fout<<a[i][j]<<" ";
		fout<<"\n";
	}
}
int main(){
	citire();
	royfloyd();
	afisare();
	fin.close();
	fout.close();
	return 0;
}