#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <algorithm>
#include <stack>


using namespace std;

const int INF = 1 << 30;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int matrix[105][105];
int n;

void royfloyd() {

    for (int k = 1; k <= n; ++k) {
        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= n; ++j)
                if (matrix[i][j] > matrix[i][k] + matrix[k][j])
                    matrix[i][j] = matrix[i][k] + matrix[k][j];
    }
}

int main() {
    f >> n;

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            f >> matrix[i][j];
            if (matrix[i][j] == 0 && i!=j)
                matrix[i][j] = INF;
        }
    }

    royfloyd();

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j)
            if (matrix[i][j] == INF)
                g << 0 << " ";
            else
                g << matrix[i][j] << "  ";
        g <<'\n';
    }

    f.close();
    g.close();
    return 0;
}