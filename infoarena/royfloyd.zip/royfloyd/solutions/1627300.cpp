#include <fstream>

using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int succ[101][101],a[101][101],n,i,j,k;
void load()
{
    f>>n;
    for(i=0;i<n;i++)
        for(j=0;j<n;j++) f>>a[i][j];
}
void afis()
{
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++) g<<a[i][j]<<" ";
        g<<'\n';
    }
}
int main()
{
    load();
    for(k=0;k<n;k++)
        for(i=0;i<n;i++)
            for(j=0;j<n;j++)
                    if((a[i][k]+a[k][j]<a[i][j] || a[i][j]==0 ) && a[i][k] && a[k][j] && i!=j)
                    {
                    a[i][j]=a[i][k]+a[k][j];
                    succ[i][j]=succ[i][k];
                    }
    afis();
    return 0;
}
