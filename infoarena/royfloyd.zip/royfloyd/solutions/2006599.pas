var a,b,n,m,i,j,k:longint;
    t:array[1..100,1..100] of longint;

begin
assign(input,'royfloyd.in');
reset(input);
readln(n);
for i:=1 to n do
 for j:=1 to n do
  begin
   read(t[i,j]);
  end;
 close(input);
for k:=1 to n do
 for i:=1 to n do
  for j:=1 to n do
   if t[i,j]>t[i,k]+t[k,j] then t[i,j]:=t[i,k]+t[k,j];
assign(output,'royfloyd.out');
rewrite(output);
for i:=1 to n do
 for j:=1 to n do
  if j=n then writeln(t[i,j]) else write(t[i,j],' ');
end.