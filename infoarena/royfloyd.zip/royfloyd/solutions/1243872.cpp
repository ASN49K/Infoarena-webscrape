#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

void newmatrix(const int& n, const int& m,
               vector<vector<int>>* matrix) {
  matrix->resize(n);
  for (int i = 0; i < n; ++i) {
    (*matrix)[i].resize(m);
  }
}

void royfloyd(vector<vector<int>> graph) {
  vector<vector<int>> dp(graph);
  const int inf = 1 << 30;
  for (int k = 0; k < graph.size(); ++k) {
    for (int i = 0; i < graph.size(); ++i) {
      for (int j = 0; j < graph.size(); ++j) {
        if (graph[i][k] == 0 || graph[k][j] == 0) {
          continue;
        }
        dp[i][j] = min(dp[i][k] + dp[k][j], dp[i][j]);
      }
    }
  }
  for (int i = 0; i < dp.size(); ++i) {
    for (int j = 0; j < dp.size(); ++j) {
      out<<dp[i][j]<<" ";
    }
    out<<"\n";
  }
}

int main (int argc, char const *argv[]) {
  int n;
  vector<vector<int>> graph;
  in>>n;
  newmatrix(n, n, &graph);
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j) {
      in>>graph[i][j];
    }
  }
  royfloyd(graph);
  return 0;
}
