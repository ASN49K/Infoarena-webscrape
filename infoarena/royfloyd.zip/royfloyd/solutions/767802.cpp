#include <fstream>
using namespace std;

int n,a[100][100],i,j,k;

void citire()
{
ifstream f("royfloyd.in");
f>>n;
for(i=1;i<=n;i++)
for(j=1;j<=n;j++)
f>>a[i][j];
f.close();
}

void royfloyd()
{
for(k=1;k<=n;k++)
for(i=1;i<=n;i++)
for(j=1;j<=n;j++)
if (a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j) a[i][j] = a[i][k] + a[k][j];
}

void afisare()
{
ofstream g("royfloyd.out");
for(i=1;i<=n;i++)
for(j=1;j<=n;j++)
g<<a[i][j];
g.close();
}

int main()
{
citire();
royfloyd();
afisare();
return 0;
}










