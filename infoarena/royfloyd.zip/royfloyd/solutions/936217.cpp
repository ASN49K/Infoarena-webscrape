#include <cstdlib>
#include <fstream>

using namespace std;

const int NMAX = 111;
const int oo   = 1 << 29;

int G[NMAX][NMAX];

int main()
{
	int N, i, j, k;
	ifstream in("royfloyd.in");
	ofstream out("royfloyd.out");
	
	in >> N;
	for(i = 1; i <= N; ++i)
	{
		for(j = 1; j <= N; ++j)
		{
			in >> G[i][j];
			if(!G[i][j]) G[i][j] = oo;
		}
	}
	for(k = 1; k <= N; ++k)
	{
		for(i = 1; i <= N; ++i)
		{
			if(k != i)
			{
				for(j = 1; j <= N; ++j)
				{
					if(k != j && i != j && G[i][j] > G[i][k] + G[k][j])
					{
						G[i][j] = G[i][k] + G[k][j];
					}
				}
			}
		}
	}
	for(i = 1; i <= N; ++i)
	{
		for(j = 1; j <= N; ++j)
		{
			if(oo == G[i][j]) G[i][j] = 0;
			out << G[i][j] << ' ';
		}
		out << '\n';
	}
	
	
	return EXIT_SUCCESS;
}
