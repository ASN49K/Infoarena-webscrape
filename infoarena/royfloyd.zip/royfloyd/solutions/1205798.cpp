#include<fstream>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n,a[105][105];

void read()
{
    f>>n;
      for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
          f>>a[i][j];
}

void roy_floyd()
{
    int k,i,j;
       for(k=1;k<=n;k++)
          for(i=1;i<=n;i++)
             for(j=1;j<=n;j++)
                {
                    if(i!=j&&a[i][k]!=0&&a[k][j]!=0&&(a[i][k]+a[k][j]<a[i][j])) a[i][j]=a[i][k]+a[k][j];
                }
}

void write()
{
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        g<<a[i][j]<<" ";
        g<<"\n";
    }
}

int main()
{
    read();
    roy_floyd();
    write();

    return 0;
}
