#include <fstream>
#define INF 100000000
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
int c[101][101];
int main()
{
    int n, k, i, j;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            fin>>c[i][j];
            if(i!=j&&c[i][j]==0)
            {
                c[i][j]=INF;
            }
        }
    }
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
            {
                if(c[i][j]>c[i][k]+c[k][j])
                {
                    c[i][j]=c[i][k]+c[k][j];
                }
            }
        }
    }
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            fout<<c[i][j]<<" ";
        }
        fout<<"\n";
    }
    return 0;
}
