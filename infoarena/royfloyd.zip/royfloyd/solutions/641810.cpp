#include<stdio.h>
#define maxn 128
int v[ maxn ][ maxn ];

int main()
{
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	int n;
	scanf("%d", &n);
	for( int i = 1; i <= n; ++i) 
		for( int j = 1; j <= n; ++j)
			scanf("%d", &v[i][j]);
	
	for( int i = 1; i <= n; ++i)
		for( int k = 1; k <= n; ++k)
			for( int j = 1; j <= n; ++j)
				if( v[i][k] + v[k][j] < v[i][j])
					v[i][j] = v[i][k] + v[k][j];
	for( int i = 1; i <= n; ++i) 
	{
		for( int j = 1; j < n; ++j)
			printf("%d ", &v[i][j]);
		printf("%d\n", v[i][n]);
	}
	
	
	
	return 0;
}
