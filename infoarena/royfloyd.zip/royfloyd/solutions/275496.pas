const nmax=100;
      inf=maxint div 2;
type mat=array [1..nmax,1..nmax] of real;
     mult=set of byte;
var c:mat;
    d:array [1..nmax,1..nmax] of mult;
    i,j,n,m,x,y,k:longint;
    ct:real;
    f,g:text;
begin
assign(f,'royfloyd.in');
reset(f);
assign(g,'royfloyd.out');
rewrite(g);
read(f,n);
for i:=1 to n do begin
                 for j:=1 to n do c[i,j]:=inf;
                 c[i,i]:=0;
                 end;
for i:=1 to n do
    for j:=1 to n do begin
                     read(f,c[i,j]);
                     end;
close(f);
for i:=1 to n do
    for j:=1 to n do if (c[i,j]<>inf) and (i<>j) then d[i,j]:=[i]
                                                 else d[i,j]:=[];
for i:=1 to n do
    for j:=1 to n do
        for k:=1 to n do if c[i,k]+c[k,j]<c[i,j] then begin
                                                      d[i,j]:=d[k,j];
                                                      c[i,j]:=c[i,k]+c[k,j];
                                                      end
                                                 else  if c[i,k]+c[k,j]=c[i,j] then d[i,j]:=d[i,j]+d[k,j];
for i:=1 to n do  begin
    for j:=1 to n do if c[i,j]=inf then write(g,0,' ')
                                   else if (i<>j) and (d[i,j]<>[]) then write(g,trunc(c[i,j]),' ')
                                                                   else if j=i then write(g,0,' ');
    writeln(g);
    end;
close(g);
end.
