/// nu stiu decat dijkstra :))))

#include<bits/stdc++.h>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n, cost[102][102], sol[102][102];
int ax[102];
struct cmp
{
    bool operator()(int a, int b)
    {
        return ax[a] > ax[b];
    }
};
priority_queue<int, vector<int>, cmp>q;
bool viz[102][102];
vector<int>v[102];
void dijkstra(int nod)
{
    for(int i = 1; i <= n; ++i)
        ax[i] = (1<<30);
    ax[nod] = 0;
    q.push(nod);
    while(!q.empty())
    {
        int x = q.top();
        q.pop();
        if(viz[nod][x])
            continue;
        viz[nod][x] = 1;
        for(int i = 0; i < v[x].size(); ++i)
        {
            int vecin = v[x][i];
            if(ax[x] + cost[x][vecin] < ax[vecin])
                ax[vecin] = ax[x] + cost[x][vecin], q.push(vecin);
        }
    }
    for(int i = 1; i <= n; ++i)
        if(ax[i] == (1<<30))
            sol[nod][i] = 0;
        else
            sol[nod][i] = ax[i];
}
int main()
{
    f >> n;
    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= n; ++j)
        {
            f >> cost[i][j];
            if(cost[i][j] != 0)
                v[i].push_back(j);
        }
    for(int i = 1; i <= n; ++i)
        dijkstra(i);
    for(int i = 1; i <= n; ++i)
    {
        for(int j = 1; j <= n; ++j)
            g << sol[i][j] << " ";
        g << '\n';
    }
    return 0;
}
