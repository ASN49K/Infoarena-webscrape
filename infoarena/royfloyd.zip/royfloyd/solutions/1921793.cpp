#include <iostream>
#include <cstdio>
#define inf 0x3f3f3f3f

using namespace std;

int n,mat[105][105];

void afis()
{
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            printf("%d ",mat[i][j]);
        }
        printf("\n");
    }
}

void parcurgere()
{
    for(int k = 1; k <= n; k++)
    {
        for(int i = 1; i <= n; i++)
        {
            for(int j = 1; j <= n; j++)
            {
                if(mat[i][k] + mat[k][j] < mat[i][j])
                {
                    mat[i][j] = mat[i][k] + mat[k][j];
                }
            }
        }
    }
}

void citire()
{
    scanf("%d\n",&n);

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            scanf("%d ",&mat[i][j]);



            if(!mat[i][j])
            {
                mat[i][j]=inf;
            }
        }
        scanf("\n");

    }

    parcurgere();
    afis();
}

int main()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);

    citire();

    return 0;
}
