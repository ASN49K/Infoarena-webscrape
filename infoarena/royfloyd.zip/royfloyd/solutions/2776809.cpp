#include <iostream>
#include <bits/stdc++.h>
using namespace std;
ifstream fin ("royfloyd.in");
ofstream fout ("royfloyd.out");
const int NMAX=105;
int dist[NMAX][NMAX];
int main()
{
    int i,j,k,n;
    fin>>n;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            fin>>dist[i][j];
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if(dist[i][j]>dist[i][k]+dist[k][j])
                    dist[i][j]=dist[i][k]+dist[k][j];
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
            fout<<dist[i][j]<<" ";
        fout<<"\n";
    }
    return 0;
}
