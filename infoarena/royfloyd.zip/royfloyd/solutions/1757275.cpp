#include <iostream>
#include <fstream>
#include <climits>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int a[102][102];
int n;

void citire()
{
    int q,i,j;
    f>>n;
    for (i=1; i<=n; i++)
        for (j=1; j<=n; j++)
        {
            f>>a[i][j];
        }
}

void constrdrum()
{
    int i,j,k;
    for (k=1; k<=n; k++)
        for (i=1; i<=n; i++)
        for (j=1; j<=n; j++)
             if (a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j) a[i][j] = a[i][k] + a[k][j];
           /* if (((a[i][j]>a[i][k]+a[k][j])||(a[i][j]==0))&&(i!=j)&&(a[i][k]!=0)&&(a[k][i]!=0))
                a[i][j]=a[i][k]+a[k][j];*/
}

int main()
{
    citire();
    constrdrum();
    int i,j;
    for (i=1; i<=n; i++)
    {
        for (j=1; j<=n; j++)
            g<<a[i][j]<<" ";
        g<<"\n";

    }

    return 0;
}
