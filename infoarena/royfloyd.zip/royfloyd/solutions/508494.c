#include<stdio.h>
#include<stdlib.h>
#include<limits.h>

int path[100][100], n;

int main() {
	freopen("royfloyd.in", "r", stdin);
	freopen("royfloyd.out", "w", stdout);
	int i, j, k;
	scanf("%d", &n);
	for(i = 0; i < n; i++) {
		for(j = 0; j < n; j++) {
			scanf("%d", &path[i][j]);
			if(path[i][j] == 0 && i != j) {
				path[i][j] = INT_MAX;
			} 
			
		}
	}
	
	for(k = 0; k < n; k++) {
		for(i = 0; i < n; i++) {
			for(j = 0; j < n; j++) {
				path[i][j] = (path[i][j] < path[i][k] + path[k][j] ? path[i][j] : path[i][k] + path[k][j]);
			}
		}
	}
	
	for(i = 0; i < n; i++) {
		for(j = 0; j < n - 1; j++) {
			printf("%d ", path[i][j]);
		}
		printf("%d\n", path[i][n-1]);
	}
	
	return 0;
}
