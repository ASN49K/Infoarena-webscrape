#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#define debug(x) cerr << #x << " " << x << "\n"
#define debug_with_space(x) cerr << #x << " " << x << " "

using namespace std;
using namespace __gnu_pbds;
typedef long long ll;
typedef pair <ll, ll> pii;
typedef pair <ll, pii> piii;
typedef tree <pii, null_type, less <pii>, rb_tree_tag, tree_order_statistics_node_update> OST;

const ll NMAX = 200001;
const ll INF = 2e9;
const ll MOD = 1000000007;
const ll BLOCK = 101;
const ll nr_of_bits = 20;

int dp[101][101];

int main() {
    ifstream cin("royfloyd.in");
    ofstream cout("royfloyd.out");
    ios_base::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n, i, j;
    cin >> n;
    for(i = 1;  i<= n;i++){
        for(j = 1; j <= n; j++){
            cin >> dp[i][j];
            if(i != j && !dp[i][j])
                dp[i][j] = 1e9;
        }
    }
    int k;
    for(k = 1; k <= n; k++){
        for(i = 1; i <= n; i++){
            for(j = 1; j <= n; j++){
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j]);
            }
        }
    }
     for(i = 1;  i<= n;i++){
        for(j = 1; j <= n; j++){
            cout << dp[i][j] << " ";
        }
        cout << "\n";
    }
    return 0;
}
