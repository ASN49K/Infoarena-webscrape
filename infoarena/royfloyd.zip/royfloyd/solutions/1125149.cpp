#include<cstdio>
#include<algorithm>
#include<climits>

using namespace std;

int a[100][100];
int sol[100][100];

int main()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    
    int n,max;
    max=INT_MAX/2-1;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            scanf("%d",&a[i][j]);
    
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            if(i!=j)
                sol[i][j]=max;
    
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                sol[i][j]=min(sol[i][j],a[i][k]+a[k][j]);
    
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            printf("%d ",sol[i][j]);
        printf("\n");
    }
    
    return 0;
}