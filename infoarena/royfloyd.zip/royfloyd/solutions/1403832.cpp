#include <fstream>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n, dist[100][100];

void royFloyd()
{
    for(int k=1; k<=n; k++)
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++)
                if(dist[i][j]>dist[i][k]+dist[k][j])
                dist[i][j]=dist[i][k]+dist[k][j];
}

int main()
{
    fin >> n;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            fin >> dist[i][j];

    royFloyd();

    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
            fout << dist[i][j] << ' ';
        fout <<'\n';
    }

    return 0;
}
