#include <iostream>
#include <fstream>
using namespace std;

int n, m;
int** M;

void read() {
    fstream fin("royfloyd.in", ios::in);
    fin >> n;

    M = new int*[n];
    for (int i = 0; i < n; i++) {
        M[i] = new int[n];
        for (int j = 0; j < n; j++) {
            fin >> M[i][j];
        }
    }

    fin.close();
}

void roy_floyd() {
    for (int x = 0; x < n; x++) {
        for (int y = 0; y < n; y++) {
            for (int k = 0; k < n; k++) {
                if ((M[x][y] > M[x][k] + M[k][y] || !M[x][y]) && (M[x][k] > 0) && (M[k][y] > 0) && (x != k) && (y != k)) {
                    M[x][y] = M[x][k] + M[k][y];
                }
            }
        }
    }
}

void write() {
    fstream fout("royfloyd.out", ios::out);
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fout << M[i][j] << " ";
        }
        fout << "\n";
    }

    fout.close();
}

int main() {
    read();
    roy_floyd();
    write();
    return 0;
}