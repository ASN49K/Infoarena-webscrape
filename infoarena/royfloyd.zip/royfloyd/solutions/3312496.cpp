#include <bits/stdc++.h>

int main() {
#ifndef LOCAL
  freopen("royfloyd.in", "r", stdin);
  freopen("royfloyd.out", "w", stdout);
#endif
  int N;
  std::cin >> N;
  std::vector<std::vector<int>> G(N, std::vector<int>(N));
  for (int u = 0; u < N; ++u) {
    for (int v = 0; v < N; ++v) {
      std::cin >> G[u][v];
      if (G[u][v] == 0) {
        G[u][v] = INT_MAX;
      }
    }
  }
  for (int w = 0; w < N; ++w) {
    for (int u = 0; u < N; ++u) {
      for (int v = 0; v < N; ++v) {
        if (G[u][w] != INT_MAX && G[w][v] != INT_MAX) {
          G[u][v] = std::min(G[u][v], G[u][w] + G[w][v]);
        }
      }
    }
  }
  for (int u = 0; u < N; ++u) {
    if (u) {
      std::cout << "\n";
    }
    for (int v = 0; v < N; ++v) {
      if (v) {
        std::cout << " ";
      }
      std::cout << (G[u][v] == INT_MAX ? 0 : G[u][v]);
    }
  }
  return 0;
}