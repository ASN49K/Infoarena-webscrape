#include<cstdio>
void read(),solve();
int n,a[105][105],i,j;
int main()
{
	read();
	solve();
	return 0;
}
void read()
{
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			scanf("%d",&a[i][j]);
}
void solve()
{
	int k;
	for(k=1;k<=n;k++)
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				if(a[i][k]&&a[k][j]&&(a[i][j]>a[i][k]+a[k][j]||!a[i][j])&&i!=j)
					a[i][j]=a[i][k]+a[k][j];
				for(i=1;i<=n;i++)
				{
					for(j=1;j<=n;j++)
						printf("%d ",a[i][j]);
					printf("\n");
				}
}
