#include <iostream>
#include <cstdio>
#define NMAX 101
#define VALMAX 1000001
using namespace std;
int A[NMAX][NMAX];

int read(){
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);
    int N;
    cin>>N;
    for(int i = 1; i <= N; i++)
        for(int j=1; j<=N; j++){
            cin>>A[i][j];
            if(i!=j && A[i][j] == 0)
                A[i][j] = VALMAX;
        }
    return N;
}

void Roy_Floyd(int N){
    for(int k=1; k<=N; k++)
        for(int i=1; i<=N; i++)
            for(int j=1; j<=N; j++)
                if(i!=j && A[i][j] > A[i][k] + A[k][j] )
                    A[i][j] = A[i][k] + A[k][j];
}

void write(int N){
    for(int i=1; i<=N; i++){
        for(int j=1; j<=N; j++)
            if(A[i][j] != VALMAX)
                cout<<A[i][j]<<" ";
            else
                cout<<"0 ";
        cout<<'\n';
    }
}
int main()
{
    int n = read();
    Roy_Floyd(n);
    write(n);
    return 0;
}
