#include <fstream>
#define nmax 103
#define inf 0x3f3f3f3f

using namespace std;

int a[nmax][nmax],n;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

void citire()
{
    fin>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
        {
            fin>>a[i][j];
            if(a[i][j]==0)
                a[i][j]=inf;
        }
}

void rezolv()
{
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                if(a[i][k]+a[k][j]<a[i][j])
                    a[i][j]=a[i][k]+a[k][j];
}

void afisare()
{
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            if(a[i][j]==inf||i==j)
                fout<<0<<" ";
            else
                fout<<a[i][j]<<" ";
        fout<<"\n";
    }
}

int main()
{
    citire();
    rezolv();
    afisare();
    return 0;
}
