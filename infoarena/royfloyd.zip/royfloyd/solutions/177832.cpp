#include<stdio.h>
#define INF 1000000
int n,a[113][113];
void citire(){
	scanf("%d",&n);
	for(int i =1;i<=n;++i)
		for(int j=1;j<=n;++j){
			scanf("%d",&a[i][j]);
			if(a[i][j]==0)
				a[i][j]=INF;
		}
	for(int i=1;i<=n;++i)
		a[i][i]=0;
}
int main(){
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	citire();
	for(int k=1;k<=n;++k)
		for(int i=1;i<=n;++i)
			for(int j=1;j<=n;++j)
				if(a[i][j]>a[i][k]+a[k][j])
					a[i][j]=a[i][k]+a[k][j];
	for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j)
			printf("%d ",a[i][j] !=INF ? a[i][j] : 0);
		printf("\n");
	}
	return 0;
}
