#include <fstream>
using namespace std;

ifstream g("royfloyd.in");
ofstream gg("royfloyd.out");

#define INF 1000
int N,Mat[105][105];
void Read(){
    g>> N;
    for(int i=1; i<=N; i++){
        for(int j=1; j<=N; j++){
            g>> Mat[i][j];
        }
    }
}

void RoyFloyd(){
    for(int k=1; k<=N; k++){
        for(int i=1; i<=N; i++){
            for(int j=1; j<=N; j++){
                if((Mat[i][j] > Mat[i][k] + Mat[k][j] || Mat[i][j] == 0) && Mat[k][j] && Mat[i][k] && i != j)
                   Mat[i][j] =  Mat[i][k] + Mat[k][j];
            }
        }
    }
}

void Write(){
    for(int i=1; i<=N; i++){
        for(int j=1; j<=N; j++){
            gg<< Mat[i][j]<< " ";
        }
    gg<<"\n";
    }
}
int main()
{
    Read();
    RoyFloyd();
    Write();
    return 0;
}
