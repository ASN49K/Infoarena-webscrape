#include<fstream>

using namespace std;

ifstream in("rf.in");
ofstream out("rf.out");


int n,a[101][101];

int main(){
	int i,j,k;
	in>>n;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			in>>a[i][j];
	for(k=1;k<=n;k++)
			for(i=1;i<=n;i++)
				for(j=1;j<=n;j++)
					if(i!=k&&i!=j&&j!=k)
							if(a[i][k]&&a[k][j]){
									int temp=a[i][k]+a[k][j];
									if(temp<a[i][j]||a[i][j]==0)
										a[i][j]=temp;
							}
							for(i=1;i<=n;i++){
								for(j=1;j<=n;j++)
									out<<a[i][j]<<" ";
								out<<"\n";
							}
							return 0;
}
		