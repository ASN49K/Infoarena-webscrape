#include <iostream>
#include <climits>
#include <fstream>

using namespace std;

 ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

const int NLIM = 100 + 10;
const int INF = INT_MAX - 1;

int N;
int mat[NLIM][NLIM];


int main()
{
    fin >> N;
    for( int i = 0; i < N; ++i )
        for( int j = 0; j < N; ++j )
        {
            fin >> mat[i][j];

            if( mat[i][j] == 0 )
                mat[i][j] = INF;
        }

    for( int k = 0; k < N; ++k )
        for( int i = 0; i < N; ++i )
            for( int j = 0; j < N; ++j )
                if( mat[i][k] + mat[k][j] < mat[i][j] )
                    mat[i][j] = mat[i][k] + mat[k][j];

    for( int i = 0; i < N; ++i )
    {
        for( int j = 0; j < N; ++j )
            fout << mat[i][j] << " ";
        fout << "\n";
    }
    return 0;
}
