#include <bits/stdc++.h>
#include <iostream>

using namespace std;

ifstream in ("royfloyd.in");
ofstream out ("royfloyd.out");

int graf[1000][1000];
int n;

void Floyd_Warshall()
{

    for(int k = 1; k <= n; k++)
    {
        for(int i = 1; i <= n; i++)//sursa
        {
            for(int j = 1; j <= n; j++)//destinatie
            {
                //daca k e un nod intermediar in cel mai scurt drum de la i la j
                if (graf[i][k] + graf[k][j] < graf[i][j])
                {
                    graf[i][j] = graf[i][k] + graf[k][j];

                }
            }
        }
    }

}

int main()
{

    in>>n;
    int x;

    for(int i = 1 ; i<= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            in>>x;

            if(x == 0 && i!=j)
                graf[i][j] = 1e9;
            else
            graf[i][j] = x;



        }

    }


    Floyd_Warshall();

    for(int i = 1 ; i<= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            if(graf[i][j] == 1e9)

                out<<"0 ";
           else
                out<<graf[i][j]<<" ";

        }
        out<<"\n";

    }

}
