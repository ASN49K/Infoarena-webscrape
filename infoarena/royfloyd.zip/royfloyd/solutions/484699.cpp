#include <cstdio>

const int MAX_N = 102;
const int INF = 0x3f3f3f3f;

int n;
int a[MAX_N][MAX_N];

int main()
{
	freopen("royfloyd.in", "r", stdin);
	freopen("royfloyd.out", "w", stdout);

	scanf("%d", &n);

	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
		{
			scanf("%d", &a[i][j]);

			if (a[i][j] == 0 && i - j)
				a[i][j] = INF;
		}

	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			for (int k = 1; k <= n; ++k)
				if (a[i][k] + a[k][j] < a[i][j])
					a[i][j] = a[i][k] + a[k][j];

	for (int i = 1; i <= n; ++i, printf("\n"))
		for (int j = 1; j <= n; ++j)
			printf("%d ", (a[i][j] <= INF) ? a[i][j] : INF);
}
