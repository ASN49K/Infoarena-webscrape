#include <fstream>

const size_t MAX_N = 100;

int N, M[MAX_N][MAX_N];

int main()
{
    std::ifstream fin("royfloyd.in");
    std::ofstream fout("royfloyd.out");

    fin >> N;
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
            fin >> M[i][j];

    for (int k = 0; k < N; ++k)
        for (int i = 0; i < N; ++i)
            for (int j = 0; j < N; ++j)
                // Check if there is a path between (i, k) and (k, j).
                if (i != j && M[i][k] != 0 && M[k][j] != 0)
                    // Update only if there was no path or the new one is
                    // better.
                    if (M[i][j] == 0 || M[i][k] + M[k][j] < M[i][j])
                        M[i][j] = M[i][k] + M[k][j];

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j)
            fout << M[i][j] << ' ';
        fout << '\n';
    }

    return 0;
}
