#include <bits/stdc++.h>

using namespace std;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");
const int nmax=101, inf=1e9;
int a[nmax][nmax], n, cost[nmax][nmax];
int main()
{
    in>>n;
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            in>>a[i][j];
            cost[i][j]=a[i][j];
            if(i!=j && a[i][j]==0)
            {
                cost[i][j]=inf;//nu eista muchie
            }
        }
    }

    for(int k=1; k<=n; k++)
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++)
                cost[i][j]=min(cost[i][j], cost[i][k]+cost[k][j]);


    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            if(cost[i][j]==inf)
                out<<0<<" ";
            else
                out<<cost[i][j]<<" ";
        }
        out<<'\n';
    }
}
