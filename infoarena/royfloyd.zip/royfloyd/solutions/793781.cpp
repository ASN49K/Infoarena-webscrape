#include <stdio.h>
#define NMAX 105
int n,A[NMAX][NMAX];
void read()
{
	scanf("%d",&n);
	int i,j;
	for (i=1; i<=n; i++)
		for (j=1; j<=n; j++)
			scanf("%d",&A[i][j]);
}
inline int min(int x,int y)
{
	return x<y ? x : y;
}
void solve()
{
	int i,j,k;
	for (k=1; k<=n; k++)
		for (i=1; i<=n; i++)
			for (j=1; j<=n; j++)
				if (A[i][j]!=0 && A[i][k] && A[k][j])
					A[i][j]=min(A[i][j],A[i][k]+A[k][j]);
	
	for (i=1; i<=n; i++)
	{
		for (j=1; j<=n; j++)
			printf("%d ",A[i][j]);
		printf("\n");
	}
}
int main()
{
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	read();
	solve();
	return 0;
}
