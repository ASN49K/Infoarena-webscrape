#include <cstdio>
#define NMax 121

long a[NMax][NMax],n;

int main()
{
	freopen("royfloyd.in","rt",stdin);
	freopen("royfloyd.out","wt",stdout);
	
	scanf("%ld",&n);
	
	for(long i=1;i<=n;i++)
		for(long j=1;j<=n;j++)
			scanf("%ld",&a[i][j]);
	
	for(long i=1;i<=n;i++)
		for(long j=1;j<=n;j++)
			for(long k=1;k<=n;k++)
				if(a[i][k]&&a[k][j])
					if(!a[i][j]||a[i][j]>a[i][k]+a[k][j])
						if(i!=j)
							a[i][j]=a[i][k]+a[k][j];
	
	for(long i=1;i<=n;i++)
	{
		for(long j=1;j<=n;j++)
			printf("%ld ",a[i][j]);
		printf("\n");
	}
	return 0;
}