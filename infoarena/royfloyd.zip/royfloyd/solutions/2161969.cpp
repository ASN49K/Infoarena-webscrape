#include <iostream>
#include <fstream>
#define inf 999999999;

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int ma[101][101], n;
int main()
{


    fin>>n;
    for (int i=1;i<=n;i++)
        for (int j=1;j<=n;j++)
           {
               fin>>ma[i][j];
           if(ma[i][j]==0 && i!=j)
            ma[i][j]=inf;
           }

    for(int k=1;k<=n;k++)
    for(int i=1;i<=n;i++)
    for(int j=1;j<=n;j++)
        if(ma[i][j]>ma[i][k]+ma[k][j])
        ma[i][j]=ma[i][k]+ma[k][j];

    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            fout<<ma[i][j]<<" ";
       fout<<endl;
    }
    return 0;
}
