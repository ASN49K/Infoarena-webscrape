#include<fstream.h>

long a[101][101],n,i,j,m,k;
int x,y,z;

int main(){
	fstream fi("royfloyd.in",ios::in);
	fstream fo("royfloyd.out",ios::out);
	fi>>n;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++) {
			fi >> a[i][j];
			if (a[i][j] == 0)
				a[i][j] = 1000000;
		}
	for (k=1;k<=n;k++){
		for (i=1;i<=n;i++)
			for (j=1;j<=n;j++)
				if (i!=j && a[i][k]+a[k][j]<a[i][j])
					a[i][j]=a[i][k]+a[k][j];
	}
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++)
			if (a[i][j] < 1000000)
				fo<<a[i][j]<<' ';
			else
				fo << 0 << ' ';
		fo<<endl;
	}
	fi.close(); fo.close();
	return 0;
}