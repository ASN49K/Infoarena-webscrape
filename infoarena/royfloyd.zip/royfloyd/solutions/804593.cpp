#include<fstream>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");



int n;
int a[101][101];

void citire()
{
 f>>n;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
        {
            f>>a[i][j];
        }
}

void floydWarshall()
{
    for(int k = 1 ; k <=n; k++)
    {
        for(int i = 1; i<=n;i++)
        {
            for(int j = 1 ; j <=n; j++)
            {
                if(a[i][k] != 0 && a[k][j] != 0 && (a[i][j] > a[i][k] + a[k][j] || a[i][j] == 0) && i != j)
                a[i][j] = a[i][k] + a[k][j];
            }
        }
    }

    for(int i =1 ; i <= n;i++)
    {
        for(int j = 1 ; j <= n; j++)

           g<<a[i][j]<<" ";
           g<<"\n";

}
}
int main()
{
    citire();
    floydWarshall();
    return 0;
}
