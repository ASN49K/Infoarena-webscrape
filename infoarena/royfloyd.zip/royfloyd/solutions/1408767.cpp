#include <fstream>
#define INF 0x3f3f3f3f
using namespace std;

ifstream is("royfloyd.in");
ofstream os("royfloyd.out");

int n, m;
int c[105][105];

int main()
{
    is >> n;
    int x;
    for(int i = 1; i <=n; ++i)
		for(int j = 1; j <= n; ++j)
		{
			if(i != j)
			{
				c[i][j] = INF;
			}
		}
    for(int i = 1; i <= n; ++i)
    {
       for(int j = 1; j <= n; ++j)
       {
           is >> x;
           c[i][j] = x;
       }
    }
    for(int k = 1; k<= n; ++k)
        for(int i = 1; i <= n; ++i)
            for(int j = 1; j <= n; ++j)
                if(i != j && c[i][j] > c[i][k] + c[k][j])
                    c[i][j] = c[i][k] + c[k][j];



    for(int i = 1; i <= n; ++i)
    {
        for(int j = 1; j <= n; ++j)
        {
            if(c[i][j] != INF)
                os << c[i][j] << ' ';
            else
                os << "-1" << ' ';
        }
        os << '\n';
    }
    is.close();
    os.close();
    return 0;
}

