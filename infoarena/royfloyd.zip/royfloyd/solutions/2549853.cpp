#include <iostream> 
#include <fstream>
using namespace std; 

#define N 100  

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");
/*Se da un graf orientat cu N noduri, memorat prin matricea ponderilor.
Sa se determine pentru orice pereche de noduri x si y lungimea minima 
a drumului de la nodul x la nodul y si sa se afiseze matricea drumurilor minime. 
Prin lungimea unui drum intelegem suma costurilor arcelor care-l alcatuiesc.
*/

int n, a[N][N];
 
void Roy_Warshall(int n, int a[][N]){
    for(int k = 1; k <= n; ++k)
        for(int i = 1; i <= n; ++i)
            for(int j = 1; j <= n; ++j)
                if(a[i][k] && a[k][j] && i != j && (a[i][j] == 0 || a[i][k] + a[k][j] < a[i][j] ))
                    a[i][j] = a[i][k] + a[k][j];
}
 
int main(){
    in>>n;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            in>>a[i][j];
    Roy_Warshall(n,a);
    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++)
            out<<a[i][j]<<" ";
        out<<"\n";
    }
}