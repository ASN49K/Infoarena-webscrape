#include<iostream>
#include<cstdio>
using namespace std;
int a[100][100],n;
int main(){
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=n;++j)
			scanf("%d",&a[i][j]);
	for(int k=1;k<=n;++k)
		for(int i=1;i<=n;++i)
			for(int j=1;j<=n;++j)
			if( a[i][k] && a[k][j] && (a[i][j]>a[i][k]+a[k][j] || a[i][j]==0) && i!=j)
				a[i][j]=a[i][k]+a[k][j];
	
	for(int i=1;i<=n;++i){
		for(int j=1;j<=n;++j)
			printf("%d ",a[i][j]);
		printf("\n");
		}
	return 0;
}