    #include <bits/stdc++.h>
    using namespace std;

    ifstream in("royfloyd.in");
    ofstream out("royfloyd.out");
    vector<pair<int,int>> a[110];
    int v[110][110],c[110][110],s;
    queue<int> q;
    int i,j,k,n,x;
    void parcurgere()
    {
        int d,s,f;
        while(!q.empty()){
            d=q.front();
            q.pop();
            for(auto b:a[d]){
                s=b.second;
                f=b.first;
                for(k=1;k<=n;k++)
                    if(c[d][f]>c[k][f]+c[d][k]||c[d][f]==0)
                        c[d][f]=c[k][f]+c[d][k];
            }
        if(d<n)
            q.push(d+1);
        }
    }

    int main()
    {
        in>>n;
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++){
                in>>x;
                c[i][j]=x;
                a[i].push_back(make_pair(j,x));
        }
        for(i=1;i<=n;i++){
            sort(a[i].begin(),a[i].end());
        }
        q.push(1);
        parcurgere();
        for(i=1;i<=n;i++){
            for(j=1;j<=n;j++)
                if(i==j)
                    out<<"0 ";
                else
                    out<<c[i][j]<<" ";
            out<<endl;
        }
    }
