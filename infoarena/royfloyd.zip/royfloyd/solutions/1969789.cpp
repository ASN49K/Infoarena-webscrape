#include <iostream>
#include <fstream>
using namespace std;

ifstream fin ("royfloyd.in");
ofstream fout ("royfloyd.out");

const int maxn = 105;
int G[maxn][maxn];
int n;

int main() {
    ios_base :: sync_with_stdio(false);
    fin >> n;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            fin >> G[i][j];
        }
    }
    for (int k = 1; k <= n; k++) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                if (G[i][k] > 0 && G[k][j] > 0 && i != j && (G[i][k] + G[k][j] < G[i][j] || G[i][j] == 0)) {
                    G[i][j] = G[i][k] + G[k][j];
                }
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            fout << G[i][j] << " ";
        }
        fout << "\n";
    }
    return 0;
}
