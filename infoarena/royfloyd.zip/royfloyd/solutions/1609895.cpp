#include <cstdio>
#include <algorithm>
using namespace std;

int n, a[102][102], b[102][102];

int main()
{
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);


    scanf("%d", &n);
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
        scanf("%d", &a[i][j]);

    for(int k=1; k<=n; k++)
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++)
               {
                   if(i==j || i==k || j==k || a[i][k]==0 || a[k][j]==0) continue;
                   if(a[i][j]==0 || a[i][k]+a[k][j]< a[i][j])
                a[i][j]=a[i][k]+a[k][j];
               }
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
            printf("%d ", a[i][j]);

        printf("\n");
    }

    return 0;
}
