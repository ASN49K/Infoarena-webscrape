#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n;
vector<vector<int>> matrix(101, vector<int>(101, 0));

void floydwarshall()
{
   for (int k = 1; k <= n; k++)
      for (int i = 1; i <= n; i++)
         for (int j = 1; j <= n; j++)
         {
            if (!matrix[i][j] || matrix[i][j] > matrix[i][k] + matrix[k][j])
            {
               matrix[i][j] = matrix[i][k] + matrix[k][j];
            }
         }
   for (int i = 1; i <= n; i++)
   {
      for (int j = 1; j <= n; j++)
         fout << matrix[i][j] << " ";
      fout << endl;
   }
}

void read()
{
   fin >> n;
   for (int i = 1; i <= n; i++)
      for (int j = 1; j <= n; j++)
         fin >> matrix[i][j];
}

int main()
{
   read();
   floydwarshall();
   return 0;
}