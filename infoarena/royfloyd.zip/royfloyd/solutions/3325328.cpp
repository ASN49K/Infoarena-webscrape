//
// Created by h4rapa1b on 11/25/25.
//
#include <fstream>
#include <vector>

using namespace std;

const int INF = 2000000000;

int main() {
    ifstream fin("royfloyd.in");
    ofstream fout("royfloyd.out");

    int n;
    fin >> n;
    int graph[101][101];

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            fin >> graph[i][j];
            if (graph[i][j] == 0 && i != j) {
                graph[i][j] = INF;
            }
        }
    }

    // Algoritmul Roy-Floyd
    // nod intermediar
    for (int k = 0; k < n; ++k) {
        // nod sursa
        for (int i = 0; i < n; ++i) {
            // nod destinatie
            for (int j = 0; j < n; ++j) {
                if (graph[i][k] != INF && graph[k][j] != INF) {
                    if (graph[i][k] + graph[k][j] < graph[i][j]) {
                        graph[i][j] = graph[i][k] + graph[k][j];
                    }
                }
            }
        }
    }

    // afisam matricea distantelor
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            if (graph[i][j] == INF) {
                fout << 0 << " ";
            } else {
                fout << graph[i][j] << " ";
            }
        }
        fout << "\n";
    }

    fin.close();
    fout.close();
    return 0;
}