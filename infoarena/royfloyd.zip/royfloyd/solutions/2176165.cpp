#include <fstream>
#define LMAX 1020
#define INF 99999999

using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");


int n;
int a[LMAX][LMAX];

int main()
{
    fin>>n;
    for (int i=1;i<=n;i++)
        for (int j=1;j<=n;j++)
            {
             fin>>a[i][j];
             if (!a[i][j]&&i!=j)
                 a[i][j]=INF;
            }
    for (int k=1;k<=n;k++)
        for (int i=1;i<=n;i++)
            for (int j=1;j<=n;j++)
                if (a[i][k]+a[k][j]<a[i][j])
                    a[i][j]=a[i][k]+a[k][j];
    for (int i=1;i<=n;i++)
    {
        for (int j=1;j<=n;j++)
            {
             if (a[i][j]==INF)
                fout<<0<<' ';
                else fout<<a[i][j]<<' ';
            }
        fout<<'\n';
    }
    fin.close();
    fout.close();
    return 0;
}
