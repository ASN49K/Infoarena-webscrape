#include <fstream>

using namespace std;

ifstream cin("royfloyd.in");
ofstream cout("royfloyd.out");
int n,a[101][101];
int max1 = 100000;
int main()
{
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
		{
			cin >> a[i][j];
			if (a[i][j] == 0 && i != j)
			{
				a[i][j] = max1;
			}
		}
	}
	for (int k = 1; k <= n; k++)
	{
		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j <= n; j++)
			{
				if (a[i][j] > a[i][k] + a[k][j])
				{
					a[i][j] = a[i][k] + a[k][j];
				}
			}
		}
	}
	for (int i = 1; i <= n; i++)
	{
		for(int j=1;j<=n;j++)
			if (a[i][j] == max1)
			{
				cout <<0<<" ";
			}
			else
			{
				cout << a[i][j] << " ";
			}
		cout << "\n";
	}
    return 0;
}
