#include <bits/stdc++.h>
using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n,mat[101][101],dp[101][101];

int main()
{
    fin >> n;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
            fin >> mat[i][j];
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
            if(i == j)
                dp[i][i] = 0;
            else
                dp[i][j] = mat[i][j];

    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
            dp[i][j] = min(dp[i][j],dp[i][1]+dp[1][j]);
    //cout << '\n';
    for(int k = 2; k <= n; k++)
    {
        for(int i = 1; i <= n; i++)
        {
            for(int j = 1; j <= n; j++)
            {
                dp[i][j] = min(dp[i][j],dp[i][k] + dp[k][j]);
            }
        }
    }

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
            fout << dp[i][j] << ' ';
        fout << '\n';
    }
}
