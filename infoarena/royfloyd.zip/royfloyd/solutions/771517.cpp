/* 
Roy-Floyd.
*/

#include <stdio.h>

#define MAXN	100

short int nr_noduri;
int mat[MAXN][MAXN];
 
void roy_floyd () {
	short int i, j, k;
	for (k = 1; k <= nr_noduri; k++)
		for (i = 1; i <= nr_noduri; i++)
			for (j = 1; j <= nr_noduri; j++)
				if (mat[i][k] && mat[k][j] && (mat[i][j] > mat[i][k] + mat[k][j] || !mat[i][j]) && i != j) 
					mat[i][j] = mat[i][k] + mat[k][j];
}

int main() {
	freopen("royfloyd.in", "r", stdin);
	freopen("royfloyd.out", "w", stdout);

	int i, j;
	scanf("%hd", &nr_noduri);
	for (i = 1; i <= nr_noduri; i++)
		for (j = 1; j <= nr_noduri; j++) 
			scanf("%d", &mat[i][j]);
	
	roy_floyd();

	for (i = 1; i <= nr_noduri; i++) {
		for (j = 1; j <= nr_noduri; j++) 
			printf("%d ", mat[i][j]);
		printf("\n");
	}

	return 0;
}
