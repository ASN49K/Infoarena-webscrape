#include <fstream>
#include <time.h>
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <bitset>
#include <queue>
#include <map>
#include <set>
#include <cmath>
#include <iomanip>
#define pb push_back
#define mp make_pair
#define sortvi(a) sort(a.begin(), a.end())
#define FOR(i, start, final) for (int i=start; i<=final; ++i)
#define ROF(i, start, final) for (int i=start; i>=final; --i)

#define MAXNODES 105

//void f(int &x){char k;for(k=getchar();k<= 32;k=getchar());for(x=0;'0'<=k;k=getchar())x=x*10+k-'0';}

/*void f(int &x)//parsare cu semn
{
	char k; bool semn=0;
	for (k = getchar(); (k>'9' || k<'0');)
    {
        if (k=='-') semn=1;
        k=getchar();
    }
	for (x = 0; '0' <= k; k = getchar())	x = x * 10 + k - '0';
    if (semn==1) x=-x;
}*/

using namespace std;

typedef long long ll;
typedef unsigned long long ull;
typedef pair < int, int> pi;
typedef vector< int > vi;
typedef vector< pair< int, int > > vpi;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int nodes, a[MAXNODES][MAXNODES];

int main()
{
    f.sync_with_stdio(false);
    f>>nodes;
    FOR(i,1,nodes) {
        FOR(j,1,nodes) {
            f>>a[i][j];
        }
    }

    FOR(k,1,nodes) {
        FOR(i,1,nodes) {
            FOR(j,1,nodes) {
                if (i != j && a[i][k] * a[k][j] != 0 && a[i][k] + a[k][j] < a[i][j]) {
                    a[i][j] = a[i][k] + a[k][j];
                }
            }
        }
    }

    FOR(i,1,nodes) {
        FOR(j,1,nodes) {
            g<<a[i][j]<<' ';
        }
        g<<'\n';
    }
    return 0;
}
