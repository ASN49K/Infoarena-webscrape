#include<stdio.h>
#define oo 1<<15

#define dim 105

using namespace std;

int dist[dim][dim],i,j,k,n;

int minim(int a,int b)
{	if(a<b) return a;
	return b;}

int main()
{
	FILE *f=fopen("royfloyd.in","r"), *g=fopen("royfloyd.out","w");
	
fscanf(f,"%d",&n);

for(i=1;i<=n;i++)
	for(j=1;j<=n;j++)
		{fscanf(f,"%d",&dist[i][j]); //costul muchiei de i la j in graf	
		if(!dist[i][j])
			dist[i][j]=oo;
		}

		
for(k=1;k<=n;k++)		
	for(i=1;i<=n;i++)
		if( k != i )
		for(j=1;j<=n;j++)
			if( k != j && i != j && dist[i][j] > dist[i][k]+dist[k][j] )
			dist[i][j] = dist[i][k]+dist[k][j]; 

for(i=1;i<=n;i++)
	{for(j=1;j<=n;j++)
		if(dist[i][j]==oo)
			fprintf(g,"0 ");
		else fprintf(g,"%d ",dist[i][j]);
		
		fprintf(g,"\n");
	}	
	
fclose(f);
fclose(g);

return 0;
}


