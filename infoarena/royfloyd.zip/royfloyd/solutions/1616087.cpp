#include <fstream>
#define DMAX 101
#define INF 2000000000

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n;
long long int M[DMAX][DMAX];

void citire();
void rezolvare();
void afisare();

int main()
{
citire();
rezolvare();
afisare();
    return 0;
}

void citire()
{
int i,j;
fin>>n;
for (i=1;i<=n;i++)
     for (j=1;j<=n;j++)
          {fin>>M[i][j];
           if (M[i][j]==0 && i!=j) M[i][j]=INF;
          }

}

void rezolvare()
{
int i,j,k;
for (k=1;k<=n;k++)
     for (i=1;i<=n;i++)
          for (j=1;j<=n;j++)
               if (M[i][j]>M[i][k]+M[k][j])
                   M[i][j]=M[i][k]+M[k][j];
}

void afisare()
{
int i,j;
for (i=1;i<=n;i++)
    {for (j=1;j<=n;j++)
         {
         if (M[i][j]==INF) M[i][j]=0;
         fout<<M[i][j]<<' ';
         }
    fout<<'\n';
    }
}
