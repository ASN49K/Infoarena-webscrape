#include<iostream>
#include<stdio.h>
#include<fstream>
using namespace std;
int k,n,a[101][101],i,j;
int main()
{
	ifstream f("royfloyd.in");
	f>>n;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			f>>a[i][j];
	for(k=1;i<=n;i++)
		for(i=1;j<=n;j++)
			for(j=1;k<=n;k++)
				//if((a[i][k])&&(a[k][j])&&(a[i][j]>a[i][k]+a[k][j] || a[i][j]==0)&&(i!=j))
					if (a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j) 
						a[i][j]=a[i][k]+a[k][j];
	ofstream g("royfloyd.out");
	for(i=1;i<=n;i++)
		{	
			for(j=1;j<=n;j++)
				g<<a[i][j]<<" ";
			g<<endl;
		}
	
	return 0;
	g.close();
}