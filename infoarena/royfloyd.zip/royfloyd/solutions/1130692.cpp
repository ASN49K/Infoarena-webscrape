#include <fstream>

using namespace std;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");
const int Nmax=150;
const int inf=99999;
int mat[Nmax][Nmax],v[Nmax],d[Nmax],drum[Nmax][Nmax],n;
void afisare(int xo[Nmax][Nmax])
{   int i,j;
    for(i=1;i<=n;i++)
    {   for(j=1;j<=n;j++)
        out<<xo[i][j]<<" ";
        out<<"\n";

    }

}
int main()
{
    int k,i,j;
    in>>n;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            {in>>mat[i][j];
             if(mat[i][j]==0&&i!=j) mat[i][j]=inf;
            }
    for(k=1;k<=n;k++)
    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    if(i!=j&&i!=k&&k!=j)
    if(mat[i][j]>mat[i][k]+mat[k][j])
    mat[i][j]=mat[i][k]+mat[k][j];
    afisare(mat);
    return 0;
}
