#include <fstream>

using namespace std;
#define MX 102
int n,a[MX][MX],i,j ;

void pd()
{
    int i,j,k,t;
    for (t=1; t<=4; t++)
        for (i=1; i<=n; i++)
            for (j=1; j<=n; j++)
                if (i!=j )
                    for (k=1; k<=n; k++)
                        if (k!=i && k!=j )
                        if (a[i][k]!=0 && a[k][j]!=0 && (a[i][k]+a[k][j]<a[i][j] || a[i][j]==0 ) )
                            a[i][j]=a[i][k]+a[k][j];
}

int main()
{
    ifstream f1("royfloyd.in");
    ofstream f2("royfloyd.out");
    f1>>n;
    for (i=1; i<=n; i++ )
        for (j=1; j<=n; j++ )
            f1>>a[i][j];

    pd();

    for (i=1; i<=n; i++)
            { for (j=1; j<=n; j++)
                f2<<a[i][j]<<" ";
              f2<<"\n"; }
    f1.close();
    f2.close();
    return 0;
}
