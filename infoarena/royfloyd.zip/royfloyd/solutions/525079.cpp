#include <fstream>

using namespace std;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int const N=260;
int const INF=1<<17;

int n,path[N][N];

void RoyFloyd(){
	int i,j,k;
	for(k=1;k<=n;k++){
		for(i=1;i<=n;i++){
			for(j=1;j<=n;j++){
				if(path[i][j]==path[i][k]+path[k][j] && path[i][j]!=0 && path[i][k]!=0 && path[k][j]!=0 && i!=j){
				}
				if(path[i][j]>path[i][k]+path[k][j]){
					path[i][j]=path[i][k]+path[k][j];
				}
			}
		}
	}
}

int main(){
	in>>n;
	int i,j;
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++){
			in>>path[i][j];
		}
	}
	RoyFloyd();
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++){
			out<<path[i][j]<<" ";
		}
		out<<"\n";
	}
	return 0;
	}
