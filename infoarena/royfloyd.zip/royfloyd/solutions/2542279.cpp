#include<fstream>
#define NMAX 101
#define INF 2*1e9

//input
std::ifstream f("royfloyd.in");
std::ofstream g("royfloyd.out");

//data
int graph[NMAX][NMAX];
int n;

//read data
void readData(){
    f >> n;
    for(int i = 0; i<n; i++){
        for(int j = 0; j<n; j++){
            f >> graph[i][j];
        }
    }
}

//solve using roy floyd
void solve(){
    for(int i = 0; i<n; i++){
        graph[i][i] = INF;
    }

    for(int k = 0; k<n; k++){
        for(int i = 0; i<n; i++){
            for(int j = 0; j<n; j++){
                if(graph[i][k] + graph[k][j] < graph[i][j] && graph[i][k] != INF && i != j){
                    graph[i][j] = graph[i][k] + graph[k][j];
                }
            }
        }
    }
}

//print solution
void printSolution(){
    for(int i = 0; i<n; i++){
        for(int j = 0; j<n; j++){
            graph[i][j] == INF ? g << 0 << ' ' : g << graph[i][j] << ' '; 
        }
        g << '\n';
    }
}

int main(){
    readData();
    solve();
    printSolution();
    return 0;
}