#include <iostream>
#include <fstream>

using namespace std;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int main()
{
    int N, M[101][101];
    int i, j, k;

    in >> N;

    for(i = 1; i <= N; i++)
        for(j = 1; j <= N; j++)
            in >> M[i][j];

    for(k = 1; k <= N; k++)
        for(i = 1; i <= N; i++)
            for(j = 1; j <= N; j++)
                if(M[i][k] && M[k][j] && (M[i][j] > M[i][k] + M[k][j] || !M[i][j] && i != j))
                    M[i][j] = M[i][k] + M[k][j];

    for(i = 1; i <= N; i++){
        for(j = 1; j <= N; j++)
            out << M[i][j] << " ";
        out << endl;
    }
    return 0;
}
