#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#define MAX 102
#define INF 200000000

using namespace std;

int v[MAX][MAX];

int main() {
	int n, i, j, k;

	FILE *fin = fopen("royfloyd.in", "r");
	fscanf(fin, "%d", &n);

	for (i = 1; i <= n; ++i) {
		for (j = 1; j <= n; ++j) {
			fscanf(fin, "%d ", &v[i][j]);
			if (v[i][j] == 0)
				v[i][j] = INF;
		}
	}
	fclose(fin);

	FILE *fout = fopen("royfloyd.out", "w");

	for (k = 1; k <= n; ++k)
		for (i = 1; i <= n; ++i)
			for (j = 1; j <= n; ++j)
				if ((i != j && i != k && j != k) && v[i][k] + v[k][j] < v[i][j])
					v[i][j] = v[i][k] + v[k][j];

	for (i = 1; i <= n; ++i) {
		for (j = 1; j <= n; ++j) {
			if (v[i][j] == INF)
				v[i][j] = 0;
			fprintf(fout, "%d ", v[i][j]);
		}

		fputc('\n', fout);
	}

	fclose(fout);

	return 0;
}
