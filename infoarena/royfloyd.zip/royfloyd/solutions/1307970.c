#include <stdio.h>
#include <stdlib.h>
#define INF 1000000

void dmin(int d[][105], int n);

int main()
{
	freopen("royfloyd.in", "r", stdin);
	freopen("royfloyd.out", "w", stdout);
	int n, a[105][105], i, j, d[105][105];
	scanf("%d", &n);
	for(i = 1; i <= n; i++)
		for(j = 1; j <= n; j++)
		{
			scanf("%d", &a[i][j]);

			if(i == j)
				d[i][j] = 0;

			else
			{
				if(a[i][j] == 0)
					d[i][j] = INF;

				else
					d[i][j] = a[i][j];
			}
		}

	dmin(d, n);

	for(i = 1; i <= n; i++)
	{
		for(j = 1; j <= n; j++)
		{
			if(d[i][j] == INF)
				printf("0 ");

			else
			 printf("%d ", d[i][j]);
		}

		printf("\n");
	}

	return 0;
}

void dmin(int d[][105], int n)
{
	int i, j, k;
	for(k = 1; k <= n; k++)
		for(i = 1; i <= n; i++)
			for(j = 1; j <= n; j++)
				if(d[i][j] > d[i][k] + d[k][j])
					d[i][j] = d[i][k] + d[k][j];
}
