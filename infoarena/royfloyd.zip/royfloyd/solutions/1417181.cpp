#include <cstdio>

#define NMAX 105
using namespace std;
int N,i,j,D[NMAX][NMAX],k;

int main()
{
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);

    scanf("%d", &N);
    for (i=1; i<=N; i++)
        for (j=1; j<=N; j++)
            scanf("%d", &D[i][j]);

    for (k=1; k<=N; k++)
        for (i=1; i<=N; i++)
            for (j=1; j<=N; j++)
                if (D[i][k] && D[k][j] && (D[i][j] > D[i][k] + D[k][j] || !D[i][j]) && i != j) D[i][j] = D[i][k] + D[k][j];

    for (i=1; i<=N; i++)
    {
        for (j=1; j<=N; j++)
            printf("%d ", D[i][j]);
        printf("\n");
    }
}
