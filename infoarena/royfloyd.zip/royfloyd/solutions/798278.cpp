#include <fstream>
using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int mat[101][101];
int d[101][101];
int N;

int royfloyd(int k);
int min(int a, int b) {
    return a < b ? a : b;
}


int main(int argc, char const *argv[])
{
    fin >> N;
    for (int i = 1; i <= N; ++i) {
        for (int j = 1; j <= N; ++j) {
            fin >> mat[i][j]; 
        }
    }

    for (int k = 0; k < N; ++k) {
        for (int i = 1; i <= N; ++i) {
            for (int j = 1; j <= N; ++j) {
                if (i != j && i != k && j != k && mat[i][k] > 0 && mat[k][j] > 0) {
                    if (mat[i][j] > mat[i][k] + mat[k][j]) {
                        mat[i][j] = mat[i][k] + mat[k][j];
                    }
                }
            }
        }
    }
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            fout << mat[i][j] << ' ';
        }
        fout << '\n';
    }
    return 0;
}

int royfloyd(int k, int x, int y) {
    if (k == 0) {
        return mat[x][y];
    } else {
        return min(royfloyd(k-1, x, y), royfloyd(k-1, k, y) + royfloyd(k-1, x, k)
    }
}