#include <iostream>
#include <fstream>
#include <iomanip>
#define SIZE 105

using namespace std;


const int inf = (2 << 30) - 1;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int     graf[SIZE][SIZE];
int     n, m;

void    citire(void)
{
    int     x, y, cost;

    f >> n;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
            f >> graf[i][j];
    }
}

void    solve(void)
{
    for (int k = 1; k <= n; k++)
    {
        for (int i  = 1; i <= n; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                if ((graf[i][j] > graf[i][k] + graf[k][j] || !graf[i][j])
                    && graf[i][k] != 0 && graf[k][j] != 0 && i != j)
                    graf[i][j] = graf[i][k] + graf[k][j];
            }

        }
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
            g << graf[i][j] << ' ';
        g << '\n';
    }
}

int main()
{
    citire();
    solve();
    return 0;
}
