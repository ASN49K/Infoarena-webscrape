#include <bits/stdc++.h>

std :: ifstream in ("royfloyd.in");

std :: ofstream out ("royfloyd.out");

const int NMAX = 1e2 + 5;

const int INF = 1e6;

int n;

int a[NMAX][NMAX];

int dp[NMAX][NMAX];

int main()
{

    in >> n;

    for(int i = 1; i <= n; i ++)
    {
        for(int j = 1; j <= n; j ++)
        {
            in >> dp[i][j];

            if(i != j && !dp[i][j])
            {
                dp[i][j] = INF;
            }
        }
    }

    for (int k = 1; k <= n; k++)
    {
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                if (dp[i][k] + dp[k][j] < dp[i][j])
                {
                    dp[i][j] = dp[i][k] + dp[k][j];
                }
            }
        }
    }

    for(int i = 1; i <= n; i ++, out << '\n')
    {
        for(int j = 1; j <= n; j ++)
        {
            if(dp[i][j] == INF)
            {
                out << 0 << " ";
            }
            else
            {
                out << dp[i][j] << " ";
            }
        }
    }

    return 0;
}