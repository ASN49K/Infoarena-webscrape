#include <iostream>
#include <fstream>

using namespace std;

ifstream input("royfloyd.in");
ofstream output("royfloyd.out");

int main()
{
	int n;
	input >> n;
	
	int x[n][n];
	
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			input >> x[i][j];
		}
	}
	
	for(int k = 0; k < n; k++)
	{
		for(int i = 0; i < n; i++)
		{
			for(int j = 0; j < n; j++)
			{
				if (x[i][k] && x[k][j] && (x[i][j] > x[i][k] + x[k][j] || !x[i][j]) && i != j)
				{
					x[i][j] = x[i][k] + x[k][j];
				}
			}
		}
	}
	
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			output << x[i][j] << " ";
		}
		output << "\n";
	}
	
	return 0;
}
