#include <iostream>
#include <fstream>

using namespace std;

    ifstream f("f.in");
    ofstream g("f.out");

    int a[105][105];
    int n;

    void citire()
    {
        f>>n;
        for(int i =1;i<=n;i++)
            for(int j = 1;j<=n;j++)
            f>>a[i][j];
    }

    void F_W()
    {
        int i,j,k;
        for(k = 1; k<=n;k++)
            for(i = 1;i<=n;i++)
                for(j = 1;j<=n;j++)
            if(a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j)
            a[i][j] = a[i][k] + a[k][j];
    }

    void afis()
    {
        for(int i =1; i <= n; i++)
        {
            for(int j = 1; j <= n; j++)
                g<<a[i][j]<<" ";

            g<<endl;


        }

    }

int main()
{
    citire();
    F_W();
    afis();

    return 0;
}
