#include<fstream>

using namespace std;

int n,i,j,a[100][100],k;
void citire()
{
     ifstream fin("royfloyd.in");
     fin>>n;
     for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
           fin>>a[i][j];
}           
                      
int main()
{
    ifstream fin("royfloyd.in");
    ofstream fout("royfloyd.out");
    citire();
    for(k=1;k<=n;k++)
       for(i=1;i<=n;i++)
          for(j=1;j<=n;j++)
             if(a[i][k]&&a[k][j]&&(a[i][k]+a[k][j]<a[i][j]||!a[i][j])&&i!=j)
               a[i][j]=a[i][k]+a[k][j];
    for(i=1;i<=n;i++)
       {
       for(j=1;j<=n;j++)
          fout<<a[i][j]<<" ";
       fout<<endl;
       }
}
    
