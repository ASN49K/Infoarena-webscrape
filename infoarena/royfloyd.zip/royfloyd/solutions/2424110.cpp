#include <bits/stdc++.h>

using namespace std;

const int MAXN = 110;
int A[MAXN][MAXN], DP[MAXN][MAXN];

int N;
int main() {
    ifstream fin("royfloyd.in");
    ofstream fout("royfloyd.out");

    fin >> N;
    for (int i = 1; i <= N;i++)
        for (int j = 1; j <= N;j++){ 
            fin >> A[i][j];
            DP[i][j] = A[i][j];
        }

    for (int k = 1; k <= N;k++)
        for(int i = 1; i <= N;i++)
            for(int j = 1; j <= N;j++)
                DP[i][j] = min(DP[i][j], DP[i][k] + DP[k][j]);

    for (int i = 1; i <= N;i++)
        for(int j = 1; j <= N;j++)
            fout <<DP[i][j] <<" \n"[j==N];
    return 0;
}