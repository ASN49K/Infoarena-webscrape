var v:array [1..100, 1..100] of integer;
    i, j, n, k:integer;
    f, g:text;

begin
assign (f, 'royfloyd.in'); reset (f);
assign (g, 'royfloyd.out'); rewrite (g);
read (f, n);
for i := 1 to n do
  for j := 1 to n do
    begin
    read (f, v[i, j]);
    if v[i, j] = 0 then v[i, j]:=1100;
    end;

for k := 1 to n do
  for i := 1 to n do
    for j := 1 to n do
      if (v[i,k]+v[k, j]<v[i, j]) then v[i, j]:=v[i, k]+v[k, j];

for i := 1 to n do
  begin
  for j := 1 to n do
    begin
    if v[i, j]<> 1100   then write (g, v[i, j], ' ')
                        else write (g, '0 ');
    end;
  writeln(g);
  end;

close (f); close (g);
end.
