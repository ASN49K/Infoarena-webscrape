#include <bits/stdc++.h>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n, cost[105][105], dp[105][105];

int main()
{
fin>>n;
for (int i = 1; i <= n; i++){
    for (int j = 1; j <= n; j++){
        fin>>cost[i][j];
        dp[i][j] = cost[i][j];
    }
}

for (int k = 1; k <= n; k++){
    for (int i = 1; i <= n; i++){
        for (int j = 1; j <= n; j++){
            if (dp[i][k] + dp[k][j] < dp[i][j])
                dp[i][j] = dp[i][k] + dp[k][j];
        }
    }
}

for (int i = 1; i <= n; i++){
    for (int j = 1; j <= n; j++){
        fout << dp[i][j] << " ";
    }
    fout << '\n';
}


    return 0;
}
