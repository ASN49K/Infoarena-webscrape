#include<cstdio>
#define infile "royfloyd.in"
#define outfile "royfloyd.out"
#define n_max 105
using namespace std;

int a[n_max][n_max];

int n;

void citeste()
{
	freopen(infile,"r",stdin);
	
	scanf("%d",&n);
	
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			scanf("%d",&a[i][j]);
	
	fclose(stdin);
}


void rezolva()
{
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if(a[i][k] && a[k][j] && i!=j && ( a[i][j] > a[i][k] + a[k][j] || !a[i][j] ) )
					a[i][j] = a[i][k] + a[k][j];
}


void afiseaza()
{
	freopen(outfile,"w",stdout);
	
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
			printf("%d ",a[i][j]);
		printf("\n");
	}
	
	fclose(stdout);
}


int main()
{
	citeste();
	rezolva();
	afiseaza();
	
	return 0;
}
