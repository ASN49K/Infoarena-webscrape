#include <fstream>
#define NMAX 105
#define inf 2000000000

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int i, n, mat[NMAX][NMAX], j, k;

int main()
{
    f >> n;

    for (i = 1; i <= n; ++ i)
        for (j = 1; j <= n; ++ j)
            f >> mat[i][j];

    for (i = 1; i <= n; ++ i)
        for (j = 1; j <= n; ++ j)
            if (mat[i][j] == 0)
                mat[i][j] = inf;

    for (k = 1; k <= n; ++ k)
        for (i = 1; i <= n; ++ i)
            for (j = 1; j <= n; ++ j)
                if (i != j)
                    mat[i][j] = min(mat[i][j], mat[i][k] + mat[k][j]);

    for (i = 1; i <= n; ++ i)
    {
        for (j = 1; j <= n; ++ j)
            if (mat[i][j] == inf)
                g << 0 << " ";
            else
                g << mat[i][j] << " ";
        g << '\n';
    }
    return 0;
}
