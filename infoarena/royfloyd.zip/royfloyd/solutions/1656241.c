#include<stdio.h>

#define NMax 100

int D[NMax][NMax] = {{0}};

void print_matrix(int n) {
  for(int i = 0; i < n; i++ ) {
    for(int j = 0; j < n; j++) {
      printf("%d ", D[i][j]);
    }
    printf("\n");
  }
  printf("----\n");
}

int main(void) {
  freopen("royfloyd.in", "r", stdin);
  freopen("royfloyd.out", "w+", stdout);

  int n;
  scanf("%d", &n);
  for(int i = 0; i < n; i++) {
    for(int j = 0; j < n; j++) {
      scanf("%d", &D[i][j]);
    }
  }

  print_matrix(n);

  for(int k = 0; k < n; k++) {
    for(int i = 0; i < n; i++) {
      for(int j = 0; j < n; j++) {
        if( D[i][k] && D[k][j] && (D[i][j] > D[i][k] + D[k][j] || !D[i][j]))
          D[i][j] = D[i][k] + D[k][j];
      }
    }
  }

  print_matrix(n);
}
