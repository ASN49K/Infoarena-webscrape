#include<fstream>
using namespace std;
int a[110][110],n;
int main()
{
    ifstream q("royfloyd.in");
    ofstream w("royfloyd.out");
    q>>n;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
        {
            q>>a[i][j];
            if(a[i][j]==0)
                a[i][j]=-1;
        }
    for (int k = 1; k <= n; k++)
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++)
                if (a[i][j] > a[i][k] + a[k][j]&&a[i][j]!=-1&&a[i][k]!=-1&&a[k][j]!=-1)
                 a[i][j]=a[i][k]+a[k][j];
    for(int i=1;i<=n;i++){
      for(int j=1;j<=n;j++)
         {
             if(a[i][j]==-1)
              a[i][j]=0;
             w<<a[i][j]<<" ";
         }
    w<<"\n";
    }
    return 0;}
