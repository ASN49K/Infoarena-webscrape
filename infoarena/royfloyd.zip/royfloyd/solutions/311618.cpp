#include <stdio.h>
#define Nmax 101
int N,A[Nmax][Nmax];
void rf()
{
     int i,j,k;
     for(k=1;k<=N;k++) //imi aleg varful K intermediar
       for(i=1;i<=N;i++)
         for(j=1;j<=N;j++)
           if(A[i][j]>A[i][k]+A[k][j])  //atunci exista un drum/lant
             A[i][j]=A[i][k]+A[k][j];     //de la I la K
                                         //si de la K la J
                                         
}
void print()
{
     int i,j;
     for(i=1;i<=N;i++)
       {
       for(j=1;j<=N;j++)
       printf("%d ",A[i][j]);
       printf("\n");
       }
}       
                                                
int main()
{int i,j;
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    scanf("%d",&N);
    for(i=1;i<=N;i++)
      for(j=1;j<=N;j++)
      {
       scanf("%d",&A[i][j]);
       if(A[i][j]==0 && i!=j)
        A[i][j]=100000;//ma asigur ca elimin nodurile care nu au nici o relatie intre ele
       } 
    rf();
    print();
    return 0;
}        
