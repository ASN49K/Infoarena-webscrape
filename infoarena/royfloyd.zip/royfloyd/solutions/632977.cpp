#include<stdio.h>
#define inf 0xfffffff
using namespace std;
int a[103][104],n;
int min(int t, int k){
if(t<k) return t;
else return k;
}

int main(){
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	scanf("%d", &n);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++){
			scanf("%d", &a[i][j]);
			if(i!=j&&a[i][j]==0)
				a[i][j]=inf;
		}	
	
  for(int z=1;z<=n;z++)
		for(int x=1;x<=n;x++)
			for(int y=1;y<=n;y++)
					a[x][y]=min(a[x][y], a[x][z]+a[z][y]);
	
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++)
			printf("%d ", a[i][j]!=inf ? a[i][j]:0);
		printf("\n");
	}
	return 0;
}

			