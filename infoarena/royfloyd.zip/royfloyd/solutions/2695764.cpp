#include <fstream>

using namespace std;

const int NMAX = 101;
const int oo = 1e9;

int n;
int G[NMAX][NMAX];

void royfloyd() {

    for (int k = 0; k < n; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                G[i][j] = min(G[i][j], G[i][k] + G[k][j]);
            }
        }
    }
}

int main() {
    ifstream fin("royfloyd.in");
    ofstream fout("royfloyd.out");

    fin >> n;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fin >> G[i][j];
            if (G[i][j] == 0) {
                G[i][j] = oo;
            }
            if (i == j) {
                G[i][j] = 0;
            }
        }
    }

    royfloyd();

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fout << G[i][j] << " ";
        }
        fout << "\n";
    }

    fin.close();
    fout.close();
    return 0;
}