#include <fstream>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n;
int a[101][101];

int main()
{
    fin >> n;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
        {
            fin >> a[i][j];
            if(a[i][j] == 0 && i != j)
                a[i][j] = 1e7;
        }

    for(int k=1; k<=n; k++)
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++)
                a[i][j] = min(a[i][j], a[i][k] + a[k][j]);

    for(int i=1; i<=n; i++, fout << "\n")
        for(int j=1; j<=n; j++)
            fout << a[i][j] << " ";
    return 0;
}
