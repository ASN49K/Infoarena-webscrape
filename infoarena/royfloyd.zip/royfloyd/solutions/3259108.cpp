#include <bits/stdc++.h>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

#define INF (long long)10e9
#define NMAX 100
#define VMAX 1000000

int n;
long long dist[NMAX+1][NMAX+1];
int main()
{
    fin >> n;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            fin >> dist[i][j];
            if(dist[i][j] == 0 && i!=j)
            {
                dist[i][j] = INF;
            }
        }
    }

    for(int k=1;k<=n;k++)
    {
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                dist[i][j] = min(dist[i][j],dist[i][k] + dist[k][j]);
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            fout << (dist[i][j]==INF ? 0 : dist[i][j]) << " ";
        }
        fout << "\n";
    }
}
