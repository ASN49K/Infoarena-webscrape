#include <iostream>
#include <fstream>

#define dim 101

using namespace std;
ifstream fin("roy-floyd.in");
ofstream fout("roy-floyd.out");

int n, m, matrix[dim][dim], a[dim][dim];

void citire() {

    fin >> n >> m;
    for(int i = 1; i <= m; i++) {
        int x, y, c;
        fin >> x >> y >> c;
        matrix[x][y] = c;
    }
}

void roy_floyd() {

    int i, j, k;
    for(k = 1; k <= n; k++) {
        for(i = 1; i <= n; i++) {
            for(int j = 1; j <= n; j++) {
                if(matrix[i][k] && matrix[k][j] && (matrix[i][j] > matrix[i][k] + matrix[k][j] || !matrix[i][j]) && i != j) {
                    matrix[i][j] = matrix[i][k] + matrix[k][j];
                }
            }
        }
    }
}

void afisare() {

    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++) {
            fout << matrix[i][j] << ' ';
        }
        fout << '\n';
    }
}

void afisare2() {

    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++) {
            fout << a[i][j] << ' ';
        }
        fout << '\n';
    }
}

int main()
{
    citire();
    roy_floyd();
    afisare();
    fout << '\n';
    afisare2();
    return 0;
}
