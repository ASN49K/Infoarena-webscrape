#include <iostream>
#include <fstream>

using namespace std;
short int N, Matr[100][100], i, j;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

void Citire()
{
    fin>>N;

    for (i=1; i<=N; ++i)
        for(j=1; j<=N; ++j)
            fin>>Matr[i][j];
}

void Construire()
{
    for(short int k=1; k<=N; k++)
        for(i=1; i<=N; i++)
            for(j=1; j<=N; j++)
                if(Matr[i][k] && Matr[k][j] && i!=j && ((Matr[i][j] && (Matr[i][j]>Matr[i][k]+Matr[k][j])) || (!Matr[i][j])))
                    Matr[i][j]=Matr[i][k]+Matr[k][j];
}

void Afisare()
{
    for (i=1; i<=N; ++i)
    {
        for(j=1; j<=N; ++j)
            cout<<Matr[i][j]<<' ';
        cout<<'\n';
    }
}

int main()
{
    Citire();
    Construire();
    Afisare();
}
