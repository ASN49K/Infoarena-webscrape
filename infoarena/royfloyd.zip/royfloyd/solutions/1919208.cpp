#include <fstream>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n,i,j,k,g[110][110],rf[110][110];

int main()
{
    fin >> n;
    for (i=1; i<=n; i++)
        for (j=1; j<=n; j++)
        fin >> g[i][j],rf[i][j]=g[i][j];
    for (k=1; k<=n; k++)
        for (i=1; i<=n; i++)
            for (j=1; j<=n; j++)
            if (i!=j&&rf[i][k]+rf[k][j]<rf[i][j])
            rf[i][j]=rf[i][k]+rf[k][j];
    for (i=1; i<=n; i++)
    {
        for (j=1; j<=n; j++)
            fout << rf[i][j] << ' ';
        fout << '\n';
    }
}
