#include <fstream>
#define NM 105

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int A[NM][NM];
int N;

void roy_floyd();

int main()
{
	fin >> N;

	for (int i = 1; i <= N; i++)
		for (int j = 1; j <= N; j++)
			fin >> A[i][j];

	roy_floyd();

	for (int i = 1; i <= N; i++)
	{
		for (int j = 1; j <= N; j++)
			fout << A[i][j] << ' ';
		fout << '\n';
	}
}

void roy_floyd()
{
	for (int k = 1; k <= N; k++)
		for (int i = 1; i <= N; i++)
			for (int j = 1; j <= N; j++)
				if (!A[i][k]&&!A[k][j]&&(A[i][k] + A[k][j] < A[i][j] || A[i][j] == 0) && i != j)
					A[i][j] = A[i][k] + A[k][j];
}
