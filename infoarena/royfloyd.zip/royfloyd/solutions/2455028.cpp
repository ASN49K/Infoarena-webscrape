#include <bits/stdc++.h>

using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n,c[101][101];
const int oo = 1000000;
int main()
{
    f>>n;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
        {
            f>>c[i][j];
            if(c[i][j]==0)c[i][j]=oo;
        }
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;i++)
                c[i][j]=min(c[i][j],c[i][k]+c[k][j]);
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            if(c[i][j]==oo)c[i][j]=0;
            g<<c[i][j]<<' ';
        }
        g<<'\n';
    }

    return 0;
}
