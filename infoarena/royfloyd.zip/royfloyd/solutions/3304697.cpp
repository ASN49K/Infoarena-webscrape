#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

string filename = "royfloyd";

ifstream fin(filename + ".in");
ofstream fout(filename + ".out");

const int NMAX = 100;
const int INF = 1e9;
int minim[NMAX + 5][NMAX + 5];
int cost[NMAX + 5][NMAX + 5];

int main()
{
    int n;
    fin >> n;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            fin >> cost[i][j];
            minim[i][j] = cost[i][j];
            if(!minim[i][j] and i!=j)
                minim[i][j] = INF;
        }
    }

    for (int k = 1; k <= n; k++)
    {
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                minim[i][j] = min(minim[i][j], minim[i][k] + minim[k][j]);
            }
        }
    }

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            fout << minim[i][j] << ' ';
        }
        fout << '\n';
    }


}
