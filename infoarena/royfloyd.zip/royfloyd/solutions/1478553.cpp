#include <fstream>

using namespace std;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int main(void){
	
	int n;
	int dp[101][101];
	in >> n;
	for (int i=1;i<=n;i++){
		for (int j=1;j<=n;j++){
			in >> dp[i][j];
		}
	}
	
	for (int i=1;i<=n;i++){
		for (int j=1;j<=n;j++){
			for (int k=1;k<=n;k++){
				if (dp[i][k]!=0 && dp[k][j]!=0){
					if (dp[i][j]==0 || dp[i][k]+dp[k][j]<dp[i][j]){
						dp[i][j] = dp[i][k]+dp[k][j];
					}
				}
			}
		}
	}
	for (int i=1;i<=n;i++) dp[i][i]=0;
	for (int i=1;i<=n;i++){
		for (int j=1;j<=n;j++){
			out << dp[i][j] << " ";
		}
		out << "\n";
	}
	
	return 0;
}
