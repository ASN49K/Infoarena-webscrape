#include <iostream>
#include <vector>
#include <fstream>

int main() {
    std::ifstream fin("royfloyd.in");
    std::ofstream fout("royfloyd.out");

    int n;
    fin >> n;
    std::vector<std::vector<int>> adjacency_matrix(n, std::vector<int>(n, 0));
    for(auto &line : adjacency_matrix) {
        for(auto &el : line) {
            fin >> el;
        }
    }

    for(int k = 0; k<n; k++)
        for(int i = 0; i < n; i++)
            for(int j = 0; j<n; j++)
                if(!adjacency_matrix[i][j] && i!=j)
                    adjacency_matrix[i][j] = adjacency_matrix[i][k] + adjacency_matrix[k][j];
                else if(adjacency_matrix[i][k] && adjacency_matrix[k][j] && i!=j)
                    adjacency_matrix[i][j] = std::min(adjacency_matrix[i][j], adjacency_matrix[i][k] + adjacency_matrix[k][j]);

    for(auto const& line : adjacency_matrix) {
        for(auto el : line) {
            fout << el << ' ';
        }
        fout << '\n';
    }

    return 0;
}
