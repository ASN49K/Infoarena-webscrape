#include <cstdio>
#define nMax 101
using namespace std;

FILE *inFile = fopen("royfloyd.in","r");
FILE *outFile = fopen("royfloyd.out","w");
int n;
int a[nMax][nMax];

void citire()
{
    scanf("%d",&n);
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
        {
            fscanf(inFile,"%d",&a[i][j]);
        }
}

void floydWarshall()
{
    for(int k = 1 ; k <=n; k++)
    {
        for(int i = 1; i<=n;i++)
        {
            for(int j = 1 ; j <=n; j++)
            {
                if(a[i][k] != 0 && a[k][j] != 0 && (a[i][j] > a[i][k] + a[k][j] || a[i][j] == 0) && i != j)
                a[i][j] = a[i][k] + a[k][j];
            }
        }
    }

    for(int i =1 ; i <= n;i++)
    {
        for(int j = 1 ; j <= n; j++)
        {
            fprintf(outFile,"%d ",a[i][j]);
        }
        fprintf(outFile,"\n");
    }
}

int main()
{
    citire();
    floydWarshall();
    return 0;
}
