#include <iostream>
#include <fstream>
#include <cstdio>
#define NMax 101
using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int n, a[NMax][NMax];

int main()
{
    f >> n;
    for(int i = 0; i < n; ++i)
        for(int j = 0; j < n; ++j)
            f >> a[i][j];

    /// ROY FLOYD

    for(int i = 0; i < n; ++i)
        for(int j = 0; j < n; ++j)
            for(int k = 0; k < n; ++k)
                if(a[j][i] && a[i][k] && (a[j][k] > a[j][i] + a[i][k] || !a[j][k]) && j != k) a[j][k] = a[j][i] + a[i][k];

    for(int i = 0; i < n; ++i)
    {
        for(int j = 0; j < n; ++j)
            g << a[i][j] << " ";
        g << '\n';
    }

    return 0;
}
