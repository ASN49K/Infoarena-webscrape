#include    <iostream>
#include    <fstream>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

const int oo=99999999;

int n;
int a[110][110];

void read()
{
    f >> n;
    for (int i= 1; i<= n; ++i)
        for (int j= 1; j<= n; ++j)
        {
            f >> a[i][j];
            if ( !a[i][j])
            a[i][j]=oo;
        }
}

void roy_floyd()
{
    for (int k= 1; k<= n; ++k)
    for (int i= 1; i<= n; ++i)
    for (int j= 1; j<= n; ++j)
        if ( i!=j && i!=k && j!=k )
        if ( a[i][k]+a[k][j] < a[i][j])
        a[i][j]= a[i][k] + a[k][j];
}

void print()
{
    for (int i= 1; i<= n; ++i)
        {
            for (int j= 1; j<= n; ++j)
            {
                if (i==j)
                    g << "0" << " ";
                else
                    if (a[i][j]==oo)
                        g << "0" << " ";
                else
                    g << a[i][j] << " ";
            }
        g<<endl;
        }
}

int main()
{
    read();
    roy_floyd();
    print();
}
