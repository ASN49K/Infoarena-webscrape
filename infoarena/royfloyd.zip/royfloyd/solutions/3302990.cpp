#include <fstream>

using namespace std;
long long int n, p[105][105], inf=1e9;
ifstream cin("royfloyd.in");
ofstream cout("royfloyd.out");
int main()
{
    cin>>n;
    for(int i=1; i<=n;i++)
        for(int j=1; j<=n;j++){
            cin>>p[i][j];
            if(p[i][j]==0) p[i][j]=inf;
        }
    for(int k=1; k<=n;k++)
        for(int i=1; i<=n;i++)
            for(int j=1; j<=n;j++)
                if(i!=j && p[i][j]>p[i][k]+p[k][j])
                    p[i][j]=p[i][k]+p[k][j];
    for(int i=1; i<=n;i++){
        for(int j=1; j<=n;j++){
            if(p[i][j]==inf)
                p[i][j]=0;
            cout<<p[i][j]<<' ';
        }
        cout<<'\n';
    }
    return 0;
}
