#include <fstream>
using namespace std;
long long n;
long long p[101][101];
fstream fin("royfloyd.in",ios::in);

void citire(){
	fin>>n;
	for (int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			fin>>p[i][j];
}

int main(){
citire();
for (int k=1;k<=n;k++)
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
			if (a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j)
				p[i][j]=p[i][k]+p[k][j];
fstream fout("royfloyd.out",ios::out);
for (int i=1;i<=n;i++){
	for (int j=1;j<=n;j++){
		fout<<p[i][j]<<" ";
	}
	fout<<endl;
}
}


