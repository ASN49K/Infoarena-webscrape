#include <stdio.h>
#include <string.h>
#define inf 100000
long x,y,i,j,k,n,m,c[101][101],d[101][101],u[101][101],z;
void scrie(int i,int j)
{printf("%d ",i);
 if(i!=j)scrie(u[i][j],j);else return;
}

int main()
{freopen("royfloyd.in","r",stdin);freopen("royfloyd.out","w",stdout);
 fscanf(stdin,"%ld",&n);
 for(i=1;i<=n;i++)for(j=1;j<=n;j++)
  {fscanf(stdin,"%ld",&c[i][j]);if(c[i][j]==0&&i!=j)c[i][j]=inf;}
 for(i=1;i<=n;i++)
  for(j=1;j<=n;j++)
   if(c[i][j]!=0&&c[i][j]!=inf)u[i][j]=j;else u[i][j]=0;
 memcpy(d,c,sizeof(c));
 for(k=1;k<=n;k++)
  for(i=1;i<=n;i++)
   for(j=1;j<=n;j++)
    if(d[i][j]>d[i][k]+d[k][j]){d[i][j]=d[i][k]+d[k][j];u[i][j]=u[i][k];}
 for(i=1;i<=n;i++)
  {for(j=1;j<=n;j++)
    if(d[i][j]!=inf)fprintf(stdout,"%ld ",d[i][j]);
	     else fprintf(stdout,"0 ");
    fprintf(stdout,"\n");}
 fclose(stdin);fclose(stdout);
 return 0;
}
