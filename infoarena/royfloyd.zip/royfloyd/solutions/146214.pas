var m:array[1..100,1..100]of integer;
    mdm:array[1..100,1..100]of longint;
    n,k,i,j:longint;
begin
assign(input,'royfloyd.in');
reset(input);
read(n);
for i:=1 to n do
    for j:=1 to n do
    begin
         read(m[i,j]);
         mdm[i,j]:=m[i,j];
    end;
close(input);
for k:=1 to n do
    for i:=1 to n do
        for j:=1 to n do
            if (m[i,k]<>0) and (m[k,j]<>0) then
               if(m[i,k]+m[k,j]<mdm[i,j])then
               mdm[i,j]:=m[i,k]+m[k,j];
assign(output,'royfloyd.out');
rewrite(output);
for i:=1 to n do
begin
     for j:=1 to n do
     write(mdm[i,j],' ');
     writeln;
end;
close(output);
end.