#include <fstream>
#include <climits>

using namespace std;

ifstream fin("royfloyd.in");
ofstream cout("royfloyd.out");

int mc[10001][10001], nodes;

void citire() {
  fin >> nodes;
  int i,j;
  for (i = 1; i <= nodes; i++)
    for (j = 1; j <= nodes; j++)
      fin >> mc[i][j];
}

void roy_floyd() {
  int i,j,k;
  for (k = 1; k <= nodes; k++)
    for (i = 1; i <= nodes; i++)
      for (j = 1; j <= nodes; j++)
        if ((i != j && mc[i][j] == 0) || (mc[i][j] > mc[i][k] + mc[k][j] && i != k && j != k && mc[i][k] && mc[k][j]))
          mc[i][j] = mc[i][k] + mc[k][j];
}

void display() {
  for (int i = 1; i <= nodes; i++) {
    for (int j = 1; j <= nodes; j++)
      cout << mc[i][j] << " ";
    cout << '\n';
  }
}

int main() {
  citire();
  roy_floyd();
  display();
  return 0;
}
