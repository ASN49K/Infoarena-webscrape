#include <iostream>
#include <fstream>
using namespace std;
int n,a[101][101];
void citire()
{
    ifstream f ("royfloyd.in");
    f>>n;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            f>>a[i][j];
}
void roy_floyd()
{
    for(int k=1; k<=n; k++)
    {
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++)
                if(a[i][j]>a[i][k]+a[k][j]&&k!=i&&j!=k)
                    a[i][j]=a[i][k]+a[k][j];

    }
}
void afisare()
{
    ofstream g ("royfloyd.out");
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
            g<<a[i][j]<<" ";
        g<<endl;
    }
}
int main()
{
    citire();
    roy_floyd();
    afisare();
    return 0;
}
