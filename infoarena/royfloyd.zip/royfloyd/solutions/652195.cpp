using namespace std;
#include<fstream>
int N;
int a[105][105];

ofstream fout("royfloyd.out");

void afisare()
{
    int i,j;
    for(i=1;i<=N;i++)
    {
        for(j=1;j<=N;j++)
        {
            fout<<a[i][j]<<" ";
        }
        fout<<"\n";
    }
}

void royfloyd()
{
    int k,i,j;
    for(k=1;k<=N;k++)
    {
        for(i=1;i<=N;i++)
        {
            for(j=1;j<=N;j++)
            {
                if(a[i][k] && a[k][j] && (a[i][j]>a[i][k]+a[k][j] || a[i][j]==0) && i!=j)
                   a[i][j]=a[i][k]+a[k][j];
            }
        }
    }
}

void cit()
{
    ifstream fin("royfloyd.in");
    fin>>N;
    int i,j;
    for(i=1;i<=N;i++)
    {
        for(j=1;j<=N;j++)
        {
            fin>>a[i][j];
        }
    }

    fin.close();
}

int main()
{
    cit();
    royfloyd();
    afisare();
    fout.close();
    return 0;
}
