#include <fstream>
#include <unordered_map>
#include <vector>

using namespace std;

vector<vector<int>> roy_floyd(const vector<vector<int>> &cost) {
  int N = cost.size();
  vector<vector<int>> apsp(cost);

  for (int k = 0; k < N; ++k)
    for (int i = 0; i < N; ++i)
      for (int j = 0; j < N; ++j)
        apsp[i][j] = min(apsp[i][k] + apsp[k][j], apsp[i][j]);

  return apsp;
}

int main() {
  ifstream fin("royfloyd.in");
  ofstream fout("royfloyd.out");

  int n;
  fin >> n;
  vector<vector<int>> cost(n, vector<int>(n));
  for (int i = 0; i < n; ++i)
    for (int j = 0; j < n; ++j) {
      fin >> cost[i][j];
      if (i != j && cost[i][j] == 0)
        cost[i][j] = 1000000;
    }

  auto apsp = roy_floyd(cost);
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < n; ++j)
      fout << apsp[i][j] << " ";
    fout << "\n";
  }

  return 0;
}
