#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
long long a[101][101];
int main()
{
    int n;
    fin>>n;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            fin>>a[i][j];
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            if(a[i][j]==0 && j!=i)
                a[i][j]=999999999;
    for(int k=1; k<=n; k++)
        for(int x=1; x<=n; x++)
            for(int y=1; y<=n; y++)
                if(a[x][k]+a[k][y]<a[x][y])
                    a[x][y]=a[x][k]+a[k][y];
     for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++)
            fout<<a[i][j]<<" ";
        fout<<'\n';
     }
}
