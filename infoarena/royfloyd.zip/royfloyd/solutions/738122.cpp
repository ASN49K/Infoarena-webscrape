#include<stdio.h>
#define NMAX 105
int N,A[NMAX][NMAX];
void citire()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    scanf("%d" ,&N);
    for(int i = 1;i<=N;i++)
        for(int j = 1;j<=N;j++)
            scanf("%d",&A[i][j]);
}
void afisare()
{
    for(int i = 1 ; i<=N;i++,printf("\n"))
        for(int j = 1 ; j<=N;j++)
            printf("%d ",A[i][j]);
}
void rfw()
{
    for(int i = 1; i<=N;i++)
        for(int j = 1 ; j<=N;j++)
            for(int k = 1 ; k<=N;k++)
                if(i!=j && A[k][j] && A[i][k])
                    if(A[i][j] > A[k][j] + A[i][k])
                        A[i][j] = A[k][j] + A[i][k];
}
int main()
{
    citire();
    rfw();
    afisare();
    return 0;
}