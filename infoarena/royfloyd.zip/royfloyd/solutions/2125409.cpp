#include <iostream>
#include <cstdio>
#define NMAX 105

using namespace std;

int N, G[NMAX][NMAX];

void read()
{
    scanf("%d", &N);
    for(int i=1; i<=N; ++i)
        for(int j=1; j<=N; ++j)
            scanf("%d", &G[i][j]);
}

void royfloyd()
{
    for(int k=1; k<=N; ++k)
        for(int i=1; i<=N; ++i)
            for(int j=1; j<=N; ++j)
                if(G[i][j] > G[i][k] + G[k][j])
                    G[i][j] = G[i][k] + G[k][j];
}

void print()
{
    for(int i=1; i<=N; ++i)
    {
        for(int j=1; j<=N; ++j)
            printf("%d ", G[i][j]);
        printf("\n");
    }
}

int main()
{
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);
    read();
    royfloyd();
    print();
    return 0;
}
