#import<fstream>
int a=100001,b=100,n,i,j,k;
#define c(i) for(i=0;i<n;i++)
std::ifstream f("royfloyd.in");
std::ofstream o("royfloyd.out");
main()
{
    int c[b][b];
    f>>n;
    c(i)c(j)
    {
        f>>c[i][j];
        if(i!=j&!c[i][j])c[i][j]=a;
    }
    c(k)c(i)c(j)c[i][j]=std::min(c[i][j],c[i][k]+c[k][j]);
    c(i)
    {
        c(j)o<<(c[i][j]==a?0:c[i][j])<<" ";
        o<<'\n';
    }
}
