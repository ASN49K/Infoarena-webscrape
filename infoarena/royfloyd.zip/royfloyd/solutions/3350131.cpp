#include <bits/stdc++.h>
#define ll long long
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
int a[101][101];
const int INF = 99999;
int main(){
    int n;
    fin >> n;
    for(int i = 1; i<=n; i++){
        for(int j = 1; j<=n; j++){
            fin >> a[i][j];
        }
    }
    for(int k = 1; k<=n; k++){
        for(int i = 1; i<=n; i++){
            for(int j = 1; j<=n; j++){
                if(a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j) a[i][j] = a[i][k] + a[k][j];
            }
        }
    }
    for(int i = 1; i<=n; i++){
        for(int j = 1; j<=n; j++){
            fout<< a[i][j] << ' ';
        }
        fout << '\n';
    }


    return 0;
}