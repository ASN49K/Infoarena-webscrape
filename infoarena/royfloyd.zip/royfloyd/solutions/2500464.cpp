#include <fstream>
#define inf 2000000000

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int n, dp[101][101];

int main()
{
    f >> n;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            {   f >> dp[i][j];
                if(!dp[i][j]) dp[i][j] = inf;
            }
    for(int k=1; k<=n; k++)
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++)
                if(i != j && dp[i][k] != inf && dp[k][j] != inf) dp[i][j] = min(dp[i][j], dp[i][k]+dp[k][j]);
    for(int i=1; i<=n; i++)
        {   for(int j=1; j<=n; j++)
                {   if(dp[i][j] == inf) g << 0 << ' ';
                    else g << dp[i][j] << ' ';
                }
            g << '\n';
        }
    return 0;
}
