#include <iostream>
#include <fstream>
using namespace std;
const int INF = 1000000;

int n, C[101][101];

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

void citire()
{
    f >> n;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
        {
            f >> C[i][j];
            if(i!=j&&C[i][j] == 0)
                C[i][j] = INF;
        }
}

void roy_floyd()
{
    int cost;
    for(int k = 1; k <= n; k++)
        for(int i = 1; i <= n; i++)
            for(int j = 1; j <= n; j++)
            {
                cost = C[i][k] + C[k][j];
                if(cost < C[i][j])
                    C[i][j] = cost;
            }
}

void afis()
{
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
            if(C[i][j] != INF)
                g << C[i][j] << ' ';
            else
                g << "0 ";
        g << '\n';
    }
}

int main()
{
    citire();
    roy_floyd();
    afis();
    return 0;
}
