#include <bits/stdc++.h>

constexpr size_t MAXNODE = 100;
constexpr unsigned int INF = 0x7fffffffu;

std::array<std::array<unsigned int, MAXNODE>, MAXNODE> shortest_path;


int main () {
    int n;

    std::ifstream f("royfloyd.in");
    std::ofstream g("royfloyd.out");

    f >> n;

    for (int i = 0; i < n; ++ i)
        for (int j = 0; j < n; ++ j) {
            f >> shortest_path[i][j];
            if (shortest_path[i][j] == 0 && i != j)
                shortest_path[i][j] = INF;
        }

    for (int k = 0; k < n; ++ k)
        for (int i = 0; i < n; ++ i)
            for (int j = 0; j < n; ++ j)
                shortest_path[i][j] = std::min(
                    shortest_path[i][j],
                    shortest_path[i][k]
                    + shortest_path[k][j]);

    for (int i = 0; i < n; ++ i, g << '\n')
        for (int j = 0; j < n; ++ j) {
            if (shortest_path[i][j] == INF)
                shortest_path[i][j] = 0;
            g << shortest_path[i][j] << ' ';
        }

}
