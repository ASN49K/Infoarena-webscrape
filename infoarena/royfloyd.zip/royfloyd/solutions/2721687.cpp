#include <bits/stdc++.h>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n;
int rf[104][104];

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            fin>>rf[i][j];
        }
    }
    for(int k=1; k<=n; k++)
    {
        for(int i=1; i<=n; i++)
        {
            for(int j=1; j<=n; j++)
            {
                if(rf[i][k] && rf[k][j] && (rf[i][j] > rf[i][k] + rf[k][j] || !rf[i][j]) && i != j)
                    rf[i][j] = rf[i][k] + rf[k][j];
            }
        }
    }
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            fout<<rf[i][j]<<" ";
        }
        fout<<"\n";
    }
    return 0;
}
