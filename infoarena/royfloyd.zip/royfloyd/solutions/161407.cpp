#include<stdio.h>
#define INF 10000
#define nmax 105

int n;
int p[nmax][nmax];

void read()
{
     int i,j;
     freopen("royfloyd.in","r",stdin);
     freopen("royfloyd.out","w",stdout);
     scanf("%d", &n);
     for(i=1;i<=n;++i)
       for(j=1;j<=n;++j)
          scanf("%d",&p[i][j]);
}

void roy_floyd()
{
    int i,j,k;
    for(i=1;i<=n;++i)
      for(j=1;j<=n;++j)
        if(p[i][j]==0&&i!=j)
          p[i][j]=INF;
    
    
     for(k=1;k<=n;k++)
       for(i=1;i<=n;i++)
         for(j=1;j<=n;j++)
           if(p[i][j]>p[i][k]+p[k][j])
              p[i][j]=p[i][k]+p[k][j];
}

void print()
{
      int i,j;
      for(i=1;i<=n;++i)
      {
         for(j=1;j<=n;++j)
          if(p[i][j]==INF)
            printf("0 ");
           else
            printf("%d ",p[i][j]);
         printf("\n");
      }
}

int main()
{
     read();
     roy_floyd();
     print();
     return 0;
}

                      
