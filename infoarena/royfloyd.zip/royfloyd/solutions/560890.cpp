#include<cstdio>
using namespace std;
const int pinf=1001;
int main()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    int n,a[100][100],i,j,k;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
       for(j=1;j<=n;j++)
       {
           if(i==j) a[i][j]=0; else a[i][j]=pinf ;
           scanf("%d",&a[i][j]);
       }
     for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
          for(j=1;j<=n;j++)
            if(a[i][j]>a[i][k]+a[k][j])
               a[i][j]=a[i][k]+a[k][j];
     for(i=1;i<=n;i++)
      { for(j=1;j<=n;j++)
          {
              if(a[i][j]==pinf) printf("0 ");
              else printf("%d ", a[i][j]);
          }
         printf("\n");
      }
       return 0;
}
