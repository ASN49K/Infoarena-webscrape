/*
 	se da matricea costurilor (ponderilor) intr-un graf orientat.
	Sa se determine matrice drumurilor.
 */
#include <fstream>
#define MAX 101
using namespace std;

void read();
void rf();
void write();


int main(){
	read();rf();write();
	return 0;
}
int n,a[MAX][MAX];
void read(){
	ifstream fin("royfloyd.in");
	fin>>n;
	for(int i =1;i<=n;i++)
		for(int j=1; j<=n;j++)
			fin>>a[i][j];
	fin.close();
}

void rf(){
	for(int k =1; k<=n ;k++)
		for(int i=1;i<=n;i++)
			for(int j = 1; j<=n ;j++)
				if(a[i][k] && a[k][j] && (a[i][j]>a[i][k]+a[k][j] || a[i][j]==0) &&i!=j  )
					a[i][j] = a[i][k]+a[k][j];
}

void write(){
	ofstream fout("royfloyd.out");
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++)
			fout<<a[i][j]<<" ";
		fout<<endl;
	}
	fout.close();
}
