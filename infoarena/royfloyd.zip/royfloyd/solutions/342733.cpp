#include<stdio.h>
int adj[105][105];
int n;
int rf[105][105];

int main()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);

    scanf("%d",&n);
    for(int i = 1; i <= n; i++)
     for(int j = 1; j <= n; j++)
     {
      scanf("%d",&adj[i][j]);
      rf[i][j] = adj[i][j];
     }
    for(int k = 1; k <= n; k++)
     for(int i = 1; i <= n; i++)
      for(int j = 1; j <= n; j++)
       if (i != j)
        if (rf[i][k] && rf[k][j])
         if ((rf[i][j] > rf[i][k] + rf[k][j]) || (rf[i][j] == 0))
          rf[i][j] = rf[i][k] + rf[k][j];
    for(int i = 1; i <= n; i++)
    {
     for(int j = 1; j <= n; j++)
       printf("%d ",rf[i][j]);
       printf("\n");
    }
}
