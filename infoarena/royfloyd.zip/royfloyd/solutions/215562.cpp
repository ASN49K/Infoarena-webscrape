#include<stdio.h>
#define nmax 110

int v[nmax][nmax];

inline int min(int a, int b)
{
    if(a>b)
        return b;
    else return a;
}

int main()
{
    int n,i,j,k;
    
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    
    scanf("%d",&n);
    
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            scanf("%d",&v[i][j]);
            
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if( v[i][k] && v[k][j] && i != j)
                    if(v[i][j] > v[i][k] + v[k][j] || !v[i][j])
                        v[i][j]=v[i][k]+v[k][j];

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
            printf("%d ",v[i][j]);
        printf("\n");
    }
    
    return 0;
}
