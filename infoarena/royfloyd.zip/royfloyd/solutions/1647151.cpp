#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int a[103][103];

int main()
{
    int n, i, j, k;
    fin >> n;
    for(i = 1 ; i <= n ; i++)
    {
        for(j = 1 ; j <= n ; j++)
        {
            fin >> a[i][j];
        }
    }
    for(k = 1 ; k <= n ; k++)
    {
        for(i = 1 ; i <= n ; i++)
        {
            for(j = 1 ; j <= n ; j++)
            {
                if(i != j && a[i][k] && a[k][j] && a[i][j] > a[i][k] + a[k][j])
                    a[i][j] = a[i][k] + a[k][j];

            }
        }
    }
    for(i = 1 ; i <= n ; i++)
    {
        for(j = 1 ; j <= n ; j++)
        {
            fout << a[i][j] << " ";
        }
        fout << "\n";
    }
}
