#include<stdio.h>
#define infile "royfloyd.in"
#define outfile "royfloyd.out"
#define nmax 102
#define max 20000000

long d[nmax][nmax];
long n;

void read()
{
	long i,j;
	scanf("%ld",&n);
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
		{
			scanf("%ld ",&d[i][j]);
		}
	
}
void rf()
{
	long i,j,k;
	
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			for(k=1;k<=n;k++)
				if(d[j][i]+d[i][k]<d[j][k])
					d[j][k]=d[j][i]+d[i][k];
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
			printf("%ld ",d[i][j]==max?0:d[i][j]);
		printf("\n");
	}
}
int main()
{
	freopen(infile,"r",stdin);
	freopen(outfile,"w",stdout);
	read();
	rf();
	fclose(stdin);
	fclose(stdout);
	return 0;
}