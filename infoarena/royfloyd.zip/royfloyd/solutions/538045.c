/* 
 * File:   main.c
 * Author: slycer
 *
 * Created on February 20, 2011, 6:32 PM
 */

#include <stdio.h>
#include <stdlib.h>

int INFINIT = 1<<15; 

int min ( int a, int b ){
    if ( a<b){
        return a;
    }
    return b; 
}

/*
 * 
 */
int main(int argc, char** argv) {

    FILE * in = fopen("royfloyd.in","r");
    FILE * out = fopen("royfloyd.out","w");

    int n;
    int d[101][101];
    
    fscanf(in,"%d",&n);

    int i,j;
    for ( i=0; i<n; i++){
        for ( j=0; j<n; j++){
            fscanf(in,"%d",&d[i][j]);
            if ( i!=j && d[i][j]==0){
                d[i][j] = INFINIT;
            }
        }
    }

    int k;
    for ( k=0; k<n; k++){
        for ( i=0; i<n; i++){
            for ( j=0; j<n; j++){
                // d[i][j]
                d[i][j] = min( d[i][j], d[i][k]+d[k][j]);
            }
        }
    }

    for ( i=0; i<n; i++){
        for ( j=0; j<n; j++){
            fprintf(out,"%d ",d[i][j]);
           // printf("%d",d[i][j]);
        }
        fprintf(out,"\n");
    }

    fclose( in );
    fclose( out );
    
    return (EXIT_SUCCESS);
}

