
#include<bits/stdc++.h>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int ma[101][101],n;
int main()
{
    f>>n;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
        f>>ma[i][j];

    for(int k=1;k<=n;++k)
        for(int i=1;i<=n;++i)
        if(ma[i][k])
        for(int j=1;j<=n;++j)
    {
        if(ma[k][j]&& (ma[i][j]==0 || ma[i][j]>ma[i][k]+ma[k][j]) && i!=j)
            ma[i][j]=ma[i][k]+ma[k][j];
    }
    for(int i=1;i<=n;++i)
    {
        for(int j=1;j<=n;++j)
            g<<ma[i][j]<<' ';
        g<<'\n';
    }
}
