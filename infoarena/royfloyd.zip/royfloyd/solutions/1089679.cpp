#include <cstdio>
using namespace std;

int n,d[100][100];
const int inf=1<<30;


void read()
{
    int x,i,j;
    freopen("royfloyd.in","r",stdin);
    scanf("%d",&n);
    for(i=0;i<n;++i)
    {
        for(j=0;j<n;++j)
        {
            scanf("%d",&x);
            if(i!=j)
            {
                if(x) d[i][j]=x;
                else d[i][j]=inf;
            }
        }
    }
}

void royfloyd()
{
    int i,j,k;
    for(k=0;k<n;++k)
    {
        for(i=0;i<n;++i)
        {
            for(j=0;j<n;++j)
            {
                if(d[i][j]>d[i][k]+d[k][j])
                {
                    d[i][j]=d[i][k]+d[k][j];
                }
            }
        }
    }
}

void write()
{
    freopen("royfloyd.out","w",stdout);
    int i,j;
    for(i=0;i<n;++i)
    {
        for(j=0;j<n;++j)
        {
            if(i!=j&&d[i][j]!=inf) printf("%d ",d[i][j]);
            else printf("0 ");
        }
        printf("\n");
    }
}

int main()
{
    read();
    royfloyd();
    write();
    return 0;
}
