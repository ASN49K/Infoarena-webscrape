#include <fstream>



using namespace std;



ifstream in("royfloyd.in");

ofstream out("royfloyd.out");



#define INF 1000000000

#define MAX_N 100



int dp[MAX_N + 1][MAX_N  + 1];



int main()

{

    int n;

    in >> n;



    for(int i = 1; i <= n; i ++)

        for(int j = 1; j <= n; j ++)

        {

            if(i == j)

                dp[i][j] = 0;

            else

                dp[i][j] = INF;

        }



    for(int i = 1; i <= n; i ++)

        for(int j = 1; j <= n; j++)

        in >> dp[i][j];



    for(int k = 1; k <=n; k ++)

        for(int i = 1; i <= n; i ++)

           for(int j = 1; j <= n; j ++)

             dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j]);



    for(int i = 1; i <= n; i ++)

    {

        for(int j = 1; j <= n; j ++)

            if(dp[i][j] == INF)

                out << "0 ";

            else

                out << dp[i][j] << " ";

        out << "\n";

    }

    return 0;

}



