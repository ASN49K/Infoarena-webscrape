#include<fstream>
using namespace std;
#define filein "royfloyd.in"
#define fileout "royfloyd.out"
#define NMAX 100
#define MIN(a,b) ((a>b) ? b : a)
FILE *in, *out;
int M[NMAX][NMAX], N;


int main(void)
{
	in = fopen(filein, "r");
    fscanf(in, "%d", N);

    for(int i = 0; i < N; i++)
        for(int j = 0; j < N; j++)
            fscanf(in, "%d", &M[i][j]);
    fclose(in);

    for(int k = 0; k < N; k++)
        for(int i = 0; i < N; i++)
            for(int j = 0; j < N; j++)
                if(M[i][j] != 0)
                    M[i][j] = MIN(M[i][j], M[i][k] + M[k][j]);

    out = fopen(fileout, "w");

    for(int i = 0; i < N; i++){
        for(int j = 0; j < N; j++)
            fprintf(out, "%d ", M[i][j]);
        fprintf(out, "\n");
    }

    fclose(out);
    return 0;
}
