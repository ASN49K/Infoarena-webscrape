#include<iostream>
#include<fstream>
#define NMAX 100
using namespace std;



int main(){
	ifstream f("royfloyd.in", ios::in);//Change the name
	ofstream g("royfloyd.out", ios::out);//Change the name

	int N;
	int a[NMAX][NMAX];

	f >> N;
	for (int i = 0; i < N; ++i)
	for (int j = 0; j < N; ++j){
		f >> a[i][j];
	}

	for (int k = 0; k < N;++k)
	for (int i = 0; i < N;++i)
	for (int j = 0; j < N; ++j){
		if (a[i][k] && a[k][j] && ((a[i][k] + a[k][j]) < a[i][j] || !a[i][j]) && i != j)
			a[i][j] = a[i][k] + a[k][j];

	}

	for (int i = 0; i < N; ++i){
	for (int j = 0; j < N; ++j)
		g<< a[i][j]<<' ';
		g << '\n';
	}

	f.close();
	g.close();
	return 0;
}