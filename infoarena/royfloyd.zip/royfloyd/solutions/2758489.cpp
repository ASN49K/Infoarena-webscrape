#include <fstream>
#include <vector>
#include <deque>
#include <cstring>
#include <queue>
#include <limits.h>
#include <unordered_map>

using namespace std;
ifstream cin("royfloyd.in") ;
ofstream cout("royfloyd.out") ;

int fin[109][109], m[109][109], n ;

int main()
{

    cin >> n ;

    for(int f = 1 ; f <= n ; f ++)
        for(int e = 1 ; e <= n ; e ++)
            cin >> fin[f][e] ;

    for(int f = 1 ; f <= n ; f ++)
        for(int e = 1 ; e <= n ; e ++)
            if(!fin[f][e])fin[f][e] = INT_MAX / 2 ;

    for(int k = 1 ; k <= n ; k ++)
        for(int f = 1 ; f <= n ; f ++)
            for(int e = 1 ; e <= n ; e ++)
                fin[f][e] = min(fin[f][e], fin[f][k] + fin[k][e]) ;

    for(int f = 1 ; f <= n ; f ++)
        for(int e = 1 ; e <= n ; e ++)
            if(fin[f][e] == INT_MAX / 2 || f == e)fin[f][e] = 0 ;

    for(int f = 1 ; f <= n ; f ++)
    {

        for(int e = 1 ; e <= n ; e ++)
            cout << fin[f][e] << " " ;

        cout << '\n' ;

    }

    return 0 ;

}
