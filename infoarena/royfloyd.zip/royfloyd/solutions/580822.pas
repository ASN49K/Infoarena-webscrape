type matrice=array[1..200,1..200] of integer;
var a:matrice;
    f,g:text;
    i,j,n,k:integer;
procedure citire;
begin
assign(f,'royfloyd.in');reset(f);
assign(g,'royfloyd.out');rewrite(g);
readln(f,n);
for i:=1 to n do
 for j:=1 to n do
     begin
     read(f,a[i,j]);
     if a[i,j]=0 then a[i,j]:=maxint;
     end;
for i:=1 to n do
a[i,i]:=0;
end;

procedure roy_floyd;
begin
for k:=1 to n do
 for i:=1 to n do
  for j:=1 to n do
   if (a[i,j]>a[i,k]+a[k,j])  then
      a[i,j]:=a[i,k]+a[k,j];
end;
procedure afisare;
begin
for i:=1 to n do
  begin
  for j:=1 to n do
   if a[i,j]=maxint then write(g,'0 ') else write(g,a[i,j],' ');
  writeln(g);
  end;
end;


begin
citire;
roy_floyd;
afisare;
close(g);
end.
