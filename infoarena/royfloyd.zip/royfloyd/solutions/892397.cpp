#include <stdio.h>
#include <fstream>
#define INF 999999999
using namespace std;
int T[105][105];
int N;
void Read(){
    freopen("royfloyd.in","r",stdin);
    scanf("%d\n",&N);
    int i,j,n=N;
//    printf("%d",N)
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++){
            scanf("%d",&T[i][j]);
            if(T[i][j]==0&&i!=j)
                T[i][j]=INF;
        }
    fclose(stdin);
}
void RoyFloyd(){
    int i,j,k,n=N;
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
            {
                if(T[i][j]>T[i][k]+T[k][j])
                    T[i][j]=T[i][k]+T[k][j];
            }
        }
    }
}
void Write(){
    int i,j,n=N;
    ofstream fout("royfloyd.out");
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++)
            fout<<T[i][j]<<' ';
        fout<<'\n';
    }
    fout.close();
}
int main()
{
    Read();
    RoyFloyd();
    Write();
    return 0;
}
