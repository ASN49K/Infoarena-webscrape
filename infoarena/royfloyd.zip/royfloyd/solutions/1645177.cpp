#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
int n, a[101][101];
int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            fin>>a[i][j];
        }
    }
    for(int k=1;k<=n;k++)
    {
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                if(i!=j&&i!=k&&j!=k&&a[i][k]!=0&&a[k][j]!=0)
                {
                    a[i][j]=min(a[i][j], a[i][k]+a[k][j]);
                }
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            fout<<a[i][j]<<' ';
        }
        fout<<'\n';
    }
    fin.close();
    fout.close();
    return 0;
}
