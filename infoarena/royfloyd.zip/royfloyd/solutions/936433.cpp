#include <fstream>
using namespace std;

int main() {
	ifstream fin("royfloyd.in");
	ofstream fout("royfloyd.out");
	int n;
	fin >> n;
	int a[n][n];
	for (int i = 0; i < n; ++i)
		for (int j = 0; j < n; ++j)
			fin >> a[i][j];

	for (int k = 0; k < n; ++k)
		for (int i = 0; i < n; ++i)
			for (int j = 0; j < n; ++j)
				if (a[i][k] != 0 && a[k][j] != 0)
					a[i][j] = min(a[i][j], a[i][k]+a[k][j]);

   for (int	i = 0; i < n; ++i) {
	   for (int j = 0; j < n; ++j)
		   fout << a[i][j] << ' ';
	   fout << '\n';
	}
	return 0;
}
