#include "bits/stdc++.h"
#define inf  INT_MAX
const int SIZE = 100;
int dist[SIZE + 5][SIZE + 5];
int n;
void Debug(){
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n; j++){
			if(dist[i][j] == inf)
				std :: cout << 0 << ' ';
			else
			 std :: cout << dist[i][j] << ' ';
		}
		std :: cout << '\n';
	}
}
void Floyd(){
	for(int k = 1; k <= n; k++){
		for(int i = 1; i <= n; i++){
			for(int j = 1; j <= n; j++){
				if(dist[i][k] != inf and dist[k][j] != inf and dist[i][j] != inf and dist[i][j] > dist[i][k] + dist[k][j]){
					dist[i][j] = dist[i][k] + dist[k][j];
				}
			}
		}
	}
}
void Solve(){
	std :: cin >> n;
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n; j++){
			std :: cin >> dist[i][j];
			if(dist[i][j] == 0){
				dist[i][j] = inf;
			}
		}
	}
	Floyd();
	Debug();
}
signed main(){
	freopen("royfloyd.in", "r", stdin);
	freopen("royfloyd.out", "w", stdout);
	std :: ios_base :: sync_with_stdio(false);
	std :: cin.tie(0);
	std :: cout.tie(0);
	Solve();
	return 0;
}
