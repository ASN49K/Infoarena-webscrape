#include <bits/stdc++.h>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int d[105][105],n;
const int inf=INT_MAX;

void init(int n)
{
    for (int i=1; i<=n; i++ )
        for (int j=1; j<=n; j++ )
            d[i][j]=inf;

    for (int i=1; i<=n; i++ )
        d[i][i]=inf;
}

void royf(int n)
{
    for (int k=1; k<=n; k++ )
        for (int i=1; i<=n; i++ )
            for (int j=1; j<=n; j++ )
                if ( d[i][k]!=inf && d[k][j]!=inf )
                     d[i][j]=min(d[i][j],d[i][k]+d[k][j]);
}

int main()
{
    f >> n;

    init(n);

    for (int i=1; i<=n; i++ )
        for (int j=1; j<=n; j++ )
            f >> d[i][j];

    royf(n);

    for (int i=1; i<=n; i++, g << '\n' )
        for (int j=1; j<=n; j++ )
           if ( d[i][j]==inf ) g << 0 << " ";
             else g << d[i][j] << " ";
    return 0;
}
