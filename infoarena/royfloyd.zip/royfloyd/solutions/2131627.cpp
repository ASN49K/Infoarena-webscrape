#include <iostream>
#include <fstream>
#include <vector>
#include <bits/stdc++.h>
#include <algorithm>
std::ifstream in("royfloyd.in");
std::ofstream out("royfloyd.out");
int d[101][101];
int main()
{
    int n;
    in >> n;
    for(int i = 0 ; i < n ; i++)
        for(int j = 0 ;  j < n ; j++)
            in >> d[i][j];
    for(int k = 0 ; k < n ; k++)
        for(int i = 0 ; i < n ; i++)
            for(int j = 0 ; j < n ; j++)
                d[i][j] = std::min(d[i][j],d[i][k]+d[k][j]);
    for(int i = 0 ; i < n ;i++)
    {
        for(int j = 0 ; j < n ; j++)
            out<<d[i][j]<<" ";
        out<<'\n';
    }
    return 0;
}
