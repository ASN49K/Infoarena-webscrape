#include <fstream>
#include <cstring>
using namespace std;

 ifstream cin ("royfloyd.in");
 ofstream cout ("royfloyd.out");

void royfloyd(int a[][101],int n)
{
    for(int k=1;k<=n;++k)
        for(int i=1;i<=n;++i)
        if(i == k )continue;
        else
            for(int j=1;j<=n;++j)
            if(j == i || j == k)continue;
            else
            a[i][j] = min(a[i][j] , a[i][k] + a[k][j]);
}

int main()
{
    int a[101][101],n;
    cin >> n;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)cin >> a[i][j];

    royfloyd(a,n);

    for(int i=1;i<=n;++i)
    {
        for(int j=1;j<=n;++j)cout << a[i][j] << ' ';
        cout<<'\n';
    }
}
