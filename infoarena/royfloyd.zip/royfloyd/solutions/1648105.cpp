#include <iostream>
#include <fstream>
using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int cost[101][101], a[101][101], viz[101];
int n,m,j,i;
void RoyFloyd() {
int i,j,k;
for (i=1;i<=n;i++)
    for (j=1;j<=n;j++)
        for (k=1;k<=n;k++)
            if (cost[i][k] + cost[k][j] < cost[i][j])
                cost[i][j] = cost[i][k] + cost[k][j];
}

int main()
{
    f>>n;
    for (i=1;i<=n;i++)
        for (j=1;j<=n;j++)
            f>>cost[i][j];
    RoyFloyd();
    for (i=1;i<=n;i++)  {
        for (j=1;j<=n;j++)
            g<<cost[i][j]<<"\t";
        g<<"\n";
    }

    return 0;
}
