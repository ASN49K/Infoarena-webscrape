#include <iostream>
#include <algorithm>
#include <fstream>
using namespace std;

int i,j,n,C[101][101],tata[101][101];


void roy_floyd ()
{
   int i, j, k;
   for (k=1;k<=n;k++)
      for (i=1;i<=n;i++)
         for (j=1;j<=n;j++)
            if (C[i][k]!=-1 && C[k][j]!=-1)
               if (C[i][j]>C[i][k]+C[k][j])
               {
                  C[i][j] = C[i][k]+C[k][j];
                  tata[i][j] = tata[k][j];
               }
}

int main ()
{
	FILE *f,*g;
	f=fopen("royfloyd.in", "r");
	g=fopen("royfloyd.out", "w");
	fscanf(f, "%d", &n);
	for (i=1; i<=n; i++)
		for(j=1; j<=n; j++) 
		{
			fscanf(f, "%d", &C[i][j]);
			if (i!=j && C[i][j]==0) C[i][j]=-1;
			tata[i][j]=j;
		}
	roy_floyd();
	for (i=1; i<=n; i++, fprintf(g, "\n"))
		for(j=1; j<=n; j++) 
			fprintf(g, "%d ", C[i][j]);
	return 0;
}