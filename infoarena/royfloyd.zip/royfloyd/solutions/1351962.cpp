#include<fstream>
using namespace std;
int i,j,a[101][101],b[101][101],n,k;
int main()
{
     ifstream fin("royfloyd.in");
    ofstream fout("royfloyd.out");
    fin>>n;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            fin>>a[i][j];
            if(a[i][j]==0 && i!=j)
            {
                a[i][j]=1000000000;
            }
            b[i][j]=a[i][j];
        }
    }
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
            {
                if(b[i][k]+b[k][j]<b[i][j])
                {
                    b[i][j]=b[i][k]+b[k][j];
                }
            }
        }
    }
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            if(b[i][j]==1000000000)
            {
                fout<<"0 ";
            }
            else
            {
                fout<<b[i][j]<<" ";
            }
        }
        fout<<"\n";
    }
    fin.close();
    fout.close();
    return 0;
}
