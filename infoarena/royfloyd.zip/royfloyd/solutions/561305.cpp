#include <stdio.h>

int c[100][100],n,i,j,k;

int main ()
{
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	scanf("%d", &n);
	for(i=1;i<=n;i++) 
		for(j=1;j<=n;j++) 
		scanf("%d", &c[i][j]);
	for(k=1;k<=n;k++)
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				if (c[i][k] && c[k][j])
					if((c[i][j] > c[i][k] + c[k][j] || !c[i][j]) && i!=j) c[i][j]=c[i][k]+c[k][j];
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++) printf("%d ", c[i][j]);
		printf("\n");
	}
	return 0;
}