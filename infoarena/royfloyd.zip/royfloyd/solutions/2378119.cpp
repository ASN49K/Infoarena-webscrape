#include "stdio.h"

int main()
{
    int N;
    int A[100][100];
    int i, j, k;
    int tmp;

    FILE *inFile = fopen("royfloyd.in", "r");
    FILE *outFile = fopen("royfloyd.out", "w");

    fscanf(inFile, "%d", &N);

    for(i = 0; i < N; i++) {
        for(j = 0; j < N; i++) {
            fscanf(inFile, "%d", &tmp);
            A[i][j] = tmp;
        }
    }

    for(k = 0; k < N; k++) {
        for(i = 0; i < N; i++) {
            for(j = 0; j < N; j++) {
                tmp =  A[i][k] + A[k][j];
                if((A[i][j] == 0) || (A[i][j] > tmp)) {
                    A[i][j] = tmp;
                }
            }
        }
    }

    for(i = 0; i < N; i++) {
        for(j = 0; j < N; j++) {
            tmp = A[i][j];
            fprintf(outFile, "%d", tmp);
        }
        fprintf(outFile, "\n");
    }

    fclose(inFile);
    fclose(outFile);

    return 0;
}