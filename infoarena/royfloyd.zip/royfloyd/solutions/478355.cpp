/* 
 * File:   main.cpp
 * Author: bitone
 *
 * Created on August 18, 2010, 11:07 AM
 */
#include <limits>
#include <fstream>
#include <cstdlib>
#define MAX_N 111
#define oo std::numeric_limits<signed int>::max()/2

using namespace std;

/*
 * 
 */
typedef signed int sint;
sint C[MAX_N][MAX_N];
int main(int argc, char** argv)
{
    sint N, i, j, k;
    ifstream in( "royfloyd.in" );
    in>>N;
    for( i=1; i <= N; ++i )
        for( j=1; j <= N; ++j )
        {
            in>>C[i][j];
            C[i][j]=( C[i][j] == 0 ? oo : C[i][j] );
        }
    for( k=1; k <= N; ++k )
        for( i=1; i <= N; ++i )
            if( i != k )
                for( j=1; j <= N; ++j )
                    if( i != j && j != k && C[i][k]+C[k][j] < C[i][j] )
                        C[i][j]=C[i][k]+C[k][j];
    ofstream out( "royfloyd.out" );
    for( i=1; i <= N; ++i )
    {
        for( j=1; j <= N; ++j )
        {
            out<<( C[i][j] == oo ? 0 : C[i][j] )<<' ';
        }
        out<<'\n';
    }
    return EXIT_SUCCESS;
}

