#include <fstream>
#include <algorithm>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

const int MAX_N = 105;
const int INF = 0x3f3f3f3f;

int n, A[MAX_N][MAX_N];

void read() {
    f >> n;

    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            A[i][j] = INF;

    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            f >> A[i][j];
}

void solve() {
    for (int k = 1; k <= n; k++)
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++)
                if (A[i][k] + A[k][j] < A[i][j])
                    A[i][j] = A[i][k] + A[k][j];
}

void write() {
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++)
            if (A[i][j] != INF)
                g << A[i][j] << " ";
            else
                g << 0 << " ";
        g << '\n';
    }
}

int main() {
    read();
    solve();
    write();

    return 0;
}
