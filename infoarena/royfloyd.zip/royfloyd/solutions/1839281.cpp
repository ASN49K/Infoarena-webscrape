#include <bits/stdc++.h>

using namespace std;

#define SIZE(x) ((int) (x).size())
#define ALL(x) (x).begin(), (x).end()

typedef long long int64; typedef unsigned long long uint64;
static const int INF = 0x3f3f3f3f; static const long long INFL = 0x3f3f3f3f3f3f3f3fLL;

const int NMAX = 105;

int dist[NMAX][NMAX];
int N;

void floydWarshall() {
    for (int k = 1; k <= N; k++) {
        for (int i = 1; i <= N; i++) {
            for (int j = 1; j <= N; j++) {
                dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
            }
        }
    }
}

int main() {
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);
    scanf("%d", &N);
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N; j++) {
            scanf("%d", &dist[i][j]);
            if (dist[i][j] == 0 && i != j) dist[i][j] = INF;
        }
    }
    floydWarshall();
    for (int i = 1; i <= N; i++) {
        int num = 0;
        for (int j = 1; j <= N; j++) {
            if (num++) printf(" ");
            if (dist[i][j] >= INF) dist[i][j] = 0;
            printf("%d", dist[i][j]);
        }
        printf("\n");
    }
}
