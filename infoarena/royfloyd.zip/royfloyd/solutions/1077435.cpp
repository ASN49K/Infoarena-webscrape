# include <cstdio>

const int N = 100;

int a [N + 1] [N + 1];
int n;

void init ()
{
    int i, j;

    freopen ("royfloyd.in", "r", stdin);
    freopen ("royfloyd.out", "w", stdout);
    scanf ("%d", & n);

    for (i = 1; i <= n; i ++)
        for (j = 1; j <= n; j ++)
            scanf ("%d", & a [i] [j]);
}

void rezolva ()
{
    int i, j, i1;

    for (i = 1; i <= n; i ++)
        for (j = 1; j <= n; j ++)
            if (j != i)
                for (i1 = 1; i1 <= n; i1 ++)
                    if (a [i] [i1] > 0 && a [i1] [j])
                        if (a [i] [i1] + a [i1] [j] < a [i] [j] || a [i] [j] == 0)
                            a [i] [j] = a [i] [i1] + a [i1] [j];
}

void afis ()
{
    int i, j;

    for (i = 1; i <= n; i ++)
    {
        for (j = 1; j <= n; j ++)
            printf ("%d ", a [i] [j]);

        printf ("\n");
    }

}


int main ()
{
    init ();
    rezolva ();
    afis ();

    return 0;
}
