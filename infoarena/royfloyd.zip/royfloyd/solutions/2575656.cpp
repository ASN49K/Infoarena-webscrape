#include <iostream>
#include <fstream>
using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int ad[105][105], n;

void RF()
{
    int i, j, k;
    for(k=1; k<=n; k++)
    {
        for(i=1; i<=n; i++)
        {
            for(j=1; j<=n; j++)
            {
                if(ad[i][k] && ad[j][k] && (ad[i][j] > ad[i][k] + ad[k][j] || (!ad[i][j] && i != j)))
                {
                    ad[i][j] = ad[i][k] + ad[k][j];
                }
            }
        }
    }
}

int main()
{
    int i, j;
    fin>>n;
    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++)
        {
            fin>>ad[i][j];
        }
    }

    RF();

    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++)
        {
            fout<<ad[i][j]<<' ';
        }
        fout<<endl;
    }
    fin.close();
    fout.close();
    return 0;
}
