#include <stdio.h>
int n,a[105][105];
void citire()
{
	freopen("royfloyd.in","r",stdin);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		for(int j=1l;j<=n;j++)
			scanf("%d",&a[i][j]);
}
void royfloyd()
{
	for(int k=1;k<=n;k++)
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				if (a[i][k]&&a[k][j]&&(a[i][k]+a[k][j]<a[i][j] || !a[i][j])&&i!=j)
					a[i][j]=a[i][k]+a[k][j];
}
void afisare()
{
	freopen("royfloyd.out","w",stdout);
	for(int i=1;i<=n;i++)
	{	
		for(int j=1;j<=n;j++)
				printf("%d ",a[i][j]);
		printf("\n");
	}
}
int main()
{
	citire();
	royfloyd();
	afisare();
	return 0;
}