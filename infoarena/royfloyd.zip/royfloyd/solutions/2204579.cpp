#include <iostream>
#include <fstream>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
const int INF = 9999999; //+infinit
int n, C[101][101];

void citire()
{
    int c;
    f >> n;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
        {
            f >> c;
            if(c == 0 && i != j)
                C[i][j] = INF;
            else
                C[i][j] = c;
        }
}

void Roy_Floyd()
{
    for(int k = 1; k <= n; k++)
        for(int i = 1; i <= n; i++)
            for(int j = 1; j <= n; j++)
            {
                int cost = C[i][k] + C[k][j];
                if(cost < C[i][j])
                    C[i][j] = cost;
            }
}

void afis()
{
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
            if(C[i][j] == INF)
                g << "0 ";
            else
                g << C[i][j] << ' ';
        g << endl;
    }
}

int main()
{
    citire();
    Roy_Floyd();
    afis();
    return 0;
}
