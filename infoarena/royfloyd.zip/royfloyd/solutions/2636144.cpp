#include <fstream>
#include <algorithm>
#include <vector>
#include <iterator>
#include <queue>
using namespace std;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");
#define NMAX 105
#define inf 0x6969

int mat[NMAX][NMAX],n;

void citire()
{
    in >> n;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
        {
            in >> mat[i][j];
            if (!mat[i][j]) mat[i][j] = inf;
        }
}

void roy()
{
    for (int k = 1; k <= n; k++)
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++)
                if ((mat[i][k] + mat[k][j] < mat[i][j])&&(mat[i][k]!=inf)&&(mat[k][j]!=inf))
                    mat[i][j] = mat[i][k] + mat[k][j];
}

void afisare()
{
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
            if (mat[i][j] != inf && i != j)
                out << mat[i][j] << ' ';
            else
                out << 0 << ' ';

        out << '\n';
    }
}

int main()
{
    citire();
    roy();
    afisare();
}


