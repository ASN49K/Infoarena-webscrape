#include <fstream>
#define MAX 101

using namespace std;

int c[MAX][MAX], n;

int main()
{
    int i, j, k;
    
    ifstream fin("royfloyd.in");
    fin >> n;
    for (i = 1; i <= n; i++)    
        for (j = 1; j <= n; j++)
            fin >> c[i][j];
    fin.close();
    
    for (k = 1; k <= n; k++)
        for (i = 1; i <= n; i++)
            for (j = 1; j <= n; j++)
                if (c[i][j] > c[i][k] + c[k][j])
                    c[i][j] = c[i][k] + c[k][j];
    
    ofstream fout("royfloyd.out");
    for (i = 1; i <= n; i++)
    {
         for (j = 1; j <= n; j++)
             fout << c[i][j] << " ";
         fout << "\n";
    }
    
    fout.close();
}
