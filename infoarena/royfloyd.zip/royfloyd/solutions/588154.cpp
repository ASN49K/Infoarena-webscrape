#include<fstream.h>
int main()
{ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int i,j,n,a[101][101],d[101][101],k;
f>>n;
for(i=1;i<=n;i++)
for(j=1;j<=n;j++)
       {f>>a[i][j],d[i][j]=a[i][j];
       if(i!=j&&d[i][j]==0)
              d[i][j]=1001;}
for(k=1;k<=n;k++)
for(i=1;i<=n;i++)
for(j=1;j<=n;j++)
if(d[i][j]>d[i][k]+d[k][j])
       d[i][j]=d[i][k]+d[k][j];
for(i=1;i<=n;i++)
       {for(j=1;j<=n;j++)
               g<<d[i][j]<<" ";
       g<<"\n";}
f.close();
g.close();
return 0;}
