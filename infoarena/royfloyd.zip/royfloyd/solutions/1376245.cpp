#include <fstream>

using namespace std;

int main()
{
    ifstream fin("royfloyd.in");
    ofstream fout("royfloyd.out");
    int n;
    fin >> n;
    int a[n + 1][n + 1];
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            fin >> a[i][j];
        }
    }
    for(int k = 1; k <= n; k++)
    {
        for(int i = 1; i <= n; i++)
        {
            for(int j = 1; j <= n; j++)
            {
                if(a[i][k] != 0 && a[k][j] != 0 && (a[i][j] > a[i][k] + a[k][j] || a[i][j] == 0) && i != j)
                {
                    a[i][j] = a[i][k] + a[k][j];
                }
            }
        }
    }
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            fout << a[i][j] << ' ';
        }
        fout << '\n';
    }
    return 0;
}
