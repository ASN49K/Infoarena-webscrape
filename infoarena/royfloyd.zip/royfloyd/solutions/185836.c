#include <stdio.h>
#define FOR(i,a,b) for(i=a;i<=b;++i)
int n,k,i,j;
long g[101][101];
    
int main()
{
    freopen("royfolyd.in","r",stdin);
    freopen("royfolyd.out","w",stdout);
    scanf("%d\n",&n);
    FOR (i,1,n)
        FOR (j,1,n)
            scanf("%ld",&g[i][j]);
    
    
    FOR (k,1,n)
        FOR (i,1,n)
            FOR (j,1,n)
                if (((g[i][k]+g[k][j] < g[i][j]) || (!g[i][j])) && (i!=j) && (g[i][k]) && (g[k][j]))
                   g[i][j]=g[i][k]+g[k][j];
    
    FOR (i,1,n)
    {
        FOR (j,1,n)
            printf("%ld ",g[i][j]);
        printf("\n");
    }
    return 0;
}
