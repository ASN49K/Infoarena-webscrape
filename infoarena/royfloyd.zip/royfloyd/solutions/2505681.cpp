#include <fstream>

using namespace std;

ifstream in("dijkstra.in");
ofstream out("dijkstra.out");

int n, a[101][101];
int main()
{
    in>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            in>>a[i][j];
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                if(a[i][j]>a[i][k]+a[k][j]&&a[i][k]&&a[k][j])
                    a[i][j]=a[i][k]+a[k][j];
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++)
            out<<a[i][j]<<' ';
        out<<'\n';
    }
    return 0;
}
