#include <fstream>

using namespace std;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");
int n, a[101][101];

void royfloyd()
{
    for(int k=1;k<=n;k++)
       {
           for(int i=1;i<=n;i++)
           {
               for(int j=1;j<=n;j++)
               {
                   if(a[i][k]!=0 && a[k][j]!=0 && (a[i][j]==0 || (a[i][j]>a[i][k]+a[k][j])) && i!=j) a[i][j]=a[i][k]+a[k][j];
               }
           }
       }
}
int main()
{
    in>>n;
    for(int i=1;i<=n;i++)
       for(int j=1;j<=n;j++) in>>a[i][j];


       royfloyd();

       for(int i=1;i<=n;i++)
       {
           for(int j=1;j<=n;j++) out<<a[i][j]<<" ";
           out<<"\n";
       }
    return 0;
}
