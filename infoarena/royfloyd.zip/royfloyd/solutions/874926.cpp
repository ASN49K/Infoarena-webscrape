#include <fstream>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int n,a[150][150],i,j;

void FloydWarshall()
{
    int i,j,k;
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if(a[i][k]!=0 && a[k][j]!=0 && i!=j && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]))
                    a[i][j]=min(a[i][j],a[i][k]+a[k][j]);
                }

int main()
{
    f >> n ;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            f >> a[i][j];

    FloydWarshall();

    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++)
            g << a[i][j] << " ";
            g << '\n';
            }

    f.close();
    g.close();

    return 0;
}
