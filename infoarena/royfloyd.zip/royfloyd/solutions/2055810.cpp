#include <fstream>
#include <algorithm>

using namespace std;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int n;
int v[105][105];

int main()
{
    in >> n;

    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            in >> v[i][j];

    for (int k = 1; k <= n; k++)
    {
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                if (v[i][k] != 0 && v[k][j] != 0 && i != j)
                {
                    if (v[i][k] + v[k][j] < v[i][j] || v[i][j] == 0)
                        v[i][j] = v[i][k] + v[k][j];
                }
            }
        }
    }

    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            out << v[i][j] << ' ';
        }
        out << '\n';
    }

    return 0;
}
