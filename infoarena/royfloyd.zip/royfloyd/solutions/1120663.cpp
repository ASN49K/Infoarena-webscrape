
#include <fstream>
using namespace std;
ifstream cin ("royfloyd.in" ) ;
ofstream cout ("royfloyd.out");
int a[105][105],n,k,i,j;

void royd_floyd()
{
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
        if(a[ i ][ k ] && a[ k ][ j ] && (a[ i ][ k ]+a[ k ][ j ]<a[ i ][ j ]|| !a[ i ][ j ]) && i!=j)
    a[i][j]=a[i][k]+a[k][j] ;
}

void afisare()
{
    for(i=1;i<=n;i++)
        {for(j=1;j<=n;j++)
        cout<<a[i][j]<<" ";
        cout<<"\n";}
    cout.close();
}

int main()
{

    cin>>n;
    for(int i=1;i<=n;++i)
    for(int j=1;j<=n;++j)
        cin>>a[i][j];
    royd_floyd();
    afisare();
    cout.close();
    cin.close();
    return 0;
}
