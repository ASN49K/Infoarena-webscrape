// infoarenaDFSnonRec.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include <fstream>
#include <assert.h>

#define MaxN 102
#define INF 123456789

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int N;
int dist[MaxN][MaxN];

int max(int a, int b) {
	return a > b ? a : b;
}

int main()
{
	fin >> N;
	for (int i = 0; i < N; ++i)
		for (int j = 0; j < N; ++j) {
			fin >> dist[i][j];
			if (dist[i][j] == 0) {
				dist[i][j] = INF;
			}
		}
	
	for (int k = 0; k < N; ++k) {
		for (int i = 0; i < N; ++i) {
			for (int j = 0; j < N; ++j) {
				if (i != j && i != k && dist[i][j] > dist[i][k] + dist[k][j]) {
					dist[i][j] = dist[i][k] + dist[k][j];
				}
			}
		}
	}

	for (int i = 0; i < N; ++i) {
		for (int j = 0; j < N; ++j) {
			fout << (i == j ? 0 :(dist[i][j] == INF ? 0 : dist[i][j])) << ' ';
		}
		fout << '\n';
	}

	return 0;
}

