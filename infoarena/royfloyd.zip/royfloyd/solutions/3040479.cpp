#include<fstream>
#include<vector>
#include<queue>

#define pii pair<int,int>
#define fi first
#define se second

using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
int n;
int dp[101][101];
int main(){
    fin >> n;
    for(int i = 1 ; i <= n ; ++ i){
        for(int j = 1 ; j <= n ; ++ j){
            fin >> dp[i][j];
        }
    }
    for(int k = 1 ; k <= n ; ++ k){
        for(int i = 1 ; i <= n ; ++ i){
            for(int j = 1 ; j <= n ; ++ j){
                if(k != i && k != j && i != j && dp[i][k] && dp[k][j] && (!dp[i][j] || dp[i][j] > dp[i][k] + dp[k][j]))
                    dp[i][j] = dp[i][k] + dp[k][j];
            }
        }
    }
    for(int i = 1 ; i <= n ; ++ i){
        for(int j = 1 ; j <= n ; ++ j){
            fout << dp[i][j] << ' ';
        }
        fout << '\n';
    }
    return 0;
}
