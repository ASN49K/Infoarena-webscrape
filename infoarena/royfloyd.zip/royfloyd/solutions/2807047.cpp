#include <bits/stdc++.h>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n;
int a[105][105],dp[105][105];

int main()
{
    fin>>n;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            fin>>a[i][j];
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            dp[i][j]=1e9;
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            if(a[i][j]==0 && i!=j)
                dp[i][j]=1e9;
            else
                dp[i][j]=a[i][j];
        }
    }
    for(int k=1; k<=n; k++)
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++)
                dp[i][j]=min(dp[i][j],dp[i][k]+dp[k][j]);
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=n; j++)
        {
            if(dp[i][j]==1e9)
                fout<<"0 ";
            else
            fout<<dp[i][j]<<" ";
        }
        fout<<"\n";
    }
    return 0;
}
