#include <iostream>
#include <vector>
#include <set>
#include <queue>
#include <algorithm>
#include <string>
#include <fstream>
#include <cctype>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <map>
#include <bitset>
#include <stack>
/*  //c++11
#include <unordered_map>
#include <unordered_set>
#include <tuple>
*/

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int a[101][101];
int d[101][101];

int main()
{
    //freopen("1.in","r",stdin);
    //freopen("1.out","w",stdout);
    int n;
    fin>>n;
    memset(d, 1<<30, sizeof(d));
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
        {
            fin>>a[i][j];
            d[i][j] = a[i][j];
        }
    for(int k = 1; k <= n; k++)
        for(int i = 1; i <= n; i++)
            for(int j = 1; j <= n; j++)
                if(a[i][k] && a[k][j])
                    d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
            fout<<d[i][j]<<' ';
        fout<<'\n';
    }
    return  0;

}


//FILE!!!
