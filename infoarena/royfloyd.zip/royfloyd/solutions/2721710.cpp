#include <bits/stdc++.h>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

long long n,i,j,k,a[110][110],d[2][110][110];

int main()
{

    /// d[k][i][j] = distanta minima de la i la j, stiind ca am trecut doar prin nodurile intermediare 1,2,3,...,n


    f>>n;
    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    {
        f>>a[i][j];
        if(a[i][j]==0)d[0][i][j]=INT_MAX/2;
        else d[0][i][j]=a[i][j];
    }

    for(k=1;k<=n;k++)
    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    {
        d[k%2][i][j]=min(d[(k+1)%2][i][j],d[(k+1)%2][i][k]+d[(k+1)%2][k][j]);
    }

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
            if(i==j || d[n%2][i][j]>=INT_MAX/2)g<<0<<" ";
            else g<<d[n%2][i][j]<<" ";
        g<<'\n';
    }
    return 0;
}
