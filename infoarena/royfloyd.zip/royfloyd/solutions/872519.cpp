#include <iostream>
#include<fstream>
using namespace std;
int a[1111][1111],n,i,j,k;
void rf()
{
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if(a[i][k]&&a[k][j]&&i!=j&&a[i][j]>a[i][k]+a[k][j])
                a[i][j]=a[i][k]+a[k][j];
}
int main()
{

    ifstream f("royfloyd.in");
    ofstream g("royfloyd.out");
    f>>n;
    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    f>>a[i][j];
    rf();
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        g<<a[i][j]<<" ";
        g<<endl;
    }
    return 0;
}
