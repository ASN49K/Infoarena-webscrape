#include<fstream>
#include<algorithm>
#define MAX 1005
using namespace std;
ifstream cin("royfloyd.in");
ofstream cout("royfloyd.out");

int n;
int a[105][105];

int main() {

    cin>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++){

            cin>>a[i][j];
            if(a[i][j]==0 && i!=j) a[i][j]=MAX;

        }


    int perm[n+1];
    for(int i=1;i<=n;i++)
        perm[i]=i;

    random_shuffle(perm+1,perm+n+1);

    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                if(a[i][perm[k]]+a[perm[k]][j]<a[i][j])
                    a[i][j]=a[i][perm[k]]+a[perm[k]][j];

    for(int i=1;i<=n;i++,cout<<'\n')
        for(int j=1;j<=n;j++,cout<<' ')
            cout<<a[i][j];

}

