#include <fstream>
using namespace std;

ifstream fin ("royfloyd.in");
ofstream fout("royfloyd.out");

int n,i,j,a[105][105];

void chestie(){
    for (int x=1;x<=n;x++)
        for (int i=1;i<=n;i++)
            for (int j=1;j<=n;j++){
                if (i==x || j==x)
                    continue;
                a[i][j]=min(a[i][j],a[i][x]+a[x][j]);
            }
}

int main(){
    fin>>n;
    for (i=1;i<=n;i++)
        for (j=1;j<=n;j++){
            fin>>a[i][j];
            if (a[i][j]==0 && i!=j)
                a[i][j]=(1<<28);
        }
    chestie();
    for (i=1;i<=n;i++){
        for (j=1;j<=n;j++)
            fout<<a[i][j]<<" ";
        fout<<'\n';
    }
    fin.close();
    fout.close();
    return 0;
}
