#include <fstream>
#include <climits>
#define nmax 105
using namespace std;
int a[nmax][nmax];
int main()
{
    ifstream fin("royfloyd.in");
    ofstream fout("royfloyd.out");
    int n,i,j,k;
    fin>>n;
    for (i=1;i<=n;i++)
        for (j=1;j<=n;j++)
        {
            fin>>a[i][j];
            if (i!=j && a[i][j]==0)
            {
                a[i][j]=INT_MAX;
            }
        }
    for (k=1;k<=n;k++)
        for (i=1;i<=n;i++)
            for (j=1;j<=n;j++)
            if (a[i][j]>a[i][k]+a[k][j]  && i!=j && a[i][k] && a[k][j])
            {
                a[i][j]=a[i][k]+a[k][j];
                //t[i][j]=k;
            }
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=n;j++)
        {
            if (a[i][j]==INT_MAX)
                a[i][j]=0;
            fout<<a[i][j]<<' ';
        }
        fout<<'\n';
    }
    fin.close();
    fout.close();
    return 0;
}
