#include <stdio.h>
int n,a[101][101];

void rf(){
 int k,i,j;

 for (k=1;k<=n;k++){
  for(i=1;i<=n;i++){
   if(k!=i){
    for(j=1;j<=n;j++){
     if((j!=k)&&(a[i][j]>a[i][k]+a[k][j])&&(a[i][k]!=0)&&(a[k][j]!=0)){

      a[i][j]=a[i][k]+a[k][j];
     }
    }

   }
  }
 }

}

int main(){
freopen("royfloyd.in","r",stdin);
freopen("royfloyd.out","w",stdout);
int i,j;
scanf("%d",&n);

for(i=1;i<=n;i++){
 for(j=1;j<=n;j++){
  scanf("%d",&a[i][j]);
 }

}

rf();

//kiir

for(i=1;i<=n;i++){
for(j=1;j<n;j++){
 printf("%d ",a[i][j]);

}
printf("%d\n",a[i][j]);
}

 return 0;
}