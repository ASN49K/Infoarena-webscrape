#include <bits/stdc++.h>

using namespace std;


ifstream fin("royfloyd.in");ofstream fout("royfloyd.out");
int n;
const int NMAX=107;
int a[NMAX][NMAX];

int main()
{
    fin >> n ;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            fin >> a[i][j];

    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                if( i!=j and a[i][k] and a[k][j] )
                    if( !a[i][j] or a[i][j]> a[i][k]+a[k][j] )
                        a[i][j]=a[i][k]+a[k][j];
    for(int i=1;i<=n;i++,fout <<"\n")
        for(int j=1;j<=n;j++)
            fout << a[i][j] << " ";
    return 0;
}
