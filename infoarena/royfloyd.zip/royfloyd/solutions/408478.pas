{DINH QUANG DAT TIN 07-10}
{ROYFLOYD}
CONST
 TFI='royfloyd.in';
 TFO='royfloyd.out';
 MAX=101;
TYPE
 arr1int=array[0..MAX] of longint;
VAR
 fi,fo:text;
 n:longint;
 c:array[0..MAX] of arr1int;

PROCEDURE       input;
var
 i,j:longint;
begin
 assign(fi,tfi);reset(fi);
  read(fi,n);
  for i:= 1 to n do
   for j:= 1 to n do read(fi,c[i][j]);
 close(fi);
end;

PROCEDURE       init;
begin
end;

PROCEDURE       process;
var
 u,v,k:longint;
begin
 for k:= 1 to n do
  for u:= 1 to n do
   for v:= 1 to n do
    if (c[u][v]>c[u][k]+c[k][v]) and (u<>v) and (v<>k) and (k<>u) then c[u][v]:=c[u][k]+c[k][v];
end;

PROCEDURE       output;
var
 i,j:longint;
begin
 assign(fo,tfo);rewrite(fo);
  for i:= 1 to n do
   begin
    for j:= 1 to n do write(fo,c[i][j],' ');
    writeln(fo);
   end;
 close(fo);
end;

BEGIN
 input;
 init;
 process;
 output;
END.