#include <stdio.h>

FILE *f, *g;
int n, d[100+10][100+10];

void ReadInputData () {
    fscanf(f, "%d", &n);
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            fscanf(f, "%d", &d[i][j]);
}
void RoyFloyd () {
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
            if (d[i][j] && i != j)
                for (int k = 1; k <= n; k++)
                    if (i != k && j != k && d[i][j] > d[i][k] + d[k][j])
                        d[i][j] = d[i][k] + d[k][j];
}
void WriteOutputData () {
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++)
            fprintf(g, "%d ", d[i][j]);
        fprintf(g, "\n");
    }
}
int main() {
    f = fopen("royfloyd.in", "r");
    g = fopen("royfloyd.out", "w");

    ReadInputData();
    RoyFloyd();
    WriteOutputData();

    fclose(f);
    fclose(g);

    return 0;
}
