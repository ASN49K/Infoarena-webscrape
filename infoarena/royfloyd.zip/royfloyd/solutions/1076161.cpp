#include<fstream>
#define maxn 105
using namespace std;
ifstream fi("royfloyd.in");
ofstream fo("royfloyd.out");

int a[maxn][maxn];
int k,i,j,n;

int main(){
    fi>>n;
    
    for(i=1;i<=n;i++)
      for(j=1;j<=n;j++) fi>>a[i][j];
    
    for(k=1;k<=n;k++)
     for(i=1;i<=n;i++)
      for(j=1;j<=n;j++)
       if(i!=j && a[i][k] && a[k][j] && (a[i][j]==0 || a[i][j]>a[i][k]+a[k][j]))
       a[i][j]=a[i][k]+a[k][j];
    
    for(i=1;i<=n;i++)
    {
     for(j=1;j<=n;j++) fo<<a[i][j]<<" ";
     fo<<"\n";
    }
    
    fi.close();
    fo.close();
    return 0;
}
