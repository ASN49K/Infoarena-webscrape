#include<iostream>
#include<fstream>
using namespace std;
#define MAX_N 100
int N, a[MAX_N][MAX_N];
void read(){
	ifstream f("royfloyd.in");
	f >> N;
	for(int i=1; i<=N; i++){
		for(int j=1; j<=N; j++){
			f >> a[i][j];
		}
	}
	
}


void solve(){
	
	for(int k=1; k<=N; k++){
		for(int i=1; i<=N; i++){
			for(int j=1; j<=N; j++){
				if(i!=j){
					if(a[i][k] != 0 && a[k][j]!=0)
						if(a[i][j] > a[i][k] + a[k][j])
							a[i][j] = a[i][k]+ a[k][j];
				}else a[i][j] = 0;
					
			}
		}
	
	}

}

void write(){
	ofstream g("royfloyd.out");
	for(int i=1; i<=N; i++){
		for(int j=1; j<=N; j++){
				g << a[i][j] << " ";
			
		}
		g << endl;
	
	}

}

int main(){
	read();
	solve();
	write();

return 0;
}
