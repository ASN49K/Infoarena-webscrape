#include <iostream>
#include <fstream>
#define dMAX 100
#define INF 999999

using namespace std;

int n;
int graf[dMAX + 2][dMAX + 2];

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

void Roy_Floyd() {
    int i, j, k;
    for (k = 1; k <= n; k++) {
        for (i = 1; i <= n; i++) {
            for (j = 1; j <= n; j++) {
                graf[i][j] = min(graf[i][j], graf[i][k] + graf[k][j]);
            }
        }
    }
}

int main()
{
    int i, j;
    fin >> n;
    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++) {
            fin >> graf[i][j];
            if (!graf[i][j]) graf[i][j] = INF;
        }
    }

    Roy_Floyd();

    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++) {
            if (graf[i][j] == INF || i == j) fout << "0 ";
            fout << graf[i][j] << ' ';
        }
        fout << '\n';
    }

    return 0;
}
