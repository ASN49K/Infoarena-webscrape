#include <fstream>
#include <vector>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

const int INF = 1e9;
vector <vector <int>> mat;

int main ()
{
    int n, i, j, k;
    f >> n;
    mat.assign (n + 1, vector <int> (n + 1));
    for (i = 1; i <= n; i += 1)
    {
        for (j = 1; j <= n; j += 1)
        {
            f >> mat[i][j];
            if (!mat[i][j])
                mat[i][j] = INF;
        }
    }
    for (k = 1; k <= n; k += 1)
    {
        for (i = 1; i <= n; i += 1)
        {
            for (j = 1; j <= n; j += 1)
            {
                if (mat[i][j] > mat[i][k] + mat[k][j])
                    mat[i][j] = mat[i][k] + mat[k][j];
            }
        }
    }
    for (i = 1; i <= n; i += 1)
    {
        for (j = 1; j <= n; j += 1)
        {
            if (i != j)
                g << mat[i][j];
            else
                g << 0;
            g << ' ';
        }
        g << '\n';
    }
    return 0;
}
