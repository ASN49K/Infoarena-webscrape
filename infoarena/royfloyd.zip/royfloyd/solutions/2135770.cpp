#include <bits/stdc++.h>

using namespace std;

int n, v[105][105];

int main()
{
    ifstream fin ("royfloyd.in");
    ofstream fout ("royfloyd.out");
    fin >> n;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j)
            fin >> v[i][j];
    for (int k = 1; k <= n; ++k)
        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= n; ++j)
                if(v[i][k] != 0 && v[k][j] != 0 && i != j && (v[i][j] > v[i][k]+v[k][j] || v[i][j] == 0))
                    v[i][j] = v[i][k]+v[k][j];
    for (int i = 1; i <= n; ++i){
        for (int j = 1; j <= n; ++j)
            fout << v[i][j] << " ";
        fout << "\n";
    }
    return 0;
}
