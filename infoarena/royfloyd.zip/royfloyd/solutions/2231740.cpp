#include <stdio.h>

int main()
{
    int n, graf[100][100], dis[100][100], i, j, k;
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);

    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            scanf("%d", &graf[i][j]);
            dis[i][j] = graf[i][j];
        }
    }

    for (k = 0; k < n; k++)
        for (i = 0; i < n; i++)
            for (j = 0; j < n; j++)
                if (dis[i][j] > dis[i][k] + dis[k][j])
                    dis[i][j] = dis[i][k] + dis[k][j];

    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++)
            printf("%d ", dis[i][j]);
        printf("\n");
    }

    return 0;
}