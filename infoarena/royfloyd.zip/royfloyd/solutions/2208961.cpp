#include <iostream>
#include <fstream>

using namespace std;
ifstream f ("royfloyd.in");
ofstream g ("royfloyd.out");
int n, a[105][105];
void royfloyd()
{
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            for(int k=1; k<=n; k++)
            if(a[i][k] && a[k][j] && a[i][j]>a[i][k]+a[k][j])
                a[i][j]=a[i][k]+a[k][j];
}

int main()
{
    f>>n;
    for(int i=1; i<=n; i++)
        for (int j=1; j<=n; j++)
        f>>a[i][j];
    royfloyd();
    for(int i=1; i<=n; i++)
       {
        for (int j=1; j<=n; j++)
            g<<a[i][j]<<" ";
            g<<"\n";
       }
    return 0;
}
