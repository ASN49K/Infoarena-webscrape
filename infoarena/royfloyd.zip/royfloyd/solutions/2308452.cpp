#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

#define NMax 110
#define inf (1 << 20) - 1

int n;
int a[NMax][NMax];

void init();
void rezolvare();
void afisare();

int main(){
	init();
	rezolvare();
	afisare();
}

void init(){
	int i, j;
	fin >> n;
	for(i = 1; i <= n; i++)
		for(j = 1; j <= n; j++){
			fin >> a[i][j];
			if(a[i][j] == 0) a[i][j] = inf;
		}
}

void rezolvare(){
	int i, j, k;
	for(k = 1; k <= n; k++)
		for(i = 1; i <= n; i++)
			for(j = 1; j <= n; j++)
				if(a[i][k] + a[k][j] < a[i][j]) a[i][j] = a[i][k] + a[k][j];
}

void afisare(){
	int i, j;
	for(i = 1; i <= n; i++){
		for(j = 1; j <= n; j++){
			if(a[i][j] >= inf or i == j) fout << 0 << ' ';
			else fout << a[i][j] << ' ';
		}
		fout << '\n';
	}
}





















