#include <stdio.h>

using namespace std;
FILE *f,*g;
int a[120][120];
void Afisare(int n)
{
    int i,j;
    for(i=1;i<=n;i++,fprintf(g,"\n"))
        for(j=1;j<=n;j++)
            fprintf(g,"%d ",a[i][j]);
}
int main()
{
    f=fopen("royfloyd.in","r");
    g=fopen("royfloyd.out","w");
    int n,i,j,k;
    fscanf(f,"%d",&n);
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            fscanf(f,"%d ",&a[i][j]);
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
              if(a[i][k]&&a[k][j]&&i!=j)
                if(a[i][j]>a[i][k]+a[k][j])
                    a[i][j]=a[i][k]+a[k][j];
    Afisare(n);
    return 0;
}
