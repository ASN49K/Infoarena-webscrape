#include <cstdio>
using namespace std;
int n;
int x[101][101];
void royfl()
{
    for(int k=1;k<=n;++k)
        for(int i=1;i<=n;++i)
            for(int j=1;j<=n;++j)
                if(i!=j&&i!=k&&j!=k&&(x[i][j]==0||x[i][j]>x[i][k]+x[k][j]))
                    x[i][j]=x[i][k]+x[k][j];
}
void citire()
{
    freopen("royfloyd.in","r",stdin);
    scanf("%d",&n);
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
            scanf("%d",&x[i][j]);
}
void afis()
{
    freopen("royfloyd.out","w",stdout);
    for(int i=1;i<=n;++i){
        for(int j=1;j<=n;++j)
            printf("%d ",x[i][j]);
        printf("\n");}
}
int main()
{
    citire();
    royfl();
    afis();
    return 0;
}
