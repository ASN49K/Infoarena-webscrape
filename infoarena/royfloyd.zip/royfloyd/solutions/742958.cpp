#include <cstdio>

int a[200][200];

int main()
{
	freopen("fis.in","r",stdin);

	int n;
	scanf("%d",&n);
	for (int i=1 ; i<=n ; i++)
		for (int j=1; j<=n; j++)
			scanf("%d",&a[i][j]);

	for (int k=1 ; k<=n ; k++)
		for (int i=1 ; i<=n ; i++)
			for (int j=1 ; j<=n ; j++)
				if(a[i][k]+a[k][j]<a[i][j])
					a[i][j]=a[i][k]+a[k][j];

	for (int i=1 ; i<=n ; i++)
	{
		for (int j=1 ; j<=n ; j++)
			printf("%d ",a[i][j]);

		printf("\n");
	}		
}
