#include <fstream>
#include <vector>
using namespace std;
ifstream cin("royfloyd.in");
ofstream cout("royfloyd.out");
int i, j, n, m, x, y, k;
int a[102][102];
int main() {
    cin>>n;
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++){
            cin>>a[i][j];
            if(a[i][j]==0 && i!=j)
                a[i][j]=1005;
        }
    }
    for(k=1;k<=n;k++){
        for(i=1;i<=n;i++){
            for(j=1;j<=n;j++){
                if(a[i][j]>a[i][k]+a[k][j]){
                    a[i][j]=a[i][k]+a[k][j];
                }
            }
        }
    }
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++)
            cout<<a[i][j]<<" ";
        cout<<"\n";
    }



}
