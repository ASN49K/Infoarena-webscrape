#include <bits/stdc++.h>

using namespace std;

ifstream fin ("royfloyd.in");
ofstream fout ("royfloyd.out");

long long n, mat[141][141], rf[141][141];

void read()
{
    fin >> n;
    for (int i=0;i<n;++i)
        for (int j=0;j<n;++j)
            rf[i][j]=100041;
    for (int i=0;i<n;++i)
        for (int j=0;j<n;++j)
        fin >> mat[i][j];
    for (int i=0;i<n;++i)
        rf[i][i]=0;
    for (int i=0;i<n;++i)
        for (int j=0;j<n;++j){
            if (i!=j&&mat[i][j])
            rf[i][j]=mat[i][j];
        }

}

void royf()
{
    for (int k=0;k<n;++k)
    {
        for (int i=0;i<n;++i)
        {
            for (int j=0;j<n;++j)
            {
                rf[i][j]=min(rf[i][k]+rf[k][j],rf[i][j]);
            }
        }
    }
}

int main()
{
    read();
    royf();
    for (int i=0;i<n;++i)
    {
        for (int j=0;j<n;++j){
            if (rf[i][j]>=100041||i==j)
                fout << 0 << " ";
            else
                fout << rf[i][j] << " ";
        }
        fout << "\n";
    }
    return 0;
}
