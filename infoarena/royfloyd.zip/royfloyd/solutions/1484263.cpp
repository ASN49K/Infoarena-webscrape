#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include <algorithm>
#include <vector>
#include <queue>
#include <deque>

#define INF ( 1 << 30 )
#define mod 666013

using namespace std;

int n, i, j, k;
int a[105][105];

int main()
{
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);

    scanf("%d", &n);

    for(i = 1; i <= n; i++)
        for(j = 1; j <= n; j++)
        {
            scanf("%d", &a[i][j]);

            if(i == 10)
            {
                i++;
                i--;
            }

            if(i != j && a[i][j] == 0)
                a[i][j] = INF;
        }

    for(k = 1; k <= n; k++)
        for(i = 1; i <= n; i++)
            if(i != k)
                for(j = 1; j <= n; j++)
                {
                    if(k != j && i != j && a[i][k] != INF && a[k][j] != INF && a[i][j] > a[i][k] + a[k][j])
                            a[i][j] = a[i][k] + a[k][j];
                }

    for(i = 1; i <= n; i++, printf("\n"))
        for(j = 1; j <= n; j++)
            printf("%d ", a[i][j]);

    return 0;
}
