#include <cstdio>

const int N_MAX = 100;

int n;
int a[2][N_MAX][N_MAX];

inline int min ( int a, int b ) { return a < b ? a : b; }

int main() {
	freopen("royfloyd.in","rt",stdin);
	freopen("royfloyd.out","wt",stdout);
	scanf("%d",&n);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= n; ++j)
			scanf("%d",&a[0][i][j]);

	for (int k = 1; k <= n; ++k)
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= n; ++j)
				a[k&1][i][j] = min(a[!(k&1)][i][j], a[!(k&1)][i][k] + a[!(k&1)][k][j]);

	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= n; ++j)
			printf("%d ",a[n&1][i][j]);
		printf("\n");
	}
	return 0;
}
