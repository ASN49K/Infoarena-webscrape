#include<bits/stdc++.h>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

vector<vector<int>> matrix;

int main(){
    int n,i,j,k,a;
    f>>n;
    vector<int> aux;

    for(i=0;i<n;++i){
        for(j=0;j<n;++j){
            f>>a;
            aux.push_back(a);
        }
        matrix.push_back(aux);
        aux.clear();

    }

    for(i=0;i<n;++i)
        for(j=0;j<n;++j){
            if(matrix[i][j]==0 && i!=j)
                matrix[i][j]=2000;
        }
    for(k=0;k<n;++k){
        for(i=0;i<n;++i){
            for(j=0;j<n;++j){
                if(matrix[i][j]>matrix[i][k]+matrix[k][j]){
                    matrix[i][j]=matrix[i][k]+matrix[k][j];
                }
            }
        }
    }
    for(i=0;i<n;++i){
        for(j=0;j<n;++j){
            g<<matrix[i][j]<<' ';
        }
        g<<endl;
    }
    return 0;
}