#include <bits/stdc++.h>
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int main()
{
  int n;
  fin >> n;

  vector<vector<int>> graph(n + 1, vector<int>(n + 1));

  for (int i = 1; i <= n; i++)
    for (int j = 1; j <= n; j++)
    {
      fin >> graph[i][j];
      if (graph[i][j] == 0 && i != j)
        graph[i][j] = INT_MAX;
    }

  for (int k = 1; k <= n; k++)
    for (int i = 1; i <= n; i++)
      for (int j = 1; j <= n; j++)
        graph[i][j] = min(graph[i][j], graph[i][k] + graph[k][j]);

  for (int i = 1; i <= n; i++)
  {
    for (int j = 1; j <= n; j++)
    {
      if (graph[i][j] == INT_MAX)
        graph[i][j] = 0;
      fout << graph[i][j] << " ";
    }
    fout << "\n";
  }

  return 0;
}