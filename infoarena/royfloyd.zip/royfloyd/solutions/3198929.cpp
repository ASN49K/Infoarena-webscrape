#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using std::cin, std::cout, std::vector, std::sort, std::ifstream, std::ofstream;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

const int NMAX = 101;

int m[NMAX][NMAX];
int n;

int main() {
    fin >> n;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            fin >> m[i][j];
        }
    }
    for (int k = 1; k <= n; k++) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                int drumNou = m[i][k] + m[k][j];
                if (drumNou < m[i][j]) {
                    m[i][j] = drumNou;
                }
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            fout << m[i][j] << " ";
        }
        fout << "\n";
    }
}