#include <iostream>
#include <fstream>
using namespace std;
int n,d,a[105][105];
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

void Citire(){
    f>>n;
    for (int i=1;i<=n;i++){
        for (int  j=1;j<=n;j++){
            f>>a[i][j];
        }

    }
}

void Roy_floyd(){
    int i,j,k;
    for (k = 1; k <= n; k++){
        for (i = 1; i <= n; i++){
            for (j = 1; j <= n; j++){
                if (a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j) a[i][j] = a[i][k] + a[k][j];
            }
        }
    }
}

void Afisare(){
    for (int i=1;i<=n;i++){
        for (int j=1;j<=n;j++) g<<a[i][j]<<"\n";
    }
}

int main(){
    Citire();
    Roy_floyd();
    Afisare();
return 0;
}
