#include <iostream>
#include <fstream>

using namespace std;
int n, A[101][101];
const int inf = 9999999;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
void citire()
{
	f >> n;
	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= n; j++)
		{
			f >> A[i][j];
			if(A[i][j] == inf)
				A[i][j] = 0;
		}
	}
}
void rf()
{
	int cost;
	for(int k = 1; k <= n; k++)
	{
		for(int i = 1; i <= n; i++)
		{
			for(int j = 1; j <= n; j++)
			{
				cost = A[i][k] + A[k][j];
				if(A[i][j] > cost)
					A[i][j] = cost;
			}
		}
	}
}
void afis()
{
	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= n; j++)
		{
			if(A[i][j] != inf)
				g << A[i][j] << ' ';
			else
				g << "0 ";
		}
		g << '\n';
	}
}
int main()
{
	citire();
	rf();
	afis();
	return 0;
}
