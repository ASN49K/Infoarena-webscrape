#include <fstream>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");


int  n, m, k, N, maxx;
int a[105][105];


int main()
{
    f >> n;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++) {
            f >> a[i][j];
            if (i != j && a[i][j] == 0) a[i][j] = 200;
        }

    for (int k = 1; k <= n; k++)
    {
        for (int i = 1; i <= n; i++)
            for (int j = 1; j <= n; j++)
                    a[i][j] = min(a[i][j], a[i][k] + a[k][j]);
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++)
            g << (a[i][j] != 200) * a[i][j] << ' ';
        g << '\n';
    }
    return 0;
}
