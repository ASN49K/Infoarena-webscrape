#include <fstream>
#define mx 105
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n,a[mx][mx];

void RF()
{
    for(int k=1;k<=n;++k)
        for(int i=1;i<=n;++i)
            for(int j=1;j<=n;++j)
                if (a[i][k]&&a[k][j]&&((a[i][k]+a[k][j]<a[i][j])||(!a[i][j]))&&(i!=j)) a[i][j]=a[i][k]+a[k][j];
}



int main()
{
    f>>n;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
            f>>a[i][j];
    RF();

    for(int i=1;i<=n;++i)
    {
        for(int j=1;j<=n;++j)
            g<<a[i][j]<<' ';
        g<<'\n';
    }

    f .close();
    g.close();
    return 0;
}
