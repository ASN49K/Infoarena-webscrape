#include<stdio.h>
int A[102][102],i,j,k,N;
int main()
{
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	scanf("%d",&N);
	for(i=1;i<=N;++i)
		for(j=1;j<=N;++j)
			scanf("%d",&A[i][j]);
	for(k=1;k<=N;++k)
		for(i=1;i<=N;++i)
			for(j=1;j<=N;++j)
				if ((i!=j)&&( A[i][k]+A[k][j] < A[i][j] || !A[i][j]==0)&&A[i][k]!=0 && A[k][j]!=0 )
					A[i][j] = A[i][k] + A[k][j] ;
	for(i=1;i<=N;++i)
	{	for(j=1;j<=N;++j)
			printf("%d ",A[i][j]);
		printf("\n");
	}
	return 0;
}
