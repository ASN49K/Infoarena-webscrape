#include<stdio.h>
int main () {
	int N;
	int C[101][101];
	int k,i,j;
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	scanf("%d",&N);
	for(i=1;i<=N;i++)
		for(j=1;j<=N;j++)
			scanf("%d",&C[i][j]);
	for(k=1;k<=N;k++)
		for(i=1;i<=N;i++)
			for(j=1;j<=N;j++)
					if(C[i][k] && C[k][j])
						if (C[i][j]>C[i][k]+C[k][j] && i!=j)
							C[i][j]=C[i][k]+C[k][j];

	for(i=1;i<=N;i++) {
		for(j=1;j<=N;j++)
			printf("%d ",C[i][j]);
			printf("\n");
	}
	fclose(stdin);
	fclose(stdout);
return 0;
}
