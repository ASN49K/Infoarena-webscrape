#include <bits/stdc++.h>

using namespace std;

ifstream fin("royfloyd.in") ;
ofstream fout("royfloyd.out") ;

int main()
{
    int n , i , j , k ;
    int sol[101][101] ;
    fin >> n ;
    for ( i = 1 ; i <= n ; i++ )
        for ( j = 1 ; j <= n ; j++ )
            fin >> sol[i][j] ;
    for ( i = 1 ; i <= n ; i++ )
    {
        for ( j = 1 ; j <= n ; j++ )
        {
            for ( k = 1 ; k <= n ; k++ )
            {
                if ( j != k && sol[i][k] != 0 && sol[j][i] != 0 && (sol[j][k] == 0||sol[j][k]>sol[j][i]+sol[i][k]) )
                    sol[j][k] = sol[j][i]+sol[i][k] ;
            }
        }
    }
    for ( i = 1 ; i <= n ; i++ )
    {
        for ( j = 1 ; j <= n ; j++ )
            fout << sol[i][j] << " " ;
        fout << '\n' ;
    }
}
