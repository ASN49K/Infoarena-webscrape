//
//  main.cpp
//  RoyFloyd
//
//  Created by Alex Petrache on 29/10/14.
//  Copyright (c) 2014 Alex Petrache. All rights reserved.
//

#include <iostream>
#include <fstream>
using namespace std;
int main(int argc, const char * argv[])
{
    int n,i,j,k,a[101][101],min[101][101];
    ifstream f("royfloyd.in");
    ofstream g("royfloyd.out");
    //ifstream f("/Users/alexpetrache/Documents/Programare/Xcode/Arhiva Educationala/RoyFloyd/RoyFloyd/royfloid.in");
    //ofstream g("/Users/alexpetrache/Documents/Programare/Xcode/Arhiva Educationala/RoyFloyd/RoyFloyd/royfloid.out");
    f>>n;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++){
            f>>a[i][j];
            min[i][j]=a[i][j];
        }
    
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if(min[i][j]>min[i][k]+min[k][j])
                    min[i][j]=min[i][k]+min[k][j];

    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++)
            g<<min[i][j]<<" ";
        g<<'\n';
    }
    return 0;
}

