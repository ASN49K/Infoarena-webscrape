import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Main {

     public static short[][] readInput()  {
        try {
            File rfin = new File("royfloyd.in");
            Scanner sc = new Scanner(rfin);
            byte vertexCount = sc.nextByte();
            short[][] matrix = new short[vertexCount][vertexCount];
            for (byte i = 0; i < vertexCount; i++) {
                for (byte j = 0; j < vertexCount; j++) {
                    matrix[i][j] = sc.nextShort();
                }
            }
            sc.close();
            return matrix;
        } catch (FileNotFoundException ex) {
            System.out.println("read ex " + ex.getLocalizedMessage());
        }
        return null;
    }

    public static void writeOutput(short[][] matrix) throws FileNotFoundException {
        PrintWriter pr = new PrintWriter("royfloyd.out");
        for (byte i = 0; i < (byte) matrix[0].length; i++) {
            for (byte j = 0; j < (byte) matrix[0].length; j++) {
                pr.write(matrix[i][j] + " ");
            }
            pr.println();
        }
        pr.close();
    }

    public static void main(String[] args) throws IOException {
        short[][] dist = readInput();
        for (byte k = 0; k < (byte) dist[0].length; k++) {
            for (byte i = 0; i < (byte) dist[0].length; i++) {
                for (byte j = 0; j < (byte) dist[0].length; j++) {
                    if (i != j && dist[i][k] != 0 && dist[k][j] != 0 &&  (dist[i][j] > dist[i][k] + dist[k][j] || dist[i][j] == 0 ) ) {
                        dist[i][j] =  (short) (dist[i][k] + dist[k][j]);
                    }
                }
            }
        }
        writeOutput(dist);

    }

}
