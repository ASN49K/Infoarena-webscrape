#include <bits/stdc++.h>
#define Nmax 101
#define inf INT_MAX
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n,a[Nmax][Nmax];
int main()
{f>>n;
int i,j,k;
for(i=1;i<=n;i++)
  for(j=1;j<=n;j++)
  f>>a[i][j];
for(k=1;k<=n;k++)
  for(i=1;i<=n;i++)
   for(j=1;j<=n;j++)
    a[i][j]=min(a[i][k]+a[k][j],a[i][j]);
for(i=1;i<=n;i++)
 {for(j=1;j<=n;j++)
  g<<a[i][j]<<' ';
 g<<'\n';
 }
    return 0;
}
