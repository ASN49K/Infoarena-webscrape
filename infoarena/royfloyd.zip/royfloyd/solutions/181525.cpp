#include<stdio.h>

#define in "royfloyd.in"
#define out "royfloyd.out"

const float inf=1.e20;

int n,i,j,k,x;
float a[101][101];

int main()
{
	freopen(in,"r",stdin);
	freopen(out,"w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			if(i!=j)
				a[i][j]=inf;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
		{
			scanf("%d",&x);
			if(x!=0)
				a[i][j]=x;
		}
	for(k=1;k<=n;k++)
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				if(a[i][j]>a[i][k]+a[k][j])
					a[i][j]=a[i][k]+a[k][j];
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=n;j++)
			printf("%.f ",a[i][j]);
		printf("\n");
	}
	return 0;
}