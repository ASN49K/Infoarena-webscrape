//
//  main.cpp
//  royfloyd
//
//  Created by Hai Tran Bach on 10/9/14.
//  Copyright (c) 2014 Hai Tran Bach. All rights reserved.
//

#include <iostream>
#include <fstream>

using namespace std;

#define MAX 100

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int v[MAX+1][MAX+1];

int main() {
    
    int n;
    
    in >> n;
    
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            in >> v[i][j];
        }
    }
    
    for (int k = 1 ;k <= n; ++k) {
        for (int i = 1; i <= n; ++i) {
            for (int j = 1; j <= n; ++j) {
                if (v[i][j] > v[i][k] + v[k][j]
                    && v[k][j] && v[i][k]) {
                    v[i][j] = v[i][k] + v[k][j];
                }
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j) {
            out << v[i][j] << " ";
        }
        out << "\n";
    }
    
    return 0;
}
