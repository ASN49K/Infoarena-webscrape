#include <cstdio>

int a[101][101],n;

inline int min(int a, int b)
{
    if(a<b) return a;
    return b;
}

int main()
{
    int i, j,k;
    freopen("royfloyd.in","r",stdin);
    scanf("%d\n", &n);
    for(i=1;i<=n;++i)
	for(j=1;j<=n;++j)scanf("%d ",&a[i][j]);

    for(k=1;k<=n;++k)
	for(i=1;i<=n;++i)
	    for(j=1;j<=n;++j)
		a[i][j]=min(a[i][j], a[i][k]+a[k][j]);

    freopen("royfloyd.out","w",stdout);

    for(i=1;i<=n;++i)
    {
	for(j=1;j<=n;++j)printf("%d ",a[i][j]);
	printf("\n");
    }
    return 0;
}


