#include <algorithm>
#include <stack>
#include <queue>
#include <deque>
#include <vector>
#include <string>

using namespace std;

//#include <iostream>
#include <fstream>

//ifstream cin ("input.in");
//ofstream cout ("output.out");

ifstream cin ("royfloyd.in");
ofstream cout ("royfloyd.out");

static const int NMAX = 105;

int n;
int v[NMAX][NMAX];

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);

	cin>>n;
	for ( int i = 1; i <= n; ++i ) {
		for ( int j = 1; j <= n; ++j ) {
			cin>>v[i][j];
		}
	}

	for ( int k = 1; k <= n; ++k ) {
		for ( int i = 1; i <= n; ++i ) {
			for ( int j = 1; j <= n; ++j ) {
				if ( i == j || !v[i][k] || !v[k][j] ) continue;

				if ( v[i][k]+v[k][j] < v[i][j] ) {
					v[i][j] = v[i][k]+v[k][j];				}
			}
		}
	}

	for ( int i = 1; i <= n; ++i ) {
		for ( int j = 1; j <= n; ++j ) {
			cout<<v[i][j]<<" ";
		}
		cout<<'\n';
	}
}