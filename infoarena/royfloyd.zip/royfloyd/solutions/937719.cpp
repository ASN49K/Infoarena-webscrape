#include <fstream>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
#define LE 106
int i,j,t,a[LE][LE],n;
int main()
{
    f>>n;

    for(i=1; i<=n; ++i)
        for(j=1; j<=n; ++j)
            f>>a[i][j];


    for(i=1; i<=n; ++i)
        for(j=1; j<=n; ++j)
            for(t=1; t<=n; ++t)
                if ((a[j][t]>a[j][i]+a[i][t]||a[j][t]==0)&&a[j][i]&&a[i][t]&&j!=t)
                    a[j][t]=a[j][i]+a[i][t];

    for(i=1; i<=n; ++i)
    {
        for(j=1; j<=n; ++j)
            g<<a[i][j]<<" ";
        g<<'\n';
    }


    f.close();
    g.close();
    return 0;
}
