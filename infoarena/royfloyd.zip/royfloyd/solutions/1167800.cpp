#include<fstream>
using namespace std;
ifstream f("royfloyd.in",ios::in);
ofstream g("royfloyd.out",ios::out);
int main()
{
    int n,a[100][100],i,j,k;
    f>>n;
    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    f>>a[i][j];
    for(k=1;k<=n;k++)
    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    if(i!=k && j!=k && i!=j && (a[i][j]>a[i][k]+a[k][j] || a[i][j]==0) && a[i][k]!=0 && a[k][j]!=0)
    a[i][j]=a[i][k]+a[k][j];
    for(i=1;i<=n;i++)
    {
                     for(j=1;j<=n;j++)
                     g<<a[i][j]<<" ";
                     g<<endl;}
    return 0;}
