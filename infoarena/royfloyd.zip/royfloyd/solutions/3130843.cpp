#include <fstream>

using namespace std;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

const int N = 101;
const int INF = 100000;
int cost[N][N], n;

int main()
{
    in >> n;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            in >> cost[i][j];
            if (cost[i][j] == 0)
            {
                cost[i][j] = INF;
            }
        }
    }
    for (int k = 1; k <= n; k++)
    {
        for (int i = 1; i <= n; i++)
        {
            for (int j = 1; j <= n; j++)
            {
                if (cost[i][k] + cost[k][j] < cost[i][j] && cost[i][j] != INF)
                {
                    cost[i][j] = cost[i][k] + cost[k][j];
                }
            }
        }
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            if (cost[i][j] == INF)
            {
                out << "0 ";
            }
            else
            {
                out << cost[i][j] << " ";
            }
        }
        out << "\n";
    }
    return 0;
}
