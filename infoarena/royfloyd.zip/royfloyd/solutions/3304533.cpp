#include <bits/stdc++.h>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
const int inf=1e9;
int cost[109][109];
int main ()
{
    int n;
    f >> n;
    for (int i=1; i<=n; i++)
    {
        for (int j=1; j<=n; j++)
        {
            f >> cost[i][j];
            if (!cost[i][j]) cost[i][j]=inf;
        }
    }
    for (int k=1; k<=n; k++)
    {
        for (int i=1; i<=n; i++)
        {
            for (int j=1; j<=n; j++)
            {
                if (i!=j && cost[i][j]>cost[i][k]+cost[k][j]) cost[i][j]=cost[i][k]+cost[k][j];
            }
        }
    }
    for (int i=1; i<=n; i++)
    {
        for (int j=1; j<=n; j++)
        {
            if (cost[i][j]!=inf) g << cost[i][j] << ' ';
            else g << 0 << ' ';
        }
        g << '\n';
    }
}
