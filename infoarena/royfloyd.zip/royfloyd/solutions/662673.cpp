#include <fstream>
using namespace std;

const int MAXSIZE = 101;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int size;
int matrix[MAXSIZE][MAXSIZE];

int main()
{
	in >> size;

	for(int i=1;i<=size;i++)
		for(int k=1;k<=size;k++)
			in >> matrix[i][k];

	in.close();

	for(int k=1;k<=size;k++)
		for(int i=1;i<=size;i++)
			for(int j=1;j<=size;j++)
				if(matrix[i][k] && matrix[k][j] && matrix[i][j] > matrix[i][k] + matrix[k][j])
					matrix[i][j] = matrix[i][k] + matrix[k][j];

	for(int i=1;i<=size;i++)
	{
		for(int k=1;k<=size;k++)
			out << matrix[i][k] << " ";
		out << "\n";
	}

	out.close();

	return (0);
}
