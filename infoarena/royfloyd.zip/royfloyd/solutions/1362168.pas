program infoarena1;
var f,g:text;
    a:array of array of int64;
    n,i,j:longint;
procedure citire;
var i,j:longint;
begin
        for i:=1 to n do
                begin
                for j:=1 to n do
                        begin
                        read(f,a[i,j]);
                        if (i <> j) and (a[i,j] = 0) then
                                a[i,j]:=maxlongint;
                        end;
                end;
end;
procedure rf;
var i,j,k:longint;
begin
        for k:=1 to n do
                for i:=1 to n do
                        for j:=1 to n do
                                if a[i,j] > a[i,k]+a[k,j] then
                                        a[i,j]:=a[i,k]+a[k,j];

end;

begin
        assign(f,'royfloyd.in'); reset(f);
        assign(g,'royfloyd.out'); rewrite(g);
        readln(f,n);
        setlength(a,n+5,n+5);
        citire;
        rf();
        for i:=1 to n do
                begin
                for j:=1 to n do
                        write(g,a[i,j],' ');
                writeln(g);
                end;
        close(f); close(g);
end.