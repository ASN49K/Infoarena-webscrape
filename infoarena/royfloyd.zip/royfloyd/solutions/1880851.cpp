#include <bits/stdc++.h>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

#define NMAX 101

int d[NMAX][NMAX];

int main()  {
    int N;
    f >> N;
    for(int i = 1;i <= N;i++)
        for(int j = 1;j <= N;j++)  {
            f >> d[i][j];
            if(d[i][j] == 0) d[i][j] = INT_MAX / 2;
        }
    for(int k = 1;k <= N;k++)
        for(int i = 1;i <= N;i++)
            for(int j = 1;j <= N;j++)  /** KIJ */
                d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
    for(int i = 1;i <= N;i++)  {
        for(int j = 1;j <= N;j++)
            if(d[i][j] == INT_MAX)
                g << "0 ";
            else
                g << d[i][j] << " ";
        g << "\n";
    }
    f.close(), g.close();
    return 0;
}
