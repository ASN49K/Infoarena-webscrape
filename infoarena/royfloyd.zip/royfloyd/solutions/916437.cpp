#include<iostream>
#include<fstream>
using namespace std;
ifstream f;
ofstream g;
int n,m[101][101];

void citire()
{f.open("royfloyd.in"); 
  f>>n;
 for(int i=1;i<=n;i++)
	 for(int j=1;j<=n;j++)
		 f>>m[i][j];
f.close();
}
 void roy_floyd()
 {
	 for(int k=1;k<=n;k++)
		 for(int i=1;i<=n;i++)
			 for(int j=1;j<=n;j++)
				 if(m[i][j]>m[i][k]+m[k][j])
					 m[i][j]=m[i][k]+m[k][j];
 }
 void afisare()
 {g.open("royfloyd.out");
   for(int i=1;i<=n;i++)
   {
	   for(int j=1;j<=n;j++)
		   g<<m[i][j]<<" ";
	   g<<endl;
   }
  g.close(); 
 }
 int main()
 {citire();
 roy_floyd();
 afisare();
 return 0;
 }
 