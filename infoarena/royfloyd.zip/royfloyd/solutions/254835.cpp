#include <fstream>

#define min(a,b) ( ((a)>(b)) ? (b) : (a) )

using namespace std;

int main()
{
    ifstream f("royfloyd.in");
    ofstream f2("royfloyd.out");

    int n,g[101][101];

    f>>n;

    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            {
                int h;
                f>>h;
                g[i][j] = h ? h : 36535;

            }

    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++) if(j!=i)
                g[i][j] = min ( g[i][j], g[i][k] + g[k][j] );

    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            if(g[i][j]<36535) f2<<g[i][j];
            else f2<<"0";
            f2<<" ";
        }
        f2<<"\n";
    }

    f.close();
    f2.close();
    return 0;
}
