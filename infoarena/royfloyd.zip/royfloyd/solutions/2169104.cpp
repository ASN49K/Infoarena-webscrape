#include<cstdio>

using namespace std;

const int NMAX = 101;

int n;
int mat[NMAX][NMAX];

int mi(int a, int b)
{
    if(a < b)
    {
        return a;
    }
    return b;
}

int main()
{
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);

    scanf("%d", &n);

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            scanf("%d", &mat[i][j]);
        }
    }

    for(int k = 1; k <= n; k++)
    {
        for(int i = 1; i <= n; i++)
        {
            for(int j = 1; j <= n; j++)
            {
                if(i != j && mat[i][k] != 0 && mat[k][j] != 0)
                {
                    if(mat[i][j] == 0)
                    {
                        mat[i][j] = mat[i][k] + mat[k][j];
                    }
                    else
                    {
                        mat[i][j] = mi(mat[i][j], mat[i][k] + mat[k][j]);
                    }
                }
            }
        }
    }

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }
}
