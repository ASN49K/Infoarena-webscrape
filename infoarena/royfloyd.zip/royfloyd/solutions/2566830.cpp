#include <bits/stdc++.h>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int n,i,j,k,a[110][110],d[110][110];

int main()
{
    f>>n;
    for(i=1;i<=n;i++)
    for(j=1;j<=n;j++)
    {
        f>>a[i][j];
        d[i][j]=a[i][j];
    }

    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                d[i][j]=min(d[i][j],d[i][k]+d[k][j]);

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
            g<<d[i][j]<<" ";
        g<<'\n';
    }
    return 0;
}
