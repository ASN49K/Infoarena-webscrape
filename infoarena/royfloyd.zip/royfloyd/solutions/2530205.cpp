
#include <bits/stdc++.h>

using namespace std;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");
int n,a[110][110];
int main()
{
    in>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
        {
          in>>a[i][j];
          if(a[i][j]==0&&i!=j) a[i][j]=1e6;
        }
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
          for(int j=1;j<=n;j++)
            if(a[i][k]+a[k][j]<a[i][j]) a[i][j]=a[i][k]+a[k][j];
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            out<<a[i][j]<<" ";
        out<<'\n';
    }
    return 0;
}
