#include <fstream>

#define Ndim 101
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
int D[Ndim][Ndim];
int main()
{
    int i,j,k,n;
    fin>>n;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            fin>>D[i][j];
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if(i!=j && D[i][k]!=0 && D[k][j]!=0 && (D[i][j]>D[i][k]+D[k][j] || D[i][j]==0) )
                    D[i][j] = D[i][k]+D[k][j];
    for(i=1;i<=n;i++,fout<<'\n')
        for(j=1;j<=n;j++)
            fout<<D[i][j]<<' ';

    return 0;
}
