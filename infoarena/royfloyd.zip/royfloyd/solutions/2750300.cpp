#include <fstream>

using namespace std;

const int N = 101;
const int INF = 1e6;

int d[N][N];

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int main()
{
    int n;
    in >> n;
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            in >> d[i][j];
            if((i!=j) && (d[i][j] == 0))
            {
                d[i][j] = INF;
            }
        }
    }
    in.close();
    for(int k = 1 ; k <= n; k++)
    {
        for(int i = 1; i <= n; i++)
        {
            for(int j = 1; j <= n; j++)
            {
                if(d[i][k] + d[k][j] < d[i][j])
                {
                    d[i][j] = d[i][k] + d[k][j];
                }
            }
        }
    }
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            if(d[i][j] == INF)
            {
                d[i][j] = 0;
            }
            out << d[i][j] << " ";
        }
        out << "\n";
    }
    out.close();
    return 0;
}
