#include <fstream>
#include <climits>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n,c[1001][1001];
void royfloyd()
{
    int k,i,j;
    for(k=1; k<=n; k++)
        for(i=1; i<=n; i++)
            for(j=1; j<=n; j++)
            {
               if (c[i][k]+c[k][j]<c[i][j]&&i!=j)
                {
                    c[i][j]=c[i][k]+c[k][j];
                }
            }
}
int main()
{
    int i,j;
    f>>n;
    for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
        {
            f>>c[i][j];
             if(c[i][j]==0&&i!=j)c[i][j]=20000000;
        }
        royfloyd();
    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++)
        {
            if(c[i][j]==20000000)g<<0<<" ";
            else
                g<<c[i][j]<<" ";
        }


        g<<'\n';
    }
    return 0;
}
