#include <fstream>
using namespace std;

#define NMax 105

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int n;
int M[NMax][NMax];

int main()
{
    int i,j,k;

    f>>n;
    for(i=1;i<=n;++i) for(j=1;j<=n;++j) f>>M[i][j];

    for(k=1;k<=n;++k) for(i=1;i<=n;++i) for(j=1;j<=n;++j)
        if(i!=j && M[i][k] && M[k][i] && (M[i][k]+M[k][j]<M[i][j] || !M[i][j]))
            M[i][j]=M[i][k]+M[k][j];

    for(i=1;i<=n;++i) {for(j=1;j<=n;++j) g<<M[i][j]<<" "; g<<"\n";}

    f.close();
    g.close();
    return 0;
}
