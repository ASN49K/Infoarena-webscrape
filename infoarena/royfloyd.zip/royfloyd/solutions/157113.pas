program roy_f;
const inf=maxint div 2;
var f,g:text;
    a:array[1..100,1..100] of integer;
    n,m:integer;

procedure citire;
var i,j:integer;
begin
readln(f,n);
for i:=1 to n do
  for j:=1 to n do
    read(f,a[i,j]);
for i:=1 to n do
  for j:=1 to n do
    if (i<>j) and (a[i,j]=0) then a[i,j]:=inf;
end;

procedure roy;
var i,j,k:integer;
begin
for k:=1 to n do
  for i:=1 to n do
    for j:=1 to n do
      if a[i,j]>a[i,k]+a[k,j] then a[i,j]:=a[i,k]+a[k,j];
end;

procedure scriere;
var i,j:integer;
begin
for i:=1 to n do
  for j:=1 to n do
    if a[i,j]=inf then a[i,j]:=0;
for i:=1 to n do begin
  for j:=1 to n do write(g,a[i,j],' ');
  writeln(g);
  end;
end;

begin
assign(f,'royfloyd.in');
assign(g,'royfloyd.out');
reset(f);
rewrite(g);
citire;
roy;
scriere;
close(g);
end.