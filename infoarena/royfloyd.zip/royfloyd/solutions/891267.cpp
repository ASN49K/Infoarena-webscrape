#include <fstream>
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
#define NMAX 105
int v[NMAX][NMAX],d[NMAX][NMAX],n;
void read()
{
    fin>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            fin>>v[i][j];
}
void tipar(int matrix[NMAX][NMAX])
{
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            fout<<matrix[i][j]<<" ";
        fout<<"\n";
    }
}
int minim(int a,int b)
{
    if(a==0)
        return b;
    if(a<b)
        return a;
    return b;
}
void solve()
{
    int i,j,nod;
    for(nod=1;nod<=n;nod++)
    {
        for(i=1;i<=n;i++)
        {
            if(v[nod][i])
            for(j=1;j<=n;j++)
            {
                if(j==nod) continue;
                if(v[i][j])
                    v[nod][j] = minim ( v[nod][j] , v[nod][i] + v[i][j]);
            }
        }
    }
}
int main()
{
    read();
    solve();
    tipar(v);
}
