var f,g:text;
    n,i,j,k:integer;
    a:array[1..150,1..150] of integer;
begin
assign(f,'royfloyd.in');reset(f);
assign(g,'royfloyd.out');rewrite(g);
read(f,n);
for i:=1 to n do
    for j:=1 to n do
        read(f,a[i,j]);
for k:=1 to n do
    for i:=1 to n do
        for j:=1 to n do
            if a[i,k]+a[k,j]<a[i,j] then
                   a[i,j]:=a[i,k]+a[k,j];
for i:=1 to n do
begin
    for j:=1 to n do
        write(g,a[i,j],' ');
    writeln(g);
end;
close(g);
end.
