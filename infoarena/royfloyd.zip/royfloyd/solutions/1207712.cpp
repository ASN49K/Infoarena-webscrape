#include <iostream>
#include <fstream>
using namespace std;
ifstream ka("royfloyd.in");
ofstream ki("royfloyd.out");
const int N_MAX = 100;
int distante[N_MAX+2][N_MAX+2];
int n;

void floyd_warshall()
{
    for(int i = 0; i < n; i++)
        distante[i][i] = 0;
    for(int k = 0; k < n; k++)
        for(int i = 0; i < n; i++)
            for(int j = 0; j < n; j++)
                if(distante[i][k] + distante[k][j] < distante[i][j])
                    distante[i][j] = distante[i][k] + distante[k][j];
}

int main()
{
    ka >> n;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            distante[i][j] = 0x3fffffff;
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            ka >> distante[i][j];
    floyd_warshall();
    for(int i = 0; i < n; i++)
    {
        for(int j = 0; j < n; j++)
            if(distante[i][j] == 0x3fffffff)
                ki << 0 << " ";
            else
                ki << distante[i][j] << " ";
        ki << '\n';
    }
}
