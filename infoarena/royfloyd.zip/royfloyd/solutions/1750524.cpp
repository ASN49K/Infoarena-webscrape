#include <iostream>
using namespace std;
int a[100][100];

int main() {
	freopen("royfloyd.in", "r", stdin);
	freopen("royfloyd.out", "w", stdout);
	int i,j,c,n;
	cin>>n;
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			cin>>a[i][j];
			
	for(int k=0;k<n;k++){
    	for(i=0;i<n;i++){
       		for(j=0;j<n;j++){
               if(a[i][k]!=0&&a[k][j]!=0&&(a[i][j]>a[i][k]+a[k][j]||a[i][j]==0)){
					a[i][j]=a[i][k]+a[k][j];
               }
       		}
    	}
    	
	}
	
	for(i=0;i<n;i++){
		for(j=0;j<n;j++)
			cout<<a[i][j]<<" ";
		cout<<endl;
	}
}

