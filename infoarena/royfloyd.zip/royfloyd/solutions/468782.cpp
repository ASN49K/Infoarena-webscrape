#include <fstream>

using namespace std;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int C[101][101];
int N,i,j,k;
int main()
{
    in>>N;
    for(i=1;i<=N;i++)
        for(j=1;j<=N;j++)
            in>>C[i][j],C[i][j]=(C[i][j]==0?9999:C[i][j]);
    for(k=1;k<=N;k++)
        for(i=1;i<=N;i++)
            if(i!=k)for(j=1;j<=N;j++)
                if(C[i][j]>C[i][k]+C[k][j]&&i!=j)
                    C[i][j]=C[i][k]+C[k][j];
    for(i=1;i<=N;i++)
    {
        for(j=1;j<=N;j++)
            out<<(C[i][j]==9999?0:C[i][j])<<' ';
        out<<'\n';
    }
    return 0;
}
