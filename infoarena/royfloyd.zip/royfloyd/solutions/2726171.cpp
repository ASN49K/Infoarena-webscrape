#include<fstream>
using namespace std;
int a[101][101];
int main(){
    ifstream in("royfloyd.in");
    ofstream out("royfloyd.out");
    int i,j,n,k;
    in>>n;
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++){
            in>>a[i][j];
            if(a[i][j]==0&&i!=j)
                a[i][j]=1000000001;
        }
    }
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                a[i][j]=min(a[i][j],a[i][k]+a[k][j]);
    for(i=1;i<=n;i++){
        for(j=1;j<=n;j++){
            if(a[i][j]==1000000001)
                out<<0<<" ";
            else
                out<<a[i][j]<<" ";
        }
        out<<endl;
    }
    return 0;
}
