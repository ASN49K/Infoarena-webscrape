#include <fstream>

using namespace std;

int dp[100][100];

signed main() {
  ifstream cin("royfloyd.in");
  ofstream cout("royfloyd.out");
  int n, i, j, k;
  cin >> n;
  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      cin >> dp[i][j];
      if (dp[i][j] == 0 && i != j)
        dp[i][j] = INT32_MAX;
    }
  }
  for (k = 0; k < n; k++) {
    for (i = 0; i < n; i++) {
      for (j = 0; j < n; j++) {
        if (dp[i][j] > dp[i][k] + dp[k][j]) {
          dp[i][j] = dp[i][k] + dp[k][j];
        }
      }
    }
  }
  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      cout << dp[i][j] << " ";
    }
    cout << "\n";
  }
  return 0;
}