#include <cstdio>
using namespace std;
int i,j,k,n,a[101][101];
int main()
{
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++){
			scanf("%d",&a[i][j]);
						 }
					 }
	for(k=1;k<=n;k++){
		for(i=1;i<=n;i++){
			for(j=1;j<=n;j++){
				if((a[i][j])&&(a[i][k])&&(a[k][j])){
					if(a[i][j]>a[i][k]+a[k][j]){a[i][j]=a[i][k]+a[k][j];}
												   }
				if((a[i][j]==0)&&((a[i][k])&&(a[k][j]))){a[i][j]=a[i][k]+a[k][j];}
							 }
						 }
					 }
	for(i=1;i<=n;i++){
		for(j=1;j<=n;j++){
			printf("%d ",a[i][j]);
						 }
		printf("\n");
					 }
	
return 0;
}