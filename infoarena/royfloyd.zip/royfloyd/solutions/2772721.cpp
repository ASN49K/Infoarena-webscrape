#include <iostream>
#include <fstream>
#include <climits>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n;
int costuri[101][101];
int main()
{
	f >> n;
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
		{
			f >> costuri[i][j];
			if (!costuri[i][j] && i != j)
			{
				costuri[i][j] = INT_MAX;
			}
		}
	}
	for (int k = 1; k <= n; k++)
	{
		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j <= n; j++)
			{
				if (costuri[i][j] > costuri[i][k] + costuri[k][j])
				{
					costuri[i][j] = costuri[i][k] + costuri[k][j];
				}
			}
		}
	}
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
		{
			if (costuri[i][j] == INT_MAX)
				g << "0 ";
			else
				g << costuri[i][j] << " ";
		}
		g << endl;

	}

}