#include <bits/stdc++.h>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n,c[101][100];
void Citire()
{
    f>>n;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
            f>>c[i][j];
    f.close();
}

void Warshall()
{
    for(int k=1;k<=n;++k)
        for(int i=1;i<=n;++i)
            for(int j=1;j<=n;++j)
                if(c[i][k] && c[k][j])
                    {
                        if(c[i][j] == 0 || c[i][j] > c[i][k] + c[k][j])
                            c[i][j] = c[i][k] + c[k][j];
                    }
}

int main()
{
    Citire();
    Warshall();
    for(int i=1;i<=n;++i)
    {
        for(int j=1;j<=n;++j)
            if(i != j) g<<c[i][j]<<" ";
            else g<<0<<" ";
        g<<'\n';
    }
    g.close();
    return 0;
}
