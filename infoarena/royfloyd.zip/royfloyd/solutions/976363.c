#include<stdio.h>
#include<stdlib.h>

int main() {
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);

    int i, j, k, n;
    int **m;

    scanf("%d", &n);
    
    m = malloc(n * sizeof(int*));
    for (i = 0; i < n; i++) {
        m[i] = malloc(n * sizeof(int));
        for (j = 0; j < n; j++)
            scanf("%d", &m[i][j]);
    }

    for(k = 0; k < n; k++)
        for(i = 0; i < n; i++)
            for(j = 0; j < n; j++)
                if (m[i][j] > m[i][k] + m[k][j])
                    m[i][j] = m[i][k] + m[k][j];

    for(i = 0; i < n; i++) {
        for(j = 0; j < n; j++)
            printf("%d ", m[i][j]);
        printf("\n");
        free(m[i]);
    }

    free(m);

    return 0;
}
