#include <iostream>
#include <fstream>
using namespace std;
int n, a[101][101];

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

void royfloyd()
{
    for(int k=1;k<=n;k++)
       for(int i=1;i<=n;i++)
         for(int j=1;j<=n;j++)
         {
             a[i][j]=min(a[i][j],a[i][k]+a[k][j]);
         }
}

int main()
{
    in>>n;

    for(int i=1;i<=n;i++)
       for(int j=1;j<=n;j++) in>>a[i][j];


       royfloyd();

       for(int i=1;i<=n;i++)
       {
           for(int j=1;j<=n;j++) out<<a[i][j]<<" ";
           out<<'\n';
       }
    return 0;
}
