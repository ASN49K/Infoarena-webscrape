#include <fstream>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int a[105][105],n;

int main()
{
    f>>n;
    for (int i=1; i<=n; i++)
      for (int j=1; j<=n; j++) f>>a[i][j];


    for (int k=1; k<=n; k++)
      for (int i=1; i<=n; i++)
        for (int j=1; j<=n; j++)
           if (a[i][k]!=0 && a[k][j]!=0 && i!=j)
             if (a[i][j]>a[i][k]+a[k][j] || a[i][j]==0) a[i][j]=a[i][k]+a[k][j];

    for (int i=1; i<=n; i++)
    {
        for (int j=1; j<=n; j++) g<<a[i][j]<<' ';
        g<<'\n';
    }
    f.close(); g.close();
    return 0;
}
