#include <fstream>
using namespace std;
int n, a[260][260];
const int inf=1<<25;

int main()
{
    ifstream fin ("royfloyd.in");
    ofstream fout ("royfloyd.out");
    int i, j, k;
    fin >> n;
    for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
        {
            fin >> a[i][j];
            if(a[i][j]==0) a[i][j]=inf;
        }

     for(k=1; k<=n; k++)
        for(i=1; i<=n; i++)
            for(j=1; j<=n; j++)
                if(a[i][k]+a[k][j]<a[i][j] && i!=j)
                    a[i][j]=a[i][k]+a[k][j];

    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++)
        {
            if(a[i][j]==inf)
                a[i][j]=0;
            fout << a[i][j] << " ";
        }
        fout << "\n";
    }
    fin.close();
    fout.close();
    return 0;
}
