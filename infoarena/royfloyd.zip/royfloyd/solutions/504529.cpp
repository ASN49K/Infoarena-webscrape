#include <iostream>
#include <fstream>

using namespace std;
int n,a[103][103];

void init()
{
    ifstream f("royfloyd.in");
    f>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            f>>a[i][j];
}

void royfloyd()
{
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
               for(int j=1;j<=n;j++)
                  if (a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j)
                    a[i][j] = a[i][k] + a[k][j];
}

int main()
{
    ofstream g("royfloyd.out");
    init();
    royfloyd();

    for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
                    g<<a[i][j]<<" ";
            g<<"\n";
        }



    return 0;
}
