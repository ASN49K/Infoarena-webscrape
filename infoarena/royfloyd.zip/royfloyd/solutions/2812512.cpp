#include <bits/stdc++.h>
using namespace std;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");
typedef long long ll;
const ll inf=2e9+7;
ll v[105][105],n;
int main()
{
    in>>n;
    for(ll i=1;i<=n;++i)
    for(ll j=1;j<=n;++j)
    {
        in>>v[i][j];
        if(v[i][j]==0 and i!=j)
            v[i][j]=inf;
    }
    for(ll k=1;k<=n;++k)
    for(ll i=1;i<=n;++i) if(i!=k)
    for(ll j=1;j<=n;++j) if(j!=i and j!=k)
    if(v[i][k]!=0 and v[k][j]!=0 and v[i][k]+v[k][j]<v[i][j])
        v[i][j]=v[i][k]+v[k][j];
    for(ll i=1;i<=n;++i)
    {
        for(ll j=1;j<=n;++j)
        if(v[i][j]==inf)
            out<<0<<' ';
        else out<<v[i][j]<<' ';
        out<<'\n';
    }
    return 0;
}
