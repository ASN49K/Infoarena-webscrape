#include <cstdio>
#include <algorithm>

#define Nmax 105
#define INF 0x3f3f3f3f

using namespace std;

int N, A[Nmax][Nmax];

void Citire()
{
    scanf("%d", &N);
    for (int i = 1; i <= N; ++i)
        for (int j = 1; j <= N; ++j)
        {
            scanf("%d", &A[i][j]);
            if (!A[i][j])
                A[i][j] = INF;
        }
}

void Rezolvare()
{
    for (int k = 1; k <= N; ++k)
        for (int i = 1; i <= N; ++i)
            for (int j = 1; j <= N; ++j)
                if (i != j && j != k)
                    A[i][j] = min(A[i][j], A[i][k] + A[k][j]);
}

void Afisare()
{
    for (int i = 1; i <= N; ++i)
    {
        for (int j = 1; j <= N; ++j)
            if (A[i][j] != INF)
                printf("%d ", A[i][j]);
            else printf("0 ");
        printf("\n");
    }
}

int main()
{
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);

    Citire();
    Rezolvare();
    Afisare();

    return 0;
}
