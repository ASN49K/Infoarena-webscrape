#include <fstream>
#include <iostream>
using namespace std;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int main() {
    int n;
    in >> n;
    int r[n][n];
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            in >> r[i][j];
        }
    }
    for(int k = 0; k < n; k++) {
        for(int i = 0; i < n; i++) {
            for(int j = 0; j < n; j++) {
                if(r[i][j] > r[i][k] + r[k][j]) {
                    r[i][j] = r[i][k] + r[k][j];
                }
            }
        }
    }
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            out << r[i][j] << " ";
        }
        out << "\n";
    }
    return 0;
}