#include<fstream>
using namespace std;

int main(int nrargv,char* argv[])
{
 ifstream f;
 ofstream g;
 f.open("royfloyd.in",ios::in);
 g.open("royfloyd.out",ios::out);
 int n;
 f>>n;
 int m[100][100];
 for(int i=0; i<n;i++)
   for(int j=0; j<n; j++)
      f>>m[i][j];
 for(int i=0;i<n;i++)
   for(int j=0;j<n; j++)
      for(int k=0;k<n;k++)
         if (m[i][k]+m[k][j]<m[i][j] && m[i][k] && m[j][k]) m[i][j]=m[i][k]+m[k][j];
 for(int i=0;i<n;i++)
 {
   for(int j=0;j<n;j++)
      g<<m[i][j]<<" ";
   g<<"\n";
 }
 f.close();
 g.close();
 return 0;
}
