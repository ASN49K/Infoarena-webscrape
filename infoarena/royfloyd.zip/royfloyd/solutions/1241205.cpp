#include <fstream>
#include <vector>
using namespace std;

ifstream is("royfloyd.in");
ofstream os("royfloyd.out");

int g[100][100];
int d[100][100];
int n;

void Floyd_Warshall();
void Write();
void Read();

int main()
{
    Read();
    Floyd_Warshall();
    Write();
    is.close();
    os.close();
    return 0;

}

void Read()
{
    is >> n;
    for(int i = 1; i <= n; ++i)
    {
        for(int j = 1;j <= n; ++j)
        {
            is >> g[i][j];
        }
    }
    return;
}
void Floyd_Warshall()
{
    for(int k = 1; k <= n; ++k)
    {
        for(int i = 1; i <= n; ++i)
        {
            for(int j = 1; j <= n; ++j )
            {
                if(i != j && g[i][k] + g[k][j] < g[i][j])
                    g[i][j] = g[i][k] + g[k][j];
            }
        }
    }
}
void Write()
{
    for(int i = 1; i <= n; ++i)
    {
        for(int j = 1; j <=n; ++j)
        {
            os << g[i][j] << ' ';
        }
        os << '\n';
    }
    return;
}

