#include<fstream.h>
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
long i,j,k,n,a[101][101];
void drum()
{
	for (k=1;k<=n;k++)
		for (i=1;i<=n;i++)
			for (j=1;j<=n;j++)
				if ((a[i][k]!=0) && (a[k][j]!=0) && (a[i][j]>a[i][k]+a[k][j]) && j!=k) a[i][j]=a[i][k]+a[k][j];
}
int main()
{fin>>n;
for (i=1;i<=n;i++)
	for (j=1;j<=n;j++)
		fin>>a[i][j];
drum();
for (i=1;i<=n;i++)
{ for (j=1;j<=n;j++)
	fout<<a[i][j]<<' ';
fout<<'\n';
}
fin.close();
fout.close();
return 0;
}