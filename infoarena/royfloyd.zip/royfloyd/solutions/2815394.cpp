#include <bits/stdc++.h>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

class Graf
{
private:
  int N;
  int adj[101][101];
  void royFloyd();

public:
  Graf(int);
  void adaugaMuchie();
  void Afisare();
};

Graf ::Graf(int n)
{
  N = n;
}

void Graf ::adaugaMuchie()
{
  int i, j;
  for (i = 0; i < N; i++)
  {
    for (j = 0; j < N; j++)
    {
      fin >> adj[i][j];
      if (i != j && adj[i][j] == 0)
        adj[i][j] = INT_MAX;
    }
  }
}

void Graf ::royFloyd()
{
  int i, j, l;
  for (l = 0; l < N; l++)
    for (i = 0; i < N; i++)
      for (j = 0; j < N; j++)
        if(i != j && adj[i][l] != INT_MAX && adj[l][j] != INT_MAX)
          adj[i][j] = min(adj[i][j], (adj[i][l] + adj[l][j]));
}

void Graf ::Afisare()
{
  int i, j;
  royFloyd();
  for (i = 0; i < N; i++)
  {
    for (j = 0; j < N; j++)
        fout << adj[i][j] << " ";
    fout << "\n";
  }
}

int main()
{
  int n;
  fin >> n;
  Graf G(n);
  G.adaugaMuchie();
  G.Afisare();
  return 0;
}