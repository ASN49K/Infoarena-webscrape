#include <fstream>
using namespace std;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int d[105][105], n;

void roy_floyd()
{
    for(int k = 1; k <= n; k++)
        for(int i = 1; i <= n; i++)
            for(int j = 1; j <= n; j++)
                if (d[i][k] && d[k][j] && (d[i][j] > d[i][k] + d[k][j] || !d[i][j]) && i != j)
                    d[i][j] = d[i][k] + d[k][j];
}

int main()
{
    in >> n;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
            in >> d[i][j];

    roy_floyd();

    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
            out << d[i][j] << " ";
        out << '\n';
    }
    return 0;
}
