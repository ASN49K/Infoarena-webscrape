#include<fstream>
#include<stdio.h>

using namespace std;

int n, a[101][101];

int main()
{
    int i, j, k;

    ifstream f ("royfloyd.in");
    ofstream g ("royfloyd.out");

    f>>n;
    for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
            f>>a[i][j];

    for(k=1; k<=n; k++)
        for(i=1; i<=n; i++)
            for(j=1; j<=n; j++)
                if((a[i][j]>a[i][k]+a[k][j] || !a[i][j]) && i!=j && a[i][k] && a[k][j])
                    a[i][j]=a[i][k]+a[k][j];

    for(i=1; i<=n; i++)
        {
        for(j=1; j<=n; j++)
            g<<a[i][j]<<" ";
        g<<endl;
        }

    f.close();
    g.close();
    return 0;
}
