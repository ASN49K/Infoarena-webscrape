#include <bits/stdc++.h>

using namespace std;

#define f first
#define s second

ifstream fin( "royfloyd.in" );
ofstream fout( "royfloyd.out" );

int D[110][110],i,j,n,m,k;

int main()
{

    fin>>n;
    for( i = 1 ; i <= n ; i++ )
    {
        for( j = 1 ; j <= n ; j++ )
        {
            fin>>D[ i ][ j ];
            if( D[ i ][ j ] == 0 )
                D[ i ][ j ] = 1000000;
        }
    }

    for( k = 1 ; k <= n ; k++ )
    for( i = 1 ; i <= n ; i++ )
    for( j = 1 ; j <= n ; j++ )
        if( i != j && i != k && j != k )
            D[ i ][ j ] = min( D[ i ][ j ] , D[ i ][ k ] + D[ k ][ j ] );

    for( i = 1 ; i <= n ; i++ )
    {
        for( j = 1 ; j <= n ; j++ )
        {
            if( D[ i ][ j ] >= 1000000 )
                D[ i ][ j ] = 0;
            fout<<D[ i ][ j ]<<' ';
        }
        fout<<'\n';
    }

return 0;
}
