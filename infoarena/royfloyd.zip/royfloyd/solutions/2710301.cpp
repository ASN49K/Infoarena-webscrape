#include <bits/stdc++.h>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n,a[101][101],d[101][101];

const int INF = (1 << 29);
void solve()
{
    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= n; ++j)
          d[i][j] = (a[i][j] == 0 ? INF : a[i][j]);
    for(int k = 1; k <= n; ++k)
    {
        for(int i = 1; i <= n; ++i)
        {
            for(int j = 1; j <= n; ++j)
            {
                if(i != j)
                    d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
            }
        }
    }
}
int main()
{
    f >> n;
    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= n; ++j)
          f >> a[i][j];
    solve();
    for(int i = 1; i <= n; ++i)
    {
        for(int j = 1; j <= n; ++j)
            {
                if(d[i][j] == INF) d[i][j] = 0;
                g << d[i][j] << " ";
            }
        g << '\n';
    }
    return 0;
}
