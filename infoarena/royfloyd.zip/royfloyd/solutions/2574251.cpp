#include <iostream>
#include <fstream>
#define INF 9999999

using namespace std;

ifstream fi("royfloyd.in");
ofstream fo("royfloyd.out");

int n;
int mat[101][101];

int main()
{
    fi>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
        {
            fi>>mat[i][j];
            if(mat[i][j]==0)
                mat[i][j]=INF;
        }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            for(int k=1;k<=n;k++)
            {
                if(i!=k && j!=k && i!=j)
                {
                    if(mat[i][j]>mat[i][k]+mat[k][j])
                        mat[i][j]=mat[i][k]+mat[k][j];
                }

            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            if(mat[i][j]>=INF)
                mat[i][j]=0;
            fo<<mat[i][j]<<" ";
        }
        fo<<endl;
    }

    fi.close();
    fo.close();
    return 0;
}
