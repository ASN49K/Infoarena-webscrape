#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

#ifdef INFOARENA
ifstream f("royfloyd.in");
#define cout g
#else
ifstream f("date.in");
#endif // INFOARENA

ofstream g("royfloyd.out");

#define nmax 101

int a[nmax][nmax];
int n,i,j,k;

int main()
    {
    f>>n;
    for(i=1;i<=n;++i)
        for(j=1;j<=n;++j)
            f>>a[i][j];

    for(k=1;k<=n;++k)
        for(i=1;i<=n;++i)
    {
        if(i==k) continue;
        for(j=1;j<=n;++j)
            if(i!=j)
                if(a[i][k] && a[k][j])
                    if(a[i][j]==0 || a[i][j]>a[i][k]+a[k][j]) a[i][j]=a[i][k]+a[k][j];
    }

    for(i=1;i<=n;++i)
    {
        for(j=1;j<=n;++j) cout<<a[i][j]<<" ";
        cout<<'\n';
    }
    return 0;
    }
