#include <fstream>
#define DIM 101

using namespace std;
int n,m,a[DIM][DIM];

void royfloyd()
{
    for(int k=1;k<=n;++k)
    {
        for(int i=1;i<=n;++i)
        {
            for(int j=1;j<=n;++j)
            {
                if(a[i][k] && a[k][j] && a[i][j] && (a[i][k]+a[k][j]<a[i][j] || (!a[i][j] && i!=j)))
                a[i][j]=a[i][k]+a[k][j];
            }
        }
    }
}

int main()
{
    ifstream f("royfloyd.in");
    ofstream g("royfloyd.out");
    f>>n;
    for(int i=1;i<=n;++i)
    {
        for(int j=1;j<=n;++j)
        f>>a[i][j];
    }
    royfloyd();
    for(int i=1;i<=n;++i)
    {
        for(int j=1;j<=n;++j)
        g<<a[i][j]<<" " ;
        g<<'\n';
    }
    f.close();
    g.close();
    return 0;
}
