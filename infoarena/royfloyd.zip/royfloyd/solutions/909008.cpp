#include <cstdio>
#include <vector>
#include <queue>

#define nMax 110
#define oo 1 << 30
#define min(a,b) ((a<b)?a:b)

using namespace std;

class nod{
public:
    int catre;
    int cost;
    nod(int Catre, int Cost){
        catre = Catre;
        cost = Cost;
    };
};
int n;
vector <nod> graf[nMax];
int d[nMax];

struct cmp{
    bool operator () (const int &a, const int &b)const{
        return d[a] > d[b];
    };
};
priority_queue <int, vector <int>, cmp> q;

void citire(){
    int m;
    scanf("%d", &n);
    for(int i = 1; i <= n; ++ i){
        for(int j = 1; j <= n; ++ j){
            int x;
            scanf("%d", &x);
            if(x == 0){
                continue;
            }
            graf[i].push_back(nod(j,x));
        }
    }
}

void afisare();

void dijkstra(int nod){
    for(int i = 1; i <= n; ++ i){
        d[i] = oo;
    }
    d[nod] = 0;
    q.push(nod);
    while(!q.empty()){
        nod = q.top();
        q.pop();
        for(unsigned int i = 0; i < graf[nod].size(); ++ i){
            if(d[graf[nod][i].catre] > d[nod] + graf[nod][i].cost){
                d[graf[nod][i].catre] = d[nod] + graf[nod][i].cost;
                q.push(graf[nod][i].catre);
            }
        }
    }
    afisare();
}

void afisare(){
    for(int i = 1; i <= n; ++ i){
        if(d[i] == oo){
            d[i] = 0;
        }
        printf("%d ", d[i]);
    }
    printf("\n");
}

int main()
{
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);

    citire();
    for(int i = 1; i <= n; ++ i){
        dijkstra(i);
    }


    return 0;
}
