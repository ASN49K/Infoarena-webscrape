#include <bits/stdc++.h>
#define nMax 105

using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n, a[nMax][nMax];

int main()
{
    fin >> n;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            fin >> a[i][j];
    for(int k=1; k<=n; k++)
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++)
                if(i!=j && a[i][k] && a[k][j] && (!a[i][j] || a[i][j]>a[i][k]+a[k][j]))
                    a[i][j]=a[i][k]+a[k][j];
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            fout << a[i][j] << " \n"[j==n];
    return 0;
}
