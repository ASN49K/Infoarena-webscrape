#include <bits/stdc++.h>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n;
int a[100][100];

int main() {
    fin >> n;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fin >> a[i][j];
        }
    }

    for (int k = 0; k < n; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (a[i][k] && a[k][j]
                    && (a[i][j] > a[i][k] + a[k][j] || (a[i][j] == 0 && i != j))) {
                    a[i][j] = a[i][k] + a[k][j];
                }
            }
        }
    }

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            fout << a[i][j] << " ";
        }
        fout << "\n";
    }
}
