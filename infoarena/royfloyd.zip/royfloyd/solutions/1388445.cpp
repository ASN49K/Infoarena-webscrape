#include <fstream>

using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
int v[101][101];
inline int min1(int a,int b)
{
        if(a<b) return a;
        return b;
}
int main()
{
    int n,i,j,k,a=0,inf=10000;
    fin>>n;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++) fin>>v[i][j];
    }
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
            {
                if(i!=j)
                {
                if(v[i][k]!=0 &&v[k][j]!=0) a=v[i][k]+v[k][j];
                else a=inf;
                v[i][j]=min1(v[i][j],a);
                }
            }
        }
    }
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++) fout<<v[i][j]<<" ";
        fout<<"\n";
    }
}
