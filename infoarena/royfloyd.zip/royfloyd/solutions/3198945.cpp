#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");


const int NMAX = 101;
const int INF = 1000000;
int m[NMAX][NMAX];
int n;

int main() {
    fin >> n;
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            fin >> m[i][j];
            if (m[i][j] == 0 && i != j) {
                m[i][j] = INF;
            }
        }
    }
    for (int k = 1; k <= n; k++) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                int drumNou = m[i][k] + m[k][j];
                bool test = i != k && j != k && i != j && m[i][k] != 0 && m[k][j] != 0;
                if (drumNou < m[i][j] && test) {
                    m[i][j] = drumNou;
                }
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            fout << m[i][j] << " ";
        }
        fout << "\n";
    }
}