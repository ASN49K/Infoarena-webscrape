#include <cstdio>

using namespace std;

FILE *f;
FILE *g;

int n;
int c[110][110];

int main()
{
    f=fopen("royfloyd.in","r");
    g=fopen("royfloyd.out","w");
    fscanf(f,"%d",&n);
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            fscanf(f,"%d",&c[i][j]);
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                if(c[i][k]&&c[k][j]&&(i!=j))
                    if(c[i][k]+c[k][j]<c[i][j]||!c[i][j])
                        c[i][j]=c[i][k]+c[k][j];
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            fprintf(g,"%d ",c[i][j]);
        fprintf(g,"\n");
    }
    return 0;
}
