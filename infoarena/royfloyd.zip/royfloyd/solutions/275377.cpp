#include<iostream.h>
#include<fstream.h>

int a[105][105],N;

void citire()
{
     fstream in("royfloyd.in",ios::in);
     in>>N;
     for(int i=1;i<=N;i++)
             for(int j=1;j<=N;j++)
                     in>>a[i][j];
     in.close();
}

void scriere()
{
     fstream out("royfloyd.out",ios::out);
     for (int i=1;i<=N;i++)
         {
              for (int j=1;j<=N;j++)
                  out<<a[i][j]<<" ";
              out<<"\n";
         }
         out.close();
}

void royfloyd()
{
     for(int k=1;k<=N;k++)
             for(int i=1;i<=N;i++)
                              for(int j=1;j<=N;j++)
                                               if(a[i][k]&&a[j][k]&&i!=j&&(a[i][j]>a[i][k]+a[k][j]||!a[i][j]))
                                                          a[i][j]=a[i][k]+a[k][j];
}

int main()
{
    citire();
    royfloyd();
    scriere();
    return 0;
}
