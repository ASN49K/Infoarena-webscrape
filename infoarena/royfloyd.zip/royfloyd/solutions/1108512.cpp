#include <fstream>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

const int inf= 1<<30;
const int nmax= 110;

int g[nmax+1][nmax+1];

int main(  ) {
    int n;
    fin>>n;
    for ( int i= 1; i<=n; ++i ) {
        for ( int j= 1; j<=n; ++j ) {
            fin>>g[i][j];
            if ( g[i][j]==0 ) {
                g[i][j]= inf;
            }
        }
    }

    for ( int i= 1; i<=n; ++i ) {
        for ( int j= 1; j<=n; ++j ) {
            for ( int k= 1; k<=n; ++k ) {
                if ( g[j][k]>0 && g[i][k]>0 && j!=k && g[j][k]>g[j][i]+g[i][k] ) {
                    g[j][k]= g[j][i]+g[i][k];
                }
            }
        }
    }

    for ( int i= 1; i<=n; ++i ) {
        for ( int j= 1; j<=n; ++j ) {
            if ( g[i][j]==inf ) {
                g[i][j]= 0;
            }
            fout<<g[i][j]<<" ";
        }
        fout<<"\n";
    }

    return 0;
}

