#include <bits/stdc++.h>
#define ll long long
#define sz size
#define pb push_back
#define er erase
#define in insert
#define fr first
#define sc second
#define mp make_pair
#define pi pair
#define _ ios_base::sync_with_stdio(false);cin.tie(0);cerr.tie(0);cout.tie(0);
#define rc(s) return cout<<s,0
const int mod=1e9+7;
const int inf=1e5;
using namespace std;
std::multiset<int>::iterator it;
std::multiset<int>::iterator it1;


int n,a[105][105];

int main(){ _
    ifstream fin ("royfloyd.in");
    ofstream fout("royfloyd.out");
    fin >> n;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            fin >> a[i][j];
        }
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            for(int k=1;k<=n;k++){
                if(a[i][k]>a[i][j]+a[j][k]){
                    a[i][k]=a[i][j]+a[j][k];
                }
            }
        }
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            fout<<a[i][j]<<' ';
        }
        fout<<endl;
    }


}
