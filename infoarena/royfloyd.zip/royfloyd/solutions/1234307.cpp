#include <cstdio>
#define NMAX 100
#define INF 0x3f3f3f3f
#define min(a,b) a < b ? a:b

int n;
int Shortest_Path[NMAX][NMAX];

inline void read(){

    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);

    scanf("%d",&n);
        for(register int i=1;i<=n;++i)
            for(register int j=1;j<=n;++j){
                    scanf("%d",&Shortest_Path[i][j]);

            }
}

inline void Roy_Floyd(){

    for(register int k=1;k<=n;++k)
        for(register int i=1;i<=n;++i)
            for(register int j=1;j<=n;++j)
              if(i!=j && Shortest_Path[i][j] && Shortest_Path[i][k] && Shortest_Path[k][j])
                Shortest_Path[i][j] = min(Shortest_Path[i][j],Shortest_Path[i][k] + Shortest_Path[k][j]);
}

inline void write(){

    for(register int i=1;i<=n;++i){
        for(register int j=1;j<=n;++j)
            printf("%d ",Shortest_Path[i][j]);

            printf("\n");
 }
}

int main(){

    read();
    Roy_Floyd();
    write();

return 0;
}
