use std::fs::{self,File};
use std::io::{BufWriter, Write};
macro_rules! parse_line {
    ($iter : expr, $($t: ty),+) => {{
        let line = $iter.next().unwrap(); 
        let mut parts = line.split_whitespace();
        ($(parts.next().unwrap().parse::<$t>().unwrap()),+)
    }};
}
macro_rules! parse_vector {
    ($iter : expr, $t: ty) => {{
        $iter
            .next()
            .unwrap()
            .split_whitespace()
            .map(|x| x.parse::<$t>().unwrap())
            .collect::<Vec<$t>>()
    }};
}
fn main() ->std::io::Result<()> {
    
    let content = fs::read_to_string("royfloyd.in")?;
    let mut lines = content.lines();
    let mut writer = BufWriter::new(File::create("royfloyd.out")?);
    let n = parse_line!(lines,usize);
    let mut dp: Vec<Vec<i32>> = (0..n)
        .map(|_| parse_vector!(lines, i32))
        .collect();
    for k in 0..n {
        for i in 0..n {
            for j in 0..n {
                dp[i][j] = std::cmp::min(dp[i][j], dp[i][k].saturating_add(dp[k][j]));
            }
        }
    }
    for i in 0..n {
        for j in 0..n {
            if i != j && dp[i][j] >= 2e9 as i32 {
                dp[i][j] = 0;
            }
        }
    }
    for i in 0..n {
        for j in 0.. n {
            write!(writer, "{} ", &dp[i][j])?;
        }
        writeln!(writer)?;
    }
    Ok(())   
}