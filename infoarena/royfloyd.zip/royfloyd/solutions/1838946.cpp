#include <fstream>
using namespace std;
const int NMAX = 100;
int d[100][100];
int main() {
	freopen("royfloyd.in", "r", stdin);
	freopen("royfloyd.out", "w", stdout);
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; ++ i) {
		for (int j = 0; j < n; ++ j) {
			scanf("%d", &d[i][j]);
		}
	}
	for (int k = 0; k < n; ++ k) {
		for (int i = 0; i < n; ++ i) {
			for (int j = 0; j < n; ++ j) {
				if (d[i][k] && d[k][j] && i != j)
				d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
			}
		}
	}
	for (int i = 0; i < n; ++ i, printf("\n")) {
		for (int j = 0; j < n; ++ j) {
			printf("%d ", d[i][j]);
		}
	}
	return 0;
}