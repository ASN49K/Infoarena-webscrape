#include <cstdio>
using namespace std;
const int NMAX=105;
int c[NMAX][NMAX];
const int INF=1000000000;
int n;

void print()
{
    int i,j;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            if(c[i][j]==INF)
                printf("0 ");
            else
                printf("%d ",c[i][j]);
        }
        printf("\n");
    }
}

void RoyFloyd()
{
    int i,j,k;
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
            {
                if(i!=j && (c[i][k]+c[k][j])<c[i][j])
                    c[i][j]=c[i][k]+c[k][j];
            }
        }
    }
}

int main()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    int i,j;
    scanf("%d",&n);

    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            scanf("%d",&c[i][j]);
            if(c[i][j]==0)
                c[i][j]=INF;
        }
    }

    RoyFloyd();
    print();

    fclose(stdin);
    fclose(stdout);
    return 0;
}
