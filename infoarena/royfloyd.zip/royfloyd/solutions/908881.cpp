#include <fstream>
# define inf 100001
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n,i,j,k,d[101][101];

int main()
{
    fin>>n;
    for (i=1;i<=n;i++) for (j=1;j<=n;j++) {fin>>d[i][j]; if (d[i][j]==0) d[i][j]=inf;}
    for (i=1;i<=n;i++)
    for (j=1;j<=n;j++)
    {
        if (i==j) continue;
        for (k=1;k<=n;k++)
        {
            if (i==k||j==k) continue;
            if (d[i][j]>d[i][k]+d[k][j]) d[i][j]=d[i][k]+d[k][j];
        }
    }
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=n;j++)
        {
            if (d[i][j]==inf) fout<<0<<" ";
            else fout<<d[i][j]<<" ";
        }
        fout<<"\n";
    }
    return 0;
}
