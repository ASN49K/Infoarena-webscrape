#include<stdio.h>
#define maxint 1<<30

using namespace std;

FILE *c,*d;

int main()
{
	int a[101][101],n,i,j,k,x;
	FILE *c,*d;
	c=fopen("royfloyd.in","r");
	d=fopen("royfloyd.out","w");
	fscanf(c,"%d",&n);
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
			if(i==j)
				a[i][j]=0;
			else
				a[i][j]=maxint;
	for(i=1;i<=n;i++)
		for(j=1;j<=n;j++)
		{
			fscanf(c,"%d",&x);
			if(x!=0)
				a[i][j]=x;
		}
	for(k=1;k<=n;k++)
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				if(k!=i&&k!=j&&(a[i][k]+a[k][j]<a[i][j]))
					a[i][j]=a[i][k]+a[k][j];
	for(i=1;i<=n;i++)
	{
		fprintf(d,"\n");
		for(j=1;j<=n;j++)
				fprintf(d,"%d ",a[i][j]);
	}
	fclose(c);
	fclose(d);
	return 0;
}