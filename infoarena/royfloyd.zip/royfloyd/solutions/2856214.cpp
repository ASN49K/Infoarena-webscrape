#include <bits/stdc++.h>

using namespace std;

const int N = 105;
const int INF = (1 << 29);

int ba[N], cost[N][N], dp[N][N], n, a, b, t;

void cp() {
  for (int i = 1; i <= n; ++i)
    for (int j = 1; j <= n; ++j)
      dp[i][j] = cost[i][j];
}

void update(int l, int r, int maxi) {// [--[ ]
  for (int k = 1; k <= n; ++k)
    if (ba[k] >= l && ba[k] <= maxi)
      for (int i = 1; i <= n; ++i)
        if (ba[i] >= l && ba[i] <= maxi)
          for (int j = 1; j <= n; ++j)
            if (ba[j] >= l && ba[j] <= maxi)
              dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j]);
}

bool check(int l, int r) {
  for (int i = 1; i <= n; ++i)
    if (ba[i] >= l && ba[i] <= r)
      for (int j = 1; j <= n; ++j)
        if (ba[j] >= l && ba[j] <= r)
          if (dp[i][j] == t) {
            a = i, b = j;
            return true;
          }
  return false;
}

int main() {
  ifstream cin("coach.in");
  ofstream cout("coach.out");
  int m;
  cin >> n >> m >> t;
  vector<int> v;
  for (int i = 1; i <= n; ++i) {
    cin >> ba[i];
    v.push_back(ba[i]);
  }
  sort(v.begin(), v.end());
  auto it = unique(v.begin(), v.end());
  v.erase(it, v.end());
  for (int i = 1; i <= n; ++i)
    for (int j = 1; j <= n; ++j)
      if (i != j)
        cost[i][j] = INF;
  while (m--) {
    int x, y, c;
    cin >> x >> y >> c;
    cost[x][y] = cost[y][x] = min(cost[x][y], c);
  }
  cin.close();
  int mini, maxi;
  bool found = false;
  for (int i = 0; i < v.size() && !found; ++i) {
    cp();
    int last = v[i] + 1;
    for (int j = i; j >= 0; --j) {
      update(v[j], last - 1, v[i]);
      //cout << v[j] << ' ' << v[i] << "\n";
     // for (int i1 = 1; i1 <= n; ++i1)
      //  for (int j1 = 1; j1 <= n; ++j1)
      //    cout << "dp[" << i1 << "][" << j1 << "] = " << dp[i1][j1] << "\n";
     // cout << "\n\n";
      if (check(v[j], v[i])) {
        found = true;
        mini = v[j], maxi = v[i];
        break;
      }
      last = v[j];
    }
  }
  cout << a << " " << b << " " << mini << " " << maxi << "\n";
  cout.close();
  return 0;
}
