#include <iostream>
#include <fstream>

using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n, m[105][105];
int main()
{
    f>>n;
    for(int i=1; i<=n; i++)
    for(int j=1; j<=n; j++)
    f>>m[i][j];

    for(int k=1; k<=n; k++)
    for(int i=1; i<=n; i++)
    for(int j=1; j<=n; j++)
    {
    if(m[i][k]!=0&&m[k][j]!=0&&i!=j&&
    (m[i][j]>m[i][k]+m[k][j]||m[i][j]==0))
     m[i][j]=m[i][k]+m[k][j];
    }
    for(int i=1; i<=n; i++){
    for(int j=1; j<=n; j++)
    g<<m[i][j]<<" ";
    g<<endl;}
    return 0;
}
