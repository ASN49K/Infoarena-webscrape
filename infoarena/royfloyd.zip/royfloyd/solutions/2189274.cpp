#include <cstdio>
#include <algorithm>

FILE *fin, *fout;

const int maxn = 100;
const int INF = 1e9;

int N, a[maxn + 3][maxn + 3];
int d[maxn + 3][maxn + 3];

int main()  {
	fin = fopen("royfloyd.in", "r");
	fout = fopen("royfloyd.out", "w");
	fscanf(fin, "%d", &N);
	for(int i = 1;i <= N;i++)
        for(int j = 1;j <= N;j++)  {
            fscanf(fin, "%d", &a[i][j]);
            d[i][j] = a[i][j];
            if(a[i][j] == 0)
                d[i][j] = INF;
        }
    for(int k = 1;k <= N;k++)
        for(int i = 1;i <= N;i++)
            for(int j = 1;j <= N;j++)  {
                if(i != j)
                    d[i][j] = std::min(d[i][j], d[i][k] + d[k][j]);
            }
    for(int i = 1;i <= N;i++)  {
        for(int j = 1;j <= N;j++)
            fprintf(fout, "%d ", (d[i][j] == INF) ? 0 : d[i][j]);
        fprintf(fout, "\n");
    }
	fclose(fin);
	fclose(fout);
	return 0;
}
