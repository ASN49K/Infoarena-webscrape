# include <cstdio>
using namespace std;

FILE *f = freopen("royfloyd.in", "r", stdin);
FILE *g = freopen("royfloyd.out", "w", stdout);

const int N_MAX = 101;

int v[N_MAX][N_MAX];

int n;

void read()
{
    scanf("%d", &n);

    for (int i=1; i<=n; i++)
    {
        for (int j=1; j<=n; j++)
        {
            scanf("%d", &v[i][j]);
        }
    }
}

void solve()
{
    for (int k=1; k<=n; k++)
    {
        for (int i=1; i<=n; i++)
        {
            for (int j=1; j<=n; j++)
            {
                if (i == j || j==k || i == k) continue;
                if (!v[i][k] || !v[k][j]) continue;

                if (!v[i][j] || v[i][k] + v[k][j] < v[i][j])
                    v[i][j] = v[i][k] + v[k][j];
            }
        }
    }

    for (int i=1; i<=n; i++)
    {
        for (int j=1; j<=n; j++)
            printf("%d ", v[i][j]);

        printf("\n");
    }
}

int main()
{
    read();
    solve();
    return 0;
}
