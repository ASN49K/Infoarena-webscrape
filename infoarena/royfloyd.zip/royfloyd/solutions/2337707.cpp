#include <iostream>
#include <fstream>
using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int n,a[101][101];

void citire()
{
    f>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            f>>a[i][j];
}

void afisare()
{
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            g<<a[i][j]<<" ";
        g<<'\n';
    }
}

void roy()
{
    int i,j,k;
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
               if(a[i][k]!=0 && a[j][k]!=0 && i!=j && (a[i][j]>a[i][k]+a[k][j] || a[i][j]==0))
                   a[i][j]=a[i][k]+a[k][j];
}


int main()
{
    citire();
    roy();
    afisare();
}
