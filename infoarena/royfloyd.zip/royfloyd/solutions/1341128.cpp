#include <stdio.h>

short ** read (FILE *in, int *n) {
	fscanf(in, "%d", n);
	
	short **m = new short *[*n];
	for (int i = 0; i < *n; i++) {
		m[i] = new short[*n];
	}
	
	for (int i = 0; i < *n; i++) {
		for (int j = 0; j < *n; j++) {
			fscanf(in, "%hd", &m[i][j]);
		}
	}
	
	return m;
}

void print (FILE *out, short **m, int n) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			fprintf(out, "%hd ", m[i][j]);
		}
		fprintf(out, "\n");
	}
}

void royfloyd (short **m, int n) {
	for (int k = 0; k < n; k++) {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if ((i != j) && (m[i][k] != 0) && (m[k][j] != 0)) {
					int np = m[i][k] + m[k][j];	
					if (m[i][j] == 0) {
						m[i][j] = np;
					} else if (m[i][j] > np) {
						m[i][j] = np;
					}
				}
			}
		}
	}
}

int main (void) {
	FILE *in = fopen("royfloyd.in", "r");
	FILE *out = fopen("royfloyd.out", "w");
	
	int n;
	short **m = read(in, &n);
	royfloyd(m, n);
	print(out, m, n);
	
	return 0;
}
	
	
	
