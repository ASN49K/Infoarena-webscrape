#include <iostream>
#include <fstream>
#include <algorithm>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

const int NMAX = 105;
const int INF = 2000000009;
int n;
int a[NMAX][NMAX], dist[NMAX][NMAX];

void read()
{
	fin >> n;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++)
			dist[i][j] = 0;
	for(int i = 1 ; i <= n ; i++)
		for (int j = 1; j <= n; j++) {
			fin >> a[i][j];
			if (i != j) dist[i][j] = a[i][j];
		}
}

void solve()
{
	for (int k = 1; k <= n; k++)
		for (int i = 1; i <= n; i++)
			for (int j = 1; j <= n; j++)
                if(i != j && dist[i][k] != 0 && dist[k][j] != 0)
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
}

void write()
{
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
			fout << dist[i][j] << " ";
		fout << "\n";
	}
}

int main()
{
	read();
	solve();
	write();
	return 0;
}

