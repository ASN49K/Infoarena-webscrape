#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
int d[101][101],n;
void citire()
{
    fin>>n;
    for(int i=1;i<=n;i++)
    for(int j=1;j<=n;j++)
        fin>>d[i][j];
}
void build()
{
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
         for(int j=1;j<=n;j++)
           if(d[i][j]>d[i][k]+d[k][j])
           d[i][j]=d[i][k]+d[k][j];
}
void afisare()
{
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            fout<<d[i][j]<<"  ";
             fout<<endl;}
}
int main()
{
    citire();
    build();
    afisare();
    return 0;
}
