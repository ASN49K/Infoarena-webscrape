#include <stdio.h>
long i,j,k,n;
long a[110][110];

int main()
{
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	scanf("%ld",&n);
	for (i=1; i<=n; i++)
		for (j=1; j<=n; j++)
			scanf("%ld",&a[i][j]);
	for (k=1; k<=n; k++)
		for (i=1; i<=n; i++)
			for (j=1; j<=n; j++)
				if (a[i][k]+a[k][j]<a[i][j])
					a[i][j]=a[i][k]+a[k][j];
	for (i=1; i<=n; i++)
	{
		for (j=1; j<n; j++)
			printf("%ld ",a[i][j]);
		printf("%ld\n",a[i][n]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}