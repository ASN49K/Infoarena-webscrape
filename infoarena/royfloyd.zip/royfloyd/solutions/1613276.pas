program roy;
var a:array [1..101,1..101] of longint;
    f,g:text;
    i,j,k,n:integer;
begin
  assign(f,'royfloyd.in');reset(f);
  assign(g,'royfloyd.out');rewrite(g);
  readln(f,n);
  for i:=1 to n do
    begin
      for j:=1 to n do
        begin
          read(f,a[i,j]);
          if (i<>j)and(a[i,j]=0) then
            a[i,j]:=10000;
        end;
      readln(f);
    end;
  for k:=1 to n do
    for i:=1 to n do
      for j:=1 to n do
         if (a[i,j]>a[i,k]+a[k,j])and(i<>j)then
         a[i,j] := a[i,k]+a[k,j];
  for i:=1 to n do
    begin
      for j:=1 to n do
        write(g,a[i,j],' ');
      writeln(g);
    end;
  close(f);
  close(g);
end.
