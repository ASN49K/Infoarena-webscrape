#include <fstream>
#include <iostream>

using namespace std;

const int NMAX = 101;

int d[NMAX][NMAX];

int main() {
  int n, m;

  ifstream cin("royfloyd.in");
  ofstream cout("royfloyd.out");

  cin >> n;

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      cin >> d[i][j];
    }
  }

  for (int k = 0; k < n; k++) {
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n; j++) {
        if (d[i][k] && d[k][j]) {
          d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
        }

        if (!d[i][j] && i != j) {
          d[i][j] = d[i][k] + d[k][j];
        }
      }
    }
  }

  for (int i = 0; i < n; i++) {
    for (int j = 0; j < n; j++) {
      cout << d[i][j] << " ";
    }
    cout << '\n';
  }

  return 0;
}