#include <fstream>
#define DMAX 102
#define INF 1001

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n;
int C[DMAX][DMAX];

void citire();
void roy_floyd();
void afisare();

int main()
{
    citire();
    roy_floyd();
    afisare();
    return 0;
}

void citire()
{
    int i, j;
    fin>>n;
    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
        {
            fin>>C[i][j];
            if(!C[i][j] && i!=j) C[i][j]=INF;
        }
}

void roy_floyd()
{
    int i, j, k;
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if(C[i][k]+C[k][j]<C[i][j])
                    C[i][j]=C[i][k]+C[k][j];
}

void afisare()
{
    int i, j;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
            if(C[i][j]!=INF) fout<<C[i][j]<<' ';
                else fout<<0<<'\n';
        fout<<'\n';
    }
}
