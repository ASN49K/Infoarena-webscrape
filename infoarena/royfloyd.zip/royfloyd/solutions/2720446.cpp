#include <iostream>
#include <fstream>
#define inf 1000000000
#define NMAX 100

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n, dp[NMAX+10][NMAX+10];

int main()
{
	fin >> n;
	for(int i=1; i<=n; i++)
		for(int j=1; j<=n; j++)
			{	int x;
				fin >> x;
				if(!x)
					dp[i][j] = inf;
				else
					dp[i][j] = x;
			}
	for(int k=1; k<=n; k++)
		for(int i=1; i<=n; i++)
			if(i != k)
				for(int j=1; j<=n; j++)
					if(i != j && k != j)
						dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j]);
	for(int i=1; i<=n; i++)
		{	for(int j=1; j<=n; j++)
				{	if(dp[i][j] == inf)
						fout << 0 << ' ';
					else
						fout << dp[i][j] << ' ';
				}
			fout << '\n';
		}
	return 0;
}