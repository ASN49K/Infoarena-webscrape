#include<cstdio>

const int N = 102;

int n, cost[N][N];

void citire() {
    scanf("%d", &n);

    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j)
            scanf("%d", &cost[i][j]);
}

inline int min(int x, int y) {
    return x < y ? x : y;
}

void rez() {
    for (int k = 1; k <= n; ++k)
        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= n; ++j)
                if (i != j && cost[i][k] && cost[k][j])
                cost[i][j] = min(cost[i][j], cost[i][k] + cost[k][j]);
}

void afis() {
    for (int i = 1; i <= n; ++i) {
        for (int j = 1; j <= n; ++j)
            printf("%d ", cost[i][j]);
        printf("\n");
    }
}

int main() {
    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);

    citire();

    rez();

    afis();

    return 0;
}
