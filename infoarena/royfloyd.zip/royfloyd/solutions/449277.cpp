#include<fstream>
using namespace std;
int ma[100][100],n;
ofstream g("royfloyd.out");
void citire()
{
    ifstream f("royfloyd.in");
    f>>n;
    for(int i=1;i<=n;i++)
    for(int j=1;j<=n;j++)
        f>>ma[i][j];
    f.close();
}
void roywarshall()
{
for (int k=1; k<=n; k++)
	for (int i=1; i<=n; i++)
	  for (int j=1; j<=n; j++)
		if (ma[i][k] && ma[k][j] && (ma[i][j]>ma[i][k]+ma[k][j] || (!ma[i][j] && i!=j))) ma[i][j]=ma[i][k]+ma[k][j];
}
void afisare ()
{
  for (int i=1; i<=n; i++)
  {
	for (int j=1; j<=n; j++)
	  g<<ma[i][j]<<" ";
	g<<'\n';
  }
}
int main()
{
    citire();
    roywarshall();
    afisare();
    return 0;
}
