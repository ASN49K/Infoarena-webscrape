#include <iostream>
#include <fstream>
#define nmax 101
using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int n,v[nmax][nmax];

void read()
{
    f>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            f>>v[i][j];
}
void solve()
{
    for(int k=1;k<=n;k++)
    {
        for(int i=1;i<=n;i++)
        {
            if(!v[i][k])continue;
            for(int j=1;j<=n;j++)
            {
                if(!v[k][j])continue;
                if(v[i][j]>v[i][k]+v[k][j])v[i][j]=v[i][k]+v[k][j];
            }
        }
    }
}
void write()
{
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            g<<v[i][j]<<" ";
        g<<"\n";
    }
}
int main()
{
    read();
    solve();
    write();
    return 0;
}
