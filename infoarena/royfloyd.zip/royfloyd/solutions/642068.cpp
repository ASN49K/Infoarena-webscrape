# include <cstdio>
int v[101][101],n;

int main ()
{
	freopen ("royfloyd.in","r",stdin);
	freopen ("royfloyd.out","w",stdout);
	scanf ("%d",&n);
	for (int i=1; i<=n;i++)
		for (int j=1;j<=n;j++)
		{
			scanf ("%d",&v[i][j]);
			if (!v[i][j] && i!=j)
				v[i][j]=1000001;
		}
	for (int k=1;k<=n;k++)
		for (int i=1;i<=n;i++)
			for (int j=1; j<=n;j++)
				if (v[i][k]+v[k][j]<v[i][j])
					v[i][j]=v[i][k]+v[k][j];
	for (int i=1; i<=n;i++)
	{
		for (int j=1;j<=n;j++)
		{
			if (v[i][j]==1000001)
				printf("0 ");
			else
				printf ("%d ",v[i][j]);
		}
		printf ("\n");
	}
	return 0;
}
