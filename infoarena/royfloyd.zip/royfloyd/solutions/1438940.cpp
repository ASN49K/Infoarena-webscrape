#include <fstream>
#include <vector>
using namespace std;
ifstream f("dfs.in");
ofstream g("dfs.out");
vector <int>A[200001];
int i,n,m,viz[200001],nr,x,y,j;
void dfs(int nod){
        viz[nod]=1;
            for(int j=0;j<A[nod].size();j++)
                if(viz[A[nod][j]]==0)
                    dfs(A[nod][j]);}
int main()
{f>>n>>m;
for(i=1;i<=m;i++){
        f>>x>>y;
        A[x].push_back(y);
        A[y].push_back(x);}
        for(i=1;i<=n;i++)

        if(viz[i]==0){
            dfs(i);
        nr++;
    }
g<<nr;
    return 0;
}
