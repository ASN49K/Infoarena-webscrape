#include <fstream>
using namespace std;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");
int n, a[105][105];
void citire()
{

    int i, j;
    in >>n;
    for (i = 1; i <= n; i++)
        for (j = 1; j <= n; j++)
            in>>a[i][j];
}

void roy_floyd()
{
    int i, j, k;
    for (k = 1; k <= n; k++)
        for (i = 1; i <= n; i++)
            for (j = 1; j <= n; j++)
                if (a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j)
                    a[i][j] = a[i][k] + a[k][j];
}

void afis()
{
    int i, j;
    for (i = 1; i <= n; i++)
    {
        for (j = 1; j <= n; j++)
            out <<a[i][j] <<' ';
        out <<'\n';
    }
}


int main()
{
    citire();
    roy_floyd();
    afis();
    return 0;
}
