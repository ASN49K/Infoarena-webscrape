#include <fstream>
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int n,a[101][101];

void roy()
{
    for(int k=1;k<=n;k++)
    for(int i=1;i<=n;i++)
    for(int j=1;j<=n;j++)
    if(a[i][j]>a[i][k]+a[k][j])
    a[i][j]=a[i][k]+a[k][j];
}

void citire()
{
    f>>n;
    for(int i=1;i<=n;i++)
    for(int j=1;j<=n;j++)
    f>>a[i][j];
}

void afara()
{
    for(int i=1;i<=n;i++)
    {
    for(int j=1;j<=n;j++)
    g<<a[i][j]<<" ";
g<<"\n";}
}
int main()
{
    citire();
    roy();
    afara();
}
