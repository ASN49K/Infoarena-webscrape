#include <fstream>
#include <algorithm>
using namespace std;
int A[105][105],N;
int main(){
	ifstream fin("royfloyd.in");
	ofstream fout("royfloyd.out");
	fin >> N;
	for(int i = 0;i<N;i++){
		for(int j = 0;j<N;j++){
			fin >> A[i][j];
		}
	}
	for(int k = 0;k<N;k++){
		for(int i = 0;i<N;i++){
		    for(int j = 0;j<N;j++){
				if(A[i][k] && A[k][j] && (A[i][k]+A[k][j] < A[i][j] || !A[i][j]) && i != j) A[i][j] = A[i][k] + A[k][j];
		    } 
		}
	}
	for(int i = 0;i<N;i++){
		for(int j = 0;j<N;j++){
			fout << A[i][j] << ' ';
		}
		fout << '\n';
	}
	
	return 0;
}
