#include <iostream>
#include <queue>
#include <vector>
#include <fstream>
#include <climits>


using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n;
int D[105][105];
const int INF = 2000000;

int main()
{
    fin>>n;
    for(int i=1;i<=n;i++)
        for(int j=1; j<=n; j++)
    {
        fin>>D[i][j];
        if(D[i][j]== 0 && i != j)
            D[i][j]= INF;
    }

    for(int k=1; k<=n; k++){
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                if(D[i][k] != INF && D[k][j] != INF){
                    D[i][j]=min(D[i][j],D[i][k]+D[k][j]);
                }
            }
        }
    }

    for(int i=1; i<=n; i++){
        for(int j=1; j<=n; j++){
            if(D[i][j] == INF)
                fout<<0<<" ";
            else
                fout<<D[i][j]<<" ";
        }
        fout<<"\n";
    }
    fout<<"\n";
    return 0;
}
