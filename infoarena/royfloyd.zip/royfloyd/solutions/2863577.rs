use std::fs::File;
use std::io::{BufRead, BufReader, Write};
use std::cmp;

fn main () {
    let mut f = BufReader::new(File::open("royfloyd.in").unwrap());

    let mut n = String::new();
    f.read_line(&mut n).unwrap();
    let n: usize = n.trim().parse().unwrap();

    let mut mat: Vec<Vec<u64>> = f.lines()
        .take(n)
        .map(|l| l.unwrap().split(char::is_whitespace)
             .take(n)
             .map(|number| number.parse().unwrap())
             .collect())
        .collect();

    for k in 0 .. n {
        for i in 0 .. n {
            for j in 0 .. n {
                mat[i][j] = cmp::min(mat[i][j], mat[i][k] + mat[k][j]);
            }
        }
    }
    let mat = mat;

    let mut g = File::create("royfloyd.out").unwrap();

    for line in &mat {
        for element in line {
            write!(g, "{} ", element).unwrap();
        }
        g.write_all(b"\n").unwrap();
    }
}
