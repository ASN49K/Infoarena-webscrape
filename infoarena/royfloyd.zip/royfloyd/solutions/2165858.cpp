#include <cstdio>
#include <algorithm>
#define inf 999999999
using namespace std;

int n, i, j, a[102][102];

int main ()
{

    freopen("royfloyd.in", "r", stdin);
    freopen("royfloyd.out", "w", stdout);

    scanf("%d", &n);
    for (i=1; i<=n; i++)
        for (j=1; j<=n; j++){
            scanf("%d", &a[i][j]);
            if (i!=j && a[i][j]==0) a[i][j]=inf;
        }

    for (int k=1; k<=n; k++)
        for (i=1; i<=n; i++)
            for (j=1; j<=n; j++)
                a[i][j]=min(a[i][j], a[i][k]+a[k][j]);

    for (i=1; i<=n; i++){
        for (j=1; j<=n; j++)
             printf("%d ", (a[i][j]!=inf)*a[i][j]);
        printf("\n");
    }
    return 0;
}
