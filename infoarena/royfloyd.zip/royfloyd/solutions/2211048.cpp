#include <bits/stdc++.h>
using namespace std;
int const NMAX=100+10;
int const VALMAX=1e8;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");
int m[NMAX][NMAX];
int main(){
    int n, i, j, k;
    in >> n;
    for (i=1; i<=n; i++)
        for (j=1; j<=n; j++)
            in >> m[i][j];
    for (i=1; i<=n; i++)
        for (j=1; j<=n; j++)
            if (!m[i][j]) m[i][j]=VALMAX;
    for (k=1; k<=n; k++)
        for (i=1; i<=n; i++)
            for (j=1; j<=n; j++)
                if (i!=j && i!=k && j!=k) m[i][j]=min(VALMAX, min(m[i][j], m[i][k]+m[k][j]));
    for (i=1; i<=n; i++){
        for (j=1; j<=n; j++)
            out << ((m[i][j]==VALMAX) ? 0 : m[i][j]) << ' ';
        out << '\n';
    }
}
