#include <iostream>
#include <fstream>
#include <queue>
#include <vector>
#include <stdio.h>
#define NMAX 101

int M[NMAX][NMAX], nM;

void read() {
	FILE * pFile;

	pFile = fopen("royfloyd.in", "r");
	fscanf(pFile, "%d", &nM);
	for (int i = 0; i < nM; i++) {
		for (int j = 0; j < nM; j++) {
			fscanf(pFile, "%d", &M[i][j]);
		}
	}
}
void royfloyd() {
	for (int i = 0; i < nM; i++) {
		for (int j = 0; j < nM; j++) {
			for (int k = 0; k < nM; k++) {
				if (M[i][k] != 0 && M[k][j] != 0 && (M[i][k] + M[k][j] < M[i][j] || M[i][j] == 0)) {
					M[i][j] = M[i][k] + M[k][j];
				}
			}
		}
	}
}
void showSolution() {
	FILE * pFile;

	pFile = fopen("royfloyd.out", "w");
	for (int i = 0; i < nM; i++) {
		for (int j = 0; j < nM; j++) {
			fprintf(pFile, "%d ", M[i][j]);
		}
		fprintf(pFile,"\n");
	}
}
int main()
{
	read();
	royfloyd();
	showSolution();
	return 0;
}

