#include <fstream>

using namespace std;

int n,a[101][101];

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
void Citire()
{
    fin>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            fin>>a[i][j];
}

void Lungime_Drumuri()
{
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                if(a[i][k] && a[k][j] && (a[i][j]>a[i][k]+a[k][j] || !a[i][j]) && i!=j) a[i][j]=a[i][k]+a[k][j];
}

void Afisare()
{
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            fout<<a[i][j]<<' ';
        fout<<'\n';
    }
}

int main()
{
    Citire();
    Lungime_Drumuri();
    Afisare();
}
