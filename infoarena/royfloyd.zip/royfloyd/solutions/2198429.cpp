#include <fstream>
#include <vector>
#include <algorithm>
#include <iostream>
#include <queue>
#include <climits>
using namespace std;

const int kNmax = 100005;

class Task {
 public:
	void solve() {
		read_input();
    get_result();
		print_output();
	}

 private:
	int n;
	int cost[100][100];

	void read_input() {
		ifstream fin("royfloyd.in");
		fin >> n;
		for (int i = 1; i <= n; i++)
      for (int j = 1; j <=n; j++) {
        fin >> cost[i][j];
        if (i !=j && cost[i][j] == 0) {
          cost[i][j] = INT_MAX;
        }

      }
		fin.close();
	}

	void get_result() {
    for (int k = 1; k <=n; k++)
      for (int i = 1; i <=n; i++)
        for (int j = 1; j <=n; j++) {
          cost[i][j] = min(cost[i][j], cost[i][k] + cost[k][j]);
        }

	}

	void print_output() {
		ofstream fout("royfloyd.out");
    for (int i = 1; i <= n; i++) {
      for (int j = 1; j <=n; j++) {
        fout << cost[i][j] << " ";
      }
      fout<<endl;
    }
	  fout.close();
	}

};

int main() {
	Task *task = new Task();
	task->solve();
	delete task;
	return 0;
}
