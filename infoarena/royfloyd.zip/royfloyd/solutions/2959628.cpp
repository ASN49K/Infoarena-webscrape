/* Alg lui Floyd-Warshall (Roy-Floyd)
 * 
 * Transforma matricea ponderilor
 * in matricea costurilor minime ale lanturilor/drumurilor
 * 
 */ 
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

const int N = 101, Inf = 0x3f3f3f3f;
int c[N][N]; // matr. ponderilor => matr costurilor minime ale lanturilor / drumurilor
int n;

ifstream fin("floyd_warshall.in");
ofstream fout("floyd_warshall.out");


void ReadData();
void Floyd_Warshall();
void Write();

int main()
{
	ReadData();
	Floyd_Warshall();
	Write();  // matr lanturilor
	
	return 0;
}
 
void Floyd_Warshall()  // O(n^3)
{
	for (int k = 1; k <= n; ++k)
		for (int i = 1; i <= n; ++i)
			for (int j = 1; j <= n; ++j)
				if (i != j && c[i][k] + c[k][j] < c[i][j])
					c[i][j] = c[i][k] + c[k][j];
}

void ReadData()
{
	fin >> n;
	
	for (int i = 1; i <= n; ++i)
	    for (int j = 1; j <= n; ++j)
			fin >> c[i][j];
	
}

void Write()
{
	for (int i = 1; i <= n; ++i, fout << '\n')
	    for (int j = 1; j <= n; ++j)
	         fout << c[i][j] << ' ';
}
