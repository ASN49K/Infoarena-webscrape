#include <iostream>
#include <fstream>
using namespace std;
int N, a[105][105];
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");
int main()
{
///    fin>>N;
///    for(int i=1;i<=N;i++)
///    {
///        for(int j=1;j<=N;j++)
///        {
///            a[i][j]=999999999;          ///Initializam cu infinit
///        }
///    }
///    for(int i=1;i<=N;i++)
///    {
///        a[i][i]=0;
///    }

fin>>N;
    for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=N;j++)
        {
            fin>>a[i][j];
        }
    }

    for(int k=1;k<=N;k++)         /// Algoritm
        for(int i=1;i<=N;i++)
        for(int j=1;j<=N;j++)
        if(a[i][j]>a[i][k]+a[k][j] && i!=j && a[i][k]!=0 && a[k][j]!=0 )
            a[i][j]=a[i][k]+a[k][j];

    for(int i=1;i<=N;i++)
    {
        for(int j=1;j<=N;j++)
        {
            fout<<a[i][j]<<" ";
        }
        fout<<"\n";
    }
    return 0;
}
