#include <bits/stdc++.h>

using namespace std;

#define ll int
#define INF 1234567890
#define N (int)(2e2 + 5)

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int matrix[N][N];

void solve()
{
    int n;
    fin >> n;
    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= n; ++j) {
            fin >> matrix[i][j];
            if(!matrix[i][j] && i != j) matrix[i][j] = INF;
        }
    for(int k = 1; k <= n; ++k)
        for(int i = 1; i <= n; ++i)
            for(int j = 1; j <= n; ++j)
            matrix[i][j] = min(matrix[i][j], matrix[i][k] + matrix[k][j]);
    for(int i = 1; i <= n; ++i)
        for(int j = 1; j <= n; ++j)
            if(matrix[i][j] == INF) matrix[i][j] = 0;
    for(int i = 1; i <= n; ++i){
        for(int j = 1; j <= n; ++j) fout << matrix[i][j] << " ";
        fout << "\n";
    }
}
int main()
{
    ios::sync_with_stdio(false);
    fin.tie(0);
    solve();
    return 0;
}
