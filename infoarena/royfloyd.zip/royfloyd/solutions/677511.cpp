#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>

using namespace std;

#define maxN 105

int A[maxN][maxN];

int main()
{
	freopen ("royfloyd.in", "r", stdin);
	freopen ("royfloyd.out", "w", stdout);
	
	int N;
	
	scanf ("%d", &N);
	
	for (int i = 1; i <= N; ++ i)
		for (int j = 1; j <= N; ++ j) scanf ("%d", &A[i][j]);
	
	for (int k = 1; k <= N; ++ k)
		for (int i = 1; i <= N; ++ i)
			for (int j = 1; j <= N; ++ j)
			{
				if (! A[i][k] || ! A[k][j]) continue;
				
				if (! A[i][j] && i != j) A[i][j] = A[i][k] + A[k][j];
				else A[i][j] = min (A[i][j], A[i][k] + A[k][j]);
			}
	
	for (int i = 1; i <= N; ++ i)
	{
		for (int j = 1; j <= N; ++ j) printf ("%d ", A[i][j]);
		printf ("\n");
	}
	
	return 0;
}
