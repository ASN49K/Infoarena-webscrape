program royfloyd;
var a:array[1..100,1..100] of longint;
    n,i,j,k:longint;
begin

   assign(input,'royfloyd.in');
   reset(input);
   readln(n);
   for i:=1 to n do begin
     for j:=1 to n do read(a[i,j]);
     readln;
     end;
   for k:=1 to n do
     for i:=1 to n do
       for j:=1 to n do
         if a[i,j]>a[i,k]+a[k,j] then a[i,j]:=a[i,k]+a[k,j];
   for i:=1 to n do a[i,i]:=0;
   assign(output,'royfloyd.out');
   rewrite(output);
   for i:=1 to n do begin
     for j:=1 to n do write(a[i,j],' ');
     writeln;
     end;
   close(output);
end.
