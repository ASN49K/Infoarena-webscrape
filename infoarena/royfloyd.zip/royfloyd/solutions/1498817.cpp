#include <fstream>

using namespace std;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");


int a[100][100],n;


void roy_floyd()
{
    int i, j, k;
    for (k = 1; k <= n; k++)
        for (i = 1; i <= n; i++)
            for (j = 1; j <= n; j++)
                if (a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j) a[i][j] = a[i][k] + a[k][j];
}


int main()
{
    in>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
    {
        in>>a[i][j];
    }
    roy_floyd();
    for(int i=1;i<=n;i++)
        {for(int j=1;j<=n;j++)
                out<<a[i][j]<<" ";
        out<<'\n';

        }
    return 0;
}
