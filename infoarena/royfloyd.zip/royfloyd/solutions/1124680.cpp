// Roy Floyd
#include<iostream>
#include<fstream>
#include<limits>
#define DMAX 105

using namespace std;

ifstream f("data.in");
ofstream g("data.out");
int M[DMAX][DMAX];
int n;

void RoyFloyd();

int main()
{
    f>>n;

    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            f>>M[i][j];
    RoyFloyd();
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            g<<M[i][j]<<" ";
        g<<"\n";
    }
    return 0;
}
void RoyFloyd()
{
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                if((M[i][j]>M[i][k]+M[k][j] or M[i][j]==0) and i!=j and M[i][k]!=0 and M[k][j]!=0)
                    M[i][j]=M[i][k]+M[k][j];
}

