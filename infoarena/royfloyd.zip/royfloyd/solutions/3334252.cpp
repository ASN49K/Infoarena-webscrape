//
// Created by avoro on 11/3/2025.
//

#include <iostream>
#include <queue>
#include <vector>
#include <fstream>
#include<climits>
using namespace std;
// ifstream fin("dijkstra.in");
// ofstream fout("dijkstra.out");
// int main()
// {
//     int n,m,x,y,c;
//     fin >> n >> m;
//     vector<vector<pair<int,int>>> adj(n+1);
//     vector<int> dist(n+1,INT_MAX);
//     vector<int> parent(n+1,-1);
//     for (int i = 0; i< m ;i ++ ) {
//         fin >> x >> y >> c;
//         adj[x].push_back(make_pair(y,c));
//     }
//     for (int i = 1; i <= n ; i++) {
//         dist[i] = INT_MAX;
//         parent[i] = -1;
//     }
//     priority_queue<pair<int,int>, vector<pair<int,int>>, greater<pair<int,int>>> pq;
//     //distanta si nodul, nodul de start este 1 si are distanta 0
//     dist[1] = 0;
//     pq.push(make_pair(0,1));
//
//     while (!pq.empty()) {
//         pair<int,int> p = pq.top();
//         pq.pop();
//         if (p.first!= dist[p.second]) continue;
//
//         for (const auto [nod,pondere] : adj[p.second]) {
//             if (dist[p.second] + pondere < dist[nod]) {
//                 dist[nod] = dist[p.second] + pondere;
//                 parent[nod] = p.second;
//                 pq.push(make_pair(dist[nod], nod));
//             }
//         }
//     }
//     for (int  i = 2; i<=n ; i++ ) {
//         if (dist[i]!= INT_MAX) {
//             fout << dist[i] << " ";
//         }
//         else fout << 0 << " ";
//     }
// }


ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int main() {
    int n;
    fin>>n;
    vector<vector<int>> dist(n,vector<int>(n));
    for (int i =0; i< n ;i ++) {
        for (int j = 0 ; j < n ; j++) {
            fin>>dist[i][j];
            if ( i != j && dist[i][j] == 0)
                dist[i][j] = INT_MAX;
        }

    }
    for (int k = 0 ;k < n; k++) {
        for (int i =0; i < n; i++) {
            for (int j = 0 ; j < n ; j++) {
                if (dist[i][k] + dist[k][j] < dist[i][j])
                    dist[i][j] = dist[i][k] + dist[k][j];
            }
        }
    }
    for (int i =0; i < n; i++) {
        for (int j = 0 ; j < n; j++) {
            fout<<dist[i][j]<<" ";
        }
        fout<<endl;
    }
}
