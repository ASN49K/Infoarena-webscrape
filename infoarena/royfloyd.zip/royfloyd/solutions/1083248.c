# include <stdio.h>
# define NMax 101

int N,Mat[NMax][NMax];

int main()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);

    int i,j,k;

    /* Citire */
    scanf("%d",&N);
    for( i = 1 ; i <= N ; ++i )
        for( j = 1 ; j <= N ; ++j )
            scanf("%d",&Mat[i][j]);

    /* Floyd-Warshall/Roy-Floyd */
    for( k = 1 ; k <= N ; ++k )
        for( i = 1 ; i <= N ; ++i )
            for( j = 1 ; j <= N ; ++j )
                if( Mat[i][k] && Mat[k][j] && (Mat[i][j] > Mat[i][k] + Mat[k][j] || !Mat[i][j]) && i != j )
                Mat[i][j] = Mat[i][k] + Mat[k][j];

    /* Afisarea */
    for( i = 1 ; i <= N ; ++i )
    {
        for( j = 1 ; j <= N ; ++j )
                printf("%d ",Mat[i][j]);
        putchar('\n');
    }
    return 0;
}
