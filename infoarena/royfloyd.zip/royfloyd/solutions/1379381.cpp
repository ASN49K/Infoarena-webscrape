#include<fstream>
#define Nmax 110
using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int n,ante[Nmax][Nmax],d[Nmax][Nmax];

 void RoyFloyd()
{
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
            for(int j=1;j<=n;j++)
                if(i!=j && d[i][k]*d[k][j] && (!d[i][j] || d[i][k]+d[k][j]<d[i][j]))
                {
                    d[i][j]=d[i][k]+d[k][j];
                    ante[i][j]=ante[k][j];
                }
}

/*void Rebuild(int node,int S)
{
    if(node==S)
    {
        g<<S<<' ';
        return;
    }
    Rebuild(ante[S][node],S);
    g<<node<<' ';
}*/


int main()
{
    f>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++) f>>d[i][j], ante[i][j]=i;
    RoyFloyd();
    for(int i=1;i<=n;i++,g<<'\n')
        for(int j=1;j<=n;j++) g<<d[i][j]<<' ';
    f.close();g.close();
    return 0;
}
