#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;
#define nMax 101
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int Cost[nMax][nMax];

void RoyFloyd(int N) {
	int k, i, j;
	for (k = 1; k <= N; k++)
		for (i = 1; i <= N; i++)
			for (j = 1; j <= N; j++)
				if (k != i && k != j && i != j) Cost[i][j] = min(Cost[i][j], Cost[i][k] + Cost[k][j]);
}

int main()
{
	int N, i, j;
	fin >> N;
	for (i = 1; i <= N; i++)
		for (j = 1; j <= N; j++)
			fin >> Cost[i][j];
	RoyFloyd(N);
	for (i = 1; i <= N; i++) {
		for (j = 1; j <= N; j++)
			fout << Cost[i][j] << ' ';
		fout << '\n';
	}
}

