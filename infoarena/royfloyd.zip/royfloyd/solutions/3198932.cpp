#include <iostream>
#include <fstream>

using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

const int NMAX=101,INF=1000000;
int n,a[NMAX][NMAX];

void read()
{
    f >> n;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            f >> a[i][j];
            if(a[i][j]==0 && i!=j)
            {
                a[i][j]=INF;
            }
        }
    }
}

int main()
{
    read();
    for(int k=1;k<=n;k++)
    {
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                int dr_nou=a[i][k]+a[k][j];
                if(dr_nou<a[i][j] && i!=k && j!=k && i!=j && a[i][k]!=0 && a[k][j]!=0)
                {
                    a[i][j]=dr_nou;
                }
            }
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            g << a[i][j] << " ";
        }
        g << "\n";
    }
    return 0;
}
