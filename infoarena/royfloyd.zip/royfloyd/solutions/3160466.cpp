#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

//ifstream fin("./date.txt");
ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int d[101][101];

int main()
{
	int n;
	fin >> n;
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n; ++j)
		{
			fin >> d[i][j];
		}
	}
	for (int k = 0; k < n; ++k)
	{
		for (int i = 0; i < n; ++i)
		{
			for (int j = 0; j < n; ++j)
			{
				d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
			}
		}
	}
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < n; ++j)
		{
			fout << d[i][j] << " ";
		}
		fout << '\n';
	}
}
