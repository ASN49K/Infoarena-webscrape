#include <iostream>
#include <fstream>

using namespace std;
#define NMAX 105
#define inf 10005
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int m[NMAX][NMAX],n;

void citire()
{
    f>>n;
    for(int i = 1; i <= n; i ++)
        for(int j = 1; j <= n; j++)
            m[i][j] = inf;
    for(int i = 1; i <= n; i ++)
        for(int j = 1; j <= n; j++)
            f>>m[i][j];
    for(int i = 1; i <= n; i ++)
        m[i][i] = 0;


}

void RoyFloyd()
{
    for(int k = 1; k <= n; k ++)
        for(int i = 1; i <= n; i ++)
            for(int j = 1; j <= n; j++)
                if(m[i][k] + m[k][j] < m[i][j])
                    m[i][j] = m[i][k] +m[k][j];


}
void afisare()
{
    for(int i = 1; i <= n; i ++)
    {
        for(int j = 1; j <= n; j++)
            if(m[i][j] == inf)
                g<<'0'<<' ';
            else
            g<<m[i][j]<<' ';
        g<<'\n';

    }
}
int main()
{
    citire();
    RoyFloyd();
    afisare();
    return 0;
}
