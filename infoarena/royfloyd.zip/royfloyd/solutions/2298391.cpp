#include <fstream>

using namespace std;
ifstream cin("royfloyd.in");
ofstream cout("royfloyd.out");

int a[105][105],tata[105][105];
int i,j,k,n;
int main()
{
    cin>>n;
    for(i=1;i<=n;++i)
        for(j=1;j<=n;++j)
            {
                cin>>a[i][j];
                if(a[i][j] == 0)
                    a[i][j] = 2000000000;
            }

    for(k=1;k<=n;++k)
        for(i=1;i<=n;++i)
            for(j=1;j<=n;++j)
        if(i!=j && a[i][k] + a[k][j] <= a[i][j])
        {
            a[i][j] = a[i][k] + a[k][j];
            tata[i][j] = tata[k][j];
        }

    for(i=1;i<=n;++i,cout<<"\n")
        for(j=1;j<=n;++j)
            if(a[i][j] == 2000000000) cout<<"0 ";
            else cout<<a[i][j]<<" ";
    return 0;
}
