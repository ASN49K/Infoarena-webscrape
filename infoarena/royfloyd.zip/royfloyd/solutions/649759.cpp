#include <cstdio>

using namespace std;

int a[105][105],n;

void read()
{
    scanf("%d",&n);
    for (int i=1;i<=n;i++)
        for (int j=1;j<=n;j++)
            scanf("%d",&a[i][j]);
}

void royfloyd()
{
    for (int k=1;k<=n;k++)
        for (int i=1;i<=n;i++)
            for (int j=1;j<=n;j++)
                if (i!=j)
                    if ((a[i][j]>a[i][k]+a[k][j] || !a[i][j])&& a[i][k] && a[k][j])
                        a[i][j]=a[i][k]+a[k][j];
}

void print()
{
    for (int i=1;i<=n;i++)
    {
        for (int j=1;j<=n;j++)
            printf("%d ",a[i][j]);
        printf("\n");
    }

}

int main()
{
    freopen("royfloyd.in","r",stdin);
    freopen("royfloyd.out","w",stdout);
    read();
    royfloyd();
    print();
    return 0;
}
