#include <cstdio>

#define MAXN 101

int n;
int g[ MAXN ][ MAXN ];

void read()
{
	freopen("royfloyd.in", "r", stdin);
	freopen("royfloyd.out", "w", stdout);
	
	scanf("%d ", &n);
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= n; ++j)
			scanf("%d", &g[ i ][ j ]);
}

void solve()
{
	for(int k = 1; k <= n; ++k)
		for(int i = 1; i <= n; ++i)
			for(int j = 1; j <= n; ++j)
			{
				if( i != j && g[ i ][ k ] && g[ k ][ j ]
				&& ( g[ i ][ k ] + g[ k ][ j ] < g[ i ][ j ] || g[ i ][ j ] == 0))
					g[ i ][ j ] = g[ i ][ k ] + g[ k ][ j ];
			}
}

void printResult()
{
	for(int i = 1; i <= n; ++i)
	{
		for(int j = 1; j <= n; ++j)
			printf("%d ", g[ i ][ j ]);
		printf("\n");
	}
}

int main()
{
	read();
	solve();	
	printResult();
	return 0;
}
