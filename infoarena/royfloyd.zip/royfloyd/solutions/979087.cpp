#include <iostream>
#include <fstream>
using namespace std;
int i,j,k,n,m[105][105];
int main(void)
{
    FILE * f;
    f=fopen("royfloyd.in","r");
    ofstream g("royfloyd.out");
    fscanf(f,"%d",&n);
    for (i=1;i<=n;i++)
        for (j=1;j<=n;j++)
            fscanf(f,"%d",&m[i][j]);
    for (k=1;k<=n;k++)
        for (i=1;i<=n;i++)
            for (j=1;j<=n;j++)
                if (m[i][k]+m[k][j]<m[i][j])
                    m[i][j]=m[i][k]+m[k][j];
    for (i=1;i<=n;i++)
    {
        for (j=1;j<=n;j++)
            g<<m[i][j]<<' ';
        g<<'\n';
    }
    g.close();
    return 0;
}
