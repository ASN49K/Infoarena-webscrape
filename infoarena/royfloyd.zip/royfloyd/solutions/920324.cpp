#include<cstdio>

#define MAX_SIZE 105

FILE *f=fopen("royfloyd.in","r");
FILE *g=fopen("royfloyd.out","w");

using namespace std;

int cost[MAX_SIZE][MAX_SIZE];
int n;

void read ( void )
{
    fscanf(f,"%d",&n);
    for(int i(1); i <= n; ++i )
        for(int ii(1) ;  ii <= n ; ++ii )
        fscanf(f,"%d",&cost[i][ii]);
    fclose(f);
}
void solve(  void  )
{
    for(int node=1; node <= n ; ++node )
        for(int i(1) ; i <= n ; ++i )
        for(int j(1); j <= n ; ++j)
        if(cost[i][j] && cost[i][node] && cost[node][j] && ( cost[i][j] > (cost[i][node]+ cost[node][j] )))
        cost[i][j]=cost[i][node]+cost[node][j];

}
void write ( void )
{
    for(int i(1); i <= n ; ++i )
    {


        for(int ii(1); ii <= n ;++ii)
        fprintf(g,"%d ",cost[i][ii]);
        fprintf(g,"\n");
    }
    fclose(g);
}

int main ( void )
{
    read();
    solve();
    write();
    return 0;
}
