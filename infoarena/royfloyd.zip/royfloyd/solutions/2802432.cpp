#include <fstream>
#define nmax 105
using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int a[nmax][nmax],n;

void read()
{
    fin>>n;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
        {
            fin>>a[i][j];
        }
}

void RF()
{
    for(int k=1;k<=n;k++)
        for(int i=1;i<=n;i++)
                for(int j=1;j<=n;j++)
                        a[i][j]=min(a[i][j],a[i][k]+a[k][j]);
}

void print()
{
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
            fout<<a[i][j]<<" ";
        fout<<"\n";
    }
}

int main()
{
    read();
    RF();
    print();
    return 0;
}
