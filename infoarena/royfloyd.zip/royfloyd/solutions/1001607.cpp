using namespace std;
#include<fstream>
#define oo 0x3f3f3f3f
ifstream eu("royfloyd.in");
ofstream tu("royfloyd.out");
#define Nmax 105
int N,A[Nmax][Nmax];
void read()
{
	eu>>N;
	for(int i=1;i<=N;i++)
		for(int j=1;j<=N;j++)
		{
			eu>>A[i][j];
			if(A[i][j]==0)
				A[i][j]=oo;
		}
}
void Roy_Floyd()
{
	for(int k=1;k<=N;k++)
		for(int i=1;i<=N;i++)
			for(int j=1;j<=N;j++)
				A[i][j]=min(A[i][j],A[i][k]+A[k][j]);
}
int main()
{
	read();
	Roy_Floyd();
	for(int i=1;i<=N;i++)
	{
		for(int j=1;j<=N;j++)
		{
			if(i==j||A[i][j]==oo)
				A[i][j]=0;
			tu<<A[i][j]<<" ";
		}
		tu<<"\n";
	}
	return 0;
}
