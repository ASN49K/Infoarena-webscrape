#include<fstream>
using namespace std;
#define NMAX 110

int n;
int a[NMAX][NMAX];

void read()
{
	int i,j;

	ifstream fin("royfloyd.in");

	fin>>n;
	for (i=1; i<=n; ++i)
		for (j=1; j<=n; ++j)
			fin>>a[i][j];

	fin.close();
}

void solve()
{
	int i,j,k;

	for (i=1; i<=n; ++i)
		for (j=1; j<=n; ++j)
			if (i != j)
				for (k=1; k<=n; ++k)
					if (i != k && j != k && a[i][k] != 0 && a[k][j] != 0)
						if (a[i][j] > a[i][k] + a[k][j] || a[i][j] == 0)
							a[i][j] = a[i][k] + a[k][j];
}

void write()
{
	int i,j;

	ofstream fout("royfloyd.out");

	for (i=1; i<=n; ++i)
	{
		for (j=1; j<=n; ++j)
			fout<<a[i][j]<<" ";
		fout<<'\n';
	}

	fout.close();
}

int main()
{
	read();
	solve();
	write();

	return 0;
}
