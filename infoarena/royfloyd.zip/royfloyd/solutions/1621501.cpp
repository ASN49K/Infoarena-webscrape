#include <iostream>
#include <fstream>

using namespace std;

ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int pred[101][101],d[101][101];

void drum(int x,int y)
{
    if(x!=y)
        drum(x,pred[x][y]);
    out<<y<<" ";
    return;
}

int main()
{
    int n,i,j,k;
    in>>n;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            in>>d[i][j];
            if(d[i][j]==0&&i!=j)
                d[i][j]=2000;
        }
    }
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
            {
                if(d[i][k]+d[k][j]<d[i][j])
                    d[i][j]=d[i][k]+d[k][j];
                    pred[i][j]=pred[k][j];
            }
        }
    }
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
            out<<d[k][i]<<" ";
        }
        out<<'\n';
    }
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
            //drum(i,j);
        }
        out<<'\n';
    }
    return 0;
}
