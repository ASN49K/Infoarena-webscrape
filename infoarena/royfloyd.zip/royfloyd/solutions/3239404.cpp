#include <bits/stdc++.h>
using namespace std;

const int MAX = 105;
int dist[MAX][MAX];

int main()
{
    ifstream cin("royfloyd.in");
    ofstream cout("royfloyd.out");
    int n;
    cin >> n;

    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j)
            dist[i][j] = INT_MAX;

    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j)
        {
            cin >> dist[i][j];

            if (i == j)
                dist[i][j] = 0;
        }

    for (int k = 1; k <= n; ++k)
        for (int i = 1; i <= n; ++i)
            for (int j = 1; j <= n; ++j)
                dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);

    for (int i = 1; i <= n; ++i)
    {
        for (int j = 1; j <= n; ++j)
            cout << dist[i][j] << " ";
        cout << "\n";
    }

    return 0;
}
