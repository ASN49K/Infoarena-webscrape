#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
using namespace std;
ifstream fin("royfloyd.in");
ofstream gout("royfloyd.out");
int dist[100][100],n;
void citire()
{
    fin>>n;
    int i,j;
    for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
        fin>>dist[i][j];
}
void floyd(void)
{
    int k,i,j;


    for(k=1; k<=n; k++)
        for(i=1; i<=n; i++)
            for(j=1; j<=n; j++)
                if( dist[i][k]!=0 && dist[k][j]!=0 &&i!=j &&((dist[i][k]+dist[k][j]<dist[i][j] ) || dist[i][j]==0))
                    dist[i][j]=dist[i][k]+dist[k][j];



}
void afisare()
{
    int i,j;
    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++)
        {
            gout<<dist[i][j];
            gout<<' ';
        }
        gout<<endl;
    }


}
int main()
{
    citire();
    floyd();
    afisare();
    return 0;



}
