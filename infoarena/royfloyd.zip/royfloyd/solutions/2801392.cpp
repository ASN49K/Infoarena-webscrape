#include <bits/stdc++.h>

using namespace std;

long long int d[257][257];

int main()
{
    ifstream cin("royfloyd.in");
    ofstream cout("royfloyd.out");
    int n, i, j, k;
    cin >> n;
    for (i = 0; i < n; i++)
        for (j = 0; j < n; j++)
        {
            cin >> d[i][j];
        }
    for (k = 0; k < n; k++)
    {
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < n; j++)
            {
                if (d[i][j] > d[i][k] + d[k][j] && d[i][k] > 0 && d[k][j] > 0)
                    d[i][j] = d[i][k] + d[k][j];
            }
        }
    }
    for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            cout << d[i][j] << " ";
        }
        cout << '\n';
    }
    /*for (i = 0; i < n; i++)
    {
        for (j = 0; j < n; j++)
        {
            cout << dist[i][j] << " ";
        }
        cout << '\n';
    }*/
    return 0;
}