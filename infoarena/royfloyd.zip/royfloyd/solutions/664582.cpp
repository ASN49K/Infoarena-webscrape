#include <fstream>
using namespace std;

int n,cost[101][101];
int main()
{
	ifstream fin("royfloyd.in");
	ofstream fout("royfloyd.out");
	
	fin>>n;
	
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=n;++j)
		{
			fin>>cost[i][j];
		}
	}
	
	for(int k=1;k<=n;++k)
	{
		for(int i=1;i<=n;++i)
		{
			for(int j=1;j<=n;++j)
			{
				if(cost[i][k] && cost[k][j] && i!=j)
				{
					if(cost[i][k]+cost[k][j]<=cost[i][j] || cost[i][j]==0)
					{
						cost[i][j]=cost[i][k]+cost[k][j];
					}
				}
			}
		}
	}
	
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=n;++j)
		{
			fout<<cost[i][j]<<' ';
		}
		fout<<'\n';
	}
	
	fout.close();
	return 0;
}