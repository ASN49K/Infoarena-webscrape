#include <iostream>
#include <fstream>
#include <limits.h>
#define inf 105
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");
int d[inf][inf], n;
int main()
{
    int i,j,k;
    f>>n;
    for(i=1; i<=n; i++)
    for(j=1; j<=n; j++)
        {f>>d[i][j];
        if(d[i][j]==0)
            d[i][j]=INT_MAX;
        if(i==j)
            d[i][j]=0;
        }

    for(k=1; k<=n; k++)
      for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
            if(i!=j && d[k][j]+d[i][k]<d[i][j])
            d[i][j]=d[k][j]+d[i][k];

    for(i=1; i<=n; i++)
    {for(j=1; j<=n; j++)
       if(d[i][j]==INT_MAX)
        g<<0<<" ";
       else
        g<<d[i][j]<<" ";
    g<<endl;}

    f.close();
    g.close();
    return 0;
}
