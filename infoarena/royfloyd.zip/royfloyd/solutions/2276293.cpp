#include <iostream>
#include <fstream>
using namespace std;
ifstream scan("royfloyd.in");
ofstream print("royfloyd.out");
int n ,ad[105][105] ;
int main()
{
  scan >> n;
  for(int i = 1 ; i <= n ; ++i)
   for(int j = 1 ; j <= n ; ++j)
    scan >> ad[i][j];
  for(int k = 1 ; k <= n ; k++)
   for(int i = 1 ; i <= n ; i++)
    for(int j = 1 ; j <= n ; j++)
     if(ad[i][k] && ad[k][j] && i!=j)
      { if(ad[i][j] == 0)
        ad[i][j] = ad[i][k] + ad[k][j];
        else
        ad[i][j] = min(ad[i][j],ad[i][k] + ad[k][j]);
      }
  for(int i = 1 ; i <= n ; i ++ ){
    for(int j = 1  ; j <= n  ; j ++ )
     print << ad[i][j] << " ";
     print << "\n";
  }
    return 0;
}
