using namespace std;
#include <fstream>
//FILE *f=fopen ("euclid3.in","r");
ifstream f ("royfloyd.in");
ofstream g ("royfloyd.out");


int main ()
{
    int n,i,j,z,c[101][101];

    f>>n;

    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++) f>>c[i][j];
    }

    for(z=1; z<=n; z++)
    {
        for(i=1; i<=n; i++)
        {
            for(j=1; j<=n; j++)
            {
                if(c[i][z]!=0 && c[z][j]!=0)
                {
                    if(c[i][z]+c[z][j]<c[i][j] || c[i][j]==0)
                    c[i][j]=c[i][z]+c[z][j];
                }
            }
        }
    }

    for(i=1; i<=n; i++)
    {
        for(j=1; j<=n; j++)
        {
            if(i==j) g<<0<<' ';
            else g<<c[i][j]<<' ';
        }
        g<<'\n';
    }


    return 0;
}
