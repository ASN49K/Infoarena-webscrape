#include <fstream>
#define INFIN 1e9
#define F(i,a,b) for (int i = a; i <= b; i++)
using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n;
int a[101][101];

void citire(){
    fin >> n;
    F(i,1,n){
        F(j,1,n){
            fin>>a[i][j];
        }
    }
}
void afis(){
    F(i,1,n){
        F(j,1,n){
            fout<<a[i][j]<<" ";
        }
        fout<<'\n';
    }
}

void rw()
{   int i, j, k;
    for(k=1;k<=n;k++)
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++)
                if(a[i][j] > a[i][k] + a[k][j])
                    a[i][j] = a[i][k] + a[k][j];
}


int main()
{
    citire();
    F(i,1,n){
        F(j,1,n){
            if(a[i][j]==0 && j!=i)
                a[i][j]=INFIN;
        }
    }
    rw();
    afis();
    return 0;
}


