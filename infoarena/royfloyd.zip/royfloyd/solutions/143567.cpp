#include <stdio.h>
#define DIM 130
int n,i,j,k;
int a[DIM][DIM];

int main(){
  FILE *f = fopen("royfloyd.in","r");
  fscanf(f,"%d",&n);
  for (i=1;i<=n;i++)
    for (j=1;j<=n;j++)
      fscanf(f,"%d",&a[i][j]);
  fclose(f);


  for (k=1;k<=n;k++)
    for (i=1;i<=n;i++)
      if (a[i][k]!=0)
	for (j=1;j<=n;j++)
	  if ((a[k][j]!=0) && ((a[i][j]>a[i][j]+a[k][j]) || (a[i][j]==0)))
	    a[i][j]=a[i][k]+a[k][j];
  FILE *g = fopen("royfloyd.out","w");
  for (i=1;i<=n;i++) {
    for (j=1;j<=n;j++)
      fprintf(g,"%d ",a[i][j]);
    fprintf(g,"\n");
  }
  fclose(g);
  return 0;
}