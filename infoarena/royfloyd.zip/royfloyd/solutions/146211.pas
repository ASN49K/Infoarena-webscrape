program floyd_warshall;
var a:array[1..100,1..100]of longint;
    n,i,j,k:integer;
    g:text;
procedure citire;
var f:text;
begin assign(f,'royfloyd.in'); reset(f);
read(f,n);
for i:=1 to n do
 for j:=1 to n do
  if i=j then a[i,j]:=0 else a[i,j]:=maxint;
for i:=1 to n do
 for j:=1 to n do
  read(f,a[i,j]);
close(f);
end;
begin {pp}
citire;
for k:=1 to n do
 for i:=1 to n do
  for j:=1 to n do
   if a[i,j]>a[i,k]+a[k,j] then a[i,j]:=a[i,k]+a[k,j];
assign(g,'royfloyd.out'); rewrite(g);
for i:=1 to n do
  begin
  for j:=1 to n do if a[i,j]<maxint then write(g,a[i,j],' ')
                                    else write(g,0,' ');
  writeln(g);
  end;
close(g);
end.