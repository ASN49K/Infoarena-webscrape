#include<fstream>
#define inf 500000
using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n;
int a[105][105];

int main(){
	
	fin>>n;
	
	for(int i=1; i<=n; ++i){
		for(int j=1; j<=n; ++j){
			fin>>a[i][j]; if(a[i][j]==0 && i!=j) a[i][j]=inf;
		}	
	}
	
	for(int k=1; k<=n; ++k){
		for(int i=1; i<=n; ++i){
			for(int j=1; j<=n; ++j){
				if(a[i][j]>a[i][k]+a[k][j]) a[i][j] = a[i][k] + a[k][j];
			}
		}
	}
	
	for(int i=1; i<=n; ++i){
		for(int j=1; j<=n; ++j){
			if(a[i][j]==inf) fout<<0<<' ';		
			else fout<<a[i][j]<<' ';
		}
		fout<<'\n';
	}
	
	
	
	
	
	
	return 0;
}
