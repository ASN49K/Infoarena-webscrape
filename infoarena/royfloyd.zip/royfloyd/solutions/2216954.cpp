//#include <iostream>
#include <fstream>
using namespace std;
int v[105][105];
int main()
{
    ifstream cin("royfloyd.in");
    ofstream cout("royfloyd.out");
    int n,cost;
    cin>>n;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            cin>>cost;
            if(cost==0){
                if(i!=j)
                    v[i][j]=1<<31-1;
            }
            else
                v[i][j]=cost;
        }
    }
    for(int k=1;k<=n;k++){
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                if(v[i][j]>v[i][k]+v[k][j]){
                    v[i][j]=v[i][k]+v[k][j];
                }
            }
        }
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            cout<<v[i][j]<<" ";
        }
        cout<<"\n";
    }
    return 0;
}
