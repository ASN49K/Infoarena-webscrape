#include <fstream>

using namespace std;

ifstream cin ("royfloyd.in");
ofstream cout ("royfloyd.out");

const int INF = 1e9;

const int N = 100;
int dp[N + 1][N + 1];

int n;

void roy_floyd ()
{
    for (int pivot = 1; pivot <= n; ++pivot)
        for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j)
            dp[i][j] = min (dp[i][j], dp[i][pivot] + dp[pivot][j]);
}

int main()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j)
        cin >> dp[i][j];
    roy_floyd();
    for (int i = 1; i <= n; ++i, cout << '\n')
        for (int j = 1; j <= n; ++j)
        cout << dp[i][j] << ' ';
    return 0;
}
