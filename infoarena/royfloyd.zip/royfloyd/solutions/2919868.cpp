#include <fstream>

const int MAX_N = 105;
int dp[MAX_N][MAX_N];

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int main() {
    
    int n, i, j, k;
    fin >> n;
    for ( i = 0; i < n; i++ ) {
        for (j = 0; j < n; j++ ) {
            fin >> dp[i][j];
        }
    }
    for( k = 0; k < n; k++ ) {
        for( i = 0; i < n; i++ ){
            for( j = 0; j < n; j++ ){
                if ( dp[i][k] && dp[k][j] && (dp[i][k] + dp[k][j] < dp[i][j] || !dp[i][j]) && i != j )
                    dp[i][j] = dp[i][k] + dp[k][j];
            }
        }
    }
    for( i = 0; i < n; i++ ){
        for( j = 0; j < n; j++ )
            fout << dp[i][j] << ' ';
        fout << '\n';
    }
    
    return 0;
}
