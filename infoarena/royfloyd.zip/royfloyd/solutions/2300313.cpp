#include <bits/stdc++.h>
#define Nmax 105
#define INF 1e9
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int n, w[Nmax][Nmax], dist[Nmax][Nmax];

void read()
{
    f >> n;
    for (int i = 1; i <= n; ++i)
        for (int j = 1; j <= n; ++j) {
            f >> w[i][j];
            if (w[i][j])
                dist[i][j] = w[i][j];
        }
}

void royfloyd()
{
    for (int k = 1; k <= n; ++k)
    for (int i = 1; i <= n; ++i)
    for (int j = 1; j <= n; ++j)
        if (dist[i][j] > dist[i][k] + dist[k][j])
            dist[i][j] = dist[i][k] + dist[k][j];
}

void show()
{
    for (int i = 1; i <= n; ++i) {
    for (int j = 1; j <= n; ++j)
        g << dist[i][j] << " ";
    g << "\n";
    }
}

int main()
{
    read();
    royfloyd();
    show();
    return 0;
}
