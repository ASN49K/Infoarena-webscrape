#include <bits/stdc++.h>

using namespace std;

ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

const int N = 101;
int n, mat[N][N]; // mat[i][j] = cost minim de la i la j

int main(){
    f >> n;
    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++){
            f >> mat[i][j];
        }
    }

    f.close();
    for(int k = 1; k <= n; k++){
        for(int i = 1; i <= n; i++){
            for(int j = 1; j <= n; j++){
                if(i == k || j == k || i == j)
                    continue;

                if(mat[i][k] && mat[k][j] && (mat[i][k] + mat[k][j] < mat[i][j] || mat[i][j] == 0))
                    mat[i][j] = mat[i][k] + mat[k][j];
            }
        }
    }

    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++)
            g << mat[i][j] << ' ';

        g << '\n';
    }

    g.close();
}
