
//roy floyd

#include <bits/stdc++.h>
using namespace std;

int dist[101][101];

int main() {
    int n;
    cin>>n;

    for (int i=1;i<=n;i++)
        for (int j=1;j<=n;j++) {
            cin>>dist[i][j];
        }

    for (int k=1;k<=n;k++)
        for (int i=1;i<=n;i++)
            for (int j=1;j<=n;j++)
                if (dist[i][k]!=0 && dist[k][j]!=0 && (dist[i][j]>dist[i][k]+dist[k][j]))
                    dist[i][j]=dist[i][k]+dist[k][j];

    for (int i=1;i<=n;i++) {
        for (int j=1;j<=n;j++) {
            cout<<dist[i][j]<<' ';
        }
        cout<<'\n';
    }
}