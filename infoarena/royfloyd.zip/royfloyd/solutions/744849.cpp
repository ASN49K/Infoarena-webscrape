#include <fstream>
using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int a[101][101], n;

void Citire();
void RF();

int main()
{
	Citire();
	RF();
}

void Citire()
{
	fin >> n;
	
	for ( int i = 1; i <= n; ++i )
	{
		for ( int j = 1; j <= n; ++j )
		{
			fin >> a[i][j];
		}
	}
}

void RF()
{
	for ( int i = 1; i <= n; ++i )
	{
		for ( int j = 1; j <= n; ++j )
		{
			for ( int k = 1; k <= n; ++k )
			{
				if ( a[i][j] > a[i][k] + a[k][j] )
				{
					a[i][j] = a[i][k] + a[k][j];
				}
			}
		}
	}
}
