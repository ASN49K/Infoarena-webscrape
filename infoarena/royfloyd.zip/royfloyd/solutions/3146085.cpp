#include <bits/stdc++.h>

using namespace std;
ifstream f ("royfloyd.in");
ofstream g ("royfloyd.out");
int n,mat[105][105];

int main()
{
    f>>n;
    for(int i=1; i<=n; i++)
        for(int j=1; j<=n; j++)
            f>>mat[i][j];
    for(int k=1; k<=n; k++)
        for(int i=1; i<=n; i++)
            for(int j=1; j<=n; j++)
                if(i!=j)
                    if( mat[k][j] && mat[i][k] && (mat[i][j]>mat[k][j]+mat[i][k] && !mat[i][j]))
                        mat[i][j]=mat[k][j]+mat[i][k];
    for(int i=1; i<=n; i++,g<<'\n')
        for(int j=1; j<=n; j++)
            g<<mat[i][j]<<' ';
    return 0;
}
