#include <bits/stdc++.h>
#define MAXN 102
using namespace std;
ifstream in("royfloyd.in");
ofstream out("royfloyd.out");

int G[MAXN][MAXN],n,dist[MAXN][MAXN];
void royfloyd()
{
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
            if(G[i][j]&& i!=j)dist[i][j]=G[i][j];
    for(int k=1;k<=n;++k)
        for(int i=1;i<=n;++i)
            for(int j=1;j<=n;++j)
                if(i!=j && dist[i][k] && dist[k][j] && (dist[i][j] > dist[i][k]+dist[k][j] || !dist[i][j] ))
                    dist[i][j]=dist[i][k]+dist[k][j];
}
int main()
{
    in>>n;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
                in>>G[i][j];
    royfloyd();
    for(int i=1;i<=n;++i){
        for(int j=1;j<=n;++j)
            out<<dist[i][j]<<' ';
        out<<'\n';
    }
    return 0;
}
