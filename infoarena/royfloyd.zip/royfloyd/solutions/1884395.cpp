#include <iostream>
#include <fstream>

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

const int MaxN=105;

int n, rf[MaxN][MaxN];

int main()
{
    fin>>n;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
            fin>>rf[i][j];

    for(int k=1;k<=n;++k)
        for(int i=1;i<=n;++i)
        for(int j=1;j<=n;++j)
        if( rf[i][k] && rf[k][j] && i!=j && (rf[i][j]>rf[i][k]+rf[k][j] || !rf[i][j]))
        rf[i][j]=rf[i][k]+rf[k][j];


    for(int i=1;i<=n;++i)
        {for(int j=1;j<=n;++j)
    fout<<rf[i][j]<<' ';
    fout<<'\n';}


    return 0;
}
