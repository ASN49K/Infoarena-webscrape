#include<stdio.h>
#define min(a,b) ((a)<(b)?(a):(b))
#define Inf 1000099
FILE*f=fopen("royfloyd.in","r");
FILE*g=fopen("royfloyd.out","w");
int n,d[104][104];
void read()
 {
 fscanf(f,"%d",&n);
 int i,j;
 for(i=1;i<=n;++i)
  for(j=1;j<=n;++j)
   {
   fscanf(f,"%d",&d[i][j]);
   if(d[i][j]==0) d[i][j]=Inf;
   }
 }
void RoyFloyd()
 {
 int i,j,x,y,z;
 for(z=1;z<=n;++z)
  for(x=1;x<=n;++x)
   for(y=1;y<=n;++y)
    d[x][y]=min(d[x][y],d[x][z]+d[z][y]);
 for(i=1;i<=n;++i)
  {
  for(j=1;j<=n;++j)
    {
    if(d[i][j]==Inf || i==j) d[i][j]=0;
    fprintf(g,"%d ",d[i][j]);
    }
  fprintf(g,"\n");
  }
 }
int main()
 {
  read();
  RoyFloyd();
  return 0;
  }

