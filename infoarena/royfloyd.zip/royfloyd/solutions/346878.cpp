#include <fstream>
#define NMAX 110
using namespace std;
ifstream f("royfloyd.in");
ofstream g("royfloyd.out");

int a[NMAX][NMAX],n;

void citire ()
{
  f>>n;
  for (int i=1; i<=n; i++)
	for (int j=1; j<=n; j++)
	  f>>a[i][j];
}


void RF ()
{
  for (int k=1; k<=n; k++)
	for (int i=1; i<=n; i++)
	  for (int j=1; j<=n; j++)
		 if (i!=j!=k) a[i][j]=min(a[i][k]+a[k][j],a[i][j]);
}

void afisare ()
{
  for (int i=1; i<=n; i++)
  {
	for (int j=1; j<=n; j++)
	  g<<a[i][j]<<" ";
	g<<'\n';
  }
}

int main ()
{
  citire ();
  RF ();
  afisare ();
  return 0;
}
