#include <cstdio>

int min(int a, int b)
{
	if (a>b) a=b;
	return a;
}

int n, v[110][110];

int main()
{
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	scanf("%d",&n);
	int i, j, k;
	for (i=1; i<=n; i++)
		for (j=1; j<=n; j++) scanf("%d",&v[i][j]);
	for (k=1; k<=n; k++)
		for (i=1; i<=n; i++)
			for (j=1; j<=n; j++)
				if (i!=j && v[i][k] && v[k][j])
					v[i][j]=min(v[i][j],v[i][k]+v[k][j]);
	for (i=1; i<=n; i++)
	{
		for (j=1; j<=n; j++) printf("%d ",v[i][j]);
		printf("\n");
	}
}