//https://infoarena.ro/problema/royfloyd#comentarii

#include <iostream>
#include <fstream>

using namespace std;


void floyd_warshall(int matrice[][100], int n)
{
  //i = rand, j = coloana, k = iterator

  for(int k=0; k<n; k++)
  {
    for(int i=0; i<n; i++)
    {
      for(int j=0; j<n; j++)
      {
        if(matrice[i][j] > matrice[i][k] + matrice[k][j])
        {
          matrice[i][j] = matrice[i][k] + matrice[k][j];
        }
      }
    }
  }
}


int main()
{
  int n;
  int matrice[100][100];

  ifstream infile;
  ofstream outfile;

  infile.open("royfloyd.in");
  outfile.open("royfloyd.in");

  infile >> n;

  for(int i=0; i<n; i++)
  {
    for(int j=0; j<n; j++)
    {
      infile >> matrice[i][j];
    }
  }

  floyd_warshall(matrice, n);

  for(int i=0; i<n; i++)
  {
    for(int j=0; j<n; j++)
    {
      outfile << matrice[i][j] << " ";
    }
    outfile << endl;
  }

  infile.close();
  outfile.close();
  return(0);
}
