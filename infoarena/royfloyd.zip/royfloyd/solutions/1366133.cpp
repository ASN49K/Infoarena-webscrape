#include <iostream>
#include <fstream>
#include <cstdlib>
#include <climits>

#define min(a,b) (a<b)?a:b
#define max(a,b) (a>b)?a:b

using namespace std;

ifstream fin("royfloyd.in");
ofstream fout("royfloyd.out");

int n, **mat, maxPond;

void read_a_line(int *v) {
    for(int i = 0; i < n; i++)
       {
           fin>>v[i];
           maxPond = max(maxPond, v[i]);
       }
}

void print_array(int **a) {
    for(int i = 0; i <n ; i++)
    {
        for(int j= 0; j < n; j++)
            fout<<a[i][j]<<' ';
        fout<<endl;
    }
}

inline void royfloyd() {
    //d(-1) -> inainte de cautari de cai intermediare
    int **d0 = new int*[n];
    int **d;
    for(int i = 0; i < n; i++) {
        d0[i] = new int[n];
        for(int j = 0; j < n;j++)
           {
               d0[i][j] = mat[i][j];
               if(!d0[i][j]) d0[i][j] = maxPond;
           }
    }

    for(int k = 0; k < n; k++) {
        d = new int*[n];
        for(int i = 0; i < n; i++){
            d[i] = new int[n];
            for(int j = 0; j < n; j++){
                d[i][j] = min(d0[i][j], d0[i][k] + d0[k][j]);
            }
        }
        for(int i = 0; i < n; i++)
            free(d0[i]);
        free(d0);
        d0 = d;
    }
    print_array(d);
}

int main()
{
    fin >> n;
    mat = new int*[n];
    for(int i = 0; i < n;i++){
        mat[i] = new int[n];
        read_a_line(mat[i]);
    }
   royfloyd();
   return 0;
}
