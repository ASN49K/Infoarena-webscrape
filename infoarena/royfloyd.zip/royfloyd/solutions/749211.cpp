#include<stdio.h>
int main(){
    freopen ("royfloyd.in", "r", stdin);
    freopen ("royfloyd.out", "w", stdout);

    int n, mat[101][101], i, j, k;

    scanf("%d ", &n);
    for(i=1; i<=n; i++)
        for(j=1; j<=n; j++)
            scanf("%d ", &mat[i][j]);

    for(k=1; k<=n; k++)
        for(i=1; i<=n; i++)
            for(j=1; j<=n; j++)
                if(mat[i][k] && mat[k][j] && i!=j && (mat[i][j]>mat[i][k]+mat[k][j] || !mat[i][j]))
                    mat[i][j]=mat[i][k]+mat[k][j];

    for(i=1; i<=n; i++){
        for(j=1; j<=n; j++)
            printf("%d ", mat[i][j]);
        printf("\n");
    }
    return 0;
}
