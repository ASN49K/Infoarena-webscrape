#include <iostream>
#include <fstream>
#define inf 1000000000
using namespace std;
ifstream fin("royfloyd.in");

ofstream fout("royfloyd.out");

int a[105][105],i,j,n,k;
int main()
{
    fin>>n;
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            fin>>a[i][j];
            if(a[i][j]==0)
                a[i][j]=inf;
        }
    }
    for(k=1;k<=n;k++)
    {
        for(i=1;i<=n;i++)
        {
            for(j=1;j<=n;j++)
            {
                if(i!=j&&j!=k&&i!=k)
                 if(a[i][j]>a[i][k]+a[k][j])
                    a[i][j]=a[i][k]+a[k][j];
            }
        }
    }
    for(i=1;i<=n;i++,fout<<"\n")
    {
        for(j=1;j<=n;j++)
        {
            if(a[i][j]==inf)
                fout<<0<<" ";
            else
            fout<<a[i][j]<<" ";
        }
    }
    return 0;
}
