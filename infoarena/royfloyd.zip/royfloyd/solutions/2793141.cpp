#include <iostream>
#include <cmath>

using namespace std;

int n, a[110][110];

int main()
{
    cin >> n;
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++)
        {
            cin >> a[i][j];
            if(a[i][j] == 0)
                a[i][j] == 999999999;
        }
    for(int k = 1; k <= n; k++)
        for(int i = 1; i <= n; i++)
            for(int j = 1; j <= n; j++)
                if(i != j && j != k && i != k)
                    a[i][j] = min(a[i][j], a[i][k] + a[k][j]);
    for(int i = 1; i <= n; i++)
    {
        for(int j = 1; j <= n; j++)
        {
            if(a[i][j] == 999999999)
                cout << "0 ";
            else cout << a[i][j] << " ";
        }
        cout << "\n";
    }
    return 0;
}
