#include <fstream>
using namespace std;
  
int n, a[105][105];
ofstream g ("royfloyd.out");
ifstream f ("royfloyd.in");
void citire()
{
  int i, j;
f>>n;
for (i = 1; i <= n; i++)
for (j = 1; j <= n; j++)
f>>a[i][j];
}
  
void floydwarshall()
{
int i, j, k;
for (k = 1; k <= n; k++)
for (i = 1; i <= n; i++)
for (j = 1; j <= n; j++)
    if (a[i][k] && a[k][j] && (a[i][j] > a[i][k] + a[k][j] || !a[i][j]) && i != j) a[i][j] = a[i][k] + a[k][j];
}
  
void afisare()
{
int i, j;
for (i=1; i<=n; i++)
    {
    for (j=1; j<=n; j++)
       g<<a[i][j]<<" ";
       g<<endl;
     
         
}}
  int main()
{
   citire();
   floydwarshall();
   afisare();
   return 0;
}
