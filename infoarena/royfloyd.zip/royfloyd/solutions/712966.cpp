#include <stdio.h>
#define FI fopen("royfloyd.in","r")
#define FO fopen("royfloyd.out","w")

int mat[100][100],n;

void citeste(FILE *f) {
	int i,j;
	fscanf(f,"%i",&n);
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			fscanf(f,"%i",&mat[i][j]);
}

void royFloyd() {
	int i,j,k;
	for(k=0;k<n;++k)
		for(i=0;i<n;++i)
			for(j=0;j<n;++j)
				if(mat[i][k] && mat[k][j] && (mat[i][j]>mat[i][k]+mat[k][j] || mat[i][j]==0) && i!=j)
					mat[i][j]=mat[i][k]+mat[k][j];
}

void scrie (FILE *f) {
	int i,j;
	for(i=0;i<n;i++) {
		for(j=0;j<n;j++)
			fprintf(f,"%i ",mat[i][j]);
		fprintf(f,"\n");
	}
}

int main() {
	citeste(FI);
	royFloyd();
	scrie(FO);
	return 0;
}
