#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

vector<vector<int>> D(100, vector<int>(100));

int main()
{

    ifstream fin("royfloyd.in");
    ofstream fout("royfloyd.out");

    int n;
    fin >> n;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            fin >> D[i][j];

    for (int k = 0; k < n; k++)
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                D[i][j] = min(D[i][k] + D[k][j], D[i][j]);

    for (int i = 0; i < n; i++){
        for (int j = 0; j < n; j++)
            fout << D[i][j] << ' ';
        fout << '\n';
    }

    return 0;
}
