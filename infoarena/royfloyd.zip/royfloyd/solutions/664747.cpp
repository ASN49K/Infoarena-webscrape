#include <stdio.h>
#include <fstream>

int n, i, j, k, a[105][105];

void roy_floyd()
{
	for (k = 1; k <= n; k++)
		for (i = 1; i <= n; i++)
			for (j = 1; j <= n; j++)
				 a[i][j] =std:: min ( a[i][j], a[i][k]+a[k][j] );
}

int main()
{
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);

	scanf("%d",&n);
	for (i = 1; i <= n; i++)
		for (j = 1; j <= n; j++) 
			scanf("%d",&a[i][j]);
			
	roy_floyd();
	
	for (i = 1; i <= n; i++) 
	{
		for (j = 1; j <= n; j++) printf("%d ",a[i][j]);
		printf("\n");
	}
}

