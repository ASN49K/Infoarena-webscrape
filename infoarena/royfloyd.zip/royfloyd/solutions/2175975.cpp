#include <fstream>

using namespace std;

int matCost[101][101], N;

void CitireDateIntrare();
void Roy_Floyd();
void AfisareRezultat();

int main() {
	CitireDateIntrare();
	Roy_Floyd();
	AfisareRezultat();
}

void CitireDateIntrare()
{
	ifstream fIn("royfloyd.in");
	fIn >> N;
	for (int i = 1; i <= N; i++)
		for (int j = 1; j <= N; j++)
			fIn >> matCost[i][j];
	fIn.close();
}

void Roy_Floyd()
{
	for (int k = 1; k <= N; k++)
		for (int i = 1; i <= N; i++)
			for (int j = 1; j <= N; j++)
				if (matCost[i][k] != 0 && matCost[k][j] != 0 && matCost[i][k] + matCost[k][j] < matCost[i][j])
					matCost[i][j] = matCost[i][k] + matCost[k][j];
}

void AfisareRezultat()
{
	ofstream fOut("royfloyd.out");
	for (int i = 1; i <= N; i++)
	{
		for (int j = 1; j <= N; j++)
			fOut << matCost[i][j] << ' ';
		fOut << '\n';
	}
	fOut.close();
}
