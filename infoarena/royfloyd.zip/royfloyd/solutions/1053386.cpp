#include<fstream>
using namespace std;

int n,v[110][110];

void citire () {

    ifstream in("royfloyd.in");
    int i,j;

    in>>n;

    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            in>>v[i][j];

    in.close();

}

void royfloyd() {

    int i,j,k;

    for(i=1;i<=n;i++)
        for(j=1;j<=n;j++)
            for(k=1;k<=n;k++)
                if(v[i][j]>v[i][k]+v[k][j] && v[i][k]!=0 && v[k][j]!=0)
                    v[i][j]=v[i][k]+v[k][j];

}

void afisare() {

    ofstream out("royfloyd.out");
    int i,j;

    for(i=1;i<=n;i++) {
        for(j=1;j<=n;j++)
            out<<v[i][j]<<" ";
        out<<'\n';
        }

    out.close();

}

int main (){

    citire();
    royfloyd();
    afisare();
}
