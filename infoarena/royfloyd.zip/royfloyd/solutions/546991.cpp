#include <cstdio>

#define MaxN 110
#define inf 1000000

int a[MaxN][MaxN],N;

/*void init()
{
	int i,j;
	for(i=1;i<=N;i++)
		for(j=1;j<=N;j++)
			a[i][j]=inf;
}*/

void cit()
{
	int i,j;
	scanf("%d",&N);
	//init();
	for(i=1;i<=N;i++)
		for(j=1;j<=N;j++)
			scanf("%d",&a[i][j]);
}

void royfloyd()
{
	int i,j,k;
	for(k=1;k<=N;k++)
		for(i=1;i<=N;i++)
			for(j=1;j<=N;j++)
				if(a[i][k] && a[k][j] && a[i][j] && (a[i][k]+a[k][j]<a[i][j] || !a[i][j]) && i!=j)
					a[i][j]=a[i][k]+a[k][j];
}

void afis()
{
	int i,j;
	for(i=1;i<=N;i++)
	{
		for(j=1;j<=N;j++)
			/*if(a[i][j]>=inf)
				printf("0 ");
			else*/
				printf("%d ",a[i][j]);
		printf("\n");
	}
}

int main()
{
	freopen("royfloyd.in","r",stdin);
	freopen("royfloyd.out","w",stdout);
	cit();
	royfloyd();
	afis();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
