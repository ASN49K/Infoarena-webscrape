#include<stdio.h>

int main(void) 
{
	freopen("royfloyd.in", "r", stdin);
	freopen("royfloyd.out", "w", stdout);

	int n;
	int dist[101][101];

	int i,j,k;

	scanf("%d\n", &n);
	for(i=0;i<n;++i) 
	{
		for(j=0;j<n;++j)
		{
			scanf("%d", &dist[i][j]);
		}
	}


	for(k=0;k<n;++k)
	{
		for(i=0;i<n;++i)
		{
			for(j=0;j<n;++j)
			{
				if(dist[i][k]!=0 && dist[k][j] != 0 && (dist[i][j] > dist[i][k] + dist[k][j] || dist[i][j] == 0) && i!=j)
					dist[i][j] = dist[i][k] + dist[k][j];
			}
		}
	}

	for(i=0;i<n;++i)
	{
		for(j=0;j<n;++j)
		{
			printf("%ld ", dist[i][j]);
		}
		printf("\n");
	}

	return 0;
}
