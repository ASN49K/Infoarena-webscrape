#include <fstream>
const int NMAX=1005;

using namespace std;
ifstream cin("royfloyd.in");
ofstream cout("royfloyd.out");

int dp[NMAX][NMAX];
int n;

int main()
{
  int i, j, k;
  ios_base::sync_with_stdio(false);
  cin.tie(0); cout.tie(0);
  cin>>n;
  for(i=1; i<=n; i++)
  {
    for(j=1; j<=n; j++)
    {
      cin>>dp[i][j];
      if(dp[i][j]==0) dp[i][j]=1e9;
    }
  }
  for(k=1; k<=n; k++)
  {
    for(i=1; i<=n; i++)
    {
      for(j=1; j<=n; j++)
      {
        dp[i][j]=min(dp[i][j], dp[i][k]+dp[k][j]);
      }
    }
  }
  for(i=1; i<=n; i++)
  {
    for(j=1; j<=n; j++)
    {
      if(dp[i][j]==1e9 || i==j) dp[i][j]=0;
      cout<<dp[i][j]<<' ';
    }
    cout<<'\n';
  }
  return 0;
}
